package evs.metric.metrics;

import evs.metric.parameters.DoubleProcedureParameter;

/**
 * An interface that denotes a metric with one or more thresholds.  For example, 
 * a score may be computed for a specific probability threshold.  
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public interface ThresholdMetric {
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/     

    /**
     * Returns the thresholds for the current metric or null.    
     *
     * @return the thresholds for the metric
     */
    
    abstract DoubleProcedureParameter getThreshold();

    /********************************************************************************
     *                                                                              *
     *                                MUTATOR METHODS                               *
     *                                                                              *
     *******************************************************************************/     

    /**
     * Returns the thresholds for the current metric or null.    
     *
     * @param threshold the threshold
     */
    
    abstract void setThreshold(DoubleProcedureParameter threshold);

}
