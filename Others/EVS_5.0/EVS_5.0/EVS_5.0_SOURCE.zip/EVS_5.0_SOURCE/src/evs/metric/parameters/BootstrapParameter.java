package evs.metric.parameters;

//EVS dependencies
import evs.data.*;
import evs.metric.metrics.*;
import evs.data.fileio.*;
import evs.utilities.mathutil.*;

//Java dependencies
import java.util.*;

/**
 * A store of bootstrap parameters required for assessing the sampling uncertainty of
 * a verification metric via bootstrapping. The precise parameters will depend on the
 * bootstrap technique, for which specific constructors and getter/setter methods
 * are provided.  Intervals may be added or removed for computation. Only one interval
 * may be defined as a "main" interval. The usage of a main interval is unspecified
 * by this class, but it might be used to preferentially select one interval for display.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public final class BootstrapParameter implements MetricParameter {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLE                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * The bootstrap technique identifier.
     */
    
    private int technique;

    /**
     * The bootstrap technique string.
     */

    private String techniqueString;

    /**
     * Nominal block size in units of absolute time given below for use block
     * bootstrap algorithms.  The precise meaning varies with block bootstrap
     * algorithm. For example, the stationary block bootstrap treats the block
     * size as a random variable with geometric distribution, for which this
     * value is the mean (1/p) of the Geometric distribution with probability of
     * success, p.
     */

    private double nominalBlockSize;

    /**
     * Time units of the nominal block size.
     */

    private String nominalBlockSizeUnits;

    /**
     * Nominal block size in milliseconds, computed on construction or on a change
     * in the nominal block size.
     */

    private long nominalBlockSizeMillis;

    /**
     * Multiplier for the nominal block size in native units to arrive at the
     * block size in milliseconds.
     */

    private double blockMult = 0;

    /**
     * Multiplier for the nominal block size in native units to arrive at the
     * block size in hours.
     */

    private double blockMultHours = 0;

    /**
     * The bootstrap sample count.
     */

    private int sampleCount;
    
    /**
     * Minimum sample count for which bootstrap results will be returned.
     */
    
    private int minSampleCount = 0;

    /**
     * An array of intervals to compute.
     */
    
    private ProbabilityIntervalParameter[] intervals = null;

    /**
     * Main interval, if defined. This should always be stored in the list of
     * intervals if non-null. May be null.
     */

    private ProbabilityIntervalParameter main = null;

    /**
     * Pseudo-random number generator, built on construction with the current
     * time in milliseconds.
     */

    private MersenneTwister random = null;

    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     

    /**
     * Default constructor, which constructs a parameter with identifier
     * {@link BootstrapableMetric#NO_BOOTSTRAP}.
     */

    public BootstrapParameter() {
        technique = BootstrapableMetric.NO_BOOTSTRAP;
        techniqueString = BootstrapableMetric.NO_BOOTSTRAP_STRING;
    }

    /**
     * Constructs a parameter object for a stationary block bootstrap.
     *
     * @param nominalBlockSize the nominal block size > 0 in the given units
     * @param timeUnits the time units
     * @param sampleCount the sampleCount > 0
     * @param minSampleCount the minimum sample count > 0
     * @param intervals at least one valid interval
     * @param main the main interval (may be null)
     */
    
    public BootstrapParameter(double nominalBlockSize,String timeUnits,int sampleCount, int minSampleCount,
            ProbabilityIntervalParameter[] intervals,ProbabilityIntervalParameter main) {
        technique = BootstrapableMetric.STATIONARY_BLOCK_BOOTSTRAP;
        techniqueString = BootstrapableMetric.STATIONARY_BLOCK_BOOTSTRAP_STRING;
        setNominalBlockSize(nominalBlockSize,timeUnits);
        setSampleCount(sampleCount,minSampleCount);
        setIntervals(intervals);
        if(main!=null) {
            setMainInterval(main);
        }
        random = new MersenneTwister(System.currentTimeMillis());
    }
    
    /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/       
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "bootstrap_parameter";
    }

    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     *
     * @return an identifier
     */

    public int getID() {
        return BOOTSTRAP_PARAMETER;
    }

    /**
     * Returns the bootstrap technique requested.
     *
     * @return an identifier from {@link evs.metric.metrics.BootstrapableMetric}
     */

    public int getTechnique() {
        return technique;
    }

    /**
     * Returns a string representation of the bootstrap technique. One of the
     * string class variables in {@link evs.metric.metrics.BootstrapableMetric}
     *
     * @return a string identifier from {@link evs.metric.metrics.BootstrapableMetric}
     */

    public String getTechniqueString() {
        return techniqueString;
    }

    /**
     * Returns a technique identifier for a named technique or throws an exception
     * if the named technique is not recognized.
     *
     * @param techniqueString the named technique
     * @return an identifier for the input string
     */

    public static int getTechniqueForString(String techniqueString) {
        if(techniqueString.equalsIgnoreCase(BootstrapableMetric.NO_BOOTSTRAP_STRING)) {
            return BootstrapableMetric.NO_BOOTSTRAP;
        } else if(techniqueString.equalsIgnoreCase(BootstrapableMetric.STATIONARY_BLOCK_BOOTSTRAP_STRING)) {
            return BootstrapableMetric.STATIONARY_BLOCK_BOOTSTRAP;
        } else {
            throw new IllegalArgumentException("Unrecognized technique '"+techniqueString+"'.");
        }
    }

    /**
     * Returns a technique string for a specified technique or throws an exception
     * if the technique is not recognized.
     *
     * @param technique the technique
     * @return a string identifier for the input technique
     */

    public static String getStringForTechnique(int technique) {
        switch(technique) {
            case BootstrapableMetric.NO_BOOTSTRAP: {
                return BootstrapableMetric.NO_BOOTSTRAP_STRING;
            }
            case BootstrapableMetric.STATIONARY_BLOCK_BOOTSTRAP: {
                return BootstrapableMetric.STATIONARY_BLOCK_BOOTSTRAP_STRING;
            }
            default: throw new IllegalArgumentException("Unrecoginized technique identifier for bootstrapping: "+technique);
        }
    }

    /**
     * Returns a copy of the intervals that should be computed.
     *
     * @return a copy of the intervals
     */

    public ProbabilityIntervalParameter[] getIntervals() {
        ProbabilityIntervalParameter[] v = new ProbabilityIntervalParameter[intervals.length];
        for(int i = 0; i < v.length; i++) {
            v[i]=(ProbabilityIntervalParameter)intervals[i].deepCopy();
        }
        return v;
    }

    /**
     * Returns a copy the main interval or null if undefined.
     *
     * @return a copy of the main interval or null
     */

    public ProbabilityIntervalParameter getMainInterval() {
        ProbabilityIntervalParameter returnMe = null;
        if(main != null) {
            returnMe = (ProbabilityIntervalParameter)main.deepCopy();
        }
        return returnMe;
    }

    /**
     * Returns a whole number from the Geometric probability distribution with
     * mean equal to 1/p, where p is the probability of success. The mean is equal
     * to the nominal block size of this instance.  Returns a random number using
     * the inverse transform method.  Throws an exception if the nominal block size
     * has not been set.
     *
     * @return a random number from the geometric distribution with mean equal to
     * the nominal block size
     */

    public double getRandomBlockSize() {
        if(nominalBlockSize==0) {
            throw new IllegalArgumentException("Cannot return a random block size: "
                    + "the nominal block size has not been set.");
        }
        //Random number in (0,1]
        double u = random.nextDouble();
        while(u==0) {
            u = random.nextDouble();
        }
        double p = 1.0/nominalBlockSize;
        return Math.floor(Math.log(1.0 - u)/Math.log(1.0 - p))+1;
    }

    /**
     * Returns a whole number from the Geometric probability distribution with
     * mean equal to 1/p, where p is the probability of success. The mean is equal
     * to the nominal block size of this instance.  Returns a random number using
     * the inverse transform method.  Throws an exception if the nominal block size
     * has not been set. The number is returned in units of milliseconds.  See
     * {@link #getRandomBlockSize}.
     *
     * @return a random number in milliseconds from the geometric distribution
     * with mean equal to the nominal block size
     */

    public double getRandomBlockSizeInMillis() {
        return getRandomBlockSize()*blockMult;
    }

    /**
     * Convenience method that returns a random block size in hours. See
     * {@link #getRandomBlockSize}.
     *
     * @return a random number in hours from the geometric distribution
     * with mean equal to the nominal block size
     */

    public double getRandomBlockSizeInHours() {
        return getRandomBlockSize()*blockMultHours;
    }

    /**
     * Returns true if the bootstrap parameter technique is something other than
     * BootstrapableMetric.NO_BOOTSTRAP.
     *
     * @return true if the bootstrap parameters has been set
     */

    public boolean isBootstrap() {
        return technique != BootstrapableMetric.NO_BOOTSTRAP;
    }

    /**
     * Returns true if a main interval has been defined, false otherwise.
     *
     * @return true if a main interval has been defined, false otherwise
     */

    public boolean hasMainInterval() {
        return main != null;
    }

    /**
     * Returns the nominal block size for a block bootstrap.  Interpretation of
     * the nominal block size varies with the block bootstrap technique.
     *
     * @return the nominal block size
     */

    public double getNominalBlockSize() {
        return nominalBlockSize;
    }
    
    /**
     * Returns the time units associated with the nominal block size.
     *
     * @return the time units of the nominal block size
     */

    public String getNominalBlockSizeUnits() {
        return nominalBlockSizeUnits;
    }        
    
    /**
     * Returns the nominal block size in milliseconds.
     *
     * @return the nominal block size in milliseconds
     */

    public long getNominalBlockSizeInMillis() {
        return nominalBlockSizeMillis;
    }

    /**
     * Returns the bootstrap sample count.
     *
     * @return the bootstrap sample count
     */

    public int getSampleCount() {
        return sampleCount;
    }
    
    /**
     * Returns the minimum bootstrap sample count.
     *
     * @return the minimum bootstrap sample count
     */

    public int getMinSampleCount() {
        return minSampleCount;
    }    

    /**
     * Returns a deep copy of the current metric parameter, where all instance variables
     * occupy independent positions in memory from the current metric parameter.
     *
     * @return a deep copy of the current object
     */

    public MetricParameter deepCopy() {
        BootstrapParameter b = new BootstrapParameter();
        b.technique=technique;
        b.techniqueString=techniqueString;
        b.nominalBlockSize = nominalBlockSize;
        b.nominalBlockSizeUnits = nominalBlockSizeUnits;
        b.nominalBlockSizeMillis = nominalBlockSizeMillis;
        b.sampleCount = sampleCount;
        b.minSampleCount = minSampleCount;
        b.blockMult = blockMult;
        b.blockMultHours = blockMultHours;
        b.random = new MersenneTwister(System.currentTimeMillis());
        if(intervals!=null && intervals.length>0) {
            b.intervals = getIntervals();
        }
        if(main!=null) {
            b.main = (ProbabilityIntervalParameter)main.deepCopy();
        }
        return b;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final BootstrapParameter other = (BootstrapParameter) obj;
        if (this.technique != other.technique) {
            return false;
        }
        if (this.nominalBlockSizeMillis != other.nominalBlockSizeMillis) {
            return false;
        }
        if (this.sampleCount != other.sampleCount) {
            return false;
        }
        if (this.minSampleCount != other.minSampleCount) {
            return false;
        }
        if (this.intervals != other.intervals && (this.intervals == null || 
                !Arrays.deepEquals(this.intervals,other.intervals))) {
            return false;
        }
        if (this.main != other.main && (this.main == null || !this.main.equals(other.main))) {
            return false;
        }
        return true;
    }

    /**
     * Override hashcode: not implemented.
     *
     * @return a hashcode
     */

    public int hashCode() {
        assert false : "hashCode not implemented for MetricParameter.";
        return 1;
    }

    /**
     * Returns a string representation of the receiver.
     *
     * @return a string representation
     */

    public String toString() {
        StringBuffer b = new StringBuffer();
        String nL = System.getProperty("line.separator");
        b.append("Technique: "+techniqueString);
        if(technique!=BootstrapableMetric.NO_BOOTSTRAP) {
            b.append(nL+"Sample count: "+sampleCount);
            b.append(nL+"Minimum sample count: "+minSampleCount);
            b.append(nL+"Nominal block size: "+nominalBlockSize);
            b.append(nL+"Nominal block size units: "+nominalBlockSizeUnits);
            if(main!=null) {
                b.append(nL+"Main interval: "+main);
            }
            for(ProbabilityIntervalParameter p : intervals) {
                b.append(nL+"Interval: "+p);
            }
        }
        return b.toString();
    }

    /********************************************************************************
     *                                                                              *
     *                               MUTATOR METHODS                                *
     *                                                                              *
     *******************************************************************************/

    /**
     * Sets the intervals that should be computed, replacing any existing intervals
     * and clearing any main interval.
     *
     * @param intervals the intervals
     */

    public void setIntervals(ProbabilityIntervalParameter[] intervals) {
        if(technique==BootstrapableMetric.NO_BOOTSTRAP) {
            throw new IllegalArgumentException("Cannot set bootstrap intervals: the bootstrap parameter was "
                    + "constructed with technique: "+techniqueString+"'.");
        }
        if(intervals == null || intervals.length==0) {
            throw new IllegalArgumentException("Specify at least one interval for bootstrapping.");
        }
        for(ProbabilityIntervalParameter in : intervals) {
            addInterval(in);
        }
        main = null;
    }

    /**
     * Sets the nominal block size associated with a block bootstrap.
     *
     * @param nominalBlockSize the nominal block size
     * @param timeUnits the time units
     */

    public void setNominalBlockSize(double nominalBlockSize, String timeUnits) throws InvalidUnitException {
        checkBlockTechnique("Block size");
        //Check input
        if(nominalBlockSize<=0) {
            throw new IllegalArgumentException("Enter a positive nominal block size " +
                    "for the block bootstrap: "+nominalBlockSize);
        }
        GlobalUnitsReader.isSupportedTimeUnit(timeUnits,true);
        double mult = GlobalUnitsReader.getMilliConversionFactor(timeUnits);
        nominalBlockSizeMillis = (long)(nominalBlockSize*mult);
        this.nominalBlockSize = nominalBlockSize;
        nominalBlockSizeUnits = timeUnits.toUpperCase();
        blockMult = mult;
        blockMultHours = blockMult/(1000*60*60);
    }

    /**
     * Adds an interval to the store.  Returns true if the interval was added,
     * false if the store contained the same interval.
     *
     * @param interval the interval to compute
     */
   
    public boolean addInterval(ProbabilityIntervalParameter interval) {
        if(technique==BootstrapableMetric.NO_BOOTSTRAP) {
            throw new IllegalArgumentException("Cannot add a bootstrap interval: the bootstrap parameter was "
                    + "constructed with technique: "+techniqueString+"'.");
        }
        if(intervals==null) {
            intervals = new ProbabilityIntervalParameter[]{
                (ProbabilityIntervalParameter)interval.deepCopy()
            };
        }
        else if(Arrays.binarySearch(intervals, interval) < 0) {
            ProbabilityIntervalParameter[] inte = new ProbabilityIntervalParameter[intervals.length+1];
            System.arraycopy(intervals,0,inte,0,intervals.length);
            inte[intervals.length]=(ProbabilityIntervalParameter)interval.deepCopy();
            Arrays.sort(inte);
            intervals = inte;
            return true;
        }
        return false;
    }

    /**
     * Sets the bootstrap sample count, which must be > 0 and > the minimum sample
     * count.
     *
     * @param sampleCount the sample count
     * @param minSampleCount the minimum sample count
     */
    
    public void setSampleCount(int sampleCount, int minSampleCount) {
        checkBlockTechnique("Sample counts");
        if(!(sampleCount > 0)) {
            throw new IllegalArgumentException("Specify a bootstrap sample count > 0: "+sampleCount+".");
        }
        if(minSampleCount <=0 || minSampleCount > sampleCount) {
            throw new IllegalArgumentException("Specify a minimum bootstrap sample count > 0 and <= " +
                    "the sample count of "+sampleCount+": "+minSampleCount+".");
        }
        this.sampleCount = sampleCount;
        this.minSampleCount = minSampleCount;
    }

    /**
     * Sets the main interval, adding the interval to the store if not currently
     * stored.  This should be set after the main intervals.
     * 
     * @param interval the interval to compute
     */
    
    public void setMainInterval(ProbabilityIntervalParameter interval) {
        if(technique==BootstrapableMetric.NO_BOOTSTRAP) {
            throw new IllegalArgumentException("Cannot set the main bootstrap interval: the bootstrap parameter was "
                    + "constructed with technique: "+techniqueString+"'.");
        }
        main = (ProbabilityIntervalParameter)interval.deepCopy();
        addInterval(main);
    }
    
    /**
     * Clears all parameters and sets the technique identifier to
     * BootstrapableMetric.NO_BOOTSTRAP.
     */

    public void clear() {
        technique = BootstrapableMetric.NO_BOOTSTRAP;
        techniqueString = BootstrapableMetric.NO_BOOTSTRAP_STRING;
        clearIntervals();
        nominalBlockSize = 0;
        nominalBlockSizeMillis = 0;
        nominalBlockSizeUnits = null;
        sampleCount = 0;
        minSampleCount = 0;
        blockMult = 0;
        blockMultHours = 0;
        random = null;
    }

    /********************************************************************************
     *                                                                              *
     *                                PRIVATE METHODS                               *
     *                                                                              *
     *******************************************************************************/

    /**
     * Clears the list of intervals stored.
     */

    private void clearIntervals() {
        intervals = null;
        main = null;
    }

    /**
     * Throws an exception on attempting to set a block parameter when the technique
     * associated with the bootstrap parameter is not a block technique.
     *
     * @param parName the parameter name to be set
     */

    private void checkBlockTechnique(String parName) {
        if(technique!=BootstrapableMetric.STATIONARY_BLOCK_BOOTSTRAP) {
            throw new IllegalArgumentException("Cannot set bootstrap parameter '"+parName+"', as "
                    + "the technique associated with the parameter object is not a block technique: '"+techniqueString+"'.");
        }
    }

}
