package evs.metric.metrics;

//EVS dependencies
import evs.data.*;
import evs.metric.parameters.*;
import evs.metric.results.*;
import evs.utilities.*;
import evs.utilities.matrix.*;
import evs.utilities.mathutil.*;

//Java util dependencies
import java.util.*;

/**
 * Constructs a reliability diagram for specified forecast probability thresholds 
 * and probability thresholds of the observations given the forecasts.  For continuous
 * data, an 'event' must be defined.  
 * 
 * The reliability diagram may contain missing data, which is represented by the 
 * {@link evs.metric.metrics.Metric#NULL_DATA} value.
 * 
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ReliabilityDiagram extends DiagramMetric implements ThresholdMetric,
        EnsembleMetric, CategoricalMetric, BootstrapableMetric {

    /********************************************************************************
     *                                                                              *
     *                             INSTANCE VARIABLES                               *
     *                                                                              *
     *******************************************************************************/ 
    
    /**
     * Default number of points to include in a ROC diagram.
     */
    
    private static PositiveIntegerParameter defPCount = new ReliabilityPointsParameter(5);    
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Attempts to construct a reliability diagram with associated parameters.
     *
     * @param event the event threshold 
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use 
     * @param equal is true to use equal sample counts in the reliability bins, false otherwise 
     * conditional pairs when available
     * @param points the number of points to use in the diagram
     * @param minS the minimum sample size
     * @param bs the bootstrap parameter
     */
    
    public ReliabilityDiagram(DoubleProcedureParameter event, ForecastTypeParameter fType,
            UnconditionalParameter unconditional, EqualSamplesParameter equal,
            ReliabilityPointsParameter points,MinimumSampleSizeParameter minS,BootstrapParameter bs) {
        //Set the name
        name = "Reliability diagram";
        //Set the parameters
        setParameters(new MetricParameter[]{event.deepCopy(),fType.deepCopy(),
            unconditional.deepCopy(),equal.deepCopy(),points.deepCopy(),minS.deepCopy(),bs.deepCopy()});
        //Set the link to html description of the metric
        descriptionURL = getClass().getResource(EVSConstants.STATS_EXPLAINED_DIR + "reliability.htm");
    }
    
     /*******************************************************************************
     *                                                                              *
     *                                ACCESSOR METHODS                              *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Returns the metric identifier.
     *
     * @return an identifier
     */
    
    public int getID() {
        return RELIABILITY_DIAGRAM;
    }        
    
    /**
     * Returns the result type associated with the metric.  See the 
     * evs.metric.MetricResult class for supported types.
     *
     * @return an identifier
     */
    
    public int getResultID() {
        return MetricResult.DOUBLE_MATRIX_2D_RESULT;
    }         
    
    /**
     * Returns true if the metric is defined in real units of the forecast
     * and observed variable, false otherwise.
     * 
     * @return true if the metric is defined in real units
     */    

    public boolean hasRealUnits() {
        return false;
    }       
    
    /**
     * Returns the threshold associated with this threshold diagram.
     *
     * @return the threshold
     */
    
    public DoubleProcedureParameter getThreshold() {
        return (DoubleProcedureParameter)pars[0].deepCopy();
    }    
    
    /**
     * Returns a deep copy of the current metric, where all instance variables 
     * occupy independent positions in memory from the current metric.  
     *
     * @return a deep copy of the current object 
     */
    
    public Metric deepCopy() {
        ReliabilityDiagram returnMe = new ReliabilityDiagram(
                (DoubleProcedureParameter)pars[0].deepCopy(),
                (ForecastTypeParameter)pars[1].deepCopy(),
                (UnconditionalParameter)pars[2].deepCopy(),
                (EqualSamplesParameter)pars[3].deepCopy(),
                (ReliabilityPointsParameter)pars[4].deepCopy(),
                (MinimumSampleSizeParameter)pars[5].deepCopy(),
                getBootstrapPar());
        deepCopyResults(returnMe);
        return returnMe;
    }      

    /**
     * Returns the bootstrap parameter associated with the verification metric.
     *
     * @return the bootstrap parameter
     */
    @Override
    public BootstrapParameter getBootstrapPar() {
        return (BootstrapParameter)pars[6].deepCopy();
    }

    /**
     * Returns the default point count.  
     *
     * @return the default point count
     */
    
    public static PositiveIntegerParameter getDefaultPointCount() {
        return (PositiveIntegerParameter)defPCount.deepCopy();
    }    
    
    /**
     * Returns a metric with default parameter values.  
     *
     * @return a metric with default parameter values.
     */
    
    public static Metric getDefaultMetric() { 
        ProbabilityIdentifierParameter prob =new ProbabilityIdentifierParameter(true);
        DoubleProcedureParameter eT = new DoubleProcedureParameter(new IntegerParameter(DoubleProcedureParameter.GREATER_THAN),
                new DoubleParameter[]{new ProbabilityParameter(0.0)},prob,new BooleanParameter(true));
        ForecastTypeParameter type = new ForecastTypeParameter(new int[]{ForecastTypeParameter.REGULAR_FORECAST});
        return new ReliabilityDiagram(eT,type,new UnconditionalParameter(false),
                new EqualSamplesParameter(false),new ReliabilityPointsParameter(5),
                new MinimumSampleSizeParameter(),new BootstrapParameter());
    }    
    
     /*******************************************************************************
     *                                                                              *
     *                                MUTATOR METHODS                               *
     *                                                                              *
     *******************************************************************************/        

    /**
     * Uses the specified paired data to compute and return the result of the metric.
     * The metric results are returned, together with the sample counts, but not stored 
     * locally.  The metric result is located in the first index of the return array
     * and the sample counts are located in the second index. Optionally, specify
     * the results of a reference forecast from which to compute skill if the 
     * metric is a skill score. 
     * 
     * @param forecastType the forecast type
     * @param paired the paired data
     * @param refResult the results for a reference forecast (may be null)
     * @return the metric result and sample counts
     */
    
    public MetricResult[] compute(int forecastType, PairedData paired, MetricResult refResult) throws MetricCalculationException {
        if(paired==null) {
            throw new MetricCalculationException("Error computing metric '"+getName()+"': input pairs were null.");
        }
        ForecastTypeParameter.isSupportedForecastType(forecastType,true);
        MetricResult[] res = new MetricResult[2];
        DoubleProcedure pro = getThreshold().getParValReal();
        DoubleMatrix2D p = paired.getPairs();
        double nV = paired.getNullValue();
//        try {
            res[0]=getRel((DoubleMatrix2D)p.getSubmatrixByColumn(2,p.getColumnCount()-1),pro,nV);
            res[1]=new IntegerResult(lastCount);
//        } catch (Exception e) {
//            //e.printStackTrace();
//        }
        return res; 
    }   

    /**
     * Sets the threshold for the current metric.
     *
     * @param threshold the threshold
     */

    public void setThreshold(DoubleProcedureParameter threshold) {
        pars[0] = (DoubleProcedureParameter)threshold.deepCopy();
    }

    /**
     * Sets the bootstrap parameter associated with the verification metric or
     * clears the parameter if the input is null;
     *
     * @param bs the bootstrap parameter
     */
    @Override
    public void setBootstrapPar(BootstrapParameter bs) {
        if(bs==null) {
            throw new IllegalArgumentException("The bootstrap parameter for metric '"+this+"' cannot be null.");
        } else {
            pars[6] = (BootstrapParameter)bs.deepCopy();
        }
    }

    /**
     * Sets the bootstrap parameter to BootstrapableMetric.NO_BOOTSTRAP and clears
     * all associated parameter values.
     */
    @Override
    public void clearBootstrapPar() {
        ((BootstrapParameter)pars[6]).clear();
    }

    /**
     * Returns the reliability diagram from the input data, comprising the forecast
     * probabilities in the first row, the observed probabilities in the second row,
     * the sample counts in the third row, the climatological frequency in the fourth
     * row, and the no skill line in the fifth row.  The input should comprise one
     * column of observations (at index 0) and the remaining n columns should 
     * comprise the n ensemble members (index 1 through n). 
     *
     * @param data the input data
     * @param pro the threshold with values in real units
     * @param nV the null value
     * @return the reliability
     */
    
    public MetricResult getRel(DoubleMatrix2D data, DoubleProcedure pro, double nV) throws MetricCalculationException {    
        
        int totSize = data.getRowCount();
        int sampleSize = 0;
         
        //Compute the forecast probabilities at each index and whether the event occurred
        double[] fProbs = new double[totSize];
        int[] occurred = new int[totSize];
        int mCount = data.getColumnCount();  //Obs in first index
        double clim =  0;//Climatological frequency
        for(int i = 0; i < totSize; i++) {
            double num = 0.0;
            double den = 0.0;
            for(int j = 1; j < mCount; j++) {  //Obs in first index
                double next = data.get(i,j);
                if(next != nV) {
                    if(pro.apply(next)) {
                        num+=1.0;
                    }
                    den+=1.0;
                }
            }
            if(den != 0) {
                fProbs[i] = num/den;
                if(pro.apply(data.get(i,0))) {
                    occurred[i] = 1;
                    clim+=1;
                }
                sampleSize++;
            }
        }

        int obsTotal = (int)clim;
        int obsNotTotal = (int)(sampleSize-clim);
        
        int minCount = ((MinimumSampleSizeParameter)pars[5]).getParVal();
        int testRows = Math.min(obsTotal,obsNotTotal);
        String occStatus = "occurrences";
        if(obsNotTotal<obsTotal) {
            occStatus = "non-occurrences";
        }
        lastCount = sampleSize;
        if(testRows < minCount) {
            throw new MetricCalculationException("Could not compute the reliability diagram: fewer "+occStatus+" than required ["+testRows+","+minCount+"].");
        }
        
        clim = clim/sampleSize;
        
        //Compute the average forecast prob within the bins, together with the observed relative frequency
        //Use 1.0/(totProb-1) increments
            
        EqualSamplesParameter equalSamples = (EqualSamplesParameter)pars[3];
        int pointsCount = ((ReliabilityPointsParameter)pars[4]).getParVal();
        
        int totProb = pointsCount+1;  //Bin count + 1
        double[][] rel = new double[5][totProb-1];
        //Equiprobable bins
        if (!equalSamples.getParVal()) {

            double inc = 1.0 / (totProb - 1.0);
            int[] countsa = new int[totProb - 1];
            for (int i = 1; i < totProb; i++) {
                double lower = (i - 1) * inc;
                double upper = i * inc;
                if (lower == 0.0) {
                    lower = -1;  //Catches zero forecast probability below
                }
                for (int j = 0; j < totSize; j++) {
                    //Iterate through all the forecast-observation pairs
                    //Only count boundary probs once (i.e. use > and <=)
                    if (fProbs[j] > lower && fProbs[j] <= upper) {
                        rel[0][i-1] += fProbs[j];  //Sum forecast prob: average later
                        rel[1][i-1] += occurred[j];  //Increment observed count: average later to avoid rounding errors
                        countsa[i-1] += 1;
                    }
                }
                if (countsa[i-1] > 0) {
                    rel[0][i-1] = rel[0][i-1] / countsa[i-1];
                    rel[1][i-1] = rel[1][i-1] / countsa[i-1];
                    rel[2][i-1] = countsa[i-1];
                    rel[3][i-1] = clim;
                    rel[4][i-1] = clim+((rel[0][i-1]-clim)/2.0);
                } else {
                    rel[0][i-1] = NULL_DATA;
                    rel[1][i-1] = NULL_DATA;
                    rel[2][i-1] = 0;
                    rel[3][i-1] = NULL_DATA;
                    rel[4][i-1] = NULL_DATA;
                }
            }
            return new DoubleMatrix2DResult(new DenseDoubleMatrix2D(rel));
        }
        //Bins with equal samples in each
        else {
            int sCount = (int)(((double)fProbs.length)/(double)pointsCount);  //Nearest integer equal sample count
            //Sort the forecasts using a sorted map.  Store observations in a vector in
            //case of duplicates
            TreeMap map = new TreeMap();
            for(int i = 0; i < totSize; i++) {
                if(map.containsKey(fProbs[i])) {
                    ((Vector<Double>)map.get(fProbs[i])).add((new Double(occurred[i])));
                }
                else {
                    Vector<Double> ob = new Vector();
                    ob.add(new Double(occurred[i]));
                    map.put(fProbs[i],ob);
                }
            }
            //Iterate through the map and store forecast and obs. prob up to running count, then move on
            int runIndex = 1;
            int[] countsa = new int[totProb];  //Observed counts
            Iterator i = map.keySet().iterator();
            while(i.hasNext()) {
                Double fProb = (Double)i.next();
                Vector<Double> nxtObs = (Vector<Double>)map.get(fProb);
                //Iterate through the observations 
                int obCount = nxtObs.size();
                for(int j = 0; j < obCount; j++) {
                    //Increment at current index
                    if(countsa[runIndex] < sCount || runIndex == countsa.length-1) { //Include last few in last bin
                        rel[0][runIndex] += fProb;  //Sum forecast prob: average later
                        rel[1][runIndex] += nxtObs.get(j);  //Increment observed count: average later to avoid rounding errors
                        countsa[runIndex]++;
                    } //Move on to next index
                    else {
                        runIndex++;
                        rel[0][runIndex] += fProb;  //Sum forecast prob: average later
                        rel[1][runIndex] += nxtObs.get(j);  //Increment observed count: average later to avoid rounding errors
                        countsa[runIndex]++;
                    }
                }
            }
            //Compute final reliability
            for (int j = 1; j < totProb; j++) {
                rel[0][j] = rel[0][j] / countsa[j];  //Average forecast probability
                rel[1][j] = rel[1][j] / countsa[j];  //Observed relative frequency
                rel[2][j] = countsa[j];
                rel[3][j] = clim;
                rel[4][j] = clim+((rel[0][j]-clim)/2.0);
            } 
            DenseDoubleMatrix2D rel2 = (DenseDoubleMatrix2D)new DenseDoubleMatrix2D(rel).getSubmatrixByColumn(1,rel[0].length-1);
            return new DoubleMatrix2DResult(rel2); 
        }
    }        
    
}
