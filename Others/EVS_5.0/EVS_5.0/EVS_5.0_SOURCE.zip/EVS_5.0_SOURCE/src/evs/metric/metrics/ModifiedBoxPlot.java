package evs.metric.metrics;

//EVS dependencies
import evs.data.PairedData;
import evs.metric.parameters.ForecastTypeParameter;
import evs.metric.parameters.ProbabilityArrayParameter;
import evs.metric.results.MetricResult;
import evs.metric.results.IntegerResult;
import evs.utilities.matrix.DoubleMatrix2D;

/**
 * Constructs a modified box-and-whisker plot with a set of thresholds.  The boxes
 * represent the empirical pdf of errors for the forecasts, pooled by lead time. 
 * 
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public abstract class ModifiedBoxPlot extends RawMetric implements EnsembleMetric {
    
    /********************************************************************************
     *                                                                              *
     *                               INSTANCE VARIABLES                             *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Default thresholds for the box plots.
     */
    
    protected static final ProbabilityArrayParameter DEF_BOX_THRESH = new ProbabilityArrayParameter(new double[]{0.0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0}); 
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/                 
    
    /**
     * Returns a default set of thresholds for the box plots.  
     *
     * @return the default thresholds for the box plot
     */
    
    public static ProbabilityArrayParameter getDefaultBoxThresholds() {
        return DEF_BOX_THRESH;
    }

    /********************************************************************************
     *                                                                              *
     *                                MUTATOR METHODS                               *
     *                                                                              *
     *******************************************************************************/           
    
    /**
     * Uses the specified paired data to compute and return the result of the metric.
     * The metric results are returned, together with the sample counts, but not stored 
     * locally.  The metric result is located in the first index of the return array
     * and the sample counts are located in the second index. Optionally, specify
     * the results of a reference forecast from which to compute skill if the 
     * metric is a skill score. 
     * 
     * @param forecastType the forecast type
     * @param paired the paired data
     * @param refResult the results for a reference forecast (may be null)
     * @return the metric result and sample counts
     */
    
    public MetricResult[] compute(int forecastType, PairedData paired, MetricResult refResult) throws MetricCalculationException {
        if(paired==null) {
            throw new MetricCalculationException("Error computing metric '"+getName()+"': input pairs were null.");
        }
        ForecastTypeParameter.isSupportedForecastType(forecastType,true);
        MetricResult[] res = new MetricResult[2];
        DoubleMatrix2D p = paired.getPairs();
        double nV = paired.getNullValue();
        try {
            res[0]=getBox(p,nV);
            res[1]=new IntegerResult(lastCount);
        } catch (Exception e) {
            //e.printStackTrace();
        }
        return res; 
    }     
    
    /********************************************************************************
     *                                                                              *
     *                              PROTECTED METHODS                               *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Returns a box dataset from an input dataset, pooling by lead time.
     *
     * @param data the input data
     * @param nV the null value
     * @return a box dataset
     */
    
    protected abstract MetricResult getBox(DoubleMatrix2D data, double nV);
    
}
