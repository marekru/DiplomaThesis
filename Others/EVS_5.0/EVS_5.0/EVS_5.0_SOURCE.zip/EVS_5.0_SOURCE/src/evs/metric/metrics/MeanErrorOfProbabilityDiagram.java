package evs.metric.metrics;

//EVS dependencies
import evs.data.*;
import evs.analysisunits.*;
import evs.metric.parameters.*;
import evs.metric.results.*;
import evs.utilities.*;
import evs.utilities.matrix.*;
import evs.utilities.mathutil.*;

//Java util dependencies
import java.util.*;

/**
 * The mean error of probability diagram plots the difference between the observed 
 * climatological probability and the average forecast probability for a given real
 * value of the observed variable and plots the residual as a function of the real
 * value, repeated for a set of real values.  The real values are sampled from the
 * observed climatological probability distribution at equal probability intervals,
 * at a resolution dictated by an input parameter (number of intervals).
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class MeanErrorOfProbabilityDiagram extends DiagramMetric implements EnsembleMetric, 
        SingleValuedMetric, ThresholdMetric, BootstrapableMetric {
    
    /********************************************************************************
     *                                                                              *
     *                                  VARIABLES                                   *
     *                                                                              *
     *******************************************************************************/     
 
    /**
     * Default number of points to include in a CE diagram.
     */
    
    private static MEPPointsParameter defPCount = new MEPPointsParameter(50);
    
    /**
     * The function to apply to forecasts with multiple values if required.
     */
    
    private VectorFunction forecastStat = null;
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Attempts to construct a mean error of probability diagram with associated parameters.
     *
     * @param points the number of equally-spaced probability intervals at which the metric should be computed
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use conditional 
     * pairs when available
     * @param minS the minimum sample size
     * @param bs the bootstrap parameter
     */
    
    public MeanErrorOfProbabilityDiagram(MEPPointsParameter points, ForecastTypeParameter fType, 
            UnconditionalParameter unconditional, MinimumSampleSizeParameter minS, BootstrapParameter bs) {
        //Set the name
        name = "Mean error of probability diagram";
        //Set the parameters
        //Specify an all-inclusive threshold condition
        ProbabilityIdentifierParameter p = new ProbabilityIdentifierParameter(false);
        DoubleParameter[] dubs = new DoubleParameter[]{new DoubleParameter(Double.NEGATIVE_INFINITY)};
        IntegerParameter p2 = new IntegerParameter(DoubleProcedureParameter.GREATER_THAN);
        setParameters(new MetricParameter[]{new DoubleProcedureParameter(p2,dubs,p,
                new BooleanParameter(true)),points.deepCopy(),fType.deepCopy(),
                unconditional.deepCopy(),minS.deepCopy(),bs.deepCopy()});
        //Set the link to html description of the metric
        descriptionURL = getClass().getResource(EVSConstants.STATS_EXPLAINED_DIR + "mep.htm");
    }
    
    /**
     * Attempts to construct a mean error of probability diagram with associated parameters.
     *
     * @param points the number of equally-spaced probability intervals at which the metric should be computed
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use conditional pairs when available
     * @param threshold the threshold
     * @param minS the minimum sample size
     * @param bs the bootstrap parameter
     */
    
    public MeanErrorOfProbabilityDiagram(DoubleProcedureParameter threshold, MEPPointsParameter points, 
            ForecastTypeParameter fType, UnconditionalParameter unconditional,
            MinimumSampleSizeParameter minS, BootstrapParameter bs) {
        this(points,fType,unconditional,minS,bs);
        pars[0]=threshold;
    }    
        
     /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/        

    /**
     * Returns the forecast statistic to be applied to paired input that comprise
     * multiple forecasts at a single time (e.g. ensemble forecast input).    
     *
     * @return the forecast statistic
     */
    
    public VectorFunction getForecastStatistic() {
        return forecastStat;
    }    
    
    /**
     * Returns true if a forecast statistic has been set, false otherwise.
     * 
     * @return true if a forecast statistic has been set.
     */
    
    public boolean hasForecastStatistic() {
        return forecastStat != null;
    }        
    
    /**
     * Returns the metric identifier.
     *
     * @return an identifier
     */
    
    public int getID() {
        return MEPD;
    }        
    
    /**
     * Returns true if the metric is defined in real units of the forecast
     * and observed variable, false otherwise.
     * 
     * @return true if the metric is defined in real units
     */    

    public boolean hasRealUnits() {
        return true;
    }       
    
    /**
     * Returns the threshold associated with this threshold diagram.
     *
     * @return the threshold
     */
    
    public DoubleProcedureParameter getThreshold() {
        return (DoubleProcedureParameter)pars[0].deepCopy();
    }  
    
    /**
     * Returns the result type associated with the metric.  See the 
     * evs.metric.MetricResult class for supported types.
     *
     * @return an identifier
     */
    
    public int getResultID() {
        return MetricResult.DOUBLE_MATRIX_2D_RESULT;
    }     
    
    /**
     * Returns a deep copy of the current metric, where all instance variables 
     * occupy independent positions in memory from the current metric.  
     *
     * @return a deep copy of the current object 
     */
    
    public Metric deepCopy() {
        MeanErrorOfProbabilityDiagram returnMe = new MeanErrorOfProbabilityDiagram(
                (DoubleProcedureParameter)pars[0].deepCopy(),
                (MEPPointsParameter)pars[1].deepCopy(),
                (ForecastTypeParameter)pars[2].deepCopy(),
                (UnconditionalParameter)pars[3].deepCopy(),
                (MinimumSampleSizeParameter)pars[4].deepCopy(),
                getBootstrapPar());
        deepCopyResults(returnMe);
        return returnMe;
    }

    /**
     * Returns the bootstrap parameter associated with the verification metric.
     *
     * @return the bootstrap parameter
     */
    @Override
    public BootstrapParameter getBootstrapPar() {
        return (BootstrapParameter)pars[5].deepCopy();
    }

    /**
     * Returns the default point count.  
     *
     * @return the default point count
     */
    
    public static PositiveIntegerParameter getDefaultPointCount() {
        return (PositiveIntegerParameter)defPCount.deepCopy();
    }    
    
    /**
     * Returns a metric with default parameter values.  
     *
     * @return a metric with default parameter values.
     */
    
    public static Metric getDefaultMetric() { 
        ForecastTypeParameter type = new ForecastTypeParameter(new int[]{ForecastTypeParameter.REGULAR_FORECAST});
        return new MeanErrorOfProbabilityDiagram(defPCount,type,new UnconditionalParameter(false),
                new MinimumSampleSizeParameter(),new BootstrapParameter());
    } 
    
     /********************************************************************************
     *                                                                              *
     *                                MUTATOR METHODS                               *
     *                                                                              *
     *******************************************************************************/        

    /**
     * Uses the specified paired data to compute and return the result of the metric.
     * The metric results are returned, together with the sample counts, but not stored 
     * locally.  The metric result is located in the first index of the return array
     * and the sample counts are located in the second index. Optionally, specify
     * the results of a reference forecast from which to compute skill if the 
     * metric is a skill score. 
     * 
     * @param forecastType the forecast type
     * @param paired the paired data
     * @param refResult the results for a reference forecast (may be null)
     * @return the metric result and sample counts
     */
    
    public MetricResult[] compute(int forecastType, PairedData paired, MetricResult refResult) throws MetricCalculationException {
        if(paired==null) {
            throw new MetricCalculationException("Error computing metric '"+getName()+"': input pairs were null.");
        }
        ForecastTypeParameter.isSupportedForecastType(forecastType,true);
        MetricResult[] res = new MetricResult[2];
        DoubleProcedure pro = getThreshold().getParValReal();
        DoubleMatrix2D p = paired.getPairs();
        double nV = paired.getNullValue();
//        try {
            p = getConditionalPairs(pro, p);
            res[0]=getMEP((DoubleMatrix2D)p.getSubmatrixByColumn(2,p.getColumnCount()-1),nV);
            res[1]=new IntegerResult(lastCount);
//        } catch (Exception e) {
//            //e.printStackTrace();
//        }
        return res; 
    }     

    /**
     * Sets the forecast statistic to be applied to paired input that comprise
     * multiple forecasts at a single time (e.g. ensemble forecast input).
     *
     * @param forecastStat the forecast statistic
     */

    public void setForecastStatistic(VectorFunction forecastStat) {
        if(forecastStat == null) {
            throw new IllegalArgumentException("Cannot use a null forecast statistic.");
        }
        this.forecastStat = forecastStat;
    }

    /**
     * Sets the threshold for the current metric.
     *
     * @param threshold the threshold
     */

    public void setThreshold(DoubleProcedureParameter threshold) {
        pars[0] = (DoubleProcedureParameter)threshold.deepCopy();
    }

    /**
     * Sets the bootstrap parameter associated with the verification metric or
     * clears the parameter if the input is null;
     *
     * @param bs the bootstrap parameter
     */
    @Override
    public void setBootstrapPar(BootstrapParameter bs) {
        if(bs==null) {
            throw new IllegalArgumentException("The bootstrap parameter for metric '"+this+"' cannot be null.");
        } else {
            pars[5] = (BootstrapParameter)bs.deepCopy();
        }
    }

    /**
     * Sets the bootstrap parameter to BootstrapableMetric.NO_BOOTSTRAP and clears
     * all associated parameter values.
     */
    @Override
    public void clearBootstrapPar() {
        ((BootstrapParameter)pars[5]).clear();
    }

    /**
     * Returns a mean error of probability dataset from an input dataset.  The input
     * should comprise one column of observations (at index 0) and the remaining n
     * columns should comprise the n forecasts (index 1 through n).
     *
     * @param data the input data
     * @param nV the null value
     * @return a mean error of probability dataset
     */

    public MetricResult getMEP(DoubleMatrix2D data, double nV) {
        
        int minCount = ((MinimumSampleSizeParameter)pars[4]).getParVal();
        int actualRows = data.getRowCount();
        lastCount = actualRows;
        if(actualRows < minCount) {
            throw new MetricCalculationException("Could not compute the mean error of probability diagram: fewer samples than required ["+actualRows+","+minCount+"].");
        }          
        
        int count = ((MEPPointsParameter)pars[1]).getParVal();

        //Weibull position for windows
        double inc = 1.0/(count+1);
        double[] pThresh = new double[count];
        for(int i = 0; i < count; i++) {
            pThresh[i] = (i+1)*inc;
        }

        //Obtain the observations and forecasts
        int cols = data.getColumnCount();
        double[] obs = ((DoubleMatrix1D)data.getColumnAt(0)).toArray();
        double[] forecasts = (double[])((DoubleMatrix2D)data.getSubmatrixByColumn(1,cols-1)).to1D().getMatrixValues();

        //Get the forecast climatological cdf at the specified quantiles using the Weibull formula
        double[][] forc = EmpiricalCDFCalculator.getEmpiricalCDF(forecasts,pThresh,nV,true,false,true);

        //Get the observed climatological cdf at the equivalent values using the Weibull formula
        double[][] clim = EmpiricalCDFCalculator.getEmpiricalCDF(obs,forc[1],nV,false,false,true);

        //Return the result
        double[][] result = new double[2][pThresh.length];
        result[0]=forc[0];
        result[1]=clim[0];

        int nullCount = 0;

        //Remove any duplicate points (e.g. associated with a discontinuity)
        int stop = result[0].length -1;
        Vector<double[]> pairs = new Vector();
        //Add the first point if it meets the criterion
        if((result[0][0]!=result[0][1]) && (result[1][0]!=result[1][1])) {
            pairs.add(new double[]{result[0][0],result[1][0]});
        } else {
            pairs.add(new double[]{Metric.NULL_DATA,Metric.NULL_DATA});
            nullCount++;
        }
        for(int i = 1; i < stop; i++) {
            //Skip a mid-point that is equal to the end points
            if(result[0][i-1]==result[0][i]) {
                if(result[0][i]==result[0][i+1]) {
                    pairs.add(new double[]{Metric.NULL_DATA,Metric.NULL_DATA});
                    nullCount++;
                    continue;
                }
            }
            //Skip a mid-point that is equal to the end points
            if(result[1][i-1]==result[1][i]) {
                if(result[1][i]==result[1][i+1]) {
                    pairs.add(new double[]{Metric.NULL_DATA,Metric.NULL_DATA});
                    nullCount++;
                    continue;
                }
            }
            pairs.add(new double[]{result[0][i],result[1][i]});
        }
        if(pairs.size()==0 || nullCount == pairs.size()) {
            throw new MetricCalculationException("Could not compute the MEP diagram from the input: "
                    + "no non-duplicate pairs were found.");
        }
        int s = result[1].length-1;
        //Add the last point if it meets the criterion
        if((result[0][s]!=result[0][s-1]) && (result[1][s]!=result[1][s-1])) {
            pairs.add(new double[]{result[0][s],result[1][s]});
        } else {
            pairs.add(new double[]{Metric.NULL_DATA,Metric.NULL_DATA});
        }
        double[][] returnMe = new double[2][pairs.size()];
        for(int i = 0; i < returnMe[0].length; i++) {
            returnMe[0][i]=pairs.get(i)[0];
            returnMe[1][i]=pairs.get(i)[1];
        }
        return new DoubleMatrix2DResult(new DenseDoubleMatrix2D(returnMe));
    }

}
