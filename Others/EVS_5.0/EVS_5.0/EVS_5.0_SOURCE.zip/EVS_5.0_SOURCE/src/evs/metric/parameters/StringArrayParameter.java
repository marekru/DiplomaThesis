package evs.metric.parameters;

//Java util dependencies
import java.util.Arrays;

/**
 * A metric parameter that comprises a set of string values stored in a string
 * array.  Some or all of the strings may be null.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class StringArrayParameter implements MetricParameter {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLE                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * The strings.
     */
    
    protected String[] strings;
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs the parameter with a string array.
     *
     * @param strings the strings
     */
    
    public StringArrayParameter(String[] strings) {
        if(strings == null || strings.length==0) {
            throw new IllegalArgumentException("Specify valid strings.");
        }
        this.strings = new String[strings.length];
        System.arraycopy(strings,0,this.strings,0,strings.length);
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     *
     * @return an identifier
     */
    
    public int getID() {
        return STRING_ARRAY_PARAMETER;
    }    
    
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "string_array_parameter";
    }       
    
    /**
     * Returns the length of the array.
     *
     * @return the length
     */
    
    public int getLength() {
        return strings.length;
    }

    /**
     * Returns true if some of the strings are non-null, otherwise false.
     *
     * @return true if some of the strings are non-null, otherwise false.
     */

    public boolean hasNonNullStrings() {
        for(String s : strings) {
            if(s!=null) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns a deep copy of the strings
     *
     * @return the strings
     */
    
    public String[] getThresholdValuesAsStringArray() {
        return Arrays.copyOf(strings,strings.length);
    }

    /**
     * Returns the parameter value.
     *
     * @return the parameter value
     */

    public String[] getParVal() {
        return getThresholdValuesAsStringArray();
    }

    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricParameter deepCopy() {
        return new StringArrayParameter(Arrays.copyOf(strings,strings.length));
    }        
    
    /**
     * Override equals.  
     *
     * @param o the object to test against the current object
     * @return true if the objects are equal
     */
    
    public boolean equals(Object o) {
        return o instanceof StringArrayParameter && 
                Arrays.equals(((StringArrayParameter)o).strings,strings);
    }     
    
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        assert false : "hashCode not implemented for MetricParameter.";
        return 1;
    }    
    
    /**
     * Returns a string representation of the thresholds separated by commas.
     *
     * @return a string representation
     */
    
    public String toString() {
        StringBuffer returnMe = new StringBuffer();
        for(int i = 0; i < strings.length; i++) {
            returnMe.append(strings[i]);
            if(i < (strings.length-1)) {
                returnMe.append(",");
            }
        }
        return returnMe.toString();
    }
       
    
}
