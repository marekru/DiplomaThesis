package evs.metric.parameters;

/**
 * A metric parameter that comprises a set of double probabilities stored in a double
 * array.  Duplication of probabilities is not allowed, and the probabilities
 * must lie between 0 and 1.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ProbabilityArrayParameter extends DoubleArrayParameter {
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs a probability array with an array of doubles
     *
     * @param probabilities the probabilities 
     */
    
    public ProbabilityArrayParameter(double[] probabilities) {
        //Check for duplication
        super(probabilities);
        //Check for proper probabilities
        for(int i = 0; i < probabilities.length; i++) {
            //Allow infinity as a valid probability, as this is used to indicate all data
            if(!Double.isInfinite(probabilities[i]) && (probabilities[i] < 0.0 || probabilities[i] > 1.0)) {
                throw new IllegalArgumentException("Invalid probability thresholds specified.");
            }
        }
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     *
     * @return an identifier
     */
    
    public int getID() {
        return PROBABILITY_ARRAY_PARAMETER;
    }      
    
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "probability_array_parameter";
    }   
    
    /**
     * Returns a deep copy of the probabilities
     *
     * @return the probabilities
     */
    
    public double[] getProbabilities() {
        return getThresholdValuesAsDoubleArray();
    }
    
    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
    
    public MetricParameter deepCopy() {
        double[] copy = new double[thresholds.length];
        System.arraycopy(thresholds,0,copy,0,copy.length);
        return new ProbabilityArrayParameter(copy);
    }             
    
}
