package evs.metric.parameters;

//Java util dependencies
import java.util.Arrays;

/**
 * A metric parameter that comprises a set of double thresholds stored in a double
 * array.  Duplication of threshold values is not allowed.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DoubleArrayParameter implements MetricParameter {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLE                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * The thresholds.
     */
    
    protected double[] thresholds; 
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs the parameter with a double array.
     *
     * @param thresholds the thresholds
     */
    
    public DoubleArrayParameter(double[] thresholds) {
        if(thresholds == null || thresholds.length==0) {
            throw new IllegalArgumentException("Specify valid thresholds.");
        }
        //Arrays.sort(thresholds);
        for(int i = 1; i < thresholds.length; i++) {
            if(thresholds[i]==thresholds[i-1]) {
                throw new IllegalArgumentException("One or more thresholds are not unique.");
            }
        }
        this.thresholds = new double[thresholds.length];
        System.arraycopy(thresholds,0,this.thresholds,0,thresholds.length);
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     *
     * @return an identifier
     */
    
    public int getID() {
        return DOUBLE_ARRAY_PARAMETER;
    }    
    
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "double_array_parameter";
    }       
    
    /**
     * Returns the length of the array.
     *
     * @return the length
     */
    
    public int getLength() {
        return thresholds.length;
    }
    
    /**
     * Returns a deep copy of the thresholds
     *
     * @return the thresholds
     */
    
    public double[] getThresholdValuesAsDoubleArray() {
        return Arrays.copyOf(thresholds,thresholds.length);
    }

    /**
     * Returns the parameter value.
     *
     * @return the parameter value
     */

    public double[] getParVal() {
        return getThresholdValuesAsDoubleArray();
    }

    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricParameter deepCopy() {
        return new DoubleArrayParameter(Arrays.copyOf(thresholds,thresholds.length));
    }        
    
    /**
     * Override equals.  
     *
     * @param o the object to test against the current object
     * @return true if the objects are equal
     */
    
    public boolean equals(Object o) {
        return o instanceof DoubleArrayParameter && Arrays.equals(((DoubleArrayParameter)o).thresholds,thresholds);
    }     
    
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        assert false : "hashCode not implemented for MetricParameter.";
        return 1;
    }    
    
    /**
     * Returns a string representation of the thresholds separated by commas.
     *
     * @return a string representation
     */
    
    public String toString() {
        StringBuffer returnMe = new StringBuffer();
        for(int i = 0; i < thresholds.length; i++) {
            returnMe.append(thresholds[i]);
            if(i < (thresholds.length-1)) {
                returnMe.append(",");
            }
        }
        return returnMe.toString();
    }
       
    
}
