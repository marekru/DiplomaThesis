package evs.metric.parameters;

/**
 * Indicates whether unconditional pairs should be used in preference when conditional
 * pairs are available for metric calculation.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class UnconditionalParameter extends BooleanParameter {
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs an object with a boolean parameter value
     *
     * @param isTrue the boolean parameter value
     */
    
    public UnconditionalParameter(boolean isTrue) {
        super(isTrue);
    }
    
    /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     *
     * @return an identifier
     */
    
    public int getID() {
        return UNCONDITIONAL_PARAMETER;
    }

    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "unconditional_parameter";
    }    
    
    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricParameter deepCopy() {
        return new UnconditionalParameter(isTrue); 
    }      
    
    /**
     * Override equals.  
     *
     * @param o the object to test against the current object
     * @return true if the objects are equal
     */
    
    public boolean equals(Object o) {
        return super.equals(o) && ((BooleanParameter)o).getID()==UNCONDITIONAL_PARAMETER;
    } 
    
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        assert false : "hashCode not implemented for MetricParameter.";
        return 1;
    }    
        
}
