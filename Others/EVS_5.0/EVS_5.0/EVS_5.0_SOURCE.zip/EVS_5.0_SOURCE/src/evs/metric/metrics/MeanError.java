package evs.metric.metrics;

//EVS dependencies
import evs.data.*;
import evs.analysisunits.*;
import evs.metric.parameters.*;
import evs.metric.results.*;
import evs.utilities.*;
import evs.utilities.matrix.*;
import evs.utilities.mathutil.*;

//Java util dependencies
import java.util.*;

/**
 * Computes the mean difference between the forecasts and observations, which is
 * indicative of first-order bias in the forecasts.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class MeanError extends Metric implements SingleValuedMetric, ThresholdMetric, BootstrapableMetric {

    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/      

    /**
     * Attempts to construct a mean error object with associated parameters.
     *
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use
     * conditional pairs when available
     * @param forecastStat a function used to derive a single-valued forecast from the ensemble
     * @param minS the minimum sample size
     * @param bs the bootstrap parameter
     */

    public MeanError(ForecastTypeParameter fType,UnconditionalParameter unconditional, 
            VectorFunctionParameter forecastStat,MinimumSampleSizeParameter minS,BootstrapParameter bs) {
        //Set the name
        name = "Mean error";
        //Set the parameters
        //Specify an all-inclusive threshold condition
        ProbabilityIdentifierParameter p = new ProbabilityIdentifierParameter(false);
        DoubleParameter[] dubs = new DoubleParameter[]{new DoubleParameter(Double.NEGATIVE_INFINITY)};
        IntegerParameter p2 = new IntegerParameter(DoubleProcedureParameter.GREATER_THAN);
        setParameters(new MetricParameter[]{new DoubleProcedureParameter(p2,dubs,p,
                new BooleanParameter(true)),fType.deepCopy(),unconditional.deepCopy(),
                forecastStat.deepCopy(),minS.deepCopy(),bs.deepCopy()});
        //Set the link to html description of the metric
        descriptionURL = getClass().getResource(EVSConstants.STATS_EXPLAINED_DIR + "me.htm");
    }

    /**
     * Attempts to construct a mean error object with associated parameters.
     *
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use 
     * conditional pairs when available
     * @param threshold the threshold
     * @param forecastStat a function used to derive a single-valued forecast from the ensemble
     * @param minS the minimum sample size
     * @param bs the bootstrap parameter
     */
    
    public MeanError(DoubleProcedureParameter threshold,ForecastTypeParameter fType,
            UnconditionalParameter unconditional, VectorFunctionParameter forecastStat,
            MinimumSampleSizeParameter minS, BootstrapParameter bs) {
        this(fType,unconditional,forecastStat,minS,bs);
        pars[0]=threshold.deepCopy();
    }
        
    /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/        

    /**
     * Returns the forecast statistic to be applied to paired input that comprise
     * multiple forecasts at a single time (e.g. ensemble forecast input).    
     *
     * @return the forecast statistic
     */
    
    public VectorFunction getForecastStatistic() {
        return ((VectorFunctionParameter)pars[3]).getParVal();
    }

    /**
     * Returns the metric identifier.
     *
     * @return an identifier
     */
    
    public int getID() {
        return MEAN_ERROR;
    }        
    
    /**
     * Returns the result type associated with the metric.  See the 
     * evs.metric.MetricResult class for supported types.
     *
     * @return an identifier
     */
    
    public int getResultID() {
        return MetricResult.DOUBLE_RESULT;
    }         
    
    /**
     * Returns true if the metric is defined in real units of the forecast
     * and observed variable, false otherwise.
     * 
     * @return true if the metric is defined in real units
     */    

    public boolean hasRealUnits() {
        return true;
    }       
    
    /**
     * Returns the threshold associated with this threshold diagram.
     *
     * @return the threshold
     */
    
    public DoubleProcedureParameter getThreshold() {
        return (DoubleProcedureParameter)pars[0].deepCopy();
    }  
    
    /**
     * Returns a deep copy of the current metric, where all instance variables 
     * occupy independent positions in memory from the current metric.  
     *
     * @return a deep copy of the current object 
     */
    
    public Metric deepCopy() {
        MeanError returnMe = new MeanError((DoubleProcedureParameter)pars[0].deepCopy(),
                (ForecastTypeParameter)pars[1].deepCopy(),
                (UnconditionalParameter)pars[2].deepCopy(),
                (VectorFunctionParameter)pars[3].deepCopy(),
                (MinimumSampleSizeParameter)pars[4].deepCopy(),
                getBootstrapPar());
        deepCopyResults(returnMe);
        return returnMe;
    }

    /**
     * Returns the bootstrap parameter associated with the verification metric.
     *
     * @return the bootstrap parameter
     */
    @Override
    public BootstrapParameter getBootstrapPar() {
        return (BootstrapParameter)pars[5].deepCopy();
    }
    
    /**
     * Returns a metric with default parameter values.  
     *
     * @return a metric with default parameter values.
     */
    
    public static Metric getDefaultMetric() { 
        ForecastTypeParameter type = new ForecastTypeParameter(new int[]{ForecastTypeParameter.REGULAR_FORECAST});
        return new MeanError(type,new UnconditionalParameter(false),
                new VectorFunctionParameter(FunctionLibrary.mean()),
                new MinimumSampleSizeParameter(),new BootstrapParameter());
    }     
    
    /********************************************************************************
     *                                                                              *
     *                                MUTATOR METHODS                               *
     *                                                                              *
     *******************************************************************************/     
  
    /**
     * Uses the specified paired data to compute and return the result of the metric.
     * The metric results are returned, together with the sample counts, but not stored 
     * locally.  The metric result is located in the first index of the return array
     * and the sample counts are located in the second index. Optionally, specify
     * the results of a reference forecast from which to compute skill if the 
     * metric is a skill score. 
     * 
     * @param forecastType the forecast type
     * @param paired the paired data
     * @param refResult the results for a reference forecast (may be null)
     * @return the metric result and sample counts
     */
    
    public MetricResult[] compute(int forecastType, PairedData paired, MetricResult refResult) throws MetricCalculationException {
        if(paired==null) {
            throw new MetricCalculationException("Error computing metric '"+getName()+"': input pairs were null.");
        }
        ForecastTypeParameter.isSupportedForecastType(forecastType,true);
        DoubleMatrix2D pairs = paired.getPairs();
        if(pairs.getColumnCount()!=4) {
            throw new MetricCalculationException("Expected single-valued input (4 columns) "
                    + "for '"+this+"': "+pairs.getColumnCount()+" found.");
        }
        double nV = paired.getNullValue();
        MetricResult[] res = new MetricResult[2];
        DoubleProcedure pro = getThreshold().getParValReal();
        pairs = getConditionalPairs(pro,pairs);
        res[0]=getME((DoubleMatrix2D)pairs.getSubmatrixByColumn(2, 3),nV);
        res[1]=new IntegerResult(lastCount);
        return res; 
    }       

    /**
     * Sets the forecast statistic to be applied to paired input that comprise
     * multiple forecasts at a single time (e.g. ensemble forecast input).
     *
     * @param forecastStat the forecast statistic
     */

    public void setForecastStatistic(VectorFunction forecastStat) {
        if(forecastStat == null) {
            throw new IllegalArgumentException("Cannot use a null forecast statistic.");
        }
        pars[3] = new VectorFunctionParameter(forecastStat);
    }

    /**
     * Sets the bootstrap parameter associated with the verification metric or
     * clears the parameter if the input is null;
     *
     * @param bs the bootstrap parameter
     */
    @Override
    public void setBootstrapPar(BootstrapParameter bs) {
        if(bs==null) {
            throw new IllegalArgumentException("The bootstrap parameter for metric '"+this+"' cannot be null.");
        } else {
            pars[5] = (BootstrapParameter)bs.deepCopy();
        }
    }

    /**
     * Sets the bootstrap parameter to BootstrapableMetric.NO_BOOTSTRAP and clears
     * all associated parameter values.
     */
    @Override
    public void clearBootstrapPar() {
        ((BootstrapParameter)pars[5]).clear();
    }

    /**
     * Sets the threshold for the current metric.
     *
     * @param threshold the threshold
     */

    public void setThreshold(DoubleProcedureParameter threshold) {
        pars[0] = (DoubleProcedureParameter)threshold.deepCopy();
    }

    /**
     * Returns the mean error from the input data.  The input should comprise one 
     * column of observations (at index 0) and one column of forecasts.
     * 
     * @param data the input data
     * @param nV the null value
     * @return the mean error
     */
    
    public MetricResult getME(DoubleMatrix2D data, double nV) {    
        int rows = data.getRowCount();
        //Compute the total error
        double totEr = 0.0;
        double actualRows = 0.0;
        for(int i = 0; i < rows; i++) {
            double o = data.get(i,0);
            double f = data.get(i,1);
            if(f != nV && o != nV) {
                totEr += f-o;
                actualRows++;
            }
        }
        int minCount = ((MinimumSampleSizeParameter)pars[4]).getParVal();
        lastCount = (int)actualRows;
        if(actualRows < minCount) {
            throw new MetricCalculationException("Could not compute the mean error: fewer samples than required ["+actualRows+","+minCount+"].");
        }
        //Compute the average error and store
        return new DoubleResult(totEr/actualRows);   
    }
    
    /*******************************************************************************
     *                                                                             *
     *                                  TEST METHOD                                *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Test method.
     *
     * @param args the args
     */
    
    public static void main(String[] args) {    
        double[][] data = new double[100000][2];
        for(int i = 0; i < data.length; i++) {
            data[i][0] = 0.5;
            data[i][1] = Math.random();            
        }
        //DenseDoubleMatrix2D data2 = new DenseDoubleMatrix2D(data);
        //MetricResult me = getME(data2); 
        //System.out.println("Expected mean: "+0.0);
        //System.out.println("Mean based on "+data.length+" uniform random numbers: "+me);
    }
    
}
    