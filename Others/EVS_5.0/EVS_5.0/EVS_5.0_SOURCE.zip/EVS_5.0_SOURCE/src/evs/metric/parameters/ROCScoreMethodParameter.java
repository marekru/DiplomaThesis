package evs.metric.parameters;

/**
 * Records the method used to compute the empirical ROC score.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public final class ROCScoreMethodParameter extends IntegerParameter {

    /********************************************************************************
     *                                                                              *
     *                                CLASS VARIABLES                               *
     *                                                                              *
     *******************************************************************************/

    /**
     * Identifier for using the trapezoid rule when computing the AUC.
     */

    public static final int TRAPEZOID = 101;

    /**
     * Identifier for using the Mason and Graham (2002) algorithm for the AUC.
     */

    public static final int MASON_GRAHAM = 102;


    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     

    /**
     * Default constructor uses the trapezoid rule to integrate the empirical ROC
     * curve.
     */

    public ROCScoreMethodParameter() {
        super(MASON_GRAHAM);
    }

    /**
     * Constructs an object with an integer parameter value
     *
     * @param par the parameter value  
     */ 
    
    public ROCScoreMethodParameter(int par) {  
        super(par);
        if(par!=TRAPEZOID && par!=MASON_GRAHAM) {
            throw new IllegalArgumentException("Unexpected method identifier for "
                    + "computing the ROC Score.");
        }
    }
    
    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricParameter deepCopy() {
        return new ROCScoreMethodParameter(par);
    }     
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
        
    /**
     * Return an identifier for the parameter from the list in 
     * {@link evs.metric.parameters.MetricParameter}
     *
     * @return an identifier
     */
    
    public int getID() {
        return ROC_SCORE_METHOD_PARAMETER;
    }     
    
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "roc_score_method_parameter";
    }

    /**
     * Returns a string representation of the method.
     *
     * @return a string representation
     */

    public String toString() {
        String returnMe = "";
        switch(par) {
            case TRAPEZOID: returnMe = "trapezoid"; break;
            case MASON_GRAHAM: returnMe = "mason_graham"; break;
        }
        return returnMe;
    }

}
