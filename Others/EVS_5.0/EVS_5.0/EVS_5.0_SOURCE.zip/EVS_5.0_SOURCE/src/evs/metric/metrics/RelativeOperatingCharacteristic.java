package evs.metric.metrics;

//EVS dependencies
import evs.data.*;
import evs.metric.parameters.*;
import evs.metric.results.*;
import evs.utilities.*;
import evs.utilities.matrix.*;
import evs.utilities.mathutil.*;

//Java util dependencies
import java.util.*;

/**
 * The Relative Operating Characteristic (also known as the Receiver Operating
 * Characteristic) plots the probability of successful detection for an event
 * against the probability of failed detection.
 *
 * @author evs@hydrosolved.com
 */

public class RelativeOperatingCharacteristic extends DiagramMetric implements ThresholdMetric,
        EnsembleMetric, SingleValuedMetric, CategoricalMetric, BootstrapableMetric {
    
    /********************************************************************************
     *                                                                              *
     *                                  VARIABLES                                   *
     *                                                                              *
     *******************************************************************************/

    /**
     * Default number of points to include in a ROC diagram.
     */
    
    private static PositiveIntegerParameter defPCount = new ROCPointsParameter(10);
    
    /**
     * The function to apply to forecasts with multiple values if required.
     */
    
    private VectorFunction forecastStat = null;            
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Attempts to construct a ROC diagram with a threshold to which a logical
     * condition is applied (i.e. an event).  In addition, specify the number of points 
     * to include in the diagram and the forecast types for which the diagram is
     * required.  See this class for the supported logical types.
     *
     * @param event the event 
     * @param pointCount the number of points to include in the diagram
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use 
     * conditional pairs when available
     * @param fitted is true to fit a smooth curve to the empirical ROC results
     * @param minS the minimum sample size
     * @param bs the bootstrap parameter
     */
    
    public RelativeOperatingCharacteristic(DoubleProcedureParameter event, ROCPointsParameter pointCount,
            ForecastTypeParameter fType,UnconditionalParameter unconditional,
            FittedROCParameter fitted,MinimumSampleSizeParameter minS,BootstrapParameter bs) {
        //Set the name
        name = "Relative operating characteristic";
        //Set the parameters
        setParameters(new MetricParameter[]{event.deepCopy(),pointCount.deepCopy(),
            fType.deepCopy(),unconditional.deepCopy(),fitted.deepCopy(),minS.deepCopy(),bs.deepCopy()});
        //Set the link to html description of the metric
        descriptionURL = getClass().getResource(EVSConstants.STATS_EXPLAINED_DIR + "roc.htm");
    }    
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Returns the forecast statistic to be applied to paired input that comprise
     * multiple forecasts at a single time (e.g. ensemble forecast input).    
     *
     * @return the forecast statistic
     */
    
    public VectorFunction getForecastStatistic() {
        return forecastStat;
    }       
    
    /**
     * Returns true if a forecast statistic has been set, false otherwise.
     * 
     * @return true if a forecast statistic has been set.
     */
    
    public boolean hasForecastStatistic() {
        return forecastStat != null;
    }        
    
    /**
     * Returns the metric identifier.
     *
     * @return an identifier
     */
    
    public int getID() {
        return ROC;
    }          
    
    /**
     * Returns the result type associated with the metric.  See the 
     * evs.metric.MetricResult class for supported types.
     *
     * @return an identifier
     */
    
    public int getResultID() {
        return MetricResult.DOUBLE_MATRIX_2D_RESULT;
    }         
    
    /**
     * Returns true if the metric is defined in real units of the forecast
     * and observed variable, false otherwise.
     * 
     * @return true if the metric is defined in real units
     */    

    public boolean hasRealUnits() {
        return false;
    }       
    
    /**
     * Returns the default point count.  
     *
     * @return the default point count
     */
    
    public static PositiveIntegerParameter getDefaultPointCount() {
        return (PositiveIntegerParameter)defPCount.deepCopy();
    }

    /**
     * Returns the threshold associated with this threshold diagram.
     *
     * @return the threshold
     */
    
    public DoubleProcedureParameter getThreshold() {
        return (DoubleProcedureParameter)pars[0].deepCopy();
    }

    /**
     * Returns true if the empirical ROC will be fitted with a smooth bivariate
     * model, false otherwise.
     *
     * @return true if the empirical ROC will be fitted
     */

    public boolean getFitted() {
        return ((FittedROCParameter)pars[4]).getParVal();
    }

    /**
     * Returns a deep copy of the current metric, where all instance variables 
     * occupy independent positions in memory from the current metric.  
     *
     * @return a deep copy of the current object 
     */
    
    public Metric deepCopy() {
        RelativeOperatingCharacteristic returnMe = new RelativeOperatingCharacteristic((DoubleProcedureParameter)pars[0].deepCopy(),
                (ROCPointsParameter)pars[1].deepCopy(),(ForecastTypeParameter)pars[2].deepCopy(),
                (UnconditionalParameter)pars[3].deepCopy(),(FittedROCParameter)pars[4].deepCopy(),
                (MinimumSampleSizeParameter)pars[5].deepCopy(),
                getBootstrapPar());
        deepCopyResults(returnMe);
        return returnMe;
    }   

    /**
     * Returns the bootstrap parameter associated with the verification metric.
     *
     * @return the bootstrap parameter
     */
    @Override
    public BootstrapParameter getBootstrapPar() {
        return (BootstrapParameter)pars[6].deepCopy();
    }

    /**
     * Returns a metric with default parameter values.  
     *
     * @return a metric with default parameter values.
     */
    
    public static Metric getDefaultMetric() { 
        ProbabilityIdentifierParameter prob =new ProbabilityIdentifierParameter(true);
        DoubleProcedureParameter eT = new DoubleProcedureParameter(new IntegerParameter(DoubleProcedureParameter.GREATER_THAN),
                new DoubleParameter[]{new ProbabilityParameter(1.0)},prob,new BooleanParameter(true));
        ForecastTypeParameter type = new ForecastTypeParameter(new int[]{ForecastTypeParameter.REGULAR_FORECAST});
        return new RelativeOperatingCharacteristic(eT,(ROCPointsParameter)defPCount,type,
                new UnconditionalParameter(false), new FittedROCParameter(false),
                new MinimumSampleSizeParameter(),new BootstrapParameter());
    }     
    
     /*******************************************************************************
     *                                                                              *
     *                                MUTATOR METHODS                               *
     *                                                                              * 
     *******************************************************************************/              
    
    /**
     * Uses the specified paired data to compute and return the result of the metric.
     * The metric results are returned, together with the sample counts, but not stored 
     * locally.  The metric result is located in the first index of the return array
     * and the sample counts are located in the second index. Optionally, specify
     * the results of a reference forecast from which to compute skill if the 
     * metric is a skill score. 
     * 
     * @param forecastType the forecast type
     * @param paired the paired data
     * @param refResult the results for a reference forecast (may be null)
     * @return the metric result and sample counts
     */
    
    public MetricResult[] compute(int forecastType, PairedData paired, MetricResult refResult) throws MetricCalculationException {
        if(paired==null) {
            throw new MetricCalculationException("Error computing metric '"+getName()+"': input pairs were null.");
        }
        ForecastTypeParameter.isSupportedForecastType(forecastType,true);
        MetricResult[] res = new MetricResult[2];
        DoubleProcedure pro = getThreshold().getParValReal();
        DoubleMatrix2D p = paired.getPairs();
        double nV = paired.getNullValue();
//        try {
            res[0]=getROC((DoubleMatrix2D)p.getSubmatrixByColumn(2,p.getColumnCount()-1),pro,nV);
            res[1]=new IntegerResult(lastCount);
//        } catch (Exception e) {
//            //e.printStackTrace();
//        }
        return res; 
    }     
  
    /**
     * Sets the forecast statistic to be applied to paired input that comprise
     * multiple forecasts at a single time (e.g. ensemble forecast input).
     *
     * @param forecastStat the forecast statistic
     */

    public void setForecastStatistic(VectorFunction forecastStat) {
        if(forecastStat == null) {
            throw new IllegalArgumentException("Cannot use a null forecast statistic.");
        }
        this.forecastStat = forecastStat;
    }

    /**
     * Sets the threshold for the current metric.
     *
     * @param threshold the threshold
     */

    public void setThreshold(DoubleProcedureParameter threshold) {
        pars[0] = (DoubleProcedureParameter)threshold.deepCopy();
    }

    /**
     * Sets the bootstrap parameter associated with the verification metric or
     * clears the parameter if the input is null;
     *
     * @param bs the bootstrap parameter
     */
    @Override
    public void setBootstrapPar(BootstrapParameter bs) {
        if(bs==null) {
            throw new IllegalArgumentException("The bootstrap parameter for metric '"+this+"' cannot be null.");
        } else {
            pars[6] = (BootstrapParameter)bs.deepCopy();
        }
    }

    /**
     * Sets the bootstrap parameter to BootstrapableMetric.NO_BOOTSTRAP and clears
     * all associated parameter values.
     */
    @Override
    public void clearBootstrapPar() {
        ((BootstrapParameter)pars[6]).clear();
    }

    /**
     * Returns the ROC from the input data.  The input should comprise one
     * column of observations (at index 0) and the remaining n columns should comprise
     * the n ensemble members (index 1 through n).
     *
     * @param data the input data
     * @param pro the threshold with values in real units
     * @param nV the null value
     * @return the ROC
     */

    public MetricResult getROC(DoubleMatrix2D data, DoubleProcedure pro, double nV) throws MetricCalculationException {
        //Determine the threshold value for the given probability threshold
        double[] obs = ((DoubleMatrix1D) data.getColumnAt(0)).toArray();
        double[][] forecasts = ((DoubleMatrix2D) data.getSubmatrixByColumn(1, data.getColumnCount() - 1)).toArray();

        int length = obs.length;

        //Forecast probabilities when event did occur
        Vector<Double> probWhenObsYes = new Vector();
        //Forecast probabilities when event did not occur
        Vector<Double> probWhenObsNo = new Vector();

        //Compute binormal ROC?
        boolean binormal = getFitted();

        int obsTotal = 0;
        int obsNotTotal = 0;
        for (int i = 0; i < length; i++) {
            if (obs[i] != nV) {
                //Event occurred according to observation
                if (pro.apply(obs[i])) {
                    //Count the number of forecast members that meet the criterion
                    double num = 0.0;
                    double den = 0.0;
                    for (int j = 0; j < forecasts[i].length; j++) {
                        if (forecasts[i][j] != nV) {
                            if (pro.apply(forecasts[i][j])) {
                                num++;
                            }
                            den++;
                        }
                    }
                    if (den != 0) {
                        //Store the probability
                        double p = num / den;
                        probWhenObsYes.add(p);
                        obsTotal++;
                    }
                } //Event did not occur according to observation
                else {
                    //Count the number of forecast members that meet the criterion
                    double num = 0.0;
                    double den = 0.0;
                    for (int j = 0; j < forecasts[i].length; j++) {
                        if (forecasts[i][j] != nV) {
                            if (pro.apply(forecasts[i][j])) {
                                num++;
                            }
                            den++;
                        }
                    }
                    if (den != 0) {
                        //Store the probability
                        double q = num / den;
                        probWhenObsNo.add(q);
                        obsNotTotal++;
                    }
                }
            }
        }

        int minCount = ((MinimumSampleSizeParameter)pars[5]).getParVal();
        int testRows = Math.min(obsTotal,obsNotTotal);
        String occStatus = "occurrences";
        if(obsNotTotal<obsTotal) {
            occStatus = "non-occurrences";
        }
        lastCount = obsNotTotal+obsTotal;
        if(testRows < minCount) {
            throw new MetricCalculationException("Could not compute the ROC: fewer "+occStatus+" than required ["+testRows+","+minCount+"].");
        }  

        //Determine the number of points to include in the diagram
        int count = ((ROCPointsParameter) pars[1]).getParVal();

        //Sort the forecast probabilities from largest to smallest
        //to speed up search of cases where forecast prob. exceeds a ROC threshold, i.e.
        //where forecast says event occurred.
        Collections.sort(probWhenObsYes);
        Collections.sort(probWhenObsNo);
        Collections.reverse(probWhenObsYes);
        Collections.reverse(probWhenObsNo);

        double[][] dat = ROCUtilities.getEmpiricalROC(probWhenObsYes, probWhenObsNo, count);

        //Store result
        double[][] result = null;
        int binorm_count = 201; //Number of thresholds for output of bi-normal ROC
        if (binormal) {
            result = new double[4][];
            result[2]=new double[binorm_count];
            result[3]=new double[binorm_count];
        } else {
            result = new double[2][];
        }
        result[0] = new double[dat[0].length + 2];
        result[1] = new double[dat[0].length + 2];

        //Force probs at origin and 1.0
        System.arraycopy(dat[0], 0, result[0], 1, dat[0].length);
        System.arraycopy(dat[1], 0, result[1], 1, dat[1].length);
        result[0][result[0].length - 1] = 1.0;
        result[1][result[1].length - 1] = 1.0;

        //Compute bi-normal ROC
        //N^-1(POD)=a+bN^-1(POFD) under the bi-normal model, with a and b to estimate
        //The approach used here is the simplest possible: least squares regression
        //using the pairs of points in the empirical ROC curve
        //There are better approaches, particularly for small sample sizes.
        //TODO: explore maximum likelihood estimation of the "proper" binormal ROC.
        //The AUC can be computed in the same way for n+1 probability thresholds
        //where n is the number of ensemble members.
        //It should be noted that this approach would not yield valid confidence intervals
        //for the ROC but is valid for point estimation.

        if (binormal) {
            try {
                double inc = Mathematics.round(1.0 / ((double) binorm_count - 1.0), 3);
                double t = 0;
                //double a = (mu_did - mu_not) / sd_did;
                //double b = sd_not / sd_did;
                double[][] raw = new double[2][result[0].length];
                System.arraycopy(result[0], 0, raw[0], 0, raw[0].length);
                System.arraycopy(result[1], 0, raw[1], 0, raw[1].length);
                int tot = 0;
                //Compute normal quantile of value pairs (0<p<1 && 0<q<1)
                for (int i = 0; i < raw[0].length; i++) {
                    if (raw[0][i] != 0 && raw[0][i] != 1 && raw[1][i] != 0 && raw[1][i] != 1) {
                        raw[0][tot] = Mathematics.normalInverse(raw[0][i]);
                        raw[1][tot] = Mathematics.normalInverse(raw[1][i]);
                        tot++;
                    }
                }
                //Some pairs not used
                if(tot!=raw[0].length) {
                    double[][] nD = new double[2][tot];
                    System.arraycopy(raw[0],0,nD[0],0,tot);
                    System.arraycopy(raw[1],0,nD[1],0,tot);
                    raw = nD;
                }
                raw = new DenseDoubleMatrix2D(raw).transpose().toArray();
                double[] c = org.jfree.data.statistics.Regression.getOLSRegression(raw);
                double a = c[0];
                double b = c[1];
                for (int i = 0; i < binorm_count; i++) {
                    //Avoid threshold of exactly 0 or 1
                    double tr = t;
                    if (t == 0) {
                        tr = 0.001;
                    } else if (t == 1.0) {
                        tr = 0.999;
                    }
                    double pod = Mathematics.normal(a + (b * Mathematics.normalInverse(tr)));
                    result[2][i] = tr;
                    result[3][i] = pod;
                    t += inc;
                    t = Mathematics.round(t, 3);
                }
            } catch (Exception e) {
                throw new MetricCalculationException("Unable to compute fitted ROC.");
                //double[][] r = new double[2][result[0].length];
                //r[0] = result[0];
                //r[1] = result[1];
                //result = r;
                //System.out.println("Unable to fit bi-normal ROC to data: returning empirical ROC only.");
                //e.printStackTrace();
            }
        }

        //Check that EVERY threshold has valid points for ROC
        //for(int i = 1; i < result[0].length; i++) {
        //    if(result[0][i]==result[0][i-1] || result[1][i] == result[1][i-1]) {
        //        throw new MetricCalculationException("Could not compute the ROC score for the specified input.");
        //    }
        //}

        //Return
        return new DoubleMatrix2DResult(new DenseDoubleMatrix2D(result));
    }

    /*******************************************************************************
     *                                                                             *
     *                                  TEST METHOD                                *
     *                                                                             *
     ******************************************************************************/

    /**
     * Test method.
     *
     * @param args the args
     */

    public static void main(String[] args) {

    }

}
