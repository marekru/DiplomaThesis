package evs.metric.metrics;

/**
 * An abstract base class for a metric that shows the raw verification
 * data, rather than computing a score or showing a specific attribute of forecast
 * quality.  Examples include the modified box plot and the scatter plot.
 *
 * @author evs@hydrosolved.com
 */

public abstract class RawMetric extends Metric {
    
    
}
