package evs.metric.results;

//Java util dependencies
import java.util.*;
import java.util.Map.*;

//EVS dependencies
import evs.metric.parameters.*;

/**
 * Stores a set of metric results against a unique identifier.  Extends {@link
 * evs.metric.results.MetricResult} for convenience.  A single store supports only one
 * class of metric result so that the getter methods will always return an object
 * of that class or null.  Stores may be stored within other stores of different types.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public abstract class MetricResultStore extends MetricResult {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLES                              *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Map of results.
     */
    
    protected TreeMap results = new TreeMap();
    
    /**
     * The metric result supported by this store.
     */
    
    protected int storedID;
    
    /********************************************************************************
     *                                                                              *
     *                                 CONSTRUCTOR                                  *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Constructs a store with a specified type of metric result as the store type.  
     * Subsequently attempting to add metrics of a different result type will throw
     * an exception.  See the {@link evs.metric.results.MetricResult} class for supported types.
     *
     * @param storedID the result type id
     */
    
    protected MetricResultStore(int storedID) {
        boolean notAllowed = true;
        notAllowed = notAllowed && storedID != DOUBLE_MATRIX_1D_RESULT;
        notAllowed = notAllowed && storedID != ENSEMBLE_SCORE_DECOMPOSITION_RESULT;
        notAllowed = notAllowed && storedID != DOUBLE_MATRIX_2D_RESULT;
        notAllowed = notAllowed && storedID != DOUBLE_RESULT;
        notAllowed = notAllowed && storedID != INTEGER_MATRIX_1D_RESULT;
        notAllowed = notAllowed && storedID != INTEGER_RESULT;
        notAllowed = notAllowed && storedID != METRIC_RESULT_BY_THRESHOLD;
        notAllowed = notAllowed && storedID != METRIC_RESULT_BY_LEAD_PERIOD;
        if(notAllowed) {        
            throw new IllegalArgumentException("Specify a valid identifier for the metric result type.");
        }
        this.storedID = storedID;
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/     

    /**
     * Returns the type of result.  
     *
     * @return the type of result
     */
    
    public int getID() {
        return METRIC_RESULT_STORE; 
    }
    
    /**
     * Returns the type of result stored in this result store.  
     *
     * @return the type of result stored
     */
    
    public int getIDForStoredResults() {
        return storedID;
    }    
    
    /**
     * Returns the result type of the lowest level of stored result in case the
     * store contains one or more other stores.  
     * 
     * @return the lowest level result type
     */
    
    public int getLowestLevelResultID() throws IllegalArgumentException {
        if(!hasResults()) {
            return getID();
        }
        //Check twenty levels
        MetricResult fin = (MetricResult)results.get(results.firstKey());
        while(fin instanceof MetricResultStore) {
            MetricResultStore f = (MetricResultStore) fin;
            if (!f.hasResults()) {
                return getID();
            }
            fin = (MetricResult) f.results.get(f.results.firstKey());
        }
        return fin.getID();
    }
    
    /**
     * Returns true if one or more metric results exists.
     *
     * @return true if a metric result exists, false otherwise
     */
    
    public boolean hasResults() {
        if(results.isEmpty()) {
            return false;
        }
        MetricResult fin = (MetricResult)results.get(results.firstKey());
        while (fin instanceof MetricResultStore) {
            MetricResultStore f = (MetricResultStore) fin;
            if (!f.hasResults()) {
                return false;
            }
            fin = (MetricResult) f.results.get(f.results.firstKey());
        }
        return true;
    }

    /**
     * Returns the number of results in the store.
     *
     * @return the number of results
     */

    public int getResultCount() {
        return results.size();
    }

    /**
     * Returns a string representation.
     *
     * @return a string representation
     */
    
    public String toString() {
        StringBuffer buff = new StringBuffer();
        Iterator i = results.keySet().iterator();
        String nL = System.getProperty("line.separator");
        while(i.hasNext()) {
            buff.append(results.get(i.next()));
            buff.append(nL);
        }
        return buff.toString();
    }

    /**
     * Returns a string representation of the result for writing to an XML file
     * with a specified writing precision.  The results may be spread across several
     * strings to be written as individual nodes.
     *
     * This method should not be called in practice: write stored results by
     * obtaining an XML string for each result in store.
     *
     * @param precision the writing precision
     * @return a string representation for writing to XML
     */

    public String[] toXMLString(int precision) {
        Vector<String> returnMe = new Vector<String>();
        Iterator i = results.keySet().iterator();
        while(i.hasNext()) {
            String[] s = ((MetricResult)results.get(i.next()))
                    .toXMLString(precision);
            for(String n : s) {
                returnMe.add(n);
            }
        }
        return returnMe.toArray(new String[returnMe.size()]);
    }

    @Override
    public TreeMap<ProbabilityIntervalParameter,MetricResult[]> getIntervalsFromResults(
        ProbabilityIntervalParameter[] intervals, MetricResult[] results, double nV, int minSampleSize)
            throws SamplingIntervalException {
        checkIntervalsInput(getID(),intervals,results,minSampleSize);
        TreeMap<ProbabilityIntervalParameter, MetricResult[]> returnMe =
                new TreeMap<ProbabilityIntervalParameter, MetricResult[]>();
        //Check that lowest level result types are the same before proceeding
        //and that the stores contain sufficient results
        for(MetricResult r : results) {
            if(((MetricResultStore)r).getLowestLevelResultID()!=
                    ((MetricResultStore)results[0]).getLowestLevelResultID()) {
                throw new SamplingIntervalException("Cannot compute the sampling intervals: "
                        + "one or more result stores contain inconsistent data types.");
            }
        }
        //Create the bounds
        //Store the metric results within the lowest level store by common key
        TreeMap<Object, Vector<MetricResult>> byCommonKey = new TreeMap<Object, Vector<MetricResult>>();
        MetricResult resultType = null; //Object on which to call getIntervalsFromResults, not a store
        //Collect together all results with common keys in the store
        for (MetricResult r : results) {
            MetricResultStore store = (MetricResultStore) r;
            Iterator it = store.results.keySet().iterator();
            while (it.hasNext()) {
                Object key = it.next();
                MetricResult nextResult = (MetricResult) store.results.get(key);
                if (resultType == null) {
                    resultType = nextResult;
                }
                if (byCommonKey.containsKey(key)) {
                    byCommonKey.get(key).add(nextResult);
                } else {
                    Vector<MetricResult> st = new Vector<MetricResult>();
                    st.add(nextResult);
                    byCommonKey.put(key, st);
                }
            }
        }
        if (resultType == null) {
            throw new SamplingIntervalException("Cannot compute the sampling intervals: one or more "
                    + "result stores contained no results.");
        }
        //Create the bounds stores
        for (ProbabilityIntervalParameter p : intervals) {
            MetricResultStore lowerBound = (MetricResultStore) results[0].deepCopy();
            MetricResultStore upperBound = (MetricResultStore) results[0].deepCopy();
            MetricResultStore sampleSize = (MetricResultStore) results[0].deepCopy();
            lowerBound.results.clear();
            upperBound.results.clear();
            sampleSize.results.clear();
            returnMe.put(p, new MetricResult[]{lowerBound, upperBound, sampleSize});
        }
        //Iterate through each keyed object and obtained all bounds together
        //then update the results
        Iterator it = byCommonKey.keySet().iterator();
        while (it.hasNext()) {
            Object key = it.next();
            Vector<MetricResult> next = byCommonKey.get(key);
            MetricResult[] re = new MetricResult[next.size()];
            next.copyInto(re);
            //Compute the bounds all together
            try {
                TreeMap<ProbabilityIntervalParameter, MetricResult[]> bounds =
                        resultType.getIntervalsFromResults(intervals, re, nV, minSampleSize);
                Iterator it2 = bounds.keySet().iterator();
                //Update the store
                while (it2.hasNext()) {
                    ProbabilityIntervalParameter nextBound = (ProbabilityIntervalParameter) it2.next();
                    MetricResult[] stored = returnMe.get(nextBound);  //Result store level
                    MetricResult[] computed = bounds.get(nextBound);  //Lower level
                    //Add the results for the current key to each of the lower and upper bounds stores
                    ((MetricResultStore) stored[0]).addResult(key, computed[0]);
                    ((MetricResultStore) stored[1]).addResult(key, computed[1]);
                    ((MetricResultStore) stored[2]).addResult(key, computed[2]);
                }
            } catch (SamplingIntervalException e) {
                System.err.println("Unable to complete the sampling intervals for result: "+key+".");
                e.printStackTrace();
            }
        }
        return returnMe;
    }
    
    /********************************************************************************
     *                                                                              *
     *                                MUTATOR METHODS                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Overides the superclass method to update the intervals associated with the
     * stored results.
     *
     * @param interval the interval
     * @param lower the lower bound
     * @param upper the upper bound
     * @param sampleSize the sample size for the interval
     * @param main is true to identify the current interval as the main interval,
     * replacing any existing main interval
     */

    public void addSamplingInterval(ProbabilityIntervalParameter interval,
            MetricResult lower, MetricResult upper, MetricResult sampleSize, boolean main) throws SamplingIntervalException {
        super.addSamplingInterval(interval,lower,upper,sampleSize,main);
        //Check that the lower level result types are consistent
        MetricResultStore lowStore = (MetricResultStore)lower;
        MetricResultStore highStore = (MetricResultStore)upper;
        MetricResultStore sampleStore = (MetricResultStore)sampleSize;
        if(!(lowStore.hasResults()&&highStore.hasResults())) {
            throw new SamplingIntervalException("One or both of the result stores containing the bounds for the sampling "
                    + "intervals is empty, which is not allowed.");
        }
        if(sampleStore.getIDForStoredResults()!=lowStore.getIDForStoredResults()) {
            throw new IllegalArgumentException("The sample size of the sampling interval has a different data type than the bounds.");
        }
        if(lowStore.getIDForStoredResults()!=highStore.getIDForStoredResults()) {
            throw new SamplingIntervalException("The lower and upper bounds of the sampling interval have different data types ["+
                lowStore.getIDForStoredResults()+","+highStore.getIDForStoredResults()+"].");
        }
        if(lowStore.getLowestLevelResultID()!=highStore.getLowestLevelResultID()) {
            throw new SamplingIntervalException("The lower and upper bounds of the sampling interval have different data types ["+
                lowStore.getIDForStoredResults()+","+highStore.getLowestLevelResultID()+"].");
        }
        if(lowStore.getIDForStoredResults()!=getIDForStoredResults()) {
            throw new SamplingIntervalException("The bounds of the sampling interval have a different data type than the result data type ["+
                lowStore.getIDForStoredResults()+","+getIDForStoredResults()+"].");
        }
        if(lowStore.getLowestLevelResultID()!=getLowestLevelResultID()) {
            throw new SamplingIntervalException("The bounds of the sampling interval have a different data type than the result data type ["+
                lowStore.getIDForStoredResults()+","+getLowestLevelResultID()+"].");
        }
        //Add intervals for lower-level result types
        Iterator it = results.keySet().iterator();
        while(it.hasNext()) {
            Object key = it.next();
            MetricResult m = (MetricResult)results.get(key);
            MetricResult low = (MetricResult)lowStore.results.get(key);
            MetricResult high = (MetricResult)highStore.results.get(key);
            MetricResult s = (MetricResult)sampleStore.results.get(key);
            //Allow failure for specific results, but report
            try {
                m.addSamplingInterval(interval, low, high, s, main);
            } catch(SamplingIntervalException g) {
                System.err.println("Failed to add sampling interval at: "+key+". "
                        + "The associated error was: ");
                g.printStackTrace();
            }
        }
    }

    /**
     * Adds a new result to the metric store with a specified identifier.
     * 
     * @param id the identifier
     * @param result the metric result
     */
    
    public void addResult(Object id, MetricResult result) throws IllegalArgumentException {
        if(result == null) {
            throw new IllegalArgumentException("Cannot add a null result to the store.");
        }
        if(result.getID() != storedID) {
            throw new IllegalArgumentException("The specified result was "
                    + "incompatible with the result type allocated for this store: "
                    + ""+result.getID()+" vs. "+storedID);
        }
        if(results.containsKey(id)) {

            System.out.println(getClass());
            System.out.println("Result store contains "+results.size()+" elements, which follow:");
            Iterator it = results.keySet().iterator();
            while(it.hasNext()) {
                System.out.println(it.next());
            }

            throw new IllegalArgumentException("Cannot add the result to the store: a result "
                    + "in this store is already associated with key '"+id+"'.");
        }
        results.put(id,result);

        //Add any sampling intervals
        if(result.hasSamplingIntervals()) {
            TreeMap<ProbabilityIntervalParameter,MetricResult[]> ints = result.getIntervalResults();
            Iterator it = ints.keySet().iterator();
            while(it.hasNext()) {
                ProbabilityIntervalParameter nx = (ProbabilityIntervalParameter)it.next();
                intervals.put(nx,ints.get(nx));
            }
            main = result.getMainInterval();
        }
    }
    
    /**
     * Clears the results from the store.
     */

    public void clearResults() {
        results.clear();
    }

}
