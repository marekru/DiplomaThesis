package evs.metric.parameters;
import java .util.*;

/**
 * A metric parameter that comprises a set of double procedures of the same type.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DoubleProcedureArrayParameter implements MetricParameter {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLE                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Parameter value.
     */
    
    private DoubleProcedureParameter[] value;        
    
    /**
     * Is true if the procedures refer to probabilities, false otherwise.
     */
    
    private ProbabilityIdentifierParameter areProbs; 
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs a double procedure array parameter from an array of double
     * procedures.
     *
     * @param procs the double procedures
     */
    
    public DoubleProcedureArrayParameter(DoubleProcedureParameter[] procs) {
        if(procs == null || procs.length==0) {
            throw new IllegalArgumentException("Specify at least one double procedure.");
        }
        int type = procs[0].getThresholdType().getParVal();
        value = new DoubleProcedureParameter[procs.length];
        value[0]=(DoubleProcedureParameter)procs[0].deepCopy();
        areProbs = procs[0].areProbs();
        for(int i = 1; i < procs.length; i++) {
            if(procs[i]==null) {
                throw new IllegalArgumentException("One or more procedures are null.");
            }
            if(procs[i].getThresholdType().getParVal() != type) {
                throw new IllegalArgumentException("Cannot mix threshold types.");
            }
            if(!(procs[i].areProbs().equals(areProbs))) {
                throw new IllegalArgumentException("Cannot mix real-valued and probability thresholds.");
            }
            value[i]=(DoubleProcedureParameter)procs[i].deepCopy();
        }
        //Sort
        Arrays.sort(value);
    }
    
    /**
     * Constructs a double procedure array parameter from an array of double
     * values and a threshold type.  If the threshold is a "BETWEEN" condition,
     * the adjacent thresholds represent the boundaries.
     *
     * In addition, specify whether each threshold is a "main" threshold.
     *
     * @param t the thresholds
     * @param type the type of condition (see DoubleProcedureParameter)
     * @param areProbs is true if the procedures refer to probabilities
     * @param m identifies whether or not the thresholds are "main" thresholds
     * @param s string identifiers for each threshold
     */
    
    public DoubleProcedureArrayParameter(DoubleArrayParameter t, int type, 
            boolean areProbs, BooleanArrayParameter m, StringArrayParameter s) {
        //Check input
        if(t==null) {
            throw new IllegalArgumentException("Specify a non null array of thresholds for " +
                    "construction of the "+getClass().getSimpleName()+".");
        }
        if(m==null) {
            throw new IllegalArgumentException("Specify a non null array of 'main' threshold identifiers for " +
                    "construction of the "+t.getClass().getSimpleName()+".");
        }
        if(s==null) {
            throw new IllegalArgumentException("Specify a non null array of string identifiers for " +
                    "construction of the "+t.getClass().getSimpleName()+".");
        }
        if(t.getID()==t.DOUBLE_ARRAY_PARAMETER && areProbs ||
                t.getID()==t.PROBABILITY_ARRAY_PARAMETER && !areProbs) {
            throw new IllegalArgumentException("The input type for "+t.getClass().getSimpleName()+" is not " +
                    "consistent with the probability identifier ["+areProbs+"].");
        }
        double[] thresholds = t.getParVal();
        boolean[] main = m.getParVal();
        String[] ids = s.getParVal();
        if (thresholds.length != main.length) {
            throw new IllegalArgumentException("Specify the same number of identifiers of \"main\" thresholds " +
                    "as thresholds ["+thresholds.length+":"+main.length+"]");
        }
        if (s.getLength() != main.length) {
            throw new IllegalArgumentException("Specify one string identifier for each threshold.");
        }
        this.areProbs=new ProbabilityIdentifierParameter(areProbs);
        TreeMap<Double,DoubleProcedureParameter> sorted = new TreeMap<Double,DoubleProcedureParameter>();
        if (type == DoubleProcedureParameter.BETWEEN) {
            for (int i = 1; i < thresholds.length; i++) {
                DoubleParameter[] ps = null;
                if (areProbs) {
                    ps = new DoubleParameter[]{new ProbabilityParameter(thresholds[i - 1]), new ProbabilityParameter(thresholds[i])};
                } else {
                    ps = new DoubleParameter[]{new DoubleParameter(thresholds[i - 1]), new DoubleParameter(thresholds[i])};
                }
                StringParameter sp = new StringParameter((String)null);
                if(ids[i-1]!=null) {
                    sp = new StringParameter(ids[i-1]);
                }
                DoubleProcedureParameter p = new DoubleProcedureParameter(new IntegerParameter(type), ps,
                        this.areProbs,new BooleanParameter(main[i-1]&&main[i]),sp);
                sorted.put(thresholds[i - 1],p);
            }
        } else {
            for (int i = 0; i < thresholds.length; i++) {
                DoubleParameter[] ps = null;
                if (areProbs) {
                    ps = new DoubleParameter[]{new ProbabilityParameter(thresholds[i])};
                } else {
                    ps = new DoubleParameter[]{new DoubleParameter(thresholds[i])};
                }
                DoubleProcedureParameter p = new DoubleProcedureParameter(new IntegerParameter(type),
                        ps, this.areProbs,new BooleanParameter(main[i]),new StringParameter(ids[i]));
                sorted.put(thresholds[i],p);
            }
        }
        //Sort
        value = new DoubleProcedureParameter[sorted.size()];
        Iterator it = sorted.keySet().iterator();
        int tot = 0;
        while(it.hasNext()) {
            value[tot]=sorted.get((Double)it.next());
            tot++;
        }
    }    
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     *
     * @return an identifier
     */
    
    public int getID() {
        return DOUBLE_PROCEDURE_ARRAY_PARAMETER;
    }      
    
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "double_procedure_array_parameter";
    }   
    
    /**
     * Returns the parameter value.
     *
     * @return the parameter value
     */
    
    public DoubleProcedureParameter[] getParVal() {
        return value;
    }       
    
    /**
     * Returns the logical type associated with this parameter.
     * 
     * @return the logical type
     */
    
    public IntegerParameter getThresholdType() {
        return value[0].getThresholdType();
    }

    /**
     * Returns the status of the thresholds as main (true) or not (false).
     *
     * @return the main thresholds
     */

    public BooleanArrayParameter getMainThresholds() {
        return (BooleanArrayParameter)((BooleanArrayParameter)getThresh()[1]).deepCopy();
    }

    /**
     * Returns the string id to append to each threshold.  Returns null if all
     * of the ids are null, otherwise returns the null string for each null id.
     * The ids are separated by ", ".
     *
     * @return the string ids to append
     */

    public StringArrayParameter getThresholdIDs() {
        String[] ids = (String[])getThresh()[2];
        return new StringArrayParameter(ids);
    }

    /**
     * Returns the threshold values associated with this parameter in a 1D array.
     * If a "BETWEEN" condition is used, only unique threshold values are returned
     * (i.e. one more value than thresholds).
     * 
     * @return the thresholds
     */
    
    public DoubleParameter[] getThresholdValues() {
        return (DoubleParameter[])getThresh()[0];
    }    
    
    /**
     * Returns the threshold values associated with this parameter in a 1D double
     * array. If a "BETWEEN" condition is used, only unique threshold values are returned
     * (i.e. one more value than thresholds).
     * 
     * @return the thresholds as doubles
     */
    
    public double[] getThresholdValuesAsDoubleArray() {
        DoubleParameter[] d = (DoubleParameter[])getThresh()[0];
        double[] returnMe = new double[d.length];
        for(int i = 0; i < d.length; i++) {
            returnMe[i]=d[i].getParVal();
        }
        return returnMe;
    }       
    
    /**
     * Returns true if the double procedures are defined for probability values,
     * false otherwise.
     * 
     * @return true if the double procedures are based on probabilities.
     */
    
    public ProbabilityIdentifierParameter areProbs() {
        return areProbs;
    }
    
    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
    
    public MetricParameter deepCopy() {
        DoubleProcedureParameter[] newVals = new DoubleProcedureParameter[value.length];  
        for(int i = 0; i < newVals.length; i++) {
            newVals[i]=(DoubleProcedureParameter)value[i].deepCopy();
        }
        return new DoubleProcedureArrayParameter(newVals);
    }       
    
    /**
     * Overrides superclass method.
     * 
     * @return a string representation of the receiver.
     */
    
    public String toString() {
        StringBuffer append = new StringBuffer();
        for(int i = 0; i < value.length; i++) {
            append.append(value[i].toString()+System.getProperty("line.separator"));
        }
        return append.toString();
    }
    
    /**
     * Overrides equals.
     * 
     * @param obj the input
     * @return true if the input object is equal
     */
    
    public boolean equals(Object obj) {
        boolean returnMe = obj instanceof DoubleProcedureArrayParameter;
        if(returnMe) {
            returnMe = Arrays.equals(value,((DoubleProcedureArrayParameter)obj).value);
        }
        if(returnMe) {
            returnMe = ((DoubleProcedureArrayParameter)obj).areProbs.equals(areProbs);
        }
        return returnMe;
    }
    
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        assert false : "hashCode not implemented for MetricParameter.";
        return 1;
    }    
    
    /*******************************************************************************
     *                                                                             *
     *                               PRIVATE METHOD                                *
     *                                                                             *
     ******************************************************************************/    
    
    /**
     * Returns a sorted array of DoubleParameter objects in the first index of 
     * the returned object array (corresponding to thresholds), a BooleanArrayParameter
     * of the same size indicating the status of each threshold as a main threshold 
     * in the second index position and an array of string identifiers in the third
     * position.
     * 
     * @return the thresholds and corresponding status as main thresholds, together
     * with any string id to append
     */
    
    private Object[] getThresh() {
        TreeMap<DoubleParameter,Object[]> unique = new TreeMap();
        for(int i = 0; i < value.length; i++) {
            DoubleParameter[] dat = value[i].getThresholdValues();
            String s = null;
            if (value[i].hasStringID()) {
                s = value[i].getStringID().getParVal();
            }
            for (int j = 0; j < dat.length; j++) {
                //Doesn't contain key, so add
                if(!unique.containsKey(dat[j])) {
                    unique.put(dat[j],new Object[]{
                        value[i].isMainThreshold().isTrue,s
                    });
                } 
                //Does contain key: if threshold is a main one, ensure the status is main
                //because a BETWEEN condition has overlapping boundary thresholds
                else {
                    if(value[i].isMainThreshold().isTrue) {
                        unique.put(dat[j],new Object[]{
                            true,s
                        });
                    }
                }
            }
        }
        boolean[] b = new boolean[unique.size()];
        String[] ids = new String[b.length];
        DoubleParameter[] c = new DoubleParameter[b.length];
        int nxt = 0;
        for(Iterator i = unique.keySet().iterator(); i.hasNext();) {
            c[nxt]=(DoubleParameter)i.next();
            b[nxt]=(Boolean)unique.get(c[nxt])[0];
            ids[nxt]=(String)unique.get(c[nxt])[1];
            nxt++;
        }
        //Remove the id on the last threshold if this is a between condition
        if(value[0].getThresholdType().getParVal()==value[0].BETWEEN) {
            ids[ids.length-1]=null;
        }
        return new Object[]{c,new BooleanArrayParameter(b),ids};
    }     
    

}
