package evs.metric.results;

//EVS dependencies
import evs.utilities.matrix.*;
import evs.utilities.mathutil.*;
import evs.metric.metrics.*;
import evs.metric.parameters.*;
import evs.analysisunits.*;

//Java dependencies
import java.util.*;

/**
 * Immutable wrapper class for a 1D double matrix that acts as a metric result.
 * Contains the decomposition of an ensemble metric, such as the CRPS, into 
 * contributions due to reliability, resolution and uncertainty.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public final class EnsembleScoreDecomposition extends DoubleMatrix1DResult {
    
    /********************************************************************************
     *                                                                              *
     *                                CLASS VARIABLES                               *
     *                                                                              *
     *******************************************************************************/    

    /**
     * Stores the type of decomposition.  One of DecomposableScore.CALIBRATION_REFINEMENT, 
     * DecomposableScore.LIKELIHOOD_BASE_RATE or DecomposableScore.CR_AND_LBR or
     * DecomposableScore.NONE.
     */

    private int template;

    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs a metric result with a double matrix and a decomposition template.
     * Throws an exception if the number of rows in the input does not match the
     * decomposition template.
     *
     * @param template one of DecomposableScore.CALIBRATION_REFINEMENT,
     * DecomposableScore.LIKELIHOOD_BASE_RATE, DecomposableScore.CR_AND_LBR or
     * DecomposableScore.NONE.
     * @param result the metric result
     */
    
    public EnsembleScoreDecomposition(int template, DoubleMatrix1D result) {
        super(result);
        switch(template) {
            case DecomposableScore.CALIBRATION_REFINEMENT: {
                if (result.getRowCount() != 4 && result.getRowCount() != 5) {  //Five allowed for potential score (perfect rel)
                    throw new IllegalArgumentException("Incorrect number of inputs for the calibration-refinement" +
                            "factorization.");
                }
            }; break;
            case DecomposableScore.LIKELIHOOD_BASE_RATE: {
                if(result.getRowCount() != 4) {
                    throw new IllegalArgumentException("Expected four inputs to the likelihood-base-rate" +
                            "factorization: overall score, Type-II bias, discrimination and sharpness.");
                }
            }; break;
            case DecomposableScore.CR_AND_LBR: {  //Variable number allowed (e.g. BSS versus BS)
//                if(result.getRowCount() != 18) {
//                    throw new IllegalArgumentException("Expected eighteen inputs to the combined CR and LBR" +
//                            "factorizations: overall score, reliability, resolution, uncertainty, " +
//                            "Type-II bias, discrimination, sharpness, followed by the overall score " +
//                            "conditional on the observed outcome, Type-II bias " +
//                            "and discrimination conditional on the observed outcome, the reliability"
//                            + "skill score, the resolution skill score, the Type-II bias skill score, "
//                            + "the discrimination skill score, and the sharpness skill score.");
//                }
            }; break;
            case DecomposableScore.NONE: {
                if(result.getRowCount() != 1) {
                    throw new IllegalArgumentException("Expected one input for no score decomposition, namely the " +
                            "overall score value.");
                }
            }; break;
            default: {
                throw new IllegalArgumentException("Unrecognized template for score decomposition.");
            }
        }
        this.template = template;
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Returns the type of result.  
     *
     * @return the type of result
     */
    
    public int getID() {
        return ENSEMBLE_SCORE_DECOMPOSITION_RESULT;
    }    
    
     /**
     * Applies an aggregation function to the corresponding values (e.g. same 
     * matrix position) in the input results, placing a Metric.NULL_DATA if all 
     * of those values are Metric.NULL_DATA.  Throws an exception if the inputs
     * are not of the same class.  The return type may not correspond to the input
     * type if the result of the aggregation function cannot be stored in the input
     * type.  Specifically, any aggregation of a result that contains integers 
     * should ALWAYS return a result that contains doubles, as the aggregation 
     * function is guaranteed to do so.  For example, the average of a set of 
     * integers may not be an integer.  Specify a set of weights for each metric
     * that are constant across all forecast lead times.  The weights must sum to 1.
     * 
     * @param input the input results
     * @param func the aggregation function
     * @param weights the constant weights to apply across all lead times
     * @return the aggregated result   
     */
    
    public MetricResult aggregate(MetricResult[] input, VectorFunction func,double[] weights) throws MetricResultException {
        checkAggInputs(input,weights);  //Throws an exception if inputs are invalid
        //Check inputs are correct
        if(input[0].getID()!=ENSEMBLE_SCORE_DECOMPOSITION_RESULT) {
            throw new MetricResultException("Expected instances of EnsembleScoreDecompositionResult in the input for aggregation, but received: "+input[0].getClass());
        }
        EnsembleScoreDecomposition e = ((EnsembleScoreDecomposition)input[0]);
        int rows = e.getResult().getRowCount();
        DenseDoubleMatrix1D im = new DenseDoubleMatrix1D(rows);
        for(int i = 0; i < rows; i++) {
            DenseDoubleMatrix1D in = new DenseDoubleMatrix1D(input.length);
            for(int j = 0; j < input.length; j++) {
                in.set(j,weights[j]*((EnsembleScoreDecomposition)input[j]).getResult().get(i));
            }
            im.set(i,func.apply(in,Metric.NULL_DATA)); //Aggregate ith position
        }
        return new EnsembleScoreDecomposition(e.getDecTemplate(),im);
    }      
    
    /**
     * Returns the metric result.
     *
     * @return the result
     */
    
    public DoubleMatrix1D getResult() {
        return result;
    }

    @Override
    public TreeMap<ProbabilityIntervalParameter,MetricResult[]> getIntervalsFromResults(
        ProbabilityIntervalParameter[] intervals, MetricResult[] results, double nV, int minSampleSize)
            throws SamplingIntervalException {
        //Check the input
        checkIntervalsInput(getID(),intervals,results,minSampleSize);
        TreeMap<ProbabilityIntervalParameter, MetricResult[]> returnMe =
                new TreeMap<ProbabilityIntervalParameter, MetricResult[]>();

        int rows = ((EnsembleScoreDecomposition)results[0]).result.getRowCount();
        int template = ((EnsembleScoreDecomposition)results[0]).getDecTemplate();
        //Set the results templates
        for (ProbabilityIntervalParameter p : intervals) {
            EnsembleScoreDecomposition addMe = new EnsembleScoreDecomposition(template,
                    new DenseDoubleMatrix1D(rows));
            returnMe.put(p,new MetricResult[]{addMe,addMe.deepCopy(),addMe.deepCopy()});
        }

        //Iterate through the pointwise statistics
        for (int i = 0; i < rows; i++) {
            //Obtain the order statistics
            double[] points = new double[results.length];
            int nullCount = 0;
            for (int j = 0; j < points.length; j++) {
                try {
                    points[j] = ((EnsembleScoreDecomposition) results[j]).result.get(i);
                    if (points[j] == nV) {
                        nullCount++;
                    }
                } catch (ArrayIndexOutOfBoundsException e) {
                    throw new SamplingIntervalException("Failed to compute the sampling intervals as one or more "
                            + "input results of type '"+getClass().getSimpleName()+"' had an inconsistent number "
                            + "of entries.");
                }
            }

            //Order the data
            Arrays.sort(points);

            //Compute and return the results
            int actualSamples = points.length - nullCount;
            for (ProbabilityIntervalParameter p : intervals) {
                MetricResult[] r = returnMe.get(p);
                //Null intervals
                if (actualSamples < minSampleSize) {
                    ((EnsembleScoreDecomposition)r[0]).result.set(i,nV);
                    ((EnsembleScoreDecomposition)r[1]).result.set(i,nV);
                    ((EnsembleScoreDecomposition)r[2]).result.set(i,nV);
                } //Valid intervals
                else {
                    try {
                        double lower = EmpiricalCDFCalculator.getVal(points, p.getLower(), nV, false);
                        double upper = EmpiricalCDFCalculator.getVal(points, p.getUpper(), nV, false);
                        ((EnsembleScoreDecomposition)r[0]).result.set(i,lower);
                        ((EnsembleScoreDecomposition)r[1]).result.set(i,upper);
                        ((EnsembleScoreDecomposition)r[2]).result.set(i,actualSamples);
                    } catch (Exception e) {
                        throw new SamplingIntervalException("Failed to compute sampling interval '" + p + "' with error "
                                + "message: " + e.getMessage());
                    }
                }
            }
        }
        return returnMe;
    }

    /**
     * Returns the type of score decomposition.
     *
     * @return the type of decomposition
     */

    public int getDecTemplate() {
        return template;
    }

    /**
     * Returns the specified component of a score decomposition.  Specify one
     * of the class variables in this class.  Throws an exception if the input is
     * not recognized.
     * 
     * @param comp one of the class variables in this class
     * @return the specified component of the score decomposition
     */
    
    public DoubleResult getComponent(int comp) {
        //Reliability, resolution, uncertainty
        int index;
        if (template == DecomposableScore.CALIBRATION_REFINEMENT) {
            switch (comp) {
                case DecomposableScore.OVERALL_SCORE:
                    index=0; break;
                case DecomposableScore.RELIABILITY:
                    index=1; break;
                case DecomposableScore.RESOLUTION:
                    index=2; break;
                case DecomposableScore.UNCERTAINTY:
                    index=3; break;
                case DecomposableScore.POTENTIAL:
                    index=4; break;
                default:
                    throw new IllegalArgumentException("Unrecognized component of score decomposition.");
            }
        }
        //Type-II bias, discrimination, sharpness
        else if (template == DecomposableScore.LIKELIHOOD_BASE_RATE) {
            switch (comp) {
                case DecomposableScore.OVERALL_SCORE:
                    index=0; break;
                case DecomposableScore.TYPE_II_BIAS:
                    index=1; break;
                case DecomposableScore.DISCRIMINATION:
                    index=2; break;
                case DecomposableScore.SHARPNESS:
                    index=3; break;
                default:
                    throw new IllegalArgumentException("Unrecognized component of score decomposition.");
            }
        } 
        //All 
        else if (template == DecomposableScore.CR_AND_LBR){
            switch (comp) {
                case DecomposableScore.OVERALL_SCORE:
                    index=0; break;
                case DecomposableScore.RELIABILITY:
                    index=1; break;
                case DecomposableScore.RESOLUTION:
                    index=2; break;
                case DecomposableScore.UNCERTAINTY:
                    index=3; break;
                case DecomposableScore.TYPE_II_BIAS:
                    index=4; break;
                case DecomposableScore.DISCRIMINATION:
                    index=5; break;
                case DecomposableScore.SHARPNESS:
                    index=6; break; 
                case DecomposableScore.SCORE_GIVEN_OBS_TRUE:
                    index=7; break;
                case DecomposableScore.SCORE_GIVEN_OBS_FALSE:
                    index=8; break;
                case DecomposableScore.TYPE_II_BIAS_GIVEN_OBS_TRUE:
                    index=9; break;
                case DecomposableScore.TYPE_II_BIAS_GIVEN_OBS_FALSE:
                    index=10; break;
                case DecomposableScore.DISCRIMINATION_GIVEN_OBS_TRUE:
                    index=11; break;
                case DecomposableScore.DISCRIMINATION_GIVEN_OBS_FALSE:
                    index=12; break;
                default:
                    throw new IllegalArgumentException("Unrecognized component of score decomposition.");
            }
        }
        else if (template == DecomposableScore.NONE) {
            switch (comp) {
                case DecomposableScore.OVERALL_SCORE:
                    index=0; break;
                default:
                    throw new IllegalArgumentException("Unrecognized component of score decomposition.");
            }
        }
        //In case of changes to code base
        else {
            throw new IllegalArgumentException("Unrecognized score decomposition.");
        }
        //Add any intervals
        DoubleResult r = new DoubleResult(result.get(index));
        TreeMap<ProbabilityIntervalParameter,MetricResult[]> addMe = new 
                TreeMap<ProbabilityIntervalParameter,MetricResult[]>();
        if(hasSamplingIntervals()) {
            TreeMap<ProbabilityIntervalParameter,MetricResult[]> ints = getIntervalResults();
            Iterator it = ints.keySet().iterator();
            while(it.hasNext()) {
                ProbabilityIntervalParameter pt = (ProbabilityIntervalParameter)it.next();
                MetricResult[] nxtO = ints.get(pt);
                MetricResult[] nxtN = new MetricResult[3];
                nxtN[0]=((EnsembleScoreDecomposition)nxtO[0]).getComponent(comp);
                nxtN[1]=((EnsembleScoreDecomposition)nxtO[1]).getComponent(comp);
                nxtN[2]=((EnsembleScoreDecomposition)nxtO[2]).getComponent(comp);
                addMe.put(pt,nxtN);
            }
            r.addSamplingIntervals(addMe,main);
        }
        return r;
    }

    /**
     * Returns true if a specified decomposition result is available and is non-null,
     * false otherwise.
     *
     * @return true if a non-null decomposition result is available, false otherwise.
     */

    public boolean hasComponent(int comp) {
        try {
            DoubleResult c = getComponent(comp);
            return c.getResult()!=Metric.NULL_DATA;
        }
        catch(Exception e) {
            return false;
        }
    }

    /**
     * Returns a string representation of the receiver.
     *
     * @return a string representation
     */
    
    public String toString() {
        String s = result.toString();
        s=s.replaceAll("-Infinity","All data");
        return s;
    }    
    
    /**
     * Returns a deep copy of the current metric result, where all instance variables 
     * occupy independent positions in memory from the current metric result.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricResult deepCopy() {
        EnsembleScoreDecomposition d = new
                EnsembleScoreDecomposition(template,(DoubleMatrix1D)result.deepCopy());
        d.intervals = deepCopyIntervals();
        if(hasMainInterval()) {
            d.main = (ProbabilityIntervalParameter)main.deepCopy();
        }
        return d;
    }     
    
}
