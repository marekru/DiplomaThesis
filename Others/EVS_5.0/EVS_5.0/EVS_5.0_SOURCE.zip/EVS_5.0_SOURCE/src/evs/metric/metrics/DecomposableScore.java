package evs.metric.metrics;

/**
 * Identifies a metric that may be decomposed into constituent parts, such as
 * reliability, resolution and uncertainty.
 * 
 * @author evs@hydrosolved.com
 */

public interface DecomposableScore {

    /**
     * Identifier for the overall score in a score decomposition.
     */
    
    static final int OVERALL_SCORE = 1001;    
    
    /**
     * Identifier for the reliability component of a score decomposition.
     */
    
    static final int RELIABILITY = 1002;

    /**
     * Identifier for the resolution component of a score decomposition.
     */
    
    static final int RESOLUTION = 1003;
    
    /**
     * Identifier for the uncertainty component of a score decomposition.
     */
    
    static final int UNCERTAINTY = 1004;

    /**
     * Identifier for the potential score value (perfect reliability).
     */

    static final int POTENTIAL = 101;

    /**
     * Identifier for the Type-II conditional bias component of a score decomposition.
     */

    static final int TYPE_II_BIAS = 1005;

    /**
     * Identifier for the discrimination component of a score decomposition.
     */

    static final int DISCRIMINATION = 1006;

    /**
     * Identifier for the sharpness component of a score decomposition.
     */

    static final int SHARPNESS = 1007;

    /**
     * Identifier for score value conditional on the event being observed.
     */

    static final int SCORE_GIVEN_OBS_TRUE = 1008;

     /**
     * Identifier for score value conditional on the event being observed to not occur.  
     */

    static final int SCORE_GIVEN_OBS_FALSE = 1009;

    /**
     * Identifier for Type-II bias conditional on the event being observed.
     */

    static final int TYPE_II_BIAS_GIVEN_OBS_TRUE = 1010;

     /**
     * Identifier for Type-II bias conditional on the event being observed to not occur.
     */

    static final int TYPE_II_BIAS_GIVEN_OBS_FALSE = 1011;

    /**
     * Identifier for discrimination conditional on the event being observed.
     */

    static final int DISCRIMINATION_GIVEN_OBS_TRUE = 1012;

     /**
     * Identifier for discrimination conditional on the event being observed to not occur.
     */

    static final int DISCRIMINATION_GIVEN_OBS_FALSE = 1013;

    /**
     * Identifier for a Calibration-Refinement (CR) factorization into reliability
     * - resolution + uncertainty, comprising the overall score followed by the
     * three components in that order.
     */

    static final int CALIBRATION_REFINEMENT = 2001;

    /**
     * Identifier for a decomposition into Type-II conditional bias - discrimination +
     * sharpness, comprising the overall score followed by the three components in
     * that order.
     */

    static final int LIKELIHOOD_BASE_RATE = 2002;

    /**
     * Identifier for the score and components of both the CR and LBR factorizations,
     * as well as several mixed components:
     *
     * The overall score
     * Reliability
     * Resolution
     * Uncertainty
     * Type-II conditional bias
     * Discrimination
     * Sharpness
     *
     * And further components:
     *
     * Score | Observed to occur
     * Score | Observed to not occur
     *
     * And further components:
     *
     * Type-II conditional bias | Observed to occur
     * Type-II conditional bias | Observed to not occur
     * Discrimination | Observed to occur
     * Discrimination | Observed to not occur
     */

    static final int CR_AND_LBR = 2003;

    /**
     * Indicator for no decomposition.
     */

    static final int NONE = 2004;
    
    /**
     * String identifier used for CR factorization.
     */
    
    static final String CALIBRATION_REFINEMENT_STRING = "CR";
    
    /**
     * String identifier used for LBR factorization.
     */
    
    static final String LIKELIHOOD_BASE_RATE_STRING = "LBR";    
    
    /**
     * String identifier used for CR and LBR factorization.
     */
    
    static final String CR_AND_LBR_STRING = "CR_LBR";    

    /**
     * String identifier used for no factorization.
     */
    
    static final String NONE_STRING = "NONE";      
    
    /**
     * String for the overall score in a score decomposition.
     */
    
    static final String OVERALL_SCORE_STRING = "SCORE";    
    
    /**
     * String for the reliability component of a score decomposition.
     */
    
    static final String RELIABILITY_STRING = "REL";

    /**
     * String for the resolution component of a score decomposition.
     */
    
    static final String RESOLUTION_STRING = "RES";
    
    /**
     * String for the uncertainty component of a score decomposition.
     */
    
    static final String UNCERTAINTY_STRING = "UNC";

    /**
     * String for the potential score value (perfect reliability).
     */

    static final String POTENTIAL_STRING = "POT";

    /**
     * String for the Type-II conditional bias component of a score decomposition.
     */

    static final String TYPE_II_BIAS_STRING = "TYPE-II";

    /**
     * String for the discrimination component of a score decomposition.
     */

    static final String DISCRIMINATION_STRING = "DIS";

    /**
     * String for the sharpness component of a score decomposition.
     */

    static final String SHARPNESS_STRING = "SHA";

    /**
     * String for score value conditional on the event being observed.
     */

    static final String SCORE_GIVEN_OBS_TRUE_STRING = "SCORE | OBS";

     /**
     * String for score value conditional on the event being observed to not occur.  
     */

    static final String SCORE_GIVEN_OBS_FALSE_STRING = "SCORE | !OBS";    
    
    /**
     * String for Type-II bias conditional on the event being observed.
     */

    static final String TYPE_II_BIAS_GIVEN_OBS_TRUE_STRING = "TYPE-II | OBS";

     /**
     * String for Type-II bias conditional on the event being not observed.
     */

    static final String TYPE_II_BIAS_GIVEN_OBS_FALSE_STRING = "TYPE-II | !OBS";

    /**
     * String for discrimination conditional on the event being observed.
     */

    static final String DISCRIMINATION_GIVEN_OBS_TRUE_STRING = "DIS | OBS";

     /**
     * String for discrimination conditional on the event being not observed.
     */

    static final String DISCRIMINATION_GIVEN_OBS_FALSE_STRING = "DIS | !OBS";    

    /**
     * The default decomposition.
     */

    static final int DEFAULT_DECOMPOSITION = CALIBRATION_REFINEMENT;   
    
    /**
     * The default decomposition string.
     */

    static final String DEFAULT_DECOMPOSITION_STRING = CALIBRATION_REFINEMENT_STRING;      
    
    /**
     * Returns true if the metric will be decomposed, false if only the overall
     * value will be computed.
     * 
     * @return true if the decomposition of the metric value will be provided
     */
    
    boolean willDecompose();
    
    /**
     * Returns the type of decomposition required. One of:
     * 
     * DecomposableScore.CALIBRATION_REFINEMENT
     * DecomposableScore.LIKELIHOOD_BASE_RATE
     * DecomposableScore.CR_AND_LBR
     * DecomposableScore.NONE  
     * 
     * @return the type of decomposition
     */
    
    int getScoreDecType();
    
    /**
     * Returns an array of integer decompositions that have been implemented. 
     * Each int is one of:
     * 
     * DecomposableScore.CALIBRATION_REFINEMENT
     * DecomposableScore.LIKELIHOOD_BASE_RATE
     * DecomposableScore.CR_AND_LBR
     * DecomposableScore.NONE  
     * 
     * @return an array of implemented decompositions.
     */
    
    int[] getDecompositionOptions();
    
}
