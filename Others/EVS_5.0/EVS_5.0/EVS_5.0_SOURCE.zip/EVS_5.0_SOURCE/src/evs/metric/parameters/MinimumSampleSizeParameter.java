package evs.metric.parameters;

/**
 * Records the minimum sample size with which to compute a metric. The meaning
 * of this parameter may vary with metric.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public final class MinimumSampleSizeParameter extends PositiveIntegerParameter {
    
    /********************************************************************************
     *                                                                              *
     *                                 VARIABLES                                    *
     *                                                                              *
     *******************************************************************************/         
    
    /**
     * Default minimum sample size.
     */
    
    public static final int DEFAULT_MINIMUM_SAMPLE_SIZE = 1;
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     

    /**
     * Constructs a default object with the sample size {@link MinimumSampleSizeParameter#DEFAULT_MINIMUM_SAMPLE_SIZE}.
     */ 
    
    public MinimumSampleSizeParameter() {  
        super(DEFAULT_MINIMUM_SAMPLE_SIZE);
    }    
    
    /**
     * Constructs an object with an integer parameter value
     *
     * @param par the parameter value  
     */ 
    
    public MinimumSampleSizeParameter(int par) {  
        super(par);
    }
    
    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricParameter deepCopy() {
        return new MinimumSampleSizeParameter(par);
    }     
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
        
    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     * Remember to override in any subclass.
     *
     * @return an identifier
     */
    
    public int getID() {
        return MINIMUM_SAMPLE_SIZE_PARAMETER;
    }     
    
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "minimum_sample_size_parameter";
    }       
    
}
