package evs.metric.metrics;

//EVS dependencies
import evs.metric.parameters.*;
import evs.metric.results.*;
import evs.utilities.*;
import evs.utilities.mathutil.*;
import evs.utilities.matrix.*;

//Java util dependencies
import java.util.TreeMap;
import java.util.Iterator;

/**
 * Constructs a modified box-and-whisker plot with a set of thresholds.  The boxes
 * represent the empirical pdf of errors for the forecasts and are constructed per
 * lead time (i.e one box per real time for a single lead time), rather than pooled 
 * by lead time.  The boxes are ordered by size of observation.  Boxes for duplicate
 * observations are averaged for each probability threshold.   
 * 
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ModifiedBoxPlotUnpooledByLeadObs extends ModifiedBoxPlot {

    /********************************************************************************
     *                                                                              *
     *                                  VARIABLES                                   *
     *                                                                              *
     *******************************************************************************/     

    /**
     * Default number of points to include in a ROC diagram.
     */
    
    private static BoxUnpooledObsPointsParameter defPCount = new BoxUnpooledObsPointsParameter(10);      
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/      
      
    /**
     * Attempts to construct a modified box plot with a set of thresholds and a
     * parameter indicating the forecast types for which the box plots will be 
     * constructed.
     *
     * @param points the number of thresholds to include in the boxes
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use 
     * conditional pairs when available
     */
    
    public ModifiedBoxPlotUnpooledByLeadObs(BoxUnpooledObsPointsParameter points, ForecastTypeParameter fType, UnconditionalParameter unconditional) {
        //Set the name
        name = "Modified box plot per lead time by observed value";
        //Set the parameters
        setParameters(new MetricParameter[]{points,fType,unconditional});
        //Set the link to html description of the metric
        descriptionURL = getClass().getResource(EVSConstants.STATS_EXPLAINED_DIR + "boxbyobs.htm");
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/      
  
    /**
     * Returns the metric identifier.
     *
     * @return an identifier
     */
    
    public int getID() {
        return BOX_DIAGRAM_UNPOOLED_BY_LEAD_OBS;
    }      
    
    /**
     * Returns the result type associated with the metric.  See the 
     * evs.metric.MetricResult class for supported types.
     *
     * @return an identifier
     */
    
    public int getResultID() {
        return MetricResult.DOUBLE_MATRIX_2D_RESULT;
    }      
    
    /**
     * Returns true if the metric is defined in real units of the forecast
     * and observed variable, false otherwise.
     * 
     * @return true if the metric is defined in real units
     */    

    public boolean hasRealUnits() {
        return true;
    }       
    
    /**
     * Returns a deep copy of the current metric, where all instance variables 
     * occupy independent positions in memory from the current metric.  
     *
     * @return a deep copy of the current object 
     */
    
    public Metric deepCopy() {
        ModifiedBoxPlotUnpooledByLeadObs returnMe = new ModifiedBoxPlotUnpooledByLeadObs((BoxUnpooledObsPointsParameter)pars[0].deepCopy(),(ForecastTypeParameter)pars[1].deepCopy(),(UnconditionalParameter)pars[2].deepCopy());
        deepCopyResults(returnMe);
        return returnMe;
    }    
    
    /**
     * Returns the default point count.  
     *
     * @return the default point count
     */
    
    public static PositiveIntegerParameter getDefaultPointCount() {
        return (PositiveIntegerParameter)defPCount.deepCopy();
    }        
    
    /**
     * Returns a metric with default parameter values.  
     *
     * @return a metric with default parameter values.
     */
    
    public static Metric getDefaultMetric() { 
        ForecastTypeParameter type = new ForecastTypeParameter(new int[]{ForecastTypeParameter.REGULAR_FORECAST});
        return new ModifiedBoxPlotUnpooledByLeadObs(defPCount,type,new UnconditionalParameter(false)); 
    }     

    /********************************************************************************
     *                                                                              *
     *                              PROTECTED METHODS                               *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Returns a box dataset from an input dataset per lead time.  Hours from 
     * the start time are in the first column and the probability thresholds are 
     * in the first row.  The remaining columns and rows contain the real values of 
     * the probability thresholds for the boxes.
     *
     * @param data the input data
     * @param nV the null value
     * @return a box dataset
     */
    
    protected MetricResult getBox(DoubleMatrix2D data, double nV) {
        int count = ((BoxUnpooledObsPointsParameter)pars[0]).getParVal();
        
        double inc = 1.0/count;
        double[] pThresh = new double[count+1];
        for(int i = 0; i < count; i++) {
            pThresh[i+1] = (i+1)*inc;
        }
        
        //Obtain the forecasts
        int cols = data.getColumnCount();
        double[][] forecasts = ((DoubleMatrix2D)data.getSubmatrixByColumn(3,cols-1)).toArray();
        int fCount = forecasts.length;
        int eCount = forecasts[0].length;
        TreeMap<Double,double[]> res = new TreeMap();
        //Iterate through the forecast times
        int actualRows = 0;
        
        //Counts for the forecast index
        int[] countsn = new int[fCount];
        
        for(int i = 0; i < fCount; i++) {
            //Subtract the observation from each ensemble member
            double obs = data.get(i,2);
            if(obs != nV) {
                boolean addSamp = false;
                for(int j = 0; j < eCount; j++) {
                    if(forecasts[i][j] != nV) {
                        forecasts[i][j]=forecasts[i][j]-obs;
                        addSamp = true;
                    }
                }
                if(addSamp) {
                    //Construct the empirical cdf
                    double[][] computeMe = EmpiricalCDFCalculator.getEmpiricalCDF(forecasts[i],pThresh,nV,true,false,false);    
                    double[] result = new double[computeMe[1].length+1];
                    result[0] = obs;
                    System.arraycopy(computeMe[1],0,result,1,computeMe[1].length);
                    //Observation already exists
                    if(res.containsKey(obs)) {
                        double[] copy = res.get(obs);
                        if(copy.length == result.length) {
                            for(int j = 0; j < copy.length; j++) {
                                copy[j] = ((copy[j] * countsn[i]) + result[j])/(countsn[i]+1.0);
                            }
                        }
                    }
                    //Observation doesn't exist
                    else {
                        res.put(obs,result); 
                    }
                    actualRows++;
                    countsn[i]++;
                }
            }
        }
        
        if(actualRows == 0) {
            lastCount = ZERO_SAMPLES;
            throw new MetricCalculationException("Could not compute box for specified input.");
        }
        else {
            lastCount=actualRows;
        }
        //Construct the double result
        int size = res.size()+1;
        DenseDoubleMatrix2D returnMe = new DenseDoubleMatrix2D(size,res.get(res.firstKey()).length);
        //Add probabilities thresholds to first row, with null in place at observation position
        for(int k = 0; k < pThresh.length; k++) {
            returnMe.set(0,k+1,pThresh[k]);
        }
        returnMe.set(0,0,Metric.NULL_DATA);
        
        int tot = 1;
        for(Iterator i = res.keySet().iterator(); i.hasNext();) {
            double[] next = res.get(i.next());
            for(int j = 0; j < next.length; j++) {
                returnMe.set(tot,j,next[j]);
            }
            tot++;
        }
        return new DoubleMatrix2DResultForModBoxUBLO(returnMe);
    }    
    
}
