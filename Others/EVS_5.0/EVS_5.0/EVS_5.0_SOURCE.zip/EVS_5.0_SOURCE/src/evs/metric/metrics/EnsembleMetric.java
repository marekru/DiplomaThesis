package evs.metric.metrics;

/**
 * An interface identifying an ensemble verification metric.
 *
 * @author evs@hydrosolved.com
 */

public interface EnsembleMetric {


    
}
