package evs.metric.parameters;

//EVS dependencies
import evs.utilities.mathutil.DoubleProcedure;
import evs.utilities.mathutil.FunctionLibrary;
import evs.utilities.mathutil.EmpiricalCDFCalculator;
import evs.utilities.matrix.DoubleMatrix1D;

//Java util dependencies
import java.util.Arrays;

/**
 * Records a double procedure for applying a logical condition to a value.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DoubleProcedureParameter implements MetricParameter, Comparable {
    
    /********************************************************************************
     *                                                                              *
     *                               CLASS VARIABLES                                *
     *                                                                              *
     *******************************************************************************/         
    
    /**
     * Identifier for a less than condition to be used on a threshold in 
     * defining an event from continuous data. 
     */
    
    public static final int LESS_THAN = 101;
    
    /**
     * Identifier for a greater than condition to be used on a threshold in 
     * defining an event from continuous data. 
     */
    
    public static final int GREATER_THAN = 102;
    
    /**
     * Identifier for a less than or equal to condition to be used on a 
     * threshold in defining an event from continuous data. 
     */
    
    public static final int LESS_EQUAL = 103;
    
    /**
     * Identifier for a greater than or equal to condition to be used on a 
     * threshold in defining an event from continuous data. 
     */
    
    public static final int GREATER_EQUAL = 104;    
    
    /**
     * Identifier for a between condition to be used on a threshold in defining 
     * an event from continuous data.  The between condition is on the closed
     * interval [a,b].
     */
    
    public static final int BETWEEN = 105;        
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLE                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * The parameter value.
     */
    
    protected DoubleProcedure par;
    
    /**
     * Logical type.
     */
    
    private IntegerParameter type;
    
    /**
     * Threshold value(s).
     */
    
    private DoubleParameter[] value;    
    
    /**
     * Is true if the threshold(s) refer to probabilities.
     */
    
    private ProbabilityIdentifierParameter areProbs;

    /**
     * Is true if the threshold is a main threshold, false otherwise.
     */

    private BooleanParameter main;

    /**
     * Identifier to append to the string representation of the parameter after
     * a single space.
     */

    private StringParameter id = null;

    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     

    /**
     * Constructs an object with a specified type of logical condition and set of
     * double parameters.
     *
     * @param type the type of logical condition
     * @param value the value(s) to which the condition is applied
     * @param areProbs is true if the thresholds are probabilities
     * @param main is true if the threshold is a "main" threshold, false otherwise
     */
    
    public DoubleProcedureParameter(IntegerParameter type, DoubleParameter[] value,
            ProbabilityIdentifierParameter areProbs, BooleanParameter main) {
        //Check the input
        if(type == null) {
            throw new IllegalArgumentException("Specify a non-null logical type identifier.");
        }
        if(areProbs==null) {
            throw new IllegalArgumentException("Specify a non-null probability identifier parameter.");
        }
        if(main==null) {
            throw new IllegalArgumentException("Indicate whether the threshold is a 'main' threshold using a non-null identifier.");
        }
        for (DoubleParameter v : value) {
            if(v==null) {
                throw new IllegalArgumentException("One or more thresholds were null on construction of the "+getClass().getSimpleName()+".");
            }
            if (v.getID() == v.DOUBLE_PARAMETER && areProbs.getParVal() ||
                    v.getID()==v.PROBABILITY_PARAMETER && !areProbs.getParVal()) {
                throw new IllegalArgumentException("The thresholds input for construction of the "+getClass().getSimpleName()+" are not " +
                    "consistent with the probability identifier ["+areProbs+"].");
            }
        }
        Arrays.sort(value);  //Make sure the parameters are sorted in the case of a between condition
        switch(type.getParVal()) {
            case LESS_THAN: {
                par = FunctionLibrary.isLess(value[0].getParVal());
            }; break;
            case GREATER_THAN: {
                par = FunctionLibrary.isGreater(value[0].getParVal());
            }; break;
            case LESS_EQUAL: {
                par = FunctionLibrary.isLessEqual(value[0].getParVal());
            }; break;
            case GREATER_EQUAL: {
                par = FunctionLibrary.isGreaterEqual(value[0].getParVal());
            }; break;
            case BETWEEN: {
                par = FunctionLibrary.isBetween(value[0].getParVal(),value[1].getParVal());
            }; break;
            default: {
                throw new IllegalArgumentException("Unrecognized logical condition identifier.");
            }
        }
        if(areProbs.isTrue) {
            for(int i = 0; i < value.length; i++) {
                if(!Double.isInfinite(value[i].getParVal()) && (value[i].getParVal() < 0.0 || value[i].getParVal()>1.0)) {
                    throw new IllegalArgumentException("Probabilities must lie within the range 0.0-1.0.");
                }
            }
        }
        this.type = (IntegerParameter)type.deepCopy();
        this.value = new DoubleParameter[value.length];
        for (int i = 0; i < value.length; i++) {
            this.value[i] = (DoubleParameter) value[i].deepCopy();
        }
        this.areProbs = (ProbabilityIdentifierParameter)areProbs.deepCopy();
        this.main = (BooleanParameter)main.deepCopy();
    }

    /**
     * Constructs an object with a specified type of logical condition and set of
     * double parameters.
     *
     * @param type the type of logical condition
     * @param value the value(s) to which the condition is applied
     * @param areProbs is true if the thresholds are probabilities
     * @param main is true if the threshold is a "main" threshold, false otherwise
     * @param id an identifier to append to the string representation
     */

    public DoubleProcedureParameter(IntegerParameter type, DoubleParameter[] value,
            ProbabilityIdentifierParameter areProbs, BooleanParameter main, StringParameter id) {
        this(type,value,areProbs,main);
        if(id==null) {
            throw new IllegalArgumentException("Specifiy a non-null string identifier.");
        }
        this.id=id;
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Return an identifier for the parameter from the list in evs.metric.parameters.MetricParameter.
     * Remember to override in any subclass.
     *
     * @return an identifier
     */
    
    public int getID() {
        return DOUBLE_PROCEDURE_PARAMETER;
    }    
    
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "double_proc_parameter";
    }       
    
    /**
     * Returns the parameter value.
     *
     * @return the parameter value
     */
    
    public DoubleProcedure getParVal() {
        return par;
    }    
    
    /**
     * Gets the real-valued equivalent of a probability threshold or returns
     * the real-value of the double threshold.
     * 
     * @return the real-valued parameter
     */
    
    public DoubleProcedure getParValReal() {
        DoubleParameter[] p = getThresholdValues();
        if(p[0] instanceof ProbabilityParameter) {
            p = getRealValuesForProbs();        
        }
        ProbabilityIdentifierParameter pt = new ProbabilityIdentifierParameter(false);
        return new DoubleProcedureParameter(type,p,pt,main).getParVal();
    }
    
    /**
     * Returns the type of logical condition.
     *
     * @return the type of condition
     */
    
    public IntegerParameter getThresholdType() {
        return type;
    }    
    
    /**
     * Returns the threshold value applied to the condition.
     *
     * @return the threshold value
     */
    
    public DoubleParameter[] getThresholdValues() {
        return value;
    }

    /**
     * Returns true if the threshold is a "main" threshold.
     *
     * @return true if the thresholds is a "main" threshold, false otherwise
     */

    public BooleanParameter isMainThreshold() {
        return main;
    }

    /**
     * Returns true if real-values are available for the real-valued threshold or
     * for the probability thresholds, false otherwise (i.e. if probability thresholds
     * are defined and the corresponding real values have not been set).
     *
     * @return true if the threshold is available in real-values, false otherwise
     */

    public boolean hasRealValuesSet() {
        if(!areProbs.getParVal()) {
            return true;
        }
        return ((ProbabilityParameter)value[0]).hasRealValueForProb();
    }

    /**
     * Returns an equivalent parameter defined for real-values (using the specified 
     * climate CDF to determine probabilities) if the current parameter is defined for 
     * probabilities.  Otherwise returns the same parameter.  Throws an exception
     * if real values are required and the input contains fewer than two samples
     * from which to determine the real-values. 
     * 
     * @param climateCDF the climatology CDF from which to determine real values
     * @param nV a null value to ignore
     * @return an equivalent parameter defined for real-values
     */
    
    public DoubleProcedureParameter getRealValuedEquivalent(double[][] climateCDF, double nV) {
        //Copy of current thresholds
        DoubleParameter[] rv = new DoubleParameter[value.length];  //JB@29th October 2012
        for (int i = 0; i < rv.length; i++) {          
            rv[i] = new DoubleParameter(value[i].getParVal());
        }
        if(!areProbs.isTrue) {
            return new DoubleProcedureParameter(getThresholdType(),rv,   //JB@29th October 2012
                    new ProbabilityIdentifierParameter(areProbs.isTrue), new BooleanParameter(main.isTrue));
        }
        DoubleProcedureParameter pro = null;        
        if(Double.isInfinite(value[0].getParVal())) {
            return new DoubleProcedureParameter(getThresholdType(),rv,    //JB@29th October 2012
                    new ProbabilityIdentifierParameter(false), new BooleanParameter(main.isTrue));
        }
        if(climateCDF == null) {
            throw new IllegalArgumentException("Found unrecognized format for the empirical CDF when attempting to "
                    + "determine the real-values corresponding to the given climatologies probabilities.");
        }        
        if(climateCDF.length!=2) {
            throw new IllegalArgumentException("Found unrecognized format for the empirical CDF when attempting to "
                    + "determine the real-values corresponding to the given climatologies probabilities.");
        }
        if(climateCDF[1].length < 2) {
            throw new IllegalArgumentException("Cannot determine the real values for the required probability '"+pro+"', "
                    + "as there is insufficient sample data from which to determine the values (at least two samples needed).");
        }
        double probBar = value[0].getParVal();
        double probBar2 = -999;
        if(value.length == 2) {
            probBar2 = value[1].getParVal();
        }
        
        //Thresholds are probabilities
        ProbabilityIdentifierParameter prob = new ProbabilityIdentifierParameter(false);
        probBar = EmpiricalCDFCalculator.getValFromCDF(climateCDF, probBar);
        if (value.length == 1) {
            pro = new DoubleProcedureParameter(getThresholdType(), new DoubleParameter[]{new DoubleParameter(probBar)}, prob, main);
        } //Between condition
        else if (value.length == 2) {
            probBar2 = EmpiricalCDFCalculator.getValFromCDF(climateCDF, probBar2);
            pro = new DoubleProcedureParameter(getThresholdType(), new DoubleParameter[]{new DoubleParameter(probBar), new DoubleParameter(probBar2)}, prob, main);
        }
        return pro;                
    }
    
    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricParameter deepCopy() {
        if(id!=null) {
            return new DoubleProcedureParameter(type,value,areProbs,main,id);
        }
        return new DoubleProcedureParameter(type,value,areProbs,main);
    }     
    
    /**
     * Override equals.  
     *
     * @param o the object to test against the current object
     * @return true if the objects are equal
     */
    
    public boolean equals(Object o) {
        if (o != null) {
            try {
                return this.compareTo(o) == 0;
            } catch (Exception e) {
                return false;
            }
        }
        return false;
    }
    
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        assert false : "hashCode not implemented for MetricParameter.";
        return 1;
    }    
    
    /**
     * Returns true if the double procedures are defined for probability values,
     * false otherwise.
     * 
     * @return true if the double procedures are based on probabilities.
     */
    
    public ProbabilityIdentifierParameter areProbs() {
        return areProbs;
    }

    /**
     * Returns an identifier appended to the string representation of the parameter
     * after a single space.
     *
     * @return the string identifier
     */

    public StringParameter getStringID() {
        return id;
    }

    /**
     * Returns true if a string id has been set for the parameter, false otherwise
     *
     * @return true if a string id has been set, otherwise false.
     */

    public boolean hasStringID() {
        return id!=null;
    }

   /**
     * Returns the real values for a probability procedure or throws an exception if
     * the current procedure does not refer to probability values.
     * 
     * @return the real values for the probability thresholds
     */
    
    public DoubleParameter[] getRealValuesForProbs() throws IllegalArgumentException {
        if(!areProbs.getParVal()) {
            throw new IllegalArgumentException("Cannot return real-values for the threshold, as it is not a probability threshold.");
        }
        if(!hasRealValuesSet()) {
            throw new IllegalArgumentException("Real-values have not been set for the probability threshold.");
        }
        DoubleParameter[] returnMe = new DoubleParameter[value.length];
        for(int i = 0; i < value.length; i++) {
            returnMe[i]=((ProbabilityParameter)value[i]).getRealValForProb();
        }
        return returnMe;
    }    
    
    /**
     * Returns a negative integer if the current object is less than the input
     * object, zero if they are equal and a positive integer if the current 
     * object is greater than the input object.  Throws an exception if the 
     * class of the input object is unexpected.  Uses the lower threshold on a
     * between condition.
     *
     * @param o the object to compare
     */
    
    public int compareTo(Object o) {
        DoubleProcedureParameter p = (DoubleProcedureParameter)o;
        if(p.type.getParVal() != type.getParVal()) {
            throw new IllegalArgumentException("Invalid comparison on metric type.");
        }
        if(p.value.length != value.length) {
            throw new IllegalArgumentException("Invalid comparison: different number of parameters in objects.");
        }        
        int returnMe = 0;
        for(int i = 0; i < value.length; i++) {
            double input = p.getThresholdValues()[i].getParVal();
            double here = value[i].getParVal();
            if(input<here) {
                returnMe = 1; break;
            }
            else if(input > here) {
                returnMe=-1; break;
            }
        }
        //Equal threshold
        if(returnMe==0) {
            if(p.isMainThreshold().getParVal()!=isMainThreshold().getParVal()) {
                if(p.isMainThreshold().getParVal()) {  //Input is true, mark the input as "larger"
                    returnMe = 1;
                }
                else {
                    returnMe = -1;
                }
            }
        }
        return returnMe;
    }
    
    /**
     * Returns a string representation of the receiver.
     *
     * @return a string representation
     */
    
    public String toString() {
        String append = "";
        if(id!=null && id.hasNonNullString()) {
            append=" "+id;
        }
        if(Double.isInfinite(value[0].getParVal())) {
            return "All data"+append;
        }
        String pre = "";
        switch(type.getParVal()) {
            case LESS_THAN: {
                pre = " <";
            }; break;
            case GREATER_THAN: {
                pre = " >";
            }; break;
            case LESS_EQUAL: {
                pre = " <=";
            }; break;
            case GREATER_EQUAL: {
                pre = " >=";
            }; break;
        }       
        if(type.getParVal()==BETWEEN) {
            return ">= "+value[0]+" & <= " +value[1]+append;
        }
        else {    
            return pre+" "+value[0]+append;
        }
    }
    
    /**
     * Returns a string representation of the receiver for writing in XML
     *
     * @return a string representation
     */
    
    public String toXMLString() {
        String append = "";
        if(id!=null && id.hasNonNullString()) {
            append=" "+id;
        }
        if(Double.isInfinite(value[0].getParVal())) {
            return "All data"+append;
        }
        String pre = "";
        switch(type.getParVal()) {
            case LESS_THAN: {
                pre = "LT";
            }; break;
            case GREATER_THAN: {
                pre = "GT";
            }; break;
            case LESS_EQUAL: {
                pre = "LTE";
            }; break;
            case GREATER_EQUAL: {
                pre = "GTE";
            }; break;
        }       
        if(type.getParVal()==BETWEEN) {
            return "GTE "+value[0]+" & LTE " +value[1]+append;
        }
        else {    
            return pre+" "+value[0]+append;
        }
    }    
    
    /********************************************************************************
     *                                                                              *
     *                               MUTATOR METHOD                                 *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Sets the real values for the probability procedure or throws an exception if
     * the current procedure does not refer to probability values.
     * 
     * @param rV the real values
     */
    
    public void setRealValuesForProbs(DoubleParameter[] rV) throws IllegalArgumentException {
        if(!areProbs.getParVal()) {
            throw new IllegalArgumentException("Cannot set real-values for the threshold, as it is not a probability threshold.");
        }
        if(rV.length != value.length) {
            throw new IllegalArgumentException("Number of real values for probability threshold does not match number of probability values.");
        }
        ((ProbabilityParameter)value[0]).setRealValForProb(rV[0]);
        if(rV.length==2) {
            ((ProbabilityParameter)value[1]).setRealValForProb(rV[1]);
        }
    }

    /**
     * Sets an identifier to append to the string representation. The identifier
     * is appended with a single space.
     *
     * @param id the string identifier to append
     */

    public void setStringID(StringParameter id) {
        if(id==null) {
            throw new IllegalArgumentException("Specify a non-null string to append "
                    + "to the '"+getClass().getSimpleName()+"'.");
        }
        this.id=id;
    }

}
