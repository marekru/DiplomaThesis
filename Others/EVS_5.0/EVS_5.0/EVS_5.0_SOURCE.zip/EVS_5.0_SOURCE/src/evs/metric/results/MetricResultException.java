package evs.metric.results;

import evs.metric.metrics.*;

/**
 * Class for throwing exceptions that signify an error in using the metric results.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class MetricResultException extends MetricCalculationException {
    
    /**
     * Constructs an MetricResultException with no message.
     */
    
    public MetricResultException() {
        super();
    }

    /**
     * Constructs an MetricResultException with the specified message. 
     * 
     * 
     * @param s the message.
     */
    
    public MetricResultException(String s) {
	super(s);
    }
}
