package evs.metric.parameters;

/**
 * Records an integer parameter for a verification metric.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class IntegerParameter implements MetricParameter {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLE                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * The parameter value.
     */
    
    protected int par;
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     

    /**
     * Constructs an object with an integer parameter value
     *
     * @param par the parameter value
     */
    
    public IntegerParameter(int par) { 
        this.par = par;
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     * Remember to override in any subclass.
     *
     * @return an identifier
     */
    
    public int getID() {
        return INTEGER_PARAMETER;
    }    
    
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "integer_parameter";
    }       
    
    /**
     * Returns the parameter value.
     *
     * @return the parameter value
     */
    
    public int getParVal() {
        return par;
    }    
    
    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricParameter deepCopy() {
        return new IntegerParameter(par);
    }     
    
    /**
     * Override equals.  
     *
     * @param o the object to test against the current object
     * @return true if the objects are equal
     */
    
    public boolean equals(Object o) {
        if(o==null) {
            return false;
        }
        return o.getClass().equals(this.getClass())
                && ((IntegerParameter)o).par == par;
    }    
    
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        assert false : "hashCode not implemented for MetricParameter.";
        return 1;
    }    
    
    /**
     * Returns a string representation of the receiver.
     *
     * @return a string representation
     */
    
    public String toString() {
        return par+"";
    }
        
}
