package evs.metric.metrics;

//EVS dependencies
import evs.data.*;
import evs.metric.parameters.*;
import evs.metric.results.*;
import evs.utilities.*;
import evs.utilities.matrix.*;
import evs.utilities.mathutil.*;


/**
 * The Mean CRPS skill score measures skill in terms of the Mean CRPS (MCRPS) and is 
 * given by:
 * 
 * (MCRPS of forecast system - MCRPS of reference forecast system)/(0 - MCRPS of 
 * reference forecast system).
 * 
 * Where 0 represents the MCRPS of the perfect forecasting system.
 *
 * @author evs@hydrosolved.com
 * @version 4.0 
 */

public class MeanContRankProbSkillScore extends MeanContRankProbScore implements SkillScore, 
        EnsembleMetric, ThresholdMetric, DecomposableScore, BootstrapableMetric {

    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Attempts to construct a MCRPSS object with a specified event threshold for 
     * continuous forecasts, an indicator for whether decomposition is required 
     * and the forecast types for which the score is required.
     *
     * @param event the event mark
     * @param decompose the decomposition indicator
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use conditional 
     * pairs when available
     * @param ref the reference forecasts used in the skill calculation
     * @param minS the minimum sample size
     * @param bs the bootstrap parameter
     */
    
    public MeanContRankProbSkillScore(DoubleProcedureParameter event,DecomposeParameter decompose,
            ForecastTypeParameter fType, UnconditionalParameter unconditional,
            ReferenceForecastParameter ref,MinimumSampleSizeParameter minS,BootstrapParameter bs) {
        super(event,decompose,fType,unconditional,minS,bs);
        //Add an empty reference forecast paramater
        MetricParameter[] pars = new MetricParameter[this.pars.length+1];
        System.arraycopy(this.pars,0,pars,0,this.pars.length);
        pars[pars.length-1]=ref.deepCopy();
        this.pars=pars;
        //Set the name
        name = "Mean continuous ranked probability skill score";
        descriptionURL = getClass().getResource(EVSConstants.STATS_EXPLAINED_DIR + "mcrpss.htm");
    }    

    /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/        
    
    /**
     * Returns the metric identifier.
     *
     * @return an identifier
     */
    
    public int getID() {
        return CRPS_SKILL_SCORE;
    }

    /**
     * Returns the name of the base metric for which the skill calculation is  
     * computed.
     * 
     * @return the base metric name
     */
    
    public String getBaseMetricName() {
        return super.getName();
    }
    
    /**
     * Returns the type of decomposition required. One of:
     * 
     * DecomposableScore.CALIBRATION_REFINEMENT
     * DecomposableScore.LIKELIHOOD_BASE_RATE
     * DecomposableScore.CR_AND_LBR
     * DecomposableScore.NONE  
     * 
     * @return the type of decomposition
     */
    
    public int getScoreDecType() {
        return ((DecomposeParameter)pars[1]).getScoreDecType();
    }        
    
    /**
     * Returns an array of integer decompositions that have been implemented. 
     * Each int is one of:
     * 
     * DecomposableScore.CALIBRATION_REFINEMENT
     * DecomposableScore.LIKELIHOOD_BASE_RATE
     * DecomposableScore.CR_AND_LBR
     * DecomposableScore.NONE.  
     * 
     * @return an array of implemented decompositions.
     */
    @Override
    public int[] getDecompositionOptions() {
        return new int[] {
            DecomposableScore.NONE,
            DecomposableScore.CALIBRATION_REFINEMENT,
        };
    }      
    
    /**
     * Returns a deep copy of the current metric, where all instance variables 
     * occupy independent positions in memory from the current metric.  
     *
     * @return a deep copy of the current object 
     */
    
    public Metric deepCopy() {
        MeanContRankProbSkillScore returnMe = new MeanContRankProbSkillScore(
                (DoubleProcedureParameter)pars[0].deepCopy(),
                (DecomposeParameter)pars[1].deepCopy(),
                (ForecastTypeParameter)pars[2].deepCopy(),
                (UnconditionalParameter)pars[3].deepCopy(),
                (ReferenceForecastParameter)pars[6].deepCopy(),
                (MinimumSampleSizeParameter)pars[4].deepCopy(),
                getBootstrapPar());
        deepCopyResults(returnMe);
        return returnMe;
    }
    
    /**
     * Returns a reference forecast parameter.
     * 
     * @return the reference forecasts
     */
    
    public ReferenceForecastParameter getRefFcst() throws IllegalArgumentException {
        return (ReferenceForecastParameter)getParameter(MetricParameter.REFERENCE_FORECAST_PARAMETER); 
    }    
    
    /**
     * Returns true if the skill score has a default reference forecast.
     * 
     * @return true if the skill score has a default reference forecasts.
     */
    
    public boolean hasDefaultRefFcst() {
        return getRefFcst().hasRefForecast();
    }

    /**
     * Returns any default reference forecast implemented for the skill score,
     * such as sample climatology.
     *
     * @return the default reference forecasts
     */

    public ReferenceForecastParameter getDefaultRefFcst() throws IllegalArgumentException {
        ReferenceForecastParameter r = new ReferenceForecastParameter();
        r.setRefForecast(ForecastTypeParameter.SAMPLE_CLIMATOLOGY_STRING);
        return r;
    }

    /**
     * Returns the bootstrap parameter associated with the verification metric.
     *
     * @return the bootstrap parameter
     */
    @Override
    public BootstrapParameter getBootstrapPar() {
        return (BootstrapParameter)pars[5].deepCopy();
    }
    
    /**
     * Returns a metric with default parameter values.  
     *
     * @return a metric with default parameter values.
     */
    
    public static Metric getDefaultMetric() { 
        ProbabilityIdentifierParameter prob =new ProbabilityIdentifierParameter(true);
        DoubleProcedureParameter eT = new DoubleProcedureParameter(new IntegerParameter(DoubleProcedureParameter.GREATER_THAN),
                new DoubleParameter[]{new ProbabilityParameter(0.0)},prob,new BooleanParameter(true));
        ForecastTypeParameter type = new ForecastTypeParameter(new int[]{ForecastTypeParameter.REGULAR_FORECAST});
        MeanContRankProbSkillScore s = new MeanContRankProbSkillScore(eT,new DecomposeParameter(false),
                type,new UnconditionalParameter(false),
                new ReferenceForecastParameter(),new MinimumSampleSizeParameter(),new BootstrapParameter());
        ReferenceForecastParameter r = s.getDefaultRefFcst();
        s.pars[6]=r;
        return s;
    }   
    
    /********************************************************************************
     *                                                                              *
     *                               MUTATOR METHODS                                *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Uses the specified paired data to compute and return the result of the metric.
     * The metric results are returned, together with the sample counts, but not stored 
     * locally.  The metric result is located in the first index of the return array
     * and the sample counts are located in the second index. Optionally, specify
     * the results of a reference forecast from which to compute skill if the 
     * metric is a skill score.
     *
     * If the reference forecast is sample climatology, only those pairs used in the
     * numerator of the skill score will be used in the reference.  If the reference
     * forecast is not sample climatology and the Hersbach technique is used, the
     * reference is computed from only those pairs without missing members so that
     * the reference contains the same paired data as the numerator in the
     * skill calculation.
     * 
     * @param forecastType the forecast type
     * @param paired the paired data
     * @param refResult the results for a reference forecast (may be null)
     * @return the metric result and sample counts
     */
    
    public MetricResult[] compute(int forecastType, PairedData paired, MetricResult refResult) throws MetricCalculationException {
        if(paired==null) {
            throw new MetricCalculationException("Error computing metric '"+getName()+"': input pairs were null.");
        }
        boolean sampleClimatology = getRefFcst().hasRefForecast(ForecastTypeParameter.SAMPLE_CLIMATOLOGY_STRING);
        //Skill calculation requested: need reference forecast or sample climatology
        if (forecastType == ForecastTypeParameter.REGULAR_FORECAST && !sampleClimatology) {
            if(refResult==null) {
                throw new IllegalArgumentException("Expected a non-null reference forecast result from which to compute the " + getName() + ".");
            }
            if(!(refResult instanceof EnsembleScoreDecomposition)) {
                throw new MetricCalculationException("Expected a reference forecast result of type " + EnsembleScoreDecomposition.class.getName() + ": " + refResult.getClass().getName());
            }
        }
        double nV = paired.getNullValue();
        //Add the skill score results if results exist for a reference forecast
        MetricResult[] result = null;
        if (forecastType == ForecastTypeParameter.REFERENCE_FORECAST) {
            result = super.compute(forecastType, paired, null);
        } else if (forecastType == ForecastTypeParameter.REGULAR_FORECAST) {
//            try {
                result = new MetricResult[2];
                MetricResult[] num = super.compute(forecastType, paired, refResult);
                EnsembleScoreDecomposition nextNum = (EnsembleScoreDecomposition) num[0];
                EnsembleScoreDecomposition nextDen = null;
                //Compute mean CRPS for climatology
                //Compute with the same number of members as the forecast, and if any members are missing,
                //eliminate the corresponding member of the climatological distribution.
                //When using the Hersbach technique, compute the climatological forecast from those
                //observations whose corresponding forecasts contain no non-null members.
                if (sampleClimatology) {
                    DoubleMatrix2D pairs = (DoubleMatrix2D) paired.getPairs();
                    DoubleMatrix1D climObs = (DoubleMatrix1D) pairs.getColumnAt(2);
                    if (MeanContRankProbScore.getMethod() == MeanContRankProbScore.HERSBACH) {
                        climObs = (DoubleMatrix1D) PairedData.getStrippedPairs((DoubleMatrix2D) pairs.getSubmatrixByColumn(2,
                                pairs.getColumnCount() - 1), false, nV, 0).getColumnAt(0);
                    }
                    //Compute the climatological probability forecast with the required number of members
                    int mem = pairs.getColumnCount() - 3;
//        try {                    
                    //Single-valued forecast
                    if(mem==1) {
                        //Experiment to test for conditional sample, but should use unconditional sample in practice
                        //for consistency with how climatology is defined elsewhere, i.e. not conditional climatology
//                        final DoubleProcedure pro = getThreshold().getParValReal();
//                        DoubleMatrix2D p = getConditionalPairs(pro, pairs);
//                        DoubleMatrix1D climObsCond = (DoubleMatrix1D)p.getColumnAt(2);
                        
                        //Compute the mean absolute difference between every sample and every other sample
                        //in the climatological array
                        double totDiff = 0.0;
                        int size = climObs.getRowCount();
                        for(int i = 0; i < size; i++) {
                            for(int j = 0; j < size; j++) {
                                totDiff+=Math.abs(climObs.get(i)-climObs.get(j));
                            }
                        }
                        double mae = totDiff/(size*size);
                        if (nextNum.getDecTemplate() == CALIBRATION_REFINEMENT) {
                            nextDen = new EnsembleScoreDecomposition(nextNum.getDecTemplate(),
                                    new DenseDoubleMatrix1D(new double[]{mae,
                                        Metric.NULL_DATA,Metric.NULL_DATA,Metric.NULL_DATA,Metric.NULL_DATA}));
                        } else {
                            nextDen = new EnsembleScoreDecomposition(nextNum.getDecTemplate(),
                                    new DenseDoubleMatrix1D(new double[]{mae}));
                        }
                    }
                    //Ensemble
                    else {
                        //Use regular thresholds
                        double[] t = new double[mem];
                        for (int i = 0; i < mem; i++) {
                            t[i] = (i + 1) / (double) mem;
                        }
                        double[] cf = EmpiricalCDFCalculator.getEmpiricalCDF(climObs.toArray(), t,
                                nV, true, false, false)[1];
                        DoubleMatrix2D copy = (DoubleMatrix2D)pairs.deepCopy(); //Copy pairs for replacement inline
                        double[][] vals = copy.toArray();  
                        for (int i = 0; i < vals.length; i++) {
                            for (int j = 3; j < vals[i].length; j++) {
                                if (vals[i][j] != nV) {
                                    vals[i][j] = cf[j - 3];
                                }
                            }
                        }
                        //Compute the CRPS from the climatological ensemble
                        PairedData in = new PairedData(copy, false, nV);
                        nextDen = ((EnsembleScoreDecomposition) super.compute(forecastType, in, null)[0]);
                    }
                } else {
                    nextDen = (EnsembleScoreDecomposition) refResult;
                }
                //Compute skill
                double overallNum = nextNum.getComponent(OVERALL_SCORE).getResult();
                double overallDen = nextDen.getComponent(OVERALL_SCORE).getResult();
                double skill = 1.0 - (overallNum / overallDen);
                if (Double.isInfinite(skill) || Double.isNaN(skill)) {
                    skill = Metric.NULL_DATA;
                }
                if (nextNum.getDecTemplate() == CALIBRATION_REFINEMENT) {
                    double rel = Metric.NULL_DATA;
                    double res = Metric.NULL_DATA;
                    double unc = Metric.NULL_DATA;
                    double pot = Metric.NULL_DATA;
                    double relNum = nextNum.getComponent(RELIABILITY).getResult();
                    double resNum = nextNum.getComponent(RESOLUTION).getResult();
                    double potNum = nextNum.getComponent(POTENTIAL).getResult();
                    double uncNum = nextNum.getComponent(UNCERTAINTY).getResult();
                    //Proceed if components are not null
                    if (relNum != Metric.NULL_DATA && resNum != Metric.NULL_DATA
                            && uncNum != Metric.NULL_DATA) {
                        rel = relNum / overallDen;
                        res = resNum / overallDen;
                        unc = uncNum / overallDen;
                        pot = 1.0 - (potNum / overallDen);
                        if (skill == Metric.NULL_DATA) {
                            rel = Metric.NULL_DATA;
                            res = Metric.NULL_DATA;
                        }
                    }
                    result[0] = new EnsembleScoreDecomposition(CALIBRATION_REFINEMENT,
                            new DenseDoubleMatrix1D(new double[]{skill, rel, res, unc, pot}));
                } else {
                    result[0] = new EnsembleScoreDecomposition(NONE,
                            new DenseDoubleMatrix1D(new double[]{skill}));
                }
                result[1] = num[1].deepCopy();
//            } catch (Exception e) {
//                //e.printStackTrace();
//            }
        }
        return result;
    }

    /**
     * Sets the bootstrap parameter associated with the verification metric or
     * clears the parameter if the input is null;
     *
     * @param bs the bootstrap parameter
     */
    @Override
    public void setBootstrapPar(BootstrapParameter bs) {
        if(bs==null) {
            throw new IllegalArgumentException("The bootstrap parameter for metric '"+this+"' cannot be null.");
        } else {
            pars[5] = (BootstrapParameter)bs.deepCopy();
        }
    }

    /**
     * Sets the bootstrap parameter to BootstrapableMetric.NO_BOOTSTRAP and clears
     * all associated parameter values.
     */
    @Override
    public void clearBootstrapPar() {
        ((BootstrapParameter)pars[5]).clear();
    }

}
    