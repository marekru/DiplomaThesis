package evs.metric.metrics;

//EVS dependencies
import evs.metric.parameters.*;
import evs.metric.results.*;
import evs.utilities.*;
import evs.utilities.mathutil.*;
import evs.utilities.matrix.*;

//Java util dependencies
import java.util.Arrays;

/**
 * Constructs a modified box-and-whisker plot with a set of thresholds.  The boxes
 * represent the empirical pdf of errors for the forecasts, pooled by lead time. 
 * 
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ModifiedBoxPlotPooledByLead extends ModifiedBoxPlot {

    /********************************************************************************
     *                                                                              *
     *                                  VARIABLES                                   *
     *                                                                              *
     *******************************************************************************/     

    /**
     * Default number of points to include in a ROC diagram.
     */
    
    private static BoxPooledLeadPointsParameter defPCount = new BoxPooledLeadPointsParameter(10);    
        
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/      
      
    /**
     * Attempts to construct a modified box plot with a set of thresholds and a
     * parameter indicating the forecast types for which the box plots will be 
     * constructed.
     *
     * @param points the number of thresholds to include
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use 
     * conditional pairs when available
     */
    
    public ModifiedBoxPlotPooledByLead(BoxPooledLeadPointsParameter points, ForecastTypeParameter fType, UnconditionalParameter unconditional) {
        //Set the name
        name = "Modified box plot pooled by lead time";
        //Set the parameters
        setParameters(new MetricParameter[]{points,fType,unconditional});
        //Set the link to html description of the metric
        descriptionURL = getClass().getResource(EVSConstants.STATS_EXPLAINED_DIR + "box.htm");
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/      
  
    /**
     * Returns the metric identifier.
     *
     * @return an identifier
     */
    
    public int getID() {
        return BOX_DIAGRAM_POOLED_BY_LEAD;
    }      
    
    /**
     * Returns the result type associated with the metric.  See the 
     * evs.metric.MetricResult class for supported types.
     *
     * @return an identifier
     */
    
    public int getResultID() {
        return MetricResult.DOUBLE_MATRIX_2D_RESULT;
    }      
    
    /**
     * Returns true if the metric is defined in real units of the forecast
     * and observed variable, false otherwise.
     * 
     * @return true if the metric is defined in real units
     */    

    public boolean hasRealUnits() {
        return true;
    }       
    
    /**
     * Returns a deep copy of the current metric, where all instance variables 
     * occupy independent positions in memory from the current metric.  
     *
     * @return a deep copy of the current object 
     */
    
    public Metric deepCopy() {
        ModifiedBoxPlotPooledByLead returnMe = new ModifiedBoxPlotPooledByLead((BoxPooledLeadPointsParameter)pars[0].deepCopy(),(ForecastTypeParameter)pars[1].deepCopy(),(UnconditionalParameter)pars[2].deepCopy());
        deepCopyResults(returnMe);
        return returnMe;
    }    
    
    /**
     * Returns the default point count.  
     *
     * @return the default point count
     */
    
    public static PositiveIntegerParameter getDefaultPointCount() {
        return (PositiveIntegerParameter)defPCount.deepCopy();
    }    
    
    /**
     * Returns a metric with default parameter values.  
     *
     * @return a metric with default parameter values.
     */
    
    public static Metric getDefaultMetric() { 
        ForecastTypeParameter type = new ForecastTypeParameter(new int[]{ForecastTypeParameter.REGULAR_FORECAST});
        return new ModifiedBoxPlotPooledByLead(defPCount,type,new UnconditionalParameter(false)); 
    }     

    /********************************************************************************
     *                                                                              *
     *                              PROTECTED METHODS                               *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Returns a box dataset from an input dataset, pooling by lead time.
     *
     * @param data the input data
     * @param nV the null value
     * @return a box dataset
     */
    
    protected MetricResult getBox(DoubleMatrix2D data, double nV) {
        data = (DoubleMatrix2D)data.getSubmatrixByColumn(2,data.getColumnCount()-1);
        int count = ((BoxPooledLeadPointsParameter)pars[0]).getParVal();
        
        double inc = 1.0/count;
        double[] pThresh = new double[count+1];
        for(int i = 0; i < count; i++) {
            pThresh[i+1] = (i+1)*inc;
        }
        
        double[][] computeMe = null;

        //Obtain the forecasts
        int cols = data.getColumnCount();
        double[][] forecasts = ((DoubleMatrix2D)data.getSubmatrixByColumn(1,cols-1)).toArray();
        int fCount = forecasts.length;
        int eCount = forecasts[0].length;
        
        double[] errors = new double[fCount*eCount];
        Arrays.fill(errors,Metric.NULL_DATA);  //Fill with nulls
        
        //Iterate through the forecast times
        int tot = 0;
        int actualRows = 0;
        for(int i = 0; i < fCount; i++) {
            //Subtract the observation from each ensemble member
            double obs = data.get(i,0);
            if(obs != nV) {
                boolean addSamp = false;
                for(int j = 0; j < eCount; j++) {
                    if(forecasts[i][j] != nV) {
                        errors[tot] = forecasts[i][j]-obs;
                        tot++;
                        addSamp = true;
                    }
                }
                if(addSamp) {
                    actualRows++;
                }
            }
        }
        
        if(actualRows != 0) {
            lastCount=actualRows;
        }
        else {
            lastCount = ZERO_SAMPLES;
        }
        
        //Compute the empirical cdf of errors
        computeMe = EmpiricalCDFCalculator.getEmpiricalCDF(errors,pThresh,nV,true,false,false);
        
        //Convert to probabilities
        if(computeMe == null) {
            throw new MetricCalculationException("Could not compute box for specified input.");
        }
        return new DoubleMatrix2DResult(new DenseDoubleMatrix2D(computeMe));
    }    
    
}
