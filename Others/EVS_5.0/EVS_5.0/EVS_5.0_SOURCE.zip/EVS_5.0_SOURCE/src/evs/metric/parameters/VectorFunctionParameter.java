package evs.metric.parameters;
import evs.utilities.mathutil.VectorFunction;

/**
 * Wrapper for using a vector function as a parameter.
 *
 * @author evs@hydrosolved.com
 */

public class VectorFunctionParameter implements MetricParameter {

    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLE                               *
     *                                                                              *
     *******************************************************************************/

    /**
     * The vector function.
     */

    private VectorFunction func = null;

    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/

    /**
     * Constructs an object with a vector function
     *
     * @param func the parameter value
     */

    public VectorFunctionParameter(VectorFunction func) {
        this.func = func;
    }

    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/

    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     * Remember to override in any subclass.
     *
     * @return an identifier
     */
    
    public int getID() {
        return VECTOR_FUNCTION_PARAMETER;
    }

    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */

    public String getName() {
        return "vector_function_parameter";
    }

    /**
     * Returns the parameter value.
     *
     * @return the parameter value
     */

    public VectorFunction getParVal() {
        return func;
    }

    /**
     * Returns a deep copy of the current metric parameter, where all instance variables
     * occupy independent positions in memory from the current metric parameter.
     *
     * @return a deep copy of the current object
     */

    public MetricParameter deepCopy() {
        return new VectorFunctionParameter(func);
    }
    
    /**
     * Returns a string representation of the receiver.
     *
     * @return a string representation
     */

    public String toString() {
        return func.toString();
    }

    /**
     * Override equals.
     *
     * @param o the object to test against the current object
     * @return true if the objects are equal
     */

    public boolean equals(Object o) {
        boolean returnMe = o instanceof VectorFunctionParameter;
        if(returnMe) {
            returnMe=((VectorFunctionParameter)o).getParVal().equals(getParVal());
        }
        return returnMe;
    }
    
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        assert false : "hashCode not implemented for MetricParameter.";
        return 1;
    }    

}

