package evs.metric.results;

//EVS dependencies
import evs.utilities.matrix.*;
import evs.utilities.mathutil.*;
import evs.metric.metrics.*;
import evs.metric.parameters.*;

//Java dependencies
import java.util.*;

/**
 * Immutable wrapper class for a 1D double matrix that acts as a metric result.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DoubleMatrix1DResult extends MetricResult {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLE                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * The metric result.
     */
    
    protected DoubleMatrix1D result;
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs a metric result with a double matrix.
     *
     * @param result the metric result
     */
    
    public DoubleMatrix1DResult(DoubleMatrix1D result) {
        if(result == null) {
            throw new IllegalArgumentException("Expected non-null data for the results store.");
        }
        this.result = result;
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Returns the type of result.  
     *
     * @return the type of result
     */
    
    public int getID() {
        return DOUBLE_MATRIX_1D_RESULT;
    } 
    
     /**
     * Applies an aggregation function to the corresponding values (e.g. same 
     * matrix position) in the input results, placing a Metric.NULL_DATA if all 
     * of those values are Metric.NULL_DATA.  Throws an exception if the inputs
     * are not of the same class.  The return type may not correspond to the input
     * type if the result of the aggregation function cannot be stored in the input
     * type.  Specifically, any aggregation of a result that contains integers 
     * should ALWAYS return a result that contains doubles, as the aggregation 
     * function is guaranteed to do so.  For example, the average of a set of 
     * integers may not be an integer.  Specify a set of weights for each metric
     * that are constant across all forecast lead times.  The weights must sum to 1.
     * 
     * @param input the input results
     * @param func the aggregation function
     * @param weights the constant weights to apply across all lead times
     * @return the aggregated result   
     */
    
    public MetricResult aggregate(MetricResult[] input, VectorFunction func,double[] weights) throws MetricResultException {
        checkAggInputs(input,weights);  //Throws an exception if inputs are invalid
        //Check inputs are correct
        if(input[0].getID()!=DOUBLE_MATRIX_1D_RESULT) {
            throw new MetricResultException("Expected instances of DoubleMatrix1DResult in the input for aggregation, but received: "+input[0].getClass());
        }
        int rows = ((DoubleMatrix1DResult)input[0]).getResult().getRowCount();
        DenseDoubleMatrix1D im = new DenseDoubleMatrix1D(rows);
        for(int i = 0; i < rows; i++) {
            DenseDoubleMatrix1D in = new DenseDoubleMatrix1D(input.length);
            double wSum = 0.0;
            for(int j = 0; j < input.length; j++) {
                double nxt = ((DoubleMatrix1DResult)input[j]).getResult().get(i);
                in.set(j,nxt);
                if (nxt != Metric.NULL_DATA) {
                    wSum += weights[j];
                }
            }
            //Use reweighted sum in case values are missing
            if (wSum == 0.0) {  //All inputs null, specify null
                im.set(i, Metric.NULL_DATA);
            }
            else {
                double wMult = 1.0 / wSum;
                for (int j = 0; j < input.length; j++) {
                    if (in.get(j) != Metric.NULL_DATA) {
                        in.set(j, in.get(j) * weights[j] * wMult);
                    }
                }
                im.set(i, func.apply(in, Metric.NULL_DATA)); //Aggregate ith position
             }
        }
        return new DoubleMatrix1DResult(im);  
    }      
    
    /**
     * Returns the metric result.
     *
     * @return the result
     */
    
    public DoubleMatrix1D getResult() {
        return result;
    }
    
    /**
     * Returns a string representation of the receiver.
     *
     * @return a string representation
     */
    
    public String toString() {
        String s = result.toString();
        s=s.replaceAll("-Infinity","All data");
        return s;
    }

    /**
     * Returns a string representation of the result for writing to an XML file
     * with a specified writing precision.  The results may be spread across several
     * strings to be written as individual nodes.
     *
     * @param precision the writing precision
     * @return a string representation for writing to XML
     */

    public String[] toXMLString(int precision) {
        StringBuffer buf = new StringBuffer();
        int rows = result.getRowCount();
        for(int j = 0; j < rows; j++) {
            double d = result.get(j);
            if (Double.isInfinite(d)) {
                buf.append("All data");
            } else {
                buf.append(Mathematics.round(d, precision));

            }
            if (j < (rows - 1)) {
                buf.append(", ");
            }
        }
        return new String[]{buf.toString()};
    }

    /**
     * Returns a deep copy of the current metric result, where all instance variables 
     * occupy independent positions in memory from the current metric result.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricResult deepCopy() {
        DoubleMatrix1DResult d = new DoubleMatrix1DResult((DoubleMatrix1D)result.deepCopy());
        d.intervals = deepCopyIntervals();
        if(hasMainInterval()) {
            d.main = (ProbabilityIntervalParameter)main.deepCopy();
        }
        return d;
    }

    @Override
    public TreeMap<ProbabilityIntervalParameter,MetricResult[]> getIntervalsFromResults(
        ProbabilityIntervalParameter[] intervals, MetricResult[] results, double nV, int minSampleSize)
            throws SamplingIntervalException {
        //Check the input
        checkIntervalsInput(getID(),intervals,results,minSampleSize);
        TreeMap<ProbabilityIntervalParameter, MetricResult[]> returnMe =
                new TreeMap<ProbabilityIntervalParameter, MetricResult[]>();

        int rows = ((DoubleMatrix1DResult)results[0]).result.getRowCount();
        //Set the results templates
        for (ProbabilityIntervalParameter p : intervals) {
            DoubleMatrix1DResult addMe = new DoubleMatrix1DResult(new DenseDoubleMatrix1D(rows));
            returnMe.put(p,new MetricResult[]{addMe,addMe.deepCopy(),addMe.deepCopy()});
        }

        //Iterate through the pointwise statistics
        for (int i = 0; i < rows; i++) {
            //Obtain the order statistics
            double[] points = new double[results.length];
            int nullCount = 0;
            for (int j = 0; j < points.length; j++) {
                try {
                    points[j] = ((DoubleMatrix1DResult) results[j]).result.get(i);
                    if (points[j] == nV) {
                        nullCount++;
                    }
                } catch (ArrayIndexOutOfBoundsException e) {
                    throw new SamplingIntervalException("Failed to compute the sampling intervals as one or more "
                            + "input results of type '"+getClass().getSimpleName()+"' had an inconsistent number "
                            + "of entries.");
                }
            }
            //Order the data
            Arrays.sort(points);
            //Compute and return the results
            int actualSamples = points.length - nullCount;
            for (ProbabilityIntervalParameter p : intervals) {
                MetricResult[] r = returnMe.get(p);
                //Null intervals
                if (actualSamples < minSampleSize) {
                    ((DoubleMatrix1DResult)r[0]).result.set(i,nV);
                    ((DoubleMatrix1DResult)r[1]).result.set(i,nV);
                    ((DoubleMatrix1DResult)r[2]).result.set(i,nV);
                } //Valid intervals
                else {
                    try {
                        double lower = EmpiricalCDFCalculator.getVal(points, p.getLower(), nV, false);
                        double upper = EmpiricalCDFCalculator.getVal(points, p.getUpper(), nV, false);
                        ((DoubleMatrix1DResult)r[0]).result.set(i,lower);
                        ((DoubleMatrix1DResult)r[1]).result.set(i,upper);
                        ((DoubleMatrix1DResult)r[2]).result.set(i,actualSamples);
                    } catch (Exception e) {
                        throw new SamplingIntervalException("Failed to compute sampling interval '" + p + "' with error"
                                + "message: " + e.getMessage());
                    }
                }
            }
        }
        return returnMe;
    }

    /********************************************************************************
     *                                                                              *
     *                                  TEST METHOD                                 *
     *                                                                              *
     *******************************************************************************/

    /**
     * Main method.
     *
     * @param args the command line args
     */

    public static void main(String[] args) {
        double[] a = new double[]{-999,2,3,4};
        double[] b = new double[]{-999,10,11,12};
        double[] c = new double[]{-999,18,19,20};
        double[] d = new double[]{25,26,27,28};

        double[] weights = new double[]{0.0,0.0,0.5,0.5};
        DoubleMatrix1DResult r1 = new DoubleMatrix1DResult(new DenseDoubleMatrix1D(a));
        DoubleMatrix1DResult r2 = new DoubleMatrix1DResult(new DenseDoubleMatrix1D(b));
        DoubleMatrix1DResult r3 = new DoubleMatrix1DResult(new DenseDoubleMatrix1D(c));
        DoubleMatrix1DResult r4 = new DoubleMatrix1DResult(new DenseDoubleMatrix1D(d));
        VectorFunction tot = evs.utilities.mathutil.FunctionLibrary.total();
        MetricResult[] all = new MetricResult[]{r1,r2,r3,r4};
        System.out.println(r1.aggregate(all,tot,weights));

    }

}

    
