package evs.metric.parameters;

/**
 * Records the number of points in the box plot ordered by size of observation.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public final class BoxUnpooledObsPointsParameter extends PositiveIntegerParameter {
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs an object with an integer parameter value
     *
     * @param par the parameter value  
     */ 
    
    public BoxUnpooledObsPointsParameter(int par) {  
        super(par);
    }
    
    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricParameter deepCopy() {
        return new BoxUnpooledObsPointsParameter(par);
    }     
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
        
    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     * Remember to override in any subclass.
     *
     * @return an identifier
     */
    
    public int getID() {
        return BOX_UNPOOLED_OBS_POINTS_PARAMETER;
    }     
    
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "box_unpooled_obs_points_parameter";
    }       
    
}
