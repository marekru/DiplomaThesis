package evs.metric.metrics;

/**
 * Identifies an ensemble or probabilistic metric that is defined only for discrete
 * events, such as the exceedence or non-exceedence of some threshold.
 *
 * @author evs@hydrosolved.com
 */
public interface CategoricalMetric {

}
