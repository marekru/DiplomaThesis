package evs.metric.results;

//Java util dependencies
import java.util.*;

//EVS dependencies
import evs.utilities.mathutil.*;
import evs.metric.parameters.*;
import evs.utilities.matrix.*;

/**
 * Stores a set of metric results by lead time in hours relative to the epoch (i.e. 
 * equivalent to Calendar.getTimeInMillis()*1000*60*60).  Extends evs.metric.MetricResult
 * for convenience.  A single store supports only one class of metric result so that 
 * the getter methods will always return an object of that class or null.  
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class MetricResultByLeadTime extends MetricResultStore {

    /********************************************************************************
     *                                                                              *
     *                                 CONSTRUCTOR                                  *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Constructs a store with a specified type of metric result as the store type.  
     * Subsequently attempting to add metrics of a different result type will throw
     * an exception.  See the evs.metric.results.MetricResult class for supported types.
     *
     * @param storedID the result type id
     */
    
    public MetricResultByLeadTime(int storedID) {
        super(storedID);
        if(storedID==METRIC_RESULT_BY_LEAD_PERIOD) {
            throw new IllegalArgumentException("Cannot create a result store within " +
                    "a result store of the same type: "+getClass().getSimpleName()+".");
        }
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/     
        
    /**
     * Returns the type of result.  
     *
     * @return the type of result
     */
    
    public int getID() {
        return METRIC_RESULT_BY_LEAD_PERIOD; 
    }    

    /**
     * Applies an aggregation function to the corresponding values (e.g. same 
     * matrix position) in the input results, placing a Metric.NULL_DATA if all 
     * of those values are Metric.NULL_DATA.  Throws an exception if the inputs
     * are not of the same class.  The return type may not correspond to the input
     * type if the result of the aggregation function cannot be stored in the input
     * type.  Specifically, any aggregation of a result that contains integers 
     * should ALWAYS return a result that contains doubles, as the aggregation 
     * function is guaranteed to do so.  For example, the average of a set of 
     * integers may not be an integer.  Specify a set of weights for each metric
     * that are constant across all forecast lead times.  The weights must sume to 1.
     * 
     * @param input the input results
     * @param func the aggregation function
     * @param weights the constant weights to apply across all lead times
     * @return the aggregated result   
     */
    
    public MetricResult aggregate(MetricResult[] input, VectorFunction func, double[] weights) throws MetricResultException {
        checkAggInputs(input,weights);  //Throws an exception if inputs are invalid
        //Check inputs are correct
        if(input[0].getID()!=METRIC_RESULT_BY_LEAD_PERIOD) {
            throw new MetricResultException("Expected instances of MetricResultByLeadPeriod in the input for aggregation, but received: "+input[0].getClass());
        }
        //Collect the results together for each lead period and then aggregate
        TreeMap<Double,Vector<MetricResult>> byPeriod = new TreeMap<Double,Vector<MetricResult>>();
        for(int i = 0; i < input.length; i++) {
            Iterator it = ((MetricResultByLeadTime)input[i]).getResults().keySet().iterator();
            while(it.hasNext()) {
                Double next = (Double)it.next();
                MetricResult res = ((MetricResultByLeadTime)input[i]).getResult(next);
                if(byPeriod.containsKey(next)) {
                    Vector<MetricResult> v = byPeriod.get(next);
                    //If v is smaller than the current input index, add nulls to make up to current index
                    int diff = i-v.size();
                    if(diff!= 0) {
                        for(int k = 0; k < diff; k++) {
                            v.add(null);
                        }
                    }
                    v.add(res);  //Will be added to correct position
                }
                else {
                    Vector<MetricResult> v = new Vector<MetricResult>();
                    v.add(res);
                    byPeriod.put(next,v);
                }
            }
        }
        
        MetricResultByLeadTime newRes = null;
        Iterator it2 = byPeriod.keySet().iterator();
        while(it2.hasNext()) {
            Double next = (Double)it2.next();
            Vector<MetricResult> mets = byPeriod.get(next);
            MetricResult[] res = new MetricResult[mets.size()];
            res = mets.toArray(res);

            //Determine if any results are missing and adjust weights accordingly
            double redSum = 0.0;  //Reduced sum after eliminating missing weights 
            Vector<MetricResult> inc = new Vector<MetricResult>();
            Vector<Double> wgh = new Vector<Double>();
            for(int i = 0; i < res.length; i++) {
                if(res[i]!=null) {
                    inc.add(res[i]);
                    wgh.add(weights[i]);
                    redSum+=weights[i];
                }
            }
            if(wgh.size()<input.length) {
                System.out.println("Rescaling weights at lead time "+next+" due to missing metrics.");
            }
            MetricResult[] res2 = new MetricResult[inc.size()];
            res2 = inc.toArray(res2);
            double[] newW = new double[wgh.size()];
            double mFac = 1.0/redSum;
            for(int i = 0; i < newW.length; i++) {
                newW[i]=wgh.get(i)*mFac;
            }
            
            MetricResult nm = res[0].aggregate(res2,func,newW);  //Aggregate

            if(newRes==null) {
                newRes = new MetricResultByLeadTime(nm.getID());
            }
            newRes.addResult(next,nm);
        }
        return newRes;  
    } 
    
    /**
     * Returns a metric result for a specified lead time in hours relative to the
     * epoch.
     *
     * @param hours the time in hours relative to the epoch 
     * @return a metric result or null
     */
    
    public MetricResult getResult(double hours) {
        return (MetricResult)results.get(hours);
    }

    /**
     * Returns the lead times in a 1D matrix.
     *
     * @return the available lead times
     */

    public DoubleMatrix1D getLeadTimes() {
        DoubleMatrix1D m = new DenseDoubleMatrix1D(results.size());
        Iterator it = results.keySet().iterator();
        int nxt = 0;
        while(it.hasNext()) {
            m.set(nxt,(Double)it.next());
            nxt++;
        }
        return m;
    }

    /**
     * Returns a set of metric results or an empty map.
     * 
     * @return the metric results
     */
    
    public TreeMap<Double,MetricResult> getResults() {
        return results;
    }     
    
    /**
     * Convenience method that returns results for a specified component of a 
     * score decomposition. Throws an exception if the stored results are not
     * of type evs.metric.results.MetricResultByThreshold, which in turn contains
     * type evs.metric.results.EnsembleScoreDecomposition or if the specified
     * component is not one of the class variables in that class.
     * 
     * @param comp the score component
     * @return the results for a specified component of a score
     */
    
    public MetricResultByLeadTime getResultsForScoreComp(int comp) throws IllegalArgumentException {
        if(getIDForStoredResults()!=MetricResult.METRIC_RESULT_BY_THRESHOLD) {
            throw new IllegalArgumentException("Cannot return results for a score component: the stored results are not organized by threshold.");
        }
        MetricResultByLeadTime p = new MetricResultByLeadTime(storedID);
        Iterator it = results.keySet().iterator();
        while(it.hasNext()) {
            Double n = (Double)it.next();
            MetricResult add = ((MetricResultByThreshold)results.get(n)).getResultsForScoreComp(comp);
            p.addResult(n, add);
        }
        return p;
    }

    /**
     * Returns the earliest lead time in the store or throws an exception if
     * no lead times are available.
     * 
     * @return the first lead time
     */
    
    public double getFirstLeadTime() throws IllegalArgumentException {
        if(results == null || results.size()==0) {
            throw new IllegalArgumentException("No lead times available.");
        }
        Double[] dat = new Double[results.size()];
        results.keySet().toArray(dat);
        Arrays.sort(dat);
        return dat[0];
    }
    
    /**
     * Returns the latest lead time in the store or throws an exception if
     * no lead times are available.
     * 
     * @return the last lead time
     */
    
    public double getLastLeadTime() throws IllegalArgumentException {
        if(results == null || results.size()==0) {
            throw new IllegalArgumentException("No lead times available.");
        }
        Double[] dat = new Double[results.size()];
        results.keySet().toArray(dat);
        Arrays.sort(dat);
        return dat[dat.length-1];
    }    
    
    /**
     * Returns the difference between successive lead times based on the first two
     * times.
     * 
     * @return the lead time increment
     */
    
    public double getLeadTimeIncrement() throws IllegalArgumentException {
        if(results == null || results.size()<2) {
            throw new IllegalArgumentException("Insufficient lead times available.");
        }
        Double[] dat = new Double[results.size()];
        results.keySet().toArray(dat);
        Arrays.sort(dat);
        return Math.abs(dat[1]-dat[0]);
    }    
    
    /**
     * Returns true if a metric result exists for a specified lead time in hours 
     * relative to the epoch.
     *
     * @param hours the time in hours relative to the epoch 
     * @return true if a metric result exists, false otherwise
     */
    
    public boolean hasResult(double hours) {
        return results.containsKey(hours);
    }  
    
    /**
     * Returns a deep copy of the current metric result, where all instance variables 
     * occupy independent positions in memory from the current metric result.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricResult deepCopy() {
        MetricResultByLeadTime returnMe = new MetricResultByLeadTime(storedID);
        Iterator i = results.keySet().iterator();
        while(i.hasNext()) {
            Double next = (Double)i.next(); 
            MetricResult nextResult = (MetricResult)results.get(next);
            returnMe.addResult(next,nextResult.deepCopy());
        }
        returnMe.intervals = deepCopyIntervals();
        if(hasMainInterval()) {
            returnMe.main = (ProbabilityIntervalParameter)main.deepCopy();
        }
        return returnMe;
    }
    
    /**
     * Returns a deep copy of the current metric result, where all instance variables 
     * occupy independent positions in memory from the current metric result.  
     *
     * @return a deep copy of the current object 
     */
     
    public String toString() {
        StringBuffer b = new StringBuffer();
        String nL = System.getProperty("line.separator");
        Iterator i = results.keySet().iterator();
        while(i.hasNext()) {
            Object time = i.next();
            b.append("Results at lead time: "+time+nL);
            b.append(results.get(time)+nL);
        }
        return b.toString();
    }    
    
    /********************************************************************************
     *                                                                              *
     *                               MUTATOR METHODS                                *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Adds a new result to the metric store.
     * 
     * @param time the time
     * @param result the metric result
     */
    
    public void addResult(double time, MetricResult result) throws IllegalArgumentException {
        super.addResult(time,result);
    }    
    
}
