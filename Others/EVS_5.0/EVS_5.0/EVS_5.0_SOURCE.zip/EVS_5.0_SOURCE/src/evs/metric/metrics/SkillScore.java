package evs.metric.metrics;
import evs.metric.parameters.ReferenceForecastParameter;

/**
 * An interface that identifies a skill metric.  A skill metric should override 
 * the conventional metric of the same type and implement this interface.  The
 * skill score is computed by overriding the compute() method in the Metric class,
 * calling the super type first and then checking to establish if results are available 
 * for reference forecasts.  If results are available, the skill score is computed 
 * for each reference forecast and added to the result store.  
 * 
 * ONLY ONE REFERENCE FORECAST CAN BE USED AT PRESENT.  IN ORDER TO SUPPORT MULTIPLE
 * REFERENCE FORECASTS, ADDITIONAL REFERENCE FORECAST IDENTIFIERS MUST BE DEFINED
 * FOR STORING THESE RESULTS IN THE RESULT MAP.  
 * 
 * Note that results for a skill metric only become available once the results for
 * two forecasting systems are available (i.e. the compute() method has successfully
 * stored results (for a reference forecast) on at least one prior occasion).
 *
 * @author evs@hydrosolved.com
 */

public interface SkillScore {
    
    /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/    
   
    /**
     * Returns a reference forecast parameter.
     * 
     * @return the reference forecasts
     */
    
    abstract ReferenceForecastParameter getRefFcst() throws IllegalArgumentException;
    
    /**
     * Returns the name of the base metric for which the skill calculation is  
     * computed.
     * 
     * @return the base metric name
     */
    
    abstract String getBaseMetricName();
    
    /**
     * Returns any default reference forecast implemented for the skill score,
     * such as sample climatology.
     * 
     * @return the default reference forecasts
     */

    abstract ReferenceForecastParameter getDefaultRefFcst() throws IllegalArgumentException;

    /**
     * Returns true if the skill score has a default reference forecast.
     *
     * @return true if the skill score has a default reference forecasts.
     */
    
    abstract boolean hasDefaultRefFcst();

}
