package evs.metric.results;

//EVS dependencies
import evs.utilities.matrix.*;
import evs.utilities.mathutil.*;
import evs.metric.metrics.*;
import evs.metric.parameters.*;

//Java dependencies
import java.util.*;

/**
 * Immutable wrapper class for an integer value that acts as a metric result.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public final class IntegerResult extends MetricResult {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLE                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * The metric result.
     */
    
    private int result;
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs a metric result with an int value.
     *
     * @param result the metric result
     */
    
    public IntegerResult(int result) {
        this.result = result;
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Returns the type of result.  
     *
     * @return the type of result
     */
    
    public int getID() {
        return INTEGER_RESULT;
    }    
    
    /**
     * Applies an aggregation function to the corresponding values (e.g. same 
     * matrix position) in the input results, placing a Metric.NULL_DATA if all 
     * of those values are Metric.NULL_DATA.  Throws an exception if the inputs
     * are not of the same class.  The return type may not correspond to the input
     * type if the result of the aggregation function cannot be stored in the input
     * type.  Specifically, any aggregation of a result that contains integers 
     * should ALWAYS return a result that contains doubles, as the aggregation 
     * function is guaranteed to do so.  For example, the average of a set of 
     * integers may not be an integer.  Specify a set of weights for each metric
     * that are constant across all forecast lead times.  The weights must sume to 1.
     * 
     * @param input the input results
     * @param func the aggregation function
     * @param weights the constant weights to apply across all lead times
     * @return the aggregated result   
     */
    
    public MetricResult aggregate(MetricResult[] input, VectorFunction func, double[] weights) throws MetricResultException {
        checkAggInputs(input,weights);  //Throws an exception if inputs are invalid
        //Check inputs are correct
        if(input[0].getID()!=INTEGER_RESULT) {
            throw new MetricResultException("Expected instances of IntegerResult in the input for aggregation, but received: "+input[0].getClass());
        }
        DenseDoubleMatrix1D im = new DenseDoubleMatrix1D(input.length);
        double wSum = 0.0;
        for(int i = 0; i < input.length; i++) {
            double nxt = ((IntegerResult)input[i]).result;
            im.set(i,nxt);
            if (nxt != Metric.NULL_DATA) {
                wSum += weights[i];
            }
        }
        //Use reweighted sum in case values are missing
        if (wSum == 0.0) {  //All inputs null, specify null
            return new DoubleResult(Metric.NULL_DATA);
        }
        else {
            double wMult = 1.0 / wSum;
            for (int i = 0; i < input.length; i++) {
                if (im.get(i) != Metric.NULL_DATA) {
                    im.set(i, im.get(i) * weights[i] * wMult);
                }
            }
            return new DoubleResult(func.apply(im,Metric.NULL_DATA));  //Aggregate
        }
    }
     
    /**
     * Returns the metric result.
     *
     * @return the result
     */
    
    public int getResult() {
        return result;
    }
    
    /**
     * Returns a string representation of the receiver.
     *
     * @return a string representation
     */
    
    public String toString() {
        return result+"";
    }

    /**
     * Returns a string representation of the result for writing to an XML file
     * with a specified writing precision.  The results may be spread across several
     * strings to be written as individual nodes.
     *
     * @param precision the writing precision
     * @return a string representation for writing to XML
     */

    public String[] toXMLString(int precision) {
        return new String[]{toString()};
    }
    
    /**
     * Returns a deep copy of the current metric result, where all instance variables 
     * occupy independent positions in memory from the current metric result.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricResult deepCopy() {
        IntegerResult d = new IntegerResult(result);
        d.intervals = deepCopyIntervals();
        if(hasMainInterval()) {
            d.main = (ProbabilityIntervalParameter)main.deepCopy();
        }
        return d;
    }

    @Override
    public TreeMap<ProbabilityIntervalParameter,MetricResult[]> getIntervalsFromResults(
        ProbabilityIntervalParameter[] intervals, MetricResult[] results, double nV, int minSampleSize)
            throws SamplingIntervalException {
        throw new SamplingIntervalException("Sampling uncertainty interval calculation not "
                + "implemented for result type '"+getClass().getSimpleName()+"'.");
    }

    /********************************************************************************
     *                                                                              *
     *                                  TEST METHOD                                 *
     *                                                                              *
     *******************************************************************************/

    /**
     * Main method.
     *
     * @param args the command line args
     */

    public static void main(String[] args) {
        int a = -999;
        int b = -999;
        int c = -999;
        int d = 25;

        double[] weights = new double[]{0.0,0.0,0.5,0.5};
        IntegerResult r1 = new IntegerResult(a);
        IntegerResult r2 = new IntegerResult(b);
        IntegerResult r3 = new IntegerResult(c);
        IntegerResult r4 = new IntegerResult(d);
        VectorFunction tot = evs.utilities.mathutil.FunctionLibrary.total();
        MetricResult[] all = new MetricResult[]{r1,r2,r3,r4};
        System.out.println(r1.aggregate(all,tot,weights));

    }

}
