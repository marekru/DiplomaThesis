package evs.metric.results;

//EVS dependencies
import evs.utilities.matrix.*;
import evs.utilities.mathutil.*;
import evs.metric.metrics.*;
import evs.metric.parameters.*;

//EVS dependencies
import java.util.*;

/**
 * Immutable wrapper class for a double value that acts as a metric result.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public final class DoubleResult extends MetricResult {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLE                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * The metric result.
     */
    
    private double result;
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs a metric result with a double value.
     *
     * @param result the metric result
     */
    
    public DoubleResult(double result) {
        this.result = result;
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Returns the type of result.  
     *
     * @return the type of result
     */
    
    public int getID() {
        return DOUBLE_RESULT;
    }    
    
    /**
     * Applies an aggregation function to the corresponding values (e.g. same 
     * matrix position) in the input results, placing a Metric.NULL_DATA if all 
     * of those values are Metric.NULL_DATA.  Throws an exception if the inputs
     * are not of the same class.  The return type may not correspond to the input
     * type if the result of the aggregation function cannot be stored in the input
     * type.  Specifically, any aggregation of a result that contains integers 
     * should ALWAYS return a result that contains doubles, as the aggregation 
     * function is guaranteed to do so.  For example, the average of a set of 
     * integers may not be an integer.  Specify a set of weights for each metric
     * that are constant across all forecast lead times.  The weights must sume to 1.
     * 
     * @param input the input results
     * @param func the aggregation function
     * @param weights the constant weights to apply across all lead times
     * @return the aggregated result   
     */
    
    public MetricResult aggregate(MetricResult[] input, VectorFunction func, double[] weights) throws MetricResultException {
        checkAggInputs(input,weights);  //Throws an exception if inputs are invalid
        //Check inputs are correct
        if(input[0].getID()!=DOUBLE_RESULT) {
            throw new MetricResultException("Expected instances of DoubleResult in the input for aggregation, but received: "+input[0].getClass());
        }
        DenseDoubleMatrix1D im = new DenseDoubleMatrix1D(input.length);
        double wSum = 0.0;
        for(int i = 0; i < input.length; i++) {
            double nxt = ((DoubleResult)input[i]).result;
            im.set(i,nxt);
            if (nxt != Metric.NULL_DATA) {
                wSum += weights[i];
            }
        }
        //Use reweighted sum in case values are missing
        if (wSum == 0.0) {  //All inputs null, specify null
            return new DoubleResult(Metric.NULL_DATA);
        }
        else {
            double wMult = 1.0 / wSum;
            for (int i = 0; i < input.length; i++) {
                if (im.get(i) != Metric.NULL_DATA) {
                    im.set(i, im.get(i) * weights[i] * wMult);
                }
            }
            return new DoubleResult(func.apply(im,Metric.NULL_DATA));  //Aggregate
        }
    }    
    
    /**
     * Returns the metric result.
     *
     * @return the result
     */
    
    public double getResult() {
        return result;
    }
    
    /**
     * Returns a string representation of the receiver.
     *
     * @return a string representation
     */
    
    public String toString() {
        if(Double.isInfinite(result)) {
            return "All data";
        }
        return result+"";
    }

    /**
     * Returns a string representation of the result for writing to an XML file
     * with a specified writing precision.  The results may be spread across several
     * strings to be written as individual nodes.
     *
     * @param precision the writing precision
     * @return a string representation for writing to XML
     */

    public String[] toXMLString(int precision) {
        return new String[]{toString()};
    }
    
    /**
     * Returns a deep copy of the current metric result, where all instance variables 
     * occupy independent positions in memory from the current metric result.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricResult deepCopy() {
        DoubleResult d = new DoubleResult(result);
        d.intervals = deepCopyIntervals();
        if(hasMainInterval()) {
            d.main = (ProbabilityIntervalParameter)main.deepCopy();
        }
        return d;
    }

    @Override
    public TreeMap<ProbabilityIntervalParameter,MetricResult[]> getIntervalsFromResults(
        ProbabilityIntervalParameter[] intervals, MetricResult[] results, double nV, int minSampleSize)
            throws SamplingIntervalException {
        //Check the input
        checkIntervalsInput(getID(),intervals,results,minSampleSize);
        TreeMap<ProbabilityIntervalParameter, MetricResult[]> returnMe =
                new TreeMap<ProbabilityIntervalParameter, MetricResult[]>();
        //Obtaine the order statistics
        double[] points = new double[results.length];
        int nullCount = 0;
        for(int i = 0; i < points.length; i++) {
            points[i]=((DoubleResult)results[i]).getResult();
            if(points[i]==nV) {
                nullCount++;
            }
        }
        //Order the data
        Arrays.sort(points);
        //Compute and return the results
        int actualSamples = points.length-nullCount;
        for(ProbabilityIntervalParameter p : intervals) {
            //Null intervals
            if(actualSamples<minSampleSize) {
                returnMe.put(p,new MetricResult[]{new DoubleResult(nV),new DoubleResult(nV),new DoubleResult(nV)});
            }
            //Valid intervals
            else {
                try {
                    DoubleResult lower = new DoubleResult(
                            EmpiricalCDFCalculator.getVal(points,p.getLower(),nV,false));
                    DoubleResult upper = new DoubleResult(
                            EmpiricalCDFCalculator.getVal(points,p.getUpper(),nV,false));
                    returnMe.put(p,new MetricResult[]{lower,upper, new DoubleResult(actualSamples)});
                }
                catch(Exception e) {
                    throw new SamplingIntervalException("Failed to compute sampling interval '"+p+"' with error"
                            + "message: "+e.getMessage());
                }
            }
        }
        return returnMe;
    }

    /********************************************************************************
     *                                                                              *
     *                                  TEST METHOD                                 *
     *                                                                              *
     *******************************************************************************/

    /**
     * Main method.
     *
     * @param args the command line args
     */

    public static void main(String[] args) {
        double a = -999;
        double b = -999;
        double c = -999;
        double d = 25;

        double[] weights = new double[]{0.0,0.0,0.5,0.5};
        DoubleResult r1 = new DoubleResult(a);
        DoubleResult r2 = new DoubleResult(b);
        DoubleResult r3 = new DoubleResult(c);
        DoubleResult r4 = new DoubleResult(d);
        VectorFunction tot = evs.utilities.mathutil.FunctionLibrary.total();
        MetricResult[] all = new MetricResult[]{r1,r2,r3,r4};
        System.out.println(r1.aggregate(all,tot,weights));

    }

    
}
