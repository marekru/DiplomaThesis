package evs.metric.metrics;

//EVS dependencies
import java.util.Arrays;
import java.util.Vector;

import evs.data.PairedData;
import evs.metric.parameters.*;
import evs.metric.results.*;
import evs.utilities.EVSConstants;
import evs.utilities.mathutil.DoubleProcedure;
import evs.utilities.mathutil.FunctionLibrary;
import evs.utilities.matrix.DenseDoubleMatrix1D;
import evs.utilities.matrix.DoubleMatrix1D;
import evs.utilities.matrix.DoubleMatrix2D;

/**
 * The Continuous Ranked Probability Score (CRPS) is the integrated squared difference 
 * between the cumulative distributions of the forecasts and the observations, where
 * the cdf of the observations is given by the Heaviside function (pdf is the dirac delta
 * function).
 *
 * For multiple forecasts, the average of these squared differences is computed,
 * leading to the mean CRPS.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class MeanContRankProbScore extends ScoreMetric implements EnsembleMetric, 
        ThresholdMetric, DecomposableScore, BootstrapableMetric {
       
    /********************************************************************************
     *                                                                              *
     *                             INSTANCE VARIABLES                               *
     *                                                                              *
     *******************************************************************************/     

    /**
     * CRPS method that ignores any null ensemble members.
     */

    public static final int HERSBACH = 101;

    /**
     * CRPS method that ignores any null ensemble members.
     */

    public static final int WITH_NULLS = 102;

    /**
     * Method used to compute CRPS.
     */

    private static int method = HERSBACH;

    /**
     * Is true to silence the output from the Hersbach method for CRPS when some
     * pairs contain missing members.
     */

    private boolean silenceHersbach = false;

    /**
     * Lead time that may be set prior to computation of the CRPS to provide a
     * more meaningful warning message on standard out when pairs are eliminated
     * by the Hersbach algorithm due to missing members. Not deep copied.
     */

    private Double warnLead = null;

    /**
     * Threshold that may be set prior to computation of the CRPS to provide a
     * more meaningful warning message on standard out when pairs are eliminated
     * by the Hersbach algorithm due to missing members. Not deep copied.
     */

    private DoubleProcedureParameter warnThresh = null;

    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/      
        
    /**
     * Attempts to construct a mean CRPS object with associated parameters.
     *
     * @param decompose is true to decompose the score
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use 
     * conditional pairs when available
     * @param minS the minimum sample size
     * @param bs the bootstrap parameter
     */
    
    public MeanContRankProbScore(final DecomposeParameter decompose, final ForecastTypeParameter fType,
            final UnconditionalParameter unconditional,final MinimumSampleSizeParameter minS,
            final BootstrapParameter bs) {
        //Set the name
        name = "Mean continuous ranked probability score";
        //Set the parameters
        //Specify an all-inclusive threshold condition
        final ProbabilityIdentifierParameter p = new ProbabilityIdentifierParameter(false);
        final DoubleParameter[] dubs = new DoubleParameter[]{new DoubleParameter(Double.NEGATIVE_INFINITY)};
        final IntegerParameter p2 = new IntegerParameter(DoubleProcedureParameter.GREATER_THAN);
        setParameters(new MetricParameter[]{new DoubleProcedureParameter(p2,dubs,p,new BooleanParameter(true))
                ,decompose.deepCopy(),fType.deepCopy(),unconditional.deepCopy(),minS.deepCopy(),bs.deepCopy()});
        //Set the link to html description of the metric
        descriptionURL = getClass().getResource(EVSConstants.STATS_EXPLAINED_DIR + "crps.htm");
    }
    
    /**
     * Attempts to construct a mean CRPS object with associated parameters.
     *
     * @param threshold the threshold
     * @param decompose is true to decompose the score
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use 
     * conditional pairs when available
     * @param minS the minimum sample size
     * @param bs the bootstrap parameter
     */
    
    public MeanContRankProbScore(final DoubleProcedureParameter threshold, final DecomposeParameter decompose, 
            final ForecastTypeParameter fType,final UnconditionalParameter unconditional,
            final MinimumSampleSizeParameter minS,final BootstrapParameter bs) {
        this(decompose,fType,unconditional,minS,bs);
        pars[0]=threshold;
    }    
    
    /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/        
    
    /**
     * Returns the metric identifier.
     *
     * @return an identifier
     */
    
    @Override
    public int getID() {
        return CRPS;
    }
    
    /**
     * Returns true if the metric will be decomposed, false if only the overall
     * value will be computed.
     * 
     * @return true if the decomposition of the metric value will be provided
     */
    
    public boolean willDecompose() {
        return ((DecomposeParameter)pars[1]).getParVal();
    }
    
    /**
     * Returns the type of decomposition required. One of:
     * 
     * DecomposableScore.CALIBRATION_REFINEMENT
     * DecomposableScore.LIKELIHOOD_BASE_RATE
     * DecomposableScore.CR_AND_LBR
     * DecomposableScore.NONE  
     * 
     * @return the type of decomposition
     */
    
    public int getScoreDecType() {
        return ((DecomposeParameter)pars[1]).getScoreDecType();
    }        
    
    /**
     * Returns an array of integer decompositions that have been implemented. 
     * Each int is one of:
     * 
     * DecomposableScore.CALIBRATION_REFINEMENT
     * DecomposableScore.LIKELIHOOD_BASE_RATE
     * DecomposableScore.CR_AND_LBR
     * DecomposableScore.NONE.  
     * 
     * @return an array of implemented decompositions.
     */
    
    public int[] getDecompositionOptions() {
        return new int[] {
            DecomposableScore.NONE,
            DecomposableScore.CALIBRATION_REFINEMENT,
        };
    }     

    /**
     * Returns the method identifier.
     *
     * @return the method identifier
     */

    public static int getMethod() {
        return method;
    }

    /**
     * Returns the result type associated with the metric.  See the 
     * evs.metric.MetricResult class for supported types.
     *
     * @return an identifier
     */
    
    @Override
    public int getResultID() {
        return MetricResult.ENSEMBLE_SCORE_DECOMPOSITION_RESULT;
    }  
    
    /**
     * Returns true if the metric is defined in real units of the forecast
     * and observed variable, false otherwise.
     * 
     * @return true if the metric is defined in real units
     */    

    @Override
    public boolean hasRealUnits() {
        return true;
    }       
    
    /**
     * Returns the threshold associated with this threshold diagram.
     *
     * @return the threshold
     */
    
    public DoubleProcedureParameter getThreshold() {
        return (DoubleProcedureParameter)pars[0].deepCopy();
    }     
    
    /**
     * Returns a deep copy of the current metric, where all instance variables 
     * occupy independent positions in memory from the current metric.  
     *
     * @return a deep copy of the current object 
     */
    
    @Override
    public Metric deepCopy() {
        final MeanContRankProbScore returnMe = new MeanContRankProbScore(
                (DoubleProcedureParameter)pars[0].deepCopy(),
                (DecomposeParameter)pars[1].deepCopy(),
                (ForecastTypeParameter)pars[2].deepCopy(),
                (UnconditionalParameter)pars[3].deepCopy(),
                (MinimumSampleSizeParameter)pars[4].deepCopy(),
                getBootstrapPar());
        deepCopyResults(returnMe);
        return returnMe;
    }

    /**
     * Returns the bootstrap parameter associated with the verification metric.
     *
     * @return the bootstrap parameter
     */
    @Override
    public BootstrapParameter getBootstrapPar() {
        return (BootstrapParameter)pars[5].deepCopy();
    }

    /**
     * Returns a metric with default parameter values.  
     *
     * @return a metric with default parameter values.
     */
    
    public static Metric getDefaultMetric() { 
        final ForecastTypeParameter type = new ForecastTypeParameter(new int[]{ForecastTypeParameter.REGULAR_FORECAST});
        return new MeanContRankProbScore(new DecomposeParameter(false),type,
                new UnconditionalParameter(false),
                new MinimumSampleSizeParameter(),new BootstrapParameter());
    }
    
    /********************************************************************************
     *                                                                              *
     *                               MUTATOR METHODS                                *
     *                                                                              *
     *******************************************************************************/     

    /**
     * Set the CRPS method.
     *
     * @param m the method identifier.
     */

    public static void setMethod(final int m) throws IllegalArgumentException {
        if(!(m==HERSBACH||m==WITH_NULLS)) {
            throw new IllegalArgumentException("Unexpected method selection for mean CRPS.");
        }
        method = m;
    }

    /**
     * Sets the threshold for the current metric.    
     *
     * @param threshold the threshold
     */
    
    public void setThreshold(final DoubleProcedureParameter threshold) {
        pars[0] = threshold.deepCopy();
    }    
    
    /**
     * Uses the specified paired data to compute and return the result of the metric.
     * The metric results are returned, together with the sample counts, but not stored 
     * locally.  The metric result is located in the first index of the return array
     * and the sample counts are located in the second index. Optionally, specify
     * the results of a reference forecast from which to compute skill if the 
     * metric is a skill score. 
     * 
     * @param forecastType the forecast type
     * @param paired the paired data
     * @param refResult the results for a reference forecast (may be null)
     * @return the metric result and sample counts
     */
    
    @Override
    public MetricResult[] compute(final int forecastType, final PairedData paired, final MetricResult refResult) throws MetricCalculationException {
        if(paired==null) {
            throw new MetricCalculationException("Error computing metric '"+getName()+"': input pairs were null.");
        }
        ForecastTypeParameter.isSupportedForecastType(forecastType,true);
        final MetricResult[] res = new MetricResult[2];
        final DoubleProcedure pro = getThreshold().getParValReal();
        DoubleMatrix2D p = paired.getPairs();
        final double nV = paired.getNullValue();
//        try {
            p = getConditionalPairs(pro, p);
            //One ensemble member = MAE
            if(p.getColumnCount()==4) {  
                VectorFunctionParameter pp = new VectorFunctionParameter(FunctionLibrary.first());    
                MeanAbsoluteError mn = new MeanAbsoluteError((ForecastTypeParameter)pars[2],
                        (UnconditionalParameter)pars[3],pp,
                        (MinimumSampleSizeParameter)pars[4],(BootstrapParameter)pars[5]);
                DoubleMatrix2D input = (DoubleMatrix2D)p.getSubmatrixByColumn(2, 3);
                MetricResult r = mn.getMAE(input, nV);
                lastCount = mn.lastCount;
                DoubleMatrix1D dm = new DenseDoubleMatrix1D(new double[]{((DoubleResult)r).getResult(),
                Metric.NULL_DATA,Metric.NULL_DATA,Metric.NULL_DATA,Metric.NULL_DATA});
                return new MetricResult[]{new EnsembleScoreDecomposition(CALIBRATION_REFINEMENT,dm),r}; 
            }
            if (method == HERSBACH) {
                res[0]=getMeanCRPSHersbach((DoubleMatrix2D) p.getSubmatrixByColumn(2, p.getColumnCount() - 1),nV);
            } else if (method == WITH_NULLS) {
                res[0]=getMeanCRPSWithNulls((DoubleMatrix2D) p.getSubmatrixByColumn(2, p.getColumnCount() - 1),nV);
            } else {
                throw new IllegalArgumentException("Unexpected method for CRPS.");
            }
            res[1]=new IntegerResult(lastCount);
//        } catch (final Exception e) {
//            //e.printStackTrace();
//        }
        return res; 
    }       

    /**
     * Sets the bootstrap parameter associated with the verification metric or
     * clears the parameter if the input is null;
     *
     * @param bs the bootstrap parameter
     */
    @Override
    public void setBootstrapPar(final BootstrapParameter bs) {
        if(bs==null) {
            throw new IllegalArgumentException("The bootstrap parameter for metric '"+this+"' cannot be null.");
        } else {
            pars[5] = bs.deepCopy();
        }
    }

    /**
     * Sets the bootstrap parameter to BootstrapableMetric.NO_BOOTSTRAP and clears
     * all associated parameter values.
     */
    @Override
    public void clearBootstrapPar() {
        ((BootstrapParameter)pars[5]).clear();
    }

    /**
     * Returns the mean CRPS from the input data.  The input should comprise one
     * column of observations (at index 0) and the remaining n columns should
     * comprise the n ensemble members (index 1 through n).
     *
     * @param data the input data
     * @param nV the null value
     * @return the mean CRPS
     */

    public MetricResult getMeanCRPSHersbach(final DoubleMatrix2D data, final double nV) {
        //Split the forecasts into groups with equal numbers of members, in
        //case some forecasts contain missing members.
        //Store forecasts by member count
        final DoubleMatrix2D[] m = PairedData.
                splitInputByMemberCount(data,nV,false);
        double[] dm = null;
        if(m.length>1) {
//            if (!silenceHersbach) {
////                System.out.println("Splitting the forecasts into "+m.length+" groups "
////                        + "for computing the Mean CRPS at lead time "+warnLead+", as "
////                        + "there are "+m.length+" groups with an equal number of "
////                        + "non-null ensemble members.");
//            }
            //Compute a weighed average by the number of cases in each group
            double actualRows = 0;
            for(int i = 0; i < m.length; i++) {
                final int currentRows = m[i].getRowCount();
                actualRows += currentRows;
                final double[] next = getMeanCRPSHersbachNoNulls(m[i]);
                if(dm==null) {
                    dm=next;
                }
                //Multiply by the number of rows and add to total
                for(int j = 0; j < next.length; j++) {
                    if(dm[j]!=Metric.NULL_DATA) {
                        if(i==0) {
                            dm[j] = next[j]*currentRows;
                        } else if (i == m.length - 1) {
                            dm[j] = dm[j] / actualRows;
                        } else {
                            dm[j] += (next[j] * currentRows);
                        }
                    }
                }
            }
            //JB@30th October 2012
            int minCount = ((MinimumSampleSizeParameter) pars[4]).getParVal();
            lastCount = (int)actualRows;
            if (actualRows < minCount) {
                throw new MetricCalculationException("Could not compute the mean CRPS: fewer samples than required [" + actualRows + "," + minCount + "].");
            }
        } else {
            //JB@30th October 2012
            int minCount = ((MinimumSampleSizeParameter) pars[4]).getParVal();
            int actualRows = m[0].getRowCount();
            lastCount = actualRows;
            if (actualRows < minCount) {
                throw new MetricCalculationException("Could not compute the mean CRPS: fewer samples than required [" + actualRows + "," + minCount + "].");
            }
            dm = getMeanCRPSHersbachNoNulls(m[0]);
        }
        return new EnsembleScoreDecomposition(CALIBRATION_REFINEMENT,new DenseDoubleMatrix1D(dm));
    }

    /**
     * Returns the mean CRPS from the input data.  The input should comprise one
     * column of observations (at index 0) and the remaining n columns should 
     * comprise the n ensemble members (index 1 through n).  The input should
     * not comprise forecasts with null ensemble members.
     *
     * @param data the input data
     * @return the mean CRPS
     */
    
    private double[] getMeanCRPSHersbachNoNulls(final DoubleMatrix2D data) {
        //Get all pairs without null forecasts
        final double[][] d = data.toArray();

//        double[][] d = null;
//        DoubleMatrix2D stripped = null;
//        try {
//            stripped = PairedData.getStrippedPairs(data,false,nV,0);
//            int el = data.getRowCount()- stripped.getRowCount();
//            if(el>0) {
//                if (!silenceHersbach) {
//                    String warnString = "";
//                    if(warnLead!=null&&warnThresh!=null) {
//                        warnString = " at lead time "+warnLead+" and threshold "+warnThresh;  //Warn thresh is pre-spaced
//                        warnString = warnString.replaceAll("  "," ");
//                    }
//                    System.out.println("Eliminated " + el + " pairs when computing the mean CRPS"+warnString+
//                            ", as they had at least one null ensemble member: this is not allowed when "
//                            + "using the 'Hersbach, H. (2000) method.'");
//                }
//            }
//            d=stripped.toArray();
//        }
//        catch(IllegalArgumentException e) {
//            //e.printStackTrace();
//            lastCount = ZERO_SAMPLES;
//            throw new MetricCalculationException("Could not compute the mean CRPS " +
//                    "as no data were found that contained a non-null observation " +
//                    "and all non-null ensemble member values.");
//        }

        final int rows = d.length; 
        final int cols = d[0].length; 
        
        //Compute CRPS according to: Hersbach, H., 2000: Decomposition of the 
        //Continuous Ranked Probability Score for Ensemble Prediction Systems. 
        //Wea. Forecasting, 15, 559-570. 
        
        //Mean alpha parameter at ith member index in eqn. 29 based on equal weighting of points
        final double[] meanAlpha = new double[cols];
        //Mean beta parameter at ith member index in eqn. 29 based on equal weighting of points
        final double[] meanBeta = new double[cols];
        //Alpha and beta value for each pair at ith index is determined by one of five 
        //cases in eqn. 26 and eqn. 27, of which two refer to the outliers where the observation
        //falls below or above the forecast distribution (eqn. 26)

        //The total CRPS
        double totCRPS = 0;

        //Iterate through the member positions and determine the mean alpha and beta
        double smallerThanLowest=0.0;
        double largerThanHighest=0.0;
        
        double sumLengthLow = 0;
        double sumLengthHigh = 0;
        
        for(int i = 0; i < cols; i++) {
            final double pi = i /(double)(cols-1);  //ith probability
            final double p2i = pi*pi;  //ith probability squared
            final double _pi2 = (1.0-pi)*(1.0-pi); //(1-pi)^2
            
            double alpha_i_sum = 0;  //Sum of ith alphas, to be averaged
            double beta_i_sum = 0;  //Sum of ith betas, to be averaged           
            //Sort forecasts in ascending order on first iteration
            if (i == 0) {
                for (int j = 0; j < rows; j++) {
                    Arrays.sort(d[j], 1, cols);
                    //Deal with low outlier: case 1
                    if (d[j][0] < d[j][1]) {
                        final double beta_i_j = d[j][1] - d[j][0];
                        beta_i_sum += beta_i_j;  //Alpha unchanged
                        totCRPS+=(beta_i_j*_pi2);
                        smallerThanLowest+=1;
                        sumLengthLow+=beta_i_j;
                    }
                }          
            } //Deal with high outlier: case 2
            else if (i == (cols - 1)) {
                for (int j = 0; j < rows; j++) {
                    if (d[j][0] > d[j][i]) {
                        final double alpha_i_j = d[j][0] - d[j][i];
                        alpha_i_sum += alpha_i_j;  //Beta unchanged
                        totCRPS+=(alpha_i_j * p2i);
                        sumLengthHigh+=alpha_i_j;
                        largerThanHighest+=1;
                    }
                }
            } //Deal with remaining 3 cases, for 0 < i < N
            else {
                for (int j = 0; j < rows; j++) {
                    //Case 3: observed exceeds ith + 1
                    if (d[j][0] > d[j][i + 1]) {
                        final double alpha_i_j = d[j][i + 1] - d[j][i];
                        alpha_i_sum += alpha_i_j;  //Beta unchanged
                        totCRPS+=alpha_i_j * p2i;
                    } //Case 4: observed falls below ith
                    else if (d[j][0] < d[j][i]) {
                        final double beta_i_j = d[j][i + 1] - d[j][i];
                        beta_i_sum += beta_i_j;  //Alpha unchanged
                        totCRPS+=beta_i_j*_pi2;
                    } //Case 5: observed falls between ith and ith+1
                    else if (d[j][0] > d[j][i] && d[j][0] < d[j][i + 1]) {
                        final double alpha_i_j = d[j][0] - d[j][i];
                        final double beta_i_j = d[j][i + 1] - d[j][0];
                        alpha_i_sum += alpha_i_j;
                        beta_i_sum += beta_i_j;
                        totCRPS+=((alpha_i_j * p2i)+(beta_i_j*_pi2));
                    }
                }
            }
            meanAlpha[i]=alpha_i_sum/rows;
            meanBeta[i]=beta_i_sum/rows;
        }
        final double meanCRPS = totCRPS/rows;       
                
        //Compute the reliability, resolution and uncertainty terms if requested
        double rel = Metric.NULL_DATA;  //Reliability
        double crps_pot = Metric.NULL_DATA;  //Potential CRPS
        double unc = Metric.NULL_DATA;
        double res = Metric.NULL_DATA;
        if (willDecompose()) {
            rel = 0; res = 0; unc = 0; crps_pot = 0;
            //Compute the uncertainty
            final double[] obs = ((DoubleMatrix1D) data.getColumnAt(0)).toArray();
            Arrays.sort(obs); //Sort the observations in ascending order
            final int N = cols - 1;
            //int N = obs.length - 1;
            double ps = 0.0;
            final double inc = 1.0 / N;
            for (int i = 0; i < N; i++) {
                final int start = (int) ((((double) i) / N) * (obs.length - 1.0));
                final int stop = (int) ((((double) i + 1) / N) * (obs.length - 1.0));
                final double gap = obs[stop] - obs[start];
                ps += inc;
                unc += (ps * (1.0 - ps)) * gap;
            }

            //Deal with outliers first
            //Low case
            final double first_o = smallerThanLowest / rows;
            double pi = 0.0;
            if (smallerThanLowest > 0) {
                final double first_g = sumLengthLow / smallerThanLowest;    //Average dist. between obs. and first member given occurrence
                //double first_g = meanBeta[0]/first_o;  //Same as above, above preferred numerically
                rel += first_g * (first_o - pi) * (first_o - pi);
                crps_pot += first_g * first_o * (1.0 - first_o);
            }

            //High case
            final double smallerThanHighest = rows - largerThanHighest;
            final double last_o = smallerThanHighest / rows;
            if (largerThanHighest > 0) {
                pi = 1.0;
                final double last_g = sumLengthHigh / largerThanHighest;
                //double last_g = meanAlpha[cols-1]/(1.0-last_o);    //Same as above, above preferred numerically
                rel += last_g * (last_o - pi) * (last_o - pi);
                crps_pot += last_g * last_o * (1.0 - last_o);
            }

            //Deal with other cases
            for (int i = 1; i < (cols - 1); i++) {
                pi = i / (double)(cols - 1);
                final double gi = meanAlpha[i] + meanBeta[i];
                //It is possible that the ith index OTHER than the first and last index
                //is undefined if the distribution has a discontinuity and the observation equals
                //the value at that discontinuity, so check to avoid singularity
                if (gi > 0) {
                    final double oi = meanBeta[i] / gi;
                    rel += gi * ((oi - pi) * (oi - pi));
                    crps_pot+=gi*oi*(1.0-oi);
                }
            }

            res = unc-crps_pot;

            //double imprel = meanCRPS+res-unc;
            //System.out.println(rel+" vs. "+imprel); //Check that imputed is equal to computed
            //System.out.println(meanCRPS+" vs. "+(rel-res+unc));

        }
        final double[] dm = new double[]{meanCRPS, rel, res, unc, crps_pot};
        return dm;
    }  

    /**
     * Returns the mean CRPS from the input data.  The input should comprise one
     * column of observations (at index 0) and the remaining n columns should 
     * comprise the n ensemble members (index 1 through n).  This method can
     * handle forecasts with null ensemble members, but cannot compute the
     * decomposition.
     *
     * @param data the input data
     * @param nV the null value
     * @return the mean CRPS
     */
    
    public MetricResult getMeanCRPSWithNulls(final DoubleMatrix2D data, final double nV) {
        final double[][] d = data.toArray();
        int actualRows = 0;
        double totCRPS = 0.0;
        for(int i = 0; i < d.length; i++) {
            try {
                totCRPS = totCRPS + getCRPSSingleCase(d[i],nV);
                actualRows+=1;
            }
            catch(final Exception e) {
                //Do nothing
            }
        }
        
        int minCount = ((MinimumSampleSizeParameter)pars[4]).getParVal();
        lastCount = actualRows;
        if(actualRows < minCount) {
            throw new MetricCalculationException("Could not compute the mean CRPS: fewer samples than required ["+actualRows+","+minCount+"].");
        }
        
        final double mC=totCRPS/actualRows;
        final DecomposeParameter p = (DecomposeParameter)pars[1];
        if(p.getParVal()) {
            System.out.println("Cannot compute CRPS decomposition for selected method (method with nulls): select alternative CRPS method for decomposition.");
        }
        return new EnsembleScoreDecomposition(NONE,new DenseDoubleMatrix1D(new double[]{mC,Metric.NULL_DATA,Metric.NULL_DATA,Metric.NULL_DATA,Metric.NULL_DATA}));
    }

    /**
     * Returns the CRPS for each verification pair within the input array.
     * Optionally, the forecast may be normalized by (y-E[Y])*Var[Y]^-1 and the
     * observation by x-E[Y]. The results comprise the following columns:
     *
     * Column 0: the CRPS
     * Column 1: the observed value (not normalized)
     * Column 2: the forecast mean (not normalized)
     * Column 3: the forecast median (not normalized)
     * Column 4: the forecast mode (not normalized)
     * Column 5: the error of the forecast mean (E[Y]-x) (not normalized)
     * Column 6: the forecast spread (not normalized)
     *
     * @param data the input data
     * @param nV the null value identifier
     * @param normalize is true to normalize the CRPS for each verification pair by the forecast mean and spread
     * @throws MetricCalculationException
     */

    public static double[][] getCRPSScatter(final double[][] data, final double nV, final boolean normalize) throws MetricCalculationException {
        final double[][] returnMe = new double[data.length][7];
        for(int i = 0; i < returnMe.length; i++) {
            double[] d = returnMe[i];
            //Add the required statistics
            returnMe[i][1]=data[i][0];
            final double[] fcst = new double[d.length-1];
            System.arraycopy(returnMe[i],1,fcst,0,d.length-1);
            returnMe[i][2]=FunctionLibrary.mean().apply(new DenseDoubleMatrix1D(fcst),nV);
            returnMe[i][3]=FunctionLibrary.median().apply(new DenseDoubleMatrix1D(fcst),nV);
            returnMe[i][4]=FunctionLibrary.mode().apply(new DenseDoubleMatrix1D(fcst),nV);
            returnMe[i][5]=returnMe[i][2]-returnMe[i][1];
            returnMe[i][6]=FunctionLibrary.stdev().apply(new DenseDoubleMatrix1D(fcst),nV);
            if(normalize) {
                d = new double[returnMe[i].length];
                for(int j = 0; j < d.length; j++) {
                    if(returnMe[i][j]!=nV) {
                        d[j]=(returnMe[i][j]-returnMe[i][2])/returnMe[i][6];
                    } else {
                        d[j]=nV;
                    }
                }
            }
            returnMe[i][0]=getCRPSSingleCase(d,nV);
        }
        return returnMe;
    }

    /**
     * Returns the CRPS for a single case, comprising the observation in the
     * first entry and the ensemble members in the remaining entries.
     *
     * @param data the input data
     * @param nV the null value identifier
     * @throws MetricCalculationException
     */

    public static double getCRPSSingleCase(final double[] data, final double nV) throws MetricCalculationException {
        if(data==null) {
            throw new MetricCalculationException("Ensemble forecast cannot be null.");
        }
        if(data.length < 3) {
            throw new MetricCalculationException("Specify an ensemble forecast with at least two members.");
        }
        if(data[0]==nV) {
            throw new MetricCalculationException("Observation cannot be null.");
        }
        final int length = data.length-1;
        int nullCount = 0;
        final double obs = data[0];
        final double[] temp = new double[length];
        int nxt = 0;
        final int st = length+1;
        for(int i = 1; i < st;i++) {
            if(data[i]==nV) {
                nullCount+=1;
            }
            else {
                temp[nxt]=data[i];
                nxt++;
            }
        }
        if((length-nullCount) < 2) {
            throw new MetricCalculationException("Ensemble forecast must contain at least two non-null members.");
        }
        final double[] s = new double[length-nullCount];
        final int tot = s.length;
        System.arraycopy(temp,0,s,0,tot);
        Arrays.sort(s);
        final int stop = tot-1;
        double totCRPS = 0;
        for(int i = 0; i < stop; i++) {
            double alpha = 0;
            double beta = 0;
            //Outlier low
            if(i==0 && obs<s[0]) {
                beta = s[0]-obs;
            }
            //Outlier high
            else if(i==(stop-1) && obs>s[stop]) {
                alpha = obs-s[stop];
            }
            //Remaining three cases
            else {
                if (obs > s[i + 1]) {
                    alpha = s[i + 1] - s[i];
                } else if (obs < s[i]) {
                    beta = s[i + 1] - s[i];
                } else {
                    alpha = obs - s[i];
                    beta = s[i + 1] - obs;
                }
            }
            final double p = (i+1.0)/tot;
            totCRPS+=(alpha*p*p)+beta*((1.0-p)*(1.0-p));
        }
        return totCRPS;
    }

    /**
     * Returns the mean CRPS from the input data.  The input should comprise one
     * column of observations (at index 0) and the remaining n columns should
     * comprise the n ensemble members (index 1 through n-1).  This method can
     * handle forecasts with null ensemble members, but cannot compute the
     * decomposition.
     *
     * ******THIS METHOD CONTAINS ERRORS******.
     *
     * @param data the input data
     * @param nV the null value
     * @return the mean CRPS
     * @deprecated
     */

    @Deprecated
    public MetricResult getMeanCRPSWithNullsDeprecated(final DoubleMatrix2D data, final double nV) {
        double totCRPS = 0.0;  //Total CRPS across all forecasts, to average at end
        final int rows = data.getRowCount();
        final int cols = data.getColumnCount();
        final int aCols = cols-1;
        int actualRows = 0;
        //Iterate through the forecasts
        final DoubleMatrix2D fcasts = (DoubleMatrix2D)data.getSubmatrixByColumn(1,aCols);
        for(int i = 0; i < rows; i++) {
            final double obs = data.get(i,0);
            if(obs != nV) {  //Ignore cases where observation is null
                final DoubleMatrix1D fc = (DoubleMatrix1D) fcasts.getRowAt(i);
                //Get sorted forecasts
                double[] fcs = (double[]) fc.deepCopy().getMatrixValues();

                final Vector<Integer> ind = new Vector();
                //Strip all null values
                for(int j = 0; j < fcs.length; j++) {
                    if(fcs[j]!=nV) {
                        ind.add(j);
                    }
                }
                //Some non-null forecasts: proceed
                if (ind.size() > 0) {
                    final double[] d = new double[ind.size()];
                    for(int j = 0; j < d.length; j++) {
                        d[j]=fcs[ind.get(j)];
                    }
                    fcs = d;
                    Arrays.sort(fcs);  //Sorted ensemble members

                    //First determine the point-based CRPS values at the members
                    final double[] crps_p = new double[fcs.length];
                    double crps_i = 0;  //CRPS for the ith forecast
                    final double dist = 1.0 / fcs.length;  //Step size in empirical forecast cdf
                    for (int j = 0; j < fcs.length; j++) {
                        double obsP = 0.0;
                        if (obs <= fcs[j]) {
                            obsP = 1.0;  //Observation assumes probability 1 if less than current member
                        }
                        final double fcP = dist * (j + 1);  //Cumulative forecast probability at member j
                        crps_p[j] = Math.pow(fcP - obsP, 2);  //Squared difference in probability at member j
                    }
                    //Integrate point-based CRPS
                    for (int j = 1; j < crps_p.length; j++) {
                        //Observation is between members, then we have a weighted average
                        if(obs<fcs[j]&&obs>fcs[j-1]) {  //02/25/09 start new logic
                            final double diff = fcs[j]-fcs[j-1];
                            final double frac1 = (obs-fcs[j-1])/diff;  //Fraction at obs prob = 0.0
                            final double frac2 = 1.0-frac1;  //Fraction at obs prob = 1.0
                            crps_i += (((crps_p[j]*(fcs[j]-obs))*frac2) + ((crps_p[j-1]*(obs-fcs[j-1]))*frac1));
                        } //02/25/09 end new logic
                        else {
                            crps_i += (((crps_p[j] + crps_p[j - 1]) / 2.0) * (fcs[j] - fcs[j - 1]));
                        }
                    }
                    //Add area above or below if observation is out of range
                    if (obs < fcs[0]) {  //Observation misses low
                        crps_i += Math.abs(fcs[0] - obs);  //Diff in probs = 1.0 = (1.0*1.0)*area
                    }
                    else if (obs > fcs[fcs.length-1]) { //Observation misses high
                        crps_i += Math.abs(fcs[fcs.length-1] - obs);
                    }
                    totCRPS += crps_i;  //Increment total CRPS
                    actualRows += 1;  //Increment total forecasts used
                }
            }
        }
        int minCount = ((MinimumSampleSizeParameter)pars[4]).getParVal();
        lastCount = actualRows;
        if(actualRows < minCount) {
            throw new MetricCalculationException("Could not compute the mean CRPS: fewer samples than required ["+actualRows+","+minCount+"].");
        }
        final double mC=totCRPS/actualRows;
        final DecomposeParameter p = (DecomposeParameter)pars[1];
        if(p.getParVal()) {
            System.out.println("Cannot compute CRPS decomposition for selected method (method with nulls): select alternative CRPS method for decomposition.");
        }
        return new EnsembleScoreDecomposition(NONE,new DenseDoubleMatrix1D(new double[]{mC,nV,nV,nV}));
    }

    /*******************************************************************************
     *                                                                             *
     *                             PROTECTED METHODS                               *
     *                                                                             *
     ******************************************************************************/
        
    /**
     * Is true to silence the standard output from the Hersbach method for CRPS 
     * when one or more pairs contain missing members.
     * 
     * @param silenceHersbach is true to silence
     */

    protected void setSilenceHersbach(final boolean silenceHersbach) {
        this.silenceHersbach = silenceHersbach;
    }

    /**
     * Sets the lead time to include in any warning on standard out when pairs
     * are eliminated by the Hersbach algorithm.
     *
     * @param warnLead the lead time for warning on standard out
     */

    protected void setLeadForHersbachWarn(final Double warnLead) {
        this.warnLead = warnLead;
    }

    /**
     * Sets the threshold to include in any warning on standard out when pairs
     * are eliminated by the Hersbach algorithm.
     *
     * @param warnThresh the threshold for warning on standard out
     */

    protected void setThresholdForHersbachWarn(final DoubleProcedureParameter warnThresh) {
        this.warnThresh = warnThresh;
    }

    /*******************************************************************************
     *                                                                             *
     *                                  TEST METHOD                                *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Test method.
     *
     * @param args the args
     */

    public static void main(final String[] args) {

        System.out.println(getCRPSSingleCase(new double[]{1.7,0.8,3.5,2.5,4.5,8.5},-999));


        final double[][] data = new double[100][51];
        for(int i = 0; i < data.length; i++) {
            data[i][0] = 0.5;  //Obs
            for(int j = 1; j < 50; j++) {
                data[i][j] = Math.random();
            }
        }
        //DenseDoubleMatrix2D data2 = new DenseDoubleMatrix2D(data);
        //MetricResult me = getMeanCRPS(data2);
        //System.out.println("Mean CRPS based on "+data.length+" uniform random numbers: "+me);
    }
    
}
    