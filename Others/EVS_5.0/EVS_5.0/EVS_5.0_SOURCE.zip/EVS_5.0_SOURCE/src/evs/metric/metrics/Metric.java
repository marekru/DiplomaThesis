package evs.metric.metrics;

//EVS dependencies
import evs.metric.*;
import evs.metric.parameters.*;
import evs.utilities.mathutil.*;
import evs.data.*;
import evs.utilities.matrix.*;
import evs.analysisunits.*;
import evs.data.fileio.GlobalUnitsReader;
import evs.metric.results.*;

//Java util dependencies
import java.util.*;

//Java net dependencies
import java.net.URL;

//Java lang dependencies
import java.lang.reflect.InvocationTargetException;

/**
 * An abstract base class for verification metrics.  A single metric may store 
 * verification results for multiple forecast types, including MetricResult.REGULAR_FORECAST,
 * MetricResult.CLIMATOLOGICAL_FORECAST and MetricResult.PERSISTENCE_FORECAST. 
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public abstract class Metric implements Comparable {

    /********************************************************************************
     *                                                                              *
     *                                CLASS VARIABLES                               *
     *                                                                              *
     *******************************************************************************/    
    
    /**
     * Identifier for an {@link evs.metric.metrics.BrierScore}.
     */
    
    public static final int BRIER_SCORE = 701;

    /**
     * Identifier for an {@link evs.metric.metrics.MeanContRankProbScore}.
     */
    
    public static final int CRPS = 702;

    /**
     * Identifier for an {@link evs.metric.metrics.Correlation}.
     */
    
    public static final int CORRELATION = 703;

    /**
     * Identifier for an {@link evs.metric.metrics.MeanCaptureRateDiagram}.
     */
    
    public static final int MCRD = 704;
    
    /**
     * Identifier for an {@link evs.metric.metrics.MeanError}.
     */
    
    public static final int MEAN_ERROR = 705;
    
    /**
     * Identifier for an {@link evs.metric.metrics.ModifiedBoxPlotPooledByLead}.
     */
    
    public static final int BOX_DIAGRAM_POOLED_BY_LEAD = 706;
    
    /**
     * Identifier for an {@link evs.metric.metrics.ModifiedBoxPlotUnpooledByLead}.
     */
    
    public static final int BOX_DIAGRAM_UNPOOLED_BY_LEAD = 707;    
    
    /**
     * Identifier for an {@link evs.metric.metrics.ModifiedBoxPlotUnpooledByLeadObs}.
     */
    
    public static final int BOX_DIAGRAM_UNPOOLED_BY_LEAD_OBS = 708;        
    
    /**
     * Identifier for an {@link evs.metric.metrics.RelativeOperatingCharacteristic}.
     */
    
    public static final int ROC = 709;
    
    /**
     * Identifier for an {@link evs.metric.metrics.ReliabilityDiagram}.
     */
    
    public static final int RELIABILITY_DIAGRAM = 710;    
            
    /**
     * Identifier for an {@link evs.metric.metrics.RootMeanSquareError}.
     */
    
    public static final int RMSE = 711;
    
    /**
     * Identifier for an {@link evs.metric.metrics.SpreadBiasDiagram}.
     */
    
    public static final int SPREAD_BIAS_DIAGRAM = 712;
    
    /**
     * Identifier for an {@link evs.metric.metrics.SpreadBiasDiagram}
     * centered around the forecast median.
     */
    
    public static final int MEDIAN_CENTRAL_SPREAD_BIAS = 713;
    
    /**
     * Identifier for an {@link evs.metric.metrics.MeanErrorOfProbabilityDiagram}.
     */
    
    public static final int MEPD = 714;
    
    /**
     * Identifier for an {@link evs.metric.metrics.ROCScore}.
     */
    
    public static final int ROCS = 715;       

    /**
     * Identifier for an {@link evs.metric.metrics.SampleSize}.
     */
    
    public static final int SAMPLE_SIZE = 716;         
    
    /**
     * Identifier for an {@link evs.metric.metrics.BrierSkillScore}.
     */
    
    public static final int BRIER_SKILL_SCORE = 717;       
    
    /**
     * Identifier for an {@link evs.metric.metrics.MeanContRankProbSkillScore}.
     */
    
    public static final int CRPS_SKILL_SCORE = 718;  
    
    /**
     * Identifier for an {@link evs.metric.metrics.RankHistogram}.
     */
    
    public static final int RANK_HISTOGRAM = 719;      
    
    /**
     * Identifier for an {@link evs.metric.metrics.MeanAbsoluteError}.
     */

    public static final int MEAN_ABSOLUTE_ERROR = 725;

    /**
     * Identifier for an {@link evs.metric.metrics.RelativeMeanError}.
     */

    public static final int RELATIVE_MEAN_ERROR = 726;

    /**
     * Identifier for an {@link evs.metric.metrics.SingleValuedQQPlot}
     */

    public static final int SVQQ = 727;

    /**
     * Indicator for zero samples.
     */
    
    public static final int ZERO_SAMPLES = 0;     
    
    /**
     * Indicator for null data (e.g. in a plotting position).
     */
    
    public static final double NULL_DATA = GlobalUnitsReader.getDefaultNullValue();
    
    /********************************************************************************
     *                                                                              *
     *                     INSTANCE VARIABLES TO SET IN SUBCLASSES                  *
     *                                                                              *
     *******************************************************************************/    
    
    /**
     * Name of the metric.
     */
    
    protected String name = null;
    
    /**
     * A store containing a metric result for one or more forecast types.  The
     * metric result is stored in a wrapper class of type evs.metric.MetricResultByLeadTime,
     * which stores a metric result for each lead time.  See the MetricResult 
     * class for forecast type identifiers. 
     */
    
    protected TreeMap<Integer,MetricResultByLeadTime> results =
            new TreeMap<Integer,MetricResultByLeadTime>();
  
    /**
     * Store of sample counts by forecast type for the last computation.
     */

    protected TreeMap<Integer,MetricResultByLeadTime> counts =
            new TreeMap<Integer,MetricResultByLeadTime>();
    
    /**
     * Sample count for the current calculation.
     */
    
    protected int lastCount = ZERO_SAMPLES;          
    
    /**
     * A URL to a description of the metric.
     */
    
    protected URL descriptionURL = null;
    
    /**
     * The parameter values of the metric.
     */
    
    protected MetricParameter[] pars = null; 
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/    
    
    /**
     * Returns an identifier for the metric from the list of static final
     * variables in this class.
     *
     * @return an identifier
     */
    
    public abstract int getID();     
    
    /**
     * Return an identifier for the result type associated with the metric.
     * See {@link evs.metric.results.MetricResult} for supported types.
     *
     * @return a result identifier
     */
    
    public abstract int getResultID();     
        
    /**
     * Returns true if the metric is defined in real units of the forecast
     * and observed variable, false otherwise.
     * 
     * @return true if the metric is defined in real units
     */    

    public abstract boolean hasRealUnits();
    
    /**
     * Returns a deep copy of the current metric, where all instance variables 
     * occupy independent positions in memory from the current metric.  Results
     * are also deep copied.  See {@link #deepCopyResults(evs.metric.metrics.Metric)}
     *
     * @return a deep copy of the current object 
     */
    
    public abstract Metric deepCopy();

    /**
     * Convenience method that returns true if the following two conditions are met:
     * 
     * 1) the implementing class extends {@link BootstrapableMetric}
     * OR is a metric store that comprises metrics that extend this class, and;
     * 
     * 2) the bootstrapable metric or store of metrics has a bootstrap parameter
     * with a technique identifier other than {@link BootstrapableMetric#NO_BOOTSTRAP}.
     *
     * @return true if the bootstrap parameter has been set
     */

    public boolean isBootstrap() {
        if (this instanceof BootstrapableMetric) {
            return ((BootstrapableMetric)this).getBootstrapPar().isBootstrap();
        } else if (this instanceof ThresholdMetricStore) {
            Metric first = ((ThresholdMetricStore) this).getFirstMetricInStore();
            if (first instanceof BootstrapableMetric) {
                return ((BootstrapableMetric)first).getBootstrapPar().isBootstrap();
            }
        }
        return false;
    }

    /**
     * Convenience method that returns true if the implementing class extends
     * {@link evs.metric.metrics.SkillScore} OR if a metric store comprises metrics that
     * extend this class.
     *
     * @return true if the metric is a skill score
     */

    public boolean isSkillMetric() {
        if (this instanceof SkillScore) {
            return true;
        } else if (this instanceof ThresholdMetricStore) {
            Metric first = ((ThresholdMetricStore) this).getFirstMetricInStore();
            if (first instanceof SkillScore) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns true if the metric is defined for discrete events, false otherwise.
     *
     * @return true if the metric is defined for discrete events, false otherwise.
     */

    public boolean isDiscreteMetric() {
        if (this instanceof CategoricalMetric) {
            return true;
        } else if (this instanceof ThresholdMetricStore) {
            Metric first = ((ThresholdMetricStore) this).getFirstMetricInStore();
            if (first instanceof CategoricalMetric) {
                return true;
            }
        }
        return false;
    }

    /**
     * Convenience method that returns true if the implementing class extends
     * {@link evs.metric.metrics.SingleValuedMetric} OR if a metric store comprises metrics that
     * extend this class.
     *
     * @return true if the metric is a single valued metric
     */

    public boolean isSingleValuedMetric() {
        if (this instanceof SingleValuedMetric) {
            return true;
        } else if (this instanceof ThresholdMetricStore) {
            Metric first = ((ThresholdMetricStore) this).getFirstMetricInStore();
            if (first instanceof SingleValuedMetric) {
                return true;
            }
        }
        return false;
    }

    /**
     * Convenience method that returns true if the implementing class extends
     * {@link evs.metric.metrics.EnsembleMetric} OR if a metric store comprises metrics that
     * extend this class.
     *
     * @return true if the metric is a single valued metric
     */

    public boolean isEnsembleMetric() {
        if (this instanceof EnsembleMetric) {
            return true;
        } else if (this instanceof ThresholdMetricStore) {
            Metric first = ((ThresholdMetricStore) this).getFirstMetricInStore();
            if (first instanceof EnsembleMetric) {
                return true;
            }
        }
        return false;
    }

    /**
     * Convenience method for returning the reference forecast identifier of a skill
     * metric.  Throws an exception if this is not a skill metric.
     *
     * @return the reference forecast identifier
     */

    public String getRefFcstID() {
        if(!isSkillMetric()) {
            throw new IllegalArgumentException("Metric '"+this+"' is not a skill metric and does "
                    + "not have a reference forecast.");
        }
        String ref = "";
        if(this instanceof SkillScore) {
            ref = ((ReferenceForecastParameter)
                    getPar(MetricParameter.REFERENCE_FORECAST_PARAMETER)).getParVal();
        } else if(this instanceof ThresholdMetricStore) {
            ref = ((ThresholdMetricStore)this).getFirstMetricInStore().getRefFcstID();
        }
        return ref;
    }

    /**
     * Returns a metric with default parameter values.  This method should be
     * hidden in the concrete subclasses AND called from there, otherwise
     * the current method will return null.  This is simply a reminder to 
     * hide the static method in the concrete subclass.
     *
     * @return a metric with default parameter values.
     */
    
    public static Metric getDefaultMetric() {
        throw new IllegalArgumentException("Forgot to call or hide the static method Metric.getDefaultMetric() in a subclass.");
    }
    
    /**
     * Returns a named metric with default parameter values by using reflection on 
     * the class name of the metric and then calling getDefaultMetric(), which must
     * be hidden in the concrete subclass to return a non-null value (see above).
     *
     * @param name the class name of the metric
     * @return a metric with default parameter values.
     */
    
    public static Metric getDefaultMetric(String name) throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        Class c = Class.forName("evs.metric.metrics."+name);
        return (Metric)c.getMethod("getDefaultMetric",(Class[])null).invoke((Object[])null);        
    }    
    
    /**
     * Aggregates a set of metrics using the specified function and returns the  
     * aggregated metric.  Throws an exception if more than one type of metric
     * is provided or the metric parameters are different.  The results are 
     * aggregated by lead period.  Specify a set of weights to use in the aggregation.
     * The weights are constant cross all lead times.
     * 
     * @param metrics the input metrics
     * @param func the aggregation function
     * @param weights the weights assigned to each input
     * @return the aggregated metric
     */
    
    public static Metric aggregate(Metric[] metrics, VectorFunction func,double[] weights) throws MetricCalculationException {
        //Check for non-null metrics and aggregation function
        MetricCalculationException m = new MetricCalculationException("Error aggregating metrics of type '"+metrics[0]+"'. Cannot aggregate the input metrics as one or more of them are null.");
        if(metrics.length == 0 || metrics[0] == null) {
            throw m;
        }
        if(func == null) {
            throw new MetricCalculationException("Error aggregating metrics of type '"+metrics[0]+"'.  Cannot aggregate with a null aggregation function.");
        }
        //Check for non-null metrics with the same parameter values
        MetricCalculationException n = new MetricCalculationException("Error aggregating metrics of type '"+metrics[0]+"'. Cannot aggregate the input metrics as one or more of them do not have results.");
        if(!metrics[0].hasResults()) {
            throw n;
        }
        for(int i = 1; i < metrics.length; i++) {
            if(metrics[i]==null) {
                throw m;
            }
            if(!metrics[i].hasResults()) {
                throw n;
            }
            if(!metrics[i].paramEquals(metrics[0],false)) {
                throw new MetricCalculationException("Error aggregating metrics of type '"+metrics[0]+"'. Cannot aggregate the input metrics as they have different parameter values.");
            }
        }
        
        //Check the weights
        if(weights == null) {
            throw new IllegalArgumentException("Error aggregating metrics of type '"+metrics[0]+"'. The aggregation weights must be non-null.");
        }
        if(metrics.length != weights.length) {
            throw new IllegalArgumentException("Error aggregating metrics of type '"+metrics[0]+"'. The number of weights must match the number of verification metrics.");
        }
        double sum = FunctionLibrary.total().apply(new DenseDoubleMatrix1D(weights));
        if(sum<0.9999 || sum > 1.0001) {
            throw new IllegalArgumentException("Error aggregating metrics of type '"+metrics[0]+"'. Weights must sum to 1.0: "+sum);
        }        
        
        //Aggregate by lead time for each forecast type present
        Metric copy = metrics[0].deepCopy();
        TreeMap<Integer,MetricResultByLeadTime> first = copy.getResults();
        TreeMap<Integer,MetricResultByLeadTime> rs = new TreeMap<Integer,MetricResultByLeadTime>();
        TreeMap<Integer,MetricResultByLeadTime> cnts = new TreeMap<Integer,MetricResultByLeadTime>();
        copy.lastCount=ZERO_SAMPLES;  //Remove local count data
        
        //NOTE: no count data are present if the metric is a store
        for(Iterator i = first.keySet().iterator(); i.hasNext();) {
            Integer nextType = (Integer)i.next();
            //Iterate through the results for the current type
            MetricResultByLeadTime[] res = new MetricResultByLeadTime[metrics.length];
            //Sum the forecast counts by forecast type
            MetricResultByLeadTime[] counts = new MetricResultByLeadTime[metrics.length];
            int sampleCount = 0;
            for(int j = 0; j < metrics.length; j++) {
                res[j]=metrics[j].getResult(nextType);
                if(metrics[j].hasSampleCounts()) {  //Not a store
                    counts[j]=metrics[j].getSampleCounts(nextType);
                    sampleCount++;
                }
            }
            //Store results
            MetricResultByLeadTime r = (MetricResultByLeadTime)res[0].aggregate(res,func,weights);
            rs.put(nextType,r); //Aggregation
            if(sampleCount>0) {
                MetricResultByLeadTime aggCounts = (MetricResultByLeadTime)res[0].aggregate(counts,FunctionLibrary.total(),weights);
                cnts.put(nextType,aggCounts);
            }
        }
        if(cnts.size()>0) {
            copy.counts=cnts;
        }
        copy.results=rs;
        return copy;
    }   
    
    /**
     * Returns the string name of this metric.
     *
     * @return the string name.
     */ 
    
    public String getName() {
        return name;
    }
    
    /**
     * Returns the number of parameters associated with this metric.
     *
     * @return the number of parameters
     */
    
    public int getParCount() {
        return pars.length;
    }  
    
    /**
     * Returns the classes of the parameters required by the metric in the same
     * order as they are required.
     *
     * @return the parameter classes
     */
    
    public Class[] getParClasses() {
        Class[] returnMe = new Class[pars.length];
        for(int i = 0; i < returnMe.length; i++) {
            returnMe[i]=pars[i].getClass();
        }
        return returnMe;
    }
    
    /**
     * Returns the number of samples (forecast-observation pairs) associated with 
     * the threshold metric or NONE_DEFINED, ordered by lead time, for the specified
     * forecast type.  Throws an exception if the samples are unavailable.  Call 
     * {@link #hasSampleCounts(int)} first.
     *
     * @param forecastType the forecast type
     * @return the sample count
     */
    
    public MetricResultByLeadTime getSampleCounts(int forecastType) throws IllegalArgumentException {
        if(! counts.containsKey(forecastType) || !results.containsKey(forecastType)) {
            throw new IllegalArgumentException("No sample counts available for the specified forecast type.");
        }
        return (MetricResultByLeadTime)counts.get(forecastType).deepCopy();
    }    
    
    /**
     * Returns the parameter types required by the metric in the order in which
     * they are required. See the MetricParameter class for the integer identifiers. 
     *
     * @return the parameter types
     */
    
    public int[] getParTypes() throws IllegalArgumentException {
        try {
            int[] ids = new int[pars.length];
            for(int i = 0; i < ids.length; i++) {
                ids[i] = pars[i].getID();
            }
            return ids;
        } catch(Exception e) {
            e.printStackTrace();
            throw new IllegalArgumentException("Could not determine parameter types for metric "+toString());
        }
    }
    
    /**
     * Returns a metric result of a specified type or null if the metric result
     * is undefined for that type (i.e. must be recomputed).  
     * 
     * If the type is unrecognized, throw an IllegalArgumentException. 
     * Call hasResult(forecastType) to establish whether a result exists for a given forecast type.
     * 
     * @param forecastType the type of result required (see the ForecastTypeParameter class)
     * @return the metric result or null
     */
    
    public MetricResultByLeadTime getResult(int forecastType) throws IllegalArgumentException {
        ForecastTypeParameter.isSupportedForecastType(forecastType, true);
        if(!results.containsKey(forecastType)) {
            throw new IllegalArgumentException("Result store for metric '"+this+"' does not contain a result "
                    + "with identifier: "+forecastType+".");
        }
        return (MetricResultByLeadTime)results.get(forecastType).deepCopy();
    }
    
    /**
     * Returns a shallow copy of all metric results in a new map. 
     *
     * @return the metric results
     */
    
    public TreeMap<Integer,MetricResultByLeadTime> getResults() {
        TreeMap<Integer,MetricResultByLeadTime> map = new TreeMap<Integer,MetricResultByLeadTime>();
        Iterator it = results.keySet().iterator();
        while(it.hasNext()) {
            int next = (Integer)it.next();
            map.put(next,(MetricResultByLeadTime)results.get(next).deepCopy());
        }
        return map;
    }
    
    /**
     * Returns the parameters associated with a verification metric in a parameter 
     * array.  
     *
     * @return the parameters
     */
    
    public MetricParameter[] getParameters() {
        MetricParameter[] returnMe = new MetricParameter[pars.length];
        for(int i = 0; i < returnMe.length; i++) {
            returnMe[i] = pars[i].deepCopy();
        }
        return returnMe;
    }   
    
    /**
     * Returns a deep copy of the specified parameter type or null if the type
     * does not exist.
     * 
     * @param type one of static final variables in MetricParameter
     * @return the specified parameter type
     */
    
    public MetricParameter getParameter(int type) {
        MetricParameter par = getPar(type);
        if(par!=null) {
            par = par.deepCopy();
        }
        return par;
    }
    
    /**
     * Returns true if sample counts are available for the specified forecast type,
     * false otherwise.
     *
     * See the ForecastTypeParameter class for the allowed types.
     *
     * @param forecastType the forecast type
     * @return true if sample counts are available.
     */
    
    public boolean hasSampleCounts(int forecastType) {
        ForecastTypeParameter.isSupportedForecastType(forecastType, true);
        return counts.containsKey(forecastType) 
                && results.containsKey(forecastType);
    }
    
    /**
     * Returns true if sample counts are available for one or more forecast types.
     *
     * @return true if sample counts are available.
     */
    
    public boolean hasSampleCounts() {
        return counts.size() > 0;
    }    
    
    /**
     * Returns a deep copy of the sample counts.
     *
     * @return a deep copy of the sample counts
     */
    
    public TreeMap<Integer,MetricResultByLeadTime> getSampleCounts() {
        TreeMap<Integer,MetricResultByLeadTime> meta = new TreeMap<Integer,MetricResultByLeadTime>();
        Iterator i = counts.keySet().iterator(); 
        while(i.hasNext()) {
            Integer next = (Integer)i.next();
            meta.put(next,(MetricResultByLeadTime)counts.get(next).deepCopy());
        }
        return meta;
    }
    
    /**
     * Returns true if the metric has a result for the specified forecast type.
     *
     * See the ForecastTypeParameter class for the allowed types.
     *
     * @param forecastType the forecast type
     * @return true if the result exists, false otherwise
     */
    
    public boolean hasResult(int forecastType) {
        ForecastTypeParameter.isSupportedForecastType(forecastType, true);
        return results.containsKey(forecastType);
    }
    
    /**
     * Returns true if the metric has some results available.
     *
     * See the ForecastTypeParameter class for the allowed types.
     *
     * @return true if the results exist, false otherwise
     */
    
    public boolean hasResults() {
        return results.size()>0;
    }
    
    /**
     * Returns true if the metric comprises a parameter with the specified parameter 
     * type identifier, false otherwise. See {@link evs.metric.parameters.MetricParameter} 
     * for supported parameter-type identifiers.
     * 
     * @param parType the parameter type
     * @return true if the metric comprises a parameter of the specified type, false otherwise
     */
    
    public boolean hasParType(int parType) {
        for(MetricParameter p: pars) {
            if(p.getID()==parType) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Returns true if the specified parameters will void a current result if used
     * to replace the existing parameters.  A result will be void if it exists, the 
     * input parameters are valid and differ from the current parameters. 
     *
     * Currently, this method checks for the presence of any results, rather than
     * results for a specific forecast type.
     *
     * @return true if a result will be void by the specified parameters
     */
    
    public boolean willVoidResult(MetricParameter[] pars) {
        //If the input parameters are invalid, they cannot void a result
        if(hasResults() && this.pars != null && pars != null && pars.length == this.pars.length) {
            for(int i = 0; i < this.pars.length; i++) {
                if(!this.pars[i].equals(pars[i])) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Returns true if conditions on the pairs will be ignored, false to use
     * the conditional pairs if available.
     *
     * @return true if conditions on the pairs will be ignored.
     */
    
    public boolean willIgnoreConditions() {
        for(int i = 0; i < pars.length; i++) {
            if(pars[i] instanceof UnconditionalParameter) {
                return((UnconditionalParameter)pars[i]).getParVal();
            }
        } 
        throw new IllegalArgumentException("Parameter to use conditional/unconditional pairs not set.");
    }    
    
    /**
     * Convenience method that returns true of the metric has dichotomous thresholds 
     * associated with it, false otherwise.
     *
     * @return true if the metric has dichotomous thresholds associated with it
     */
    
    public boolean hasThresholds() {
        for(int i = 0; i < pars.length; i++) {
            if(pars[i].getClass().equals(DoubleProcedureArrayParameter.class)) {
                return true;
            }
        }
        return false;
    }    
    
    /**
     * Returns true if the metric has a parameter value that indicates the 
     * specified result WILL be computed, regardless of whether it is currently
     * available.  If so, the result will become available on next calling
     * compute().  See the ForecastTypeParameter class for available types.
     *
     * @return true if a parameter value indicates the specified result will be computed
     */
    
    public boolean willCompute(int forecastType) {
        ForecastTypeParameter.isSupportedForecastType(forecastType, true);
        if(pars != null) {
            //Regular forecast always computed
            if(forecastType == ForecastTypeParameter.REGULAR_FORECAST) {
                return true;
            }
            for(int i = 0; i < pars.length; i++) {
                if(pars[i] instanceof ForecastTypeParameter) {
                    return ((ForecastTypeParameter)pars[i]).willDo(forecastType);
                }
            }
        }
        return false;
    }

    /**
     * Returns an html description for this metric.
     * 
     * @return an html description
     */
    
    public URL getDescriptionURL() {
        return descriptionURL;
    }        
    
    /**
     * Returns the string name of this metric.
     *
     * @return the string name.
     */ 
    
    public String toString() {
        return getName();
    }
    
    /**
     * Tests for equality of the metric type and parameters.  
     *
     * @param m the metric 
     * @param checkRefForecasts is true to check reference forecast parameters
     */
    
    public boolean paramEquals(Metric m, boolean checkRefForecasts) {
        if(!m.getClass().equals(getClass())) {
            return false;
        }
        for(int i = 0; i < pars.length; i++) {
            if(checkRefForecasts || !(pars[i] instanceof ReferenceForecastParameter)) {
                if (!pars[i].equals(m.pars[i])) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Tests for equality of the metric name.  
     *
     * @param o the object to test for equality
     */
    
    public boolean equals(Object o) {
        if(o==null) {
            return false;
        }
        return toString().equals(o.toString());
    }    
    
    /**
     * Allows storage in a map where comparable is adopted.  Returns an integer 
     * depending on the relationship between the string representation of this 
     * object and the string representation of the input.  Throws an exception
     * if the input is not an {@link Metric}.
     *
     * @param o the test object
     * @return an integer < 0 if less, > 0 if greater or 0 if equal
     */
    
    public int compareTo(Object o) {
        Metric m = (Metric)o;
        return toString().compareTo(m.toString());
    }
    
    /**
     * Override hashcode to allow storage in a hash map.  The hash code is based
     * on the string representation.
     *
     * @return a hash code
     */
    
    public int hashCode() {
        return toString().hashCode();
    }
    
    /********************************************************************************
     *                                                                              *
     *                                MUTATOR METHODS                               *
     *                                                                              *
     *******************************************************************************/        

    /**
     * Uses the specified paired data to compute and return the result of the metric.
     * The metric results are returned, together with the sample counts, but are
     * not stored locally.  The metric result is located in the first index of the 
     * returned array and the sample counts are located in the second index. 
     * Optionally, specify the results of a reference forecast from which to compute 
     * skill if the metric is a skill score. 
     * 
     * @param forecastType the forecast type
     * @param paired the paired data
     * @param refResult the results for a reference forecast (may be null)
     * @return the metric result and sample counts
     */
    
    public abstract MetricResult[] compute(int forecastType, PairedData paired, MetricResult refResult) throws MetricCalculationException;    
        
    /**
     * Uses the specified paired data to compute and store the result of the metric
     * for every forecast lead time in the input paired dataset.  
     * 
     * This method will overwrite the results of a previous calculation if one exists.  
     * It also assumes that all conditioning of the forecasts and observations has 
     * been completed.  Care should be taken to call this method each time the 
     * parameter values of the current metric are modified.  The metric result is 
     * computed for each lead period separately.  They are added to the local store 
     * with the associated sample counts, both of which are returned for convenience. 
     * 
     * If the current metric is a skill score, the reference forecast must be 
     * provided, unless the reference is sample climatology, otherwise an exception
     * will be thrown.  Only one reference forecast is currently supported, but
     * this may be changed in future.
     *
     * @param forecastType the forecast type
     * @param paired the paired data
     * @param reference the reference forecast (may be null, unless skill metric)
     * @param silent is true to silence printing of messages to standard out
     * @return the result 
     */
    
    public synchronized MetricResultByLeadTime computeByLeadTime(int forecastType, 
            PairedData paired, MetricResultByLeadTime reference, boolean silent) throws MetricCalculationException {
        ForecastTypeParameter.isSupportedForecastType(forecastType,true);

     /*
      * TODO: currently this method does not update the results for the individual
      * threshold metrics when the current metric is a ThresholdMetricStore.  If this is needed
      * in future, ensure that this method sets the results appropriately, which will
      * require implementation of setResult() in ThresholdMetricStore, as well as a
      * method setCount() for the individual sample count, implemented in this store
      * and to be overriden in ThresholdMetricStore.
      */

        //Must have results already available, unless sample climatology only
        boolean skill = false;
        boolean sampleClim = false;
        int fType = forecastType;
        double nV = paired.getNullValue();
        if(isSkillMetric()) {
            if(forecastType == ForecastTypeParameter.REGULAR_FORECAST) {
                skill = true;
                fType = ForecastTypeParameter.SKILL;
                if (reference == null) {
                    ReferenceForecastParameter r = null;
                    if(this instanceof ThresholdMetricStore) {
                        r = ((SkillScore)((ThresholdMetricStore) this)
                                .getFirstMetricInStore()).getRefFcst();
                    } else {
                        r = ((SkillScore) this).getRefFcst();
                    }
                    if (!r.isSampleClimatology()) {
                        throw new IllegalArgumentException("Cannot compute the skill score '" + this.getName() + "' as no "
                                + "results were found for a reference forecast: compute the reference forecast first.");
                    } else {
                        sampleClim = true;
                    }
                }
            } else {
                if(reference != null) {
                    throw new IllegalArgumentException("A non-null reference forecast was supplied for metric "
                            + "'"+this+"', but the forecast type is not consistent with a skill calculation: "
                            +forecastType);
                }
            }
        }
        //Set the metadata stores
        MetricResultByLeadTime localCounts = null;
        DoubleMatrix1D leadTimes = paired.getLeadTimes();
        //Construct a result for each lead time
        int length = leadTimes.getRowCount();
        MetricResultByLeadTime res = null;
        boolean thresholdMetric = this instanceof ThresholdMetric;
//        //Update parameters with real values
//        if (thresholdMetric) {
//            DoubleProcedureParameter pro = ((ThresholdMetric)this).getThreshold().
//                    getRealValuedEquivalent(paired.getClimObs(), AnalysisUnit.getNullValue());
//            DoubleProcedureParameter pt = ((ThresholdMetric)this).getThreshold();
//            if (pt.areProbs().getParVal()) {
//                pt.setRealValuesForProbs(pro.getThresholdValues());
//            }
//            ((ThresholdMetric)this).setThreshold(pt);
//        }
        
        //Iterate through the times
        for(int i = 0; i < length; i++) {
            double time = (Double)leadTimes.get(i);
            MetricResult refResult = null;

            //Get reference forecast result for specific time, unless sample climatology
            if(skill && !sampleClim) {
                if(reference.hasResult(time)) {
                    refResult = reference.getResult(time);
                } else {
                    throw new IllegalArgumentException("Could not compute '"+this+"' at lead time '"+time+"', "
                            + "as the reference forecast was missing. Reference forecast only available at "
                            + "lead times: "+reference.getLeadTimes());
                }
            }
//            //Silence Hersbach CRPS output if requested silent
//            if (this instanceof MeanContRankProbScore ||
//                    this instanceof MeanContRankProbSkillScore) {
//                ((MeanContRankProbScore) this).setSilenceHersbach(silent);
//                if (!silent) {
//                    ((MeanContRankProbScore) this).setLeadForHersbachWarn(time);
//                }
//            }
            try {
                DoubleMatrix2D p = paired.getPairsByLeadTime(time);
                PairedData d = new PairedData(p,false,nV);
                
                //JB@23/10/12 Failed to set climatological observations 
                d.setClimObsWithTimes(paired.getClimObsWithTimes());
                d.setUncClimObsWithTimes(paired.getUncClimObsWithTimes());
                
                MetricResult[] r = compute(forecastType,d,refResult);
                if(res == null && r[0]!=null) {
                    res = new MetricResultByLeadTime(r[0].getID());
                    localCounts = new MetricResultByLeadTime(r[1].getID());
                }
                if(r[0]!=null) {
                    res.addResult(time,r[0]);
                    localCounts.addResult(time,r[1]);
                } else if(!silent){
                    if(thresholdMetric) {
                        System.err.println("No data to compute "+getName()+" at time "+time+" for threshold "+pars[0]+".");
                    } else {
                        System.err.println("No data to compute "+getName()+" at time "+time+".");
                    }                   
                }
            }
            catch(Exception e) {
                System.out.println("Error computing "+getName()+" at lead time "+time+":");
                e.printStackTrace();
            }
        }
        if(res==null || !res.hasResults()) {
            throw new MetricCalculationException("No results available for metric "+getName()+".");
        } 
        else {
            //Store the metadata
            counts.put(fType,localCounts);
            //Store the results
            results.put(fType,res);  
        }
        return res;
    }    
    
    /**
     * Sets the parameters of the verification metric.  If the input parameter 
     * values imply that a metric must be recomputed for a given forecast type,
     * the existing result is removed from the result list and any reference
     * to a result file is removed.  Call willVoidResult(pars) to establish if an 
     * existing result will be voided by a change.  Throws an exception if the
     * parameters are inconsistent with the metric.
     * 
     * @param pars the parameters
     */
    
    public void setParameters(MetricParameter[] pars) throws IllegalArgumentException {
        //Check the parameters
        if(pars == null || (this.pars != null && pars.length != this.pars.length)) {
             if(pars != null) {
                System.err.println("Input par classes: ");
                for(int i = 0; i < pars.length; i++) {
                    if(pars[i]!= null) {
                        System.err.println(pars[i].getClass());
                    }
                    else {
                        System.err.println("Null input.");
                    }
                }
             }
             if(this.pars != null) {
                System.err.println("Expected par classes: ");
                for(int i = 0; i < this.pars.length; i++) {
                    System.err.println(this.pars[i].getClass());
                }
             }
             throw new IllegalArgumentException("Unexpected parameter types for metric '"+name+"'.");
        }
        //Check parameter classes.
        boolean clearResults = false;
        for(int i = 0; i < pars.length; i++) {
            if(pars[i]==null) {
                throw new IllegalArgumentException("Cannot specify a null parameter for a metric.");
            }
            //Check the par classes if not already set.  
            //This only happens when calling from the constructor of a concrete subclass.
            //The parameters are otherwise set on construction.
            if(this.pars != null) {
                if(!this.pars[i].getClass().equals(pars[i].getClass())) {
                    throw new IllegalArgumentException("Unexpected parameter types for metric '"+name+"'. Found '"
                            + ""+pars[i].getClass()+"', expected '"+this.pars[i].getClass()+"'.");
                }
                //Check the results and clear ONLY if parameter values have changed
                if(! pars[i].equals(this.pars[i])) {
                    clearResults = true;
                }
            }
        }
        //Clear results?
        if(clearResults && results.size() > 0) {
            //Clear all results: in future this may be refined to clear specific invalidated results
            System.out.println("Parameters changed for metric '"+toString()+"': results have been cleared.");
            clearResults();
            //results.clear();
            //counts.clear();
        }        
        this.pars = new MetricParameter[pars.length];
        for(int i = 0; i < pars.length; i++) {
            this.pars[i]=pars[i].deepCopy();
        }
    } 
    
   /**
     * Sets a metric result of a specified type, replacing any existing result.
     * Throws an exception if the result is of an unexpected type or the forecast 
     * type is unrecognized.
     * 
     * @param forecastType the type of result (see the ForecastTypeParameter class)
     * @param result the metric result to set
     */
    
    public void setResult(int forecastType, MetricResultByLeadTime result) throws IllegalArgumentException {
        ForecastTypeParameter.isSupportedForecastType(forecastType, true);
        if(getResultID() != result.getIDForStoredResults()) {
            throw new IllegalArgumentException("Unexpected result type for "+toString()+": "+getResultID()+" vs. "+result.getID());
        }
        if(!result.hasResults()) {
            throw new IllegalArgumentException("Could not add the results to the store: "
                    + "the input did not contain results for any forecast lead times.");
        }
        results.put(forecastType,result);
    }
    
   /**
     * Sets the metric results for specified result types, replacing any existing result.
     * Throws an exception if the result is of an unexpected type or the forecast 
     * type is unrecognized.
     * 
     * @param results the results
     * @param counts the sample counts (may be null)
     */
    
    public void setResults(TreeMap<Integer,MetricResultByLeadTime> results, TreeMap<Integer,MetricResultByLeadTime> counts) throws IllegalArgumentException {
        if(results.size()==0) {
            throw new IllegalArgumentException("Specify one or more results to set.");
        }
        if(counts != null && counts.size() != results.size()) {
            throw new IllegalArgumentException("Specify the same number of sample counts as results.");
        }
        Iterator i = results.keySet().iterator();
        try {
            while(i.hasNext()) {
                Integer in = (Integer)i.next();
                setResult(in,results.get(in));
            }
            //Assumes the forecast types 
            if(counts != null) {
                setSampleCounts(counts);
            }
        }
        catch(Exception e) {
            results.clear();
            counts.clear();
            throw new IllegalArgumentException(e.getMessage());
        }
    }
    
   /**
     * Sets the sample counts for existing metric results.  Throws an exception if the 
     * metadata is of an unexpected type or the forecast type is unrecognized.
     * 
     * @param counts the sample counts
     */
    
    public void setSampleCounts(TreeMap<Integer,MetricResultByLeadTime> counts) throws IllegalArgumentException {
        if(counts.size()==0) {
            throw new IllegalArgumentException("Specify valid sample counts.");
        }
        Iterator i = counts.keySet().iterator();
        TreeMap<Integer,MetricResultByLeadTime> meta = new TreeMap<Integer,MetricResultByLeadTime>();
        try {
            while(i.hasNext()) {
                Integer next = Integer.valueOf((Integer)i.next());
                ForecastTypeParameter.isSupportedForecastType(next, true);
                meta.put(next,(MetricResultByLeadTime)counts.get(next).deepCopy());
            }
            this.counts = meta;
        }
        catch(Exception e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }    
    
    /**
     * Clears all metric results.
     */
    
    public synchronized void clearResults() {
        results.clear();
        counts.clear();
    }
    
    /**
     * Clears all sample counts.
     */
    
    public void clearSampleCounts() {
        counts.clear();
    }    
    
    /**
     * Clears results for a specified forecast type.  Returns true if some results
     * were cleared, false otherwise.
     * 
     * @param type the forecast type
     * @return true if results were cleared, false otherwise
     */
    
    public boolean clearResults(int type) {
        counts.remove(type);
        return results.remove(type)!= null;
    }

    /**
     * Convenience method for setting the reference forecast identifier of a skill
     * metric (e.g. when the verification unit has changed name).  Throws an exception
     * if the input ID is null or this is not a skill metric.
     *
     * @param refID the reference forecast identifier
     */

    public void setRefFcst(String refID) {
        if(!isSkillMetric()) {
            throw new IllegalArgumentException("Cannot set the reference forecast identifier for"
                    + "metric '"+this+"', because it is not a skill metric.");
        }
        if(this instanceof SkillScore) {
            ((ReferenceForecastParameter)
                    getPar(MetricParameter.REFERENCE_FORECAST_PARAMETER)).
                    setRefForecast(refID);
        } else if(this instanceof ThresholdMetricStore) {
            ((ThresholdMetricStore)this).setRefFcst(refID);
        }
    }

    /********************************************************************************
     *                                                                              *
     *                                PROTECTED METHODS                             *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Convenience method for deep copying the results associated with the current
     * metric to the input metric.
     *
     * @param metric the input metric that will receive the deep copied results
     */
    
    protected void deepCopyResults(Metric metric) {
        TreeMap<Integer,MetricResultByLeadTime> map = new TreeMap<Integer,MetricResultByLeadTime>();
        TreeMap<Integer,MetricResultByLeadTime> cnts = new TreeMap<Integer,MetricResultByLeadTime>();
        Iterator i = results.keySet().iterator();
        Iterator j = counts.keySet().iterator();
        //Deep copy results
        while(i.hasNext()) {
            Integer next = Integer.valueOf((Integer)i.next());
            map.put(next,(MetricResultByLeadTime)results.get(next).deepCopy());
        }
        //Deep copy sample counts
        while(j.hasNext()) {
            Integer next = Integer.valueOf((Integer)j.next());
            cnts.put(next,(MetricResultByLeadTime)counts.get(next).deepCopy());
        }
        metric.results = map;
        metric.counts = cnts;
    }   
    
    /**
     * Returns the number of samples (forecast-observation pairs) associated with 
     * the metric, ordered by lead time, for the specified forecast type.
     * Throws an exception if the samples are unavailable.  Call
     * {@link #hasSampleCounts(int)} first.
     *
     * @param forecastType the forecast type
     * @return the sample count
     */
    
    protected int[] getSCount(int forecastType) throws IllegalArgumentException {
        if(! counts.containsKey(forecastType)) {
            throw new IllegalArgumentException("No sample counts available, or none for the specified forecast type.");
        }
        MetricResultByLeadTime cnts = counts.get(forecastType);
        int length = cnts.getResultCount();
        int[] returnMe = new int[length];
        TreeMap t = cnts.getResults();
        int nx = 0;
        for(Iterator k = t.keySet().iterator(); k.hasNext(); nx++) {
            returnMe[nx] = ((IntegerResult)t.get(k.next())).getResult();
        }
        return returnMe;
    }   
    
    /**
     * Convenience method that computes a statistic from forecast values when 
     * the paired input comprise more than one forecast per pair.  If not, the
     * input is simply returned.
     *
     * @param forecastStat the forecast statistic
     * @param pairs the paired input
     * @param nV the null value
     * @return the processed input
     */
    
    protected DoubleMatrix2D getForecastStatFromPaired(VectorFunction forecastStat, 
            DoubleMatrix2D pairs, double nV) {
        return PairedData.getForecastStatFromPaired(forecastStat, pairs, nV);
    }
    
    /**
     * Returns a set of pairs for which a threshold condition on the observations
     * is met.  The condition should be in real-valued units. Throws an exception
     * if no pairs were found that meet the condition.
     * 
     * @param condition the condition
     * @return the conditioned pairs
     */
    
    protected DoubleMatrix2D getConditionalPairs(DoubleProcedure condition, DoubleMatrix2D pairs) throws MetricCalculationException {
        //Return the original pairs if the threshold condition contains Infinity as an argument
        if(Double.isInfinite(condition.getConstants()[0])) {
            return pairs;
        }
        int rows = pairs.getRowCount();
        Vector<double[]> include = new Vector<double[]>();
        for(int i = 0; i < rows; i++) {
            if(condition.apply(pairs.get(i,2))) {
                include.add((double[])pairs.getRowAt(i).getMatrixValues());
            }
        }
        double[][] temp = new double[include.size()][pairs.getColumnCount()];
        int tot = include.size();
        if(tot==0) {
            throw new MetricCalculationException("No pairs met the input condition '"+condition+"'.");
        }
        for(int i = 0; i < tot; i++) {
            temp[i]=include.get(i);
        }
        return new DenseDoubleMatrix2D(temp);
    }

    /**
     * Locates and returns a parameter or null if the parameter does not exist.
     *
     * @param type the parameter ID
     * @return the parameter
     */

    protected MetricParameter getPar(int type) {
        for(int i = 0; i < pars.length; i++) {
            if(pars[i].getID()==type) {
                return pars[i];
            }
        }
        return null;
    }
}



