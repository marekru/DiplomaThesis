package evs.metric.parameters;

/**
 * Records a string identifier.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class StringParameter implements MetricParameter {

    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLE                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * The parameter value. 
     */
    
    protected String par;
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs an object with a string parameter value. The empty string is
     * stored as null.
     *
     * @param par the parameter value
     */
    
    public StringParameter(String par) {
        if(par!=null && par.equals("")) {
            this.par=null;
        } else {
            this.par = par;
        }
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     *
     * @return an identifier
     */
    
    public int getID() {
        return STRING_PARAMETER;
    }    
    
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "string_parameter";
    }    
    
    /**
     * Returns the parameter value.
     *
     * @return the parameter value
     */
    
    public String getParVal() {
        return par;
    }    

    /**
     * Returns true if the string is non-null, otherwise false.
     *
     * @return true if the string is non-null, otherwise false.
     */

    public boolean hasNonNullString() {
        return par!=null;
    }

    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricParameter deepCopy() {
        return new StringParameter(par);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final StringParameter other = (StringParameter) obj;
        if ((this.par == null) ? (other.par != null) : !this.par.equals(other.par)) {
            return false;
        }
        return true;
    }
    
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        assert false : "hashCode not implemented for MetricParameter.";
        return 1;
    }    
    
    /**
     * Returns a string representation of the receiver.
     *
     * @return a string representation
     */
    
    public String toString() {
        return par;
    }
    
}
