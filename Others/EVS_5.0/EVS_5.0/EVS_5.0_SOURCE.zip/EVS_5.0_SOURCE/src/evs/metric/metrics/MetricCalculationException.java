package evs.metric.metrics;

/**
 * Class for throwing exceptions that signify an error calculating a metric.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class MetricCalculationException extends RuntimeException {
    
    /**
     * Constructs an MetricCalculationException with no message.
     */
    
    public MetricCalculationException() {
        super();
    }

    /**
     * Constructs an MetricCalculationException with the specified message. 
     * 
     * 
     * @param s the message.
     */
    
    public MetricCalculationException(String s) {
	super(s);
    }
}
