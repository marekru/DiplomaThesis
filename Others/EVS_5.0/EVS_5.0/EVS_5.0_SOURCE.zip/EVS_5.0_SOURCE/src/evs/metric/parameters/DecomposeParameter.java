package evs.metric.parameters;

//EVS dependencies
import evs.metric.metrics.DecomposableScore;

/**
 * Indicates whether a score will be decomposed. The type of decomposition can
 * also be defined. The default decomposition comprises the Calibration-Refinement
 * (CR) factorization into reliability - resolution + uncertainty.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DecomposeParameter extends BooleanParameter {

    /********************************************************************************
     *                                                                              *
     *                                 VARIABLES                                    *
     *                                                                              *
     *******************************************************************************/

    /**
     * Stores the type of decomposition.  One of DecomposableScore.CALIBRATION_REFINEMENT,
     * DecomposableScore.LIKELIHOOD_BASE_RATE, DecomposableScore.CR_AND_LBR or
     * DecomposableScore.NONE.
     */

    private int type = DecomposableScore.NONE;
    
    /**
     * String representation.
     */

    private String typeString = DecomposableScore.NONE_STRING;
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs an object with a boolean parameter value. Uses the default
     * decomposition defined in this class if a decomposition is requested.
     *
     * @param isTrue the boolean parameter value
     */
    
    public DecomposeParameter(boolean isTrue) {
        super(isTrue);
        if(isTrue) {
            type = DecomposableScore.DEFAULT_DECOMPOSITION;
            typeString = DecomposableScore.DEFAULT_DECOMPOSITION_STRING;
        }
    }

    /**
     * Constructs an object with a specified decomposition type.
     *
     * @param template the decomposition template
     */

    public DecomposeParameter(int template) {
        super(template!=DecomposableScore.NONE);
        switch(template) {
            case DecomposableScore.CALIBRATION_REFINEMENT: {
                this.type = template;
                typeString = DecomposableScore.CALIBRATION_REFINEMENT_STRING;
            }; break;
            case DecomposableScore.LIKELIHOOD_BASE_RATE: {
                this.type = template;
                typeString = DecomposableScore.LIKELIHOOD_BASE_RATE_STRING;
            }; break;
            case DecomposableScore.CR_AND_LBR: {
                this.type = template;
                typeString = DecomposableScore.CR_AND_LBR_STRING;
            }; break;
            case DecomposableScore.NONE: {
                this.type = template;
                typeString = DecomposableScore.NONE_STRING;
            }; break;
            default: {
                throw new IllegalArgumentException("Unrecognized template for score decomposition.");
            }
        }
    }

    /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     *
     * @return an identifier
     */
    
    public int getID() {
        return DECOMPOSE_PARAMETER;
    }

    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "decompose_parameter";
    }       
    
    /**
     * Returns the type of score decomposition.
     *
     * @return the type of score decomposition
     */

    public int getScoreDecType() {
        return type;
    }

    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricParameter deepCopy() {
        DecomposeParameter d = new DecomposeParameter(isTrue);
        d.type = type;
        d.typeString = typeString;
        return d;
    }      
    
    /**
     * Returns a string representation of the parameter.
     * 
     * @return a string representation
     */
    
    public String toString() {
        return typeString;
    }
    
    /**
     * Override equals.  
     *
     * @param o the object to test against the current object
     * @return true if the objects are equal
     */
    
    public boolean equals(Object o) {
        if(o instanceof BooleanParameter) {
            return super.equals(o) && ((BooleanParameter)o).getID()==DECOMPOSE_PARAMETER;
        } else if (o instanceof DecomposeParameter) {
            return super.equals(o) && ((DecomposeParameter)o).getID()==DECOMPOSE_PARAMETER
                && ((DecomposeParameter)o).getScoreDecType()==type;
        } else {
            return false;
        }
    } 
        
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        assert false : "hashCode not implemented for MetricParameter.";
        return 1;
    }
    
}
