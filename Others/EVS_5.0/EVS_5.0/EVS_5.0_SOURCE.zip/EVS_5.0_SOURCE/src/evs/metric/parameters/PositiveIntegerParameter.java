package evs.metric.parameters;

/**
 * Records an integer parameter for a verification metric.  The integer must be 
 * positive (i.e. >=1).
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class PositiveIntegerParameter extends IntegerParameter {
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs an object with an integer parameter value
     *
     * @param par the parameter value  
     */ 
    
    public PositiveIntegerParameter(int par) {  
        super(par);
        if(par < 1) {
            throw new IllegalArgumentException("Specify an integer value greater than zero.");
        }      
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     * Remember to override in any subclass.
     *
     * @return an identifier
     */
    
    public int getID() {
        return POSITIVE_INTEGER_PARAMETER;
    }        
    
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "positive_integer_parameter";
    }       
    
    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricParameter deepCopy() {
        return new PositiveIntegerParameter(par);
    }         
    
}
