package evs.metric.metrics;

//EVS dependencies
import evs.data.*;
import evs.metric.parameters.*;
import evs.metric.results.*;
import evs.utilities.*;
import evs.utilities.matrix.*;
import evs.utilities.mathutil.*;
        
//Java util dependencies
import java.util.*;

/**
 * The Brier score is the mean squared error of a dichotomous forecast event 
 * in probability space.
 *
 * @author evs@hydrosolved.com
 * @version 4.0 
 */

public class BrierScore extends ScoreMetric implements EnsembleMetric,
        ThresholdMetric, DecomposableScore, CategoricalMetric, BootstrapableMetric {
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/      

    /**
     * Construct a Brier score object with associated parameters.
     *
     * @param event the event mark
     * @param decompose the decomposition indicator
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use conditional 
     * pairs when available
     * @param minS the minimum sample size
     * @param bs the bootstrap parameter
     */
    
    public BrierScore(DoubleProcedureParameter event,DecomposeParameter decompose,
            ForecastTypeParameter fType, UnconditionalParameter unconditional,MinimumSampleSizeParameter minS,
            BootstrapParameter bs) {
        //Set the name
        name = "Brier score";
        //Set the parameters
        setParameters(new MetricParameter[]{event.deepCopy(),decompose.deepCopy(),fType.deepCopy(),
        unconditional.deepCopy(),minS.deepCopy(),bs.deepCopy()});
        //Set the link to html description of the metric
        descriptionURL = getClass().getResource(EVSConstants.STATS_EXPLAINED_DIR + "brier.htm");
    }    

    /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/        
    
    /**
     * Returns the metric identifier.
     *
     * @return an identifier
     */
    
    public int getID() {
        return BRIER_SCORE;
    }         

    /**
     * Returns true if the metric will be decomposed, false if only the overall
     * value will be computed.
     * 
     * @return true if the decomposition of the metric value will be provided
     */
    
    public boolean willDecompose() {
        return ((DecomposeParameter)pars[1]).getParVal();
    }
    
    /**
     * Returns the type of decomposition required. One of:
     * 
     * DecomposableScore.CALIBRATION_REFINEMENT
     * DecomposableScore.LIKELIHOOD_BASE_RATE
     * DecomposableScore.CR_AND_LBR
     * DecomposableScore.NONE  
     * 
     * @return the type of decomposition
     */
    
    public int getScoreDecType() {
        return ((DecomposeParameter)pars[1]).getScoreDecType();
    }    
    
    /**
     * Returns an array of integer decompositions that have been implemented. 
     * Each int is one of:
     * 
     * DecomposableScore.CALIBRATION_REFINEMENT
     * DecomposableScore.LIKELIHOOD_BASE_RATE
     * DecomposableScore.CR_AND_LBR
     * DecomposableScore.NONE.  
     * 
     * @return an array of implemented decompositions.
     */
    
    public int[] getDecompositionOptions() {
        return new int[] {
            DecomposableScore.NONE,
            DecomposableScore.CALIBRATION_REFINEMENT,
            DecomposableScore.LIKELIHOOD_BASE_RATE,
            DecomposableScore.CR_AND_LBR,
        };
    }    
    
    /**
     * Returns the result type associated with the metric.  See the 
     * evs.metric.MetricResult class for supported types.
     *
     * @return an identifier
     */
    
    public int getResultID() {
        return MetricResult.ENSEMBLE_SCORE_DECOMPOSITION_RESULT;
    }     
    
    /**
     * Returns true if the metric is defined in real units of the forecast
     * and observed variable, false otherwise.
     * 
     * @return true if the metric is defined in real units
     */    

    public boolean hasRealUnits() {
        return false;
    }   
    
    /**
     * Returns the threshold associated with this threshold diagram.
     *
     * @return the threshold
     */
    
    public DoubleProcedureParameter getThreshold() {
        return (DoubleProcedureParameter)pars[0].deepCopy();
    }

    /**
     * Returns a deep copy of the current metric, where all instance variables 
     * occupy independent positions in memory from the current metric.  
     *
     * @return a deep copy of the current object 
     */
    
    public Metric deepCopy() {
        BrierScore returnMe = new BrierScore((DoubleProcedureParameter)pars[0].deepCopy(),
                (DecomposeParameter)pars[1].deepCopy(),
                (ForecastTypeParameter)pars[2].deepCopy(),
                (UnconditionalParameter)pars[3].deepCopy(),
                (MinimumSampleSizeParameter)pars[4].deepCopy(),
                getBootstrapPar());
        deepCopyResults(returnMe);
        return returnMe;
    }

    /**
     * Returns the bootstrap parameter associated with the verification metric.
     *
     * @return the bootstrap parameter
     */
    @Override
    public BootstrapParameter getBootstrapPar() {
        return (BootstrapParameter)pars[5].deepCopy();
    }

    /**
     * Returns a metric with default parameter values.  
     *
     * @return a metric with default parameter values.
     */
    
    public static Metric getDefaultMetric() { 
        ProbabilityIdentifierParameter prob =new ProbabilityIdentifierParameter(true);
        DoubleProcedureParameter eT = new DoubleProcedureParameter(new IntegerParameter(DoubleProcedureParameter.GREATER_THAN),
                new DoubleParameter[]{new ProbabilityParameter(0.0)},prob, new BooleanParameter(true));
        ForecastTypeParameter type = new ForecastTypeParameter(new int[]{ForecastTypeParameter.REGULAR_FORECAST});
        return new BrierScore(eT,new DecomposeParameter(false),type,new UnconditionalParameter(false),
                new MinimumSampleSizeParameter(),new BootstrapParameter());
    }    
    
    /********************************************************************************
     *                                                                              *
     *                               MUTATOR METHODS                                *
     *                                                                              *
     *******************************************************************************/     

    /**
     * Sets the threshold for the current metric.    
     *
     * @param threshold the threshold
     */
    
    public void setThreshold(DoubleProcedureParameter threshold) {
        pars[0] = (DoubleProcedureParameter)threshold.deepCopy();
    }        
    
    /**
     * Uses the specified paired data to compute and return the result of the metric.
     * The metric results are returned, together with the sample counts, but not stored 
     * locally.  The metric result is located in the first index of the return array
     * and the sample counts are located in the second index. Optionally, specify
     * the results of a reference forecast from which to compute skill if the 
     * metric is a skill score. 
     * 
     * @param forecastType the forecast type
     * @param paired the paired data
     * @param refResult the results for a reference forecast (may be null)
     * @return the metric result and sample counts
     */
    
    public MetricResult[] compute(int forecastType, PairedData paired, MetricResult refResult) throws MetricCalculationException {
        if(paired==null) {
            throw new MetricCalculationException("Error computing metric '"+getName()+"': input pairs were null.");
        }
        ForecastTypeParameter.isSupportedForecastType(forecastType,true);
        MetricResult res = null;
        DoubleProcedure pro = getThreshold().getParValReal();
        DoubleMatrix2D p = paired.getPairs();
        double nV = paired.getNullValue();
        //Set the metadata stores
//        try {
            if (willDecompose()) {
                res = getBSWithDecomp((DoubleMatrix2D) p.getSubmatrixByColumn(2, p.getColumnCount() - 1), pro, nV);
            } else {
                res = getBS((DoubleMatrix2D) p.getSubmatrixByColumn(2, p.getColumnCount() - 1), pro, nV);
            }
//        } catch (Exception e) {
//            //e.printStackTrace();
//        }
        return new MetricResult[]{res,new IntegerResult(lastCount)}; 
    }   
        
    /**
     * Sets the bootstrap parameter associated with the verification metric or
     * clears the parameter if the input is null;
     *
     * @param bs the bootstrap parameter
     */
    @Override
    public void setBootstrapPar(BootstrapParameter bs) {
        if(bs==null) {
            throw new IllegalArgumentException("The bootstrap parameter for metric '"+this+"' cannot be null.");
        } else {
            pars[5] = (BootstrapParameter)bs.deepCopy();
        }
    }

    /**
     * Sets the bootstrap parameter to BootstrapableMetric.NO_BOOTSTRAP and clears
     * all associated parameter values.
     */
    @Override
    public void clearBootstrapPar() {
        ((BootstrapParameter)pars[5]).clear();
    }

    /**
     * Returns the Brier score from the input data.  The input should comprise one
     * column of observations (at index 0) and the remaining n columns should comprise
     * the n ensemble members (index 1 through n). 
     *
     * @param data the input data
     * @param pro the threshold with values in real units
     * @param nV the null value
     * @return the Brier score
     */
    
    public MetricResult getBS(DoubleMatrix2D data, DoubleProcedure pro, double nV) {    
        double[] obs = ((DoubleMatrix1D)data.getColumnAt(0)).toArray();
        double[][] forecasts = ((DoubleMatrix2D)data.getSubmatrixByColumn(1,data.getColumnCount()-1)).toArray();
        
        int length = obs.length;
        
        //Iterate the BS 
        int actualRows = 0;
        int cols = forecasts[0].length;
        double bs = 0.0;
        
        //Occurrences/Non-occurrences
        int obsTotal = 0;
        int obsNotTotal = 0;        
        
        for(int i = 0; i < length; i++) {
            if(obs[i] != nV) {
                double indObs = 0.0;
                if(pro.apply(obs[i])) {
                    indObs=1.0;
                }

                //Count the number of forecast members that meet the criterion
                double num = 0;
                double den = 0;
                for (int j = 0; j < cols; j++) {
                    if (forecasts[i][j] != nV) {
                        if (pro.apply(forecasts[i][j])) {
                            num++;
                        }
                        den++;
                    }
                }
                if (den != 0) {
                    //Increment the BS
                    bs += Math.pow(indObs - (num / den), 2);
                    actualRows += 1;
                    if(indObs==1) {
                        obsTotal+=1;
                    } else {
                        obsNotTotal+=1;
                    }
                }
            }
        }

        int minCount = ((MinimumSampleSizeParameter)pars[4]).getParVal();
        int testRows = Math.min(obsTotal,obsNotTotal);
        String occStatus = "occurrences";
        if(obsNotTotal<obsTotal) {
            occStatus = "non-occurrences";
        }
        lastCount = actualRows;
        if(testRows < minCount) {
            throw new MetricCalculationException("Could not compute the Brier score: fewer "+occStatus+" than required ["+testRows+","+minCount+"].");
        }
        
        //Compute the average score and return
        return new EnsembleScoreDecomposition(NONE,new DenseDoubleMatrix1D(new double[]{bs/actualRows}));  
    }

    /**
     * Returns the Brier score from the input data with decomposition defined by
     * the DecomposeParameter from which the object was constructed.  There are
     * three possible decompositions: 1) the CR factorization; 2) the LGR factorization
     * and; 3) both, including mixed factors (see the DecomposeParameter class).
     *
     * @param data the input data
     * @param pro the threshold with values in real units
     * @return the Brier score and decompositions
     */

    public MetricResult getBSWithDecomp(DoubleMatrix2D data, DoubleProcedure pro, double nV) {
        int type = ((DecomposeParameter)pars[1]).getScoreDecType();
        switch(type) {
            case CALIBRATION_REFINEMENT: {
                return getBSWithCRDecomp(data, pro,nV);
            }
            case LIKELIHOOD_BASE_RATE: {
                return getBSWithLBRDecomp(data, pro,nV);
            }
            case CR_AND_LBR: {
                return getBSWithAllDecomp(data, pro,nV);
            }
            default: {
                throw new IllegalArgumentException("Unrecognized score decomposition requested for the Brier Score.");
            }
        }
    }

    /**
     * Returns the CR factorization of the Brier Score, comprising:
     *
     * Brier Score
     * Reliability
     * Resolution
     * Uncertainty
     *
     * @param data the input data
     * @param pro the threshold with values in real units
     * @param nV the null value
     * @return the Brier score and CR decomposition
     */

    public MetricResult getBSWithCRDecomp(DoubleMatrix2D data, DoubleProcedure pro, double nV) {
        double[] d = getBSWithCR(data,pro,nV);
        int actualRows = (int)d[6];
        int minCount = ((MinimumSampleSizeParameter)pars[4]).getParVal();
        int occ = (int)d[7];
        int nonOcc = (int)d[8];
        int testRows = Math.min(occ,nonOcc);
        String occStatus = "occurrences";
        if(nonOcc<occ) {
            occStatus = "non-occurrences";
        }
        lastCount = actualRows;
        if(testRows < minCount) {
            throw new MetricCalculationException("Could not compute the Brier score: fewer "+occStatus+" than required ["+testRows+","+minCount+"].");
        }
        double[] dm = new double[]{d[0],d[1],d[2],d[3]};
        return new EnsembleScoreDecomposition(CALIBRATION_REFINEMENT,new DenseDoubleMatrix1D(dm));
    }

    /**
     * Returns the LBR factorization of the Brier Score, comprising:
     *
     * Brier Score
     * Type-II conditional bias
     * Discrimination
     * Sharpness
     *
     * @param data the input data
     * @param pro the threshold with values in real units
     * @param nV the null value
     * @return the Brier score and LBR decomposition
     */

    public MetricResult getBSWithLBRDecomp(DoubleMatrix2D data, DoubleProcedure pro, double nV) {
        double[] d = getBSWithLBR(data,pro,nV);
        int actualRows = (int)d[8];
        int minCount = ((MinimumSampleSizeParameter)pars[4]).getParVal();
        int occ = (int)d[9];
        int nonOcc = (int)d[10];
        int testRows = Math.min(occ,nonOcc);
        String occStatus = "occurrences";
        if(nonOcc<occ) {
            occStatus = "non-occurrences";
        }
        lastCount = actualRows;
        if(testRows < minCount) {
            throw new MetricCalculationException("Could not compute the Brier score: fewer "+occStatus+" than required ["+testRows+","+minCount+"].");
        }
        double[] dm = new double[]{d[0],d[1],d[2],d[3]};
        return new EnsembleScoreDecomposition(LIKELIHOOD_BASE_RATE,new DenseDoubleMatrix1D(dm));
    }    
    
    /**
     * Returns the combined CR and LBR factorization of the Brier Score, comprising:
     *
     * Brier Score
     * Reliability
     * Resolution
     * Uncertainty
     * Type-II conditional bias
     * Discrimination
     * Sharpness
     * Score when the event was observed
     * Score when the event was observed to not occur
     * Type-II conditional bias when the event was observed
     * Type-II conditional bias when the event was observed to not occur
     * Discrimination when the event was observed
     * Discrimination when the event was observed to not occur
     *
     * @param data the input data
     * @param pro the threshold with values in real units
     * @param nV the null value
     * @return the Brier score and CR and LBR decompositions
     */

    public MetricResult getBSWithAllDecomp(DoubleMatrix2D data, DoubleProcedure pro, double nV) throws MetricCalculationException {
        double[] d = getBSWithCR(data,pro,nV);
        int actualRows = (int)d[6];
        int occ = (int)d[7];
        int nonOcc = (int)d[8];
        int minCount = ((MinimumSampleSizeParameter)pars[4]).getParVal();
        int testRows = Math.min(occ,nonOcc);
        String occStatus = "occurrences";
        if(nonOcc<occ) {
            occStatus = "non-occurrences";
        }
        lastCount = actualRows;
        if(testRows < minCount) {
            throw new MetricCalculationException("Could not compute the Brier score: fewer "+occStatus+" than required ["+testRows+","+minCount+"].");
        }
        double[] d2 = getBSWithLBR(data,pro,nV);
        double[] dm = new double[]{d[0],d[1],d[2],d[3],d2[1],d2[2],d2[3],d[4],
            d[5],d2[4],d2[5],d2[6],d2[7]};
        return new EnsembleScoreDecomposition(CR_AND_LBR,new DenseDoubleMatrix1D(dm));
    }

    /**
     * Returns the CR factorization of the Brier Score, comprising:
     *
     * Brier Score
     * Reliability
     * Resolution
     * Uncertainty
     * 
     * Also returns:
     * 
     * Score given event observed to occur
     * Score given event observed to not occur
     * Total valid pairs
     * Total valid pairs where event occurred
     * Total valid pairs where event did not occur
     *
     * @param data the input data
     * @param pro the threshold with values in real units
     * @param nV the null value
     * @return the Brier score and CR decomposition
     */

    public static double[] getBSWithCR(DoubleMatrix2D data, DoubleProcedure pro, double nV) throws MetricCalculationException {
        if(data == null) {
            throw new MetricCalculationException("Specify non-null input "
                    + "data for the BS with CR decomposition.");
        }
        if(pro == null) {
            throw new MetricCalculationException("Specify a non-null threshold condition "
                    + "for the BS with CR decomposition.");
        }
        if(data.getColumnCount()<2) {
            throw new MetricCalculationException("The input data for the BS with CR "
                    + "decomposition contains fewer than two columns, which is not allowed.");
        }
        double[] obs = ((DoubleMatrix1D)data.getColumnAt(0)).toArray();
        double[][] forecasts = ((DoubleMatrix2D)data.
                getSubmatrixByColumn(1,data.getColumnCount()-1)).toArray();
        int length = obs.length;
        
        //Iterate the BS 
        double actualRows = 0;
        double clim = 0; //Climatological probability to be determined
        int cols = forecasts[0].length;
        
        //Store the score when observed versus not observed
        double bsObs = 0;
        double bsNotObs = 0;
        double obsTotal = 0;
        double obsNotTotal = 0;
        
        //Store forecast counts and observed sums by unique forecast probability
        TreeMap<Double,double[]> map = new TreeMap();
        for(int i = 0; i < length; i++) {
            if(obs[i] != nV) {
                double indObs = 0.0;
                if(pro.apply(obs[i])) {
                    indObs=1.0;
                }

                //Count the number of forecast members that meet the criterion
                double num = 0;
                double den = 0;
                for (int j = 0; j < cols; j++) {
                    if (forecasts[i][j] != nV) {
                        if (pro.apply(forecasts[i][j])) {
                            num++;
                        }
                        den++;
                    }
                }
                if (den != 0) {
                    double p = num/den;
                    //Store the unique forecast probabilities
                    if(map.containsKey(p)) {
                        double[] g = map.get(p);
                        g[0]+=1;
                        g[1]+=indObs;
                    } else {
                        map.put(p,new double[]{1,indObs});
                    }
                    if(indObs==0.0) {
                        bsNotObs+=(p*p);
                        obsNotTotal+=1;
                    } else {
                        bsObs+=((1.0-p)*(1.0-p));
                        obsTotal+=1;
                    }
                    clim+=indObs;
                    actualRows += 1;
                }
            }
        }
        clim = clim/actualRows;
        
        double nullValue = Metric.NULL_DATA;
        
        if(obsTotal>0) {
            bsObs = bsObs / obsTotal;
        } else {
            bsObs = nullValue;
        }
        if(obsNotTotal>0) {
            bsNotObs = bsNotObs / obsNotTotal;
        } else {
            bsNotObs = nullValue;
        }

        double[] dm = null;
        if (actualRows > 0) {
            //Compute decomposed score
            double rel = 0.0;
            double res = 0.0;
            double unc = clim * (1.0 - clim);
            Iterator it = map.keySet().iterator();
            while (it.hasNext()) {
                Double fk = (Double) it.next();
                double[] d = map.get(fk);
                double nk = d[0];
                double ok = d[1] / nk;
                rel += (nk * Math.pow(ok - fk, 2));
                res += (nk * Math.pow(ok - clim, 2));
            }
            rel = rel / actualRows;
            res = res / actualRows;
            double bs = rel - res + unc;
            dm = new double[]{bs, rel, res, unc, bsObs, bsNotObs, actualRows, obsTotal, obsNotTotal};
        } else {
            dm = new double[]{nullValue,nullValue,nullValue,nullValue, bsObs, bsNotObs, actualRows, obsTotal, obsNotTotal};
        }
        return dm; 
    }

    /**
     * Returns the LBR factorization of the Brier Score, comprising:
     *
     * Brier Score
     * Type-II conditional bias
     * Discrimination
     * Sharpness
     * Type-II conditional bias when the event was observed
     * Type-II conditional bias when the event was not observed
     * Discrimination when the event was observed
     * Discrimination when the event was not observed
     * The number of pairs with valid data
     *
     * @param data the input data
     * @param pro the threshold with values in real units
     * @param nV the null value
     * @return the Brier score and LBR decomposition
     */

    public static double[] getBSWithLBR(DoubleMatrix2D data, DoubleProcedure pro, double nV) throws MetricCalculationException {
        if(data == null) {
            throw new MetricCalculationException("Specify non-null input "
                    + "data for the BS with LBR decomposition.");
        }
        if(pro == null) {
            throw new MetricCalculationException("Specify a non-null threshold condition "
                    + "for the BS with LBR decomposition.");
        }
        if(data.getColumnCount()<2) {
            throw new MetricCalculationException("The input data for the BS with "
                    + "LBR decomposition contains fewer than two columns, which is not allowed.");
        }
        double[] obs = ((DoubleMatrix1D)data.getColumnAt(0)).toArray();
        double[][] forecasts = ((DoubleMatrix2D)data.getSubmatrixByColumn(1,data.getColumnCount()-1)).toArray();

        int length = obs.length;

        //Iterate the BS
        double actualRows = 0;
        double obsTotal = 0;
        double obsNotTotal = 0;  
        double x_bar = 0; //Climatological probability (or the number of observed occurrences / actualRows)
        double y_bar = 0; //Average forecast probability
        double y_bar_obs = 0; //Average forecast probability given observed
        double y_bar_nobs = 0; //Average forecast probability given not observed
        double y_var = 0;  //Variance of the forecast probabilities
        //Parameters for computing variance of the forecast probabilities incrementally
        double M2 = 0;

        int cols = forecasts[0].length;
        //Store forecast counts and observed sums by unique forecast probability
        for(int i = 0; i < length; i++) {
            if(obs[i] != nV) {
                double indObs = 0.0;
                if(pro.apply(obs[i])) {
                    indObs=1.0;
                }

                //Count the number of forecast members that meet the criterion
                double num = 0;
                double den = 0;
                for (int j = 0; j < cols; j++) {
                    if (forecasts[i][j] != nV) {
                        if (pro.apply(forecasts[i][j])) {
                            num++;
                        }
                        den++;
                    }
                }
                if (den != 0) {
                    double p = num/den;
                    x_bar+=indObs;
                    actualRows +=1;
                    //Update parameters for incremental mean and variance of forecast probabilities
                    double delta = p - y_bar;
                    y_bar = y_bar + (delta/actualRows);
                    M2+=delta*(p - y_bar);
                    //Update conditional mean sums
                    if(indObs==1) {
                        y_bar_obs+=p;
                        obsTotal+=1;
                    } else {
                        y_bar_nobs+=p;
                        obsNotTotal+=1;
                    }
                }
            }
        }       
        if (actualRows > 0) {

            //Compute averages (y-bar already done)
            y_var = M2 / actualRows;
            y_bar_obs = y_bar_obs / x_bar; //x_bar is currently an effective conditional row count
            y_bar_nobs = y_bar_nobs / (actualRows - x_bar);
            x_bar = x_bar / actualRows;

            //Compute decomposed score
            double typeIIObs = 0;
            double discObs = 0;
            if(obsTotal>0) {
                typeIIObs = x_bar * Math.pow(y_bar_obs - 1.0, 2);
                discObs = (x_bar) * Math.pow(y_bar_obs - y_bar, 2);
            }
            double typeIINotObs = 0;
            double discNotObs = 0;       
            if(obsNotTotal>0) {
                typeIINotObs = (1.0 - x_bar) * Math.pow(y_bar_nobs, 2);
                discNotObs = (1.0 - x_bar) * Math.pow(y_bar_nobs - y_bar, 2);
            }
            double typeII = typeIIObs + typeIINotObs;
            double discrimination = discObs + discNotObs;
            double sharpness = y_var;
            double bs = typeII - discrimination + sharpness;
            return new double[]{bs, typeII, discrimination, sharpness,
                        typeIIObs, typeIINotObs, discObs, discNotObs, actualRows, obsTotal, obsNotTotal};
        }
        return new double[]{nV,nV,nV,nV,nV,nV,nV,nV,actualRows,obsTotal,obsNotTotal};
    }

    /**
     * Test method.
     * 
     * @param args command line args
     */
    
    public static void main(String[] args) {
//        double[][] t = new double[][] {
//            {25.7,23,43,45,23,54},
//            {21.4,19,16,57,23,9},
//            {32,23,54,23,12,32},
//            {47,12,54,23,54,78},
//            {12,9,8,5,6,12},
//            {43,23,12,12,31,12}
//        };
//        DoubleProcedure pro = evs.utilities.mathutil.FunctionLibrary.isGreater(28);
        
//        System.out.println(getBS(new DenseDoubleMatrix2D(t),pro));
//        System.out.println(getBSWithDecomp(new DenseDoubleMatrix2D(t),pro));
//        
    }
    
    
    
    
    
    
    
}
    