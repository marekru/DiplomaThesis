package evs.metric.parameters;

/**
 * Indicates whether absolute or relative frequencies should be used when computing
 * the rank histogram. Absolute frequencies are equivalent to sample counts. Relative
 * frequencies may be interpreted as probabilities.
 *
 * @author evs@hydrosolved.com
 * @version 1.0
 */

public class RankHistSampleParameter extends BooleanParameter {
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs an object with a boolean parameter value
     *
     * @param useRelative is true to use relative frequencies, false for absolute
     */
    
    public RankHistSampleParameter(boolean useRelative) {
        super(useRelative);
    }
    
    /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     *
     * @return an identifier
     */
    
    public int getID() {
        return RANK_HIST_SAMPLE_PARAMETER;
    }

    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "rank_hist_sample_parameter";
    }    
    
    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricParameter deepCopy() {
        return new RankHistSampleParameter(isTrue); 
    }      
    
    /**
     * Override equals.  
     *
     * @param o the object to test against the current object
     * @return true if the objects are equal
     */
    
    public boolean equals(Object o) {
        return super.equals(o) && ((BooleanParameter)o).getID()==RANK_HIST_SAMPLE_PARAMETER;
    } 
    
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        assert false : "hashCode not implemented for MetricParameter.";
        return 1;
    }    
        
}
