package evs.metric.parameters;

//Java util dependencies
import java.util.Arrays;

/**
 * A metric parameter that comprises an array of boolean values.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class BooleanArrayParameter implements MetricParameter {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLE                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * The parameter value.
     */
    
    protected boolean[] parVal;
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs a metric result with a boolean array.
     *
     * @param parVal the parVal
     */
    
    public BooleanArrayParameter(boolean[] parVal) {
        if(parVal == null || parVal.length==0) {
            throw new IllegalArgumentException("Specify valid thresholds.");
        }
        this.parVal = new boolean[parVal.length];
        System.arraycopy(parVal,0,this.parVal,0,parVal.length);
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     *
     * @return an identifier
     */
    
    public int getID() {
        return BOOLEAN_ARRAY_PARAMETER;
    }    
    
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "boolean_array_parameter";
    }       
    
    /**
     * Returns the length of the array.
     *
     * @return the length
     */
    
    public int getLength() {
        return parVal.length;
    }
    
    /**
     * Returns the parameter value.
     *
     * @return the parameter value
     */

    public boolean[] getParVal() {
        return Arrays.copyOf(parVal,parVal.length);
    }

    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricParameter deepCopy() {
        return new BooleanArrayParameter(Arrays.copyOf(parVal,parVal.length));
    }        
    
    /**
     * Override equals.  
     *
     * @param o the object to test against the current object
     * @return true if the objects are equal
     */
    
    public boolean equals(Object o) {
        return o instanceof BooleanArrayParameter && Arrays.equals(((BooleanArrayParameter)o).parVal,parVal);
    }     
    
    /**
     * Returns a string representation of the parVal separated by commas.
     *
     * @return a string representation
     */
    
    public String toString() {
        StringBuffer returnMe = new StringBuffer();
        for(int i = 0; i < parVal.length; i++) {
            returnMe.append(parVal[i]);
            if(i < (parVal.length-1)) {
                returnMe.append(", ");
            }
        }
        return returnMe.toString();
    }
       
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        assert false : "hashCode not implemented for MetricParameter.";
        return 1;
    }
    
}
