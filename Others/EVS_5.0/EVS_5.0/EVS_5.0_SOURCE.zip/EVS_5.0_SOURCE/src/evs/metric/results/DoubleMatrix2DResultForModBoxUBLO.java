package evs.metric.results;

//EVS dependencies
import evs.utilities.matrix.*;
import evs.utilities.mathutil.*;
import evs.metric.metrics.*;
import evs.metric.parameters.*;

//Java dependencies
import java.util.*;

/**
 * Immutable wrapper class for a 2D double matrix that acts as a metric result.
 * Stores a 2D matrix for the modified box plot by size of observed value.  The
 * result type of this class is {@link evs.metric.results.MetricResult#DOUBLE_MATRIX_2D_RESULT}.
 * 
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public final class DoubleMatrix2DResultForModBoxUBLO extends DoubleMatrix2DResult {

    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs a metric result with a double matrix.
     *
     * @param result the metric result
     */
    
    public DoubleMatrix2DResultForModBoxUBLO(DoubleMatrix2D result) {
        super(result);
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Returns the type of result.  The result type is the same as that of the
     * superclass, namely {@link evs.metric.results.MetricResult#DOUBLE_MATRIX_2D_RESULT}
     *
     * @return the type of result
     */
    
    public int getID() {
        return super.getID();
    }    
    
     /**
     * Applies an aggregation function to the corresponding values (e.g. same 
     * matrix position) in the input results, placing a Metric.NULL_DATA if all 
     * of those values are Metric.NULL_DATA.  Throws an exception if the inputs
     * are not of the same class.  The return type may not correspond to the input
     * type if the result of the aggregation function cannot be stored in the input
     * type.  Specifically, any aggregation of a result that contains integers 
     * should ALWAYS return a result that contains doubles, as the aggregation 
     * function is guaranteed to do so.  For example, the average of a set of 
     * integers may not be an integer.  Specify a set of weights for each metric
     * that are constant across all forecast lead times.  The weights must sume to 1.
     * 
     * @param input the input results
     * @param func the aggregation function
     * @param weights the constant weights to apply across all lead times
     * @return the aggregated result   
     */
    
    public MetricResult aggregate(MetricResult[] input, VectorFunction func,double[] weights) throws MetricResultException {
        //Check inputs are correct
        checkAggInputs(input,weights);  //Throws an exception if inputs are invalid

        //Organize results by observed value
        TreeMap<Double,Vector<double[]>> map = new TreeMap();
        TreeMap<Double,Vector<Double>> wghts = new TreeMap(); //One weight for each double[] in map
        int cols = 0;
        for(int i = 0; i < input.length; i++) {
            DoubleMatrix2D n = ((DoubleMatrix2DResultForModBoxUBLO)input[i]).getResult();
            cols= n.getColumnCount();
            int rows = n.getRowCount();
            for(int j = 0; j < rows; j++) {
                double next = n.get(j,0);
                if(map.containsKey(next)) {
                    Vector<double[]> v = (Vector<double[]>)map.get(next);
                    v.add(((DoubleMatrix1D)n.getRowAt(j)).toArray());
                    Vector<Double> v2 = (Vector<Double>)wghts.get(next);
                    v2.add(weights[i]);
                }
                else {
                    Vector<double[]> v = new Vector();
                    v.add(((DoubleMatrix1D)n.getRowAt(j)).toArray());
                    map.put(next,v);
                    Vector<Double> v2 = new Vector();
                    v2.add(weights[i]);
                    wghts.put(next,v2);
                }
            }
        }
        int sz = map.size();
        //Rescale the weights as necessary depending on inputs available
        for(final Iterator j = wghts.keySet().iterator(); j.hasNext();) {
            Vector<Double> n = wghts.get(j.next());
            int sz2 = n.size();
            //Reweight
            if (sz2 != input.length) {
                double redSum = 0;
                for (int i = 0; i < sz2; i++) {
                    redSum += n.get(i);
                }
                double mFac = 1.0/redSum;
                for(int i = 0; i < sz2; i++) {
                    n.set(i,n.get(i)*mFac);
                }
            }
        }
        //Aggregate    
        DenseDoubleMatrix2D im = new DenseDoubleMatrix2D(sz,cols);
        int inc = 0;
        for(final Iterator i = map.keySet().iterator(); i.hasNext(); inc++) {
            Double nx = (Double)i.next();
            Vector<double[]> v = map.get(nx);
            Vector<Double> w = wghts.get(nx);
            int s = v.size();
            for(int j = 0; j < cols; j++) {
                DenseDoubleMatrix1D in = new DenseDoubleMatrix1D(s);
                for(int k = 0; k < s; k++) {
                    in.set(k,v.get(k)[j] * w.get(k));
                }
                im.set(inc,j,func.apply(in,Metric.NULL_DATA)); //Aggregate
            }
        }
        return new DoubleMatrix2DResultForModBoxUBLO(im);  
    }          
    
    /**
     * Returns a deep copy of the current metric result, where all instance variables 
     * occupy independent positions in memory from the current metric result.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricResult deepCopy() {
        DoubleMatrix2DResultForModBoxUBLO d = new
                DoubleMatrix2DResultForModBoxUBLO((DoubleMatrix2D)result.deepCopy());
        d.intervals = deepCopyIntervals();
        if(hasMainInterval()) {
            d.main = (ProbabilityIntervalParameter)main.deepCopy();
        }
        return d;
    }       
    
    /**
     * Checks whether the specified inputs are all non-null and of the same class 
     * and throws an exception one or both conditions are not met.  If the input
     * contains a matrix, the matrix dimensions are also checked for equivalence
     * and an exception thrown if they are not equivalent.
     * 
     * Does not check whether the inputs are appropriate for a given implementation
     * of {@link #aggregate(evs.metric.results.MetricResult[], evs.utilities.mathutil.VectorFunction, double[])} in a subclass.
     * 
     * @param input the input results to check
     * @param weights the weights to check
     */
    
    protected void checkAggInputs(MetricResult[] input, double[] weights) throws MetricResultException {
        MetricResultException n = new MetricResultException("Cannot aggregate the metric results for at least one metric, as one or more of the results are missing.");
        MetricResultException m = new MetricResultException("Cannot aggregate the metric results for at least one metric, as the results have different data dimensions.");
        if(input[0]==null) {
            throw n;
        }
        if(!(input[0] instanceof DoubleMatrix2DResultForModBoxUBLO)) {
            throw new MetricResultException("Expected instances of DoubleMatrix2DResultForModBoxUBLO in the input for aggregation, but received: "+input[0].getClass());
        }
        for(int i = 1; i < input.length; i++) {
            if(input[i]==null) {
                throw n;
            }
            if(!input[i].getClass().equals(input[0].getClass())) {
                throw new MetricResultException("Cannot aggregate the input results as they contain different data types.  Found: "+input[i].getClass()+". Expected: "+input[0].getClass());
            }
            if(((DoubleMatrix2DResult)input[i]).getResult().getColumnCount()
                            !=((DoubleMatrix2DResult)input[0]).getResult().getColumnCount()) {
                        throw m;
            }
        }
        
        //Check the weights
        if(weights == null) {
            throw new IllegalArgumentException("The aggregation weights must be non-null.");
        }
        if(input.length != weights.length) {
            throw new IllegalArgumentException("The number of weights must match the number of verification metrics.");
        }
        double sum = FunctionLibrary.total().apply(new DenseDoubleMatrix1D(weights));
        if(sum<0.9999 || sum > 1.0001) {
            throw new IllegalArgumentException("Weights must sum to 1.0: "+sum);
        }            
        
        
    }
    
    
}

    
