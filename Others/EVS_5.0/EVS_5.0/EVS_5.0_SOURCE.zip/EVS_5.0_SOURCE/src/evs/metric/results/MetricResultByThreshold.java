package evs.metric.results;

//Java util dependencies
import java.util.*;

//EVS dependencies
import evs.utilities.mathutil.*;
import evs.metric.parameters.*;

/**
 * Stores a set of metric results by a threshold value.  Extends evs.metric.MetricResult
 * for convenience.  A single store supports only one class of metric result so that 
 * the getter methods will always return an object of that class or null.  
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class MetricResultByThreshold extends MetricResultStore {
    
    /********************************************************************************
     *                                                                              *
     *                                 CONSTRUCTOR                                  *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Constructs a store with a specified type of metric result as the store type.  
     * Subsequently attempting to add metrics of a different result type will throw
     * an exception.  See the evs.metric.results.MetricResult class for supported types.
     *
     * @param storedID the result type id
     */
    
    public MetricResultByThreshold(int storedID) {
        super(storedID);
        if(storedID==METRIC_RESULT_BY_THRESHOLD) {
            throw new IllegalArgumentException("Cannot create a result store within " +
                    "a result store of the same type: "+getClass().getSimpleName()+".");
        }
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/     
     
    /**
     * Returns the type of result.  
     *
     * @return the type of result
     */
    
    public int getID() {
        return METRIC_RESULT_BY_THRESHOLD; 
    }    
    
    /**
     * Applies an aggregation function to the corresponding values (e.g. same 
     * matrix position) in the input results, placing a Metric.NULL_DATA if all 
     * of those values are Metric.NULL_DATA.  Throws an exception if the inputs
     * are not of the same class.  The return type may not correspond to the input
     * type if the result of the aggregation function cannot be stored in the input
     * type.  Specifically, any aggregation of a result that contains integers 
     * should ALWAYS return a result that contains doubles, as the aggregation 
     * function is guaranteed to do so.  For example, the average of a set of 
     * integers may not be an integer.  Specify a set of weights for each metric
     * that are constant across all forecast lead times.  The weights must sum to 1.
     * 
     * @param input the input results
     * @param func the aggregation function
     * @param weights the constant weights to apply across all lead times
     * @return the aggregated result   
     */
 
    public MetricResult aggregate(MetricResult[] input, VectorFunction func, double[] weights) throws MetricResultException {
        checkAggInputs(input,weights);  //Throws an exception if inputs are invalid
        //Check inputs are correct
        if(input[0].getID()!=METRIC_RESULT_BY_THRESHOLD) {
            throw new MetricResultException("Expected instances of MetricResultByThreshold in the input for aggregation, but received: "+input[0].getClass());
        }
        //Collect the results together for each threshold and then aggregate
        TreeMap<DoubleProcedureParameter,Vector<MetricResult>> byThresh = new TreeMap();            
        for(int i = 0; i < input.length; i++) {
            Iterator it = ((MetricResultByThreshold)input[i]).getResults().keySet().iterator();
            while(it.hasNext()) {
                DoubleProcedureParameter next = (DoubleProcedureParameter)it.next();
                MetricResult res = ((MetricResultByThreshold)input[i]).getResult(next);
                if(byThresh.containsKey(next)) {
                    Vector<MetricResult> v = byThresh.get(next);
                    //If v is smaller than the current input index, add nulls to make up to current index
                    int diff = i-v.size();
                    if(diff!= 0) {
                        for(int k = 0; k < diff; k++) {
                            v.add(null);
                        }
                    }
                    v.add(res);  //Will be added to correct position
                }
                else {
                    Vector<MetricResult> v = new Vector();
                    v.add(res);
                    byThresh.put(next,v);
                }
            }
        }

        MetricResultByThreshold newRes = null;
        Iterator it2 = byThresh.keySet().iterator();
        while(it2.hasNext()) {
            DoubleProcedureParameter next = (DoubleProcedureParameter)it2.next();
            Vector<MetricResult> mets = byThresh.get(next);
            MetricResult[] res = new MetricResult[mets.size()];
            res = mets.toArray(res);
            //Determine if any results are missing and adjust weights accordingly
            double redSum = 0.0;  //Reduced sum after eliminating missing weights 
            Vector<MetricResult> inc = new Vector();
            Vector<Double> wgh = new Vector();
            for(int i = 0; i < res.length; i++) {
                if(res[i]!=null) {
                    inc.add(res[i]);
                    wgh.add(weights[i]);
                    redSum+=weights[i];
                }
            }
            if(wgh.size()<input.length) {
                System.out.println("Rescaling weights at threshold "+next+" due to missing metrics.");
            }
            MetricResult[] res2 = new MetricResult[inc.size()];
            res2 = inc.toArray(res2);
            double[] newW = new double[wgh.size()];
            double mFac = 1.0/redSum;
            for(int i = 0; i < newW.length; i++) {
                newW[i]=wgh.get(i)*mFac;
            }
            
            MetricResult nm = res[0].aggregate(res2,func,newW);  //Aggregate
            if(newRes==null) {
                newRes = new MetricResultByThreshold(nm.getID());
            }
            newRes.addResult(next,nm);
        }
        return newRes;  
    }     
    
    /**
     * Returns a metric result for a specified threshold.
     *
     * @param threshold the threshold 
     * @return a metric result or null
     */
    
    public MetricResult getResult(DoubleProcedureParameter threshold) {
        return (MetricResult)results.get(threshold);
    }

    /**
     * Returns the first threshold in the store or throws an exception if
     * no thresholds are available.
     *
     * @return the first threshold
     */

    public DoubleProcedureParameter getFirstThreshold() throws IllegalArgumentException {
        if(results == null || results.size()==0) {
            throw new IllegalArgumentException("No thresholds available.");
        }
        return (DoubleProcedureParameter)results.firstKey();
    }
    
    /**
     * Returns a set of metric results or an empty map.
     * 
     * @return the metric results
     */
    
    public TreeMap<DoubleProcedureParameter,MetricResult> getResults() {
        return results;
    }     
    
    /**
     * Convenience method that returns results for a specified component of a 
     * score decomposition. Throws an exception if the stored results are not
     * of type evs.metric.results.EnsembleScoreDecomposition or if the specified
     * component is not one of the class variables in that class.
     * 
     * @param comp the score component
     * @return the results for a specified component of a score
     */
    
    public MetricResultByThreshold getResultsForScoreComp(int comp) throws IllegalArgumentException {
        if(getIDForStoredResults()!=MetricResult.ENSEMBLE_SCORE_DECOMPOSITION_RESULT) {
            throw new IllegalArgumentException("The stored results do not originate from an ensemble score decomposition.");
        }
        MetricResultByThreshold m = new MetricResultByThreshold(MetricResult.DOUBLE_RESULT);
        Iterator it = results.keySet().iterator();
        while(it.hasNext()) {
            DoubleProcedureParameter n = (DoubleProcedureParameter)it.next();
            DoubleResult add = ((EnsembleScoreDecomposition)results.get(n)).getComponent(comp);
            m.addResult(n,add);
        }
        return m;
    }    
    
    /**
     * Returns true if a metric result exists for a specified threshold.
     *
     * @param threshold the threshold
     * @return true if a metric result exists, false otherwise
     */
    
    public boolean hasResult(DoubleProcedureParameter threshold) {
        return results.containsKey(threshold);
    }  
    
    /**
     * Returns a deep copy of the current metric result, where all instance variables 
     * occupy independent positions in memory from the current metric result.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricResult deepCopy() {
        MetricResultByThreshold returnMe = new MetricResultByThreshold(storedID);
        Iterator i = results.keySet().iterator();
        while(i.hasNext()) {
            DoubleProcedureParameter next = (DoubleProcedureParameter)i.next(); 
            MetricResult nextResult = (MetricResult)results.get(next);
            returnMe.addResult(next,nextResult.deepCopy());
        }
        returnMe.intervals = deepCopyIntervals();
        if(hasMainInterval()) {
            returnMe.main = (ProbabilityIntervalParameter)main.deepCopy();
        }
        return returnMe;
    } 
    
    /********************************************************************************
     *                                                                              *
     *                               MUTATOR METHODS                                *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Adds a new result to the metric store.
     * 
     * @param threshold the threshold
     * @param result the metric result
     */
    
    public void addResult(DoubleProcedureParameter threshold, MetricResult result) throws IllegalArgumentException {
        super.addResult(threshold,result);
    }      
    
}
