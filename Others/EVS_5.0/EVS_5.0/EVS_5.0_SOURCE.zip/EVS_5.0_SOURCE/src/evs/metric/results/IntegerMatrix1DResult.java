package evs.metric.results;

//EVS dependencies
import evs.utilities.matrix.*;
import evs.utilities.mathutil.*;
import evs.metric.metrics.*;
import evs.metric.parameters.*;

//Java dependencies
import java.util.*;

/**
 * Immutable wrapper class for a 1D integer matrix that acts as a metric result.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public final class IntegerMatrix1DResult extends MetricResult {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLE                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * The metric result.
     */
    
    private IntegerMatrix1D result;
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs a metric result with an integer matrix.
     *
     * @param result the metric result
     */
    
    public IntegerMatrix1DResult(IntegerMatrix1D result) {
        this.result = result;
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Returns the type of result.  
     *
     * @return the type of result
     */
    
    public int getID() {
        return INTEGER_MATRIX_1D_RESULT;
    }
    
     /**
     * Applies an aggregation function to the corresponding values (e.g. same 
     * matrix position) in the input results, placing a Metric.NULL_DATA if all 
     * of those values are Metric.NULL_DATA.  Throws an exception if the inputs
     * are not of the same class.  The return type may not correspond to the input
     * type if the result of the aggregation function cannot be stored in the input
     * type.  Specifically, any aggregation of a result that contains integers 
     * should ALWAYS return a result that contains doubles, as the aggregation 
     * function is guaranteed to do so.  For example, the average of a set of 
     * integers may not be an integer.  Specify a set of weights for each metric
     * that are constant across all forecast lead times.  The weights must sume to 1.
     * 
     * @param input the input results
     * @param func the aggregation function
     * @param weights the constant weights to apply across all lead times
     * @return the aggregated result   
     */
    
    public MetricResult aggregate(MetricResult[] input, VectorFunction func,double[] weights) throws MetricResultException {
        checkAggInputs(input,weights);  //Throws an exception if inputs are invalid
        //Check inputs are correct
        if(input[0].getID()!=INTEGER_MATRIX_1D_RESULT) {
            throw new MetricResultException("Expected instances of IntegerMatrix1DResult in the input for aggregation, but received: "+input[0].getClass());
        }
        int rows = ((IntegerMatrix1DResult)input[0]).getResult().getRowCount();
        DenseDoubleMatrix1D im = new DenseDoubleMatrix1D(rows);
        for(int i = 0; i < rows; i++) {
            DenseDoubleMatrix1D in = new DenseDoubleMatrix1D(input.length);
            double wSum = 0.0;
            for(int j = 0; j < input.length; j++) {
                double nxt = ((IntegerMatrix1DResult)input[j]).getResult().get(i);
                in.set(j,nxt);
                if (nxt != Metric.NULL_DATA) {
                    wSum += weights[j];
                }
            }
            //Use reweighted sum in case values are missing
            if (wSum == 0.0) {  //All inputs null, specify null
                im.set(i, Metric.NULL_DATA);
            }
            else {
                double wMult = 1.0 / wSum;
                for (int j = 0; j < input.length; j++) {
                    if (in.get(j) != Metric.NULL_DATA) {
                        in.set(j, in.get(j) * weights[j] * wMult);
                    }
                }
                im.set(i, func.apply(in, Metric.NULL_DATA)); //Aggregate ith position
             }
        }
        return new DoubleMatrix1DResult(im);
    }    
        
    /**
     * Returns the metric result.
     *
     * @return the result
     */
    
    public IntegerMatrix1D getResult() {
        return result;
    }
    
    /**
     * Returns a string representation of the receiver.
     *
     * @return a string representation
     */
    
    public String toString() {
        return result+"";
    }    

    /**
     * Returns a string representation of the result for writing to an XML file
     * with a specified writing precision.  The results may be spread across several
     * strings to be written as individual nodes.
     *
     * @param precision the writing precision
     * @return a string representation for writing to XML
     */

    public String[] toXMLString(int precision) {
        StringBuffer buf = new StringBuffer();
        int rows = result.getRowCount();
        for (int j = 0; j < rows; j++) {
            int d = result.get(j);
            buf.append(d);
            if (j < (rows - 1)) {
                buf.append(", ");
            }
        }
        return new String[]{buf.toString()};
    }

    /**
     * Returns a deep copy of the current metric result, where all instance variables 
     * occupy independent positions in memory from the current metric result.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricResult deepCopy() {
        IntegerMatrix1DResult d = new IntegerMatrix1DResult((IntegerMatrix1D)result.deepCopy());
        d.intervals = deepCopyIntervals();
        if(hasMainInterval()) {
            d.main = (ProbabilityIntervalParameter)main.deepCopy();
        }
        return d;
    }

    @Override
    public TreeMap<ProbabilityIntervalParameter,MetricResult[]> getIntervalsFromResults(
        ProbabilityIntervalParameter[] intervals, MetricResult[] results, double nV, int minSampleSize)
            throws SamplingIntervalException {
        throw new SamplingIntervalException("Sampling uncertainty interval calculation not "
                + "implemented for result type '"+getClass().getSimpleName()+"'.");
    }

    /********************************************************************************
     *                                                                              *
     *                                  TEST METHOD                                 *
     *                                                                              *
     *******************************************************************************/

    /**
     * Main method.
     *
     * @param args the command line args
     */

    public static void main(String[] args) {
        int[] a = new int[]{-999,2,3,4};
        int[] b = new int[]{-999,10,11,12};
        int[] c = new int[]{-999,18,19,20};
        int[] d = new int[]{25,26,27,28};

        double[] weights = new double[]{0.0,0.0,0.5,0.5};
        IntegerMatrix1DResult r1 = new IntegerMatrix1DResult(new DenseIntegerMatrix1D(a));
        IntegerMatrix1DResult r2 = new IntegerMatrix1DResult(new DenseIntegerMatrix1D(b));
        IntegerMatrix1DResult r3 = new IntegerMatrix1DResult(new DenseIntegerMatrix1D(c));
        IntegerMatrix1DResult r4 = new IntegerMatrix1DResult(new DenseIntegerMatrix1D(d));
        VectorFunction tot = evs.utilities.mathutil.FunctionLibrary.total();
        MetricResult[] all = new MetricResult[]{r1,r2,r3,r4};
        System.out.println(r1.aggregate(all,tot,weights));
    }

}

    
