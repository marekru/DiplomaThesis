package evs.metric.metrics;

/**
 * An abstract base class for a metric that comprises a diagram.  Examples
 * include the reliability diagram and the Relative Operating Characteristic.
 *  
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public abstract class DiagramMetric extends Metric {


}
