package evs.metric.metrics;

//EVS dependencies
import evs.data.*;
import evs.metric.parameters.*;
import evs.metric.results.*;
import evs.utilities.*;
import evs.utilities.matrix.*;
import evs.utilities.mathutil.*;


//Java util dependencies
import java.util.*;

/**
 * The spread-bias plot shows the fraction of observations falling in a given
 * probability interval on the forecast support, which should be equal to the 
 * width of that interval (in the case of perfect reliability). 
 *
 * @author evs@hydrosolved.com
 */

public class SpreadBiasDiagram extends DiagramMetric implements EnsembleMetric, 
        ThresholdMetric, BootstrapableMetric {
    
    /********************************************************************************
     *                                                                              *
     *                                  VARIABLES                                   *
     *                                                                              *
     *******************************************************************************/   
    
    /**
     * Default number of bins to include in a spread-bias diagram.
     */
    
    private static SpreadBiasPointsParameter defPCount = new SpreadBiasPointsParameter(10);;      
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Attempts to construct a spread-bias diagram with associated parameters.
     *
     * @param pointCount the number of points to include in the diagram
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use 
     * conditional pairs when available
     * @param cent is true to center the windows around the ensemble median value (i.e. symmetric windows)
     * @param minS the minimum sample size
     * @param bs the bootstrap parameter
     */
    
    public SpreadBiasDiagram(SpreadBiasPointsParameter pointCount, ForecastTypeParameter fType, 
            UnconditionalParameter unconditional, CentralSpreadBiasParameter cent,
            MinimumSampleSizeParameter minS,BootstrapParameter bs) {
        //Set the name
        name = "Spread-bias diagram";
        //Specify an all-inclusive threshold condition
        ProbabilityIdentifierParameter p = new ProbabilityIdentifierParameter(false);
        DoubleParameter[] dubs = new DoubleParameter[]{new DoubleParameter(Double.NEGATIVE_INFINITY)};
        IntegerParameter p2 = new IntegerParameter(DoubleProcedureParameter.GREATER_THAN);
        //Set the parameters
        setParameters(new MetricParameter[]{new DoubleProcedureParameter(p2,dubs,p,
                new BooleanParameter(true)),pointCount.deepCopy(),fType.deepCopy(),
                unconditional.deepCopy(),cent.deepCopy(),minS.deepCopy(),bs.deepCopy()});
        //Set the link to html description of the metric
        descriptionURL = getClass().getResource(EVSConstants.STATS_EXPLAINED_DIR + "spreadbias.htm");       
    } 
    
    /**
     * Attempts to construct a spread-bias diagram with associated parameters.
     * 
     * @param threshold the threshold condition
     * @param pointCount the number of points to include in the diagram
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use 
     * conditional pairs when available
     * @param cent is true to center the windows around the ensemble median value (i.e. symmetric windows)
     * @param bs the bootstrap parameter
     */
    
    public SpreadBiasDiagram(DoubleProcedureParameter threshold,SpreadBiasPointsParameter pointCount,
            ForecastTypeParameter fType, UnconditionalParameter unconditional,
            CentralSpreadBiasParameter cent,MinimumSampleSizeParameter minS,BootstrapParameter bs) {
        this(pointCount,fType,unconditional,cent,minS,bs);
        pars[0]=threshold;
    }    
          
     /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/        
    
    /**
     * Returns the metric identifier.
     *
     * @return an identifier
     */
    
    public int getID() {
        if(isCentral()) {
            return MEDIAN_CENTRAL_SPREAD_BIAS;
        }
        return SPREAD_BIAS_DIAGRAM;
    }        
    
    /**
     * Returns the result type associated with the metric.  See the 
     * evs.metric.MetricResult class for supported types.
     *
     * @return an identifier
     */
    
    public int getResultID() {
        return MetricResult.DOUBLE_MATRIX_2D_RESULT;
    }         
    
    /**
     * Returns true if the metric is defined in real units of the forecast
     * and observed variable, false otherwise.
     * 
     * @return true if the metric is defined in real units
     */    

    public boolean hasRealUnits() {
        return false;
    }       
    
    /**
     * Returns the threshold associated with this threshold diagram.
     *
     * @return the threshold
     */
    
    public DoubleProcedureParameter getThreshold() {
        return (DoubleProcedureParameter)pars[0].deepCopy();
    }     
    
    /**
     * Returns true if the spread-bias diagram is median centered, false otherwise.
     * 
     * @return true if the diagram is centered around the forecast median
     */
    
    public boolean isCentral() {
        return ((CentralSpreadBiasParameter)pars[4]).getParVal();
    }
    
    /**
     * Returns a deep copy of the current metric, where all instance variables 
     * occupy independent positions in memory from the current metric.  
     *
     * @return a deep copy of the current object 
     */
    
    public Metric deepCopy() {
        SpreadBiasDiagram returnMe = new SpreadBiasDiagram(
                (DoubleProcedureParameter)pars[0].deepCopy(),
                (SpreadBiasPointsParameter)pars[1].deepCopy(),
                (ForecastTypeParameter)pars[2].deepCopy(),
                (UnconditionalParameter)pars[3].deepCopy(),
                (CentralSpreadBiasParameter)pars[4].deepCopy(),
                (MinimumSampleSizeParameter)pars[5].deepCopy(),
                getBootstrapPar());
        deepCopyResults(returnMe);
        return returnMe;
    }     

    /**
     * Returns the bootstrap parameter associated with the verification metric.
     *
     * @return the bootstrap parameter
     */
    @Override
    public BootstrapParameter getBootstrapPar() {
        return (BootstrapParameter)pars[6].deepCopy();
    }

    /**
     * Returns the default point count.  
     *
     * @return the default point count
     */
    
    public static PositiveIntegerParameter getDefaultPointCount() {
        return (PositiveIntegerParameter)defPCount.deepCopy();
    }
    
    /**
     * Returns a metric with default parameter values.  
     *
     * @return a metric with default parameter values.
     */
    
    public static Metric getDefaultMetric() { 
        ForecastTypeParameter type = new ForecastTypeParameter(new int[]{ForecastTypeParameter.REGULAR_FORECAST});
        return new SpreadBiasDiagram(defPCount,type,new UnconditionalParameter(false),
                new CentralSpreadBiasParameter(false),
                new MinimumSampleSizeParameter(),new BootstrapParameter());
    }    
    
    /********************************************************************************
     *                                                                              *
     *                                MUTATOR METHODS                               *
     *                                                                              *
     *******************************************************************************/        
    
    /**
     * Uses the specified paired data to compute and return the result of the metric.
     * The metric results are returned, together with the sample counts, but not stored 
     * locally.  The metric result is located in the first index of the return array
     * and the sample counts are located in the second index. Optionally, specify
     * the results of a reference forecast from which to compute skill if the 
     * metric is a skill score. 
     * 
     * @param forecastType the forecast type
     * @param paired the paired data
     * @param refResult the results for a reference forecast (may be null)
     * @return the metric result and sample counts
     */
    
    public MetricResult[] compute(int forecastType, PairedData paired, MetricResult refResult) throws MetricCalculationException {
        if(paired==null) {
            throw new MetricCalculationException("Error computing metric '"+getName()+"': input pairs were null.");
        }
        ForecastTypeParameter.isSupportedForecastType(forecastType,true);
        MetricResult[] res = new MetricResult[2];
        DoubleProcedure pro = getThreshold().getParValReal();
        DoubleMatrix2D p = paired.getPairs();
        double nV = paired.getNullValue();
//        try {
            p = getConditionalPairs(pro, p);
            res[0]=getSpreadBias((DoubleMatrix2D)p.getSubmatrixByColumn(2,p.getColumnCount()-1),nV);
            res[1]=new IntegerResult(lastCount);
//        } catch (Exception e) {
//            //e.printStackTrace();
//        }
        return res; 
    }      
    
    /**
     * Sets the threshold for the current metric.    
     *
     * @param threshold the threshold
     */
    
    public void setThreshold(DoubleProcedureParameter threshold) {
        pars[0] = (DoubleProcedureParameter)threshold.deepCopy();
    }      

    /**
     * Sets the bootstrap parameter associated with the verification metric or
     * clears the parameter if the input is null;
     *
     * @param bs the bootstrap parameter
     */
    @Override
    public void setBootstrapPar(BootstrapParameter bs) {
        if(bs==null) {
            throw new IllegalArgumentException("The bootstrap parameter for metric '"+this+"' cannot be null.");
        } else {
            pars[6] = (BootstrapParameter)bs.deepCopy();
        }
    }

    /**
     * Sets the bootstrap parameter to BootstrapableMetric.NO_BOOTSTRAP and clears
     * all associated parameter values.
     */
    @Override
    public void clearBootstrapPar() {
        ((BootstrapParameter)pars[6]).clear();
    }

    /**
     * Returns the a spread-bias diagram dataset from an input dataset with the windows
     * in the second row and the reliability in the first row.  The input should comprise 
     * one column of observations (at index 0) and the remaining n columns should 
     * comprise the n ensemble members (index 1 through n). 
     *
     * @param data the input data
     * @param nV the null value
     * @return a spread-bias diagram
     */
    
    public MetricResult getSpreadBias(DoubleMatrix2D data, double nV) {      
        int count = ((SpreadBiasPointsParameter)pars[1]).getParVal();        
        boolean cent = ((CentralSpreadBiasParameter)pars[4]).getParVal();        
        double[] pThresh = new double[count+1];
        if(cent) {
            double inc = 0.5/count;
            for (int i = 0; i < count; i++) {
                pThresh[i + 1] = Mathematics.round((i + 1.0) * inc,5);
            }
        }
        else {
            double inc = 1.0/count;
            for (int i = 0; i < count; i++) {
                pThresh[i + 1] = Mathematics.round((i + 1.0) * inc,5);
            }
        }
        int length = pThresh.length;
        double[][] computeMe = new double[2][length];
        //Set the thresholds in the new array
        computeMe[0] = pThresh;
        int cols = data.getColumnCount();
        double[][] forecasts = ((DoubleMatrix2D)data.getSubmatrixByColumn(1,cols-1)).toArray();
        int fCount = forecasts.length;        
        double actualRows = 0;

        //Iterate through the forecast times
        for(int i = 0; i < fCount; i++) {
            //Determine the probability of the observation within the forecast distribution
            double obs = data.get(i,0);
            //Only increment the count if the observation falls within the forecast range
            //for the median-centered diagram
            Double min = null;
            Double max = null;
            for(int j = 0; j < forecasts[i].length; j++) {
                if(forecasts[i][j] != nV) {
                    if(min == null) {
                        min = forecasts[i][j];
                        max = min;
                    }
                    else {
                        if(forecasts[i][j] < min) {
                            min = forecasts[i][j];
                        }
                        else if(forecasts[i][j] > max) {
                            max = forecasts[i][j];
                        }
                    }
                }
            }
            if(obs != nV) {                
                //Get the empirical probability
                //double prob = 0;
                try {
                    //Iterate through the probability thresholds
                    //Only increment count if observation is within range for the
                    //median-centered diagram
                    double[] copy = new double[forecasts[i].length];
                    System.arraycopy(forecasts[i],0,copy,0,copy.length);
                    Arrays.sort(copy);
                    if (cent) {
                        if (obs >= min && obs <= max) {
                            for (int k = 0; k < length; k++) {
                                double lower = EmpiricalCDFCalculator.getVal(copy, (0.5 - pThresh[k]), nV, false);
                                double upper = EmpiricalCDFCalculator.getVal(copy, (0.5 + pThresh[k]), nV, false);
                                if (obs >= lower && obs <= upper) {
                                    computeMe[1][k] += 1.0;
                                }
                            }
                        }
                    } else {
                        for (int k = 0; k < length; k++) {
                            double val = EmpiricalCDFCalculator.getVal(copy, pThresh[k], nV, false);
                            if (obs <= val) {
                                computeMe[1][k] += 1.0;
                            }
                        }
                    }
                    actualRows+=1;
                } catch (Exception e) {
                    //Forecast[i] contains all null members
                }
            }
        }
        
        int minCount = ((MinimumSampleSizeParameter)pars[5]).getParVal();
        lastCount = (int)actualRows;
        if(actualRows < minCount) {
            throw new MetricCalculationException("Could not compute the spread-bias diagram: fewer samples than required ["+actualRows+","+minCount+"].");
        }   
        
        //Convert to probabilities
        for(int i = 0; i < computeMe[0].length; i++) {
            computeMe[1][i] = computeMe[1][i]/actualRows;
        }
        return new DoubleMatrix2DResult(new DenseDoubleMatrix2D(computeMe));
    }
    
}
