package evs.metric.parameters;

/**
 * Records the number of points in the box plot pooled by lead time.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public final class BoxPooledLeadPointsParameter extends PositiveIntegerParameter {
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs an object with an integer parameter value
     *
     * @param par the parameter value  
     */ 
    
    public BoxPooledLeadPointsParameter(int par) {  
        super(par);
    }
    
    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricParameter deepCopy() {
        return new BoxPooledLeadPointsParameter(par);
    }     
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
        
    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     * Remember to override in any subclass.
     *
     * @return an identifier
     */
    
    public int getID() {
        return BOX_POOLED_LEAD_POINTS_PARAMETER;
    }     
    
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "box_pooled_lead_points_parameter";
    }       
    
}
