package evs.metric.parameters;

//Java util depdencies
import java.util.Vector;

/**
 * Records the types of forecasts to be used in a verification study.  Specify
 * multiple forecast types for use in skill calculations.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ForecastTypeParameter implements MetricParameter {    
    
    /********************************************************************************
     *                                                                              *
     *                               CLASS VARIABLES                                *
     *                                                                              *
     *******************************************************************************/      
  
    /**
     * Indicator for a regular forecast type.
     */
    
    public static final int REGULAR_FORECAST = 101;
    
    /**
     * Indicator for a reference forecast for use in a skill calculation.
     */
    
    public static final int REFERENCE_FORECAST = 102;

    /**
     * Identifier for a forecast type used to compute sampling uncertainty, such
     * as a bootstrap realization.
     */

    public static final int RESAMPLED_FORECAST = 103;

    /**
     * Indicator for sample climatology as the reference forecast for use in a
     * skill calculation.
     */

    public static final int SAMPLE_CLIMATOLOGY = 104;

    /**
     * String identifier for sample climatology as the reference forecast.
     */

    public static final String SAMPLE_CLIMATOLOGY_STRING = "Sample climatology";

    /**
     * Identifier for a result based on a skill calculation.
     */
    
    public static final int SKILL = 105;
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLE                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     *
     * @return an identifier
     */
    
    public int getID() {
        return FORECAST_TYPE_PARAMETER;
    }    
    
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "forecast_type_parameter";
    }      
    
    /**
     * Unique identifiers of forecast types that will be used.
     */
    
    private Vector<Integer> willDo = null;
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs the parameter with a single type, namely REGULAR_FORECAST.
     */
    
    public ForecastTypeParameter() {
        willDo = new Vector();
        willDo.add(REGULAR_FORECAST);
    }    
    
    /**
     * Constructs the parameter with a specified forecast type
     * 
     * @param type the forecast type
     */
    
    public ForecastTypeParameter(int type) {
        checkType(type);
        willDo = new Vector();
        willDo.add(type);
    }        
    
    /**
     * Constructs the parameter with the unique identifiers of forecasts to include.  
     * See the MetricResult class for these identifiers.
     *
     * @param willDo the forecasts to include
     */
    
    public ForecastTypeParameter(Vector<Integer> willDo) throws IllegalArgumentException {
        for(int i = 0; i < willDo.size(); i++) {
            checkType(willDo.get(i));
        }
        this.willDo = willDo;
    }
    
    /**
     * Constructs the parameter with the unique identifiers of forecasts to include.  
     * See the MetricResult class for these identifiers.
     *
     * @param willDo the forecasts to include
     */
    
    public ForecastTypeParameter(int[] willDo) throws IllegalArgumentException {
        this.willDo = new Vector();
        for(int i = 0; i < willDo.length; i++) {
            checkType(willDo[i]);
            this.willDo.add(willDo[i]);
        }
    }    
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Returns true if the specified forecast type will be used.
     *
     * @param forecastType reference forecast identifier (see the MetricResult class)
     * @return true if the forecast type will be used
     */
    
    public boolean willDo(int forecastType) {
        return willDo.contains(forecastType);
    }    
    
    /**
     * Returns the array of forecast types.
     *
     * @return the forecast types
     */
    
    public Vector<Integer> getTypes() {
        return ((ForecastTypeParameter)deepCopy()).willDo;
    }
    
    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricParameter deepCopy() {
        Vector<Integer> copy = new Vector(willDo);
        return new ForecastTypeParameter(copy);
    }        
    
    /**
     * Override equals.  
     *
     * @param o the object to test against the current object
     * @return true if the objects are equal
     */
    
    public boolean equals(Object o) {
        return o instanceof ForecastTypeParameter && ((ForecastTypeParameter)o).willDo.equals(willDo);
    }     
    
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        assert false : "hashCode not implemented for MetricParameter.";
        return 1;
    }    
    
    /**
     * Returns true if the specified forecast type is supported, false otherwise.
     * 
     * @param fType the forecast type
     * @return true if the forecast type is supported.
     */
    
    public static boolean isSupportedForecastType(int fType) {
        boolean returnMe = false;
        returnMe = fType == REGULAR_FORECAST || fType == REFERENCE_FORECAST || fType == SKILL;
        return returnMe;
    }
    
    /**
     * Returns true if the specified forecast type is supported, false otherwise 
     * or throws an exception if throwEx is true and the result is false.
     * 
     * @param fType the forecast type
     * @param throwEx is true to throw an exception on false
     * @return true if the forecast type is supported.
     */
    
    public static boolean isSupportedForecastType(int fType, boolean throwEx) {
        boolean returnMe = isSupportedForecastType(fType);
        if(throwEx && !returnMe) {
            throw new IllegalArgumentException("The specified forecast type is unrecognized.");
        }
        return returnMe;
    }        
    
    /**
     * Returns a string representation of the parameter comprising the forecast
     * included type names separated by commas.
     *
     * @return a string representation
     */
    
    public String toString() {
        StringBuffer returnMe = new StringBuffer();
        int length = willDo.size();
        for(int i = 0; i < length; i++) {
            switch(willDo.get(i)) {
                case REGULAR_FORECAST: {
                    returnMe.append("regular");
                }; break;
                case REFERENCE_FORECAST: {
                    returnMe.append("baseline");
                }; break;
                case SKILL: {
                    returnMe.append("skill");
                }; break;
            }
            if(i < (length-1)) {
                returnMe.append(", ");
            }
        }
        return returnMe.toString();        
    }
    
    /********************************************************************************
     *                                                                              *
     *                               MUTATOR METHODS                                *
     *                                                                              *
     *******************************************************************************/    
    
    /**
     * Adds a forecast type to the list or throws an exception if the type is not
     * recognized.
     *
     * @param fType the forecast type to add.
     */
    
    public void addType(int fType) {
        checkType(fType);
        if(!willDo.contains(fType)) {
            willDo.add(fType);
        }
    }
    
    /********************************************************************************
     *                                                                              *
     *                               PRIVATE METHODS                                *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Checks the forecast type and throws an exception if the type is not recognized.
     *
     * @param fType the forecast type
     */
    
    private void checkType(int fType) {
        if(!isSupportedForecastType(fType)) {
            throw new IllegalArgumentException("Unsupported forecast type.");
        }
    }
    
    
}
