package evs.metric.metrics;

//EVS dependencies
import evs.metric.parameters.*;
import evs.metric.results.*;
import evs.utilities.*;
import evs.utilities.mathutil.*;
import evs.utilities.matrix.*;

//Java util dependencies
import java.util.Vector;

/**
 * Constructs a modified box-and-whisker plot with a set of thresholds.  The boxes
 * represent the empirical pdf of errors for the forecasts and are constructed per
 * lead time (i.e one box per real time for a single lead time), rather than pooled 
 * by lead time.   
 * 
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ModifiedBoxPlotUnpooledByLead extends ModifiedBoxPlot {

    /********************************************************************************
     *                                                                              *
     *                                  VARIABLES                                   *
     *                                                                              *
     *******************************************************************************/     

    /**
     * Default number of points to include in a ROC diagram.
     */
    
    private static BoxUnpooledPointsParameter defPCount = new BoxUnpooledPointsParameter(10);     
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/      
      
    /**
     * Attempts to construct a modified box plot with a set of thresholds and a
     * parameter indicating the forecast types for which the box plots will be 
     * constructed.
     *
     * @param points the number of thresholds to include in the boxes
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use 
     * conditional pairs when available
     */
    
    public ModifiedBoxPlotUnpooledByLead(BoxUnpooledPointsParameter points, ForecastTypeParameter fType, UnconditionalParameter unconditional) {
        //Set the name
        name = "Modified box plot per lead time";
        //Set the parameters
        setParameters(new MetricParameter[]{points,fType,unconditional});
        //Set the link to html description of the metric
        descriptionURL = getClass().getResource(EVSConstants.STATS_EXPLAINED_DIR + "boxbytime.htm");
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/      
  
    /**
     * Returns the metric identifier.
     *
     * @return an identifier
     */
    
    public final int getID() {
        return BOX_DIAGRAM_UNPOOLED_BY_LEAD;
    }      
    
    /**
     * Returns the result type associated with the metric.  See the 
     * evs.metric.MetricResult class for supported types.
     *
     * @return an identifier
     */
    
    public final int getResultID() {
        return MetricResult.DOUBLE_MATRIX_2D_RESULT;
    }      
    
    /**
     * Returns true if the metric is defined in real units of the forecast
     * and observed variable, false otherwise.
     * 
     * @return true if the metric is defined in real units
     */    

    public final boolean hasRealUnits() {
        return true;
    }       
    
    /**
     * Returns a deep copy of the current metric, where all instance variables 
     * occupy independent positions in memory from the current metric.  
     *
     * @return a deep copy of the current object 
     */
    
    public final Metric deepCopy() {
        ModifiedBoxPlotUnpooledByLead returnMe = new ModifiedBoxPlotUnpooledByLead((BoxUnpooledPointsParameter)pars[0].deepCopy(),(ForecastTypeParameter)pars[1].deepCopy(),(UnconditionalParameter)pars[2].deepCopy());
        deepCopyResults(returnMe);
        return returnMe;
    }    
    
    /**
     * Returns the default point count.  
     *
     * @return the default point count
     */
    
    public final static PositiveIntegerParameter getDefaultPointCount() {
        return (PositiveIntegerParameter)defPCount.deepCopy();
    }     
    
    /**
     * Returns a metric with default parameter values.  
     *
     * @return a metric with default parameter values.
     */
    
    public final static Metric getDefaultMetric() { 
        ForecastTypeParameter type = new ForecastTypeParameter(new int[]{ForecastTypeParameter.REGULAR_FORECAST});
        return new ModifiedBoxPlotUnpooledByLead(defPCount,type,new UnconditionalParameter(false)); 
    }     

    /********************************************************************************
     *                                                                              *
     *                              PROTECTED METHODS                               *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Returns a box dataset from an input dataset per lead time.  Hours from 
     * the start time are in the first column and the probability thresholds are 
     * in the first row.  The remaining columns and rows contain the real values of 
     * the probability thresholds for the boxes.
     *
     * @param data the input data
     * @param nV the null value
     * @return a box dataset
     */
    
    protected final MetricResult getBox(DoubleMatrix2D data, double nV) {
        int count = ((BoxUnpooledPointsParameter)pars[0]).getParVal();
        
        double inc = 1.0/count;
        double[] pThresh = new double[count+1];
        for(int i = 0; i < count; i++) {
            pThresh[i+1] = (i+1)*inc;
        }
        
        //Obtain the forecasts
        int cols = data.getColumnCount();
        double[][] forecasts = ((DoubleMatrix2D)data.getSubmatrixByColumn(3,cols-1)).toArray();
        int fCount = forecasts.length;
        int eCount = forecasts[0].length;
        Vector<double[]> res = new Vector();
        //Add the probability thresholds
        res.add(pThresh);
        double start = data.get(0,0);  //Start time in hours to be subtracted from all times
        //Iterate through the forecast times
        int actualRows = 0;
        for(int i = 0; i < fCount; i++) {
            //Subtract the observation from each ensemble member
            double obs = data.get(i,2);
            if(obs != nV) {
                boolean addSamp = false;
                for(int j = 0; j < eCount; j++) {
                    if(forecasts[i][j] != nV) {
                        forecasts[i][j]=forecasts[i][j]-obs;
                        addSamp = true;
                    }
                }
                if(addSamp) {
                    //Construct the empirical cdf
                    double[][] computeMe = EmpiricalCDFCalculator.getEmpiricalCDF(forecasts[i],pThresh,nV,true,false,false);    
                    double[] result = new double[computeMe[1].length+1];
                    result[0] = data.get(i,0)-start;
                    System.arraycopy(computeMe[1],0,result,1,computeMe[1].length);
                    res.add(result);    
                    actualRows++;
                }
            }
        }
        
        if(actualRows == 0) {
            lastCount = ZERO_SAMPLES;
            throw new MetricCalculationException("Could not compute box for specified input.");
        }
        else {
            lastCount=actualRows;
        }
        //Construct the double result
        DenseDoubleMatrix2D returnMe = new DenseDoubleMatrix2D(actualRows,res.get(1).length);
        for(int i = 0; i < actualRows; i++) {
            double[] next = res.get(i);
            //First row contains probability thresholds: add null at index 0, as first
            //column contains date
            if(i == 0) {
                returnMe.set(0,0,Metric.NULL_DATA);
                for(int j = 0; j < next.length; j++) {
                    returnMe.set(i,j+1,next[j]);
                }
            } else {
                for(int j = 0; j < next.length; j++) {
                    returnMe.set(i,j,next[j]);
                }
            }
        }
        return new DoubleMatrix2DResult(returnMe);
    }    
    
}
