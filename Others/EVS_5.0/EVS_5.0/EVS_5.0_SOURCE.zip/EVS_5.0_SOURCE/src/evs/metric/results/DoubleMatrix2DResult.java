package evs.metric.results;

//EVS dependencies
import evs.utilities.matrix.*;
import evs.utilities.mathutil.*;
import evs.metric.metrics.*;
import evs.metric.parameters.*;

//Java dependencies
import java.util.*;

/**
 * Immutable wrapper class for a 2D double matrix that acts as a metric result.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DoubleMatrix2DResult extends MetricResult {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLE                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * The metric result.
     */
    
    protected DoubleMatrix2D result;
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs a metric result with a double matrix.
     *
     * @param result the metric result
     */
    
    public DoubleMatrix2DResult(DoubleMatrix2D result) {
        if(result == null) {
            throw new IllegalArgumentException("Expected non-null data for the results store.");
        }
        this.result = result;
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Returns the type of result.  
     *
     * @return the type of result
     */
    
    public int getID() {
        return DOUBLE_MATRIX_2D_RESULT;
    }
    
     /**
     * Applies an aggregation function to the corresponding values (e.g. same 
     * matrix position) in the input results, placing a Metric.NULL_DATA if all 
     * of those values are Metric.NULL_DATA.  Throws an exception if the inputs
     * are not of the same class.  The return type may not correspond to the input
     * type if the result of the aggregation function cannot be stored in the input
     * type.  Specifically, any aggregation of a result that contains integers 
     * should ALWAYS return a result that contains doubles, as the aggregation 
     * function is guaranteed to do so.  For example, the average of a set of 
     * integers may not be an integer.  Specify a set of weights for each metric
     * that are constant across all forecast lead times.  The weights must sum to 1.
     * 
     * @param input the input results
     * @param func the aggregation function
     * @param weights the constant weights to apply across all lead times
     * @return the aggregated result   
     */
    
    public MetricResult aggregate(MetricResult[] input, VectorFunction func,double[] weights) throws MetricResultException {
        checkAggInputs(input,weights);  //Throws an exception if inputs are invalid
        //Check inputs are correct
        if(input[0].getID()!=DOUBLE_MATRIX_2D_RESULT) {
            throw new MetricResultException("Expected instances of DoubleMatrix2DResult in the input for aggregation, but received: "+input[0].getClass());
        }
        int rows = ((DoubleMatrix2DResult)input[0]).getResult().getRowCount();
        //The number of columns may vary with row, since some results do not instantiate every row
        //with equal columns (e.g. ROC curve with fitted ROC values sampled)
        double[][] im = new double[rows][];
        for(int i = 0; i < rows; i++) {
            int cols = ((DoubleMatrix2DResult)input[0]).getResult().getRowAt(i).getElementCount();
            im[i]=new double[cols];
            for(int j = 0; j < cols; j++) {
                DenseDoubleMatrix1D in = new DenseDoubleMatrix1D(input.length);
                double wSum = 0.0;
                for (int k = 0; k < input.length; k++) {
                    double nxt = ((DoubleMatrix2DResult)input[k]).getResult().get(i, j);
                    in.set(k,nxt);
                    if(nxt!=Metric.NULL_DATA) {
                        wSum+=weights[k];
                    }
                }
                //Use reweighted sum in case values are missing
                if(wSum==0.0) {  //All inputs null, specify null
                    im[i][j]=Metric.NULL_DATA;
                }
                else {
                    double wMult = 1.0 / wSum;
                    for (int k = 0; k < input.length; k++) {
                        if (in.get(k) != Metric.NULL_DATA) {
                            in.set(k, in.get(k) * weights[k] * wMult);
                        }
                    }
                    im[i][j] = func.apply(in, Metric.NULL_DATA); //Aggregate (i,j)th position
                }
            }
        }
        return new DoubleMatrix2DResult(new DenseDoubleMatrix2D(im));
    }     
    
    /**
     * Returns the metric result.
     *
     * @return the result
     */
    
    public DoubleMatrix2D getResult() {
        return result;
    }
    
    /**
     * Returns a string representation of the receiver.
     *
     * @return a string representation
     */
    
    public String toString() {
        String s = result.toString();
        s=s.replaceAll("-Infinity","All data");
        return s;
    }        
    
    /**
     * Returns a string representation of the result for writing to an XML file
     * with a specified writing precision.  The results may be spread across several
     * strings to be written as individual nodes.
     * 
     * @param precision the writing precision
     * @return a string representation for writing to XML
     */
    
    public String[] toXMLString(int precision) {
        int rows = result.getRowCount();
        String[] returnMe = new String[rows];
        for(int j = 0; j < rows; j++) {
            StringBuffer buf = new StringBuffer();
            int cols = result.getRowAt(j).getRowCount();
            for (int k = 0; k < cols; k++) {
                double d = result.get(j,k);
                if (Double.isInfinite(d)) {
                    buf.append("All data");
                } else {
                    buf.append(Mathematics.round(d, precision));
                }
                if (k < (cols - 1)) {
                    buf.append(", ");
                }
            }
            returnMe[j]=buf.toString();
        }
        return returnMe;      
    }

    /**
     * Strips columns with specified null data values and returns a deep copy of
     * the result.  Specify the row in which results should not be null.  The method may be
     * called recursively to eliminate null columns on the basis of several rows.
     *
     * @param nV the null value
     * @param row the row to search
     * @return the stripped result
     */

    public DoubleMatrix2DResult stripNullSamples(double nV, int row) {
        double[][] d = result.toArray();
        Vector<Integer> keep = new Vector<Integer>();
        for(int i = 0; i < d[0].length; i++) {
            if(d[row][i]!=nV) {
                keep.add(i);
            }
        }
        int sz = keep.size();

        double[][] ds = new double[d.length][sz];
        for(int i = 0; i < sz; i++) {
            for(int j = 0; j < d.length; j++) {
                ds[j][i]=d[j][keep.get(i)];
            }
        }
        DoubleMatrix2DResult rs = new DoubleMatrix2DResult(new DenseDoubleMatrix2D(ds));
        //Add the sampling intervals
        if (hasSamplingIntervals()) {
            TreeMap<ProbabilityIntervalParameter,MetricResult[]> ints = getIntervalResults();
            Iterator it = ints.keySet().iterator();
            while(it.hasNext()) {
                ProbabilityIntervalParameter pt = (ProbabilityIntervalParameter)it.next();
                MetricResult[] next = ints.get(pt);
                double[][] lower = new double[d.length][sz];
                double[][] upper = new double[d.length][sz];
                double[][] size = new double[d.length][sz];
                double[][] low = ((DoubleMatrix2DResult) next[0]).getResult().toArray();
                double[][] high = ((DoubleMatrix2DResult) next[1]).getResult().toArray();
                double[][] s = ((DoubleMatrix2DResult) next[2]).getResult().toArray();
                for (int i = 0; i < sz; i++) {
                    for (int j = 0; j < d.length; j++) {
                        lower[j][i] = low[j][keep.get(i)];
                        upper[j][i] = high[j][keep.get(i)];
                        size[j][i] = s[j][keep.get(i)];
                    }
                }
                rs.addSamplingInterval(pt,
                    new DoubleMatrix2DResult(new DenseDoubleMatrix2D(lower)),
                    new DoubleMatrix2DResult(new DenseDoubleMatrix2D(upper)),
                    new DoubleMatrix2DResult(new DenseDoubleMatrix2D(size)),
                    pt.equals(main));
            }
        }
        return rs;
    }

    /**
     * Returns a deep copy of the current metric result, where all instance variables 
     * occupy independent positions in memory from the current metric result.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricResult deepCopy() {
        DoubleMatrix2DResult d = new DoubleMatrix2DResult((DoubleMatrix2D)result.deepCopy());
        d.intervals = deepCopyIntervals();
        if(hasMainInterval()) {
            d.main = (ProbabilityIntervalParameter)main.deepCopy();
        }
        return d;
    }   

    @Override
    public TreeMap<ProbabilityIntervalParameter,MetricResult[]> getIntervalsFromResults(
        ProbabilityIntervalParameter[] intervals, MetricResult[] results, double nV, int minSampleSize)
            throws SamplingIntervalException {
        //Check the input
        checkIntervalsInput(getID(),intervals,results,minSampleSize);
        TreeMap<ProbabilityIntervalParameter, MetricResult[]> returnMe =
                new TreeMap<ProbabilityIntervalParameter, MetricResult[]>();

        //Set the results templates
        DoubleMatrix2D template = (DoubleMatrix2D)((DoubleMatrix2DResult)results[0]).result;
        template = (DoubleMatrix2D)template.assign(FunctionLibrary.assign(nV),false);
        int rows = ((DoubleMatrix2DResult)results[0]).result.getRowCount();
        for (ProbabilityIntervalParameter p : intervals) {
            DoubleMatrix2DResult addMe = new DoubleMatrix2DResult((DoubleMatrix2D)template.deepCopy());
            returnMe.put(p,new MetricResult[]{addMe,addMe.deepCopy(),addMe.deepCopy()});
        }
        
        //Iterate through the pointwise statistics
        for (int i = 0; i < rows; i++) {
            //Columns may not be constant, depending on metric (e.g. binormal ROC)
            int columns = ((DoubleMatrix2DResult) results[0]).result.getRowAt(i).getRowCount();
            for (int j = 0; j < columns; j++) {
                //Obtain the order statistics
                double[] points = new double[results.length];
                int nullCount = 0;
                for (int k = 0; k < points.length; k++) {
                    try {
                        points[k] = ((DoubleMatrix2DResult) results[k]).result.get(i,j);
                        if (points[k] == nV) {
                            nullCount++;
                        }
                    } catch (ArrayIndexOutOfBoundsException e) {
                        throw new SamplingIntervalException("Failed to compute the sampling intervals as one or more "
                                + "input results of type '" + getClass().getSimpleName() + "' had an inconsistent number "
                                + "of entries.");
                    }
                }
                //Order the data
                Arrays.sort(points);
                //Compute and return the results
                int actualSamples = points.length - nullCount;
                for (ProbabilityIntervalParameter p : intervals) {
                    MetricResult[] r = returnMe.get(p);
                    //Null intervals
                    if (actualSamples < minSampleSize) {
                        ((DoubleMatrix2DResult) r[0]).result.set(i,j, nV);
                        ((DoubleMatrix2DResult) r[1]).result.set(i,j, nV);
                        ((DoubleMatrix2DResult) r[2]).result.set(i,j, nV);
                    } //Valid intervals
                    else {
                        try {
                            double lower = EmpiricalCDFCalculator.getVal(points, p.getLower(), nV, false);
                            double upper = EmpiricalCDFCalculator.getVal(points, p.getUpper(), nV, false);
                            ((DoubleMatrix2DResult) r[0]).result.set(i,j, lower);
                            ((DoubleMatrix2DResult) r[1]).result.set(i,j, upper);
                            ((DoubleMatrix2DResult) r[2]).result.set(i,j, actualSamples);
                        } catch (Exception e) {
                            throw new SamplingIntervalException("Failed to compute sampling interval '" + p + "' with error "
                                    + "message: " + e.getMessage());
                        }
                    }
                }
            }
        }
        return returnMe;
    }

    /********************************************************************************
     *                                                                              *
     *                                  TEST METHOD                                 *
     *                                                                              *
     *******************************************************************************/

    /**
     * Main method.
     *
     * @param args the command line args
     */

    public static void main(String[] args) {
        double[][] a = new double[][]{{-999,2,3,4},{5,6,7,8}};
        double[][] b = new double[][]{{-999,10,11,12},{13,14,15,16}};
        double[][] c = new double[][]{{-999,18,19,20},{21,22,23,-999}};
        double[][] d = new double[][]{{25,26,27,28},{29,30,31,-999}};

        double[] weights = new double[]{0.0,0.0,0.5,0.5};
        DoubleMatrix2DResult r1 = new DoubleMatrix2DResult(new DenseDoubleMatrix2D(a));
        DoubleMatrix2DResult r2 = new DoubleMatrix2DResult(new DenseDoubleMatrix2D(b));
        DoubleMatrix2DResult r3 = new DoubleMatrix2DResult(new DenseDoubleMatrix2D(c));
        DoubleMatrix2DResult r4 = new DoubleMatrix2DResult(new DenseDoubleMatrix2D(d));
        VectorFunction tot = evs.utilities.mathutil.FunctionLibrary.total();
        MetricResult[] all = new MetricResult[]{r1,r2,r3,r4};
        System.out.println(r1.aggregate(all,tot,weights));

    }


    
}

    
