package evs.metric.parameters;

/**
 * An interface for the parameters required by a verification metric.  Define
 * appropriate subclasses for different parameter types, such as probability
 * thresholds.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public interface MetricParameter {

    /********************************************************************************
     *                                                                              *
     *                                  CONSTANTS                                   *
     *                                                                              *
     *******************************************************************************/    
   
    /**
     * Identifier for an {@link evs.metric.parameters.BooleanParameter}.
     */
    
    static final int BOOLEAN_PARAMETER = 501;

    /**
     * Identifier for an {@link evs.metric.parameters.DoubleParameter}.
     */
    
    static final int DOUBLE_PARAMETER = 502;

    /**
     * Identifier for an {@link evs.metric.parameters.ForecastTypeParameter}.
     */
    
    static final int FORECAST_TYPE_PARAMETER = 503;

    /**
     * Identifier for an {@link evs.metric.parameters.IntegerParameter}.
     */
    
    static final int INTEGER_PARAMETER = 504;
    
    /**
     * Identifier for an {@link evs.metric.parameters.PositiveIntegerParameter}.
     */
    
    static final int POSITIVE_INTEGER_PARAMETER = 505;
    
    /**
     * Identifier for an {@link evs.metric.parameters.ProbabilityArrayParameter}.
     */
    
    static final int PROBABILITY_ARRAY_PARAMETER = 506;
    
    /**
     * Identifier for an {@link evs.metric.parameters.ProbabilityParameter}.
     */
    
    static final int PROBABILITY_PARAMETER = 507;
    
    /**
     * Identifier for an {@link evs.metric.parameters.DoubleArrayParameter}.
     */
    
    static final int DOUBLE_ARRAY_PARAMETER = 508;    
            
    /**
     * Identifier for an {@link evs.metric.parameters.ROCPointsParameter}.
     */
    
    static final int ROC_POINTS_PARAMETER = 509;
    
    /**
     * Identifier for an {@link evs.metric.parameters.DecomposeParameter}.
     */
    
    static final int DECOMPOSE_PARAMETER = 510;

    /**
     * Identifier for an {@link evs.metric.parameters.UnconditionalParameter}.
     */
    
    static final int UNCONDITIONAL_PARAMETER = 511;
    
    /**
     * Identifier for an {@link evs.metric.parameters.DoubleProcedureParameter}.
     */
    
    static final int DOUBLE_PROCEDURE_PARAMETER = 512;    
    
    /**
     * Identifier for an {@link evs.metric.parameters.EqualSamplesParameter}.
     */
    
    static final int EQUAL_SAMPLES_PARAMETER = 513;    
    
    /**
     * Identifier for an {@link evs.metric.parameters.SpreadBiasPointsParameter}.
     */
    
    static final int SPREAD_BIAS_POINTS_PARAMETER = 514;   
    
    /**
     * Identifier for an {@link evs.metric.parameters.MCRPointsParameter}.
     */
    
    static final int MCR_POINTS_PARAMETER = 515;    

    /**
     * Identifier for an {@link evs.metric.parameters.MEPPointsParameter}.
     */
    
    static final int MEP_POINTS_PARAMETER = 516;       
    
    /**
     * Identifier for an {@link evs.metric.parameters.BoxPooledLeadPointsParameter}.
     */
    
    static final int BOX_POOLED_LEAD_POINTS_PARAMETER = 517;       
    
    /**
     * Identifier for an {@link evs.metric.parameters.BoxUnpooledPointsParameter}.
     */
    
    static final int BOX_UNPOOLED_POINTS_PARAMETER = 518;    
    
    /**
     * Identifier for an {@link evs.metric.parameters.BoxUnpooledObsPointsParameter}.
     */
    
    static final int BOX_UNPOOLED_OBS_POINTS_PARAMETER = 519;       
    
    /**
     * Identifier for an {@link evs.metric.parameters.DoubleProcedureArrayParameter}.
     */
    
    static final int DOUBLE_PROCEDURE_ARRAY_PARAMETER = 520;  
        
    /**
     * Identifier for an {@link evs.metric.parameters.ProbabilityIdentifierParameter}.
     */
    
    static final int PROBABILITY_IDENTIFIER_PARAMETER = 521;  
    
    /**
     * Identifier for an {@link evs.metric.parameters.CentralSpreadBiasParameter}.
     */
    
    static final int CENTRAL_SPREAD_BIAS_PARAMETER = 522;      
    
    /**
     * Identifier for an {@link evs.metric.parameters.ReliabilityPointsParameter}.
     */
    
    static final int RELIABILITY_POINTS_PARAMETER = 523;  
    
    /**
     * Identifier for an {@link evs.metric.parameters.ROCScorePointsParameter}.
     */
    
    static final int ROC_SCORE_POINTS_PARAMETER = 524;  
    
    /**
     * Identifier for an {@link evs.metric.parameters.ReferenceForecastParameter}.
     */
    
    static final int REFERENCE_FORECAST_PARAMETER = 525;

    /**
     * Identifier for an {@link evs.metric.parameters.VectorFunctionParameter}.
     */

    static final int VECTOR_FUNCTION_PARAMETER = 526;

    /**
     * Identifier for an {@link evs.metric.parameters.BooleanArrayParameter}.
     */

    static final int BOOLEAN_ARRAY_PARAMETER = 527;

    /**
     * Identifier for an {@link evs.metric.parameters.FittedROCParameter}.
     */

    static final int FITTED_ROC_PARAMETER = 528;

    /**
     * Identifier for an {@link evs.metric.parameters.FittedAUCParameter}.
     */

    static final int FITTED_AUC_PARAMETER = 529;

    /**
     * Identifier for an {@link evs.metric.parameters.ProbabilityIntervalParameter}.
     */

    static final int PROBABILITY_INTERVAL_PARAMETER = 530;

    /**
     * Identifier for an {@link evs.metric.parameters.BootstrapParameter}.
     */

    static final int BOOTSTRAP_PARAMETER = 531;

    /**
     * Identifier for an {@link evs.metric.parameters.StringArrayParameter}.
     */

    static final int STRING_ARRAY_PARAMETER = 532;

    /**
     * Identifier for an {@link evs.metric.parameters.StringParameter}.
     */

    static final int STRING_PARAMETER = 533;

    /**
     * Identifier for an {@link evs.metric.parameters.ROCScoreMethodParameter}.
     */

    static final int ROC_SCORE_METHOD_PARAMETER = 534;   
    
    /**
     * Identifier for an {@link evs.metric.parameters.RankHistSampleParameter}.
     */

    static final int RANK_HIST_SAMPLE_PARAMETER = 535;  
    
    /**
     * Identifier for an {@link evs.metric.parameters.MinimumSampleSizeParameter}.
     */

    static final int MINIMUM_SAMPLE_SIZE_PARAMETER = 536;      

    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/    
    
    /**
     * Enforces the return of an identifier for the parameter from the list of 
     * static final variables in this class.
     *
     * @return an identifier
     */
    
    public int getID();
    
    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current parameter.  
     *
     * @return a deep copy of the current object 
     */
    
    public MetricParameter deepCopy();    
    
    /**
     * Subclasses should override equals.  
     *
     * @param o the object to test against the current object
     * @return true if the objects are equal
     */
    
    public boolean equals(Object o);
    
    /**
     * Subclasses should override hashcode because they override equals.  The default
     * implementation is to assert false : not implemented and return an arbitrary int.   
     *
     * @return a hash code
     */
    
    public int hashCode();        
    
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName();
   
}
