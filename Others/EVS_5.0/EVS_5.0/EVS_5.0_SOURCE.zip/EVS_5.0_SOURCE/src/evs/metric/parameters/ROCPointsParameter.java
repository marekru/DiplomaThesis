package evs.metric.parameters;

/**
 * Records the number of points in the ROC diagram.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public final class ROCPointsParameter extends PositiveIntegerParameter {
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs an object with an integer parameter value
     *
     * @param par the parameter value  
     */ 
    
    public ROCPointsParameter(int par) {  
        super(par);
    }
    
    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricParameter deepCopy() {
        return new ROCPointsParameter(par);
    }     
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
        
    /**
     * Return an identifier for the parameter from the list in
     * {@link evs.metric.parameters.MetricParameter}
     *
     * @return an identifier
     */
    
    public int getID() {
        return ROC_POINTS_PARAMETER;
    }     
    
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "roc_points_parameter";
    }       
    
}
