package evs.metric.metrics;

//EVS dependencies
import evs.data.*;
import evs.analysisunits.*;
import evs.metric.parameters.*;
import evs.metric.results.*;
import evs.utilities.*;
import evs.utilities.matrix.*;
import evs.utilities.mathutil.*;

//Java util dependencies
import java.util.*;

/**
 * The mean capture rate diagram plots the average probability with which a 
 * randomly chosen ensemble member will have a given absolute error.
 *
 * @author evs@hydrosolved.com
 */

public class MeanCaptureRateDiagram extends DiagramMetric implements EnsembleMetric, 
        SingleValuedMetric, ThresholdMetric, BootstrapableMetric {
    
    /********************************************************************************
     *                                                                              *
     *                                  VARIABLES                                   *
     *                                                                              *
     *******************************************************************************/     
 
    /**
     * Default number of points to include in a MCR diagram.
     */
    
    private static MCRPointsParameter defPCount = new MCRPointsParameter(10);    
    
    /**
     * The function to apply to forecasts with multiple values if required.
     */
    
    private VectorFunction forecastStat = null;

    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Attempts to construct a mean capture rate diagram with associated parameters.
     *
     * @param probs the probabilities at which the mean capture rate is computed
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use 
     * conditional pairs when available
     * @param minS the minimum sample size
     * @param bs the bootstrap parameter
     */
    
    public MeanCaptureRateDiagram(MCRPointsParameter probs, ForecastTypeParameter fType, 
            UnconditionalParameter unconditional,MinimumSampleSizeParameter minS,BootstrapParameter bs) {
        //Set the name
        name = "Mean capture rate diagram";
        //Set the parameters
        //Specify an all-inclusive threshold condition
        ProbabilityIdentifierParameter p = new ProbabilityIdentifierParameter(false);
        DoubleParameter[] dubs = new DoubleParameter[]{new DoubleParameter(Double.NEGATIVE_INFINITY)};
        IntegerParameter p2 = new IntegerParameter(DoubleProcedureParameter.GREATER_THAN);
        setParameters(new MetricParameter[]{new DoubleProcedureParameter(p2,dubs,p,new BooleanParameter(true))
                ,probs.deepCopy(),fType.deepCopy(),unconditional.deepCopy(),minS.deepCopy(),bs.deepCopy()});
        //Set the link to html description of the metric
        descriptionURL = getClass().getResource(EVSConstants.STATS_EXPLAINED_DIR + "mcr.htm");
    }
    
    /**
     * Attempts to construct a mean capture rate diagram with a set of probability points
     * for the probability axis and the forecast types for which the diagram is required.
     * Specify a threshold condition from which to obtain a subset of pairs for analysis.
     *
     * @param probs the probabilities at which the mean capture rate is computed
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use 
     * conditional pairs when available
     * @param threshold the threshold
     * @param minS the minimum sample size
     * @param bs the bootstrap parameter
     */
    
    public MeanCaptureRateDiagram(DoubleProcedureParameter threshold, MCRPointsParameter probs, 
            ForecastTypeParameter fType, UnconditionalParameter unconditional,
            MinimumSampleSizeParameter minS,BootstrapParameter bs) {
        this(probs,fType,unconditional,minS,bs);
        pars[0]=threshold;
    }    
        
     /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/        

    /**
     * Returns the forecast statistic to be applied to paired input that comprise
     * multiple forecasts at a single time (e.g. ensemble forecast input).    
     *
     * @return the forecast statistic
     */
    
    public VectorFunction getForecastStatistic() {
        return forecastStat;
    }    
    
    /**
     * Returns true if a forecast statistic has been set, false otherwise.
     * 
     * @return true if a forecast statistic has been set.
     */
    
    public boolean hasForecastStatistic() {
        return forecastStat != null;
    }        
    
    /**
     * Returns the metric identifier.
     *
     * @return an identifier
     */
    
    public int getID() {
        return MCRD;
    }   
    
    /**
     * Returns true if the metric is defined in real units of the forecast
     * and observed variable, false otherwise.
     * 
     * @return true if the metric is defined in real units
     */    

    public boolean hasRealUnits() {
        return true;
    }       
    
    /**
     * Returns the threshold associated with this threshold diagram.
     *
     * @return the threshold
     */
    
    public DoubleProcedureParameter getThreshold() {
        return (DoubleProcedureParameter)pars[0];
    }  
    
    /**
     * Returns the result type associated with the metric.  See the 
     * evs.metric.MetricResult class for supported types.
     *
     * @return an identifier
     */
    
    public int getResultID() {
        return MetricResult.DOUBLE_MATRIX_2D_RESULT;
    }     
    
    /**
     * Returns a deep copy of the current metric, where all instance variables 
     * occupy independent positions in memory from the current metric.  
     *
     * @return a deep copy of the current object 
     */
    
    public Metric deepCopy() {
        MeanCaptureRateDiagram returnMe = new MeanCaptureRateDiagram(
                (DoubleProcedureParameter)pars[0].deepCopy(),(MCRPointsParameter)pars[1].deepCopy(),
                (ForecastTypeParameter)pars[2].deepCopy(),
                (UnconditionalParameter)pars[3].deepCopy(),
                (MinimumSampleSizeParameter)pars[4].deepCopy(),
                getBootstrapPar());
        deepCopyResults(returnMe);
        return returnMe;
    }

    /**
     * Returns the bootstrap parameter associated with the verification metric.
     *
     * @return the bootstrap parameter
     */
    @Override
    public BootstrapParameter getBootstrapPar() {
        return (BootstrapParameter)pars[5].deepCopy();
    }

    /**
     * Returns the default point count.
     *
     * @return the default point count
     */

    public static PositiveIntegerParameter getDefaultPointCount() {
        return (PositiveIntegerParameter)defPCount.deepCopy();
    }

    /**
     * Returns a metric with default parameter values.  
     *
     * @return a metric with default parameter values.
     */
    
    public static Metric getDefaultMetric() { 
        ForecastTypeParameter type = new ForecastTypeParameter(new int[]{ForecastTypeParameter.REGULAR_FORECAST});
        return new MeanCaptureRateDiagram(defPCount,type,
                new UnconditionalParameter(false),new MinimumSampleSizeParameter(),
                new BootstrapParameter());
    } 
    
     /********************************************************************************
     *                                                                              *
     *                                MUTATOR METHODS                               *
     *                                                                              *
     *******************************************************************************/        
    
    /**
     * Uses the specified paired data to compute and return the result of the metric.
     * The metric results are returned, together with the sample counts, but not stored 
     * locally.  The metric result is located in the first index of the return array
     * and the sample counts are located in the second index. Optionally, specify
     * the results of a reference forecast from which to compute skill if the 
     * metric is a skill score. 
     * 
     * @param forecastType the forecast type
     * @param paired the paired data
     * @param refResult the results for a reference forecast (may be null)
     * @return the metric result and sample counts
     */
    
    public MetricResult[] compute(int forecastType, PairedData paired, MetricResult refResult) throws MetricCalculationException {
        if(paired==null) {
            throw new MetricCalculationException("Error computing metric '"+getName()+"': input pairs were null.");
        }
        ForecastTypeParameter.isSupportedForecastType(forecastType,true);
        MetricResult[] res = new MetricResult[2];
        DoubleProcedure pro = getThreshold().getParValReal();
        DoubleMatrix2D p = paired.getPairs();   
        double nV = paired.getNullValue();
//        try {
            p = getConditionalPairs(pro, p);
            res[0]=getMCR((DoubleMatrix2D)p.getSubmatrixByColumn(2,p.getColumnCount()-1),nV);
            res[1]=new IntegerResult(lastCount);
//        } catch (Exception e) {
//            //e.printStackTrace();
//        }
        return res; 
    }     

    /**
     * Sets the forecast statistic to be applied to paired input that comprise
     * multiple forecasts at a single time (e.g. ensemble forecast input).
     *
     * @param forecastStat the forecast statistic
     */

    public void setForecastStatistic(VectorFunction forecastStat) {
        if(forecastStat == null) {
            throw new IllegalArgumentException("Cannot use a null forecast statistic.");
        }
        this.forecastStat = forecastStat;
    }

    /**
     * Sets the threshold for the current metric.
     *
     * @param threshold the threshold
     */

    public void setThreshold(DoubleProcedureParameter threshold) {
        pars[0] = (DoubleProcedureParameter)threshold.deepCopy();
    }

    /**
     * Sets the bootstrap parameter associated with the verification metric or
     * clears the parameter if the input is null;
     *
     * @param bs the bootstrap parameter
     */
    @Override
    public void setBootstrapPar(BootstrapParameter bs) {
        if(bs==null) {
            throw new IllegalArgumentException("The bootstrap parameter for metric '"+this+"' cannot be null.");
        } else {
            pars[5] = (BootstrapParameter)bs.deepCopy();
        }
    }

    /**
     * Sets the bootstrap parameter to BootstrapableMetric.NO_BOOTSTRAP and clears
     * all associated parameter values.
     */
    @Override
    public void clearBootstrapPar() {
        ((BootstrapParameter)pars[5]).clear();
    }

    /**
     * Returns an MCR dataset from an input dataset.  The input should comprise one
     * column of observations (at index 0) and the remaining n columns should comprise
     * the n forecasts (index 1 through n). 
     *
     * @param data the input data
     * @param nV the null value
     * @return an MCR dataset
     */
    
    public MetricResult getMCR(DoubleMatrix2D data, double nV) {
        int count = ((MCRPointsParameter)pars[1]).getParVal();
        
        double inc = 1.0/count;
        double[] pThresh = new double[count+1];
        for(int i = 0; i < count; i++) {
            pThresh[i+1] = (i+1)*inc;
        }
        
        double[][] computeMe = null;

        //Obtain the forecasts
        int cols = data.getColumnCount();
        double[][] forecasts = ((DoubleMatrix2D)data.getSubmatrixByColumn(1,cols-1)).toArray();
        int fCount = forecasts.length;
        int eCount = cols-1;
        int actualRows = 0;
        
        //Iterate through the forecast times
        for(int i = 0; i < fCount; i++) {
            //Subtract the observation from each ensemble member
            double obs = data.get(i,0);
            if(obs != nV) {
                for(int j = 0; j < eCount; j++) {
                    if(forecasts[i][j] != nV) {
                        forecasts[i][j] = Math.abs(forecasts[i][j]-obs);
                    }
                }                
                //Compute the empirical cdf of absolute errors and increment the total
                if(computeMe == null) {
                    computeMe = EmpiricalCDFCalculator.getEmpiricalCDF(forecasts[i],pThresh,nV,true,false,false);
                }
                //Increment the total
                else {
                    double[] next = EmpiricalCDFCalculator.getEmpiricalCDF(forecasts[i],pThresh,nV,true,false,false)[1];
                    for(int j = 0; j < next.length; j++) {
                        computeMe[1][j] += next[j];
                    }
                }
                actualRows +=1;
            }
        }
        
        int minCount = ((MinimumSampleSizeParameter)pars[4]).getParVal();
        lastCount = actualRows;
        if(actualRows < minCount) {
            throw new MetricCalculationException("Could not compute the MCR: fewer samples than required ["+actualRows+","+minCount+"].");
        }        
        
        //Compute the average
        for(int j = 0; j < computeMe[0].length; j++) {
            computeMe[1][j]=(computeMe[1][j]/actualRows);
        }        
        return new DoubleMatrix2DResult(new DenseDoubleMatrix2D(computeMe));
    }    
    
}
