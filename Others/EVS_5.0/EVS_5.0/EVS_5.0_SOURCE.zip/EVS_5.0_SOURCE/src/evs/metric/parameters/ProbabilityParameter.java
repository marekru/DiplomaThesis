package evs.metric.parameters;

/**
 * Records a probability parameter for a verification metric.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ProbabilityParameter extends DoubleParameter {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLE                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Real value of the parameter.
     */
    
    private DoubleParameter realValue = null;
    
    /********************************************************************************
     *                                                                              *
     *                                ACCESSOR METHODS                              *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     *
     * @return an identifier
     */
    
    public final int getID() {
        return PROBABILITY_PARAMETER;
    }       
    
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public final String getName() {
        return "probability_parameter";
    }       
    
    /**
     * Constructs an object with a double parameter value.
     *
     * @param par the parameter value
     */
    
    public ProbabilityParameter(double par) {
        super(par);
        //Allow infinity as a valid value: this is used to denote all data
        if(!Double.isInfinite(par) && par < 0.0 || par > 1.0) {
            throw new IllegalArgumentException("Specify a valid probability ["+par+"].");
        } 
    }
    
    /**
     * Returns the real value of the probability parameter or null.
     *
     * @return the real value of the parameter.
     */
    
    public final DoubleParameter getRealValForProb() {
        return (DoubleParameter)realValue.deepCopy();
    }
    
    /**
     * Returns true if the real value of the probability parameter has been defined.
     *
     * @return true if the real value is set, false otherwise
     */
    
    public final boolean hasRealValueForProb() {
        return realValue != null;
    }
    
    /**
     * Returns a string representation of the receiver.
     *
     * @return a string representation
     */
    
    public final String toString() {
        if(realValue != null) {
            return realValue+" (Pr="+super.toString()+")";
        }
        return super.toString();
    }    
    
    /**
     * Override equals.  
     *
     * @param o the object to test against the current object
     * @return true if the objects are equal
     */
    
    public final boolean equals(Object o) {
        return super.equals(o) && ((DoubleParameter)o).getID() == PROBABILITY_PARAMETER;
    }     
    
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public final int hashCode() {
        assert false : "hashCode not implemented for MetricParameter.";
        return 1;
    }     
    
    /********************************************************************************
     *                                                                              *
     *                                 MUTATOR METHODS                              *
     *                                                                              *
     *******************************************************************************/        
    
    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
     
    public final MetricParameter deepCopy() {
        ProbabilityParameter p = new ProbabilityParameter(par);
        if(hasRealValueForProb()) {
            p.setRealValForProb((DoubleParameter)realValue.deepCopy());
        }
        return p;
    }             
    
    /**
     * Sets the real value of the probability parameter.
     *
     * @param realValue the real value of the probability parameter
     */
    
    public final void setRealValForProb(DoubleParameter realValue) {
        this.realValue = new DoubleParameter(realValue.getParVal());
    }    
    
}
