package evs.metric.metrics;

//EVS dependencies
import evs.data.*;
import evs.metric.parameters.*;
import evs.metric.results.*;
import evs.utilities.*;
import evs.utilities.matrix.*;
import evs.utilities.mathutil.*;

/**
 * The Brier skill score measures skill in terms of the Brier Score (BS) and is 
 * given by:
 * 
 * 1.0 - (BS of forecast system / BS of reference forecast system).
 *
 * @author evs@hydrosolved.com
 * @version 4.0 
 */

public class BrierSkillScore extends BrierScore implements SkillScore, EnsembleMetric, 
        ThresholdMetric, CategoricalMetric, BootstrapableMetric {

    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Attempts to construct a BSS object with associated parameters.
     *
     * @param event the event mark
     * @param decompose the decomposition indicator
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use conditional 
     * pairs when available
     * @param ref the reference forecasts used in the skill calculation
     * @param minS the minimum sample size
     * @param bs the bootstrap parameter
     */
    
    public BrierSkillScore(DoubleProcedureParameter event,DecomposeParameter decompose,
            ForecastTypeParameter fType, UnconditionalParameter unconditional,
            ReferenceForecastParameter ref,MinimumSampleSizeParameter minS,BootstrapParameter bs) {
        super(event,decompose,fType,unconditional,minS,bs);
        //Add an empty reference forecast paramater
        MetricParameter[] pars = new MetricParameter[this.pars.length+1];
        System.arraycopy(this.pars,0,pars,0,this.pars.length);
        pars[pars.length-1]=ref.deepCopy();
        this.pars=pars;
        //Set the name
        name = "Brier skill score";
        descriptionURL = getClass().getResource(EVSConstants.STATS_EXPLAINED_DIR + "bss.htm");
    }    

    /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/        
    
    /**
     * Returns the metric identifier.
     *
     * @return an identifier
     */
    
    public final int getID() {
        return BRIER_SKILL_SCORE;
    }         

    /**
     * Returns the name of the base metric for which the skill calculation is  
     * computed.
     * 
     * @return the base metric name
     */
    
    public final String getBaseMetricName() {
        return super.getName();
    }
    
    /**
     * Returns a deep copy of the current metric, where all instance variables 
     * occupy independent positions in memory from the current metric.  
     *
     * @return a deep copy of the current object 
     */
    
    public final Metric deepCopy() {
        BrierSkillScore returnMe = new BrierSkillScore((DoubleProcedureParameter)pars[0].deepCopy(),
                (DecomposeParameter)pars[1].deepCopy(),(ForecastTypeParameter)pars[2].deepCopy(),
                (UnconditionalParameter)pars[3].deepCopy(),
                (ReferenceForecastParameter)pars[6].deepCopy(),
                (MinimumSampleSizeParameter)pars[4].deepCopy(),getBootstrapPar());
        deepCopyResults(returnMe);
        return returnMe;
    }
    
    /**
     * Returns a reference forecast parameter.
     * 
     * @return the reference forecasts
     */
    
    public final ReferenceForecastParameter getRefFcst() throws IllegalArgumentException {
        return (ReferenceForecastParameter)getParameter(MetricParameter.REFERENCE_FORECAST_PARAMETER); 
    }

    /**
     * Returns true if the skill score has a default reference forecast.
     *
     * @return true if the skill score has a default reference forecasts.
     */

    public final boolean hasDefaultRefFcst() {
        return getRefFcst().hasRefForecast();
    }

    /**
     * Returns any default reference forecast implemented for the skill score,
     * such as sample climatology.
     *
     * @return the default reference forecast
     */

    public final ReferenceForecastParameter getDefaultRefFcst() throws IllegalArgumentException {
        ReferenceForecastParameter r = new ReferenceForecastParameter();
        r.setRefForecast(ForecastTypeParameter.SAMPLE_CLIMATOLOGY_STRING);
        return r;
    }

    /**
     * Returns the type of decomposition required. One of:
     * 
     * DecomposableScore.CALIBRATION_REFINEMENT
     * DecomposableScore.LIKELIHOOD_BASE_RATE
     * DecomposableScore.CR_AND_LBR
     * DecomposableScore.NONE  
     * 
     * @return the type of decomposition
     */
    
    public final int getScoreDecType() {
        return ((DecomposeParameter)pars[1]).getScoreDecType();
    }        
    
    /**
     * Returns an array of integer decompositions that have been implemented. 
     * Each int is one of:
     * 
     * DecomposableScore.CALIBRATION_REFINEMENT
     * DecomposableScore.LIKELIHOOD_BASE_RATE
     * DecomposableScore.CR_AND_LBR
     * DecomposableScore.NONE.  
     * 
     * @return an array of implemented decompositions.
     */
    @Override
    public final int[] getDecompositionOptions() {
        return new int[] {
            DecomposableScore.NONE,
            DecomposableScore.CALIBRATION_REFINEMENT,
            DecomposableScore.LIKELIHOOD_BASE_RATE,
            DecomposableScore.CR_AND_LBR
        };
    }        

    /**
     * Returns the bootstrap parameter associated with the verification metric.
     *
     * @return the bootstrap parameter
     */
    @Override
    public final BootstrapParameter getBootstrapPar() {
        return (BootstrapParameter)pars[5].deepCopy();
    }

    /**
     * Returns a metric with default parameter values.  
     *
     * @return a metric with default parameter values.
     */
    
    public static Metric getDefaultMetric() { 
        ProbabilityIdentifierParameter prob =new ProbabilityIdentifierParameter(true);
        DoubleProcedureParameter eT = new DoubleProcedureParameter(new IntegerParameter(DoubleProcedureParameter.GREATER_THAN),
                new DoubleParameter[]{new ProbabilityParameter(0.0)},prob, new BooleanParameter(true));
        ForecastTypeParameter type = new ForecastTypeParameter(new int[]{ForecastTypeParameter.REGULAR_FORECAST});
        BrierSkillScore s = new BrierSkillScore(eT,new DecomposeParameter(false),type,
                new UnconditionalParameter(false),new ReferenceForecastParameter(),
                new MinimumSampleSizeParameter(),new BootstrapParameter());
        ReferenceForecastParameter r = s.getDefaultRefFcst();
        s.pars[6]=r;
        return s;
    }   
    
    /********************************************************************************
     *                                                                              *
     *                               MUTATOR METHODS                                *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Uses the specified paired data to compute and return the result of the metric.
     * The metric results are returned, together with the sample counts, but not stored 
     * locally.  The metric result is located in the first index of the return array
     * and the sample counts are located in the second index. Optionally, specify
     * the results of a reference forecast from which to compute skill if the 
     * metric is a skill score. 
     * 
     * @param forecastType the forecast type
     * @param paired the paired data
     * @param refResult the results for a reference forecast (may be null)
     * @return the metric result and sample counts
     */
    
    public final MetricResult[] compute(int forecastType, PairedData paired, MetricResult refResult) throws MetricCalculationException {
        if(paired==null) {
            throw new MetricCalculationException("Error computing metric '"+getName()+"': input pairs were null.");
        }
        boolean sampleClimatology = getRefFcst().hasRefForecast(ForecastTypeParameter.SAMPLE_CLIMATOLOGY_STRING);
        //Skill calculation requested: need reference forecast or sample climatology
        if (forecastType == ForecastTypeParameter.REGULAR_FORECAST && !sampleClimatology) {
            if(refResult==null) {
                throw new IllegalArgumentException("Expected a non-null reference forecast result from which to compute the " + getName() + ".");
            }
            if(!(refResult instanceof EnsembleScoreDecomposition)) {
                throw new MetricCalculationException("Expected a reference forecast result of type " + EnsembleScoreDecomposition.class.getName() + ": " + refResult.getClass().getName());
            }
        }
        EnsembleScoreDecomposition ref = (EnsembleScoreDecomposition)refResult;
        MetricResult[] result = null;
        double nV = paired.getNullValue();
        double nullValue = Metric.NULL_DATA;  //Metric null value
                        
        if (forecastType == ForecastTypeParameter.REFERENCE_FORECAST) {
            result = super.compute(forecastType, paired, null);
        } else if (forecastType == ForecastTypeParameter.REGULAR_FORECAST) {
//            try {
                DoubleProcedure pro = getThreshold().getParValReal();
                result = new MetricResult[3];
                MetricResult[] num = super.compute(forecastType, paired, refResult);   //Sample size applies in superclass
                EnsembleScoreDecomposition nextNum = (EnsembleScoreDecomposition) num[0];
                //Reference forecast type: sample climatology    
                double referenceBS = 0;
                double referenceBSObs = 0;
                double referenceBSNotObs = 0;
                DoubleMatrix1D r = null;
                if (sampleClimatology) {
                    DoubleMatrix2D pairs = paired.getPairs();
                    //NOTE: no observations are eliminated here based on attributes of the forecasts
                    //such as all members being null. Thus, the climatology used may differ marginally
                    //from the sample climatology associated with the non-skill score
                    //Compute number of rows with indicator value 1 (i.e. p-value of Bernoulli RV)
                    double p = 0.0;
                    try {
                        double count = pairs.subRowsbyColCond(pro, 2, nV).getRowCount();
                        double total = pairs.getRowCount();
                        if(count==0 || count == total) {
                            //Equivalent to having insufficient samples
                            throw new MetricCalculationException("Variance of climatology is zero."); //Caught below
                        }
                        p =  count / total;
                        //Variance of Bernoulli RV with parameter p
                        referenceBS = p * (1.0 - p);
                        referenceBSObs = Math.pow((1.0 - p),2);
                        referenceBSNotObs = p * p;
                    } catch (Exception e) {
                        //Do nothing
                    }
                } //Reference forecast type: other   
                else {
                    referenceBS = ref.getComponent(OVERALL_SCORE).getResult();
                    if(ref.hasComponent(SCORE_GIVEN_OBS_TRUE)) {
                        referenceBSObs = ref.getComponent(SCORE_GIVEN_OBS_TRUE).getResult();
                    }
                    if(ref.hasComponent(SCORE_GIVEN_OBS_FALSE)) {
                        referenceBSNotObs = ref.getComponent(SCORE_GIVEN_OBS_FALSE).getResult();
                    }
                }
                //Construct the result
                switch (nextNum.getDecTemplate()) {
                    case NONE: {
                        double skill = 1.0 - (nextNum.getComponent(OVERALL_SCORE).getResult() / referenceBS);
                        r = new DenseDoubleMatrix1D(new double[]{skill});
                    }; break;
                    case CALIBRATION_REFINEMENT: {
                        double skill = 1.0 - (nextNum.getComponent(OVERALL_SCORE).getResult() / referenceBS);
                        double rel = nextNum.getComponent(RELIABILITY).getResult() / referenceBS;
                        double resol = nextNum.getComponent(RESOLUTION).getResult() / referenceBS;
                        double unc = nextNum.getComponent(UNCERTAINTY).getResult() / referenceBS;
                        r = new DenseDoubleMatrix1D(new double[]{skill, rel, resol, unc});
                    }; break;
                    case LIKELIHOOD_BASE_RATE: {
                        double skill = 1.0 - (nextNum.getComponent(OVERALL_SCORE).getResult() / referenceBS);
                        double type_II = nextNum.getComponent(TYPE_II_BIAS).getResult() / referenceBS;
                        double disc = nextNum.getComponent(DISCRIMINATION).getResult() / referenceBS;
                        double sha = nextNum.getComponent(SHARPNESS).getResult() / referenceBS;
                        r = new DenseDoubleMatrix1D(new double[]{skill, type_II, disc, sha});
                    }; break;
                    case CR_AND_LBR: {
                        double skill = 1.0 - (nextNum.getComponent(OVERALL_SCORE).getResult() / referenceBS);
                        double rel = nextNum.getComponent(RELIABILITY).getResult() / referenceBS;
                        double resol = nextNum.getComponent(RESOLUTION).getResult() / referenceBS;
                        double unc = nextNum.getComponent(UNCERTAINTY).getResult() / referenceBS;
                        double type_II = nextNum.getComponent(TYPE_II_BIAS).getResult() / referenceBS;
                        double disc = nextNum.getComponent(DISCRIMINATION).getResult() / referenceBS;
                        double sha = nextNum.getComponent(SHARPNESS).getResult() / referenceBS;
                        //Score when the event was observed
                        //Score when the event was observed to not occur
                        //Type-II conditional bias when the event was observed
                        //Type-II conditional bias when the event was observed to not occur
                        //Discrimination when the event was observed
                        //Discrimination when the event was observed to not occur                              
                        double scoreObsTrue = nullValue;
                        double scoreObsFalse = nullValue;
                        double T2ObsTrue = nullValue;
                        double T2ObsFalse = nullValue;
                        double disObsTrue = nullValue;
                        double disObsFalse = nullValue;
                        double relSkillScore = nullValue;
                        double resSkillScore = nullValue;
                        double T2SkillScore = nullValue;
                        double discSkillScore = nullValue;
                        double sharpSkillScore = nullValue;
                        if(referenceBSObs!=0) {
                            scoreObsTrue = nextNum.getComponent(SCORE_GIVEN_OBS_TRUE).getResult() / referenceBSObs;
                            T2ObsTrue = nextNum.getComponent(TYPE_II_BIAS_GIVEN_OBS_TRUE).getResult() / referenceBSObs;
                            disObsTrue = nextNum.getComponent(DISCRIMINATION_GIVEN_OBS_TRUE).getResult() / referenceBSObs;
                        }
                        if(referenceBSNotObs!=0) {
                            scoreObsFalse = nextNum.getComponent(SCORE_GIVEN_OBS_FALSE).getResult() / referenceBSNotObs;
                            T2ObsFalse = nextNum.getComponent(TYPE_II_BIAS_GIVEN_OBS_FALSE).getResult() / referenceBSNotObs;
                            disObsFalse = nextNum.getComponent(DISCRIMINATION_GIVEN_OBS_FALSE).getResult() / referenceBSNotObs;
                        }
                        if(!sampleClimatology) {
                            double relM = nextNum.getComponent(RELIABILITY).getResult();
                            double resolM = nextNum.getComponent(RESOLUTION).getResult();
                            double type_IIM = nextNum.getComponent(TYPE_II_BIAS).getResult();
                            double discM = nextNum.getComponent(DISCRIMINATION).getResult();
                            double shaM = nextNum.getComponent(SHARPNESS).getResult();
                            double relR = ref.getComponent(RELIABILITY).getResult();
                            double resolR = ref.getComponent(RESOLUTION).getResult();
                            double type_IIR = ref.getComponent(TYPE_II_BIAS).getResult();
                            double discR = ref.getComponent(DISCRIMINATION).getResult();
                            double shaR = ref.getComponent(SHARPNESS).getResult();
                            if(relR!=nullValue) {
                                relSkillScore = 1.0 - (relM/relR);  //Positively-oriented (positive = good, zero = no skill)
                            }
                            if(shaR!=nullValue) {
                                sharpSkillScore = 1.0 - (shaM/shaR); //Positively-oriented (positive = good, zero = no skill)
                            } 
                            if(type_IIR!=nullValue) {
                                T2SkillScore = 1.0 - (type_IIM/type_IIR); //Positively-oriented (positive = good, zero = no skill)
                            }
                            if(resolR!=nullValue) {
                                resSkillScore = (resolM/resolR) - 1.0;  //Positively-oriented (positive = good, zero = no skill)
                            }
                            if(discR!=nullValue) {
                                discSkillScore = (discM/discR) - 1.0;  //Positively-oriented (positive = good, zero = no skill)
                            }
                        }
                        r = new DenseDoubleMatrix1D(new double[]{skill, rel, resol, unc, type_II, disc,
                            sha, scoreObsTrue, scoreObsFalse, T2ObsTrue, T2ObsFalse, disObsTrue, disObsFalse,
                            relSkillScore,resSkillScore,T2SkillScore,discSkillScore,sharpSkillScore});
                    }; break;
                }
                if (r != null) {
                    //Check for NaN/Infinite
                    int rows = r.getRowCount();
                    for (int i = 0; i < rows; i++) {
                        double v = r.get(i);
                        if (Double.isNaN(v) || Double.isInfinite(v)) {
                            r.set(i, nullValue);
                        }
                    }
                    result[0] = new EnsembleScoreDecomposition(nextNum.getDecTemplate(), r);
                    result[1] = num[1].deepCopy();
                }
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
        }
        return result;
    }     

    /**
     * Sets the bootstrap parameter associated with the verification metric or
     * clears the parameter if the input is null;
     *
     * @param bs the bootstrap parameter
     */
    @Override
    public final void setBootstrapPar(BootstrapParameter bs) {
        if(bs==null) {
            throw new IllegalArgumentException("The bootstrap parameter for metric '"+this+"' cannot be null.");
        } else {
            pars[5] = (BootstrapParameter)bs.deepCopy();
        }
    }

    /**
     * Sets the bootstrap parameter to BootstrapableMetric.NO_BOOTSTRAP and clears
     * all associated parameter values.
     */
    @Override
    public final void clearBootstrapPar() {
        ((BootstrapParameter)pars[5]).clear();
    }
    
}
    