package evs.metric.parameters;

/**
 * Records a boolean parameter for a verification metric.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class BooleanParameter implements MetricParameter {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLE                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Is true if the parameter value is true.
     */
    
    protected boolean isTrue = false;
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs an object with a boolean parameter value
     *
     * @param isTrue the boolean parameter value
     */
    
    public BooleanParameter(boolean isTrue) {
        this.isTrue = isTrue;
    }
    
    /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     *
     * @return an identifier
     */
    
    public int getID() {
        return BOOLEAN_PARAMETER;
    }
    
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "boolean_parameter";
    }
    
    /**
     * Returns the parameter value.
     *
     * @return the parameter value
     */
    
    public boolean getParVal() {
        return isTrue;
    }    
     
    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricParameter deepCopy() {
        return new BooleanParameter(isTrue);
    }      
    
    /**
     * Override equals.  
     *
     * @param o the object to test against the current object
     * @return true if the objects are equal
     */
    
    public boolean equals(Object o) {
        return o instanceof BooleanParameter && ((BooleanParameter)o).isTrue == isTrue;
    } 
    
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        assert false : "hashCode not implemented for MetricParameter.";
        return 1;
    }    
    
    /**
     * Returns a string representation of the receiver.
     *
     * @return a string representation
     */
    
    public String toString() {
        return isTrue+"";
    }
        
}
