package evs.metric.metrics;

import evs.metric.parameters.BooleanParameter;
import evs.metric.parameters.ForecastTypeParameter;
import evs.metric.results.DoubleResult;
import evs.metric.results.MetricResult;
import java.util.TreeMap;
import java.util.Iterator;

/**
 * An abstract base class for metrics that represents an integrated score.  Integrated
 * scores are derived from a set of raw verification data and include, the Brier score,
 * the Ranked Probability Score and the Continuous Ranked Probability Score.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public abstract class ScoreMetric extends Metric {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLES                              *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Store of results for the decomposed statistic values.  The results are contained
     * in map of maps, registered first against the forecast type and then against
     * the decomposed type (see this class for the decomposed types and the 
     * MetricResult class for the other forecast types).  The integrated result 
     * remains in the Metric class.
     */
    
    private TreeMap<Integer,TreeMap> decomposed = new TreeMap();    

    /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/      

    /**
     * Return a result for the specified forecast type and type of decomposed
     * result or null.  Throws an exception if the forecast type or decomposed
     * type are unrecognized.  See this class for the types of decomposition
     * allowed.
     *
     * @param forecastType the type of result required (see the ForecastTypeParameter class)
     * @param decomposedType the decomposition indicator
     * @return the metric result or null
     */
    
    public DoubleResult getResult(int forecastType, int decomposedType) throws IllegalArgumentException {
        ForecastTypeParameter.isSupportedForecastType(forecastType, true);
        DoubleResult result = null;
        TreeMap map = decomposed.get(forecastType);
        if(map != null && map.containsKey(decomposedType)) {
            result = (DoubleResult)map.get(decomposedType);
        }
        return result;
    }
    
    /**
     * Returns true if the metric has a decomposed result for the specified 
     * forecast type and type of decomposition.  See this class for the types of 
     * decomposition allowed.
     *
     * @param forecastType the forecast type
     * @param decomposedType the component of the decomposition
     * @return true if the result exists, false otherwise
     */
    
    public boolean hasResult(int forecastType, int decomposedType) {
        ForecastTypeParameter.isSupportedForecastType(forecastType, true);
        boolean returnMe  = false;
        TreeMap map = decomposed.get(forecastType);
        if(map != null && map.containsKey(decomposedType)) {
            returnMe = true;
        }
        return returnMe;
    }   
    
    /**
     * Returns true if the score will be decomposed for each forecast type,
     * false otherwise.
     *
     * @return true if the score will be decomposed
     */
    
    public boolean getDecompose() {
        return ((BooleanParameter)pars[1]).getParVal();
    }

    /**
     * Returns true if a score decomposition is supported, false otherwise.
     *
     * @return true if decomposition is supported
     */

    public boolean canDecompose() {
        return this instanceof DecomposableScore;
    }

    /********************************************************************************
     *                                                                              *
     *                               MUTATOR METHODS                                *
     *                                                                              *
     *******************************************************************************/     

    /**
     * Overrides superclass method to deep copy the decomposed results also.
     *
     * @param metric the input metric that will receive the deep copied results
     */
    
    protected void deepCopyResults(Metric metric) {
        super.deepCopyResults(metric);
        if(metric instanceof ScoreMetric) {
            TreeMap<Integer,TreeMap> copy = new TreeMap();
            Iterator i = decomposed.keySet().iterator();
            while(i.hasNext()) {
                Integer next = Integer.valueOf((Integer)i.next());
                TreeMap oldMap = decomposed.get(next);
                if(oldMap != null) {
                    TreeMap newMap = new TreeMap();
                    Iterator j = oldMap.keySet().iterator();
                    while(j.hasNext()) {
                        Integer next2 = (Integer)j.next();
                        MetricResult result = (MetricResult)oldMap.get(next2);
                        newMap.put(Integer.valueOf(next2),result.deepCopy());
                    }
                    copy.put(next,newMap);
                }
            }
            ((ScoreMetric)metric).decomposed=copy;
        }
    }

    
}
