package evs.metric.metrics;

//Java dependencies
import java.util.*;

/**
 * Utilities class for computing ROC statistics.
 *  
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public final class ROCUtilities {

    /**
     * Returns the POFD and POD from the input, with the POD in the second row.
     *
     * @param probWhenObsYes the forecast probabilities when the event occurs, sorted
     * @param probWhenObsNo the forecast probabilities when the event does not occur, sorted
     * @param count the number of points aside from the origin (i.e. 1 will be added)
     * @return the POFD and POD
     */

    protected static double[][] getEmpiricalROC(Vector<Double> probWhenObsYes,
            Vector<Double> probWhenObsNo, int count) {
        //Number of points to include for the binormal approximation: N + 1 where N = member count
        //Convention is to use as many points as members, but some control is allowed here
        //for consistency with the ROC curve
        //int count =  forecasts[0].length;
        count = count + 1; //Number of points aside from the origin
        double[][] dat = new double[2][count];
        double[] pThresh2 = new double[count];
        for (int i = 0; i < count; i++) {
            pThresh2[i] = 1.0 - (i * (1.0 / (count - 1.0)));  //Prob thresholds in descending size
        }
        int s1 = probWhenObsYes.size();
        int s2 = probWhenObsNo.size();
        //Determine the POD and POFD
        dat[0][dat[0].length - 1] = 1.0;
        dat[1][dat[1].length - 1] = 1.0;
        int stop = count - 1;
        for (int i = 0; i < stop; i++) {
            //Determine the POFD and place in the first row
            for (int j = 0; j < s2; j++) {
                if (probWhenObsNo.get(j) >= pThresh2[i]) {  //Forecast prob is >= ROC thresh
                    dat[0][i] += 1.0;
                } else {
                    break;  //Sorted data, so no more elements
                }
            }
            dat[0][i] = dat[0][i] / s2;
            //Determine POD and place in the second row
            for (int j = 0; j < s1; j++) {
                if (probWhenObsYes.get(j) >= pThresh2[i]) {  //Forecast prob is >= ROC thresh
                    dat[1][i] += 1.0;
                } else {
                    break;  //Sorted data, so no more elements
                }
            }
            dat[1][i] = dat[1][i] / s1;
        }
        return dat;
    }

}
