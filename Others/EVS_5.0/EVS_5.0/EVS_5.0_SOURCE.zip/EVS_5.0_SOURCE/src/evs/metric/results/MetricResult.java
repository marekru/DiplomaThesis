package evs.metric.results;

//EVS dependencies
import evs.utilities.mathutil.*;
import evs.utilities.matrix.*;
import evs.metric.parameters.*;

//Java dependencies
import java.util.*;

/**
 * The result of a metric calculation.  Depending on the type of result returned
 * by a metric, appropriate subclasses should be defined.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public abstract class MetricResult {
    
    /********************************************************************************
     *                                                                              *
     *                                CLASS VARIABLES                               *
     *                                                                              *
     *******************************************************************************/    
    
    /**
     * Identifier for an evs.metric.results.DoubleMatrix1DResult.
     */
    
    public static final int DOUBLE_MATRIX_1D_RESULT = 801;

    /**
     * Identifier for an evs.metric.results.DoubleMatrix2DResult.
     */
    
    public static final int DOUBLE_MATRIX_2D_RESULT = 802;
    
    /**
     * Identifier for an evs.metric.results.MetricResultByLeadPeriod.
     */
    
    public static final int METRIC_RESULT_BY_LEAD_PERIOD = 803;    
    
    /**
     * Identifier for an evs.metric.results.DoubleResult.
     */
    
    public static final int DOUBLE_RESULT = 804;        
    
    /**
     * Identifier for evs.metric.results.MetricResultByThreshold.
     */
    
    public static final int METRIC_RESULT_BY_THRESHOLD = 805;      
    
    /**
     * Identifier for evs.metric.results.MetricResultStore.
     */
    
    public static final int METRIC_RESULT_STORE = 806;        
    
    /**
     * Identifier for an evs.metric.results.IntegerResult.
     */
    
    public static final int INTEGER_RESULT = 807;       
    
    /**
     * Identifier for an evs.metric.results.IntegerMatrix1DResult.
     */
    
    public static final int INTEGER_MATRIX_1D_RESULT = 808;    
    
    /**
     * Identifier for an evs.metric.results.EnsembleScoreDecomposition.
     */
    
    public static final int ENSEMBLE_SCORE_DECOMPOSITION_RESULT = 809;

    /**
     * Identifier for an evs.metric.results.MetricResultBySamplingInterval.
     */

    public static final int METRIC_RESULT_BY_SAMPLING_INTERVAL= 810;


    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLES                              *
     *                                                                              *
     *******************************************************************************/

    /**
     * Sampling uncertainty interval associated with the metric result, indexed by interval.
     */

    protected TreeMap<ProbabilityIntervalParameter,MetricResult[]> intervals =
            new TreeMap<ProbabilityIntervalParameter,MetricResult[]>();

    /**
     * A main sampling uncertainty interval associated with the result.
     */

    protected ProbabilityIntervalParameter main = null;

    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/     

    /**
     * Returns a deep copy of the current metric result, where all instance variables 
     * occupy independent positions in memory from the current metric result.  
     *
     * @return a deep copy of the current object 
     */
     
    public abstract MetricResult deepCopy();
    
    /**
     * Returns the type of result.  See this class for supported types.
     *
     * @return the type of result
     */
    
    public abstract int getID();
    
    /**
     * Applies an aggregation function to the corresponding values (e.g. same 
     * matrix position) in the input results, placing a Metric.NULL_DATA if all 
     * of those values are Metric.NULL_DATA.  Throws an exception if the inputs
     * are not of the same class.  The return type may not correspond to the input
     * type if the result of the aggregation function cannot be stored in the input
     * type.  Specifically, any aggregation of a result that contains integers 
     * should ALWAYS return a result that contains doubles, as the aggregation 
     * function is guaranteed to do so.  For example, the average of a set of 
     * integers may not be an integer.  Specify a set of weights for each metric
     * that are constant across all forecast lead times.  The weights must sum to 1.
     *
     * No sampling intervals should be aggregated. Sampling uncertainty should be
     * assessed on the aggregate quantities, rather than the sampling intervals
     * aggregated.
     * 
     * @param input the input results
     * @param func the aggregation function
     * @param weights the constant weights to apply across all lead times
     * @return the aggregated result   
     */
    
    public abstract MetricResult aggregate(MetricResult[] input, VectorFunction func, double[] weights) throws MetricResultException;

    /**
     * Returns a string representation of the result for writing to an XML file
     * with a specified writing precision.  The results may be spread across several
     * strings to be written as individual nodes.
     *
     * @param precision the writing precision
     * @return a string representation for writing to XML
     */

    public abstract String[] toXMLString(int precision);


    /**
     * Returns a set of sampling intervals for the input results. Throws an
     * exception if the intervals are null or the input results are null, contain
     * no elements or contain null elements, or if any of the input results are
     * not of the same class as the implementing class.  Also throws an
     * exception if intervals are repeated.  These checks are implemented
     * in the {@link #checkIntervalsInput(int, evs.metric.parameters.ProbabilityIntervalParameter[], 
     * evs.metric.results.MetricResult[], int)}.
     * The intervals are computed from the pointwise statistics at the lowest level
     * result type (e.g. the double element of a result of type {@link evs.metric.results.DoubleResult})
     * and the lower and upper bounds are returned in the same result type as the input,
     * indexed by interval in the returned map.  The statistics are computed from the empirical
     * probability distributions of the pointwise results, without any plotting position
     * formula.  In other words, given a set of 100 order statistics, the {0.05, 0.95}
     * interval will correspond to the 5th and 95th order statistics, respectively.
     *
     * An exception is thrown if any one of the intervals cannot be computed.
     *
     * Returns the null value identifier for each pointwise statistic in which
     * all of the input results are null or below the non-null results are below
     * the minimum sample size (which must be greater than 0 and less than the
     * size of the input results array).
     *
     * @param intervals an array of sampling intervals to compute from the results
     * @param results an array of results from which to compute sampling intervals
     * @param nV a null value identifier to ignore when computing the intervals
     * @param minSampleSize the minimum sample size from which to return non-null interval identifiers
     * @return the sampling intervals
     */

    public abstract TreeMap<ProbabilityIntervalParameter,MetricResult[]> getIntervalsFromResults(
            ProbabilityIntervalParameter[] intervals, MetricResult[] results, double nV,
            int minSampleSize) throws SamplingIntervalException;

    /**
     * Returns true if one or more sampling uncertainty intervals are associated
     * with the metric result, false otherwise.
     *
     * @return true if one or more sampling uncertainty intervals are available
     */

    public boolean hasSamplingIntervals() {
        return intervals.size()>0;
    }

    /**
     * Returns true if a "main" sampling uncertainty interval has been defined,
     * false otherwise.
     *
     * @return true if a main interval has been defined, false otherwise
     */

    public boolean hasMainInterval() {
        return main !=null;
    }

    /**
     * Returns true if one or more ancillary intervals are available. An ancillary interval
     * is anything except a main interval.
     *
     * @return true if an ancillary interval has been defined, false otherwise
     */

    public boolean hasAncillaryIntervals() {
        if(main==null && intervals.size()>0 || main != null && intervals.size()>1) {
            return true;
        }
        return false;
    }

    /**
     * Returns the main sampling interval associated with the metric result or
     * null if no interval has been defined.
     *
     * @return the main interval or null
     */

    public ProbabilityIntervalParameter getMainInterval() {
        if(main==null) {
            return null;
        }
        return (ProbabilityIntervalParameter)main.deepCopy();
    }

    /**
     * Returns the sampling intervals and associated lower and upper bounds in
     * a map, or null if no sampling intervals are available.
     *
     * @return an array of sampling intervals and associated bounds
     */

    public TreeMap<ProbabilityIntervalParameter,MetricResult[]> getIntervalResults() {
        if(intervals.size()==0) {
            return null;
        }
        return deepCopyIntervals();
    }

    /**
     * Returns the main sampling interval results associated with the metric result 
     * or null if no interval has been defined. The lower bound is contained in the
     * first index of the array, and the upper bound in the second index.
     *
     * @return the main interval or null
     */

    public MetricResult[] getMainIntervalResults() {
        if(main==null || !intervals.containsKey(main)) {
            return null;
        }
        MetricResult[] returnMe = new MetricResult[3];
        MetricResult[] stored = intervals.get(main);
        returnMe[0]=stored[0].deepCopy();
        returnMe[1]=stored[1].deepCopy();
        returnMe[2]=stored[2].deepCopy();
        return returnMe;
    }

    /**
     * Returns the sampling intervals and associated lower and upper bounds in
     * a map, or null if no sampling intervals are available.  Removes any "main"
     * interval from the map.
     *
     * @return an array of sampling intervals and associated bounds, minus anu main interval
     */

    public TreeMap<ProbabilityIntervalParameter,MetricResult[]> getAncillaryIntervalResults() {
        if(intervals.size()==0) {
            return null;
        }
        TreeMap<ProbabilityIntervalParameter,MetricResult[]> t = deepCopyIntervals();
        if(hasMainInterval()) {
            t.remove(main);
        }
        return t;
    }

    /********************************************************************************
     *                                                                              *
     *                                MUTATOR METHODS                               *
     *                                                                              *
     *******************************************************************************/

    /**
     * Associates a sampling uncertainty interval with the metric result. The input
     * type must be the same for the lower and upper bound and must be consistent
     * with the main result type determined on construction.  If either of these
     * conditions are not met, or if the same interval exists in the local store,
     * an exception is thrown.  An interval may be identified as a "main" interval.
     * No sensibility checks are performed on the content of the lower or
     * upper bound (e.g. that the intervals are, in some sense, valid, such as
     * the upper bound being higher than the lower bound); this should be ensured
     * beforehand.
     *
     * @param interval the interval
     * @param lower the lower bound
     * @param upper the upper bound
     * @param sampleSize the sample size data
     * @param main is true to identify the current interval as the main interval,
     * replacing any existing main interval
     */

    public void addSamplingInterval(ProbabilityIntervalParameter interval,
            MetricResult lower, MetricResult upper, MetricResult sampleSize, boolean main) throws SamplingIntervalException {
        if(interval==null) {
            throw new SamplingIntervalException("Specify a non-null interval for the sampling uncertainty of the result.");
        }
        if(lower==null || upper==null) {
            throw new SamplingIntervalException("Specify non-null bounds for the sampling uncertainty of the result.");
        }
        if(sampleSize==null) {
            throw new SamplingIntervalException("Specify non-null sample size information for the sampling uncertainty of the result.");
        }
        if(intervals.containsKey(interval)) {
            throw new SamplingIntervalException("The sampling uncertainty interval '"+interval+"' has already"
                    + " been associated with the result: cannot overwrite.");
        }
        if(lower.getID()!=upper.getID()) {
            throw new SamplingIntervalException("The lower and upper bounds of the sampling interval have different data types: "
                    + "["+lower.getID()+","+upper.getID()+"].");
        }
        if(lower.getID()!=getID()) {
            throw new SamplingIntervalException("The bounds of the sampling interval have a different data type than the result data type: "
                    + "["+lower.getID()+","+getID()+"].");
        }
        if(sampleSize.getID()!=getID()) {
            throw new SamplingIntervalException("The sample size of the sampling interval has a different data type than the result data type: "
                    + "["+sampleSize.getID()+","+getID()+"].");
        }
        intervals.put(interval,new MetricResult[]{lower,upper,sampleSize});
        if(main) {
            this.main = interval;
        }
    }

    /**
     * Adds a set of sampling intervals in the input map to the result.  In addition,
     * a main interval may be defined.  Throws an exception if the main interval is
     * not contained in the input map or under any of the conditions in which {@link
     * #addSamplingInterval(evs.metric.parameters.ProbabilityIntervalParameter, evs.metric.results.MetricResult, evs.metric.results.MetricResult, evs.metric.results.MetricResult, boolean)} 
     * throws an exception.
     *
     * @param intervals the interval results indexed by interval in a map
     * @param main a main interval (may be null)
     */

    public void addSamplingIntervals(TreeMap<ProbabilityIntervalParameter,
            MetricResult[]> intervals, ProbabilityIntervalParameter main)  throws SamplingIntervalException {
        if(intervals==null || intervals.size()==0) {
            throw new SamplingIntervalException("No valid input samping intervals to add.");
        }
        if(main !=null && !intervals.containsKey(main)) {
            throw new SamplingIntervalException("Could not add sampling intervals to the metric result: "
                    + "the main interval '"+main+"' is not contained in the input map of interval results.");
        }
        Iterator it = intervals.keySet().iterator();
        while(it.hasNext()) {
            ProbabilityIntervalParameter next = (ProbabilityIntervalParameter)it.next();
            MetricResult[] results = intervals.get(next);
            if(results[0]==null || results[1]==null) {
                throw new SamplingIntervalException("One or both of the bounds of interval '"+next+"' comprised null results.");
            }
            if(results[2]==null) {
                throw new SamplingIntervalException("The sample size of interval '"+next+"' comprised null results.");
            }
            addSamplingInterval(next,results[0],results[1],results[2],next.equals(main));
        }
    }

    /********************************************************************************
     *                                                                              *
     *                              PROTECTED METHODS                               *
     *                                                                              *
     *******************************************************************************/     

    /**
     * Convenience method that returns a deep copy of the sampling uncertainty
     * intervals associated with the result.
     *
     * @return a deep copy of the sampling uncertainty intervals
     */

    protected TreeMap<ProbabilityIntervalParameter,MetricResult[]> deepCopyIntervals() {
        TreeMap<ProbabilityIntervalParameter,MetricResult[]> map = new
                TreeMap<ProbabilityIntervalParameter,MetricResult[]>();
        Iterator it = intervals.keySet().iterator();
        while(it.hasNext()) {
            ProbabilityIntervalParameter p = (ProbabilityIntervalParameter)it.next();
            MetricResult[] r = intervals.get(p);
            MetricResult[] copy = new MetricResult[]{r[0].deepCopy(),r[1].deepCopy(),r[2].deepCopy()};
            map.put((ProbabilityIntervalParameter)p.deepCopy(),copy);
        }
        return map;
    }

    /**
     * Checks whether the specified inputs are all non-null and of the same class 
     * and throws an exception one or both conditions are not met.  If the input
     * contains a matrix, the matrix dimensions are also checked for equivalence
     * and an exception thrown if they are not equivalent.
     * 
     * Does not check whether the inputs are appropriate for a given implementation
     * of {@link #aggregate(evs.metric.results.MetricResult[], evs.utilities.mathutil.VectorFunction, double[]) }
     * in a subclass.
     * 
     * @param input the input results to check
     * @param weights the weights to check
     */
    
    protected void checkAggInputs(MetricResult[] input, double[] weights) throws MetricResultException {
        MetricResultException n = new MetricResultException("Cannot aggregate the metric results for at least one metric, as one or more of the results are missing.");
        MetricResultException m = new MetricResultException("Cannot aggregate the metric results for at least one metric, as the results have different data dimensions.");
        if(input[0]==null) {
            throw n;
        }
        for(int i = 1; i < input.length; i++) {
            if(input[i]==null) {
                throw n;
            }
            if(!input[i].getClass().equals(input[0].getClass())) {
                throw new MetricResultException("Cannot aggregate the input results as they contain different data types.  Found: "+input[i].getClass()+". Expected: "+input[0].getClass());
            }
            //Check matrix dimensions if required
            switch (input[0].getID()) {
                case DOUBLE_MATRIX_1D_RESULT: {
                    if(((DoubleMatrix1DResult)input[i]).getResult().getRowCount()
                            !=((DoubleMatrix1DResult)input[0]).getResult().getRowCount()) {
                        throw m;
                    }
                }; break;
                case INTEGER_MATRIX_1D_RESULT: {
                    if(((IntegerMatrix1DResult)input[i]).getResult().getRowCount()
                            !=((IntegerMatrix1DResult)input[0]).getResult().getRowCount()) {
                        throw m;
                    }
                }; break;
                case DOUBLE_MATRIX_2D_RESULT: {
                    if(((DoubleMatrix2DResult)input[i]).getResult().getRowCount()
                            !=((DoubleMatrix2DResult)input[0]).getResult().getRowCount()) {
                        throw m;
                    }
                    if(((DoubleMatrix2DResult)input[i]).getResult().getColumnCount()
                            !=((DoubleMatrix2DResult)input[0]).getResult().getColumnCount()) {
                        throw m;
                    }
                }; break;
            }
        }
        
        //Check the weights
        if(weights == null) {
            throw new IllegalArgumentException("The aggregation weights must be non-null.");
        }
        if(input.length != weights.length) {
            throw new IllegalArgumentException("The number of weights must match the number of verification metrics.");
        }
        double sum = FunctionLibrary.total().apply(new DenseDoubleMatrix1D(weights));
        if(sum<0.9999 || sum > 1.0001) {
            throw new IllegalArgumentException("Weights must sum to 1.0: "+sum);
        }
    }

    /**
     * Checks the input for calculation of sampling intervals from an array of
     * results as prescribed by {@link #getIntervalsFromResults(evs.metric.parameters.ProbabilityIntervalParameter[], evs.metric.results.MetricResult[], double, int)}.
     *
     * Throws an exception if the intervals are null or the input results are null,
     * contain no elements or contain null elements, or if any of the input results are
     * not of the same class as the implementing class specified by the input result
     * type, which is one of the class variables in this class.  Also throws an
     * exception if intervals are repeated or if the minimum sample size is zero or
     * greater than the size of the input result array.
     *
     * @param resultType the result type expected
     * @param intervals the array of intervals to compute
     * @param results from which the intervals will be computed
     * @param minSampleSize the minimum sample size
     */
    
    protected void checkIntervalsInput(int resultType, ProbabilityIntervalParameter[] intervals,
        MetricResult[] results, int minSampleSize) throws SamplingIntervalException {
        if(intervals==null) {
            throw new SamplingIntervalException("Cannot compute the sampling intervals: the intervals were null.");
        }
        if(results==null || results.length == 0) {
            throw new SamplingIntervalException("Cannot compute the sampling intervals: no interval results provided.");
        }
        if(minSampleSize==0) {
            throw new SamplingIntervalException("Cannot compute the sampling intervals: the minimum sample size cannot be zero.");
        }
        if(minSampleSize>results.length) {
            throw new SamplingIntervalException("Cannot compute the sampling intervals: fewer results available than the minimum "
                    + "sample size requested ["+results.length+","+minSampleSize+"].");
        }
        ArrayList<ProbabilityIntervalParameter> list = new ArrayList<ProbabilityIntervalParameter>();
        for(ProbabilityIntervalParameter p : intervals) {
            if(p==null) {
                throw new SamplingIntervalException("Cannot compute the sampling intervals: one or more intervals were null.");
            }
            if(list.contains(p)) {
                throw new SamplingIntervalException("Cannot compute the sampling intervals: one or more intervals were duplicated: "+p+".");
            }
            list.add(p);
        }
        for(MetricResult r : results) {
            if(r==null) {
                throw new SamplingIntervalException("Cannot compute the sampling intervals: one or more interval results were null.");
            }
            if(r.getID()!=resultType) {
                throw new SamplingIntervalException("Cannot compute the sampling intervals: one or more results were of unexpected type.");
            }
        }
    }

}
