package evs.metric.parameters;

/**
 * Stores the identifier of a reference forecast used in a skill calculation.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ReferenceForecastParameter implements MetricParameter {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLE                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * The parameter value.
     */
    
    private String ref = null;

    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricParameter deepCopy() {
        ReferenceForecastParameter p = new ReferenceForecastParameter();
        p.ref = ref;
        return p;
    }     
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
        
    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     * Remember to override in any subclass.
     *
     * @return an identifier
     */
    
    public int getID() {
        return REFERENCE_FORECAST_PARAMETER;
    }     
    
    /**
     * Returns true if a reference forecast is available.
     * 
     * @return true if a reference forecast has been set, false otherwise
     */
    
    public boolean hasRefForecast() {
        return ref!=null;
    }

    /**
     * Returns true if the input string equals the reference forecast identifier,
     * false otherwise, including if either the input or the existing reference
     * are null.
     *
     * @param ref the reference forecast identifier
     * @return true if the input equals the existing (non-null) reference
     */

    public boolean hasRefForecast(String ref) {
        return this.ref!=null && this.ref.equals(ref);
    }
    
    /**
     * Returns true if the reference forecast has been set and matches the sample climatology
     * string in {@link ForecastTypeParameter#SAMPLE_CLIMATOLOGY_STRING}, false otherwise.
     * 
     * @return true if the only reference forecast is sample climatology, false otherwise
     */
    
    public boolean isSampleClimatology() {
        return hasRefForecast() && ref.
                equalsIgnoreCase(ForecastTypeParameter.SAMPLE_CLIMATOLOGY_STRING);
    }
        
    /**
     * Returns a copy of the reference forecast (may be null).
     * 
     * @return the available reference forecast
     */
    
    public String getParVal() {
        return ref;
    }
    
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "reference_forecast_parameter";
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ReferenceForecastParameter other = (ReferenceForecastParameter) obj;
        if ((this.ref == null) ? (other.ref != null) : !this.ref.equals(other.ref)) {
            return false;
        }
        return true;
    }

    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        assert false : "hashCode not implemented for MetricParameter.";
        return 1;
    }    
    
    /**
     * Returns a string representation of the parameter comprising the reference
     * forecast.
     *
     * @return a string representation
     */
    
    public String toString() {
        return ref;
    }    
    
    /********************************************************************************
     *                                                                              *
     *                               MUTATOR METHODS                                *
     *                                                                              *
     *******************************************************************************/    
    
    /**
     * Clears the reference forecast.
     */
    
    public void removeRefForecast() {
        ref = null;
    }
    
    /**
     * Adds a reference forecast to the list.
     * 
     * @param forecast the forecast id
     */
    
    public void setRefForecast(String forecast) throws IllegalArgumentException {
        if(forecast == null || forecast.equals("")) {
            throw new IllegalArgumentException("Reference forecast identifier '"+forecast+"' is not a valid reference forecast identifier.");
        }
        ref = forecast;
    }
    
}
