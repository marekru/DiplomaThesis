package evs.metric.parameters;

//Java util dependencies
import java.util.*;

/**
 * A probability interval with lower and upper bounds such that upper > lower
 * and both lower and upper fall in [0,1].
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ProbabilityIntervalParameter implements MetricParameter, Comparable {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLE                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * The lower bound of the probability interval.
     */
    
    protected double lower;

    /**
     * The upper bound of the probability interval.
     */

    protected double upper;
    
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Constructs a probability interval in [0,1].
     *
     * @param lower the lower bound
     * @param upper the upper bound
     */
    
    public ProbabilityIntervalParameter(double lower, double upper) {
        if(lower >= 0 && lower < upper && upper <=1) {
            this.lower = lower;
            this.upper = upper;
        } else {
            throw new IllegalArgumentException("Expected bounds in [0,1]: ["+lower+","+upper+"].");
        }
    }

    /**
     * Convenience constructor that attempts to construct a parameter from a string
     * in the same format as the toString method implemented for objects of this class.
     *
     * @param input the input string
     */

    public ProbabilityIntervalParameter(String input) {
        Double lower = null;
        Double upper = null;
        try {
            StringTokenizer t = new StringTokenizer(input,", \t\n\r\f",false);
            lower = new Double(t.nextToken());
            upper = new Double(t.nextToken());
        } catch(Exception e) {
            throw new IllegalArgumentException("Could not construct probability interval: unrecognized format " +
                "for input string: expected separated lower and upper limits of interval.");
        }
        if (lower >= 0 && lower < upper && upper <= 1) {
            this.lower = lower;
            this.upper = upper;
        } else {
            throw new IllegalArgumentException("Expected bounds in [0,1]: [" + lower + "," + upper + "].");
        }
    }

    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Return an identifier for the parameter from the list in evs.metric.MetricParameter.
     *
     * @return an identifier
     */
    
    public int getID() {
        return PROBABILITY_INTERVAL_PARAMETER;
    }    
    
    /**
     * Returns the parameter name.
     *
     * @return the parameter name
     */
    
    public String getName() {
        return "probability_interval_parameter";
    }

    /**
     * Returns a deep copy of the current metric parameter, where all instance variables 
     * occupy independent positions in memory from the current metric parameter.  
     *
     * @return a deep copy of the current object 
     */
     
    public MetricParameter deepCopy() {
        return new ProbabilityIntervalParameter(lower,upper);
    }

    /**
     * Returns the lower and upper bounds as a double array.
     *
     * @return the parameter value
     */

    public double[] getParVal() {
        return new double[]{lower,upper};
    }

    /**
     * Returns the lower bound of the interval.
     *
     * @return the lower bound
     */

    public double getLower() {
        return lower;
    }

     /**
     * Returns the upper bound of the interval.
     *
     * @return the upper bound
     */

    public double getUpper() {
        return upper;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ProbabilityIntervalParameter other = (ProbabilityIntervalParameter) obj;
        if (this.lower != other.lower) {
            return false;
        }
        if (this.upper != other.upper) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 73 * hash + (int) (Double.doubleToLongBits(this.lower) ^
                (Double.doubleToLongBits(this.lower) >>> 32));
        hash = 73 * hash + (int) (Double.doubleToLongBits(this.upper) ^
                (Double.doubleToLongBits(this.upper) >>> 32));
        return hash;
    }
 
    /**
     * Overrides superclass method.
     * 
     * @return a negative integer if the current value is less, 0 if equal, positive if greater
     */
    
    public int compareTo(Object o) {
        ProbabilityIntervalParameter in = (ProbabilityIntervalParameter)o;
        //Equal
        if(this.equals(o)) {
            return 0;
        }
        //This lower bound is lower than input
        if(lower<in.lower) {
            return -1;
        } 
        //This lower bound is higher than input
        else if(lower>in.lower) {
            return 1;
        } 
        //Lower bounds are equal
        else {
            if(upper<in.upper) {
                return -1;
            } 
            return 1;
        }
    }    
    
    /**
     * Returns a string representation of the thresholds separated by commas.
     *
     * @return a string representation
     */
    
    public String toString() {
        return lower+", "+upper;
    }
       
    
}
