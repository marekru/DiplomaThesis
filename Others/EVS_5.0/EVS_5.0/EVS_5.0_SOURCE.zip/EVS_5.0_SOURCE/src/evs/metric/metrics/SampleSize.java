package evs.metric.metrics;

//EVS dependencies
import evs.data.*;
import evs.metric.*;
import evs.metric.parameters.*;
import evs.metric.results.*;
import evs.utilities.*;
import evs.utilities.mathutil.*;
import evs.utilities.matrix.*;

//Java util dependencies
import java.util.*;

/**
 * Convenience metric that computes the sample sizes available for each forecast
 * lead time, and by threshold, if available.  Note that the sample sizes are also
 * available for specific metrics.  However, this metric may be used to collect
 * the (matching) high-level sample size information from several metrics in one 
 * place.  Other metrics may have low-level sample-size information, such as the 
 * reliability diagram which has a sharpness plot.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class SampleSize extends Metric implements SingleValuedMetric, ThresholdMetric {
 
    /********************************************************************************
     *                                                                              *
     *                             INSTANCE VARIABLES                               *
     *                                                                              *
     *******************************************************************************/     

    /**
     * The function to apply to forecasts with multiple values.
     */
    
    private VectorFunction forecastStat = FunctionLibrary.mean();

    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Attempts to construct a sample size metric with the forecast types for 
     * which the metric is required.
     *
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use 
     * conditional pairs when available
     */
    
    public SampleSize(ForecastTypeParameter fType,UnconditionalParameter unconditional) {
        //Set the name
        name = "Sample size";
        //Set the parameters
        //Specify an all-inclusive threshold condition
        ProbabilityIdentifierParameter p = new ProbabilityIdentifierParameter(false);
        DoubleParameter[] dubs = new DoubleParameter[]{new DoubleParameter(Double.NEGATIVE_INFINITY)};
        IntegerParameter p2 = new IntegerParameter(DoubleProcedureParameter.GREATER_THAN);
        setParameters(new MetricParameter[]{new DoubleProcedureParameter(p2,dubs,p,
                new BooleanParameter(true)),fType.deepCopy(),unconditional.deepCopy()});
        //Set the link to html description of the metric
        descriptionURL = getClass().getResource(EVSConstants.STATS_EXPLAINED_DIR + "ss.htm");
    }
    
    /**
     * Attempts to construct a sample size metric with the forecast types for 
     * which the metric is required and a threshold condition on which to select
     * a subset of pairs.
     *
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use 
     * conditional pairs when available
     * @param threshold the threshold
     */
    
    public SampleSize(DoubleProcedureParameter threshold,ForecastTypeParameter fType,UnconditionalParameter unconditional) {
        this(fType,unconditional);
        pars[0]=threshold.deepCopy();
    }
        
    /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/        

    /**
     * Returns the forecast statistic to be applied to paired input that comprise
     * multiple forecasts at a single time (e.g. ensemble forecast input).    
     *
     * @return the forecast statistic
     */
    
    public VectorFunction getForecastStatistic() {
        return forecastStat;
    }

    /**
     * Returns true if a forecast statistic has been set, false otherwise.
     * 
     * @return true if a forecast statistic has been set.
     */
    
    public boolean hasForecastStatistic() {
        return forecastStat != null;
    }    
    
    /**
     * Returns the metric identifier.
     *
     * @return an identifier
     */
    
    public int getID() {
        return SAMPLE_SIZE;
    }        
    
    /**
     * Returns the result type associated with the metric.  See the 
     * evs.metric.MetricResult class for supported types.
     *
     * @return an identifier
     */
    
    public int getResultID() {
        return MetricResult.DOUBLE_RESULT;
    }         
    
    /**
     * Returns true if the metric is defined in real units of the forecast
     * and observed variable, false otherwise.
     * 
     * @return true if the metric is defined in real units
     */    

    public boolean hasRealUnits() {
        return true;
    }       
    
    /**
     * Returns the threshold associated with this threshold diagram.
     *
     * @return the threshold
     */
    
    public DoubleProcedureParameter getThreshold() {
        return (DoubleProcedureParameter)pars[0].deepCopy();
    }

    /**
     * Returns a deep copy of the current metric, where all instance variables 
     * occupy independent positions in memory from the current metric.  
     *
     * @return a deep copy of the current object 
     */
    
    public Metric deepCopy() {
        SampleSize returnMe = new SampleSize((DoubleProcedureParameter)pars[0].deepCopy(),(ForecastTypeParameter)pars[1].deepCopy(),(UnconditionalParameter)pars[2].deepCopy());
        deepCopyResults(returnMe);
        return returnMe;
    } 
    
    /**
     * Returns a metric with default parameter values.  
     *
     * @return a metric with default parameter values.
     */
    
    public static Metric getDefaultMetric() { 
        ForecastTypeParameter type = new ForecastTypeParameter(new int[]{ForecastTypeParameter.REGULAR_FORECAST});
        return new SampleSize(type,new UnconditionalParameter(false)); 
    }     
    
    /********************************************************************************
     *                                                                              *
     *                                MUTATOR METHODS                               *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Sets the forecast statistic to be applied to paired input that comprise
     * multiple forecasts at a single time (e.g. ensemble forecast input).      
     *
     * @param forecastStat the forecast statistic
     */
    
    public void setForecastStatistic(VectorFunction forecastStat) {
        if(forecastStat == null) {
            throw new IllegalArgumentException("Cannot use a null forecast statistic.");
        }
        this.forecastStat = forecastStat;
    }     
    
    /**
     * Sets the threshold for the current metric.    
     *
     * @param threshold the threshold
     */
    
    public void setThreshold(DoubleProcedureParameter threshold) {
        pars[0] = (DoubleProcedureParameter)threshold.deepCopy();
    }    
    
    /**
     * Uses the specified paired data to compute and return the result of the metric.
     * The metric results are returned, together with the sample counts, but not stored 
     * locally.  The metric result is located in the first index of the return array
     * and the sample counts are located in the second index. Optionally, specify
     * the results of a reference forecast from which to compute skill if the 
     * metric is a skill score. 
     * 
     * @param forecastType the forecast type
     * @param paired the paired data
     * @param refResult the results for a reference forecast (may be null)
     * @return the metric result and sample counts
     */
    
    public MetricResult[] compute(int forecastType, PairedData paired, MetricResult refResult) throws MetricCalculationException {
        if(paired==null) {
            throw new MetricCalculationException("Error computing metric '"+getName()+"': input pairs were null.");
        }
        ForecastTypeParameter.isSupportedForecastType(forecastType,true);
        MetricResult[] res = new MetricResult[2];
        DoubleProcedure pro = getThreshold().getParValReal();
        DoubleMatrix2D p = paired.getPairs();
        double nV = paired.getNullValue();
//        try {
            p = getConditionalPairs(pro,p);
            res[0]=getCounts((DoubleMatrix2D)p.getSubmatrixByColumn(2,p.getColumnCount()-1),nV);
            res[1]=new IntegerResult(lastCount);
//        } catch (Exception e) {
//            //e.printStackTrace();
//        }
        return res; 
    }     
   
    /**
     * Returns the counts from the input data.  The input should comprise one 
     * column of observations (at index 0) and the remaining columns as forecast
     * members.
     * 
     * @param data the input data
     * @param nV the null value
     * @return the sample count
     */
    
    public MetricResult getCounts(DoubleMatrix2D data, double nV) {    
        int rows = data.getRowCount();
        int cols = data.getColumnCount();
        double actualRows = 0.0;
        for(int i = 0; i < rows; i++) {
            double o = data.get(i,0);
            if(o == nV) {
                break;
            }
            int nullCount = 0;
            for(int j = 1; j < cols; j++) {    
                if(data.get(i,j)==nV) {
                    nullCount++;
                }
            }
            if(nullCount!=(cols-1)) {
                actualRows++;
            }
        }
        lastCount = (int)actualRows;
        //Compute 
        return new DoubleResult(lastCount);   
    }
    
}
    