package evs.metric.metrics;

//EVS dependencies
import evs.metric.parameters.*;

/**
 * Identifies a metric that may be bootstrapped, in order to assess its uncertainty
 * when computed from a limited sample of verification pairs.  Metrics that implement
 * this interface should store the bootstrap parameter together with the other
 * parameters of the metric, as this will encourage proper handling when creating
 * copies of the metric. 
 * 
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public interface BootstrapableMetric {

    /**
     * Identifier for no bootstrap.
     */

    static final int NO_BOOTSTRAP = 1001;

    /**
     * String identifier for no bootstrap.
     */

    static final String NO_BOOTSTRAP_STRING = "None";

    /**
     * Identifier for the stationary block bootstrap algorithm, which obtains
     * a bootstrap resample from a moving window of variable block length centered
     * on a particular verification pair.  The block length is a random variable,
     * with values to be sampled from a probability distribution.
     */
    
    static final int STATIONARY_BLOCK_BOOTSTRAP = 1002;
    
    /**
     * String identifier for stationary block bootstrap.
     */

    static final String STATIONARY_BLOCK_BOOTSTRAP_STRING = "Stationary block";

    /**
     * Returns the bootstrap parameter associated with the verification metric
     * or null if no parameter has been set.
     *
     * @return the bootstrap parameter
     */
    
    BootstrapParameter getBootstrapPar();

    /**
     * Sets the bootstrap parameter associated with the verification metric or
     * clears the parameter if the input is null;
     * 
     * @param bs the bootstrap parameters
     */

    void setBootstrapPar(BootstrapParameter bs);

    /**
     * Clears any bootstrap parameter associated with the verification metric.
     */

    void clearBootstrapPar();


}
