package evs.metric.results;

import evs.metric.metrics.*;

/**
 * Class for throwing exceptions that signify an error in computing interval results.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class SamplingIntervalException extends MetricCalculationException {
    
    /**
     * Constructs an SamplingIntervalException with no message.
     */
    
    public SamplingIntervalException() {
        super();
    }

    /**
     * Constructs an SamplingIntervalException with the specified message.
     * 
     * 
     * @param s the message.
     */
    
    public SamplingIntervalException(String s) {
	super(s);
    }
}
