package evs.metric.metrics;

//EVS dependencies
import evs.data.PairedData;
import evs.metric.results.*;
import evs.metric.parameters.*;
import evs.utilities.mathutil.*;
import evs.utilities.matrix.*;
import evs.analysisunits.*;
import evs.utilities.StringUtilities;

//Java util dependencies
import java.util.*;

//Spring framework dependencies
//import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
//import org.springframework.beans.factory.config.BeanDefinition;
//import org.springframework.core.type.filter.AssignableTypeFilter;
        
/**
 * A store of threshold metrics, such as reliability diagrams or ROC plots.  For
 * convenience, this class extends the evs.metric.Metric class, allowing a set of
 * threshold metrics to be recognized as a metric in itself.  By implication, 
 * all of the parameter values of the input metrics must be the same, except the
 * first parameter of the threshold metric, namely the event threshold.  This is
 * replaced with a threshold array with each index taking the corresponding
 * value of the threshold parameter for a given threshold metric.  
 *
 * All input metrics are deep copied on construction to prevent inadvertent and 
 * invalid changes in the parameter values of the children.  The same applies to 
 * the get methods.
 *
 * Care should be taken when storing objects of this class in a map, since the
 * {@link evs.metric.metrics.Metric#compareTo(java.lang.Object)} method tests for the String representation
 * of the metric, which is the same for the stored metric as the metric store.  Thus,
 * metrics should not be mixed with stores of metrics in a map.
 *
 * Currently, this class does not guarantee consistency between the results in the
 * metric store (i.e. the store of this superclass, namely Metric) and the results
 * in the stores of the associated threshold metrics.  Specifically, the current
 * metric may be associated with threshold results, but the threshold metrics
 * may not contain pointers to the individual results. TODO: fully implement the method
 * setResult in this class to ensure recursive setting of results for associated 
 * threshold metrics.  Note that clearResults() has been fully implemented.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ThresholdMetricStore extends Metric implements SingleValuedMetric, EnsembleMetric {

    /********************************************************************************
     *                                                                              *
     *                                   VARIABLES                                  *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * The store of metrics indexed by their threshold values for convenience 
     * in an ordered map.
     */
    
    private TreeMap<DoubleProcedureParameter,ThresholdMetric> metricsByThreshold = new TreeMap();
    
    /**
     * Default thresholds for each threshold metric.
     */
    
    private static TreeMap<String,DoubleProcedureArrayParameter> defaultPars = new TreeMap();    
    
    /**
     * Class for which a default metric will be returned.
     */
    
    private static Class defaultClass = ReliabilityDiagram.class;
        
    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Constructs a new store with a single threshold metric.
     *
     * @param metric the threshold metric
     */
    
    public ThresholdMetricStore(ThresholdMetric metric) {
        //Set the superclass parameters
        Metric m = (Metric)metric;
        descriptionURL = m.descriptionURL;
        name = m.name;
        //Set the first metric
        int length = ((Metric)metric).getParCount();
        pars = new MetricParameter[length];
        DoubleProcedureParameter p = (DoubleProcedureParameter)metric.getThreshold().deepCopy();
        pars[0] = new DoubleProcedureArrayParameter(new DoubleProcedureParameter[]{p});
        for(int i = 1; i < length; i++) {
            pars[i] = m.pars[i].deepCopy(); 
        }
        metricsByThreshold.put(p,(ThresholdMetric)((Metric)metric).deepCopy());
        setResultsAndCounts(new ThresholdMetric[]{metric});
    }

    /**
     * Constructs a new store with a set of threshold metrics, which must be of the
     * same class and have different threshold parameter values.
     *
     * @param metric the threshold metric
     */
    
    public ThresholdMetricStore(ThresholdMetric[] metric) {
        if(metric.length <=0) {
            throw new IllegalArgumentException("Specify at least one threshold for the metric store.");
        }
        //Set the superclass parameters
        Metric m = (Metric)metric[0];
        descriptionURL = m.descriptionURL;
        name = m.name;
        //Set the first metric
        int length = ((Metric)metric[0]).getParCount();
        pars = new MetricParameter[length];
        DoubleProcedureParameter pp = (DoubleProcedureParameter)metric[0].getThreshold().deepCopy();
        pars[0] = new DoubleProcedureArrayParameter(new DoubleProcedureParameter[]{pp});
        for(int i = 1; i < length; i++) {
            pars[i] = m.pars[i].deepCopy(); 
        }
        metricsByThreshold.put(pp,(ThresholdMetric)((Metric)metric[0]).deepCopy());
        setResultsAndCounts(new ThresholdMetric[]{metric[0]});
        
        //Check the remaining metrics (the first is already stored)
        for(int i = 1; i < metric.length; i++) {
            checkMetric(metric[0],metric[i]);
            ThresholdMetric copy = (ThresholdMetric)((Metric)metric[i]).deepCopy();
            DoubleProcedureParameter p = (DoubleProcedureParameter)metric[i].getThreshold().deepCopy();
            metricsByThreshold.put(p,copy);
        }
        //Set the new parameter
        DoubleProcedureParameter[] input = new DoubleProcedureParameter[metric.length];
        for(int i = 0; i < input.length; i++) {
            input[i]=(DoubleProcedureParameter)metric[i].getThreshold().deepCopy();
        }
        pars[0] = new DoubleProcedureArrayParameter(input);
        setParameters(pars);
        setResultsAndCounts(metric);  
    }    
    
    /********************************************************************************
     *                                                                              *
     *                                ACCESSOR METHODS                              *
     *                                                                              *
     *******************************************************************************/            

    /**
     * Returns the forecast statistic to be applied to paired input that comprise
     * multiple forecasts at a single time (e.g. ensemble forecast input).    
     *
     * @return the forecast statistic
     */
    
    public VectorFunction getForecastStatistic() {
        Metric m = getFirstMetricInStore();
        if(m instanceof SingleValuedMetric) {
            return ((SingleValuedMetric)m).getForecastStatistic();
        }
        return null;
    }    
    
    /**
     * Returns true if a forecast statistic has been set, false otherwise.
     * 
     * @return true if a forecast statistic has been set.
     */
    
    public boolean hasForecastStatistic() {
        return getForecastStatistic() != null;
    }        
    
    /**
     * Returns true if the metric has a result for the specified forecast type.
     *
     * See the ForecastTypeParameter class for the allowed types.
     *
     * @param forecastType the forecast type
     * @return true if the result exists, false otherwise
     */
    @Override
    public boolean hasResult(int forecastType) {
        return super.hasResult(forecastType);
        //TODO: uncheck below when the setResult method has been fully implemented to set results
        
//        Iterator it = metricsByThreshold.keySet().iterator();
//        while(it.hasNext()) {
//            if(((Metric)metricsByThreshold.get(
//                    (DoubleProcedureParameter)it.next())).hasResult(forecastType)) {
//                return true;
//            }
//        }        
//        return false;
    }
    
    /**
     * Returns true if the metric has some results available.
     *
     * @return true if the results exist, false otherwise
     */
    @Override
    public boolean hasResults() {
        return super.hasResults();
        //TODO: uncheck below when the setResult method has been fully implemented to set results
        
//        Iterator it = metricsByThreshold.keySet().iterator();
//        while(it.hasNext()) {
//            if(((Metric)metricsByThreshold.get(
//                    (DoubleProcedureParameter)it.next())).hasResults()) {
//                return true;
//            }
//        }
//        return false;
    }        
    
    /**
     * Returns the metric identifier, which is the ID of the stored metric.
     *
     * @return an identifier
     */
    
    public int getID() {
        return getStoredID();
    }    

    /**
     * Returns the id of a stored metric associated with this class.
     *
     * @return an identifier
     */
    
    public int getStoredID() {
        return ((Metric)metricsByThreshold.get(metricsByThreshold.firstKey())).getID();
    }    
    
    /**
     * Returns the result type associated with the metric.  See the 
     * evs.metric.MetricResult class for supported types.
     *
     * @return an identifier
     */
    
    public int getResultID() {
        return ((Metric)metricsByThreshold.get(metricsByThreshold.firstKey())).getResultID();
    }
    
    /**
     * Returns the first stored metric.
     *
     * @return the first stored metric
     */
    
    public Metric getFirstMetricInStore() {
        return (Metric)metricsByThreshold.get(metricsByThreshold.firstKey());
    }

    /**
     * Returns true if the stored metrics are instances of {@link evs.metric.metrics.BootstrapableMetric},
     * false otherwise.
     *
     * @return true if the stored metrics are instances of {@link evs.metric.metrics.BootstrapableMetric}, false otherwise.
     */

    public boolean isBootstrapable() {
        return metricsByThreshold.firstEntry().getValue() instanceof BootstrapableMetric;
    }
    
    /**
     * Returns true if the metric is defined in real units of the forecast
     * and observed variable, false otherwise.
     * 
     * @return true if the metric is defined in real units
     */    

    public boolean hasRealUnits() {
        return ((Metric)metricsByThreshold.get(metricsByThreshold.firstKey())).hasRealUnits();
    }      
    
    /**
     * Returns a default set of probability thresholds for a specified class of metric or
     * null if no default thresholds exist for that class.  
     *
     * @param metricClass the metric class
     * @return the default thresholds for the specified metric
     */
    
    public static DoubleProcedureArrayParameter getDefProbThresh(Class metricClass) {
        initializeDefaults();
        if(!defaultPars.containsKey(metricClass.toString())) {
            throw new IllegalArgumentException("Update method 'initializeDefaults' in class " +
                    "'evs.metric.metrics.ThresholdMetricStore' to include default " +
                    "threshold values for the new metric '"+metricClass+"'.");
        }
        return defaultPars.get(metricClass.toString());
    }
    
    /**
     * Returns all thresholds for metrics currently in the store.
     * 
     * @return all thresholds
     */
    
    public DoubleProcedureParameter[] getThresholds() {
        DoubleProcedureParameter[] returnMe = new DoubleProcedureParameter[metricsByThreshold.size()];
        Iterator i = metricsByThreshold.keySet().iterator();
        int next = 0;
        while(i.hasNext()) {
            DoubleProcedureParameter nx = metricsByThreshold.get(i.next()).getThreshold();
            returnMe[next] = (DoubleProcedureParameter)nx.deepCopy();
            next++;
        }
        return returnMe;
    }    
    
    /**
     * Returns information about the thresholds by lead period.  The first row
     * contains the threshold values in the specified units.  The second row
     * contains the threshold values in real units if the original thresholds
     * were in probabilities.  If the threshold contains a lower and an upper 
     * limit, the first two rows refer to the lower limit and the next two rows
     * refer to the upper limit.  The last row contains the sample counts.
     *
     * @param forecastType the forecast type
     * @return metadata on the thresholds
     */
    
    public MetricResultByLeadTime getThresholdMetadata(int forecastType) {
        MetricResultByLeadTime returnMe = new MetricResultByLeadTime(MetricResult.DOUBLE_MATRIX_2D_RESULT);
        MetricResultByLeadTime times = results.get(forecastType);
        int tCount = times.getResultCount();
        int trCount = metricsByThreshold.size();
        //For each threshold, store the real values of the thresholds
        //If the thresholds are probabilities, these are the real values
        DoubleProcedureArrayParameter p = (DoubleProcedureArrayParameter)pars[0];
        Vector<Double> thresh_temp = new Vector<Double>();
        Vector<Double> realVals_temp = new Vector<Double>();                
        //Obtain the unique thresholds used (in case of a BETWEEN condition)
        DoubleProcedureParameter[] p2 = p.getParVal();
        for(int i = 0; i < p2.length; i++) {
            DoubleParameter[] next = p2[i].getThresholdValues();
            for(int j = 0; j < next.length; j++) {
                if(!thresh_temp.contains(next[j].getParVal())) {
                    thresh_temp.add(next[j].getParVal());
                    if (next[j] instanceof ProbabilityParameter) {
                        if (((ProbabilityParameter) next[j]).hasRealValueForProb()) {
                            DoubleParameter p3 = ((ProbabilityParameter) next[j]).getRealValForProb();
                            realVals_temp.add(p3.getParVal());
                        }
                    }
                }
            }
        }
        double[] thresh = new double[thresh_temp.size()];
        double[] realVals = null;
        for(int i = 0; i < thresh.length; i++) {
            thresh[i]=thresh_temp.get(i);
        }
        if(realVals_temp.size()>0) {
            realVals = new double[realVals_temp.size()];
            for(int i = 0; i < thresh.length; i++) {
                realVals[i]=realVals_temp.get(i);
            }
        }
        
        //TODO: when results and sample counts are stored at the level of 
        //individual metrics, return the sample counts from the individual metrics
        //using the code commented out below with UC. For now, return the results stored
        //in this class
        //TODO: when results and sample counts are stored at the level of 
        //individual metrics, return the sample counts from the individual metrics
        //using the code commented out below with UC. For now, return the results stored
        //in this class
        double[][] samples = new double[tCount][trCount];
        try {
            MetricResultByLeadTime r = counts.get(forecastType);
            DoubleMatrix1D t = times.getLeadTimes();
            for (int i = 0; i < tCount; i++) {
                Arrays.fill(samples[i],NULL_DATA);   //JB @30th October 2012
                double time = t.get(i);
                if (r.hasResult(time)) {
                    MetricResultByThreshold tr = (MetricResultByThreshold) r.getResult(time);
                    int tot = 0;
                    for(Iterator<DoubleProcedureParameter> it = 
                            metricsByThreshold.keySet().iterator(); it.hasNext(); ) {
                    	DoubleProcedureParameter pp = it.next();
                    	if (tr.hasResult(pp)) {
                            //Sample counts could be double results if aggregating metrics
                            MetricResult rrr = tr.getResult(pp);
                            if(rrr.getID()==MetricResult.INTEGER_RESULT) {
                                samples[i][tot] = ((IntegerResult) tr.getResult(pp)).getResult();
                            } else if (rrr.getID()==MetricResult.DOUBLE_RESULT) {
                                samples[i][tot] = ((DoubleResult) tr.getResult(pp)).getResult();
                            } else {
                                throw new IllegalArgumentException
                                        ("Unexpected result type for sample counts: '"+
                                        tr.getResult(pp).getClass()+"'.");
                            }
                        }
                    	tot++;
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Could not retrieve sample counts for metric '" + this + "'.");
            e.printStackTrace();
        }
        
        //Construct the matrix of sample counts per time and threshold
        //each row contains a time and each column a threshold, but to begin
        //with the rows and thresholds and columns are times
//UC        int[][] samples = new int[tCount][trCount];
//UC        Iterator i = metricsByThreshold.keySet().iterator();
//UC        int tot = 0;
//UC        while (i.hasNext()) {
//UC            ThresholdMetric m = metricsByThreshold.get(i.next());
//UC            if(((Metric) m).hasSampleCounts(forecastType)) {
//UC                int[] nS = ((Metric) m).getSCount(forecastType);
//UC                for(int j = 0; j < nS.length; j++) {
//UC                    samples[j][tot] = nS[j];
//UC                }
//UC            }
//UC            tot++;
//UC        }
        
        //Construct and return the result
        //JB@ 30th October 2012. Only return columns for which the sample count is not NULL_DATA
        //as duplicate thresholds are not computed, even if they are requested
        Object[] tim = times.getResults().keySet().toArray();
        for(int j = 0; j < samples.length; j++) {
            DoubleMatrix2D addMe = null;
            ArrayList<Integer> include = new ArrayList<Integer>();  //Columns to include
            if(realVals != null) {
                double[][] nxt = new double[3][thresh.length];
                nxt[0]=thresh;
                nxt[1]=realVals;
                for(int k = 0; k < samples[j].length; k++) {
                    nxt[2][k]=samples[j][k];
                    if(samples[j][k]!=NULL_DATA) {
                        include.add(k);
                    }
                }
                addMe  = new DenseDoubleMatrix2D(nxt);
            }
            else {
                double[][] nxt = new double[2][thresh.length];
                nxt[0]=thresh;
                for(int k = 0; k < samples[j].length; k++) {
                    nxt[1][k]=samples[j][k];
                    if(samples[j][k]!=NULL_DATA) {
                        include.add(k);
                    }                    
                }
                addMe  = new DenseDoubleMatrix2D(nxt);
            }
            //Subset data
            int tot = include.size();
            if (tot > 0) {
                addMe = addMe.transpose();
                double[][] useMe = new double[tot][addMe.getColumnCount()];
                for (int k = 0; k < tot; k++) {
                    useMe[k] = (double[]) addMe.getRowAt(include.get(k)).getMatrixValues();
                }
                addMe = new DenseDoubleMatrix2D(useMe).transpose();
            }
            returnMe.addResult(tim[j],new DoubleMatrix2DResult(addMe));           
        }
        return returnMe;
    }
            
    /**
     * Returns a deep copy of the current metric, where all instance variables 
     * occupy independent positions in memory from the current metric.  
     *
     * @return a deep copy of the current object 
     */
    
    public Metric deepCopy() {
        ThresholdMetric[] mets = new ThresholdMetric[metricsByThreshold.size()];
        int next = 0;
        for(Iterator i = metricsByThreshold.keySet().iterator(); i.hasNext();) {
            Metric m = (Metric)metricsByThreshold.get(i.next());
            mets[next]=(ThresholdMetric)m.deepCopy();
            next++;
        }        
        ThresholdMetricStore copy = new ThresholdMetricStore(mets);
        //Deep copy results.  There is no guarantee that the results are stored at the child level
        deepCopyResults(copy);
        return copy;
    }
    
    /**
     * Returns a metric with default parameter values using the static class
     * variable defaultClass to determine the type of metric to return.    
     *
     * @return a metric with default parameter values.
     */
    
    public static Metric getDefaultMetric() { 
        return getMetric(getDefProbThresh(defaultClass));
    }
    
    /**
     * Returns the class of metric for which this store has been instantiated.
     *
     * @return the store type
     */
    
    public Class getStoreInstanceClass() {
        return metricsByThreshold.get(metricsByThreshold.firstKey()).getClass();
    }
    
    /**
     * Returns a deep copy of the metric for a specified threshold value or null.
     *
     * @param threshold the threshold
     * @return a metric at the input threshold or null.
     */
    
    public Metric getMetric(DoubleProcedureParameter threshold) {
        Metric m = null;
        if(metricsByThreshold.containsKey(threshold)) {
            m = ((Metric)metricsByThreshold.get(threshold)).deepCopy();
        }
        return m;
    }
  
    /**
     * Convenience constructor for a set of metrics with specified parameter 
     * values.  The metric type to be constructed is defined in the defaultClass
     * variable of this class, which may be set.
     *
     * @param probs the probabilities
     */
    
    public static Metric getMetric(DoubleProcedureArrayParameter probs) { 
        Metric returnMe = null;
        DoubleProcedureParameter[] ps = probs.getParVal();
        ThresholdMetric[] tr = new ThresholdMetric[ps.length];
        try {
            for(int i = 0; i < tr.length; i++) {
                tr[i] = (ThresholdMetric)defaultClass.getMethod("getDefaultMetric",(Class[])null).invoke(null,(Object[])null);
                MetricParameter[] pars = ((Metric)tr[i]).getParameters();
                //Find the index of the probability procedure in the parameter list
                pars[0] = (DoubleProcedureParameter)ps[i].deepCopy();
                ((Metric)tr[i]).setParameters(pars);
            }
            returnMe = new ThresholdMetricStore(tr);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return returnMe;
    }    
    
    /**
     * Returns true if a metric exists for the specified threshold, false otherwise.
     *
     * @param threshold the threshold
     * @return true if the metric exists at the input threshold
     */
    
    public boolean hasMetric(DoubleProcedureParameter threshold) {
        return metricsByThreshold.containsKey(threshold);
    }

    /**
     * Returns a string representation of the metric store, which is the string
     * representation of the first metric in store.
     *
     * @return a string representation
     */

    public String toString() {
        return getFirstMetricInStore().toString();
    }
    
    /********************************************************************************
     *                                                                              *
     *                                MUTATOR METHODS                               *
     *                                                                              *
     *******************************************************************************/    
    
    /**
     * Sets the forecast statistic to be applied to paired input that comprise
     * multiple forecasts at a single time (e.g. ensemble forecast input).      
     *
     * @param forecastStat the forecast statistic
     */
    
    public void setForecastStatistic(VectorFunction forecastStat) {
        if(forecastStat == null) {
            throw new IllegalArgumentException("Cannot set a null forecast statistic.");
        }
        for(Iterator i = metricsByThreshold.keySet().iterator(); i.hasNext();) {
            Metric m = (Metric)metricsByThreshold.get(i.next());
            if(m instanceof SingleValuedMetric) {
                ((SingleValuedMetric)m).setForecastStatistic(forecastStat);
            }
        }
    }    
    
    /**
     * Sets the class for which a default metric will be constructed.  Throws an
     * exception if the class is not an evs.metric.ThresholdMetric.
     *
     * @param def the default class
     */    
        
    public static void setDefaultMetricClass(Class def) {
        Class[] imp = def.getInterfaces();
        boolean throwEx = true;
        for(int i = 0; i < imp.length; i++) {
            if(imp[i].equals(ThresholdMetric.class)) {
                throwEx = false;
            }
        }
        if(throwEx) {
            throw new IllegalArgumentException("Unsupported class type for the default.  Specify a threshold metric.");
        }
        defaultClass = def;
    }    
        
    /**
     * Adds another threshold metric to the store.  Throws an exception if the
     * specified metric is already contained in the store or if the metric is
     * not of the same type as the existing concrete ThresholdMetric.
     *
     * @param threshold the threshold metric
     */
    
    public void addMetric(ThresholdMetric threshold) throws IllegalArgumentException {
        ThresholdMetric test = (ThresholdMetric)metricsByThreshold.get(threshold.getThreshold());
        checkMetric(test,threshold);
        metricsByThreshold.put((DoubleProcedureParameter)threshold.getThreshold().deepCopy(),
                (ThresholdMetric)((Metric)threshold).deepCopy());
    }
    
    /**
     * Removes a threshold metric from the store.  
     *
     * @param remove the threshold to remove
     * @return true if the threshold was deleted
     */
    
    public boolean deleteMetric(DoubleProcedureParameter remove) {
        return metricsByThreshold.remove(remove) != null;
    }      
    
    /**
     * Overrides the superclass method to set the parameters of the stored metrics.
     * 
     * @param pars the parameters
     */
    
    public void setParameters(MetricParameter[] pars) throws IllegalArgumentException {
        //Check the parameters
        if(pars == null || pars.length != this.pars.length) {
             if (pars != null) {
                System.err.println("Input par classes: ");
                for (int i = 0; i < pars.length; i++) {
                    if (pars[i] != null) {
                        System.err.println(pars[i].getClass());
                    } else {
                        System.err.println("Null input.");
                    }
                }
            }
            if (this.pars != null) {
                System.err.println("Expected par classes: ");
                for (int i = 0; i < this.pars.length; i++) {
                    System.err.println(this.pars[i].getClass());
                }
            }
            throw new IllegalArgumentException("Unexpected parameter types for metric '"+name+"'.");
        }
        int len = this.pars.length;
        for(int i = 0; i < len; i++) {
            if(!getParClasses()[i].equals(pars[i].getClass())) {
                throw new IllegalArgumentException("Unexpected parameter types for metric '"+name+"': "+getParClasses()[i]+" versus "+pars[i].getClass());
            }
        }
        this.pars = new MetricParameter[pars.length];
        for(int i = 0; i < pars.length; i++) {
            this.pars[i]=pars[i].deepCopy();
        }
        
        //Set the parameters of the children
        DoubleProcedureArrayParameter p = (DoubleProcedureArrayParameter)pars[0];
        DoubleProcedureParameter[] pp = p.getParVal();
        int length = pp.length;
        ThresholdMetric[] mets = metricsByThreshold.values().toArray(new ThresholdMetric[length]);
        TreeMap<DoubleProcedureParameter,ThresholdMetric> newMet = new TreeMap();
        Metric copyMe = (Metric)metricsByThreshold.get(metricsByThreshold.firstKey());
        for(int i = 0; i < length; i++) {
            try {
                DoubleProcedureParameter next = (DoubleProcedureParameter)pp[i].deepCopy();
                //Add the new metric to the store
                Metric copy = null;
                try {
                    copy = ((Metric)metricsByThreshold.get(next)).deepCopy();
                }
                //No match
                catch(Exception e) {
                    copy = copyMe.deepCopy();                    
                }
                MetricParameter[] copiedPars = new MetricParameter[pars.length];
                copiedPars[0] = next;
                for(int j = 1; j < pars.length; j++) {
                    copiedPars[j] = pars[j].deepCopy();
                }
                //This will clear results if necessary
                copy.setParameters(copiedPars);
                newMet.put(next,(ThresholdMetric)copy);
            }
            catch(Exception f) {
                f.printStackTrace();
                throw new IllegalArgumentException("Unexpected parameter types for metric '"+name+"'.");
            }
        }
        
        metricsByThreshold = newMet;
        
//        //Clear all results if required
//        Iterator i = metricsByThreshold.keySet().iterator();
//        boolean clearRes = true;
//        while(i.hasNext()) {
//            if(((Metric)metricsByThreshold.get(i.next())).hasResults()) {
//                clearRes  = false;
//            }
//        }
        
        if(hasResults()) {  // && clearRes
            clearResults();
            clearSampleCounts();
            System.out.println("Clearing all results for the threshold metric store comprising '"+mets[0].getClass().getName()+"'.");
        } 
    }     
    
    /**
     * Uses the specified paired data to compute and return the result of the metric.
     * The metric results are returned, together with the sample counts, but not stored 
     * locally.  The metric result is located in the first index of the return array
     * and the sample counts are located in the second index. Optionally, specify
     * the results of a reference forecast from which to compute skill if the 
     * metric is a skill score. 
     * 
     * @param forecastType the forecast type
     * @param paired the paired data
     * @param refResult the results for a reference forecast (may be null)
     * @return the metric result and sample counts alternating for each threshold metric in store
     */
    
    public MetricResult[] compute(int forecastType, PairedData paired, MetricResult refResult) throws MetricCalculationException {
        if(paired==null) {
            throw new MetricCalculationException("Error computing metric '"+getName()+"': input pairs were null.");
        }
        if(refResult!=null) {
            if(!(refResult instanceof MetricResultByThreshold)) {
                throw new MetricCalculationException("Incorrect result type for reference forecast. "
                        + "Expected result of type '"+MetricResultByThreshold.class+"': "+refResult.getClass()+".");
            }
        }

        //Need a reference result for a skill calculation, unless sample climatology
        if(forecastType==ForecastTypeParameter.REGULAR_FORECAST && isSkillMetric() && !((SkillScore)getFirstMetricInStore()).getRefFcst().
                hasRefForecast(ForecastTypeParameter.SAMPLE_CLIMATOLOGY_STRING) && refResult==null) {
            throw new MetricCalculationException("Expected a non-null reference forecast "
                        + "result from which to compute the " + getName() + ".");
        }

        //Iterate through the children, calling compute each time, then add the
        //results for each threshold to a threshold store 
        MetricResultByThreshold threshStore = null;
        MetricResultByThreshold countStore = null;
        
        Iterator i = metricsByThreshold.keySet().iterator();
        //TreeMap<DoubleProcedureParameter,ThresholdMetric> updatedByThreshold = new TreeMap();

        //Derive single-valued pairs if required
        PairedData p = paired;
        Metric test = getFirstMetricInStore();
        double nV = paired.getNullValue();
        //Could test with hasForecastStatistic(), but this is extra safe
        //in case forecast statistics have been set for some mixed metrics
        if (hasForecastStatistic() && ! (test instanceof SampleSize
                || test instanceof EnsembleMetric)) {
            DoubleMatrix2D pp = getForecastStatFromPaired(
                    getForecastStatistic(), p.getPairs(),nV);
            p = new PairedData(pp,false,nV);
            p.setClimObsWithTimes(paired.getClimObsWithTimes());
            p.setUncClimObsWithTimes(paired.getUncClimObsWithTimes());
        }
        
        //Iterate through the thresholds
        DoubleProcedureParameter[] pts = ((DoubleProcedureArrayParameter)pars[0]).getParVal();
        int tC = 0;  //Current threshold
        
        //Store real thresholds already computed. Do not compute repeat/non-unique real-valued thresholds 
        //JB@29th October 2012
        TreeSet<DoubleProcedureParameter> uniqueReal = new TreeSet<DoubleProcedureParameter>();

        //Get the real values corresponding to climatological probabilities
        //using the unconditional climatology if available. The climatology here is 
        //used to compute the real values corresponding to any climatological probability
        //thresholds. Note that the paired data are ALWAYS used for any climatological reference
        //in skill scores, otherwise the score may not make sense. However, the climatological
        //thresholding relies on obtaining the unconditional observations here (or any other observations
        //explicitly set for the pairs), prior to determining the conditional pairs below. Once
        //the conditional pairs are determined, any paired climatology associated with them will,
        //by definition, be conditional
        DoubleMatrix1D climatology = p.getClimObs();
        if (p.hasUncClimObs()) {
            climatology = p.getUncClimObs();
        }
        double[][] climateCDF = EmpiricalCDFCalculator.getRawEmpiricalCDF(climatology.toArray(),nV,true);

        //Loop thresholds
        while(i.hasNext()) {
            DoubleProcedureParameter next = (DoubleProcedureParameter)i.next();
            Metric m = (Metric)metricsByThreshold.get(next);
            ThresholdMetric tm = (ThresholdMetric)m;

            //Update probability thresholds with real-valued thresholds if possible
            //Update both the thresholds in the metricsByThreshold store and the array parameter
            DoubleProcedureParameter pro = null;
            try {
                
                pro = tm.getThreshold().getRealValuedEquivalent(
                        climateCDF, nV);
                
                DoubleProcedureParameter pt = tm.getThreshold();
                if (pt.areProbs().getParVal()) {
                    pt.setRealValuesForProbs(pro.getThresholdValues());
                }
                tm.setThreshold(pt);
                //Update parameter values for the threshold metric with the 
                //real-valued thresholds just computed
                if (next.areProbs().getParVal()) {

                    pts[tC].setRealValuesForProbs(pro.getThresholdValues());
                    next.setRealValuesForProbs(pro.getThresholdValues());
                    DoubleProcedureParameter check = new DoubleProcedureParameter(pro.getThresholdType(), pro.getThresholdValues(),
                            new ProbabilityIdentifierParameter(false), new BooleanParameter(false));
                    //JB@29th October 2012
                    //Check that the probability threshold is unique in real terms
                    if (uniqueReal.contains(check)) {
                        //System.out.println("Skipping duplicate threshold: "+next);
                        tC++;
                        continue;   //Skip
                    }
                    uniqueReal.add(check);

                }             
            } catch (IllegalArgumentException e) {
                 System.err.println("Could not compute metric '"+this+"' at threshold "+next+". "
                         +e.getMessage());
            }
            MetricResult ref = refResult;
            MetricResult[] r = null;
            //Compute results for the current metric
            if(refResult!=null) {
                if(!((MetricResultByThreshold)refResult).hasResult(next)) {
                    System.err.println("Could not compute metric '"+this+"' at threshold "+next+
                            ": the reference forecast was not available.");
                } else {
                    ref = ((MetricResultByThreshold)refResult).getResult(next);
                    try {
                        r = m.compute(forecastType,p,ref);
                    } catch(MetricCalculationException e) {
                        System.err.println("Could not compute metric '"+this+"' at threshold "+next+". "+e.getMessage());
                    }
                }
            } else {
                try {
                    r = m.compute(forecastType, p, ref);
                } catch (MetricCalculationException e) {
                    System.err.println("Could not compute metric '"+this+"' at threshold "+next+". "+e.getMessage());
                }
            }
            if(r!=null && r[0]!=null) {
                //Set the stores
                if(threshStore==null) {
                    threshStore = new MetricResultByThreshold(r[0].getID());
                    countStore = new MetricResultByThreshold(r[1].getID());
                }
                threshStore.addResult(next,r[0]);
                countStore.addResult(next,r[1]);
            }
            tC++;
        }
        if(threshStore==null) {
                throw new MetricCalculationException("No data for any of the threshold conditions associated with metric: "+getStoreInstanceClass().getSimpleName());
        }
        return new MetricResult[]{threshStore,countStore};
            
            
//            //Update the reference to the threshold
//            next = tm.getThreshold();
//            updatedByThreshold.put(next,tm);
//
//            tC++;
//            //Result computed?
//            if(m.hasResult(forecastType)) {
//                MetricResultByLeadTime nextLead = m.getResult(forecastType);   
//                //Add the new threshold stores
//                TreeMap<Double,MetricResult> res = nextLead.getResults();
//                Iterator j = res.keySet().iterator();
//                //Iterate through the forecast lead times for the current threshold
//                while(j.hasNext()) {
//                    double lead = (Double) j.next();
//                    MetricResult res2 = res.get(lead);
//                    MetricResultByThreshold nextThresh = null;
//                    if(!periodStore.hasResult(lead)) {
//                        nextThresh = new MetricResultByThreshold(res2.getID());
//                        periodStore.addResult(lead,nextThresh);
//                    } else {
//                        nextThresh = (MetricResultByThreshold)periodStore.getResult(lead);
//                    }
//                    nextThresh.addResult(next,res2);
//                }
//            }
//            //Also add skill results if available (must be done separately as last call with 
//            //a regular forecast automatically adds the skill results for all available references)
//            if(m.hasResult(ForecastTypeParameter.SKILL)) {
//                MetricResultByLeadTime nextLead = m.getResult(ForecastTypeParameter.SKILL);
//                
//                //Add the new threshold stores
//                TreeMap<Double,MetricResult> res = nextLead.getResults();
//                Iterator j = res.keySet().iterator();
//                //Iterate through the forecast lead times for the current threshold
//                while(j.hasNext()) {
//                    double lead = (Double)j.next();
//                    MetricResult res2 = res.get(lead);
//                    MetricResultByThreshold nextThresh = null;
//                    if(!skillStore.hasResult(lead)) {
//                        nextThresh = new MetricResultByThreshold(res2.getID());
//                        skillStore.addResult(lead,nextThresh);
//                    } else {
//                        nextThresh = (MetricResultByThreshold)skillStore.getResult(lead);
//                    }
//                    nextThresh.addResult(next,res2);
//                }
//            }
//        }
//        //Regular forecast not present with skill score, so only check skill store
//        if(forecastType==ForecastTypeParameter.SKILL ||
//                forecastType==ForecastTypeParameter.REGULAR_FORECAST && (getFirstMetricInStore() instanceof SkillScore)) {
//            if(skillStore.getResultCount()==0&&!silent) {
//                throw new MetricCalculationException("No data for any of the threshold conditions associated with metric: "+getStoreInstanceClass().getSimpleName());
//            }
//        } 
//        else {
//            if(periodStore.getResultCount()==0&&!silent) {
//                throw new MetricCalculationException("No data for any of the threshold conditions associated with metric: "+getStoreInstanceClass().getSimpleName());
//            }
//        }
//        metricsByThreshold = updatedByThreshold; //Updated thresholds that include real-values in case of prob thresholds
//        results.put(forecastType,periodStore);
//        if(skillStore.getResultCount()>0) {
//            results.put(ForecastTypeParameter.SKILL,skillStore);
//            return skillStore;
//        }
//        return periodStore;



    }    
    
//    /**
//     * Uses the specified paired data to compute and store the result of the metric
//     * for every forecast lead time in the input paired dataset.
//     *
//     * This method will overwrite the results of a previous calculation if one exists.
//     * It also assumes that all conditioning of the forecasts and observations has
//     * been completed.  Care should be taken to call this method each time the
//     * parameter values of the current metric are modified.  The metric result is
//     * computed for each lead period separately.  They are added to the local store
//     * with the associated sample counts, both of which are returned for convenience.
//     *
//     * If the current metric is a skill score, the reference forecast must be
//     * provided, unless the reference is sample climatology, otherwise an exception
//     * will be thrown.  Only one reference forecast is currently supported, but
//     * this may be changed in future.
//     *
//     * @param forecastType the forecast type
//     * @param paired the paired data
//     * @param reference the reference forecast (may be null, unless skill metric)
//     * @param silent is true to silence printing of messages to standard out
//     * @return the metric result (if skill is available, this will be returned)
//     */
//    @Override
//    public synchronized MetricResultByLeadTime computeByLeadTime(int forecastType,
//            PairedData paired, MetricResultByLeadTime reference, boolean silent)
//            throws MetricCalculationException {
//        if(paired==null) {
//            throw new MetricCalculationException("Error computing metric '"+getName()+"': input pairs were null.");
//        }
//        //Iterate through the children, calling compute each time, then add the
//        //results for each threshold to a threshold store
//        MetricResultByLeadTime periodStore = new MetricResultByLeadTime(MetricResult.METRIC_RESULT_BY_THRESHOLD);
//        MetricResultByLeadTime skillStore = new MetricResultByLeadTime(MetricResult.METRIC_RESULT_BY_THRESHOLD);
//
//        Iterator i = metricsByThreshold.keySet().iterator();
//        TreeMap<DoubleProcedureParameter,ThresholdMetric> updatedByThreshold = new TreeMap();
//
//        //Single-valued pairs if required
//        PairedData p = paired;
//        Metric test = getFirstMetricInStore();
//        //Could test with hasForecastStatistic(), but this is extra safe
//        //in case forecast statistics have been set for some mixed metrics
//        if (hasForecastStatistic() && ! (test instanceof SampleSize
//                || test instanceof EnsembleMetric)) {
//            DoubleMatrix2D pp = getForecastStatFromPaired(
//                    getForecastStatistic(), p.getPairs());
//            p = new PairedData(pp,false);
//            p.setClimObsWithTimes(paired.getClimObsWithTimes());
//        }
//
//        //Iterate through the thresholds
//        int tC = 0;  //Current threshold
//        while(i.hasNext()) {
//            DoubleProcedureParameter next = (DoubleProcedureParameter)i.next();
//            Metric m = (Metric)metricsByThreshold.get(next);
//            ThresholdMetric tm = (ThresholdMetric)m;
//
//            //Update probability thresholds with real-valued thresholds
//            DoubleProcedureParameter pro = tm.getThreshold().getRealValuedEquivalent(
//                    p.getClimObs(), AnalysisUnit.getNullValue());
//            DoubleProcedureParameter pt = tm.getThreshold();
//            if (pt.areProbs().getParVal()) {
//                pt.setRealValuesForProbs(pro.getThresholdValues());
//            }
//            tm.setThreshold(pt);
//
//            DoubleProcedureParameter[] pts = ((DoubleProcedureArrayParameter)pars[0]).getParVal();
//            //Update parameter values for the threshold metric with the
//            //real-valued thresholds just computed
//            if(next.areProbs().getParVal()) {
//                pts[tC].setRealValuesForProbs(pro.getThresholdValues());
//            }
//            //Set warning message for CRPS with Hersbach
//            if (m instanceof MeanContRankProbScore) {
//                ((MeanContRankProbScore)m).setSilenceHersbach(silent);
//                if(!silent) {
//                    ((MeanContRankProbScore)m).setThresholdForHersbachWarn(pro);
//                }
//            }
//
////            MetricResultByLeadTime ref = null;
////            if(m.hasResult(ForecastTypeParameter.REFERENCE_FORECAST)) {
////                ref = m.getResult(ForecastTypeParameter.REFERENCE_FORECAST);
////            }
//            //Compute results for the current metric
//            m.computeByLeadTime(forecastType,p,reference,silent);
//
//
//
//
//            //Update the reference to the threshold, as computeByLeadTime()
//            //also sets the real-valued threshold for a probability threshold
//            next = tm.getThreshold();
//            updatedByThreshold.put(next,tm);
//
//            tC++;
//            //Result computed?
//            if(m.hasResult(forecastType)) {
//                MetricResultByLeadTime nextLead = m.getResult(forecastType);
//                //Add the new threshold stores
//                TreeMap<Double,MetricResult> res = nextLead.getResults();
//                Iterator j = res.keySet().iterator();
//                //Iterate through the forecast lead times for the current threshold
//                while(j.hasNext()) {
//                    double lead = (Double) j.next();
//                    MetricResult res2 = res.get(lead);
//                    MetricResultByThreshold nextThresh = null;
//                    if(!periodStore.hasResult(lead)) {
//                        nextThresh = new MetricResultByThreshold(res2.getID());
//                        periodStore.addResult(lead,nextThresh);
//                    } else {
//                        nextThresh = (MetricResultByThreshold)periodStore.getResult(lead);
//                    }
//                    nextThresh.addResult(next,res2);
//                }
//            }
//            //Also add skill results if available (must be done separately as last call with
//            //a regular forecast automatically adds the skill results for all available references)
//            if(m.hasResult(ForecastTypeParameter.SKILL)) {
//                MetricResultByLeadTime nextLead = m.getResult(ForecastTypeParameter.SKILL);
//
//                //Add the new threshold stores
//                TreeMap<Double,MetricResult> res = nextLead.getResults();
//                Iterator j = res.keySet().iterator();
//                //Iterate through the forecast lead times for the current threshold
//                while(j.hasNext()) {
//                    double lead = (Double)j.next();
//                    MetricResult res2 = res.get(lead);
//                    MetricResultByThreshold nextThresh = null;
//                    if(!skillStore.hasResult(lead)) {
//                        nextThresh = new MetricResultByThreshold(res2.getID());
//                        skillStore.addResult(lead,nextThresh);
//                    } else {
//                        nextThresh = (MetricResultByThreshold)skillStore.getResult(lead);
//                    }
//                    nextThresh.addResult(next,res2);
//                }
//            }
//        }
//        //Regular forecast not present with skill score, so only check skill store
//        if(forecastType==ForecastTypeParameter.SKILL ||
//                forecastType==ForecastTypeParameter.REGULAR_FORECAST && (getFirstMetricInStore() instanceof SkillScore)) {
//            if(skillStore.getResultCount()==0&&!silent) {
//                throw new MetricCalculationException("No data for any of the threshold conditions associated with metric: "+getStoreInstanceClass().getSimpleName());
//            }
//        }
//        else {
//            if(periodStore.getResultCount()==0&&!silent) {
//                throw new MetricCalculationException("No data for any of the threshold conditions associated with metric: "+getStoreInstanceClass().getSimpleName());
//            }
//        }
//        metricsByThreshold = updatedByThreshold; //Updated thresholds that include real-values in case of prob thresholds
//        results.put(forecastType,periodStore);
//        if(skillStore.getResultCount()>0) {
//            results.put(ForecastTypeParameter.SKILL,skillStore);
//            return skillStore;
//        }
//        return periodStore;
//    }
    
   /**
     * Overrides superclass method to set all the results for the children metrics.
     * 
     * @param forecastType the type of result (see the ForecastTypeParameter class)
     * @param result the metric result to set
     */
    
    public void setResult(int forecastType, MetricResultByLeadTime result) throws IllegalArgumentException {
//        throw new IllegalArgumentException("Method ThresholdMetricStore.setResult(int forecastType, MetricResultByLeadTime result)"
//                + " is not currently implemented.");
        ForecastTypeParameter.isSupportedForecastType(forecastType, true);
        if(result.getIDForStoredResults()!=MetricResult.METRIC_RESULT_BY_THRESHOLD) {
            throw new IllegalArgumentException("Unexpected data type for the thresholds store: threshold metric result expected but data type '"+result.getIDForStoredResults()+"' specified.");
        }
        //Set the overall results
        results.put(forecastType,result);
        //TODO: implement recursive setting of results for each stored threshold metric
    }    
    
    /**
     * Overrides the superclass method to clear all the results in the children metrics.
     */
    
    public synchronized void clearResults() {
        super.clearResults();
        Iterator it = metricsByThreshold.keySet().iterator();
        while(it.hasNext()) {
            Metric m = (Metric)metricsByThreshold.get(it.next());
            m.clearResults();
        }
    }
    
    /**
     * Overrides the superclass method to clear all the sample counts in the 
     * children metrics.
     */
    
    public void clearSampleCounts() {
        super.clearSampleCounts();
        Iterator it = metricsByThreshold.keySet().iterator();
        while(it.hasNext()) {
            ((Metric)metricsByThreshold.get(it.next())).clearSampleCounts();
        }
    }

    /**
     * Convenience method for setting the reference forecast identifier of a skill
     * metric (e.g. when the verification unit has changed name).  Throws an exception
     * if the input ID is null or this is not a skill metric.
     *
     * @param refID the reference forecast identifier
     */

    public void setRefFcst(String refID) {
        if(!isSkillMetric()) {
            throw new IllegalArgumentException("Cannot set the reference forecast identifier for"
                    + "metric '"+this+"', because it is not a skill metric.");
        }
        //Set parameter for store
        ((ReferenceForecastParameter)
                    ((Metric)this).getPar(MetricParameter.REFERENCE_FORECAST_PARAMETER)).
                    setRefForecast(refID);
        //Set parameter for each stored metric
        Iterator it = metricsByThreshold.keySet().iterator();
        while(it.hasNext()) {
            ((Metric)metricsByThreshold.get(it.next())).setRefFcst(refID);
        }
    }

    /*******************************************************************************
     *                                                                              *
     *                              PROTECTED METHODS                               *
     *                                                                              *
     *******************************************************************************/         

    /**
     * Convenience method for sub-selecting a paired dataset based on a real
     * threshold of the observations.  
     *
     * @param pairs the pairs
     * @param rT the real-valued threshold
     * @param nV the null value
     * @return the subset 
     */
    
    protected static DoubleMatrix2D getSubsetOfPairsByObsThresh(DoubleMatrix2D pairs, DoubleProcedure rT, double nV) {
        int length = pairs.getRowCount();
        boolean[] include = new boolean[length];
        int tot = 0;
        for(int i = 0; i < length; i++) {
            if(pairs.get(i,0) != nV) {
                include[i] = rT.apply(pairs.get(i,0));
                if(include[i]) {
                    tot++;
                }
            }
        }
        double[][] returnMe = new double[tot][pairs.getColumnCount()];
        int tot2 = 0;
        for(int i = 0; i < length; i++) {
            if(include[i]) { 
                returnMe[tot2]=(double[])pairs.getRowAt(i).getMatrixValues();
                tot2++;
            }
        }
        return new DenseDoubleMatrix2D(returnMe);
    }
    
     /*******************************************************************************
     *                                                                              *
     *                                PRIVATE METHODS                               *
     *                                                                              *
     *******************************************************************************/       
    
    /**
     * Throws an exception if the two metrics are from a different class or if
     * the threshold of the second metric is already stored. 
     *
     * @param first the first metric
     * @param second the second metric
     */
    
    private void checkMetric(ThresholdMetric first, ThresholdMetric second) throws IllegalArgumentException {
        if(!first.getClass().equals(second.getClass())) {
            throw new IllegalArgumentException("All metrics should be from the same class.");
        }
        if(metricsByThreshold.containsKey(second.getThreshold())) {
            throw new IllegalArgumentException("One or more of the specified thresholds are already contained in this store.");
        }
    }
    
    /**
     * Initializes the default thresholds for all current threshold metrics.
     */
    
    private static void initializeDefaults() {
        if(defaultPars.size()==0) {
            //Set the new parameter
            DoubleProcedureParameter[] input = new DoubleProcedureParameter[3];  //Without all data option
            DoubleProcedureParameter[] input2 = new DoubleProcedureParameter[4]; //With all data option
            DoubleParameter[] dubs = new DoubleParameter[]{new ProbabilityParameter(Double.NEGATIVE_INFINITY)};
            IntegerParameter pi = new IntegerParameter(DoubleProcedureParameter.GREATER_THAN);
            ProbabilityIdentifierParameter probs = new ProbabilityIdentifierParameter(true);
            input2[0]= new DoubleProcedureParameter(pi,dubs,probs,new BooleanParameter(true));
            for(int i = 0; i < input.length; i++) {
                DoubleParameter[] d = new DoubleParameter[1];
                d[0]=new ProbabilityParameter(Mathematics.round(0.25*(i+1),5));
                input[i]=new DoubleProcedureParameter(new IntegerParameter(DoubleProcedureParameter.GREATER_THAN)
                        ,d,probs,new BooleanParameter(true));
                input2[i+1]=(DoubleProcedureParameter)input[i].deepCopy();
            }
            DoubleProcedureArrayParameter p = new DoubleProcedureArrayParameter(input); 
            DoubleProcedureArrayParameter p2 = new DoubleProcedureArrayParameter(input2); 
            //MEP diagram: by default, just specify one threshold - all data
            DoubleProcedureArrayParameter p3 = new DoubleProcedureArrayParameter
                    (new DoubleProcedureParameter[]{new DoubleProcedureParameter((IntegerParameter)pi.deepCopy(),
                            new DoubleParameter[]{new ProbabilityParameter(Double.NEGATIVE_INFINITY)},
                            new ProbabilityIdentifierParameter(true),new BooleanParameter(true))});
            //Scan for available metrics
//            ClassPathScanningCandidateComponentProvider provider =
//                    new ClassPathScanningCandidateComponentProvider(true);
//            provider.addIncludeFilter(new AssignableTypeFilter(Metric.class));
//            Set<BeanDefinition> components = provider.findCandidateComponents("evs/metric/metrics/");
//            for (BeanDefinition component : components) {
//                try {
//                    Class cls = Class.forName(component.getBeanClassName());
//                    Class[] ifc = cls.getInterfaces();
//                    boolean nonCatMetric = true;
//                    boolean thresholdMetric = false;
//                    for(Class nxt : ifc) {
//                        if(nxt.getSimpleName().equals("CategoricalMetric")) {
//                            defaultPars.put(cls.getSimpleName(), (DoubleProcedureArrayParameter) p.deepCopy());
//                            nonCatMetric = false;
//                            break;
//                        } else if(nxt.getSimpleName().equals("ThresholdMetric")) {  //Exclude anything that is not a threshold metric
//                            thresholdMetric = true;
//                        }
//                    }
//                    //Add the default thresholds for metrics that can have an "All data" threshold (i.e. non-categorical)
//                    //If the metric is not a categorical metric, it must at least be a threshold metric to add the
//                    //threshold parameter values.
//                    if(nonCatMetric && thresholdMetric) {
//                        defaultPars.put(cls.getSimpleName(), (DoubleProcedureArrayParameter) p2.deepCopy());
//                    }
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }

            //Categorical metrics (i.e. metrics designed around discrete events)
            defaultPars.put(ReliabilityDiagram.class.toString(),(DoubleProcedureArrayParameter)p.deepCopy());
            defaultPars.put(RelativeOperatingCharacteristic.class.toString(),(DoubleProcedureArrayParameter)p.deepCopy());
            defaultPars.put(ROCScore.class.toString(),(DoubleProcedureArrayParameter)p.deepCopy());
            defaultPars.put(BrierScore.class.toString(),(DoubleProcedureArrayParameter)p.deepCopy());
            defaultPars.put(BrierSkillScore.class.toString(),(DoubleProcedureArrayParameter)p.deepCopy());

            //Non-categorical metrics (for which > -infinity, i.e. all data, can be used as one threshold)
            defaultPars.put(MeanError.class.toString(),(DoubleProcedureArrayParameter)p2.deepCopy());
            defaultPars.put(RelativeMeanError.class.toString(),(DoubleProcedureArrayParameter)p2.deepCopy());
            defaultPars.put(MeanAbsoluteError.class.toString(),(DoubleProcedureArrayParameter)p2.deepCopy());
            defaultPars.put(RootMeanSquareError.class.toString(),(DoubleProcedureArrayParameter)p2.deepCopy());
            defaultPars.put(MeanContRankProbScore.class.toString(),(DoubleProcedureArrayParameter)p2.deepCopy());
            defaultPars.put(Correlation.class.toString(),(DoubleProcedureArrayParameter)p2.deepCopy());
            defaultPars.put(SampleSize.class.toString(),(DoubleProcedureArrayParameter)p2.deepCopy());
            defaultPars.put(MeanCaptureRateDiagram.class.toString(),(DoubleProcedureArrayParameter)p2.deepCopy());
            defaultPars.put(SpreadBiasDiagram.class.toString(),(DoubleProcedureArrayParameter)p2.deepCopy());
            defaultPars.put(RankHistogram.class.toString(),(DoubleProcedureArrayParameter)p2.deepCopy());
            defaultPars.put(MeanContRankProbSkillScore.class.toString(),(DoubleProcedureArrayParameter)p2.deepCopy());
            
            //All data threshold by default only.
            defaultPars.put(MeanErrorOfProbabilityDiagram.class.toString(),(DoubleProcedureArrayParameter)p3.deepCopy());
            defaultPars.put(SingleValuedQQPlot.class.toString(),(DoubleProcedureArrayParameter)p3.deepCopy());
        }
    }
    
    /**
     * Sets the results and sample counts for a set of input metrics, so that the 
     * results are stored in the proper format.
     *
     * @param mets the metrics
     */
    
    private void setResultsAndCounts(ThresholdMetric[] mets) {
        if(mets != null && mets.length>0) {
            results = new TreeMap();
            counts = new TreeMap();
            //Result computed?  Not all thresholds need have all results, so collate all types available
            Vector<Integer> types = new Vector();            
            for(int i = 0; i < mets.length; i++) {
                Metric ms = (Metric)mets[i];
                TreeMap<Integer,MetricResultByLeadTime> res = ms.getResults();
                Integer[] tp = res.keySet().toArray(new Integer[res.size()]);  
                for(int j = 0; j < tp.length; j++) {
                    if(!types.contains(tp[j])) {
                        types.add(tp[j]);
                    }
                }
            }
            int length = types.size();
            for(int q = 0; q < length; q++) {
                int forecastType = types.get(q);
                MetricResultByLeadTime periodStore = new
                        MetricResultByLeadTime(MetricResult.METRIC_RESULT_BY_THRESHOLD);
                MetricResultByLeadTime sampleStore = new
                        MetricResultByLeadTime(MetricResult.METRIC_RESULT_BY_THRESHOLD);
                for(int i = 0; i < mets.length; i++) {
                    DoubleProcedureParameter next = mets[i].getThreshold();
                    Metric m = (Metric)mets[i];
                    //Results
                    if(m.hasResult(forecastType)) {
                        MetricResultByLeadTime nextLead = m.getResult(forecastType);
                        //Add the new threshold stores
                        TreeMap<Double,MetricResult> res = nextLead.getResults();
                        Iterator j = res.keySet().iterator();
                        while(j.hasNext()) {
                            double lead = (Double)j.next();
                            MetricResult res2 = res.get(lead);
                            MetricResultByThreshold nextThresh = null;
                            if(!periodStore.hasResult(lead)) {
                                nextThresh = new MetricResultByThreshold(res2.getID());
                                periodStore.addResult(lead,nextThresh);
                            } else {
                                nextThresh = (MetricResultByThreshold)periodStore.getResult(lead);
                            }
                            nextThresh.addResult(next,res2);
                        }
                    }
                    //Sample counts (JB @ 21 June 2012)                    
                    if(m.hasSampleCounts(forecastType)) {
                        MetricResultByLeadTime nextLead = m.getSampleCounts(forecastType);
                        //Add the new threshold stores
                        TreeMap<Double,MetricResult> res = nextLead.getResults();
                        Iterator j = res.keySet().iterator();
                        while(j.hasNext()) {
                            double lead = (Double)j.next();
                            MetricResult res2 = res.get(lead);
                            MetricResultByThreshold nextThresh = null;
                            if(!sampleStore.hasResult(lead)) {
                                nextThresh = new MetricResultByThreshold(res2.getID());
                                sampleStore.addResult(lead,nextThresh);
                            } else {
                                nextThresh = (MetricResultByThreshold)sampleStore.getResult(lead);
                            }
                            nextThresh.addResult(next,res2);
                        }
                    }
                }
                //Results
                if(periodStore.hasResults()) {
                    results.put(forecastType,periodStore);
                }
                //Sample counts (JB @ 21 June 2012)  
                if(sampleStore.hasResults()) {
                    counts.put(forecastType,sampleStore);
                }
                
            }
        }
    }
    
}
