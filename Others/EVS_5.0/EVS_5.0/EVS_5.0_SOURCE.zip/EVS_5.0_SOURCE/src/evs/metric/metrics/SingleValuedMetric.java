package evs.metric.metrics;

import evs.utilities.mathutil.VectorFunction;

/**
 * An interface identifying a single-valued forecast verification metric.
 *
 * @author evs@hydrosolved.com
 */

public interface SingleValuedMetric {

    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/     

    /**
     * Returns the forecast statistic to be applied to the vector of ensemble members
     * (or a single member in the case of a single-valued forecast).
     *
     * @return the forecast statistic
     */
    
    abstract VectorFunction getForecastStatistic();

    /********************************************************************************
     *                                                                              *
     *                                MUTATOR METHODS                               *
     *                                                                              *
     *******************************************************************************/     

    /**
     * Sets the forecast statistic to be applied to paired input that comprise
     * multiple forecasts at a single time (e.g. ensemble forecast input).      
     *
     * @param forecastStat the forecast statistic
     */
    
    abstract void setForecastStatistic(VectorFunction forecastStat);        
    
    
}
