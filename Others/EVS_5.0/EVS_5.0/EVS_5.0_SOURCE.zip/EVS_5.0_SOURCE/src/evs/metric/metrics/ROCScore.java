package evs.metric.metrics;

//EVS dependencies
import evs.data.*;
import evs.metric.parameters.*;
import evs.metric.results.*;
import evs.utilities.*;
import evs.utilities.matrix.*;
import evs.utilities.mathutil.*;

//Java util dependencies
import java.util.*;

//Other dependencies
import org.jfree.data.statistics.Regression;

/**
 * The ROC score comprises the rescaled area under the ROC curve (AUC), which 
 * provides a measure of a probability forecasts ability to discriminate between
 * events and non-events according to the observed outcome at different forecast
 * probability levels.  For the sample climatology as the reference forecast, 
 * the rescaled quantity is 2*AUC-1.
 * 
 * Multiple options exist for computing the empirical AUC, including the default:
 *
 * Mason, S.J. and N.E. Graham. (2002) Areas beneath the relative operating 
 * characteristics (ROC) and relative operating levels (ROL) curves: Statistical 
 * significance and interpretation, Q. J. R. Meteorol. Soc., 128, 2145-2166.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ROCScore extends ScoreMetric implements EnsembleMetric, SingleValuedMetric, 
        ThresholdMetric, SkillScore, CategoricalMetric, BootstrapableMetric {
       
    /********************************************************************************
     *                                                                              *
     *                             INSTANCE VARIABLES                               *
     *                                                                              *
     *******************************************************************************/     

    /**
     * Default number of points to include in the fitted ROC score calculation.
     */
    
    private static PositiveIntegerParameter defPCount = new ROCScorePointsParameter(10);    

    /**
     * Default method for computing the empirical ROC score.
     */

    private static ROCScoreMethodParameter defMethod
            = new ROCScoreMethodParameter();

    /**
     * The function to apply to forecasts with multiple values.
     */
    
    private VectorFunction forecastStat = null;

    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/      
        
    /**
     * Attempts to construct a ROC Score object with associated parameters.
     *  
     * @param event the event 
     * @param pointCount the number of points to include in the diagram
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use 
     * conditional pairs when available
     * @param fitted is true to fit a smooth bivariate model to the empirical AUC results
     * @param ref the reference forecasts used in the skill calculation
     * @param method the method used to compute the ROC Score
     * @param minS the minimum sample size
     * @param bs the bootstrap parameter
     */
    
    public ROCScore(DoubleProcedureParameter event,ROCScorePointsParameter pointCount,
            ForecastTypeParameter fType,UnconditionalParameter unconditional,
            FittedAUCParameter fitted,ReferenceForecastParameter ref,
            ROCScoreMethodParameter method,MinimumSampleSizeParameter minS,BootstrapParameter bs) {
        //Set the name
        name = "Relative operating characteristic score";
        //Set the parameters
        setParameters(new MetricParameter[]{event.deepCopy(),pointCount.deepCopy(),
        fType.deepCopy(),unconditional.deepCopy(),fitted.deepCopy(),ref.deepCopy(),
        method.deepCopy(),minS.deepCopy(),bs.deepCopy()});
        //Set the link to html description of the metric
        descriptionURL = getClass().getResource(EVSConstants.STATS_EXPLAINED_DIR + "rocscore.htm");
    } 
    
    /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/        
    
    /**
     * Returns the metric identifier.
     *
     * @return an identifier
     */
    
    public final int getID() {
        return ROCS;
    }    
    
    /**
     * Returns the result type associated with the metric.  See the 
     * {@link evs.metric.results.MetricResult} class for supported types.
     *
     * @return an identifier
     */
    
    public final int getResultID() {
        return MetricResult.DOUBLE_MATRIX_1D_RESULT;
    }
    
    /**
     * Returns true if the metric is defined in real units of the forecast
     * and observed variable, false otherwise.
     * 
     * @return true if the metric is defined in real units
     */    

    public final boolean hasRealUnits() {
        return false;
    }       

    /**
     * Returns true if the empirical AUC/ROC Score will be fitted with a smooth bivariate
     * model, false otherwise.
     *
     * @return true if the empirical ROC will be fitted
     */

    public final boolean getFitted() {
        return ((FittedAUCParameter)pars[4]).getParVal();
    }

    /**
     * Returns the forecast statistic to be applied to paired input that comprise
     * multiple forecasts at a single time (events.g. ensemble forecast input).    
     *
     * @return the forecast statistic
     */
    
    public final VectorFunction getForecastStatistic() {
        return forecastStat;
    }      
    
    /**
     * Returns true if a forecast statistic has been set, false otherwise.
     * 
     * @return true if a forecast statistic has been set.
     */
    
    public final boolean hasForecastStatistic() {
        return forecastStat != null;
    }       
    
    /**
     * Returns the default point count.  
     *
     * @return the default point count
     */
    
    public final static PositiveIntegerParameter getDefaultPointCount() {
        return (PositiveIntegerParameter)defPCount.deepCopy();
    }

    /**
     * Returns the default method for computing the empirical ROC Score.
     *
     * @return the default method
     */

    public final static ROCScoreMethodParameter getDefaultMethod() {
        return (ROCScoreMethodParameter)defMethod.deepCopy();
    }

    /**
     * Returns the threshold associated with this threshold diagram.
     *
     * @return the threshold
     */
    
    public final DoubleProcedureParameter getThreshold() {
        return (DoubleProcedureParameter)pars[0].deepCopy();
    }         

    /**
     * Returns a reference forecast parameter.
     *
     * @return the reference forecasts
     */

    public final ReferenceForecastParameter getRefFcst() throws IllegalArgumentException {
        return (ReferenceForecastParameter)getParameter(MetricParameter.REFERENCE_FORECAST_PARAMETER);
    }

    /**
     * Returns true if the skill score has a default reference forecast.
     *
     * @return true if the skill score has a default reference forecasts.
     */

    public final boolean hasDefaultRefFcst() {
        return getRefFcst().hasRefForecast();
    }

    /**
     * Returns any default reference forecast implemented for the skill score,
     * such as sample climatology.
     *
     * @return the default reference forecast
     */

    public final ReferenceForecastParameter getDefaultRefFcst() throws IllegalArgumentException {
        ReferenceForecastParameter r = new ReferenceForecastParameter();
        r.setRefForecast(ForecastTypeParameter.SAMPLE_CLIMATOLOGY_STRING);
        return r;
    }

    /**
     * Returns the name of the base metric for which the skill calculation is
     * computed.
     *
     * @return the base metric name
     */

    public final String getBaseMetricName() {
        return super.getName();
    }

    /**
     * Returns a deep copy of the current metric, where all instance variables 
     * occupy independent positions in memory from the current metric.  
     *
     * @return a deep copy of the current object 
     */
    
    public final Metric deepCopy() {
        ROCScore returnMe = new ROCScore((DoubleProcedureParameter)pars[0].deepCopy(),
                (ROCScorePointsParameter)pars[1].deepCopy(),
                (ForecastTypeParameter)pars[2].deepCopy(),
                (UnconditionalParameter)pars[3].deepCopy(),
                (FittedAUCParameter)pars[4].deepCopy(),
                (ReferenceForecastParameter)pars[5].deepCopy(),
                getROCScoreMethodPar(),
                (MinimumSampleSizeParameter)pars[7].deepCopy(),
                getBootstrapPar());
        deepCopyResults(returnMe);
        return returnMe;
    }

    /**
     * Returns the bootstrap parameter associated with the verification metric.
     *
     * @return the bootstrap parameter
     */
    @Override
    public final BootstrapParameter getBootstrapPar() {
        return (BootstrapParameter)pars[8].deepCopy();
    }

    /**
     * Returns a copy of the ROC Score method parameter.
     *
     * @return a deep copy of the ROC method parameter
     */

    public final ROCScoreMethodParameter getROCScoreMethodPar() {
        return (ROCScoreMethodParameter)pars[6].deepCopy();
    }

    /**
     * Returns a metric with default parameter values.  
     *
     * @return a metric with default parameter values.
     */
    
    public static Metric getDefaultMetric() { 
        ProbabilityIdentifierParameter prob =new ProbabilityIdentifierParameter(true);
        DoubleProcedureParameter eT = new DoubleProcedureParameter(new IntegerParameter(DoubleProcedureParameter.GREATER_THAN)
                ,new DoubleParameter[]{new ProbabilityParameter(1.0)},prob, new BooleanParameter(true));
        ForecastTypeParameter type = new ForecastTypeParameter(new int[]{ForecastTypeParameter.REGULAR_FORECAST});
        ROCScore r = new ROCScore(eT,(ROCScorePointsParameter)defPCount,type,
                new UnconditionalParameter(false),new FittedAUCParameter(false),
                new ReferenceForecastParameter(),
                new ROCScoreMethodParameter(),
                new MinimumSampleSizeParameter(),
                new BootstrapParameter());
        r.pars[5]=r.getDefaultRefFcst();
        return r;
    }  
    
    /********************************************************************************
     *                                                                              *
     *                               MUTATOR METHODS                                *
     *                                                                              *
     *******************************************************************************/     
     
    /**
     * Uses the specified paired data to compute and return the result of the metric.
     * The metric results are returned, together with the sample counts, but not stored 
     * locally.  The metric result is located in the first index of the return array
     * and the sample counts are located in the second index. Optionally, specify
     * the results of a reference forecast from which to compute skill if the 
     * metric is a skill score. If the forecastType is
     * {@link evs.metric.parameters.ForecastTypeParameter#REFERENCE_FORECAST}, the
     * ROC score is computed relative to sample climatology.  Note, however, that
     * the metrics associated with a verification unit may have a different forecast
     * type in another context, which is why the forecast type is specified explicitly.
     *
     * The returned results comprise {Empirical ROC Score, Fitted ROC Score, Empirical
     * ROC area, Fitted ROC area, Empirical ROC area for reference, Fitted ROC area
     * for reference} or the null value where undefined.
     * 
     * @param forecastType the forecast type
     * @param paired the paired data
     * @param refResult the results for a reference forecast (may be null)
     * @return the metric result and sample counts
     */
    
    public final MetricResult[] compute(int forecastType, PairedData paired, MetricResult refResult) throws MetricCalculationException {
        if(paired==null) {
            throw new MetricCalculationException("Error computing metric '"+getName()+"': "
                    + "input pairs were null.");
        }
        boolean sampleClimatology = getRefFcst().
                hasRefForecast(ForecastTypeParameter.SAMPLE_CLIMATOLOGY_STRING);
        //Skill calculation requested: need reference forecast or sample climatology
        if (forecastType == ForecastTypeParameter.REGULAR_FORECAST && !sampleClimatology) {
            if(refResult==null) {
                throw new MetricCalculationException("Expected a non-null reference forecast "
                        + "result from which to compute the " + getName() + ".");
            }
            if(!(refResult instanceof DoubleMatrix1DResult)) {
                throw new MetricCalculationException("Expected a reference forecast "
                        + "result of type " + DoubleMatrix1DResult.class.getName() + ": " +
                        refResult.getClass().getName());
            }
        }
        double nV = paired.getNullValue();
        ForecastTypeParameter.isSupportedForecastType(forecastType,true);
        MetricResult[] result = new MetricResult[2];
        DoubleProcedure pro = getThreshold().getParValReal();
        DoubleMatrix2D p = paired.getPairs();
        DoubleMatrix1D scores = new DenseDoubleMatrix1D(new double[]{Metric.NULL_DATA,Metric.NULL_DATA,
            Metric.NULL_DATA,Metric.NULL_DATA,Metric.NULL_DATA,Metric.NULL_DATA});
        result[0]=new DoubleMatrix1DResult(scores);
        try {
            if (forecastType == ForecastTypeParameter.REFERENCE_FORECAST) {
                //Compute ROC Score for reference relative to sample climatology
                //ROC areas are also provided
                DoubleMatrix1D d = ((DoubleMatrix1DResult)getAUC((DoubleMatrix2D)p.
                        getSubmatrixByColumn(2,p.getColumnCount()-1),pro,nV)).getResult();
                //Set the AUC results
                scores.set(2,d.get(0));
                scores.set(3,d.get(1));
                scores.set(4,0.5);
                scores.set(5,0.5);
                //Set the ROC Scores
                if(d.get(0)!=Metric.NULL_DATA) {
                    scores.set(0,2*d.get(0)-1);
                }
                if(d.get(1)!=Metric.NULL_DATA) {
                    scores.set(1,2*d.get(1)-1);
                }
                result[1]=new IntegerResult(lastCount);
            }
            else if (forecastType == ForecastTypeParameter.REGULAR_FORECAST) {
                DoubleMatrix1DResult num = (DoubleMatrix1DResult)getAUC((DoubleMatrix2D)p.
                        getSubmatrixByColumn(2,p.getColumnCount()-1),pro,nV);
                result[1]=new IntegerResult(lastCount);
                //SS for sample climatology
                if(sampleClimatology) {
                    double rs = num.getResult().get(0);
                    double rsn = num.getResult().get(1);
                    //Set the AUC results
                    scores.set(2,rs);
                    scores.set(3,rsn);
                    scores.set(4,0.5);
                    scores.set(5,0.5);
                    //Set the ROC Scores
                    if(rs!=Metric.NULL_DATA) {
                        scores.set(0,2*rs-1);;
                    }
                    if(rsn!=Metric.NULL_DATA) {
                        scores.set(1,2*rsn-1);
                    }
                } else {
                    double rs = num.getResult().get(0);  //AUC for empirical: note AUC method returns two results, hence index
                    double rsn = num.getResult().get(1); //AUC for binormal: note AUC method returns two results, hence index
                    DoubleMatrix1D refArea = ((DoubleMatrix1DResult)refResult).getResult();
                    double ref = refArea.get(2);  //AUC for empirical of reference: this is the main AUC result index for the reference, not the reference index
                    double refBin = refArea.get(3);  //AUC for binormal of reference: as above
                    //Set the AUC results
                    scores.set(2,rs);
                    scores.set(3,rsn);
                    scores.set(4,ref);
                    scores.set(5,refBin);
                    //Compute empirical skill
                    if(rs!=Metric.NULL_DATA && ref!=Metric.NULL_DATA) {
                        scores.set(0,(rs - ref) / (1.0 - ref));
                    }
                    //Compute binormal skill
                    if(rsn!=Metric.NULL_DATA && refBin!=Metric.NULL_DATA) {
                        scores.set(1,(rsn - refBin) / (1.0 - refBin));
                    }
                    if(rsn!=Metric.NULL_DATA && refBin==Metric.NULL_DATA) {
                        System.err.println("The binormal ROC area was not available "
                                + "for the reference forecast at threshold "+getThreshold()+" and will be missing from the "
                                + "skill results.");
                    }
                }
                //Replace any NaN with nV
                int rows = scores.getRowCount();
                for(int i = 0; i < rows; i++) {
                    double test = scores.get(i);
                    if(Double.isNaN(test) || Double.isInfinite(test)) {
                        scores.set(i,Metric.NULL_DATA);
                    }
                }
            }
        } catch (Exception e) {
            //Make sure results are null as these are checked elsewhere
            result[0] = null;
            result[1] = null;
            //e.printStackTrace();
        }
        return result;
    }     

    /**
     * Sets the threshold for the current metric.
     *
     * @param threshold the threshold
     */

    public final void setThreshold(DoubleProcedureParameter threshold) {
        pars[0] = (DoubleProcedureParameter)threshold.deepCopy();
    }

    /**
     * Sets the forecast statistic to be applied to paired input that comprise
     * multiple forecasts at a single time (events.g. ensemble forecast input).
     *
     * @param forecastStat the forecast statistic
     */

    public final void setForecastStatistic(VectorFunction forecastStat) {
        if(forecastStat == null) {
            throw new IllegalArgumentException("Cannot use a null forecast statistic.");
        }
        this.forecastStat = forecastStat;
    }

    /**
     * Sets the bootstrap parameter associated with the verification metric or
     * clears the parameter if the input is null;
     *
     * @param bs the bootstrap parameter
     */
    @Override
    public final void setBootstrapPar(BootstrapParameter bs) {
        if(bs==null) {
            throw new IllegalArgumentException("The bootstrap parameter for metric '"+this+"' cannot be null.");
        } else {
            pars[8] = (BootstrapParameter)bs.deepCopy();
        }
    }

    /**
     * Sets the bootstrap parameter to BootstrapableMetric.NO_BOOTSTRAP and clears
     * all associated parameter values.
     */
    @Override
    public final void clearBootstrapPar() {
        getBootstrapPar().clear();
    }

    /**
     * Returns the ROC area from the input data.  The input should comprise one
     * column of observations (at index 0) and the remaining n columns should comprise
     * the n ensemble members (index 1 through n).
     *
     * @param data the input data
     * @param pro the threshold with values in real units
     * @param nV the null value
     * @return the ROC area
     */

    public final MetricResult getAUC(DoubleMatrix2D data, DoubleProcedure pro, double nV) throws MetricCalculationException {
        //Determine the threshold value for the given probability threshold
        double[] obs = ((DoubleMatrix1D) data.getColumnAt(0)).toArray();
        double[][] forecasts = ((DoubleMatrix2D) data.getSubmatrixByColumn(1, data.getColumnCount() - 1)).toArray();

        int length = obs.length;
        boolean binormal = getFitted();

        //Forecast probabilities when event did occur
        Vector<Double> probWhenObsYes = new Vector();
        //Forecast probabilities when event did not occur
        Vector<Double> probWhenObsNo = new Vector();
        int obsTotal = 0;
        int obsNotTotal = 0;
        for (int i = 0; i < length; i++) {
            if (obs[i] != nV) {
                //Event occurred according to observation
                if (pro.apply(obs[i])) {
                    //Count the number of forecast members that meet the criterion
                    double num = 0.0;
                    double den = 0.0;
                    for (int j = 0; j < forecasts[i].length; j++) {
                        if (forecasts[i][j] != nV) {
                            if (pro.apply(forecasts[i][j])) {
                                num++;
                            }
                            den++;
                        }
                    }
                    if (den != 0) {
                        //Store the probability
                        probWhenObsYes.add(num / den);
                        obsTotal++;
                    }
                } //Event did not occur according to observation
                else {
                    //Count the number of forecast members that meet the criterion
                    double num = 0.0;
                    double den = 0.0;
                    for (int j = 0; j < forecasts[i].length; j++) {
                        if (forecasts[i][j] != nV) {
                            if (pro.apply(forecasts[i][j])) {
                                num++;
                            }
                            den++;
                        }
                    }
                    if (den != 0) {
                        //Store the probability
                        probWhenObsNo.add(num / den);
                        obsNotTotal++;
                    }
                }
            }
        }
        
        int minCount = ((MinimumSampleSizeParameter)pars[7]).getParVal();
        int testRows = Math.min(obsTotal,obsNotTotal);
        String occStatus = "occurrences";
        if(obsNotTotal<obsTotal) {
            occStatus = "non-occurrences";
        }
        lastCount = obsNotTotal+obsTotal;
        if(testRows < minCount) {
            throw new MetricCalculationException("Could not compute the ROC score: fewer "+occStatus+" than required ["+testRows+","+minCount+"].");
        }        

        //Sort the forecast probabilities from largest to smallest
        Collections.sort(probWhenObsYes);
        Collections.sort(probWhenObsNo);
        Collections.reverse(probWhenObsYes);
        Collections.reverse(probWhenObsNo);

        double area = Metric.NULL_DATA;
        int s1 = probWhenObsYes.size();
        int s2 = probWhenObsNo.size();
        double[][] dat = null; //ROC data

        //Number of points in the empirical ROC curve
        int count = ((ROCScorePointsParameter) pars[1]).getParVal();

        //Compute the empirical ROC area with a given method
        int method = getROCScoreMethodPar().getParVal();
        if (method == ROCScoreMethodParameter.MASON_GRAHAM) {
            double events = probWhenObsYes.size();  //Number of events
            double nonEvents = probWhenObsNo.size();  //Number of non-events
            //Determine rhs of eqn. (10) in Mason and Graham (2002)
            double rhs = 0;

            for (int i = 0; i < s1; i++) {
                //For each "hit" (p[obs]=1), determine the number of "misses" with greater, and greater
                //or equal, forecast probability
                double prob = probWhenObsYes.get(i);
                double msGt = 0;  //Number of misses with greater than forecast prob
                double msGtE = 0; //Number of misses with greater or equal than forecast prob
                for (int j = 0; j < s2; j++) {
                    if (probWhenObsNo.get(j) > prob) {
                        msGt += 1.0;
                        msGtE += 1.0;
                    } else if (probWhenObsNo.get(j) == prob) {
                        msGtE += 1.0;
                    } else {
                        break;  //Sorted data, so no more elements
                    }
                }
                rhs += (msGt + msGtE);
            }
            area = 1.0 - ((1.0 / (2.0 * events * nonEvents)) * rhs);
        } else if(method == ROCScoreMethodParameter.TRAPEZOID) {
            dat = ROCUtilities.getEmpiricalROC(probWhenObsYes,probWhenObsNo,count);
            //Integrate using the trapezoid rule
            area = Mathematics.trapIntegrate(dat);
        } else {
            throw new MetricCalculationException("Unrecognized method identifier "
                    + "for computing the ROC Score.");
        }

        //Binormal approximation too?  Use the same approach used for the ROC diagram.
        double normal_area = Metric.NULL_DATA;
        if (binormal) {
            try {
                //Compute empirical ROC curve if not done already
                if(dat==null) {
                    dat = ROCUtilities.getEmpiricalROC(probWhenObsYes,probWhenObsNo,count);
                }
                int tot = 0;
                for (int i = 0; i < count; i++) {
                    //Compute normal quantile of value pairs (0<p<1 && 0<q<1)
                    if (dat[0][i] != 0 && dat[0][i] != 1 && dat[1][i] != 0 && dat[1][i] != 1) {
                        dat[0][tot] = Mathematics.normalInverse(dat[0][i]);
                        dat[1][tot] = Mathematics.normalInverse(dat[1][i]);
                        tot++;
                    }
                }
                //Some pairs not used
                if (tot != dat[0].length) {
                    double[][] nD = new double[2][tot];
                    System.arraycopy(dat[0], 0, nD[0], 0, tot);
                    System.arraycopy(dat[1], 0, nD[1], 0, tot);
                    dat = nD;
                }
                dat = new DenseDoubleMatrix2D(dat).transpose().toArray();
                double[] c = Regression.getOLSRegression(dat);
                normal_area = Mathematics.normal(c[0] / (1 + Math.pow(c[1], 2)));  //AUC
            } catch (Exception e) {
                //Do nothing
                //System.out.println("Unable to fit bi-normal ROC to data: returning empirical ROC score only.");
                //e.printStackTrace();
            }
        }
        double[] rm = new double[]{area,normal_area};
        return new DoubleMatrix1DResult(new DenseDoubleMatrix1D(rm));
    }

    /**
     * Returns the ROC area from the input data.  The input should comprise one
     * column of observations (at index 0) and the remaining n columns should comprise
     * the n ensemble members (index 1 through n).
     *
     * @param data the input data
     * @param pro the threshold with values in real units
     * @param nV the null data value
     * @return the ROC area
     * @deprecated
     */

    public final MetricResult getAUCOld(DoubleMatrix2D data, DoubleProcedure pro, double nV) throws MetricCalculationException {
        //Determine the threshold value for the given probability threshold
        double[] obs = ((DoubleMatrix1D) data.getColumnAt(0)).toArray();
        double[][] forecasts = ((DoubleMatrix2D) data.getSubmatrixByColumn(1, data.getColumnCount() - 1)).toArray();

        int length = obs.length;
        boolean binormal = getFitted();

        //Forecast probabilities when event did occur
        Vector<Double> probWhenObsYes = new Vector();
        //Forecast probabilities when event did not occur
        Vector<Double> probWhenObsNo = new Vector();
        int obsTotal = 0;
        int obsNotTotal = 0;
        for (int i = 0; i < length; i++) {
            if (obs[i] != nV) {
                //Event occurred according to observation
                if (pro.apply(obs[i])) {
                    //Count the number of forecast members that meet the criterion
                    double num = 0.0;
                    double den = 0.0;
                    for (int j = 0; j < forecasts[i].length; j++) {
                        if (forecasts[i][j] != nV) {
                            if (pro.apply(forecasts[i][j])) {
                                num++;
                            }
                            den++;
                        }
                    }
                    if (den != 0) {
                        //Store the probability
                        probWhenObsYes.add(num / den);
                        obsTotal++;
                    }
                } //Event did not occur according to observation
                else {
                    //Count the number of forecast members that meet the criterion
                    double num = 0.0;
                    double den = 0.0;
                    for (int j = 0; j < forecasts[i].length; j++) {
                        if (forecasts[i][j] != nV) {
                            if (pro.apply(forecasts[i][j])) {
                                num++;
                            }
                            den++;
                        }
                    }
                    if (den != 0) {
                        //Store the probability
                        probWhenObsNo.add(num / den);
                        obsNotTotal++;
                    }
                }
            }
        }

        if (obsTotal != 0 && obsNotTotal != 0) {
            lastCount=obsTotal + obsNotTotal;
        }

        if (probWhenObsYes.size() == 0 || probWhenObsNo.size() == 0) {
            lastCount = ZERO_SAMPLES;
            throw new MetricCalculationException("Could not compute the ROC score for the specified input.");
        }

        //Sort the forecast probabilities from largest to smallest
        Collections.sort(probWhenObsYes);
        Collections.sort(probWhenObsNo);
        Collections.reverse(probWhenObsYes);
        Collections.reverse(probWhenObsNo);

        double events = probWhenObsYes.size();  //Number of events
        double nonEvents = probWhenObsNo.size();  //Number of non-events
        //Determine rhs of eqn. (10) in Mason and Graham (2002)
        double rhs = 0;
        int s1 = probWhenObsYes.size();
        int s2 = probWhenObsNo.size();

        for (int i = 0; i < s1; i++) {
            //For each "hit" (p[obs]=1), determine the number of "misses" with greater, and greater
            //or equal, forecast probability
            double prob = probWhenObsYes.get(i);
            double msGt = 0;  //Number of misses with greater than forecast prob
            double msGtE = 0; //Number of misses with greater or equal than forecast prob
            for (int j = 0; j < s2; j++) {
                if (probWhenObsNo.get(j) > prob) {
                    msGt += 1.0;
                    msGtE += 1.0;
                } else if(probWhenObsNo.get(j) == prob) {
                    msGtE += 1.0;
                } else {
                    break;  //Sorted data, so no more elements
                }
            }
            rhs+=(msGt+msGtE);
        }
        double area = 1.0 - ((1.0/(2.0*events*nonEvents))*rhs);

        //Binormal approximation too?  Use the same approach used for the ROC diagram.
        double normal_area = Metric.NULL_DATA;
        if (binormal) {
            try {
                //Number of points to include for the binormal approximation: N + 1 where N = member count
                //Convention is to use as many points as members, but some control is allowed here
                //for consistency with the ROC curve
                //int count =  forecasts[0].length;
                int count = ((ROCScorePointsParameter) pars[1]).getParVal();
                count = count + 1; //Number of points aside from the origin
                double[][] dat = new double[2][count];  //Data for the binormal approximation
                double[] pThresh2 = new double[count];
                for (int i = 0; i < count; i++) {
                    pThresh2[i] = 1.0 - (i * (1.0 / (count - 1.0)));  //Prob thresholds in descending size
                }
                //Determine the POD and POFD
                dat[0][dat[0].length - 1] = 1.0;
                dat[1][dat[1].length - 1] = 1.0;
                int stop = count -1;
                int tot = 0;
                for (int i = 0; i < stop; i++) {
                    //Determine the POFD and place in the first row
                    for (int j = 0; j < s2; j++) {
                        if (probWhenObsNo.get(j) >= pThresh2[i]) {  //Forecast prob is >= ROC thresh
                            dat[0][i] += 1.0;
                        } else {
                            break;  //Sorted data, so no more elements
                        }
                    }
                    dat[0][i] = dat[0][i] / s2;
                    //Determine POD and place in the second row
                    for (int j = 0; j < s1; j++) {
                        if (probWhenObsYes.get(j) >= pThresh2[i]) {  //Forecast prob is >= ROC thresh
                            dat[1][i] += 1.0;
                        } else {
                            break;  //Sorted data, so no more elements
                        }
                    }
                    dat[1][i] = dat[1][i] / s1;
                    //Compute normal quantile of value pairs (0<p<1 && 0<q<1)
                    if (dat[0][i] != 0 && dat[0][i] != 1 && dat[1][i] != 0 && dat[1][i] != 1) {
                        dat[0][tot] = Mathematics.normalInverse(dat[0][i]);
                        dat[1][tot] = Mathematics.normalInverse(dat[1][i]);
                        tot++;
                    }
                }
                //Some pairs not used
                if (tot != dat[0].length) {
                    double[][] nD = new double[2][tot];
                    System.arraycopy(dat[0], 0, nD[0], 0, tot);
                    System.arraycopy(dat[1], 0, nD[1], 0, tot);
                    dat = nD;
                }
                dat = new DenseDoubleMatrix2D(dat).transpose().toArray();
                double[] c = Regression.getOLSRegression(dat);
                normal_area = Mathematics.normal(c[0] / (1 + Math.pow(c[1], 2)));  //AUC
            } catch (Exception e) {
                //Do nothing
                //System.out.println("Unable to fit bi-normal ROC to data: returning empirical ROC score only.");
                //e.printStackTrace();
            }
        }
        double[] rm = new double[]{area,normal_area};
        return new DoubleMatrix1DResult(new DenseDoubleMatrix1D(rm));
    }

    /*******************************************************************************
     *                                                                             *
     *                                  TEST METHOD                                *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Test method.
     *
     * @param args the args
     */
    
    public static void main(String[] args) {    
        //Test using the data from Mason and Graham (2000)
        //Area should be 0.875 and score, 0.75
//        double[] obs = new double[] {
//            1,
//            1,
//            1,
//            0,
//            1,
//            1,
//            1,
//            0,
//            0,
//            0,
//            1,
//            0,
//            0,
//            0,
//            0};
//        
//        double[] forc = new double[] {
//            0.984,
//            0.952,
//            0.944,
//            0.928,
//            0.832,
//            0.816,
//            0.584,
//            0.576,
//            0.28,
//            0.136,
//            0.032,
//            0.024,
//            0.016,
//            0.008,
//            0};
//        
//        Vector<Double> probWhenObsYes = new Vector();
//        Vector<Double> probWhenObsNo = new Vector();
//        
//        probWhenObsYes.add(forc[0]);
//        probWhenObsYes.add(forc[1]);
//        probWhenObsYes.add(forc[2]);
//        probWhenObsYes.add(forc[4]);
//        probWhenObsYes.add(forc[5]);
//        probWhenObsYes.add(forc[6]);
//        probWhenObsYes.add(forc[10]);
//        
//        probWhenObsNo.add(forc[3]);
//        probWhenObsNo.add(forc[7]);
//        probWhenObsNo.add(forc[8]);
//        probWhenObsNo.add(forc[9]);
//        probWhenObsNo.add(forc[11]);
//        probWhenObsNo.add(forc[12]);
//        probWhenObsNo.add(forc[13]);    
//        probWhenObsNo.add(forc[14]);  
//        
//        /*
//         * CODE COPIED FROM LAST PART OF ROC CALCULATION ONCE THE SORTED 
//         * PROBABILITIES ARE KNOWN FOR EACH CASE OBS OCCURRED AND DID NOT.
//         * 
//         */
//        
//        //Sort the forecast probabilities from largest to smallest 
//        Collections.sort(probWhenObsYes);
//        Collections.sort(probWhenObsNo);
//        Collections.reverse(probWhenObsYes);
//        Collections.reverse(probWhenObsNo);    
//        
//        double events = probWhenObsYes.size();  //Number of events
//        double nonEvents = probWhenObsNo.size();  //Number of non-events
//        //Determine rhs of eqn. (10) in Mason and Graham (2002)
//        double rhs = 0;
//        int s1 = probWhenObsYes.size(); 
//        int s2 = probWhenObsNo.size(); 
//        for (int i = 0; i < s1; i++) {
//            //For each "hit" (p[obs]=1), determine the number of "misses" with greater, and greater 
//            //or equal, forecast probability
//            double prob = probWhenObsYes.get(i);
//            double msGt = 0;  //Number of misses with greater than forecast prob
//            double msGtE = 0; //Number of misses with greater or equal than forecast prob
//            for (int j = 0; j < s2; j++) {
//                if (probWhenObsNo.get(j) > prob) {
//                    msGt += 1.0;
//                    msGtE += 1.0;
//                } else if(probWhenObsNo.get(j) == prob) {
//                    msGtE += 1.0;
//                } else {
//                    break;  //Sorted data, so no more elements
//                }
//            }
//            rhs+=(msGt+msGtE);
//        }
//        double area = 1.0 - ((1.0/(2.0*events*nonEvents))*rhs);
//
//        double score = (2*area)-1.0;      
//        
//        System.out.println(area);
//        System.out.println(score);

    }    
    
//        for (int i = 0; i < count; i++) {
//            //Determine the number of hits and misses at ith point in diagram
//            double hi = 0; 
//            for (int j = 0; j < s1; j++) {
//                if (probWhenObsYes.get(j) > pThresh2[i]) {  //Forecast prob is > ROC thresh
//                    hi += 1.0;
//                } else {
//                    break;  //Sorted data, so no more elements
//                }
//            }
//            //Determine number of false alarms with higher forecast probability
//            //than segment i and the number of false alarms with equal or higher
//            //probability than segment i
//            double msGt = 0;  //Number of false alarms with higher forecast probability than segment i
//            double msGtE = 0; //Number of false alarms with equal or higher forecast probability than segment i
//            for (int j = 0; j < s2; j++) {
//                if (probWhenObsNo.get(j) > pThresh2[i]) {  //Forecast prob is > ROC thresh
//                    msGt += 1.0;
//                    msGtE += 1.0;
//                } else if(probWhenObsNo.get(j) == pThresh2[i]) { //Forecast prob is = to ROC thresh
//                    msGtE += 1.0;
//                } else {
//                    break;  //Sorted data, so no more elements
//                }
//            }
//            rhs+=(hi*(msGt+msGtE))-last;
//            last = (hi*(msGt+msGtE));
//        }
//        double area = 1.0 - ((1.0/(2.0*events*nonEvents))*rhs);
//        
//        double score = (2*area)-1.0;
//        return new DoubleResult(score);       
     
    
}
    