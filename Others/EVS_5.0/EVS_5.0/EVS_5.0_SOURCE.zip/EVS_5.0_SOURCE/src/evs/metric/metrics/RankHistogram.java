package evs.metric.metrics;

//EVS dependencies
import evs.data.*;
import evs.metric.parameters.*;
import evs.metric.results.*;
import evs.utilities.*;
import evs.utilities.matrix.*;
import evs.utilities.mathutil.*;


//Java util dependencies
import java.util.*;

/**
 * The rank histogram is similar to the spread-bias diagram where the intervals 
 * correspond to the ranked ensemble members. Hence, the probability that the 
 * observation falls between any two members is (approximately) uniform in the 
 * case of a reliable ensemble.
 *
 * @author evs@hydrosolved.com
 * @version 1.0
 */

public class RankHistogram extends DiagramMetric implements EnsembleMetric, 
        ThresholdMetric, BootstrapableMetric {

    /********************************************************************************
     *                                                                              *
     *                                CONSTRUCTOR                                   *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Attempts to construct a rank histogram with associated parameters.
     * 
     * @param sample indicates whether to use absolute or relative frequencies
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use 
     * conditional pairs when available
     * @param minS the minimum sample size
     * @param bs the bootstrap parameter
     */
    
    public RankHistogram(RankHistSampleParameter sample, ForecastTypeParameter 
            fType,UnconditionalParameter unconditional,MinimumSampleSizeParameter minS,
            BootstrapParameter bs) {
        //Set the name
        name = "Rank histogram";
        //Specify an all-inclusive threshold condition
        ProbabilityIdentifierParameter p = new ProbabilityIdentifierParameter(false);
        DoubleParameter[] dubs = new DoubleParameter[]{new DoubleParameter(Double.NEGATIVE_INFINITY)};
        IntegerParameter p2 = new IntegerParameter(DoubleProcedureParameter.GREATER_THAN);
        //Set the parameters
        setParameters(new MetricParameter[]{new DoubleProcedureParameter(p2,dubs,p,
                new BooleanParameter(true)),sample.deepCopy(),fType.deepCopy(),
                unconditional.deepCopy(),minS.deepCopy(),bs.deepCopy()});
        //Set the link to html description of the metric
        descriptionURL = getClass().getResource(EVSConstants.STATS_EXPLAINED_DIR + "rankhist.htm");       
    } 
    
    /**
     * Attempts to construct a rank histogram with associated parameters.
     *
     * @param threshold the threshold condition
     * @param sample indicates whether to use absolute or relative frequencies
     * @param fType the forecast types
     * @param unconditional is true to always use unconditional pairs, false to use 
     * conditional pairs when available
     * @param minS the minimum sample size
     * @param bs the bootstrap parameter
     */
    
    public RankHistogram(DoubleProcedureParameter threshold, RankHistSampleParameter sample,
            ForecastTypeParameter fType, UnconditionalParameter unconditional,MinimumSampleSizeParameter minS,
            BootstrapParameter bs) {
        this(sample,fType,unconditional,minS,bs);
        pars[0]=threshold;
    }    
          
     /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/        
    
    /**
     * Returns the metric identifier.
     *
     * @return an identifier
     */
    
    public int getID() {
        return RANK_HISTOGRAM; 
    }        
    
    /**
     * Returns the result type associated with the metric.  See the 
     * evs.metric.MetricResult class for supported types.
     *
     * @return an identifier
     */
    
    public int getResultID() {
        return MetricResult.DOUBLE_MATRIX_2D_RESULT;
    }         
    
    /**
     * Returns true if the metric is defined in real units of the forecast
     * and observed variable, false otherwise.
     * 
     * @return true if the metric is defined in real units
     */    

    public boolean hasRealUnits() {
        return false;
    }       
    
    /**
     * Returns the threshold associated with this threshold diagram.
     *
     * @return the threshold
     */
    
    public DoubleProcedureParameter getThreshold() {
        return (DoubleProcedureParameter)pars[0].deepCopy();
    }     
    
    /**
     * Returns a deep copy of the current metric, where all instance variables 
     * occupy independent positions in memory from the current metric.  
     *
     * @return a deep copy of the current object 
     */
    
    public Metric deepCopy() {
        RankHistogram returnMe = new RankHistogram(
                (DoubleProcedureParameter)pars[0].deepCopy(),
                (RankHistSampleParameter)pars[1].deepCopy(),
                (ForecastTypeParameter)pars[2].deepCopy(),
                (UnconditionalParameter)pars[3].deepCopy(),
                (MinimumSampleSizeParameter)pars[4].deepCopy(),
                getBootstrapPar());
        deepCopyResults(returnMe);
        return returnMe;
    }     

    /**
     * Returns the bootstrap parameter associated with the verification metric.
     *
     * @return the bootstrap parameter
     */
    @Override
    public BootstrapParameter getBootstrapPar() {
        return (BootstrapParameter)pars[5].deepCopy();
    }
    
    /**
     * Returns true if using relative frequencies, false for absolute frequencies.
     * 
     * @return true if using relative frequencies, false for absolute frequencies
     */
    
    public boolean isRelativeFreq() {
        return ((RankHistSampleParameter)pars[1]).getParVal();
    }
    
    /**
     * Returns a metric with default parameter values.  
     *
     * @return a metric with default parameter values.
     */
    
    public static Metric getDefaultMetric() { 
        ForecastTypeParameter type = new ForecastTypeParameter(new int[]{ForecastTypeParameter.REGULAR_FORECAST});
        return new RankHistogram(new RankHistSampleParameter(true),type,
                new UnconditionalParameter(false),new MinimumSampleSizeParameter(),new BootstrapParameter());
    }    
    
    /********************************************************************************
     *                                                                              *
     *                                MUTATOR METHODS                               *
     *                                                                              *
     *******************************************************************************/        
    
    /**
     * Uses the specified paired data to compute and return the result of the metric.
     * The metric results are returned, together with the sample counts, but not stored 
     * locally.  The metric result is located in the first index of the return array
     * and the sample counts are located in the second index. Optionally, specify
     * the results of a reference forecast from which to compute skill if the 
     * metric is a skill score. 
     * 
     * @param forecastType the forecast type
     * @param paired the paired data
     * @param refResult the results for a reference forecast (may be null)
     * @return the metric result and sample counts
     */
    
    public MetricResult[] compute(int forecastType, PairedData paired, MetricResult refResult) throws MetricCalculationException {
        if(paired==null) {
            throw new MetricCalculationException("Error computing metric '"+getName()+"': input pairs were null.");
        }
        ForecastTypeParameter.isSupportedForecastType(forecastType,true);
        MetricResult[] res = new MetricResult[2];
        DoubleProcedure pro = getThreshold().getParValReal();
        DoubleMatrix2D p = paired.getPairs();
        double nV = paired.getNullValue();
        p = getConditionalPairs(pro, p);
        res[0] = getRankHistogram((DoubleMatrix2D) p.getSubmatrixByColumn(2, p.getColumnCount() - 1), nV);
        res[1] = new IntegerResult(lastCount);
        return res; 
    }      
    
    /**
     * Sets the threshold for the current metric.    
     *
     * @param threshold the threshold
     */
    
    public void setThreshold(DoubleProcedureParameter threshold) {
        pars[0] = (DoubleProcedureParameter)threshold.deepCopy();
    }      

    /**
     * Sets the bootstrap parameter associated with the verification metric or
     * clears the parameter if the input is null;
     *
     * @param bs the bootstrap parameter
     */
    @Override
    public void setBootstrapPar(BootstrapParameter bs) {
        if(bs==null) {
            throw new IllegalArgumentException("The bootstrap parameter for metric '"+this+"' cannot be null.");
        } else {
            pars[5] = (BootstrapParameter)bs.deepCopy();
        }
    }

    /**
     * Sets the bootstrap parameter to BootstrapableMetric.NO_BOOTSTRAP and clears
     * all associated parameter values.
     */
    @Override
    public void clearBootstrapPar() {
        ((BootstrapParameter)pars[5]).clear();
    }

    /**
     * Returns the rank histogram from an input dataset.  The input should comprise 
     * one column of observations (at index 0) and the remaining n columns should 
     * comprise the n ensemble members (index 1 through n). Any rows with fewer
     * than n ensemble members or null members are eliminated prior to computation.
     * The result comprises the ordered positions (first row) and the relative 
     * fraction of observations falling between them, which may be interpreted
     * as a probability.
     * 
     * Tied ranks are handled by randomly choosing one of the tied positions.
     *
     * @param data the input data
     * @param nV the null value
     * @return the rank histogram
     */
    
    public MetricResult getRankHistogram(DoubleMatrix2D data, double nV) {      
        double actualRows = 0;
        DoubleMatrix2D stripped = null;
        try {
             stripped = PairedData.getStrippedPairs(data,false,nV,0);
             actualRows = stripped.getRowCount();
        } catch(Exception e) {
           //Do nothing
        }

        int minCount = ((MinimumSampleSizeParameter)pars[4]).getParVal();
        lastCount = (int)actualRows;
        if(actualRows < minCount) {
            throw new MetricCalculationException("Could not compute the rank histogram: fewer samples than required ["+actualRows+","+minCount+"].");
        }   
        
        int memberCount = stripped.getColumnCount()-1;
        int bins = memberCount+1;
        double[][] computeMe = new double[2][bins];
        //Set the rank positions (n+1)
        for(int i = 0; i < bins; i++) {
            computeMe[0][i]=i+1;
        }
        
        double[][] forecasts = ((DoubleMatrix2D)data.getSubmatrixByColumn(1,memberCount)).toArray();
        int fCount = forecasts.length;        
        
        //Iterate through the forecast times
        for(int i = 0; i < fCount; i++) {
            //Determine the probability of the observation within the forecast distribution
            double obs = data.get(i,0);
            if(obs != nV) {
                double[] copy = new double[memberCount];
                System.arraycopy(forecasts[i], 0, copy, 0, copy.length);
                //Get the rank position, handling ties
                int rank = getRankHandleTies(obs,copy,true);
                computeMe[1][rank]+=1;
            }
        }
        
        //Convert to probabilities if required
        if (isRelativeFreq()) {
            for (int i = 0; i < bins; i++) {
                computeMe[1][i] = computeMe[1][i] / actualRows;
            }
        }
        return new DoubleMatrix2DResult(new DenseDoubleMatrix2D(computeMe));
    }
    
    /**
     * Returns the zero-based rank position of an observation within an array, handling ties 
     * as needed by randomly assigning one of the tied positions. 
     * 
     * @param obs the observation
     * @param check the array
     * @param sort is true to sort the input array, false if already sorted
     * @return the zero-based rank
     */
    
    public static int getRankHandleTies(double obs, double[] check, boolean sort) {
        if(sort) {
            Arrays.sort(check);
        }
        Random r = new Random();
        //OOB low
        if(obs < check[0]) {
            return 0;
        } 
        //OOB high
        else if(obs > check[check.length-1]) {
            return check.length;
        } 
        //Inside
        else {
            for (int k = 0; k < check.length; k++) {
                if (obs <= check[k]) {
                    if (k < (check.length - 1) && check[k] < check[k + 1]) {
                        return k;
                    } else {
                        int startRank = k;
                        int endRank = k;
                        for (int j = k + 1; j < check.length; j++) {
                            if (check[k] == check[j]) {
                                endRank += 1;
                            } else {
                                break;
                            }
                        }
                        if (startRank == endRank) {
                            return startRank;
                        }
                        int adj = endRank - startRank;
                        //Return random rank between start and end
                        return r.nextInt(adj + 1) + startRank;
                    }
                }
            }
            return check.length;
        }
    }
    
    /*******************************************************************************
     *                                                                             *
     *                                  TEST METHOD                                *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Test method.
     *
     * @param args the args
     */
    
    public static void main(String[] args) {    

//        double[] d = new double[]{1,2,3,4,5,6};
//        double obs = 1.0;
//        System.out.println(getRankHandleTies(obs,d,true));
//        
//        
        
//        Probability of a uniform RN falling within a uniform ensemble is 
//        approximately uniform
        int forecasts = 1000000;
        int members = 10;
        int bins = members+1;
        double[][] data = new double[forecasts][bins];
        for(int i = 0; i < forecasts; i++) {
            data[i][0] = Math.random();
            for(int j = 1; j < bins; j++) {
                data[i][j] = Math.random();
            }
        }
        
        DoubleMatrix2D d = new DenseDoubleMatrix2D(data);

        RankHistogram r = new RankHistogram(new RankHistSampleParameter(true),new ForecastTypeParameter(ForecastTypeParameter.REGULAR_FORECAST),
                new UnconditionalParameter(false),
                new MinimumSampleSizeParameter(),new BootstrapParameter());
        double nV = -999.0;
        MetricResult rs = r.getRankHistogram(d,nV);
        
        DoubleMatrix2D expected = new DenseDoubleMatrix2D(2,bins);
        for(int i = 0; i < bins; i++) {
            expected.set(0,i,i+1);
            expected.set(1,i,1.0/bins);
        }
        
        System.out.println("Expected result: ");
        System.out.println(expected);
        System.out.println("Actual result (with sampling uncertainty): ");
        System.out.println(((DoubleMatrix2DResult)rs).getResult());
    }     
    
}
