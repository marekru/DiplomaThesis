package evs.analysisunits;

//Java util dependencies
import java.util.*;
import java.util.concurrent.*;

//EVS dependencies
import evs.data.*;
import evs.metric.parameters.*;
import evs.metric.metrics.*;
import evs.metric.results.*;
import evs.utilities.progress.*;

/**
 * Class to support parallel execution of bootstrap samples for verification metrics.
 * This may be extended to skill metrics in future, if a significant number of
 * additional skill metrics are added.
 *
 * @author evs@hydrosolved.com
 */
public class Bootstrap implements Callable<TreeMap<Metric,MetricResult>> {

    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLES                              *
     *                                                                              *
     *******************************************************************************/

    /**
     * Paired data indexed by forecast type.
     */

    private TreeMap<Integer, PairedData[]> bsInput = null;

    /**
     * The metrics to bootstrap.
     */

    private Metric[] metrics = null;

    /**
     * Is true for a spatially dependent bootstrap, false otherwise.
     */

    private boolean spatialDep = false;

    /**
     * Is true to skip all checks of inputs (e.g. after first sample)
     */

    private boolean skipCheck = false;

    /**
     * A progress monitor.
     */

    private ProgressMonitor monitor = null;
    
    /*******************************************************************************
     *                                                                             *
     *                                CONSTRUCTOR                                  *
     *                                                                             *
     ******************************************************************************/

    /**
     * Construct a bootstrap sample object.  The input metrics are deep copied.
     *
     * @param bsInput paired data indexed by forecast type
     * @param metrics the metrics to bootstrap
     * @param spatialDep is true for perfect spatial dependence, false for independence
     * @param skipCheck is true to skip all checks of inputs (e.g. after first sample)
     * @param monitor a progress monitor to update with progress
     */

    public Bootstrap(TreeMap<Integer, PairedData[]> bsInput, Metric[] metrics,
            boolean spatialDep, boolean skipCheck,
            ProgressMonitor monitor) {
        if(bsInput==null || bsInput.size()==0) {
            throw new IllegalArgumentException("Valid paired data are required to "
                    + "perform a bootstrap.");
        }
        if(metrics == null || metrics.length == 0) {
            throw new IllegalArgumentException("One or more metrics are required to perform a bootstrap.");
        }
        this.metrics = new Metric[metrics.length];
        for(int i = 0; i < metrics.length; i++) {
            if(!metrics[i].isBootstrap()) {
                throw new IllegalArgumentException("Cannot bootstrap metric '"+metrics[i]+"'.");
            }
            this.metrics[i]=metrics[i];
        }
        this.bsInput = bsInput;
        this.spatialDep = spatialDep;
        this.skipCheck = skipCheck;
        this.monitor = monitor;
    }

    /**
     * Computes a bootstrap result.  Throws a stopped exception if the process
     * is stopped during execution.
     *
     * @return a map of metric results indexed by unique metric identifier
     */

    public TreeMap<Metric,MetricResult> call() throws ProgressStoppedException {
        //Bootstrap parameters are constant for the purposes of deriving a single
        //bootstrap sample
        BootstrapParameter bp = null;
            if (metrics[0] instanceof BootstrapableMetric) {
                bp = ((BootstrapableMetric) metrics[0]).getBootstrapPar();
            } else {
                bp = ((BootstrapableMetric) ((ThresholdMetricStore) metrics[0]).
                        getFirstMetricInStore()).getBootstrapPar();
            }
        TreeMap<Integer, PairedData[]> bsOutput =
                PairedData.getBootstrapSample(bsInput, bp, false, skipCheck);
        PairedData[] pairs = bsOutput.get(ForecastTypeParameter.REGULAR_FORECAST);
        PairedData finalPairs = null;
        //Pool pairs if required. Note - spatial dependence is accounted for when
        //requesting the bootstrap sample for multiple locations (i.e. multiple paired datasets).
        if(pairs.length==1) {
            finalPairs = pairs[0];
        } else {
            finalPairs = PairedData.getPooledPairs(pairs, false);
        }

        TreeMap<Metric,MetricResult> result = new TreeMap<Metric,MetricResult>();
        for (int j = 0; j < metrics.length; j++) {
            Metric me = metrics[j];
            MetricResultByLeadTime res = me.computeByLeadTime(
                    ForecastTypeParameter.REGULAR_FORECAST,finalPairs,null,true);
            result.put(me,res);
            monitor.increment();  //Increment has been set in monitor
            if(monitor.isStopped()) {
                throw new ProgressStoppedException("Bootstrap terminated.");
            }
        }
        return result;
    }


}
