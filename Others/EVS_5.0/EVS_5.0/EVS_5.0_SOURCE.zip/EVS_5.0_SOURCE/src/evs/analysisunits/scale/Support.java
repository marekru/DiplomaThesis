package evs.analysisunits.scale;
import evs.data.fileio.GlobalUnitsReader;
import evs.data.InvalidUnitException;
import evs.utilities.mathutil.FunctionLibrary;
import evs.utilities.mathutil.Function;

/**
 * A class that defines the support of a variable, including the units in which
 * it is measured and associated scale information.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public abstract class Support {

/*******************************************************************************
 *                                                                             *
 *                               CLASS VARIABLES                               *
 *                                                                             *
 ******************************************************************************/      
    
    /**
     * Identifier for the support of observations.
     */
    
    public static final int OBSERVED_SUPPORT = 301;
    
    /**
     * Identifier for support of forecasts.
     */
    
    public static final int FORECAST_SUPPORT = 302;
    
    /**
     * Identifier for support of both forecasts and observations.
     */
    
    public static final int ALL_SUPPORT = 303;
    
/*******************************************************************************
 *                                                                             *
 *                        INSTANCE VARIABLES OF CHILDREN                       *
 *                                                                             *
 ******************************************************************************/      
         
    /**
     * Existing measurement units in US English.
     */

    protected String measurementUnits;

    /**
     * Target measurement units (may be null or the same as measurementUnits) in
     * US English.
     */

    protected String targetUnits;
    
    /**
     * Function to get to the required measurement units.
     */

    protected Function measurementFunc;
    
    /**
     * Additional information associated with the support.
     */
    
    protected String notes;    

/*******************************************************************************
 *                                                                             *
 *                              ACCESSOR METHODS                               *
 *                                                                             *
 ******************************************************************************/     
        
    /**
     * Returns any additional information associated with the support.
     *
     * @return any notes
     */
    
    public String getNotes() {
        return notes;
    }
    
    /**
     * Returns the measurement units
     *
     * @return the measurement units
     */
    
    public String getMeasurementUnits() {
        return measurementUnits;
    }         
    
    /**
     * Returns the function that should be applied to the current units to arrive
     * at the stated units.
     *
     * @return the measurement units function
     */
    
    public Function getTargetMeasurementUnitsFunc() {
        return measurementFunc;
    }

    /**
     * Returns the target measurement units of the support object, following the
     * application of a measurement function.
     *
     * @return the target units
     */

    public String getTargetMeasurementUnits() {
        return targetUnits;
    }

    /**
     * Returns true if target measurement units have been defined.
     *
     * @return true if target units exist
     */

    public boolean hasTargetMeasurementUnits() {
        return targetUnits!=null;
    }
    
    /**
     * Returns true if the original support can be changed to the required support
     * and false otherwise.  Currently returns true if both support objects are 
     * instances of TemporalSupport, the required temporal support is larger 
     * than the existing support, they have the same attribute units and the
     * original support is either instantaneous or both support objects represent
     * totals over their input periods and these periods are exactly divisible.
     *
     * @param origS the original support
     * @param reqS the required support
     * @return true if a change of support is possible, false otherwise
     */
    
    public static boolean canChangeSupport(Support origS, Support reqS) throws IllegalArgumentException {
        //Check that aggregation is possible
        if(!(origS instanceof TemporalSupport && reqS instanceof TemporalSupport)) {
            return false;
        }
        return TemporalSupport.canChangeSupport((TemporalSupport)origS,(TemporalSupport)reqS);
    }        
    
/*******************************************************************************
 *                                                                             *
 *                               MUTATOR METHODS                               *
 *                                                                             *
 ******************************************************************************/     
        
    /**
     * Returns a deep copy of the current object. 
     */
    
    public abstract Support deepCopy();
    
    /**
     * Sets the function that should be applied to the current units to arrive
     * at some new units.
     *
     * @param measurementFunc the attribute units function
     * @param targetUnits the required units
     */
    
    public void setTargetMeasurementUnitsFunc(Function measurementFunc, String targetUnits) throws InvalidUnitException, InvalidSupportException {
        if(measurementFunc==null || targetUnits==null) {
            throw new InvalidSupportException("Specify a non-null attribute function and target units.");
        }
        //Check if non null function is anything other than the identity function in case of no change in units
        if(measurementUnits.equals(targetUnits)) {
            if(measurementFunc!=null) {
                if(!FunctionLibrary.identity.equals(measurementFunc)) {
                    throw new IllegalArgumentException("No change of measurement units from '"+measurementUnits+"'"
                            + " was requested, but a function to change units has been specified, '"+measurementFunc+"',"
                            + " and is not the identity function. Remove or specify the identity function.");
                }
            }
        }        
        //GlobalUnitsReader.isSupportedContinuousNumericalUnit(targetUnits,true);
        this.measurementFunc = measurementFunc;
        this.targetUnits = GlobalUnitsReader.toUSEnglish(targetUnits);
    }

    /**
     * Sets any additional information associated with the support.
     *
     * @param notes further information on support
     */
    
    public void setNotes(String notes) {
        this.notes = notes;
    }           

}