package evs.analysisunits;

//Java util dependencies
import evs.data.DateElement;
import evs.data.DateCondition;
import evs.data.ConditioningException;
import evs.data.Condition;
import evs.data.ValueCondition;
import java.util.*;
import java.util.concurrent.*;

//Java io dependencies
import java.io.*;

//EVS dependencies
import evs.data.fileio.*;
import evs.analysisunits.scale.*;
import evs.metric.metrics.*;
import evs.metric.parameters.*;
import evs.metric.results.*;
import evs.utilities.matrix.*;
import evs.data.*;
import evs.utilities.*;
import evs.utilities.mathutil.*;
import evs.utilities.progress.*;

/**
 * A Verification Unit comprises the location, time and attribute for which
 * verification will be conducted.  A single verification unit stores one location,
 * time-series and attribute.
 *
 * NOTE: it is critical that any change in a verification unit is coordinated with
 * its parent aggregation unit if it exists because aggregation units may only
 * comprise verification units with common properties.  The aggregation units are
 * accessed by calling {@link evs.analysisunits.VerificationUnit#getAggregationUnits()}.
 * The children verification units are accessed by calling
 * {@link evs.analysisunits.AggregationUnit#getVerificationUnits()}.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class VerificationUnit extends AnalysisUnit implements ProgressMonitorInterface {

    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLES                              *
     *                                                                              *
     *******************************************************************************/

    /**
     * Default identifier for integers.
     */
    public static final int DEFAULT_INT_VALUE = -999;    
    /**
     * Number of pairs at the first lead time for the last set of pairs read. This
     * is used by {@link evs.analysisunits.AggregationUnit#computeMetricsByAveraging}
     */
    
    protected int lastPairFirstLeadCount = 0;
    
    /**
     * The location ID.
     */
    private String locationID;
    /**
     * The variable ID.
     */
    private String variableID;
    /**
     * An additional ID to append to the others.
     */
    private String additionalID;
    /**
     * The forecast data source.
     */
    private DataSource forecastData;   
    /**
     * Null value of the unit.
     */
    private double nullValue = -999.0;
    /**
     * The observed data source.
     */
    private DataSource observedData;
    /**
     * First lead time.
     */
    private double firstTime = nullValue;
    /**
     * Last lead time.
     */
    private double lastTime = nullValue;
    /**
     * Verification timestep.
     */
    private int verificationResolution = DEFAULT_INT_VALUE;
    /**
     * Verification timestep units.
     */
    private String verificationResolutionUnits = "";
    /**
     * Forecast lead time units.
     */
    private String leadUnits = "";
    /**
     * Time system for the observations.
     */
    private TimeZone observedTimeSystem = null;
    /**
     * Time system for the forecasts.
     */
    private TimeZone forecastTimeSystem = null;
    /**
     * An array of aggregation units of which this verification unit is a part.
     */
    private ArrayList<AggregationUnit> aggregation = new ArrayList<AggregationUnit>();
    /**
     * Start date of verification period.
     */
    private Calendar start = null;
    /**
     * End date of verification period.
     */
    private Calendar end = null;
    /**
     * A date condition associated with the verification unit.
     */
    private DateCondition dateCondition = null;
    /**
     * One or more value conditions associated with the verification unit.
     */
    private Vector<ValueCondition> valueConditions = new Vector<ValueCondition>();
    /**
     * Support information associated with the forecasts.
     */
    private TemporalSupport forecastSupport = null;
    /**
     * Support information associated with the observations.
     */
    private TemporalSupport observedSupport = null;
    /**
     * Source of paired data.
     */
    private PairedDataSource pairedSource = null;
    /**
     * The function used for temporal aggregation of forecasts and observations.
     * This is a mean by default.
     */
    private VectorFunction tempAggFunc = FunctionLibrary.mean();
    /**
     * Is true to write the conditional pairs to file, false otherwise.
     */
    private boolean writeConditionalPairs = true;
    /**
     * Is true to write the unconditional pairs to file, false otherwise.
     */
    private boolean writeUnconditionalPairs = true;    
    /**
     * Is true to use the full period of observations available, and not only
     * those paired with forecasts.
     */
    private boolean useFullClimatology = false;
    /**
     * Only those lead times with at least the following fraction of the average
     * number of pairs across lead times will be retained for computing results.
     * When a lead time does not meet this fraction, it will be eliminated from
     * the results. The fraction applies after any conditioning and aggregation
     * has been performed (i.e. immediately before verification).  By default,
     * all lead times are retained.
     */
    private double sampleSizeConstraint = 0.0;
    /**
     * The fraction of time allocated to reading of pairs, with the remainder
     * for metric calculation.
     */
    private double pairIOFrac = 0.75;
    /**
     * Start time in hours UTC [0,23] from which to begin aggregation of pairs.
     * Aggregation will begin from the first pair that matches this time (may
     * be null).
     */
    private Integer aggregationStartTime = null;
    
    /** 
     * First forecast lead time in hours at which aggregation of pairs should begin.
     * Aggregation will begin from the first pair that matches this time (may
     * be null).
     */
    private Double aggregationStartLeadHour = null;
    
    /** 
     * First forecast lead time at which pairing should begin.
     */
    private Double pairedStartLeadHour = null;       
    
    /**
     * Forecast file type. ASCII by default.
     */
    private int forecastFileType = FileIO.ASCII;
    
    /**
     * Observed file type. ASCII by default.
     */
    private int observedFileType = FileIO.ASCII;
    
    /**
     * Optional location identifier for reading the forecast files. This may differ
     * from the {@link locationID}.
     */

    private String forecastFileLocationID = null;
    
    /**
     * Optional location identifier for reading the observed files. This may differ
     * from the {@link locationID}.
     */

    private String observedFileLocationID = null;
    
    /**
     * Optional variable identifier for reading the forecast files. This may differ
     * from the {@link variableID}.
     */

    private String forecastFileVariableID = null;
    
    /**
     * Optional variable identifier for reading the observed files. This may differ
     * from the {@link variableID}.
     */

    private String observedFileVariableID = null; 
    
    /**
     * Is true to store the raw paired data in an aggregated resolution, false to store
     * in their native resolution for I/O and disk space efficiency. However, if the pairs
     * are stored in their aggregated resolution, they will be deleted upon changing
     * any aggregation parameters, such as {@link VerificationUnit#verificationResolution}.
     * Thus, storing pairs in their aggregated resolution is not recommended unless
     * the aggregation options are fixed, because changing these options will require 
     * re-pairing. Whether the raw pairs have the same resolution as the native pairs
     * is not considered in acting upon the value of this parameter. Thus, the raw pairs
     * will be removed unconditionally following a change in resolution if this parameter
     * is true.
     */
    
    private boolean storeRawPairsInAggregatedRes = false;
    
    /**
     * Is true to apply date conditions to an otherwise unconditional 
     * climatology. This allows for degrees of conditioning of an otherwise 
     * unconditional climatology. Note that this option refers to the determination
     * of climate thresholds only, not the computation of skill metrics with sample
     * climatology as the baseline, which are based on the paired data (i.e. any 
     * conditions apply by default).
     */
    
    private boolean applyDateCondToClim = false;

    /**
     * Is true to apply value conditions to an otherwise unconditional 
     * climatology. This allows for degrees of conditioning of an otherwise 
     * unconditional climatology.  Note that this option refers to the determination
     * of climate thresholds only, not the computation of skill metrics with sample
     * climatology as the baseline, which are based on the paired data (i.e. any 
     * conditions apply by default).
     */
    
    private boolean applyValueCondToClim = false;   
    
    /**
     * Is true to return a missing value when performing temporal aggregation if any of 
     * the inputs are missing, otherwise aggregate the non-missing data.
     */
    
    private boolean strictAgg = true;    
    
    /**
     * The time system type for the verification window. In valid time if true,
     * otherwise forecast issue time/basis time. By definition, observations are
     * always in valid time. Pairs and forecasts may be in issue time/basis time.
     */
    
    private boolean verifWindowInValidTime = true;
    
    /*******************************************************************************
     *                                                                             *
     *                                CONSTRUCTOR                                  *
     *                                                                             *
     ******************************************************************************/

    /**
     * Constructs a VerificationUnit with a segment ID, a time-series ID and a
     * variable type.  An optional additional identifier may be specified.
     *
     * @param locationID the segment ID
     * @param variableID the variable ID
     * @param additionalID an additional identifier
     */

    public VerificationUnit(String locationID,String variableID, String additionalID) {
        if(locationID == null || variableID == null || locationID.equals("") || variableID.equals("")) {
            throw new IllegalArgumentException("One or more identifiers are undefined: specify a location identifier and a variable identifier.");
        } else if(locationID.indexOf(sepChar)>-1 || variableID.indexOf(sepChar)>-1 || (additionalID != null && additionalID.indexOf(sepChar)>-1)) {
            throw new IllegalArgumentException("One or more identifiers contains illegal characters ["+sepChar+"].");
        }
        this.locationID = locationID;
        this.variableID = variableID;
        if(additionalID != null && ! additionalID.equals("")) {
            this.additionalID = additionalID;
        }
    }

    /**
     * Constructs a VerificationUnit with a segment ID, a time-series ID and a
     * variable type.
     *
     * @param locationID the segment ID
     * @param variableID the variable ID
     */

    public VerificationUnit(String locationID, String variableID) {
        this(locationID,variableID,null);
    }

    /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/

    /**
     * Returns the location ID.
     *
     * @return the location ID
     */

    public String getLocationID() {
        return locationID;
    }

    /**
     * Returns the variable ID.
     *
     * @return the variable ID
     */

    public String getVariableID() {
        return variableID;
    }
    
    /**
     * Returns the forecast file location ID.
     *
     * @return the forecast file location ID
     */

    public String getForecastFileLocationID() {
        return forecastFileLocationID;
    }

    /**
     * Returns the forecast file variable ID.
     *
     * @return the forecast file variable ID
     */

    public String getForecastFileVariableID() {
        return forecastFileVariableID;
    }    
    
    /**
     * Returns the observed file location ID.
     *
     * @return the observed file location ID
     */

    public String getObservedFileLocationID() {
        return observedFileLocationID;
    }

    /**
     * Returns the observed file variable ID.
     *
     * @return the observed file variable ID
     */

    public String getObservedFileVariableID() {
        return observedFileVariableID;
    }    
    
    /**
     * Returns true if the forecast file location ID is set, false otherwise.
     *
     * @return true if the forecast file location ID is set
     */

    public boolean hasForecastFileLocationID() {
        return forecastFileLocationID!=null;
    }

    /**
     * Returns true if the forecast file variable ID is set, false otherwise.
     *
     * @return true if the forecast file variable ID is set
     */

    public boolean hasForecastFileVariableID() {
        return forecastFileVariableID!=null;
    }    
    
    /**
     * Returns true if the observed file location ID is set, false otherwise.
     *
     * @return true if the observed file location ID is set
     */

    public boolean hasObservedFileLocationID() {
        return observedFileLocationID!=null;
    }

    /**
     * Returns true if the observed file variable ID is set, false otherwise.
     *
     * @return true if the observed file variable ID is set
     */

    public boolean hasObservedFileVariableID() {
        return observedFileVariableID!=null;
    }       
    
    /**
     * Returns true to insert a missing value when performing temporal aggregation if any of 
     * the inputs are missing, otherwise aggregate the non-missing data.
     * 
     * @return true to perform strict aggregation
     */
    
    public boolean isStrictAgg() {
        return strictAgg;
    }       
    
    /**
     * Returns any additional ID associated with the verification unit.
     *
     * @return the additional ID
     */

    public String getAdditionalID() {
        return additionalID;
    }

    /**
     * Returns the forecast data source or null.
     *
     * @return the the forecast data
     */

    public DataSource getForecastData() {
        return forecastData;
    }

    /**
     * Returns the observed data source or null.
     *
     * @return the observed data
     */

    public DataSource getObservedData() {
        return observedData;
    }
        
    /**
     * Returns the null value associated with the unit.
     *
     * @return the null value
     */
    
    public double getNullValue() {
        return nullValue;
    } 

    /**
     * Returns the time system for the forecasts
     *
     * @return the forecast time system
     */

    public TimeZone getForecastTimeSystem() {
        return forecastTimeSystem;
    }

    /**
     * Returns the time system for the observations
     *
     * @return the observed time system
     */

    public TimeZone getObservedTimeSystem() {
        return observedTimeSystem;
    }

    /**
     * Returns the first forecast lead time.
     *
     * @return the first forecast lead time
     */

    public double getFirstLeadTime() {
        return firstTime;
    }

    /**
     * Returns the sub forecast lead time.
     *
     * @return the sub forecast lead time
     */

    public double getLastLeadTime() {
        return lastTime;
    }

    /**
     * Returns the forecast lead time units.
     *
     * @return the lead time units
     */

    public String getForecastLeadTimeUnits() {
        return leadUnits;
    }

    /**
     * Returns the temporal resolution of the verification.
     *
     * @return the temporal resolution
     */

    public int getResolution() {
        return verificationResolution;
    }

    /**
     * Returns the units of the temporal resolution.
     *
     * @return the temporal resolution units
     */

    public String getResolutionUnits() {
        return verificationResolutionUnits;
    }

    /**
     * Returns a source for a paired dataset or null (not the actual paired data).
     *
     * @return the paired data source
     */

    public PairedDataSource getPairedDataSource() {
        return pairedSource;
    }

    /**
     * Returns any date condition associated with the verification unit.
     *
     * @return a date condition or null
     */

    public DateCondition getDateCondition() {
        DateCondition d = dateCondition;
        if(d!=null) {
            d = (DateCondition)dateCondition.deepCopy();
        }
        return d;
    }

    /**
     * Returns the time of day in hours (UTC) at which temporal aggregation will
     * begin or null if the start time has not been defined.
     *
     * @return the start time for aggregation or null
     */

    public Integer getAggregationStartHourUTC() {
        return aggregationStartTime;
    }
    
    /**
     * Returns the lead time in hours at which temporal aggregation will
     * begin or null if the lead time has not been defined.
     *
     * @return the first lead time for aggregation or null
     */

    public Double getAggregationStartLeadHour() {
        return aggregationStartLeadHour;
    }    
    
    /**
     * Returns the first lead time in hours after which the pairs will be constructed
     * or null if the lead time has not been set. Deprecated as of 5.0. Use the
     * start lead time of the verification window instead.
     * 
     * @return the first lead time at which pairs will begin
     * @deprecated
     */
    
    public Double getPairedStartLeadHour() {
        return pairedStartLeadHour;
    }

    /**
     * Returns a set of value condition associated with the verification unit.
     *
     * @return a set of value conditions or null
     */
    
    public Vector<ValueCondition> getValueConditions() {
        Vector<ValueCondition> returnMe = null;
        if (hasValueConditions()) {
            returnMe = new Vector<ValueCondition>();
            int length = valueConditions.size();
            for (int i = 0; i < length; i++) {
                returnMe.add((ValueCondition) valueConditions.get(i).deepCopy());
            }
        }
        return returnMe;
    }

    /**
     * Returns the value conditions for which the named input unit is a parameter.
     *
     * @param id the identifier for the unit on which conditions may be built
     * @return the value conditions
     */

    public Vector<ValueCondition> getValueConditions(String id) {
        Vector<ValueCondition> returnMe = new Vector<ValueCondition>();
        int length = valueConditions.size();
        for(int i = 0; i < length ; i++) {
            if(valueConditions.get(i).getVerificationUnitID().equals(id)) {
                returnMe.add((ValueCondition)valueConditions.get(i).deepCopy());
            }
        }
        return returnMe;
    }

    /**
     * Returns the temporal aggregation function associated with a verification
     * unit.
     *
     * @return the temporal aggregation function
     */

    public VectorFunction getTemporalAggFunc() {
        return tempAggFunc;
    }

    /**
     * Returns the support for a specified identifier.  See the evs.analysisunits.scale.Support
     * class for identifiers.
     *
     * @param id the identifier
     * @return the forecast support
     */

    public Support getSupport(int id) throws IllegalArgumentException {
        switch(id) {
            case Support.FORECAST_SUPPORT: {
                return forecastSupport;
            }
            case Support.OBSERVED_SUPPORT: {
                return observedSupport;
            }
            default: {
                throw new IllegalArgumentException("Unrecognized idenfifier for support information.");
            }
        }
    }

    /**
     * Returns the fraction of pairs required at each lead time for that lead time
     * to be included in the verification results. The fraction falls in [0,1] and
     * is relative to the average number of pairs found across all lead times after
     * applying all conditions and any temporal aggregation.
     *
     * @return the sample size fraction
     */

    public double getSampleSizeConstraint() {
        return sampleSizeConstraint;
    }

    /**
     * Returns the forecast file type.
     *
     * @return the forecast file type.
     */

    public int getForecastFileType() {
        return forecastFileType;
    }

    /**
     * Returns the observed file type.
     *
     * @return the observed file type.
     */

    public int getObservedFileType() {
        return observedFileType;
    }

    /**
     * Returns true if the support information associated with the forecasts
     * and observations has been set for a specified support type.  See the
     * evs.analysisunits.scale.Support class for identifiers.
     *
     * @param id the identifier
     * @return true if the support has been set
     */

    public boolean hasSupport(int id) throws IllegalArgumentException {
        switch(id) {
            case Support.ALL_SUPPORT: {
                return forecastSupport != null && observedSupport != null;
            }
            case Support.FORECAST_SUPPORT: {
                return forecastSupport != null;
            }
            case Support.OBSERVED_SUPPORT: {
                return observedSupport != null;
            }
            default: {
                throw new IllegalArgumentException("Unrecognized idenfifier for support information.");
            }
        }
    }

    /**
     * Returns true if both the observed and forecast support are null or if they
     * are both non-null and equal or if the support can be changed, false otherwise.
     * Null support is allowed for both the observed and forecast support under
     * an *assumption* of equal support.
     *
     * @return true if verification can be performed with existing support information
     */

    public boolean hasVerifiableSupport() {
        boolean returnMe = forecastSupport == null && observedSupport == null;
        //Both supports are non-null but different: is aggregation of one possible?
        if(forecastSupport !=null && observedSupport!= null) {
            if(forecastSupport.equals(observedSupport)) {
                returnMe = true;
            }
            else {
                returnMe = Support.canChangeSupport(forecastSupport, observedSupport);
                if (!returnMe) {
                    returnMe = Support.canChangeSupport(observedSupport, forecastSupport);
                }
            }
        }
        return returnMe;
    }

    /**
     * Returns true if a paired data source has been set.
     *
     * @return true if a paired data source has been set.
     */

    public boolean hasPairedDataSource() {
        return pairedSource != null;
    }

    /**
     * Returns true if the forecast data have been set, false otherwise.
     *
     * @return true if the forecast data are set
     */

    public boolean hasForecastData() {
        return forecastData != null;
    }

    /**
     * Returns true if the observed data have been set, false otherwise.
     *
     * @return true if the observed data are set
     */

    public boolean hasObservedData() {
        return observedData != null;
    }

    /**
     * Returns true if the time system for the forecasts has been set.
     *
     * @return true if the time system has been set
     */

    public boolean hasForecastTimeSystem() {
        return forecastTimeSystem != null;
    }

    /**
     * Returns true if the time system for the observations has been set.
     *
     * @return true if the time system has been set
     */

    public boolean hasObservedTimeSystem() {
        return observedTimeSystem != null;
    }

    /**
     * Returns true if the forecast lead times have been set, false otherwise.
     *
     * @return true if the forecast lead times have been set
     */

    public boolean hasLeadTimes() {
        //Only check first time, as both must be defined
        return firstTime != DEFAULT_INT_VALUE;
    }

    /**
     * Returns true if the verification resolution has been set, false otherwise.
     *
     * @return true if the verification timestep has been set
     */

    public boolean hasResolution() {
        return verificationResolution != DEFAULT_INT_VALUE;
    }

    /**
     * Returns true if there are date conditions associated with the verification
     * unit, false otherwise.
     *
     * @return true if date conditions have been set
     */

    public boolean hasDateCondition() {
        return dateCondition != null;
    }

    /**
     * Returns true if there are value conditions associated with the verification
     * unit, false otherwise.
     *
     * @return true if value conditions have been set
     */

    public boolean hasValueConditions() {
        return valueConditions.size()>0;
    }

    /**
     * Returns true if there are value conditions associated with the verification
     * unit that rely on the specified unit, false otherwise.
     *
     * @param id the identifier for the unit on which conditions may be built
     * @return true if value conditions exist that depend on the input unit
     */

    public boolean hasValueConditions(String id) {
        boolean returnMe = false;
        int length = valueConditions.size();
        for(int i = 0; i < length ; i++) {
            if(valueConditions.get(i).getVerificationUnitID().equals(id)) {
                returnMe = true;
            }
        }
        return returnMe;
    }

    /**
     * Returns true if there are reference forecasts associated with the verification
     * unit that rely on the specified unit, false otherwise.
     *
     * @param id the identifier for the unit which may be defined as a reference forecast
     * @return true if the unit contains the input as a reference forecast
     */

    public boolean hasReferenceForecast(String id) {
        if(hasSkillMetrics()) {
            Vector<Metric> s = getSkillMetrics();
            int t = s.size();
            for (int i = 0; i < t; i++) {
                Metric m = s.get(i);
                if (m.isSkillMetric()) {
                    if (m instanceof SkillScore) {
                        if (((SkillScore) m).getRefFcst().hasRefForecast(id)) {
                            return true;
                        }
                    } else if (m instanceof ThresholdMetricStore) {
                        SkillScore sk = (SkillScore) ((ThresholdMetricStore) m).getFirstMetricInStore();
                        if (sk.getRefFcst().hasRefForecast(id)) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    /**
     * Returns true if both the verification dates have been set.
     *
     * @return true if the dates have been set
     */

    public boolean hasDates() {
        return start != null && end != null;
    }

    /**
     * Returns true if the start date has been set, false otherwise.
     *
     * @return true if the start date has been set
     */

    public boolean hasStartDate() {
        return start != null;
    }

    /**
     * Returns true if the end date has been set, false otherwise.
     *
     * @return true if the end date has been set
     */

    public boolean hasEndDate() {
        return end != null;
    }

    /**
     * Returns true if an additional identifier has been defined, false otherwise.
     *
     * @return true if an additional identifier is available
     */

    public boolean hasAdditionalID() {
        return additionalID != null && !additionalID.equals("");
    }

    /**
     * Returns true if an aggregation unit has been set for the current
     * verification unit.
     *
     * @return true if an aggregation unit is set
     */

    public boolean hasAggregationUnit() {
        return aggregation.size()>0;
    }

    /**
     * Returns true if an aggregation unit has been set for the current
     * verification unit AND that aggregation unit contains verification units.
     *
     * @return true if a usable aggregation unit is set
     */

    public boolean hasUsableAggregationUnit() {
        if(aggregation.size()>0) {  //JB @ 11th March 2013
            for(AggregationUnit a : aggregation) {
                if(a.hasVerificationUnits()) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Returns true if a start time has been specified in hours UTC [0,23] from
     * which to start temporal aggregation, false otherwise.
     *
     * @return true if an aggregation start time has been defined, false otherwise
     */

    public boolean hasAggregationStartHourUTC() {
        return aggregationStartTime !=null;
    }
    
    /**
     * Returns true if a first lead time in hours has been specified from
     * which to start temporal aggregation, false otherwise.
     *
     * @return true if an aggregation start lead time has been defined, false otherwise
     */

    public boolean hasAggregationStartLeadHour() {
        return aggregationStartLeadHour !=null;
    }    
    
    /**
     * Returns true if a first lead time in hours has been specified from
     * which to start pairing, false otherwise. Deprecated as of 5.0. Use
     * the start lead hour of the verification window instead.
     *
     * @return true if a start lead time has been defined, false otherwise
     * @deprecated
     */

    public boolean hasPairedStartLeadHour() {
        return pairedStartLeadHour !=null;
    }      

    /**
     * Is true if the conditional pairs will be written to file.
     *
     * @return true if the conditional pairs will be written
     */

    public boolean isWriteConditionalPairs() {
        return writeConditionalPairs;
    }
    
    /**
     * Returns true to store pairs in an aggregated resolution where required, false
     * to store in their native resolution.
     * 
     * @return true to store pairs in their native resolution, false otherwise
     */
    
    public boolean isStoreRawPairsInAggregatedRes() {
        return storeRawPairsInAggregatedRes;
    }
        
    /**
     * Is true if the raw pairs will be written to file.
     *
     * @return true if the raw pairs will be written
     */

    public boolean isWriteUnconditionalPairs() {
        return writeUnconditionalPairs;
    }    
    
    /**
     * Returns true if date conditions will be applied to the sample climatology
     * before determining thresholds corresponding to given climatological
     * probabilities, false otherwise.
     * 
     * @return true if date conditions will be applied to the climatology, false otherwise 
     */
    
    public boolean isApplyDateCondToClim() {
        return applyDateCondToClim;
    } 
    
    /**
     * Returns true if value conditions will be applied to the sample climatology
     * before determining thresholds corresponding to given climatological
     * probabilities, false otherwise.
     * 
     * @return true if value conditions will be applied to the climatology, false otherwise 
     */    

    public boolean isApplyValueCondToClim() {
        return applyValueCondToClim;
    }
       
   /**
     * Returns true if the time system for the verification window is forecast 
     * valid time, false if using issue/basis time. By definition, observations are
     * always in valid time. Pairs and forecasts may be in issue time/basis time.
     * 
     * @return true if the verification window is in forecast valid time, false if issue/basis time
     */
   
    public boolean isVerifWindowInValidTime() {
        return verifWindowInValidTime;
    }
    
    /**
     * Returns a string representation of the receiver.
     */

    @Override
    public String toString() {
        String basic = locationID+sepChar+variableID;
        if(hasAdditionalID()) {
            basic = basic+sepChar+additionalID;
        }
        return basic;
    }

    /**
     * Creates a deep copy of the current verification unit with its basic parameters.
     * If an aggregation unit is present it is not copied.  Optionally, the metrics
     * may be deep copied. In most cases, the metrics SHOULD be deep copied. However,
     * in some cases this is not necessary, and this is the most time-consuming part
     * of deep copying.
     *
     * @param copyMetrics is true to deep copy the metrics
     * @return a deep copy of the current unit    
     */
    
    @Override
    public VerificationUnit deepCopy(boolean copyMetrics) {
        //System.out.println("Copying unit '"+this+"' (developer note: associated aggregation unit(s) are not copied and should be re-instated in copied unit).");
        VerificationUnit copy = new VerificationUnit(locationID,variableID);
        copy.verificationResolution = verificationResolution;
        copy.verificationResolutionUnits = verificationResolutionUnits;
        copy.forecastData= forecastData;
        copy.firstTime = firstTime;
        copy.lastTime = lastTime;
        copy.leadUnits = leadUnits;
        copy.observedData = observedData;
        copy.outputData = outputData;
        copy.sepChar = sepChar;
        copy.variableID = variableID;
        copy.additionalID = additionalID;
        copy.observedTimeSystem = observedTimeSystem;
        copy.forecastTimeSystem = forecastTimeSystem;
        copy.pairedSource = pairedSource;
        copy.eliminateDuplicates=eliminateDuplicates;
        copy.writeConditionalPairs=writeConditionalPairs;
        copy.writeUnconditionalPairs=writeUnconditionalPairs;
        copy.useFullClimatology=useFullClimatology;
        copy.pairPrecision = pairPrecision;
        copy.stripNullMembers = stripNullMembers;
        copy.sampleSizeConstraint = sampleSizeConstraint;
        copy.aggregationStartTime = aggregationStartTime;
        copy.aggregationStartLeadHour = aggregationStartLeadHour;        
        copy.forcDateFormat = forcDateFormat;
        copy.obsDateFormat = obsDateFormat;
        copy.observedFileType = observedFileType;
        copy.forecastFileType = forecastFileType;
        copy.lastPairFirstLeadCount = lastPairFirstLeadCount;
        copy.nullValue = nullValue;
        copy.forecastFileLocationID = forecastFileLocationID;
        copy.observedFileLocationID = observedFileLocationID;       
        copy.forecastFileVariableID = forecastFileVariableID;
        copy.observedFileVariableID = observedFileVariableID;  
        copy.storeRawPairsInAggregatedRes = storeRawPairsInAggregatedRes;
        copy.applyDateCondToClim = applyDateCondToClim;
        copy.applyValueCondToClim = applyValueCondToClim;
        copy.pairedStartLeadHour = pairedStartLeadHour;   
        copy.write = write;
        copy.verifWindowInValidTime = verifWindowInValidTime;
        if(start != null) {
            copy.start = Calendar.getInstance();
            copy.start.setTimeZone(start.getTimeZone());
            copy.start.clear();
            copy.start.setTimeInMillis(start.getTimeInMillis());
        }
        if(end != null) {
            copy.end = Calendar.getInstance();
            copy.end.setTimeZone(end.getTimeZone());
            copy.end.clear();
            copy.end.setTimeInMillis(end.getTimeInMillis());
        }
        //Set the date condition
        if(dateCondition != null) {
            TreeMap<DateElement,Vector<Integer>> conditions = dateCondition.getConditions();
            copy.dateCondition = new DateCondition(copy,conditions);
        }
        //Set the value conditions: note that subsequent changes will NOT be reflected.
        //Indeed, they should not be.  Changes in a verification unit to be used
        //as a parameter in a value condition should trigger the removal of that value condition.
        if(valueConditions != null) {
            copy.valueConditions = new Vector<ValueCondition>();
            int length = valueConditions.size();
            for(int i = 0; i < length; i++) {
                ValueCondition v = (ValueCondition)valueConditions.get(i).deepCopy();
                copy.valueConditions.add(v);
            }
        }
        //Deep copy the metrics
        if(copyMetrics) {
            copy.metrics = new TreeMap<String, Metric>();
            Iterator i = metrics.keySet().iterator();
            while (i.hasNext()) {
                String next = i.next().toString();
                Metric m = metrics.get(next);
                m = m.deepCopy();
                copy.metrics.put(next, m);
            }
        } else {
            copy.metrics=metrics;
        }
        if(forecastSupport != null) {
            copy.forecastSupport = (TemporalSupport)forecastSupport.deepCopy();
        }
        if(observedSupport != null) {
            copy.observedSupport = (TemporalSupport)observedSupport.deepCopy();
        }
        copy.tempAggFunc = tempAggFunc;
        return copy;
    }

    /**
     * Returns true if the current unit is a candidate for aggregation.  A unit
     * becomes a candidate for aggregation once it has dates, a forecast lead
     * time and period, observations and forecasts with corresponding time systems
     * and a set of verification metrics.
     *
     * @return true if the verification unit is a candidate for aggregation
     */

    public boolean isAggregationCandidate() {
        boolean returnMe = hasDates(); // && hasLeadTimes();
        returnMe = returnMe && hasForecastData() && hasObservedData();
        returnMe = returnMe && hasForecastTimeSystem() && hasObservedTimeSystem();
        returnMe = returnMe && hasMetrics();
        return returnMe;
    }

    /**
     * Returns true if all of the parameters of the input unit and the current unit
     * match for aggregation purposes.  Both units must return true when calling
     * isAggregationCandidate(), as this ensures that all required parameter
     * values have been set.  Once achieved, the check here involves a limited subset of
     * parameters, namely the variable ID, the forecast lead time, the verification
     * timestep, and period, the temporal aggregation functions and the verification
     * metrics (including their parameter values).
     *
     * NOTE that no check is made on verification conditions, such as variable value
     * or date conditions. Whether checks are made on the reference forecasts defined
     * for skill scores can be controlled by an input parameter; for example, if 
     * checking as part of a code block that changes the names for reference forecasts, 
     * no check on reference forecasts may be desired.  
     *
     * @param unit the input unit
     * @param checkRefPars is true to check reference forecast parameters associated with metrics
     * @return true if all parameters match
     */

    public boolean aggregationEquals(VerificationUnit unit, boolean checkRefPars) {
        if(unit == null) {
            return false;
        }
        if(!unit.isAggregationCandidate() || !isAggregationCandidate()) {
            return false;
        }
        if(unit.verificationResolution != verificationResolution) {
            return false;
        }
        if(!unit.verificationResolutionUnits.equals(verificationResolutionUnits)) {
            return false;
        }
        if(!hasLeadTimes()==unit.hasLeadTimes()) {
            return false;
        }
        if (hasLeadTimes()) {
            if (unit.firstTime != firstTime) {
                return false;
            }
            if (unit.lastTime != lastTime) {
                return false;
            }
            if (!unit.leadUnits.equals(leadUnits)) {
                return false;
            }
        }
        if(!unit.variableID.equals(variableID)) {
            return false;
        }
//        if(!unit.start.equals(start)) {
//            return false;
//        }
//        if(!unit.end.equals(end)) {
//            return false;
//        }
        if(!unit.tempAggFunc.equals(tempAggFunc)) {
            return false;
        }
        //Check the support information
        //JB@8th March 2013 from equals to equalsOnUnitChange
        if(unit.hasSupport(Support.FORECAST_SUPPORT) && 
                !((TemporalSupport)unit.getSupport(Support.FORECAST_SUPPORT)).equalsOnUnitChange(forecastSupport)) {
            return false;
        }
        if(unit.hasSupport(Support.OBSERVED_SUPPORT) && 
                !((TemporalSupport)unit.getSupport(Support.OBSERVED_SUPPORT)).equalsOnUnitChange(observedSupport)) {
            return false;
        }
        if(hasSupport(Support.FORECAST_SUPPORT) && 
                !((TemporalSupport)getSupport(Support.FORECAST_SUPPORT)).equalsOnUnitChange(unit.forecastSupport)) {
            return false;
        }
        if(hasSupport(Support.OBSERVED_SUPPORT) && 
                !((TemporalSupport)getSupport(Support.OBSERVED_SUPPORT)).equalsOnUnitChange(unit.observedSupport)) {
            return false;
        }
        //Check the date conditions
        //if(unit.hasDateCondition() != hasDateCondition()) {
        //    return false;
        //}
        //Date conditions must be equal
        //if(hasDateCondition()) {
        //    if(!unit.getDateCondition().equals(getDateCondition())) {
        //        return false;
        //    }
        //}
        //Check the value conditions
        //if(unit.hasValueConditions() != hasValueConditions()) {
        //    return false;
        //}
        //Value conditions must be equal
        //if(hasValueConditions()) {
        //    if(!unit.getValueConditions().equals(getValueConditions())) {
        //        return false;
        //    }
        //}
        
        //Check for the same metrics for the same parameter values: UPDATED 8th March 2013
        //Ignore reference forecasts 
        if(!unit.hasMetrics() || !hasMetrics()) {
            return false;
        }
        TreeMap<String, Metric> thisSet = metrics;
        TreeMap<String, Metric> testSet = unit.metrics;
        if(thisSet.size()!=testSet.size()) {
            return false;
        }
        Iterator j = thisSet.keySet().iterator();
        boolean go = true;
        while(j.hasNext()) {
            String next = (String)j.next();
            if(testSet.containsKey(next)) {
                if(!testSet.get(next).paramEquals(thisSet.get(next),checkRefPars)) {
                    go = false; break;
                }
            } else {
                go = false; break;
            }
        }
        return go;
    }

    /**
     * Returns the aggregation unit associated with this verification unit if
     * one has been defined.
     *
     * @return the aggregation unit
     */

    public ArrayList<AggregationUnit> getAggregationUnits() {
        ArrayList<AggregationUnit> returnMe = new ArrayList<AggregationUnit>();
        returnMe.addAll(aggregation);
        return returnMe;
    }

    /**
     * Returns a deep copy of the start date for the verification period.
     *
     * @return the start date
     */

    public Calendar getStartDate() {
        Calendar s = null;
        if(start != null) {
            s = Calendar.getInstance();
            s.setTimeZone(start.getTimeZone());
            s.clear();
            s.setTimeInMillis(start.getTimeInMillis());
        }
        return s;
    }

    /**
     * Returns a deep copy of the end date for the verification period.
     *
     * @return the end date
     */

    public Calendar getEndDate() {
        Calendar s = null;
        if(end != null) {
            s = Calendar.getInstance();
            s.setTimeZone(end.getTimeZone());
            s.clear();
            s.setTimeInMillis(end.getTimeInMillis());
        }
        return s;
    }

    /**
     * Returns a set of paired observations and forecasts associated with the current
     * verification unit or throws an exception if no paired data source has been
     * defined or is otherwise unreadable.  Performs any change of support on the
     * pairs as specified by the current and required support of the VU and returns
     * paired forecasts and observations whose values are in a common support.  If
     * the support is undefined, it is assumed to be common.
     *
     * @return the paired data in a common support or assumed common support
     */

    public PairedData getPairs() throws IllegalArgumentException, PairedDataException {
        //Check for progress every second and update for purposes of metric computation
        Timer t2 = new Timer();
        try {
            TimerTask task2 = new TimerTask() {
                public void run() {
                    double prog = pairIOFrac * ((double) PairedDataSource.getProgress());
                    progress.setProgress((int)prog);
                    if (prog >= (pairIOFrac*100)) {
                        cancel();
                    }
                }
            };
            t2.scheduleAtFixedRate(task2, 0, 50);

            //Attempt to compute pairs if not immediately available: this sets
            //the paired source variable in the current unit also
            //Any change of support is conducted at the point of reading the
            //paired data.
            PairedData p = null;
            try {
                //No paired data source: compute and write pairs and set paired data source
                //This also sets the full climatology
                if (!hasPairedDataSource() || !getPairedDataSource().canRead()) {
                    PairedData[] pa = PairedDataSource.computeAndSetPairs(new VerificationUnit[]{this});
                    if (pa[0] != null) {
                        p = pa[0];
                    }
                }
                //Paired data source exists: read pairs
                else {
                    p = pairedSource.getPairedData(eliminateDuplicates, nullValue);
                    //Set the climatological data if required
                    try {
                        if (isUseFullClimatology()) {
                            PairedDataSource.readAndSetClimatology(this, p, observedData);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        throw new PairedDataException("Could not process climatological data source for '" + this + "': " + e.getMessage());
                    }              
                }
            } catch (Exception e) {
                e.printStackTrace();
                throw new PairedDataException("Could not process the paired data "
                        + "for '" + this + "': " + e.getMessage());
            }
            return p;
        } catch (PairedDataException e) {
            e.printStackTrace();
            throw e;
        } catch (IllegalArgumentException f) {
            f.printStackTrace();
            throw f;
        } finally {
            t2.cancel();
        }
    }

    /**
     * Applies any conditions associated with the current verification unit to
     * the verification pairs and returns the reduced set of pairs that satisfy
     * those conditions.  Also aggregates the input first if required (i.e. if an
     * aggregation resolution has been defined).
     *
     * The conditions applied may include conditions on the times, the forecasts or
     * the observations.  Throws an exception if the paired forecasts and observations
     * have not been defined for all of the dependent conditions.  In addition, any change of
     * measurement units is applied at this stage.
     *
     * @return the conditioned set of forecasts and observations
     * @param applyValCond is true to apply the value conditions, false otherwise
     */

    public PairedData getConditionedPairs(boolean applyValCond) throws ConditioningException {
        DoubleMatrix2D result = null;
//25/05/12        DoubleMatrix2D climate = null;
        DoubleMatrix2D fullClimate = null;

        //Eliminate pairs that do not fall between the verification start and end dates
        if(!hasDates()) {
            throw new ConditioningException("Selection of conditional pairs requires the start "
                    + "and end dates to be defined.");
        }
        //Pairs in common support
        PairedData ps = getPairs();
        result = ps.getPairs();
        if(useFullClimatology) {
            fullClimate = ps.getUncClimObsWithTimes();
            //23/10/12  Bug whereby full climatology may be requested, but could not be found, so check
            if(fullClimate==null) {
                throw new ConditioningException("Could not read full set of observations for determining climatological thresholds.");
            }
        }
        
        //Check that aggregation is possible
        if (hasResolution() && !hasSupport(Support.ALL_SUPPORT)) {
            throw new ConditioningException("Cannot compute aggregated pairs: cannot apply an aggregation period without knowing the scale of the "
                    + "forecasts and observations. Set the scale of the forecasts and observations or remove the aggregation period.");
        }      
        

//25/05/12        climate = ps.getClimObsWithTimes();

        //Eliminate pairs that do not fall within the forecast lead time constraints
        
//TODO: update this code to use the existing code in LeadTimeCondition.java, which returns a matrix of booleans
//There are currently two locations where conditions are applied to pairs, namely here and on-the-fly in PairedDataSource.java,
//which is intended for processing individual forecast files when handling large datasets on-the-fly. The two approaches need to
//be sychronized in future, both calling subclasses of Condition.java to do the conditioning         
        if(hasLeadTimes()) {
            //Compute the number of milliseconds equivalent of the units
            double maxLead = GlobalUnitsReader.getMilliConversionFactor(getForecastLeadTimeUnits());
            //Convert to hours i.e. number of hours per unit
            maxLead = maxLead / (1000.0 * 60.0 * 60.0);
            double minLead = maxLead;
            //Multiply by the number of units
            minLead = minLead * getFirstLeadTime();
            maxLead = maxLead * getLastLeadTime();

            //Remove any pairs that do not match these criteria
//            boolean[] matches = new boolean[result.getRowCount()];
            //Construct the boolean sub
            DoubleProcedure sub = FunctionLibrary.isBetween(minLead,maxLead);
            try {
                result=result.subRowsbyColCond(sub,1,nullValue);
            }
            catch(Exception e) {
                throw new ConditioningException("Could not find any pairs with forecast lead times within the range "
                        + "["+getFirstLeadTime()+", "+getLastLeadTime()+"] "+getForecastLeadTimeUnits()+".");
            }
//            int conditionsCount = 0;
//            for(int i = 0; i < matches.length; i++) {
//                matches[i] = sub.apply(result.get(i,1));  //Lead time in hours is in column 1
//                if(matches[i]) {
//                    conditionsCount++;
//                }
//            }
//            double[][] temp = result.toArray();
//            double[][] processed = new double[conditionsCount][temp[0].length];
//            int tot = 0;
//            //Construct the new matrix
//            for(int i = 0; i < matches.length; i++) {
//                if(matches[i]) {
//                    processed[tot] = temp[i];
//                    tot++;
//                }
//            }
//            result = new DenseDoubleMatrix2D(processed);
        }

        //Aggregate if necessary
        //At this point, the support of the forecasts and observations is common (or assumed common)
        //other than the measurement units. However, aggregation of the pairs (both the forecasts
        //and observations) may be required.
        //If the aggregation resolution is equal to the support of
        //either the forecasts (where the observations were aggregated)
        //or the observations (where the forecasts were aggregated), use 
        //the existing data
        
        //JB@13th November 2012. This code will execute aggregation if pairs are stored in native resolution, rather
        //than aggregate resolution. If stored in aggregate resolution, no aggregation will be performed.
        //see {@link VerificationUnit#storeRawPairsInNativeRes}
        boolean aggregate = willAggregatePairs();
        if (!storeRawPairsInAggregatedRes && aggregate) {
            result = PairedData.getTimeAggData(result, false, getResolution(),
                    getResolutionUnits(), tempAggFunc, getNullValue(), null,
                    getAggregationStartHourUTC(), getAggregationStartLeadHour(), null, null, 
                    (TemporalSupport) observedSupport,isStrictAgg());

            //Set unconditional climatology in same support 
            if (fullClimate != null) {
                fullClimate = PairedData.getTimeAggData(fullClimate, true, getResolution(),
                        getResolutionUnits(), tempAggFunc, getNullValue(), null,
                        getAggregationStartHourUTC(), null, null, null, 
                        (TemporalSupport) observedSupport,isStrictAgg());
            }
        }
        
        //Subset pairs by date
//TODO: update this code to use the existing code in SimpleDateCondition.java, which returns a matrix of booleans        
        result = PairedData.subsetPairsByDate(result,this);    
        
        //Change the measurement units if required
        int rws = result.getRowCount();
        if (forecastSupport != null) {
            DoubleFunction func = (DoubleFunction) forecastSupport.getTargetMeasurementUnitsFunc();
            if(func == null) {
                func = FunctionLibrary.identity;
            }
            int cls = result.getColumnCount();
            for (int i = 0; i < rws; i++) {
                for (int j = 3; j < cls; j++) {
                    if (result.get(i, j) != nullValue) {
                        result.set(i, j, func.apply(result.get(i, j)));
                    }
                }
            }
        }
        if (observedSupport != null) {
            DoubleFunction func = (DoubleFunction) observedSupport.getTargetMeasurementUnitsFunc();
            if(func == null) {
                func = FunctionLibrary.identity;
            }
            for (int i = 0; i < rws; i++) {
                result.set(i, 2, func.apply(result.get(i, 2)));
            }
            //Change measurement units for unconditional climate data if needed
            if(fullClimate!=null) {
                int rr = fullClimate.getRowCount();
                for (int i = 0; i < rr; i++) {
                    if (fullClimate.get(i, 1) != nullValue) {   //JB @ 31st October 2012
                        fullClimate.set(i, 1, func.apply(fullClimate.get(i, 1)));
                    }
                }
            }
        }
        
        //Full climatology to which limited conditions may be applied, i.e. 
        //conditions on date and variable value, but not on date range because
        //this distinguishes a full climatology from the paired climatology to begin with
        //This will be deep copied below
        DoubleMatrix2D fullClimateCond = fullClimate;    

        //Apply any date conditions
        int conditionsCount = 0;
        if(hasDateCondition()) {
            conditionsCount = 1;
        }
        if(applyValCond && hasValueConditions()) {
            conditionsCount += valueConditions.size();
        }

        //Matrix of booleans with as many rows as conditions and as many
        //columns as times.  To include a time, every row in the time column
        //must be true.
        boolean[][] useMe = new boolean[conditionsCount][result.getRowCount()];
        boolean[][] useMeClim = null;
        if(fullClimateCond!=null) {        
            fullClimateCond = (DoubleMatrix2D)fullClimateCond.deepCopy(); 
            useMeClim = new boolean[conditionsCount][fullClimateCond.getRowCount()]; //JB @ 26th November 2012
            //Use all climate data by default 
            for(boolean[] fill : useMeClim) { //JB @ 26th November 2012
                Arrays.fill(fill,true);
            }
        }
        
//25/05/12         if(climate!=null) {
//25/05/12             useMeClim = new boolean[conditionsCount][climate.getRowCount()];
//25/05/12             uncClimate = (DoubleMatrix2D)climate.deepCopy();
//25/05/12         }

        //Apply the time conditions first
        if(hasDateCondition()) {
            //Aggregate the pairs associated with this unit if required
            boolean[] u1 = dateCondition.apply(result,Condition.PAIRED_DATA).toArray();
            System.arraycopy(u1,0,useMe[0],0,u1.length);
            //useMe[0] = dateCondition.apply(new PairedData(result,eliminateDuplicates)).toArray();
            //JB @ 26th November 2012
             if(applyDateCondToClim && fullClimateCond!=null) {
                 boolean[] u2 = dateCondition.apply(fullClimateCond,Condition.OBSERVED_DATA).toArray();
                 System.arraycopy(u2,0,useMeClim[0],0,u2.length);
                 //useMeClim[0] = dateCondition.apply(fullClimateCond).toArray();
             }
        }
        //Apply the value conditions
        if(applyValCond && hasValueConditions()) {
            int length = valueConditions.size();
            //Determine start index: 1 if date condition, 0 otherwise
            int initial = 0;
            if(hasDateCondition()) {
                initial = 1;
            }
            for(int i = 0; i < length; i++) {
                ValueCondition nC = valueConditions.get(i);
                DoubleMatrix2D nCPairs = null;
                //Condition on same variable
                if(nC.getVerificationUnitID().equals(toString())) {
                    nCPairs = result;
                }
                //Condition on different variable
                else {
                    System.out.println("Attempting to condition variable '"+this+"' on variable '"+nC.getVerificationUnitID()+"'.");
                    nCPairs = nC.getVerificationUnit().getConditionedPairs(true).getPairs();
                    //Create the combined paired dataset and throw exception if the sizes differ
                    DoubleMatrix2D merged = PairedData.getMergedData(result,nCPairs,false,true,true);
                    DenseDoubleMatrix2D start = (DenseDoubleMatrix2D)merged.getSubmatrixByColumn(0,2);
                    DenseDoubleMatrix2D end = (DenseDoubleMatrix2D)merged.getSubmatrixByColumn(result.getColumnCount(),merged.getColumnCount()-1);
                    nCPairs = start.concatenate(end,start.E);
                    int resultRows = result.getRowCount();
                    int condRows = nCPairs.getRowCount();
                    if(resultRows!=condRows) {
                        //System.out.println("Warning: different number of pairs found in conditioning variable " +
                        //        "'"+nC.getVerificationUnitID()+"' than conditioned variable '"+toString()+"': ["+condRows+","+resultRows+"].");
                        String extra = "";
                        if(nC.getVerificationUnit().hasValueConditions()) {
                            extra = "Note that the conditioning variable also has value conditions, and these conditions are applied first.";
                        }
                        throw new ConditioningException("Could not apply specified value conditions for unit '"+this+"' based on "
                                + "conditioning variable '"+nC.getVerificationUnitID()+".' The conditioned and conditioning variables "
                                        + "have different time dimensions (numbers of rows): ["+resultRows+","+condRows+"]. "+extra);
                    }
                }
                //useMe[i+initial] = nC.apply(nCPairs).toArray();               
                boolean[] u = nC.apply(nCPairs,Condition.PAIRED_DATA).toArray();
                System.arraycopy(u,0,useMe[i+initial],0,u.length);
                
                //Apply value conditions to unconditional climatology
                if (applyValueCondToClim && fullClimateCond!=null) {
                    if (valueConditions.get(i).getConditionType() == ValueCondition.OBSERVED_CONDITION) {
                        boolean[] u1 = valueConditions.get(i).apply(fullClimateCond,
                                Condition.OBSERVED_DATA).toArray();
                        System.arraycopy(u1, 0, useMeClim[i + initial], 0, u1.length);
                        //useMeClim[i+initial] = valueConditions.get(i).apply(climate).toArray();
                    } //Fill the unused forecast conditions with "true" entries
//                    else {
//                        useMeClim[i + initial] = new boolean[fullClimateCond.getRowCount()];
//                        Arrays.fill(useMeClim[i + initial], true);
//                    }
                }
            }
        }
        //Determine the rows to include if conditions were set
        if(conditionsCount > 0) {
            Vector<double[]> rowsToUse = new Vector<double[]>();
            BooleanMatrix2D copy = new DenseBooleanMatrix2D(useMe);
            copy = copy.transpose();  //Values are now row-wise
            boolean[][] cop = copy.toArray();
            int tot = cop.length;
            double[][] resultArray = result.toArray();
            //Construct boolean sub, filling sub array with true
            boolean[] test = new boolean[useMe.length];
            Arrays.fill(test,true);
            for(int i = 0; i < tot; i++) {
                if(Arrays.equals(cop[i],test)) {
                    rowsToUse.add(resultArray[i]);
                }
            }
            //Construct the result matrix
            int size = rowsToUse.size();
            if(size < 1) {
                throw new ConditioningException("The conditions failed to select any pairs of forecasts and observations.");
            }
            double[][] complete = new double[rowsToUse.size()][result.getColumnCount()];
            for(int i = 0; i < size; i++) {
                complete[i] = rowsToUse.get(i);
            }
            result = new DenseDoubleMatrix2D(complete);
            if (fullClimateCond!=null && (applyDateCondToClim || applyValueCondToClim)) {                                            //25/05/12 
                Vector<double[]> rowsToUseClim = new Vector<double[]>();
                BooleanMatrix2D copyClim = new DenseBooleanMatrix2D(useMeClim);
                copyClim = copyClim.transpose();  //Values are now row-wise
                boolean[][] copClim = copyClim.toArray();
                int totClim = copClim.length;
                double[][] resultArrayClim = fullClimateCond.toArray();
                //Construct boolean sub, filling sub array with true
                boolean[] testClim = new boolean[useMeClim.length];
                Arrays.fill(testClim, true);
                for (int i = 0; i < totClim; i++) {
                    if (Arrays.equals(copClim[i], testClim)) {
                        rowsToUseClim.add(resultArrayClim[i]);
                    }
                }
                //Construct the result matrix
                int sizeClim = rowsToUseClim.size();
                if (sizeClim < 1) {
                    throw new ConditioningException("The conditions failed to select any climate observations.");
                }
                double[][] completeClim = new double[rowsToUseClim.size()][fullClimateCond.getColumnCount()];
                for (int i = 0; i < sizeClim; i++) {
                    completeClim[i] = rowsToUseClim.get(i);
                }
                fullClimateCond = new DenseDoubleMatrix2D(completeClim);
            }
        }
            
        //Is there a relative sample size constraint per lead time?
        //Yes: determine the average number of pairs per lead time
        //JB @ 8th April, simplified search
        if (sampleSizeConstraint > 0) {
            PairedData p = new PairedData(result,eliminateDuplicates,nullValue);
            DoubleMatrix1D r = p.getLeadTimes();
            int rows = r.getRowCount();
            double average = ((double)result.getRowCount())/rows;
            double min = average * sampleSizeConstraint;
            for(int  i = 0; i < rows; i++) {
                double lead = r.get(i);
                if(p.getPairsByLeadTime(lead).getRowCount()<min) {
                    DoubleProcedure pl = FunctionLibrary.isEqual(lead);
                    result = result.subRowsbyColCond(pl,nullValue,true);
                }
            }            
            
//            TreeMap<Double, Integer> counts = new TreeMap<Double, Integer>();  //Sample counts per lead time
//            int rs = result.getRowCount();
//            for (int i = 0; i < rs; i++) {
//                Double lead = result.get(i,1);
//                if (counts.containsKey(lead)) {
//                    counts.put(lead, counts.get(lead) + 1);
//                } else {
//                    counts.put(lead, 1);
//                }
//            }
//            //Remove lead times that do not meet the constraint
//            double constraint = (((double)rs) / counts.size()) * sampleSizeConstraint;
//            Iterator it = counts.keySet().iterator();
//            while (it.hasNext()) {
//                Double lead = (Double)it.next();
//                if (counts.get(lead) < constraint) {
//                    DoubleProcedure p = FunctionLibrary.isEqual(lead);
//                    result = result.subRowsbyColCond(p,nullValue,true);
//                }
//            }
        }

        PairedData pd = new PairedData(result,eliminateDuplicates,nullValue);
        //Set the full climatology if available
        if(fullClimateCond!=null) {
            //Set the unconditional climatology //JB@26th November 2012 
            //or unconditional climatology with limited application of other conditions
            //Note that that the unconditional climate is read every time, regardless or state
            //so changes to conditioning options will be processed properly each time, i.e.
            //the partially conditioned unconditional pairs only exist in the context of one run
            //and the first call to getUncClimObsWithTimes in this method will always recall the clean data
            pd.setClimObsWithTimes(fullClimateCond);  //JB@23/10/12 
            pd.setUncClimObsWithTimes(fullClimateCond);   //JB@23/10/12 
        } 
        return pd;
    }

    /**
     * Returns true if the unit can be executed (i.e. all parameters are set),
     * false otherwise.
     *
     * @return true if the unit is ready to execute
     */

    public boolean canExecute() {
        boolean first = hasForecastData() && hasObservedData() && hasObservedTimeSystem() && hasForecastTimeSystem();
        boolean second = hasLeadTimes() && hasDates() && hasMetrics();
        return first && second;
    }

    /**
     * Returns true if the full period of observed data will be used for climatology,
     * false otherwise.
     *
     * @return true if the full period of observed data will be used for climatology
     */

    public boolean isUseFullClimatology() {
        return useFullClimatology;
    }
    
    /**
     * Returns true if the pairs will be aggregated, i.e. if the requested support
     * of the pairs is greater than their native resolution, false otherwise. For 
     * aggregation to take place, the {@link VerificationUnit#verificationResolution} 
     * and associated units, {@link VerificationUnit#verificationResolutionUnits}, 
     * must be larger than both the observed support and the forecast support, since
     * the pairing process leads to the forecasts and observations having the greater
     * of these two supports as a prerequisite for pairing.
     * 
     * @return true if the pairs will be aggregated, false otherwise, including if unknown
     */

    public boolean willAggregatePairs() {
        if(!hasResolution()) {
            return false;
        }
        boolean aggregate = false;
        //Compute verification resolution in hours
        double vRes = GlobalUnitsReader.getMilliConversionFactor(verificationResolutionUnits);
        vRes = vRes / (1000.0 * 60.0 * 60.0);  //Conversion factor to hours
        vRes = vRes * verificationResolution; //Verification resolution in hours
        //Compare to the observed support
        if (hasSupport(Support.OBSERVED_SUPPORT)) {  //Must have support
            TemporalSupport t = (TemporalSupport) observedSupport;
            //Pairs have point support
            if (t.hasPointSupport()) { 
                //Since verification resolution is set, aggregation is required, 
                //because verification resolution > point support
                aggregate = true;
            } 
            //Pairs have aggregate support: is the verification resolution larger?
            else {
                double period = t.getAggregationPeriod();
                String units = t.getAggregationUnits();
                double factor = GlobalUnitsReader.getMilliConversionFactor(units);
                factor = factor / (1000.0 * 60.0 * 60.0);  //Conversion factor to hours
                period = factor * period;  //Period in hours for pairs
                if (Math.abs(vRes - period) > .00000001) {
                    aggregate = true;
                }
            } 
        }
        //Must also be larger than the forecast support
        if (aggregate && hasSupport(Support.FORECAST_SUPPORT)) { 
            TemporalSupport t = (TemporalSupport) forecastSupport;
            if (t.hasPointSupport()) {
                aggregate = true;  
            }
            else {
                double period = t.getAggregationPeriod();
                String units = t.getAggregationUnits();
                double factor = GlobalUnitsReader.getMilliConversionFactor(units);
                factor = factor / (1000.0 * 60.0 * 60.0);  //Conversion factor to hours
                period = factor * period;  //Period in hours
                if (Math.abs(vRes - period) > .00000001) {
                    aggregate = true;
                } else {
                    aggregate = false;
                }
            }
        } else {
            aggregate = false;
        }
        return aggregate;
    }

    /********************************************************************************
     *                                                                              *
     *                               MUTATOR METHODS                                *
     *                                                                              *
     *******************************************************************************/

    /**
     * Sets the forecast file location ID.
     *
     * @param forecastFileLocationID the forecast file location ID
     */

    public void setForecastFileLocationID(String forecastFileLocationID) {
        if(!StringUtilities.nullEquals(forecastFileLocationID,this.forecastFileLocationID,true)) {
            deletePairedDataSource();
            clearAllMetricResults();
        } 
        if("".equals(forecastFileLocationID)) {
            this.forecastFileLocationID=null;
        } else {
            this.forecastFileLocationID=forecastFileLocationID;
        }       
    }

    /**
     * Sets the forecast file variable ID.
     *
     * @param forecastFileVariableID the forecast file variable ID
     */

    public void setForecastFileVariableID(String forecastFileVariableID) {
        if(!StringUtilities.nullEquals(forecastFileVariableID,this.forecastFileVariableID,true)) {
            deletePairedDataSource();
            clearAllMetricResults();
        }
        if("".equals(forecastFileVariableID)) {
            this.forecastFileVariableID=null;
        } else {
            this.forecastFileVariableID=forecastFileVariableID;
        }
    }    
    
    /**
     * Sets the observed file location ID.
     *
     * @param observedFileLocationID the observed file location ID
     */

    public void setObservedFileLocationID(String observedFileLocationID) {
        if(!StringUtilities.nullEquals(observedFileLocationID,this.observedFileLocationID,true)) {
            deletePairedDataSource();
            clearAllMetricResults();
        } 
        if("".equals(observedFileLocationID)) {
            this.observedFileLocationID=null;
        } else {
            this.observedFileLocationID=observedFileLocationID;
        }
    }

    /**
     * Sets the observed file variable ID.
     *
     * @param observedFileVariableID the observed file variable ID
     */

    public void setObservedFileVariableID(String observedFileVariableID) {
        if(!StringUtilities.nullEquals(observedFileVariableID,this.observedFileVariableID,true)) {
            deletePairedDataSource();
            clearAllMetricResults();
        } 
        if("".equals(observedFileVariableID)) {
            this.observedFileVariableID=null;
        } else {
            this.observedFileVariableID=observedFileVariableID;
        }
    }       
    
    /**
     * Set the flag for using the full set of observed data for climatology and
     * not just the paired observations.
     *
     * @param useFullClimatology is true to use the full observed record as climatology
     */

    public void setUseFullClimatology(boolean useFullClimatology) {
        if(!useFullClimatology==this.useFullClimatology) {
            clearAllMetricResults();
        }
        this.useFullClimatology = useFullClimatology;
    }

    /**
     * Sets the location ID.
     *
     * @param locationID the location ID
     */

    public void setLocationID(String locationID) throws IllegalArgumentException {
        if(locationID == null || locationID.equals("")) {
            throw new IllegalArgumentException("Enter a location ID for unit "+toString());
        }
        if(locationID.indexOf(sepChar)>-1) {
            throw new IllegalArgumentException("The location ID for "+toString()+"  contains an illegal character ["+sepChar+"].");
        }
        this.locationID = locationID;
    }

    /**
     * Sets the variable ID.
     *
     * @param variableID the variable ID
     */

    public void setVariableID(String variableID) throws IllegalArgumentException {
        if(variableID == null || variableID.equals("")) {
            throw new IllegalArgumentException("Enter a variable ID for "+toString());
        }
        if(variableID.indexOf(sepChar)>-1) {
            throw new IllegalArgumentException("The variable ID for "+toString()+" contains an illegal character ["+sepChar+"].");
        }
        this.variableID = variableID;
    }

    /**
     * Sets an additional ID associated with the verification unit.
     *
     * @param additionalID the additional ID
     */

    public void setAdditionalID(String additionalID) throws IllegalArgumentException {
        if(additionalID == null) {
            throw new IllegalArgumentException("Enter a valid additional identifier for "+toString());
        }
        if(additionalID.indexOf(sepChar)>-1) {
            throw new IllegalArgumentException("The additional ID for "+toString()+" contains an illegal character ["+sepChar+"].");
        }
        this.additionalID = additionalID;
    }

    /**
     * Sets the forecast data source.
     *
     * @param forecastData the forecast data source
     */

    public void setForecastData(DataSource forecastData) {
        if(! forecastData.equals(this.forecastData)) {
            deletePairedDataSource();
            clearAllMetricResults();
        }
        this.forecastData = forecastData;
    }

    /**
     * Sets the observed data source.
     *
     * @param observedData the observed data source
     */

    public void setObservedData(DataSource observedData) {
        if(! observedData.equals(this.observedData)) {
            deletePairedDataSource();
            clearAllMetricResults();
        }
        this.observedData = observedData;
    }

    /**
     * Sets the time system for the forecasts
     *
     * @param forecastTimeSystem the forecast time system
     */

    public void setForecastTimeSystem(TimeZone forecastTimeSystem) throws IllegalArgumentException {
        if(! forecastTimeSystem.equals(this.forecastTimeSystem)) {
            deletePairedDataSource();
            clearAllMetricResults();
        }
        this.forecastTimeSystem = forecastTimeSystem;
    }

    /**
     * Sets the time system for the observations
     *
     * @param observedTimeSystem the observed time system
     */

    public void setObservedTimeSystem(TimeZone observedTimeSystem) throws IllegalArgumentException {
        if(! observedTimeSystem.equals(this.observedTimeSystem)) {
            deletePairedDataSource();
            clearAllMetricResults();
        }
        this.observedTimeSystem = observedTimeSystem;
    }

    /**
     * Sets the forecast lead time.
     *
     * @param firstTime the first lead time
     * @param lastTime the last lead time
     * @param leadUnits the forecast lead time units
     */

    public void setLeadTimes(double firstTime, double lastTime, String leadUnits) throws IllegalArgumentException {
        if(lastTime<firstTime) {
            throw new IllegalArgumentException("The last lead time must be greater than or equal to the first lead time for "+toString());
        }
        GlobalUnitsReader.isSupportedTimeUnit(leadUnits,true);
        if(lastTime != this.lastTime || firstTime != this.firstTime ||
                !leadUnits.equals(this.leadUnits)) {
            deletePairedDataSource();
            clearAllMetricResults();
        }
        //Check for consistency with verification resolution, if set
        if(hasResolution()) {
            //Check that the verification resolution is consistent with the lead-time specification
            //Compute the number of milliseconds equivalent of the units
            double maxLead = GlobalUnitsReader.getMilliConversionFactor(leadUnits);
            maxLead = maxLead / (1000.0 * 60.0 * 60.0);  //Conversion factor to hours
            maxLead = maxLead * lastTime;  //Max lead time in hours
            double vRes = GlobalUnitsReader.getMilliConversionFactor(verificationResolutionUnits);
            vRes = vRes / (1000.0 * 60.0 * 60.0);  //Conversion factor to hours
            vRes = vRes * verificationResolution; //Verification resolution in hours
            if(vRes > maxLead) {
                throw new IllegalArgumentException("The verification resolution cannot be greater than the maximum forecast lead time considered.");
            }
        }
        this.firstTime = firstTime;
        this.lastTime = lastTime;
        this.leadUnits = leadUnits;
    }

    /**
     * Sets the verification resolution.
     *
     * @param verificationResolution the verification timestep
     * @param verificationResolutionUnits the temporal units
     */

    public void setResolution(int verificationResolution, String verificationResolutionUnits) throws IllegalArgumentException {
        checkValueCondition(verificationResolution,verificationResolutionUnits);
        if(verificationResolution <0) {
            throw new IllegalArgumentException("Enter a positive timestep for the temporal resolution of "+toString());
        }
        //Check for consistency with forecast lead time, if set
        if(hasLeadTimes()) {
            //Check that the verification resolution is consistent with the lead-time specification
            //Compute the number of milliseconds equivalent of the units
            double maxLead = GlobalUnitsReader.getMilliConversionFactor(getForecastLeadTimeUnits());
            maxLead = maxLead / (1000.0 * 60.0 * 60.0);  //Conversion factor to hours
            maxLead = maxLead * lastTime;  //Max lead time in hours
            double vRes = GlobalUnitsReader.getMilliConversionFactor(verificationResolutionUnits);
            vRes = vRes / (1000.0 * 60.0 * 60.0);  //Conversion factor to hours
            vRes = vRes * verificationResolution; //Verification resolution in hours
            if(vRes > maxLead) {
                throw new IllegalArgumentException("The verification resolution cannot be greater than the maximum forecast lead time considered.");
            }
        }
        GlobalUnitsReader.isSupportedTimeUnit(verificationResolutionUnits,true);
        if(verificationResolution!=this.verificationResolution ||
                !verificationResolutionUnits.equals(this.verificationResolutionUnits)) {
            clearAllMetricResults();
            //If raw pairs are aggregated pairs, remove them, as the change invalidates them
            if(storeRawPairsInAggregatedRes) {
                System.out.println("Deleting raw pairs, as they are aggregated, and the verification resolution has changed.");
                deletePairedDataSource();
            }
        }
        this.verificationResolution = verificationResolution;
        this.verificationResolutionUnits = verificationResolutionUnits;
    }

    /**
     * Sets the time of day in hours (UTC) at which temporal aggregation will
     * begin.  Must be an integer in the range [0,23] or null.
     *
     * @param aggregationStartTime the start time for aggregation or null
     */

    public void setAggregationStartHourUTC(Integer aggregationStartTime)
            throws IllegalArgumentException {
        if(aggregationStartTime!=null) {
            if(aggregationStartTime > 23 || aggregationStartTime < 0) {
                throw new IllegalArgumentException("Start time for temporal aggregation must fall within [0,23] UTC: "+aggregationStartTime+".");
            }
        }
        this.aggregationStartTime=aggregationStartTime;
        //One null and the other not
        if((aggregationStartTime==null && this.aggregationStartTime!=null)
        		|| aggregationStartTime!=null && this.aggregationStartTime==null //Both either null or not null after this check 
        		|| (aggregationStartTime!=null && 
        		!aggregationStartTime.equals(this.aggregationStartTime))) {
            //JB@10th December 2012
            if(storeRawPairsInAggregatedRes) {
        	System.out.println("Deleting raw pairs, as they are aggregated, and the time of day at which to begin aggregation has changed.");
                deletePairedDataSource();  
            }
            clearAllMetricResults();        	
        }
    }
    
    /**
     * Sets the first lead time at which temporal aggregation will begin.  
     *
     * @param aggregationStartLeadHour the first lead time for aggregation or null
     */

    public void setAggregationStartLeadHour(Double aggregationStartLeadHour)
            throws IllegalArgumentException {
        this.aggregationStartLeadHour=aggregationStartLeadHour;
        //One null and the other not
        if((aggregationStartLeadHour==null && this.aggregationStartLeadHour!=null)
        		|| aggregationStartLeadHour!=null && this.aggregationStartLeadHour==null //Both either null or not null after this check 
        		|| (aggregationStartLeadHour!=null && 
        		!aggregationStartLeadHour.equals(this.aggregationStartLeadHour))) {
            //JB@10th December 2012
            if(storeRawPairsInAggregatedRes) {
        	System.out.println("Deleting raw pairs, as they are aggregated, and the lead time at which to begin aggregation has changed.");
                deletePairedDataSource();  
            }
            clearAllMetricResults();        	
        }
    }    
    
    /**
     * Sets the first lead time at which pairing will begin. Deprecated as of
     * 5.0. Use the first lead time of the verification window instead.
     *
     * @param pairedStartLeadHour the first lead time or null
     * @deprecated 
     */

    public void setPairedStartLeadHour(Double pairedStartLeadHour)
            throws IllegalArgumentException {
        this.pairedStartLeadHour=pairedStartLeadHour;
        //One null and the other not
        if((pairedStartLeadHour==null && this.pairedStartLeadHour!=null)
        		|| pairedStartLeadHour!=null && this.pairedStartLeadHour==null //Both either null or not null after this check 
        		|| (pairedStartLeadHour!=null && 
        		!pairedStartLeadHour.equals(this.pairedStartLeadHour))) {
        	deletePairedDataSource();  
        	clearAllMetricResults();        	
        }
    }       
    
    /**
     * Sets the fraction of pairs required at each lead time for that lead time
     * to be included in the verification results. The fraction falls in [0,1] and
     * is relative to the average number of pairs found across all lead times after
     * applying all conditions and any temporal aggregation.  For example, 0.5
     * implies that any lead time with fewer than 50% of the average number of pairs
     * across all lead times will be eliminated.
     *
     * @param sampleSizeConstraint the sample size fraction
     */

    public void setSampleSizeConstraint(double sampleSizeConstraint) {
        if(sampleSizeConstraint<0 || sampleSizeConstraint > 1) {
            throw new IllegalArgumentException("Sample size constraint must be a fraction in [0,1]: "+sampleSizeConstraint+" is not allowed.");
        }
        this.sampleSizeConstraint = sampleSizeConstraint;
    }

    /**
     * Sets an aggregation unit associated with this verification unit.  
     *
     * @param aggregation the aggregation unit
     */

    public void addAggregationUnit(AggregationUnit aggregation) throws IllegalArgumentException {
        if(aggregation == null) {
            throw new IllegalArgumentException("Specify a non-null aggregation unit.");
        }
        //if(! aggregation.containsUnit(this)) {
        //    throw new IllegalArgumentException("Attempted to set an aggregation unit that does not contain this verification unit '"+this+"'.");
        //}
        this.aggregation.add(aggregation); //JB @ 11th March 2013
    }

    /**
     * Sets the verification period with a start and end date.  Throws an exception
     * if the dates are illogical or some more specific date conditions already
     * exist and conflict.
     *
     * @param start the start date
     * @param end the end date
     */

    public void setDates(Calendar start, Calendar end) throws IllegalArgumentException {
        if(start == null || end == null) {
            setStartDate(start);
            setEndDate(end);
        }
        else {
            checkDateCondition(start,end);
            checkValueCondition(start,end);
            if(start.getTimeInMillis()>=end.getTimeInMillis()) {
                throw new IllegalArgumentException("End date must occur after the start date for "+toString());
            }
            Calendar st = this.start;
            Calendar en = this.end;
            try {
                setStartDate(start);
                setEndDate(end);
            }
            catch(IllegalArgumentException e) {
                this.start = st;
                this.end = en;
                throw e;
            }
        }
    }

    /**
     * Sets the verification start date.  Throws an exception if the date occurs
     * on or after an existing end date or if some more specific date conditions
     * already exist and conflict.
     *
     * @param start the start date
     */

    public void setStartDate(Calendar start) throws IllegalArgumentException {
        if(start == null) {
            deleteStartDate();
        }
        else {
            checkDateCondition(start,this.end);
            checkValueCondition(start,this.end);
            if(end != null && start.getTimeInMillis()>=this.end.getTimeInMillis()) {
                end = null;
                //Exception is too inflexible here, as one or other of start and end need to
                //be set first
                System.out.println("Removed end date due to conflict with start date.");
            }
            if(! start.equals(this.start)) {
                deletePairedDataSource();
                clearAllMetricResults();
            }
            //Create a copy
            Calendar c = Calendar.getInstance();
            c.clear();
            c.setTimeZone(start.getTimeZone());
            c.setTimeInMillis(start.getTimeInMillis());
            this.start = c;
        }
    }

    /**
     * Sets the verification end date.  Throws an exception if the date occurs
     * on or before an existing start date or if some more specific date conditions
     * already exist and conflict.
     *
     * @param end the end date
     */

    public void setEndDate(Calendar end) throws IllegalArgumentException {
        if(end == null) {
            deleteEndDate();
        }
        else {
            checkDateCondition(this.start,end);
            checkValueCondition(this.start,end);
            if(start != null && end.getTimeInMillis()<=this.start.getTimeInMillis()) {
                start = null;
                //Exception is too inflexible here, as one or other of start and end need to
                //be set first
                System.out.println("Removed start date due to conflict with start date.");
            }
            if(! end.equals(this.end)) {
                deletePairedDataSource();
                clearAllMetricResults();
            }
            this.end = end;
        }
    }

    /**
     * Associates a date condition with the current verification unit.
     *
     * @param dateCondition the date condition
     */

    public void setDateCondition(DateCondition dateCondition) throws IllegalArgumentException {
        dateCondition.canApplyCondition(this,true);
        if(! dateCondition.equals(this.dateCondition)) {
            clearAllMetricResults();
        }
        this.dateCondition = dateCondition;
    }

    /**
     * Associates a value condition with the current verification unit.  Appends
     * to other value conditions or overwrites an existing condition with the
     * same verification unit identifier and data type.
     *
     * @param valueCondition the value condition
     */

    public void setValueCondition(ValueCondition valueCondition) throws IllegalArgumentException {
        valueCondition.canApplyCondition(this,true);
        //Add condition
        int type = valueCondition.getConditionType();
        String id = valueCondition.getVerificationUnitID();
        int replace = -1;
        int length = valueConditions.size();
        for(int i = 0; i < length; i++) {
            if(valueConditions.get(i).getConditionType()==type && valueConditions.get(i).getVerificationUnitID().equals(id)) {
                replace = i;
                break;
            }
        }
        if(replace > -1) {
            valueConditions.set(replace,valueCondition);
            if(!valueConditions.get(replace).equals(valueCondition)) {
                clearAllMetricResults();
            }
        } else {
            valueConditions.add(valueCondition);
            clearAllMetricResults();
        }
    }

    /**
     * Associates a set of value conditions with the current verification unit.
     * Appends to other value conditions or overwrites an existing condition with the
     * same verification unit identifier and data type.
     *
     * @param valueConditions the value conditions
     */

    public void setValueConditions(Vector<ValueCondition> valueConditions) throws IllegalArgumentException {
        int length = valueConditions.size();
        for(int i = 0; i < length; i++) {
            setValueCondition(valueConditions.get(i));
        }
    }

    /**
     * Sets the temporal aggregation function associated with a verification
     * unit.
     *
     * @param tempAggFunc the temporal aggregation function
     */

    public void setTemporalAggFunc(VectorFunction tempAggFunc) throws IllegalArgumentException {
        if(tempAggFunc == null) {
            throw new IllegalArgumentException("Cannot define a null function for temporal aggregation.");
        }
        if(! tempAggFunc.equals(this.tempAggFunc)) {
            clearAllMetricResults();
        }
        this.tempAggFunc = tempAggFunc;
    }

    /**
     * Set true to write the conditional pairs to file.
     *
     * @param writeConditionalPairs is true to write the conditional pairs to file
     */

    public void setWriteConditionalPairs(boolean writeConditionalPairs) {
        this.writeConditionalPairs = writeConditionalPairs;
    }
    
    /**
     * Set true to write the raw pairs to file.
     *
     * @param writeUnconditionalPairs is true to write the raw pairs to file
     */

    public void setWriteUnconditionalPairs(boolean writeUnconditionalPairs) {
        this.writeUnconditionalPairs = writeUnconditionalPairs;
    }    

    /**
     * Sets the indicator to store pairs in an aggregated resolution if the 
     * {@link VerificationUnit#verificationResolution} exceeds the greater of 
     * the observed or forecast support, false otherwise. 
     * 
     * @param storeRawPairsInAggregatedRes 
     */

    public void setStoreRawPairsInAggregatedRes(boolean storeRawPairsInAggregatedRes) {
        this.storeRawPairsInAggregatedRes = storeRawPairsInAggregatedRes;
        if(storeRawPairsInAggregatedRes !=this.storeRawPairsInAggregatedRes) {
            System.out.println("Deleting raw pairs as the option to store the raw pairs in their native or aggregated resolution has changed.");
            deletePairedDataSource();   
            clearAllMetricResults();
        }
    }
    
   /**
     * Sets the time system for the verification window. If the input is true, the
     * forecast valid time is used, otherwise the issue/basis time is used. By 
     * definition, observations are always in valid time. Pairs and forecasts 
     * may be in issue time/basis time.
     * 
     * @param verifWindowInValidTime is true to set the verification window to forecast valid time, false to use issue/basis time
     */

    public void setVerifWindowInValidTime(boolean verifWindowInValidTime) {
        this.verifWindowInValidTime = verifWindowInValidTime;
    }
    
    /**
     * Sets the support information associated with the forecasts or observations.
     * See the evs.analysisunits.scale.Support class for identifiers.
     *
     * @param id the identifier
     * @param support the support
     */

    public void setSupport(int id, TemporalSupport support) {
        if(support == null) {
            throw new IllegalArgumentException("Specify valid support information for "+toString());
        }
        if(hasUsableAggregationUnit()) {
            if(!(support.equals(getSupport(id))) ) {
                throw new IllegalArgumentException("Changing the support of verification unit "+toString()+" will compromise an existing aggregation unit.  Delete the aggregation unit first.");
            }
        }
        switch(id) {
            case Support.FORECAST_SUPPORT: {
                //JB @ 28th May 2013: allow for a change in measurement units, but otherwise
                //delete pairs on a change of support                
                if(forecastSupport != null && !forecastSupport.equalsExceptMeasUnits(support)) {
                    //Must delete paired source here, because pairing may take place
                    //on reading data initially, using support defined at that time
                    deletePairedDataSource();
                    clearAllMetricResults();
                }
                forecastSupport = support;
            }; break;
            case Support.OBSERVED_SUPPORT: {
                //JB @ 28th May 2013: allow for a change in measurement units, but otherwise
                //delete pairs on a change of support
                if(observedSupport != null && !observedSupport.equalsExceptMeasUnits(support)) {
                    //Must delete paired source here, because pairing may take place
                    //on reading data initially, using support defined at that time
                    deletePairedDataSource();
                    clearAllMetricResults();
                }
                observedSupport = support;
            }; break;
            default: {
                throw new IllegalArgumentException("Unrecognized idenfifier for support information for "+toString());
            }
        }
    }

    /**
     * Sets a paired data source, removing any existing pairs if the input data
     * source differs from the stored data source.
     *
     * @param pairedSource the data source
     */

    public void setPairedDataSource(PairedDataSource pairedSource) {
        //Delete the pairs if a source was previously defined and does not
        //equal the input source
        if(this.pairedSource != null && !pairedSource.equals(this.pairedSource)) {
            deletePairedDataSource();
            clearAllMetricResults();
        }
        this.pairedSource = pairedSource;
    }

    /**
     * Sets the observed file type. Throws an exception if the type is not
     * supported.  See {@link evs.data.fileio.FileIO} for supported types.
     *
     * @param observedFileType the observed file type
     */

    public void setObservedFileType(int observedFileType) throws IllegalArgumentException {
        if(!FileIO.isSupportedObservedFileType(observedFileType)) {
            throw new IllegalArgumentException("Unrecognized file type identifier for "
                    + "the observations.");
        }
        this.observedFileType = observedFileType;
    }

    /**
     * Sets the forecast file type. Throws an exception if the type is not
     * supported.  See {@link evs.data.fileio.FileIO} for supported types.
     *
     * @param forecastFileType the forecast file type
     */

    public void setForecastFileType(int forecastFileType) throws IllegalArgumentException {
        if(!FileIO.isSupportedForecastFileType(forecastFileType)) {
            throw new IllegalArgumentException("Unrecognized file type identifier for "
                    + "the forecasts.");
        }
        this.forecastFileType = forecastFileType;
    }

    /**
     * Sets the null value associated with the unit. For simplicity in checking
     * for equality throughout the code, NaN and infinite values are not allowed.
     *
     * @param nullValue the null value
     */
    
    public void setNullValue(double nullValue) throws IllegalArgumentException {
        if(Double.isNaN(nullValue)) {
            throw new IllegalArgumentException("The NaN identifier cannot be used for missing values.");
        }
        if(Double.isInfinite(nullValue)) {
            throw new IllegalArgumentException("The missing value identifier must be finite.");
        }
        this.nullValue = nullValue;
    } 
    
    /**
     * Attempts to compute a set of metrics associated with a verification unit.
     * Computes the paired forecasts and observations first if these have not been
     * precomputed.  Throws an exception if the pairs could not be generated or if
     * valid metrics have not been defined.  Returns true if successful, false
     * otherwise.
     *
     * @param ref a vector of reference forecasts (may be null)
     * @return true if the metrics were generated successfully
     */

    public boolean computeMetrics(Vector<VerificationUnit> ref) throws IllegalArgumentException {

        computeErrors = null;
        if(!hasMetrics()) {
            throw new IllegalArgumentException("No metrics have been associated with verification unit '"+toString()+"'.");
        }

        //Check for any required reference forecasts
        Vector<String> sref = new Vector<String>();
        if(ref != null) {
            int t = ref.size();
            for (int i = 0; i < t; i++) {
                sref.add(ref.get(i).toString());
            }
        }
        Iterator j = metrics.keySet().iterator();
        while(j.hasNext()) {
            Metric m = metrics.get(j.next());
            if(m instanceof SkillScore) {
                SkillScore s = (SkillScore)m;
                ReferenceForecastParameter p = s.getRefFcst();
                if (!p.isSampleClimatology()) {
                    String r = p.getParVal();
                    if (sref.size() == 0) {
                        throw new IllegalArgumentException("Specify the required reference forecasts for skill calculations.");
                    }
                    if (!sref.contains(r)) {
                        throw new IllegalArgumentException("Cannot find the reference forecast with unique ID: '." + r + "'.");
                    }
                }
            }
        }

        Iterator i = metrics.keySet().iterator();
        boolean returnMe = true;

        //Reset progress
        progress.reset();
        if(willBootstrap()) {
            progress.display(this+". Percent complete: ", 5);
        }

        //Determine if bootstrapping is required and weight the progress fraction for metric calculation
        //accordingly
        if(willBootstrap()) {
            pairIOFrac = 0.25;
        }

        //Local reference to pairs: read once only!!
        //Reference forecasts are also pre-read, requiring more memory, but increasing
        //the calculation speed.
        PairedData pairsCond = getConditionedPairs(true);
        PairedData pairsUncond = null;
        TreeMap<String,PairedData> refPairsUncond = new TreeMap<String,PairedData>();
        TreeMap<String,PairedData> refPairsCond = new TreeMap<String,PairedData>();

        lastPairFirstLeadCount=pairsCond.getPairCount(pairsCond.getFirstLeadTime());  //Set temporary reference to paired data
        //Pairs to use when unconditional pairs in terms of value conditions requested for a particular metric
        if(hasValueConditions()) {
            pairsUncond = getConditionedPairs(false);
        }

        //Write the conditional pairs if required
        if(writeConditionalPairs) {
            try {
                writePairs(pairsCond);
            } catch(Exception e) {
                throw new IllegalArgumentException(e.getMessage());
            }
        }

        //Assign processing time evenly to metric calculation
        int length = metrics.size();
        double inc = ((1.0-pairIOFrac)*100) / length;
        progress.setIncrement(inc);

        //Iterate through the metrics and compute each one
        Vector<Metric> sharedBootstrap = new Vector<Metric>();
        int bDone = 0; //Number of metrics bootstrapped without a shared sample
        while(i.hasNext()&&!progress.isStopped()) {
            try {
                long start = System.currentTimeMillis();
                Object key = i.next();
                Metric m = metrics.get(key);
                boolean skill = m.isSkillMetric();
                //Set the reference pairs
                PairedData refPairs = null; //Reference forecasts for skill
                if(skill) {
                    //Reference forecasts are the same for all thresholds, just get the first.
                    SkillScore sm = null;
                    if (m instanceof SkillScore) {
                        sm = (SkillScore)m;
                    } else if (m instanceof ThresholdMetricStore) {
                        sm = (SkillScore)((ThresholdMetricStore)m).getFirstMetricInStore();
                    }
                    if (sm != null) {
                        String ra = sm.getRefFcst().getParVal();
                        //Reference forecast: may not always be present (e.g. sample climatology has no VU)
                        if (sref.contains(ra)) {
                            VerificationUnit rf = ref.get(sref.indexOf(ra));
                            //Use unconditional pairs
                            if (rf.hasValueConditions() && ((Metric) m).willIgnoreConditions()) {
                                PairedData p1 = null;
                                if (refPairsUncond.containsKey(rf.toString())) {
                                    p1 = refPairsUncond.get(rf.toString());
                                } else {
                                    System.out.println("Obtaining pairs for reference forecast '" + rf.toString() + "', ignoring value conditions.");
                                    p1 = rf.getConditionedPairs(false);
                                    refPairsUncond.put(rf.toString(), p1);
                                }
                                refPairs=p1;
                            } //Use conditional pairs
                            else {
                                PairedData p2 = null;
                                if (refPairsCond.containsKey(rf.toString())) {
                                    p2 = refPairsCond.get(rf.toString());
                                } else {
                                    System.out.println("Obtaining pairs for reference forecast '" + rf.toString() + "'.");
                                    p2 = rf.getConditionedPairs(true);
                                    refPairsCond.put(rf.toString(), p2);
                                }
                                refPairs=p2;
                            }
                        }
                    }
                }
                //Set the main pairs
                PairedData mainPairs = null;  //Pairs of the numerator in skill or pairs for non-skill
                if (hasValueConditions() && ((Metric) m).willIgnoreConditions()) {
                    mainPairs = pairsUncond;
                } else {
                    mainPairs = pairsCond;
                }

                //Compute the nominal values of the metric
                //Compute the reference forecasts first
                MetricResultByLeadTime reference = null;
                if(refPairs!=null) {
                    //System.out.println("Computing "+m+" for reference forecast.");
                    reference = ((Metric) m).computeByLeadTime(
                            ForecastTypeParameter.REFERENCE_FORECAST,refPairs,null,false);
                }
                ((Metric) m).computeByLeadTime(ForecastTypeParameter.REGULAR_FORECAST,
                        mainPairs,reference,false);
                //Do bootstrap
                //Bootstrap required? If so, skill score requires dependent bootstrap
                if (m.isBootstrap() && m.hasResults()) {
                    boolean isSkill = m.isSkillMetric();
                    if(isSkill && m instanceof SkillScore) {
                        isSkill = !((SkillScore)m).getRefFcst().isSampleClimatology();
                    } else if(isSkill && m instanceof ThresholdMetricStore) {
                        isSkill = !((SkillScore)((ThresholdMetricStore)m).getFirstMetricInStore()).
                                getRefFcst().isSampleClimatology();
                    }
                    if (isSkill) {
                        try {
                            String append = "";
//                            if (threadCount > 1) {
//                                append = "  Conducting parallel processing with " + threadCount + " threads.";
//                            }
                            System.out.println("Performing bootstrapping of skill metric '" + m + "' for unit '" + this + "' "
                                    + "using a separate bootstrap sample." + append);
                            doSkillBootstrap(m, mainPairs, refPairs);
                            System.out.println("Completed bootstrap of skill metric '"+m+"' for unit '"+this+"'.");
                            bDone++;
                        } catch (Exception e) {
                            e.printStackTrace();
                            throw new MetricCalculationException("Error computing bootstrap confidence "
                                    + "intervals for metric '" + m + "' of unit '" + this + "'.");
                        }
                        progress.increment();
                    } else {
                        sharedBootstrap.add(m);
                        //Do not increment progress, as the shared bootstrap will be time-consuming
                        //And the shared bootstrap increments with the remainder
                    }
                } else {
                    progress.increment();
                }
                long stop = System.currentTimeMillis();
                System.out.println("Time taken to compute nominal value of '" +m+"': " + Mathematics.round((stop - start) / 1000.0,1) + " seconds.");
            }
            catch(Exception e) {
                e.printStackTrace();
                computeErrors = computeErrors + StringUtilities.stackTraceToString(e);
                returnMe = false;
            }
        }
        //Perform shared-sample bootstrapping if required
        if(sharedBootstrap.size()>0) {
            try {
                int bTot = sharedBootstrap.size() + bDone;
                String append = "";
                if (threadCount > 1) {
                    append = "  Conducting parallel processing with " + threadCount + " threads.";
                }
                System.out.println("Bootstrapping " + bTot + " of " + metrics.size() + " metrics for "
                        + "unit '"+this+"'. Using a shared sample for "+sharedBootstrap.size()+" "
                        + "of "+bTot+" metrics."+append);
                doSharedBootstrap(sharedBootstrap.toArray(new Metric[sharedBootstrap.size()]),
                        pairsCond,pairsUncond);
                System.out.println("Completed bootstrap of "+bTot+" metrics for "
                        + "unit '"+this+"'.");
            }
            catch(Exception e) {
                e.printStackTrace();
                computeErrors = computeErrors + StringUtilities.stackTraceToString(e);
                returnMe = false;
            }
        }
        return returnMe;
    }

    /**
     * Deletes the support information for the forecasts or observations or both.
     * See evs.analysisunits.scale.Support for the supported types.
     *
     * @param id the identifier
     */

    public void deleteSupport(int id) {
        if(forecastSupport != null && hasUsableAggregationUnit()) {
            throw new IllegalArgumentException("Deleting the support of verification unit "+toString()+" will compromise an existing aggregation unit.  Delete the aggregation unit first.");
        }
        if(hasPairedDataSource()) {
            deletePairedDataSource();
            clearAllMetricResults();
        }
        switch(id) {
            case Support.ALL_SUPPORT: {
                forecastSupport = null;
                observedSupport = null;
            }; break;
            case Support.FORECAST_SUPPORT: {
                forecastSupport = null;
            }; break;
            case Support.OBSERVED_SUPPORT: {
                observedSupport = null;
            }; break;
            default: {
                throw new IllegalArgumentException("Unrecognized idenfifier for removal of support information.");
            }
        }
    }

    /**
     * Deletes any paired observations and forecasts from the current verification
     * unit, together with any reference to a paired data source.
     *
     * @return true if pairs were deleted
     */

    public boolean deletePairedDataSource() {
        boolean returnMe = pairedSource != null;
        if(pairedSource != null) {
            pairedSource.delete();
            System.out.println("Deleted paired data source, either through direct request to delete or following a parameter change.");
        }
        //Delete reference
        deletePairedDataSourceReference();
        return returnMe;
    }

    /**
     * Deletes a reference to a paired data source without deleting the underlying
     * data source.
     */

    public void deletePairedDataSourceReference() {
        pairedSource = null;
        clearAllMetricResults();
    }

    /**
     * Deletes any aggregation units from the current verification unit and updates
     * the associated aggregation units accordingly.  If an aggregation unit contains only
     * one other verification unit, all references to the aggregation unit are
     * removed from the children verification units.
     */

    public void deleteAggregationUnits() {
        AggregationUnit[] aggs = aggregation.toArray(
                new AggregationUnit[aggregation.size()]);
        for(AggregationUnit a : aggs) {
            deleteAndUpdateAggregationUnit(a);
        }
    }    

    /**
     * Deletes an aggregation unit from the current verification unit and updates
     * the aggregation unit accordingly, including any weights associated with the
     * remaining verification units (if applicable).  If the aggregation unit 
     * contains only one other verification unit, all references to the aggregation 
     * unit are removed from the children verification units.
     * 
     * @param agg the aggregation unit to delete
     */

    public void deleteAndUpdateAggregationUnit(AggregationUnit agg) {
        //AU associated with this VU: proceed
        if(aggregation.contains(agg)) {
            //Obtain actual aggregation unit as match is on name only
            AggregationUnit modifyMe = aggregation.get(aggregation.indexOf(agg));         
            //VUs associated with the AU
            if (modifyMe.hasVerificationUnits()) {  //Double check, should not really be needed
                
//JB @ 20th March                
//                ArrayList<VerificationUnit> units = modifyMe.getVerificationUnits();              
//                //Update the weights if there are at least two component VUs
//                //after removing this one from the AU
//                if (units.size() > 2) {
//                    System.out.println("Updating aggregation unit '" + modifyMe + "'.");
//                    //aggregation = null;  //JB @11th March 2013
//                    ArrayList<VerificationUnit> newUnits = new ArrayList<VerificationUnit>();
//                    //Update VUs
//                    for (VerificationUnit v : units) {
//                        if (!v.toString().equals(toString())) {  //JB @11th March 2013
//                            newUnits.add(v);
//                        }
//                    }
//                    //Update aggregation unit: reset weights to default of equal weights
//                    ArrayList<Double> weights = new ArrayList<Double>();
//                    int rows = newUnits.size();
//                    double d = 1.0 / rows;
//                    for(int i = 0; i < rows; i++) {
//                        weights.add(d);
//                    }
//                    //JB @11th March 2013
//                    ArrayList<AggregationUnit> updateMe = newUnits.get(0).aggregation;
//                    int index = updateMe.indexOf(agg);
//                    updateMe.get(index).setVerificationUnits(newUnits, weights);
//                } 
                //Remove this VU from the AU
                modifyMe.deleteVerificationUnit(this,true);                
            }
            //Delete input AU from current VU
            aggregation.remove(agg);
        }
    }

    /**
     * Deletes the verification dates.
     */

    public void deleteDates() throws IllegalArgumentException {
        if(hasValueConditions()) {
            throw new IllegalArgumentException("Removing the verification dates for "+toString()+" will invalidate existing value conditions.  Remove them first.");
        }
        if(hasDateCondition()) {
            throw new IllegalArgumentException("Removing the verification dates for "+toString()+" will invalidate existing date conditions.  Remove them first.");
        }
        start = null;
        end = null;
        deletePairedDataSource();
        clearAllMetricResults();
    }

    /**
     * Deletes the start date.
     */

    public void deleteStartDate() throws IllegalArgumentException {
        if(hasValueConditions()) {
            throw new IllegalArgumentException("Removing the start date for "+toString()+" will invalidate existing value conditions.  Remove them first.");
        }
        if(hasDateCondition()) {
            throw new IllegalArgumentException("Removing the start date for "+toString()+" will invalidate existing date conditions.  Remove them first.");
        }
        start = null;
        deletePairedDataSource();
        clearAllMetricResults();
    }

    /**
     * Deletes the end date.
     */

    public void deleteEndDate() throws IllegalArgumentException {
        if(hasValueConditions()) {
            throw new IllegalArgumentException("Removing the end date for "+toString()+" will invalidate existing value conditions.  Remove them first.");
        }
        if(hasDateCondition()) {
            throw new IllegalArgumentException("Removing the end date for "+toString()+" will invalidate existing date conditions.  Remove them first.");
        }
        end = null;
        deletePairedDataSource();
        clearAllMetricResults();
    }

    /**
     * Removes a date condition associated with the verification unit.
     *
     * @return true if a condition was deleted
     */

    public boolean deleteDateCondition() {
        boolean returnMe = dateCondition !=null;
        dateCondition = null;
        if(returnMe) {
            clearAllMetricResults();
        }
        return returnMe;
    }

    /**
     * Removes a variable value condition associated with the verification unit.
     * Specify the unique identifier of the verification unit and the type of
     * dataset to which the condition applies.
     *
     * @param id the identifier of the verification unit
     * @param type the data type (one of ValueCondition.FORECAST_CONDITION or ValueCondition.OBSERVED_CONDITION)
     * @return true if a condition was deleted
     */

    public boolean deleteValueCondition(String id, int type) {
        boolean returnMe = false;
        int length = valueConditions.size();
        for(int i = 0; i < length; i++) {
            if(valueConditions.get(i).getConditionType()==type && valueConditions.get(i).getVerificationUnitID().equals(id)) {
                valueConditions.remove(i);
                returnMe=true;
                break;
            }
        }
        if(returnMe) {
            clearAllMetricResults();
        }
        return returnMe;
    }
    
    /**
     * Deletes a metric from the array.  Returns true if the metric was deleted 
     * successfully, false otherwise.
     *
     * @param name the metric name
     * @return true if the metric was removed successfully
     */
    
    @Override
    public boolean deleteMetric(String name) {
        if(hasAggregationUnit()) {
            //JB @ 11th March 2013
            for(AggregationUnit a : aggregation) {    
                a.deleteMetric(name);
            }
        }
        return super.deleteMetric(name);
    }       
    
    /**
     * Deletes all metrics from the unit.
     */
    
    @Override
    public void deleteAllMetrics() {
        if (hasAggregationUnit()) {
            Iterator it = metrics.keySet().iterator();
            while (it.hasNext()) {
                String name = it.next().toString();
                //JB @ 11th March 2013
                for (AggregationUnit a : aggregation) {
                    a.deleteMetric(name);
                }
            }
        }
        super.deleteAllMetrics();
    } 
    
    /**
     * Delete the dependencies on the input reference forecast.  If no metrics
     * are defined that depend on the specified reference forecast, nothing is
     * changed and a value of false is returned.  If some metrics are defined
     * that depend on the reference forecast, the specified reference forecast
     * and any associated results are removed.  If no remaining reference
     * forecasts are defined, the metric is removed. In all cases where a change
     * is made, a value of true is returned.
     *
     * @param id the identifier of the reference forecast
     * @return true if a change is made that relates to the reference forecasts
     */

    public boolean deleteReferenceForecast(String id) {
        Object[] keys = metrics.keySet().toArray();
        boolean returnMe = false;
        for(int i = 0; i < keys.length; i++) {
            Metric m = metrics.get((String)keys[i]);
            if (m.isSkillMetric()) {
                if (m instanceof SkillScore) {
                    if (((SkillScore) m).getRefFcst().hasRefForecast(id)) {
                        deleteMetric(m.getName());
                        returnMe = true;
                    }
                } else if (m instanceof ThresholdMetricStore) {
                    SkillScore sk = (SkillScore) ((ThresholdMetricStore) m).getFirstMetricInStore();
                    if (sk.getRefFcst().hasRefForecast(id)) {
                        deleteMetric(m.getName());
                        returnMe = true;
                    }
                }
            }
        }
        return returnMe;
    }
    
    /**
     * Updates any reference forecasts associated with the current VU following
     * a name change in one or more other VUs. Specify a mapping of fully qualified 
     * old VU names (keys) to corresponding new VU names (values). 
     * 
     * @param units the mapping of old VU names (keys) to new VU names (values)
     */
    
    public void updateReferenceForecasts(HashMap<String,String> units) {
        Iterator i = metrics.keySet().iterator();
        String last = "";
        while(i.hasNext()) {
            String metName = (String)i.next();
            Metric m = metrics.get(metName);
            if (m.isSkillMetric()) {
                String refOld = m.getRefFcstID();
                if (units.containsKey(refOld)) {
                    String refNew = units.get(refOld);
                    if (!refOld.equals(refNew)) {
                        String message = "Updating reference forecast for metric "+metName+" of unit " + this + " from " + refOld + " to " + refNew;
                        if (!last.equals(message)) {
                            System.out.println(message);
                        }
                        m.setRefFcst(refNew);
                    }
                }
            }
        }
    }
    
    /**
     * Removes any variable value conditions associated with the verification unit
     * that match the specified unit identifier.  Use this method to remove all conditions
     * on the forecast and observed values for a given unit.
     *
     * @param id the identifier of the verification unit
     * @return true if a condition was deleted
     */

    public boolean deleteValueConditions(String id) {
        return deleteValueCondition(id,ValueCondition.FORECAST_CONDITION) || deleteValueCondition(id,ValueCondition.OBSERVED_CONDITION);
    }

    /**
     * Removes all variable value conditions associated with the verification unit.
     *
     * @return true if a condition was deleted
     */

    public boolean deleteAllValueConditions() {
        boolean removed = valueConditions.size() > 0;
        valueConditions.clear();
        if(removed) {
            clearAllMetricResults();
        }
        return removed;
    }
    
    /**
     * Clears the forecast lead time and associated units.
     */

    public void deleteForecastLeadTimes() {
        boolean delete = true;
        if(firstTime==DEFAULT_INT_VALUE && lastTime == DEFAULT_INT_VALUE) {
            delete = false;
        }
        firstTime = DEFAULT_INT_VALUE;
        lastTime = DEFAULT_INT_VALUE;
        leadUnits = "";
        if(delete) {
            deletePairedDataSource();
            clearAllMetricResults();
        }
    }

    /**
     * Removes reference to a forecast data source.
     */

    public void deleteForecastData() {
        deletePairedDataSource();
        clearAllMetricResults();
        forecastData = null;
    }

    /**
     * Removes reference to an observed data source.
     */

    public void deleteObservedData() {
        deletePairedDataSource();
        clearAllMetricResults();
        observedData = null;
    }

    /**
     * Clears the verification resolution and associated units.
     */

    public void deleteResolution() {
        if(hasValueConditions()) {
            throw new IllegalArgumentException("Removing the verification resolution for "+toString()+" will invalidate existing value conditions.  Remove them first.");
        }
        verificationResolution = DEFAULT_INT_VALUE;
        verificationResolutionUnits = "";
        clearAllMetricResults();
        //If raw pairs are aggregated pairs, remove them, as the change invalidates them
        if (storeRawPairsInAggregatedRes) {
            System.out.println("Deleting raw pairs, as they are aggregated, and the verification resolution has changed.");
            deletePairedDataSource();
        }     
    }

    /**
     * Deletes the time system for the observations
     */

    public void deleteObservedTimeSystem() {
        deletePairedDataSource();
        clearAllMetricResults();
        observedTimeSystem = null;
    }

    /**
     * Deletes the time system for the forecasts
     */

    public void deleteForecastTimeSystem() {
        deletePairedDataSource();
        clearAllMetricResults();
        forecastTimeSystem = null;
    }

    /**
     * Returns true if the input units have equal date and value conditions (or
     * lack thereof), and false otherwise.
     *
     * @param verifUnits the inputs units to check
     * @return true if the date and value conditions are equal
     */

    public static boolean getEqualDateValConds(ArrayList<VerificationUnit> verifUnits) throws IllegalArgumentException {
        if(verifUnits==null || verifUnits.size()==0) {
            throw new IllegalArgumentException("Specify non-null VUs to check for equality of conditions.");
        }
        for(VerificationUnit v : verifUnits) {
            if(v==null) {
                throw new IllegalArgumentException("Specify non-null VUs to check for equality of conditions.");
            }
        }
        if(verifUnits.size()==1) {
            return true;
        }
        VerificationUnit base = verifUnits.get(0);
        int rows = verifUnits.size();
        for (int i = 1; i < rows; i++) {

            //Check the date conditions
            if (verifUnits.get(i).hasDateCondition() != base.hasDateCondition()) {
                return false;
            }
            //Date conditions must be equal
            if (base.hasDateCondition()) {
                if (!verifUnits.get(i).getDateCondition().equals(base.getDateCondition())) {
                    return false;
                }
            }
            //Check the value conditions
            if (verifUnits.get(i).hasValueConditions() != base.hasValueConditions()) {
                return false;
            }
            //Value conditions must be equal
            if (base.hasValueConditions()) {
                if (!verifUnits.get(i).getValueConditions().equals(base.getValueConditions())) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Returns a list of metrics that are not present in all inputs or whose parameter
     * values are not equal across all inputs.  Returns null if all metrics are present
     * for all units and all have equal parameter values.  Throws an exception if
     * metrics have not been set for one or more of the inputs or if one of the inputs
     * is null.
     *
     * @return a list of metrics that are absent in some of the inputs or have unequal parameter values
     */

    public static String[] getUnequalMetrics(ArrayList<VerificationUnit> units) {
        //Store by unique metric name
        TreeMap<String,Vector<Metric>> byMetric = new TreeMap<String,Vector<Metric>>();
        for(VerificationUnit v : units) {
            if(v==null) {
                throw new IllegalArgumentException("Cannot check metrics and parameters: one or more of " +
                        "the input verification units is null.");
            }
            if(!v.hasMetrics()) {
                throw new IllegalArgumentException("Cannot check metrics and parameters: one or more of " +
                        "the input verification units has no metrics associated with it.");
            }
            Vector<Metric> m = v.getMetrics();
            for(Metric n : m) {
                String name;
                if(n instanceof ThresholdMetricStore) {
                    name = ((ThresholdMetricStore)n).getFirstMetricInStore().getName();
                } else {
                    name = n.getName();
                }
                if(byMetric.containsKey(name)) {
                    byMetric.get(name).add(n);
                } else {
                    Vector<Metric> vm = new Vector<Metric>();
                    vm.add(n);
                    byMetric.put(name,vm);
                }
            }
        }
        //Create the list of VUs for which some metrics have not been defined or whose
        //parameter values are unequal
        Iterator it = byMetric.keySet().iterator();
        Vector<String> s = new Vector<String>();
        while(it.hasNext()) {
            String next = (String)it.next();
            Vector<Metric> nm = byMetric.get(next);
            int tot = nm.size();
            if(tot!=units.size()) {
                s.add(next);
            } else {
                for (int i = 1; i < nm.size(); i++) {
                    if (!nm.get(i).paramEquals(nm.get(0),false)) {
                        s.add(next); break;
                    }
                }
            }
        }
        if(s.size()==0) {
            return null;
        }
        return s.toArray(new String[s.size()]);
    }
    
    /**
     * Apply date conditions to the sample climatology before determining 
     * thresholds corresponding to given climatological probabilities. This will
     * not affect the calculation of skill scores with sample climatology as the
     * baseline, as these are based on the paired data by default.
     * 
     * @param applyDateCondToClim is true to apply date conditions to the climatology 
     */    
    
    public void setApplyDateCondToClim(boolean applyDateCondToClim) {
        this.applyDateCondToClim = applyDateCondToClim;
    }
    
    /**
     * Apply date conditions to the sample climatology before determining 
     * thresholds corresponding to given climatological probabilities. This will
     * not affect the calculation of skill scores with sample climatology as the
     * baseline, as these are based on the paired data by default.
     * 
     * @param applyValueCondToClim is true to apply value conditions to the climatology 
     */     

    public void setApplyValueCondToClim(boolean applyValueCondToClim) {
        this.applyValueCondToClim = applyValueCondToClim;
    }       

    /********************************************************************************
     *                                                                              *
     *                              PROTECTED METHODS                               *
     *                                                                              *
     *******************************************************************************/

    /**
     * Checks that all reference forecasts required by the stored metrics are
     * available in the input and throws an exception otherwise.
     *
     * @param ref a vector of reference forecasts (may be null)
     * @return a vector of strings containing the unique identifiers of the reference forecasts
     */

    protected Vector<String> checkRefs(Vector<VerificationUnit> ref) throws IllegalArgumentException {
        //Store reference forecast id's
        Vector<String> sref = new Vector<String>();
        if(ref != null) {
            int t = ref.size();
            for (int i = 0; i < t; i++) {
                sref.add(ref.get(i).toString());
            }
        }
        //Check for any required reference forecasts
        Iterator j = metrics.keySet().iterator();
        while(j.hasNext()) {
            Metric m = metrics.get(j.next());
            if(m.isSkillMetric()) {
                String checkRef = null;
                if(m instanceof SkillScore) {
                    checkRef = ((SkillScore)m).getRefFcst().getParVal();
                } else if(m instanceof ThresholdMetricStore) {
                    checkRef = ((SkillScore)((ThresholdMetricStore)m).getFirstMetricInStore()).getRefFcst().getParVal();
                }
                if(checkRef==null) {
                    throw new IllegalArgumentException("Specify the required reference forecasts for skill calculations.");
                }
                //Check for sample climatology, otherwise throw exception
                if (!ForecastTypeParameter.SAMPLE_CLIMATOLOGY_STRING.equalsIgnoreCase(checkRef)) {
                    if (!sref.contains(checkRef)) {
                        throw new IllegalArgumentException("Cannot find the reference forecast with unique identifier '" + checkRef + "' for unit '" + toString() + "'.");
                    }
                }
            }
        }
        return sref;
    }
    
    /**
     * Removes an aggregation unit from the current verification unit without
     * updating the aggregation unit to reflect the change. This is a convenience
     * method to be called when deleting an aggregation unit, i.e. deleting the
     * reference to that aggregation unit from every verification unit that it 
     * comprises.
     * 
     * @param agg the aggregation unit
     */
    
    protected void blindDeleteAggregationUnit(AggregationUnit agg) {
        aggregation.remove(agg);
    }    
        
    /********************************************************************************
     *                                                                              *
     *                               PRIVATE METHODS                                *
     *                                                                              *
     *******************************************************************************/

    /**
     * Checks whether some variable value conditions have been applied and, if
     * they have and the input verification resolutions do not match, throws
     * an exception.  This method should be called before allowing a
     * CHANGE to verification unit that compromises a set of variable value
     * conditions without deleting those conditions first.
     *
     * @param verificationResolution the verification resolution
     * @param verificationResolutionUnits the verification resolution units
     */

    private void checkValueCondition(int verificationResolution, String verificationResolutionUnits) throws IllegalArgumentException {
        if(valueConditions.size() > 0) {
            if(verificationResolution != this.verificationResolution || ! verificationResolutionUnits.equals(this.verificationResolutionUnits)) {
                throw new IllegalArgumentException("This change will compromise a value condition for '"+toString()+"': delete the value condition first.");
            }
        }
    }

    /**
     * Checks whether some variable value conditions have been applied and throws
     * an exception if they have and the input dates do not match the current dates.
     * This method should be called before allowing a CHANGE to verification unit
     * that compromises a set of variable value conditions without deleting those
     * conditions first.
     *
     * @param start the start date
     * @param end the end date
     */

    private void checkValueCondition(Calendar start, Calendar end) throws IllegalArgumentException {
        if(valueConditions.size() > 0) {
            boolean startEquals = this.start.equals(start);
            boolean endEquals = this.end.equals(end);
            if(! (startEquals && endEquals) ) {
                throw new IllegalArgumentException("The new dates will compromise a value condition for '"+toString()+"': delete the value condition first.");
            }
        }
    }

    /**
     * Checks whether a date condition has been applied and throws
     * an exception if it has and the input start and end dates differ from the
     * existing start and end dates.  This method should be called before allowing a
     * CHANGE to verification unit that compromises a set of variable value
     * conditions without deleting those conditions first.
     *
     * @param start the start date
     * @param end the end date
     */

    private void checkDateCondition(Calendar start, Calendar end) throws IllegalArgumentException {
        if(dateCondition != null) {
            boolean startEquals = this.start.equals(start);
            boolean endEquals = this.end.equals(end);
            if(! (startEquals && endEquals) ) {
                throw new IllegalArgumentException("The new dates will compromise a date condition for '"+toString()+"': delete the date condition first.");
            }
        }
    }

    /**
     * Attempts to write the specified conditional pairs to file.
     *
     * @param pairs the pairs to write
     * @param nV the null value
     */

    private void writePairs(PairedData d) throws IOException {
        if(d!= null) {
            System.out.println("Attempting to write conditioned and/or aggregated pairs.....");
            try {
                String name = ((File)getOutputData().getData()).getCanonicalPath()+
                        System.getProperty("file.separator")+((File)pairedSource.getData()).getName();
                name = name.replaceFirst("(?i)_raw.xml","_cond.xml");
                evs.data.fileio.PairedFileIO.write(new File(name),d,isStripNullMembers(),
                        getPairPrecision(),PairedDataSource.getIOState(),nullValue);
                System.out.println("....pairs written to "+name);
            }
            catch(Exception e) {
                throw new IOException("Failed to write conditioned and/or aggregated pairs: "+e.getMessage());
            }
        }
    }

    /**
     * Performs bootstrap resampling on the input metrics, updating the results
     * with the bootstrap intervals defined in the bootstrap parameter of the
     * metric.  Uses the same samples on all metrics.
     *
     * @param m the metric for which bootstrapping is required
     * @param pairsCond the conditional pairs
     * @param pairsUncond the unconditional pairs
     */

    private void doSharedBootstrap(Metric[] m, PairedData pairsCond, PairedData pairsUncond)
            throws InterruptedException, ExecutionException {
        long start = System.currentTimeMillis();
        Vector<Metric> uncond = new Vector<Metric>();
        Vector<Metric> cond = new Vector<Metric>();
        Vector<BootstrapParameter> uncondBP = new Vector<BootstrapParameter>();
        Vector<BootstrapParameter> condBP = new Vector<BootstrapParameter>();
        int maxSamplesCond = 0;
        int maxSamplesUncond = 0;
        int uncondCount = 0;
        int condCount = 0;
        //Check inputs
        for (int i = 0; i < m.length; i++) {
            BootstrapParameter p = null;
            boolean store = false;
            if (m[i] instanceof BootstrapableMetric) {
                p = ((BootstrapableMetric) m[i]).getBootstrapPar();
            } else if (m[i] instanceof ThresholdMetricStore) {
                store = true;
                p = ((BootstrapableMetric) ((ThresholdMetricStore) m[i]).getFirstMetricInStore()).getBootstrapPar();
            } else {
                throw new IllegalArgumentException("Bootstrap error: cannot bootstrap metric '" + m[i] + "' of unit '" + this + "', "
                        + "as the bootstrap parameter could not be obtained.");
            }
            if(m[i].isSkillMetric()) {
                SkillScore check = null;
                if(store) {
                    check = (SkillScore)((ThresholdMetricStore)m[i]).getFirstMetricInStore();
                } else {
                    check = (SkillScore)m[i];
                }
                if(!check.getRefFcst().isSampleClimatology()) {
                    throw new IllegalArgumentException("Incorrect method call: cannot bootstrap skill metric with shared "
                            + "samples unless the reference forecast is sample climatology.");
                }
            }
            if(m[i].willIgnoreConditions()&&pairsUncond==null) {
                throw new IllegalArgumentException("Expected non-null unconditional pairs when bootstrapping metric '"
                        +m[i]+ "' of unit '"+this+"'.");
            }
            if(m[i].willIgnoreConditions()) {
                if(uncondBP.size()>0) {
                    if(uncondBP.get(0).getNominalBlockSizeInMillis()!=
                            p.getNominalBlockSizeInMillis()) {
                        throw new MetricCalculationException("When computing block bootstrap intervals "
                                + "across multiple metrics, the block size must be constant.");
                    }
                }
                uncondBP.add(p);
                int nextSamples = p.getSampleCount();
                if (nextSamples > maxSamplesUncond) {
                    maxSamplesUncond = nextSamples;
                }
                uncondCount+=1;
                //Create a base metric for computation
                Metric copy = m[i].deepCopy();
                //Clear existing results from the copy
                copy.clearResults();
                uncond.add(copy);
            } else {
                if(condBP.size()>0) {
                    if(condBP.get(0).getNominalBlockSizeInMillis()!=
                            p.getNominalBlockSizeInMillis()) {
                        throw new MetricCalculationException("When computing block bootstrap intervals "
                                + "across multiple metrics, the block size must be constant.");
                    }
                }
                condBP.add(p);
                int nextSamples = p.getSampleCount();
                if (nextSamples > maxSamplesCond) {
                    maxSamplesCond = nextSamples;
                }
                condCount+=1;
                //Create a base metric for computation
                Metric copy = m[i].deepCopy();
                //Clear existing results from the copy
                copy.clearResults();
                cond.add(copy);
            }
        }
        boolean doCond = cond.size()>0;
        boolean doUncond = uncond.size()>0;

        //Determine lead times to process (may not all be available)
        PairedData[] pt = null;
        if(doCond && doUncond) {
            pt = new PairedData[]{pairsUncond,pairsCond};
        } else if(doUncond) {
            pt = new PairedData[]{pairsUncond};
        } else {
            pt = new PairedData[]{pairsCond};
        }
        DoubleMatrix1D leadTimes = PairedData.getUnionOfLeadTimes(pt);

        //Progress increment: use the remaining time, increment after each sample
        int times = leadTimes.getRowCount();
        double remainder = 100.0 - progress.getProgress();
        double startInc = progress.getIncrement();  //Increment that the monitor started with
        double incCond = remainder / (double)(condCount*maxSamplesCond*times);
        double incUncond = remainder /(double)(condCount*maxSamplesUncond*times);

        //Iterate through the samples and obtain a metric result for each one.
        //Bootstrap each lead-time separately to conserve memory.
        TreeMap<Metric,TreeMap<ProbabilityIntervalParameter,MetricResult[]>> intervalsByTime =
                new TreeMap<Metric,TreeMap<ProbabilityIntervalParameter,MetricResult[]>>();
        for (int t = 0; t < times; t++) {
            double time = leadTimes.get(t);
            TreeMap<Integer, PairedData[]> bsIn = null;
            TreeMap<Integer, PairedData[]> bsInWithUncond = null;
            TreeMap<Integer,Vector<MetricResult>> results = 
                    new TreeMap<Integer,Vector<MetricResult>>();
            //Add empty stores
            for (int i = 0; i < m.length; i++) {
                results.put(m[i].getID(), new Vector<MetricResult>());
            }

            //Do conditional first
            if (doCond && pairsCond.hasLeadTime(time)) {
                progress.setIncrement(incCond);
                bsIn = new TreeMap<Integer, PairedData[]>();
                DoubleMatrix2D nextPairs = pairsCond.getPairsByLeadTime(time);
                bsIn.put(ForecastTypeParameter.REGULAR_FORECAST,
                        new PairedData[]{new PairedData(nextPairs,false,nullValue)});

                //Do bootstrap in thread pool
                ExecutorService pool = Executors.newFixedThreadPool(threadCount);
                Collection<Callable<TreeMap<Metric,MetricResult>>> tasks =
                        new ArrayList<Callable<TreeMap<Metric,MetricResult>>>();
                //Construct the bootstrap samples
                for (int i = 0; i < maxSamplesCond; i++) {
                    ArrayList<Metric> ms = new ArrayList<Metric>();
                    for (int j = 0; j < condCount; j++) {
                        if(i<condBP.get(j).getSampleCount()) {
                            ms.add(cond.get(j));
                        }
                    }
                    Bootstrap b = new Bootstrap(bsIn,ms.toArray(
                            new Metric[ms.size()]),false, i > 0,progress);
                    tasks.add(b);
                }

                //Execute the bootstrap and set the results
                try {
                    List<Future<TreeMap<Metric,MetricResult>>> booted =
                            pool.invokeAll(tasks);
                    for(Future<TreeMap<Metric,MetricResult>> next : booted) {
                        TreeMap<Metric,MetricResult> mm = next.get();
                        Iterator it = mm.keySet().iterator();
                        while (it.hasNext()) {
                            Metric me = (Metric)it.next();
                            results.get(me.getID()).add(mm.get(me));
                        }
                    }
                } catch(ProgressStoppedException e) {
                    e.printStackTrace();
                    return;
                } finally {
                    pool.shutdown();
                }
            }
            //Do unconditional next
            if (doUncond && pairsUncond.hasLeadTime(time)) {
                progress.setIncrement(incUncond);
                bsInWithUncond = new TreeMap<Integer, PairedData[]>();
                DoubleMatrix2D nextPairs = pairsUncond.getPairsByLeadTime(time);
                bsInWithUncond.put(ForecastTypeParameter.REGULAR_FORECAST, 
                        new PairedData[]{new PairedData(nextPairs,false,nullValue)});
                //Do bootstrap in thread pool
                ExecutorService pool = Executors.newFixedThreadPool(threadCount);
                Collection<Callable<TreeMap<Metric,MetricResult>>> tasks =
                        new ArrayList<Callable<TreeMap<Metric,MetricResult>>>();
                //Construct the bootstrap samples
                for (int i = 0; i < maxSamplesUncond; i++) {
                    ArrayList<Metric> ms = new ArrayList<Metric>();
                    for (int j = 0; j < uncondCount; j++) {
                        if(i<uncondBP.get(j).getSampleCount()) {
                            ms.add((Metric)uncond.get(j));
                        }
                    }
                    Bootstrap b = new Bootstrap(bsInWithUncond,ms.toArray(
                            new Metric[ms.size()]),false, i > 0,progress);
                    tasks.add(b);
                }

                //Execute the bootstrap and set the results
                try {
                    List<Future<TreeMap<Metric,MetricResult>>> booted =
                            pool.invokeAll(tasks);
                    for(Future<TreeMap<Metric,MetricResult>> next : booted) {
                        TreeMap<Metric,MetricResult> mm = next.get();
                        Iterator it = mm.keySet().iterator();
                        while (it.hasNext()) {
                            Metric me = (Metric)it.next();
                            results.get(me.getID()).add(mm.get(me));
                        }
                    }
                } catch(ProgressStoppedException e) {
                    e.printStackTrace();
                    return;
                } finally {
                    pool.shutdown();
                }
            }
            //Prepare the intervals for the current time
            for(Metric nextMet : m) {
                Vector<MetricResult> r = results.get(nextMet.getID());
                MetricResult[] nxR = r.toArray(new MetricResult[r.size()]);
                BootstrapParameter bp = null;
                if (nextMet instanceof BootstrapableMetric) {
                    bp = ((BootstrapableMetric) nextMet).getBootstrapPar();
                } else {
                    bp = ((BootstrapableMetric) ((ThresholdMetricStore) nextMet).
                            getFirstMetricInStore()).getBootstrapPar();
                }
                try {
                    //Compute the intervals for the current time
                    TreeMap<ProbabilityIntervalParameter, MetricResult[]> nextIntervals =
                            r.get(0).getIntervalsFromResults(bp.getIntervals(),
                            nxR, getNullValue(), bp.getMinSampleCount());
                    //Prior times computed: append
                    if (intervalsByTime.containsKey(nextMet)) {
                        System.out.println("Updating interval for metric '"+nextMet+"': adding time "+time+".");
                        TreeMap<ProbabilityIntervalParameter, MetricResult[]> nn = intervalsByTime.get(nextMet);
                        //Add the new time for each interval
                        Iterator timeIt = nn.keySet().iterator();
                        while (timeIt.hasNext()) {
                            ProbabilityIntervalParameter nI = (ProbabilityIntervalParameter) timeIt.next();
                            MetricResult[] existingBound = nn.get(nI);
                            MetricResultByLeadTime lower = (MetricResultByLeadTime) existingBound[0];
                            MetricResultByLeadTime upper = (MetricResultByLeadTime) existingBound[1];
                            MetricResultByLeadTime samples = (MetricResultByLeadTime) existingBound[2];
                            //Add new times
                            MetricResult[] currentBound = nextIntervals.get(nI);
                            lower.addResult(time, ((MetricResultByLeadTime) currentBound[0]).getResult(time));
                            upper.addResult(time, ((MetricResultByLeadTime) currentBound[1]).getResult(time));
                            samples.addResult(time, ((MetricResultByLeadTime) currentBound[2]).getResult(time));
                        }
                    } //No prior times computed: add new
                    else {
                        System.out.println("Updating interval for metric '"+nextMet+"': adding time "+time+".");
                        intervalsByTime.put(nextMet, nextIntervals);
                    }
                } catch (SamplingIntervalException e) {
                    System.err.println("Unable to compute the sampling interval for metric '"+nextMet+"' of unit '" + toString() + "' at "
                            + "lead time: " + time + ".  " + System.getProperty("line.separator") + e.getMessage());
                }
            }
        }
        //Set the new intervals for each metric across all lead times
        for(Metric nx: m) {
            int fType = ForecastTypeParameter.REGULAR_FORECAST;
            //Skill metric with sample climatology
            if (nx.isSkillMetric()) {
                fType = ForecastTypeParameter.SKILL;
            }
            BootstrapParameter bp = null;
            if (nx instanceof BootstrapableMetric) {
                bp = ((BootstrapableMetric) nx).getBootstrapPar();
            } else {
                bp = ((BootstrapableMetric) ((ThresholdMetricStore) nx).
                        getFirstMetricInStore()).getBootstrapPar();
            }
            MetricResultByLeadTime addToMe = (MetricResultByLeadTime)nx.getResult(fType);
            try {
                if(intervalsByTime.containsKey(nx)) {
                    addToMe.addSamplingIntervals(intervalsByTime.get(nx),bp.getMainInterval());
                    nx.setResult(fType,addToMe);
                }
            } catch(SamplingIntervalException e) {
                e.printStackTrace();
                throw new SamplingIntervalException("Failed to process sampling interval for metric '"+nx+
                        "' of verification unit '"+this+"'.  " + System.getProperty("line.separator")+
                        e.getMessage());
            }
        }
        if(startInc>0) {
            progress.setIncrement(startInc);
        }
        long stop = System.currentTimeMillis();
        System.out.println("Time taken for bootstrapping: " + Mathematics.round((stop - start) / 60000.0,1) + " minutes.");
    }

    /**
     * Performs bootstrap resampling on the input skill metric, updating the results
     * with the bootstrap intervals defined in the bootstrap parameter of the
     * metric.
     *
     * @param m the skill metric for which bootstrapping is required
     * @param mainPairs the main pairs
     * @param refPairs the pairs associated with a reference forecast for a skill metric (may be null)
     */

    private void doSkillBootstrap(Metric m, PairedData mainPairs, PairedData refPairs) {
        BootstrapParameter bp = null;
        if(!m.isSkillMetric()) {
            throw new IllegalArgumentException("Bootstrap error: cannot bootstrap the non-skill metric '"+m+"' with a skill bootstrap.");
        }
        if (m instanceof BootstrapableMetric) {
            bp = ((BootstrapableMetric) m).getBootstrapPar();
        } else if (m instanceof ThresholdMetricStore) {
            bp = ((BootstrapableMetric) ((ThresholdMetricStore) m).getFirstMetricInStore()).getBootstrapPar();
        } else {
            throw new IllegalArgumentException("Bootstrap error: cannot bootstrap metric '" + m + "' of unit '" + toString() + "', "
                    + "as the bootstrap parameter could not be obtained.");
        }
        int maxSamples = bp.getSampleCount();

        //Create a base metric for computation
        Metric copy = ((Metric)m).deepCopy();

        //Iterate through the samples and obtain a metric result for each one
        Vector<MetricResult> results = new Vector<MetricResult>();
        MetricResult useMe = null;
        //Compute the reference forecast first
        TreeMap<Integer, PairedData[]> bsInput = new TreeMap<Integer, PairedData[]>();
        //Set-up reference forecast if required: not required if sample climatology
        boolean sampleClim = false;
        if (m instanceof SkillScore) {
            sampleClim = ((SkillScore)m).getRefFcst().isSampleClimatology();
        } else if (m instanceof ThresholdMetricStore) {
            sampleClim = ((SkillScore)((ThresholdMetricStore)m).getFirstMetricInStore())
                    .getRefFcst().isSampleClimatology();
        }
        if(!sampleClim) {
            bsInput.put(ForecastTypeParameter.REFERENCE_FORECAST,new PairedData[]{refPairs});
        }
        //Set-up regular forecast
        bsInput.put(ForecastTypeParameter.REGULAR_FORECAST, new PairedData[]{mainPairs});
        for (int i = 0; i < maxSamples; i++) {
            copy.clearResults();
            //Obtain the next bootstrap resample
            //Get resampled pairs
            TreeMap<Integer, PairedData[]> bsOutput =
                    PairedData.getBootstrapSample(bsInput, bp, false, i > 0);
            //Compute reference with resample reference pairs if required
            MetricResultByLeadTime reference = null;
            if (!sampleClim) {
                reference = copy.computeByLeadTime(ForecastTypeParameter.REFERENCE_FORECAST,
                        bsOutput.get(ForecastTypeParameter.REFERENCE_FORECAST)[0], null, true);
            }
            //Compute main with resampled main pairs
            copy.computeByLeadTime(ForecastTypeParameter.REGULAR_FORECAST,
                    bsOutput.get(ForecastTypeParameter.REGULAR_FORECAST)[0], reference, true);
            results.add(copy.getResult(ForecastTypeParameter.SKILL));
            if (useMe == null) {
                useMe = results.get(0);
            }
            if (progress.isStopped()) {
                return;
            }
        }
        MetricResult[] rr = results.toArray(new MetricResult[results.size()]);
        MetricResultByLeadTime mm = ((Metric)m).getResult(ForecastTypeParameter.SKILL);
        try {
            mm.addSamplingIntervals(useMe.getIntervalsFromResults(bp.getIntervals(),
                    rr, getNullValue(), bp.getMinSampleCount()), bp.getMainInterval());
            //Set the new results with intervals
            ((Metric) m).setResult(ForecastTypeParameter.SKILL, mm);
        } catch (SamplingIntervalException e) {
            System.err.println("Unable to compute the sampling interval for metric '" + m + "' of unit "
                    + "'" + toString() + "'.  " + System.getProperty("line.separator") + e.getMessage());
        }
    }

}

