package evs.analysisunits.scale;

/**
 * Class for throwing exceptions that signify an unsupported change of measurement
 * units.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class InvalidMeasurementUnitChangeException extends RuntimeException {
    
    /**
     * Constructs an InvalidMeasurementUnitChangeException with no message.
     */
    
    public InvalidMeasurementUnitChangeException() {
        super();
    }

    /**
     * Constructs an InvalidMeasurementUnitChangeException with the specified message.
     *
     * @param s the message.
     */
    
    public InvalidMeasurementUnitChangeException(String s) {
	super(s);
    }
}
