package evs.analysisunits.scale;

//EVS dependencies
import evs.data.fileio.GlobalUnitsReader;
import evs.utilities.mathutil.FunctionLibrary;
import evs.utilities.mathutil.Function;

/**
 * Temporal support of a variable, including the integration volume.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class TemporalSupport extends Support {

/*******************************************************************************
 *                                                                             *
 *                             INSTANCE VARIABLES                              *
 *                                                                             *
 ******************************************************************************/      

    /**
     * The temporal support of an attribute is unknown but effectively infintesimal
     * (i.e. at the 'point' support).
     */    
    
    private boolean temporalPointSupport = false;
    
    /**
     * The representative elementary unit of an attribute value (integration 
     * volume). 
     */
    
    private double temporalAggregation = 0.0;

    /**
     * The units of temporal aggregation.
     */    
   
    private String temporalUnits = null;
    
    /**
     * The temporal aggregation function.
     */
    
    private String aggregationFunction = null;
    
/*******************************************************************************
 *                                                                             *
 *                                 CONSTRUCTORS                                *
 *                                                                             *
 ******************************************************************************/      

     /**
     * Constructs a temporal support object where the support is effectively
     * infinitesimal (i.e. at the point support).  Specify the measurement units.
     *
     * @param measurementUnits the attribute units
     */

    public TemporalSupport(String measurementUnits) {
        //GlobalUnitsReader.isSupportedContinuousNumericalUnit(measurementUnits,true);
        temporalPointSupport = true;
        this.measurementUnits = GlobalUnitsReader.toUSEnglish(measurementUnits);
        aggregationFunction = "INSTANTANEOUS";
    }

    /**
     * Constructs a temporal support object where the support is effectively 
     * infinitesimal (i.e. at the point support).  Specify the measurement units.
     *
     * @param measurementUnits the attribute units
     * @param measurementFunc the function required to arrive at the stated attribute values (e.g. FunctionLibrary.mult(1.0))
     * @param targetUnits the target measurement units
     */
    
    public TemporalSupport(String measurementUnits, Function measurementFunc, String targetUnits) {
        this(measurementUnits);
        //GlobalUnitsReader.isSupportedContinuousNumericalUnit(measurementUnits,true);
        //GlobalUnitsReader.isSupportedContinuousNumericalUnit(targetUnits,true);
        setTargetMeasurementUnitsFunc(measurementFunc,targetUnits);
    }

    /**
     * Constructs a temporal support object with a specified integration volume
     * and statistic (e.g. mean over 10 minutes).
     *
     * @param measurementUnits the attribute units
     * @param temporalAggregation the period of aggregation
     * @param temporalUnits the units of aggregation
     * @param aggregationFunction the aggregation function
     */
    
    public TemporalSupport(String measurementUnits, double temporalAggregation, String temporalUnits, String aggregationFunction) {
        //Validate the input
        if(temporalAggregation <=0) {
            throw new InvalidSupportException("Error: the aggregation level must be positive.");
        }
        //Check the function
        if(! aggregationFunction.equalsIgnoreCase("instantaneous") && !FunctionLibrary.isSupportedAggregationFunction(aggregationFunction)) {
            throw new InvalidSupportException("Error: unsupported aggregation function '"+aggregationFunction+"'. See the user manual for supported types.");
        }
        //GlobalUnitsReader.isSupportedContinuousNumericalUnit(measurementUnits,true);
        GlobalUnitsReader.isSupportedTimeUnit(temporalUnits,true);
        this.measurementUnits = GlobalUnitsReader.toUSEnglish(measurementUnits);
        this.aggregationFunction = aggregationFunction;
        this.temporalAggregation = temporalAggregation;
        this.temporalUnits = temporalUnits;
        temporalPointSupport = false;
    }

    /**
     * Constructs a temporal support object with a specified integration volume
     * and statistic (e.g. mean over 10 minutes).
     *
     * @param measurementUnits the attribute units
     * @param temporalAggregation the period of aggregation
     * @param temporalUnits the units of aggregation
     * @param aggregationFunction the aggregation function
     * @param measurementFunc the function required to arrive at the stated attribute values (e.g. FunctionLibrary.mult(1.0))
     * @param targetUnits the target measurement units
     */

    public TemporalSupport(String measurementUnits, double temporalAggregation, String temporalUnits, String aggregationFunction, Function measurementFunc, String targetUnits) {
        this(measurementUnits,temporalAggregation,temporalUnits,aggregationFunction);
        setTargetMeasurementUnitsFunc(measurementFunc,targetUnits);
    }

/*******************************************************************************
 *                                                                             *
 *                              ACCESSOR METHODS                               *
 *                                                                             *
 ******************************************************************************/          
    
    /**
     * Returns the period of aggregation.  
     *
     * @return the temporal aggregation
     */
    
    public double getAggregationPeriod() {
        return temporalAggregation;
    }
    
    /**
     * Returns the units of aggregation in a string.
     *
     * @return the temporal units
     */
    
    public String getAggregationUnits() {
        return temporalUnits;
    }
    
    /**
     * Returns the functional type of the attribute value at the given support.
     *
     * @return the aggregation function
     */
    
    public String getAggregationFunction() {
        return aggregationFunction;
    }  
    
    /**
     * Returns true if the temporal attribute is defined at the point support.
     *
     * @return true if the temporal attribute is defined at the point support
     */
    
    public boolean hasPointSupport() {
        return temporalPointSupport;
    }

    /**
     * Returns true if the original support can be changed to the required support
     * and false otherwise.  Currently returns true if both support objects are
     * instances of TemporalSupport, the required temporal support is larger
     * than the existing support, they have the same attribute units (or target
     * units, if defined) and the original support is either instantaneous or
     * both support objects represent totals over their input periods and these
     * periods are exactly divisible.
     *
     * @param origS the original support
     * @param reqS the required support
     * @return true if a change of support is possible, false otherwise
     */

    public static boolean canChangeSupport(TemporalSupport origS, TemporalSupport reqS) throws IllegalArgumentException {
        //Check that aggregation is possible
        if(origS == null || reqS == null) {
            throw new IllegalArgumentException("Specify non-null support for both the forecasts and observations.");
        }

//        //Attribute units must be equivalent in prospect
//        //Both have target units
//        if(origS.hasTargetMeasurementUnits()&&reqS.hasTargetMeasurementUnits()) {
//            if(!origS.getTargetMeasurementUnits().equals(reqS.getTargetMeasurementUnits())) {
//                return false;
//            }
//        }
//        //One has target units: compare to existing units of other
//        else if(origS.hasTargetMeasurementUnits()) {
//            if(!origS.getTargetMeasurementUnits().equals(reqS.getMeasurementUnits())) {
//                return false;
//            }
//        }
//        else if(reqS.hasTargetMeasurementUnits()) {
//            if(!reqS.getTargetMeasurementUnits().equals(origS.getMeasurementUnits())) {
//                return false;
//            }
//        }

        //If the units are equal in prospect return true
        if(origS.equalsOnUnitChange(reqS)) {
            return true;
        }

        //Original support must be instantaneous values or totals
        if(!origS.hasPointSupport()) {
            //Check that the observed and forecast supports are totals
            if(!origS.getAggregationFunction().equalsIgnoreCase("total")) {
                return false;
            }
            if(!reqS.getAggregationFunction().equalsIgnoreCase("total")) {
                return false;
            }

            //Existing hours
            int origResolution = (int)origS.getAggregationPeriod();
            String origResUnits = origS.getAggregationUnits();
            double existingHours = GlobalUnitsReader.getMilliConversionFactor(origResUnits);
            existingHours = existingHours / (1000.0 * 60.0 * 60.0);
            existingHours = existingHours * origResolution;

            //Required hours
            int reqResolution = (int)reqS.getAggregationPeriod();
            String reqResUnits = reqS.getAggregationUnits();
            double requiredHours = GlobalUnitsReader.getMilliConversionFactor(reqResUnits);
            requiredHours = requiredHours / (1000.0 * 60.0 * 60.0);
            requiredHours = requiredHours * reqResolution;

            //Cannot downscale
            if(requiredHours<existingHours) {
                return false;
            }

            double div = requiredHours / existingHours;  //Required hours / existing hours
            double div2 = existingHours / requiredHours; //Existing hours / required hours

            if (Math.abs(Math.rint(div)-div)>.000000001) {
                if (Math.abs(Math.rint(div2)-div2)>.000000001) {
                    return false;
                }
            }
        }
        return true;
    }
    
    /**
     * Returns true if the input object is a temporal support object and the instance
     * variables are identical to those of the current support object.  Otherwise returns
     * false. 
     *
     * @return true if the objects are equal
     */
    
    public boolean equals(Object obj) {
        if(!(obj instanceof TemporalSupport)) {
            return false;
        }
        boolean basicEquals = basicEquals(obj);
        if(!basicEquals) {
            return false;
        }
        TemporalSupport comp = (TemporalSupport)obj;
        if (!comp.measurementUnits.equals(measurementUnits)) {
            return false;
        }
        if ((comp.measurementFunc == null) != (measurementFunc == null)) {
            return false;
        }
        if (comp.measurementFunc != null && !comp.measurementFunc.equals(measurementFunc)) {
            return false;
        }
        if ((comp.targetUnits == null) != (targetUnits == null)) {
            return false;
        }
        if (comp.targetUnits != null && !comp.targetUnits.equals(targetUnits)) {
            return false;
        }
        return true;
    }
    
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        assert false : "hashCode not implemented for TemporalSupport.";
        return 1;
    }    

    /**
     * Returns true if the input object is a temporal support object and the following
     * parameters are equal:
     *
     * 1) temporalPointSupport OR
     *
     * If not at the temporal point support:
     *
     * 2) temporalAggregation (length of time)
     * 3) temporalUnits (units of time, e.g. hours)
     * 4) aggregationFunction (function over length of time, e.g. mean)
     *
     * @return true if the objects are conditionally equal
     */

    public boolean equalsAggregation(Object obj) {
        if(!(obj instanceof TemporalSupport)) {
            return false;
        }
        TemporalSupport comp = (TemporalSupport)obj;
        if (comp.temporalPointSupport != temporalPointSupport) {
            return false;
        }
        //Not point support
        if (!temporalPointSupport) {
            if (comp.temporalAggregation != temporalAggregation) {
                return false;
            }
            if ((comp.temporalUnits == null) != (temporalUnits == null)) {
                return false;
            }
            if (comp.temporalUnits != null && !comp.temporalUnits.equals(temporalUnits)) {
                return false;
            }
            if ((comp.aggregationFunction == null) != (aggregationFunction == null)) {
                return false;
            }
            if (comp.aggregationFunction != null && !comp.aggregationFunction.equals(aggregationFunction)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Returns true if the input object is a temporal support object and is
     * equal to the current unit. If the target support is defined, the target
     * support takes priority when checking for equality.
     *
     * @return true if the objects are conditionally equal
     */

    public boolean equalsOnUnitChange(Object obj) {
        boolean basicEquals = basicEquals(obj);
        if(!basicEquals) {
            return false;
        }
        TemporalSupport comp = (TemporalSupport)obj;
        //Neither have target units defined
        if(!comp.hasTargetMeasurementUnits()&&!hasTargetMeasurementUnits()) {
            return comp.getMeasurementUnits().equals(getMeasurementUnits());
        }
        //Both have target measurement units defined
        if(comp.hasTargetMeasurementUnits()&&hasTargetMeasurementUnits()) {
            return comp.getTargetMeasurementUnits().equals(getTargetMeasurementUnits());
        }
        //Only input has target measurement units defined
        if(comp.hasTargetMeasurementUnits()) {
            return comp.getTargetMeasurementUnits().equals(getMeasurementUnits());
        }
        //Only this support has target measurement units defined  
        //JB @ 29th March 2013: fixed bug, calls were wrong way around
        return getTargetMeasurementUnits().equals(comp.getMeasurementUnits());
    }
    
   /**
     * Returns true if the input attribute is a temporal support object and the instance
     * variables are identical to those of the current support object apart from
     * the measurement units and any notes, which may change.
     *
     * @param obj the input object
     * @return true if the objects are conditionally equal
     */
    public boolean equalsExceptMeasUnits(Object obj) {
        if (!(obj instanceof TemporalSupport)) {
            return false;
        }
        TemporalSupport comp = (TemporalSupport) obj;
        if (comp.temporalPointSupport != temporalPointSupport) {
            return false;
        }
        //Not point support
        if (!temporalPointSupport) {
            if (comp.temporalAggregation != temporalAggregation) {
                return false;
            }
            if ((comp.temporalUnits == null) != (temporalUnits == null)) {
                return false;
            }
            if (comp.temporalUnits != null && !comp.temporalUnits.equals(temporalUnits)) {
                return false;
            }
            if ((comp.aggregationFunction == null) != (aggregationFunction == null)) {
                return false;
            }
            if (comp.aggregationFunction != null && !comp.aggregationFunction.equals(aggregationFunction)) {
                return false;
            }
        }
        return true;
    }    

    /**
     * Returns a deep copy of the current object. 
     *
     * @return a deep copy of this support object
     */
    
    public Support deepCopy() {
        boolean pSupp = temporalPointSupport;
        TemporalSupport temporalCopy = new TemporalSupport(measurementUnits);
        temporalCopy.temporalPointSupport = pSupp;
        temporalCopy.aggregationFunction = aggregationFunction;
        temporalCopy.temporalAggregation = temporalAggregation;
        temporalCopy.temporalUnits = temporalUnits;
        temporalCopy.measurementUnits = measurementUnits;
        temporalCopy.targetUnits = targetUnits;
        temporalCopy.measurementFunc = measurementFunc;
        temporalCopy.notes = notes;
        return temporalCopy;
    }

    /**
     * Returns a string representation.
     *
     * @return a string representation
     */

    public String toString() {
        String nL = System.getProperty("line.separator");
        return 
            "Point support: "+temporalPointSupport+nL+
            "Temporal aggregation function: "+aggregationFunction+nL+
            "Temporal aggregation period: "+temporalAggregation+nL+
            "Temporal aggregation units: "+temporalUnits+nL+
            "Existing attribute units: "+measurementUnits+nL+
            "Target attribute units: "+targetUnits+nL+
            "Function for change of attribute units: "+measurementFunc+nL+
            "Notes: "+notes+nL;
    }

   /**
     * Returns true if the input attribute is a temporal support object and the instance
     * variables are identical to those of the current support object apart from
     * the measurement units, which may change.
     *
     * @param obj the input object
     * @return true if the objects are conditionally equal
     */

    private boolean basicEquals(Object obj) {
        boolean basicEquals = equalsExceptMeasUnits(obj);
        if(!basicEquals) {
            return false;
        }
        TemporalSupport comp = (TemporalSupport) obj;
        if ((comp.notes == null) != (notes == null)) {
            return false;
        }
        if (comp.notes != null && !comp.notes.equals(notes)) {
            return false;
        }
        return true;
    }

}
