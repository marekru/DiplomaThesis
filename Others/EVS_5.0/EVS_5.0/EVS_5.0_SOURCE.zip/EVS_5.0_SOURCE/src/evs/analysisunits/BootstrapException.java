package evs.analysisunits;

/**
 * Class for throwing exceptions that signify a bootstrap exception.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class BootstrapException extends RuntimeException {
    
    /**
     * Constructs an InvalidUnitException with no message.
     */
    
    public BootstrapException() {
        super();
    }

    /**
     * Constructs an InvalidUnitException with the specified message. 
     * 
     * 
     * @param s the message.
     */
    
    public BootstrapException(String s) {
	super(s);
    }
}
