package evs.analysisunits.scale;

import java.util.TreeMap;
import evs.utilities.mathutil.FunctionLibrary;
import evs.utilities.mathutil.DoubleFunction;
import evs.utilities.StaticClassInitializer;

/**
 * Utility class for changing between measurement units. All methods should check
 * that the measurement units have been read from file and should otherwise read
 * them first by calling the constructor.
 *
 * @author evs@hydrosolved.com
 */

public final class MeasurementUnitsChangeLibrary implements StaticClassInitializer {

    /**
     * Constructor that initializes the measurement units.
     */

    public MeasurementUnitsChangeLibrary() {
        initialize();
    }
    
    /**
     * Initializes.
     */
    
    public static MeasurementUnitsChangeLibrary start() {
        return new MeasurementUnitsChangeLibrary();
    }

    /**
     * List of pairwise unit changes and their associated functions
     */

    private static TreeMap<MeasurePair,DoubleFunction> uChange = null;

    /**
     * Initialize the static class members using US English.
     */

    public void initialize() {
        uChange = new TreeMap<MeasurePair,DoubleFunction>();

        MeasurePair p1a = new MeasurePair("DEGREE (FAHRENHEIT)","DEGREE (CELSIUS)");
        DoubleFunction f1a = FunctionLibrary.chain(FunctionLibrary.mult(5.0/9.0),FunctionLibrary.minus(32.0));
        uChange.put(p1a,f1a);
        MeasurePair p1b = new MeasurePair("DEGREE (CELSIUS)","DEGREE (FAHRENHEIT)");
        DoubleFunction f1b = FunctionLibrary.chain(FunctionLibrary.plus(32.0),FunctionLibrary.div(5.0/9.0));
        uChange.put(p1b,f1b);

        MeasurePair p2a = new MeasurePair("INCH","MILLIMETER");
        DoubleFunction f2a = FunctionLibrary.mult(25.4);
        uChange.put(p2a,f2a);
        MeasurePair p2b = new MeasurePair("MILLIMETER","INCH");
        DoubleFunction f2b = FunctionLibrary.mult(0.0393700787);
        uChange.put(p2b,f2b);

        MeasurePair p3a = new MeasurePair("FEET","METER");
        DoubleFunction f3a = FunctionLibrary.mult(0.3048);
        uChange.put(p3a,f3a);
        MeasurePair p3b = new MeasurePair("METER","FEET");
        DoubleFunction f3b = FunctionLibrary.mult(3.2808399);
        uChange.put(p3b,f3b);

        MeasurePair p4a = new MeasurePair("FEET CUBED/SECOND","METER CUBED/SECOND");
        DoubleFunction f4a = FunctionLibrary.mult(0.02831685);
        uChange.put(p4a,f4a);
        MeasurePair p4b = new MeasurePair("METER CUBED/SECOND","FEET CUBED/SECOND");
        DoubleFunction f4b = FunctionLibrary.mult(35.3146667);
        uChange.put(p4b,f4b);

    }

    /**
     * Returns true if the input pairing of existing and target measurement units
     * is in the library, false otherwise.
     *
     * @return true if the existing and target units pairing is in the library, false otherwise.
     */

    public static boolean isInLibrary(final String from, final String to) {
        start();
        if(from==null || to==null) {
            throw new IllegalArgumentException("Specify non-null 'from' and 'to' units for checking conversion.");
        }
        MeasurePair m = new MeasurePair(from,to);
        if(from.equals(to) || uChange.containsKey(m)) {
            return true;
        }
        return false;
    }

    /**
     * Returns a function that converts from one unit to another or throws an
     * exception if the unit change pairing is not supported.
     *
     * @param from the string representation of the function to go from
     * @param to the string representation of the function to go to
     */

    public static DoubleFunction getMeasureUnitsChangeFunc(final String from, final String to) throws InvalidMeasurementUnitChangeException {
        start();
        if(from==null || to==null) {
            throw new IllegalArgumentException("Specify non-null 'from' and 'to' units for conversion.");
        }
        MeasurePair m = new MeasurePair(from,to);
        //Return the identity function if the units are equal
        if(from.equals(to)) {
            return FunctionLibrary.identity;
        }
        else if(!uChange.containsKey(m)) {
            throw new InvalidMeasurementUnitChangeException("Unsupported change of measurement units from '"+from+"' to '"+to+"'.");
        }
        else {
            return uChange.get(m);
        }
    }

    /**
     * Inner class for representing a measurement pair. The order of the units
     * matters.
     *
     * @author evs@hydrosolved.com
     */
    private static class MeasurePair implements Comparable {

        /**
         * First unit.
         */

        private String first;

        /**
         * Second unit.
         */

        private String second;

        /**
         * Construct with two units.
         *
         * @param first the first unit
         * @param second the second unit
         */
        public MeasurePair(String first, String second) {
            this.first = first;
            this.second = second;
        }

        /**
         * Throws an exception if the input object is not a MeasurePair. Otherwise,
         * returns an integer with respect to the input MeasurePair.
         *
         * @param input the input object to compare
         * @return an integer: less than if the input is less, 0 if equal, positive otherwise
         */
        public int compareTo(Object input) {
            MeasurePair in = (MeasurePair) input;
            int c = in.first.compareToIgnoreCase(first);
            if(c!=0) {
                return c;
            }
            else {
                return in.second.compareToIgnoreCase(second);
            }
        }

        /**
         * For hashing.
         *
         * @return  hashcode
         */
        public int hashCode() {
            return toString().hashCode();
        }

        /**
         * String representation.
         *
         * @return a string representation.
         */
        public String toString() {
            return first.toUpperCase() + "." + second.toUpperCase();
        }

        /**
         * Returns true if the input class is MeasurePair and has the same first
         * and second measurement units.
         *
         * @param o the object to test for equality
         * @return true if the objects are equal
         */
        public boolean equals(Object o) {
            if (o == null || o.getClass() != getClass()) {
                return false;
            }
            MeasurePair v = ((MeasurePair) o);
            return v.first.equalsIgnoreCase(first) && v.second.equalsIgnoreCase(second);
        }
    }



}
