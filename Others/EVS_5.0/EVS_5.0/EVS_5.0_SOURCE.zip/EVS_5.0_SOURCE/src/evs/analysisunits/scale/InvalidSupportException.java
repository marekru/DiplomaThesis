package evs.analysisunits.scale;

/**
 * Class for throwing exceptions that signify an invalid support.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class InvalidSupportException extends RuntimeException {
    
    /**
     * Constructs an InvalidSupportException with no message. 
     */
    
    public InvalidSupportException() {
        super();
    }

    /**
     * Constructs an InvalidSupportException with the specified message. 
     *
     * @param s the message.
     */
    
    public InvalidSupportException(String s) {
	super(s);
    }
}
