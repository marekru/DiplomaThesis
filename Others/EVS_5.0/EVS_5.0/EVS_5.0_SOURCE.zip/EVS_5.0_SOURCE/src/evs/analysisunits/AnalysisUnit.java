package evs.analysisunits;

//Java util dependencies
import java.util.*;

//EVS dependencies
import evs.metric.metrics.*;

import evs.metric.results.MetricResultByLeadTime;
import evs.data.DataSource;
import evs.data.fileio.WriteOption;
import evs.utilities.progress.*;
import evs.utilities.*;

/**
 * A base class for analysis units, such as verification units or aggregated 
 * verification units.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public abstract class AnalysisUnit implements Comparable {

/********************************************************************************
 *                                                                              *
 *                              INSTANCE VARIABLES                              *
 *                                                                              *
 *******************************************************************************/    
    
    /**
     * The character used to separate ID strings.
     */
    
    protected static char sepChar = '.';    
    
    /**
     * The output data source.
     */    
    
    protected DataSource outputData;       

    /**
     * String representation of any errors thrown during computation of metrics.
     */
    
    protected String computeErrors = null;    
    
    /**
     * A map of metrics that will be computed or for which results are already 
     * available.  The metrics are stored against their unique name.
     */
    
    protected TreeMap<String,Metric> metrics = new TreeMap<String,Metric>();

    /**
     * Is false to retain ALL pairs, including duplicate pairs (same forecast valid 
     * time and lead time) when computing verification metrics and true to use the 
     * reduced set of pairs with duplicates removed. Duplicates must be removed 
     * when ordering paired data by trace, so any paired data for which all pairs 
     * are retained will retain the input order on construction, which is not 
     * necessarily trace order. Since temporal aggregation requires the pairs to 
     * be in trace order, it will lead to the elimination of duplicate pairs.
     */
    
    protected boolean eliminateDuplicates = true;

    /**
     * Is true to strip null ensemble members when writing the paired data for
     * the current unit.
     */

    protected boolean stripNullMembers = true;

    /**
     * Decimal precision with which to write the paired data for the current unit.
     */

    protected int pairPrecision = 5;

    /**
     * Progress of an operation.
     */

    protected ProgressMonitor progress = new ProgressMonitor();

    /**
     * Number of threads to use for bootstrapping.  Defaults to the number of
     * available processors.
     */

    protected static final int threadCount =  Runtime.getRuntime().availableProcessors();

    /**
     * Date format string for forecasts read in ASCII format.
     */

    protected String forcDateFormat = StringUtilities.DEFAULT_DATE_FORMAT; 

    /**
     * Date format string for observations read in ASCII format.
     */

    protected String obsDateFormat = StringUtilities.DEFAULT_DATE_FORMAT;

    /**
     * Write options for the EVS graphical and numerical outputs.
     */
    
    protected WriteOption write = EVSDefaults.getWriteOptions();    
    
/********************************************************************************
 *                                                                              *
 *                              ACCESSOR METHODS                                *
 *                                                                              *
 *******************************************************************************/    

    /**
     * Creates a deep copy of the current unit.  Optionally, the metrics may be
     * shallow copied (false).  In most cases, they should be deep copied (true).
     *
     * @param copyMetrics is true to copy any metrics associated with the object,
     * false otherwise.
     * @return a deep copy of the current unit
     */
    
    public abstract AnalysisUnit deepCopy(boolean copyMetrics);

    /**
     * Returns true if the unit can be executed (i.e. all parameters are set), 
     * false otherwise.
     *
     * @return true if the unit is ready to execute
     */
    
    public abstract boolean canExecute();  

    /**
     * Returns true if there are date conditions associated with the analysis
     * unit, false otherwise.
     *
     * @return true if date conditions have been set
     */

    public abstract boolean hasDateCondition();

    /**
     * Returns true if there are value conditions associated with the analysis
     * unit, false otherwise.
     *
     * @return true if value conditions have been set
     */

    public abstract boolean hasValueConditions();

    /**
     * Returns the ID separator character for placing between the river section ID
     * and the time-series ID.
     *
     * @return the separator character
     */
    
    public static char getIDSepChar() {
        return sepChar;
    }
    
    /**
     * Is false if the verification metrics will be computed from all available
     * pairs, including any duplicate pairs (same forecast valid time and lead 
     * time), and true if they will be computed from only the unique pairs.
     * 
     * @return true to eliminate duplicate pairs
     */
    
    public boolean isEliminateDuplicates() {
        return eliminateDuplicates;
    }

    /**
     * Returns true if one or more metrics will be bootstrapped, false otherwise
     *
     * @return true if metrics will be bootstrapped, otherwise false
     */

    public boolean willBootstrap() {
        Iterator i = metrics.keySet().iterator();
        while(i.hasNext()) {
            Metric next = metrics.get(i.next());
            if(next.isBootstrap()) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Returns the data source to which the output will be written.
     *
     * @return the output data source
     */
    
    public DataSource getOutputData() {
        return outputData;
    }

    /**
     * Returns the percentage progress for metric computation.
     *
     * @return the metric computation progress
     */

    public int getProgress() {
        return progress.getProgress();
    }

    /**
     * Returns any static options to their defaults. Call this method on
     * constructing a new project.
     */

    public static void returnToDefaults() {
        evs.metric.metrics.MeanContRankProbScore.
                setMethod(evs.metric.metrics.MeanContRankProbScore.HERSBACH);
    }
    
    /**
     * Returns a list of metrics for which results are available.  The metrics
     * are returned in a sorted map, indexed by their unique names.
     *
     * @return all metrics for which results are available
     */
    
    public TreeMap<String,Metric> getMetricsWithResults() {
        TreeMap<String,Metric> results = new TreeMap<String,Metric>();
        Iterator i = metrics.keySet().iterator();
        while(i.hasNext()) {
            String key = (String)i.next();
            Metric next = metrics.get(key);
            if(next.hasResults()) {
                results.put(key+"",next);
            }
        }
        return results;
    }
        
    /**
     * Returns a metric or null
     *
     * @param name the metric name
     * @return the metric or null
     */
    
    public Metric getMetric(String name) {
        return metrics.get(name);
    }    
    
    /**
     * Returns a vector of metrics.  See {@link #getCopyOfMetrics() }
     *
     * @return the metrics
     */
    
    public Vector<Metric> getMetrics() {
        Vector<Metric> returnMe = new Vector<Metric>();
        Iterator i = metrics.keySet().iterator();
        while(i.hasNext()) {
            returnMe.add(metrics.get((String)i.next()));
        }
        return returnMe;
    }
    
    /**
     * Returns a vector of skill metrics.
     *
     * @return the skill metrics
     */
    
    public Vector<Metric> getSkillMetrics() {
        Vector<Metric> returnMe = new Vector<Metric>();
        Iterator i = metrics.keySet().iterator();
        while(i.hasNext()) {
            Metric m = metrics.get((String)i.next());
            if(m.isSkillMetric()) {
                returnMe.add(m);
            }
        }
        return returnMe;
    }    
    
    /**
     * Returns a vector of deep copied metrics.  See {@link #getMetrics() }
     *
     * @return the deep copied metrics
     */
    
    public Vector<Metric> getCopyOfMetrics() {
        Vector<Metric> returnMe = new Vector<Metric>();
        Iterator i = metrics.keySet().iterator();
        while(i.hasNext()) {
            returnMe.add(metrics.get((String)i.next()).deepCopy());
        }
        return returnMe;
    }
    
    /**
     * Returns true if one or more metrics have been set.
     *
     * @return true if metrics are set, false otherwise
     */
    
    public boolean hasMetrics() {
        return metrics.size() > 0;
    }

    /**
     * Returns true if one or more skill metrics have been set.
     *
     * @return true if skill metrics are set, false otherwise
     */
    
    public boolean hasSkillMetrics() {
        return this.getSkillMetrics().size()>0;
    }      
    
    /**
     * Returns true if one or more metrics have results.
     *
     * @return true if metrics with results exist, false otherwise
     */
    
    public boolean hasMetricsWithResults() {
        return getMetricsWithResults().size()>0;
    }   
    
    /**
     * Returns true if results are available for all metrics, false if they are
     * available for only some metrics or no metrics or no metrics are available.
     * 
     * @return true if results are available for all metrics, false otherwise
     */
    
    public boolean hasResultsForAllMetrics() {
        if(!hasMetrics()) {
            return false;
        }
        Iterator i = metrics.keySet().iterator();
        while(i.hasNext()) {
            //No need to check for forecast types, as any change in a verification
            //metric will update all types.
            if(!metrics.get(i.next()).hasResults()) {
                return false;
            }
        }
        return true;       
    }
    
    /**
     * Returns true if a writeable output path exists for the current unit, false
     * otherwise.
     * 
     * @return true if a valid output path exists
     */
    
    public boolean hasWriteableOutputPath() {
    	if(outputData!=null) {
    		return outputData.canWrite();
    	}
    	return false;
    }
    
    /**
     * Returns true if one or more metrics have been set.
     *
     * @param name the metric name
     * @return true if the metric is set, false otherwise
     */
    
    public boolean hasMetric(String name) {
        return metrics.containsKey(name);
    }    
    
    /**
     * Returns true if the the data source in which output will be written has 
     * been set, false otherwise.
     *
     * @return true if the output data source has been set
     */
    
    public boolean hasOutputData() {
        return outputData != null;
    }    

    /**
     * Override superclass method to allow storage in a map that relies on 
     * the Comparable interface.  The comparison is made on the basis of the
     * string representation of the analysis unit (i.e. it differs from equals()).
     * Throws an exception if the object is of the wrong type.
     *
     * @param o the object to compare
     * @return an integer < 0 if the input is ordered below, 0 if equal and > 0 if above
     */

    public int compareTo(Object o) {
        AnalysisUnit comp = (AnalysisUnit)o;
        return comp.toString().compareTo(toString());
    }
    
    /**
     * Overrides the superclass method to test for equality of the string
     * representations (i.e. the unique analysis unit identifier).  
     *
     * @param o the object to test
     * @return true if the input object is of the same class and has the same id
     */

    public boolean equals(Object o) {
        return o != null && o.toString().equals(toString());
    }
    
    /**
     * Override the superclass method to allow hashing on the basis of the string
     * representation of this object. 
     *
     * @return a hash code
     */
    
    public int hashCode() {
        return toString().hashCode();
    }
    
    /**
     * Returns any errors associated with the last attempt to calculate metrics.
     *
     * @return a string representation of exceptions thrown
     */
    
    public String getComputeErrors() {
        return computeErrors;
    }

    /**
     * Returns the precision with which the paired data will be written.
     *
     * @return the precision for writing the paired data
     */

    public int getPairPrecision() {
        return pairPrecision;
    }

    /**
     * Returns true if null ensemble members will be stripped when writing the
     * paired data, false otherwise.
     *
     * @return true if null members will be stripped when writing pairs
     */

    public boolean isStripNullMembers() {
        return stripNullMembers;
    }

    /**
     * Returns the date format string used for reading ASCII observations.  Returns
     * one of {@link StringUtilities#DATE_FORMATS}
     *
     * @return the date format
     */

    public String getObsDateFormat() {
        return obsDateFormat;
    }

    /**
     * Returns the date format string used for reading ASCII forecasts.  Returns
     * one of {@link StringUtilities#DATE_FORMATS}
     *
     * @return the date format
     */

    public String getForcDateFormat() {
        return forcDateFormat;
    }
    
    /**
     * Returns the options for writing graphical and numerical outputs.
     * 
     * @return the write options
     */
    
    public WriteOption getWriteOptions() {
        return write;
    }    
    
/********************************************************************************
 *                                                                              *
 *                               MUTATOR METHODS                                *
 *                                                                              *
 *******************************************************************************/    

    /**
     * Attempts to compute a set of metrics associated with an analysis unit.  
     * Throws an exception if the pairs have not been set or if valid metrics 
     * have not been defined.  Returns true if successful, false otherwise.
     * Also, specify any verification units that are required as reference forecasts
     * in skill calculations.  The vector of reference forecasts may be null, but 
     * if any required reference forecasts are missing, an exception is thrown.
     * 
     * @param ref a vector of reference forecasts (may be null) 
     * @return true if the metrics were generated successfully
     */
    
    public abstract boolean computeMetrics(Vector<VerificationUnit> ref) throws IllegalArgumentException;       
    
    /**
     * Sets the ID separator character for placing between the river section ID
     * and the time-series ID.
     *
     * @param sep the separator character
     */
    
    public static void setIDSepChar(char sep) {
        sepChar = sep;
    }    
    
    /**
     * Set whether the verification metrics will be computed from all available
     * pairs (false), including any duplicate pairs (same forecast valid time and lead 
     * time), or from only the unique pairs available (true).
     * 
     * @param eliminateDuplicates is true to eliminate duplicate pairs
     */
    
    public void setEliminateDuplicates(boolean eliminateDuplicates) {
        this.eliminateDuplicates = eliminateDuplicates;
    }    
    
    /**
     * Sets the data source to which the output will be written.
     *
     * @param outputData the output data source
     */
    
    public void setOutputData(DataSource outputData) {
        this.outputData = outputData;
    }

    /**
     * Stops all metric calculation in progress and clears all metric results.
     */
     public void stop() {
         System.out.println("Stopping calculation of metrics for unit '"+this+"'.");
         clearAllMetricResults();
         progress.stop();
     }
    
    /**
     * Adds a metric to the array, overwriting a metric of the same type.  If the
     * metric has identical parameters, the results are copied.  Returns true if 
     * the metric was added successfully, false otherwise.
     *
     * @param metric the metric
     * @return true if the metric was added successfully
     */
    
    public boolean addMetric(Metric metric) {
        if(metrics.containsKey(metric.toString())) {
            Metric existing = metrics.get(metric.toString());
            //Transfer the results
            if(existing.hasResults() && metric.paramEquals(existing,false)) {
                TreeMap<Integer,MetricResultByLeadTime> results = existing.getResults();
                Iterator i = results.keySet().iterator();
                while(i.hasNext()) {
                    int next = (Integer)i.next();
                    MetricResultByLeadTime nR = results.get(next);
                    metric.setResult(next,nR);
                }
                //Transfer the sample counts
                if(existing.hasSampleCounts()) {
                    metric.setSampleCounts(existing.getSampleCounts());
                }
            }
        }
        metrics.put(metric.toString(),metric);
        return true;
    }
    
    /**
     * Deletes a metric from the array.  Returns true if the metric was deleted 
     * successfully, false otherwise.
     *
     * @param name the metric name
     * @return true if the metric was removed successfully
     */
    
    public boolean deleteMetric(String name) {
        return metrics.remove(name) != null;
    }    
    
    /**
     * Deletes all metrics from the unit.
     */
    
    public void deleteAllMetrics() {
        metrics.clear();
    }     
    
    
    /**
     * Removes the output data source.
     */
    
    public void deleteOutputData() {
        outputData = null;
    }
    
    /**
     * Clears results from all metrics in store.
     */
    
     public synchronized void clearAllMetricResults() {
         Iterator i = metrics.keySet().iterator();
         while (i.hasNext()) {
             Metric m = metrics.get((String)i.next());
             m.clearResults();
         }
//         if(hasMetricsWithResults()) {
//             TreeMap<String,Metric> results = getMetricsWithResults();
//             Iterator i = results.keySet().iterator();
//             while(i.hasNext()) {
//                 Metric m = results.get((String)i.next());
//                 m.clearResults();
//             }
//         }
     }

    /**
     * Sets the decimal precision for writing the paired data. Must be greater
     * than or equal to one.
     *
     * @param pairPrecision
     */

    public void setPairPrecision(int pairPrecision) {
        if(pairPrecision < 1) {
            throw new IllegalArgumentException("The precision for writing verification pairs must be one decimal place or more.");
        }
        this.pairPrecision = pairPrecision;
    }

    /**
     * Sets the behavior for writing null ensemble members. If the input is true,
     * null members will be stripped by default.
     *
     * @param stripNullMembers
     */

    public void setStripNullMembers(boolean stripNullMembers) {
        this.stripNullMembers = stripNullMembers;
    }

    /**
     * Set the date format string for reading ASCII forecasts.
     *
     * @param forcDateFormat the date format string
     */

    public void setForcDateFormat(String forcDateFormat) throws IllegalArgumentException {
        //StringUtilities.checkDateFormat(forcDateFormat);
        if(!StringUtilities.isCheckDateFormat(forcDateFormat)) {
            System.err.println("WARNING: forecast date format '"+forcDateFormat+"' is not a common type. Double-check that "
                    + "the specified format is the intended format, as format strings are case sensitive "
                    + "(e.g. m=minute, M=month).");            
        }
        this.forcDateFormat = forcDateFormat;
    }

    /**
     * Set the date format string for reading ASCII observations.  
     *
     * @param obsDateFormat the date format string
     */

    public void setObsDateFormat(String obsDateFormat) throws IllegalArgumentException {
        //StringUtilities.checkDateFormat(obsDateFormat);
        if(!StringUtilities.isCheckDateFormat(obsDateFormat)) {
            System.err.println("WARNING: observed date format '"+obsDateFormat+"' is not a common type. Double-check that "
                    + "the specified format is the intended format, as format strings are case sensitive "
                    + "(e.g. m=minute, M=month).");                
        }        
        this.obsDateFormat = obsDateFormat;
    }

    /**
     * Sets the options for writing graphical and numerical outputs.
     * 
     * @param write the write options
     */
    
    public void setWriteOptions(WriteOption write) {
        if(write==null) {
            throw new IllegalArgumentException("Cannot set write options to null: "
                    + "specify non-null write options.");
        }
        this.write=write;
    }        
    

}
