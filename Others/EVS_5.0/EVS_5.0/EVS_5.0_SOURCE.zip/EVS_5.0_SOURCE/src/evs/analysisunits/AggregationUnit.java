package evs.analysisunits;

//EVS dependencies
import evs.data.*;
import evs.metric.metrics.*;
import evs.metric.parameters.*;
import evs.metric.results.*;
import evs.utilities.*;
import evs.utilities.mathutil.*;
import evs.utilities.matrix.*;
import evs.utilities.progress.*;
import java.util.concurrent.*;

//Java util dependencies
import java.util.*;

/**
 * An aggregation unit comprises a set of verification units for which spatial
 * aggregation will be conducted.  The verification units must refer to the same
 * variable and time-series and have common verification parameter values.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class AggregationUnit extends AnalysisUnit implements ProgressMonitorInterface {

/********************************************************************************
 *                                                                              *
 *                               CLASS VARIABLES                                *
 *                                                                              *
 *******************************************************************************/

    /**
     * Indicator for weights that are equal to the sample size at the first time.
     */

    public static final int SAMPLE_WEIGHTS_FIRST_TIME = -1;

/********************************************************************************
 *                                                                              *
 *                              INSTANCE VARIABLES                              *
 *                                                                              *
 *******************************************************************************/

    /**
     * Stores the verification units.
     */

    protected ArrayList<VerificationUnit> verifUnits 
            = new ArrayList<VerificationUnit>();

    /**
     * Common aggregation unit ID.
     */

    private String aggregationID = null;

    /**
     * Weighting factors to apply to the verification units.
     */

    protected ArrayList<Double> weights = new ArrayList<Double>();

    /**
     * Is true to conduct aggregation by pooling, false to conduct aggregation
     * by averaging metrics.
     */

    private boolean poolPairs = false;

    /**
     * Is true if the verification units that comprise the aggregation unit
     * are statistically dependent in space, false otherwise.
     */

    private boolean statDependent = false;

    /**
     * Returns true if the aggregated metrics will be bootstrapped according to
     * the boostrap options set in the component verification units, false to
     * not conduct boostrapping, regardless of the options set for the component
     * units.
     */

    private boolean bootstrap = false;

/*******************************************************************************
 *                                                                             *
 *                                CONSTRUCTOR                                  *
 *                                                                             *
 ******************************************************************************/

    /**
     * Construct an aggregation unit with an ID.
     *
     * @param aggregationID the aggregation ID
     */

    public AggregationUnit(String aggregationID) {
        this.aggregationID = aggregationID;
    }

/********************************************************************************
 *                                                                              *
 *                              ACCESSOR METHODS                                *
 *                                                                              *
 *******************************************************************************/

    /**
     * Returns the verification units associated with this aggregation unit.
     *
     * @return the verification units
     */

    public ArrayList<VerificationUnit> getVerificationUnits() {
        return verifUnits;
    }

    /**
     * Returns true if the aggregated metrics will be computed from pooled pairs,
     * false for averaging metrics.
     *
     * @return true if the pairs will be pooled across locations
     */

    public boolean isPoolPairs() {
        return poolPairs;
    }

    /**
     * Returns true if the verification units that comprise the aggregation unit
     * are statistically dependent in space, false otherwise.
     *
     * @return true if the verification units are dependent, otherwise false.
     */

    public boolean isStatDependent() {
        return statDependent;
    }

    /**
     * Returns true if the aggregated metrics will be boostrapped according to the
     * options set for boostrapping in the component verification units, false to
     * not conduct bootstrapping, regardless of the options set for the component
     * units.
     *
     * @return true to conduct bootstrapping if set for the component units, false otherwise
     */

    public boolean isBootstrap() {
        return bootstrap;
    }

    /**
     * Returns the aggregation unit ID.
     *
     * @return the aggregation unit ID
     */

    public String getAggregationID() {
        return aggregationID;
    }

    /**
     * Returns true if the named verification unit is contained within the
     * aggregation unit.
     *
     * @param unit the verification unit
     * @return true if the unit will be aggregated, false otherwise
     */

    public boolean containsUnit(VerificationUnit unit) {
        return verifUnits.contains(unit);
    }

    /**
     * Returns a string representation of the receiver.
     *
     * @return a string representation
     */

    public String toString() {
        return aggregationID;
    }

    /**
     * Returns the ID separator character.
     *
     * @return the separator character
     */

    public static char getIDSepChar() {
        return sepChar;
    }

    /**
     * Returns true if the unit can be executed (i.e. all parameters are set),
     * false otherwise.
     *
     * @return true if the unit is ready to execute
     */

    public boolean canExecute() {
        return outputData != null && aggregationID != null && verifUnits != null && weights != null;
    }

    /**
     * Returns true if there are date conditions associated with the aggregation
     * unit, false otherwise.
     *
     * @return true if date conditions have been set
     */

    public boolean hasDateCondition() {
        if(verifUnits.size()>0) {
            return verifUnits.get(0).hasDateCondition();
        }
        return false;
    }

    /**
     * Returns true if there are value conditions associated with the aggregation
     * unit, false otherwise.
     *
     * @return true if value conditions have been set
     */

    public boolean hasValueConditions() {
        if(verifUnits.size()>0) {
            return verifUnits.get(0).hasValueConditions();
        }
        return false;
    }

    /**
     * Returns true if weighting factors have been assigned for the verification
     * units.
     *
     * @return true if weighting factors have been assigned.
     */

    public boolean hasWeights() {
        return weights.size()>0;
    }

    /**
     * Creates a deep copy of the aggregation unit.  Verification units are only
     * shallow copied for consistency in case the VU is changed (thereby impacting
     * the AU). The parameter copyMetrics is not used in this context.
     *
     * @param copyMetrics is true to copy any metrics associated with the object,
     * false otherwise.
     * @return a deep copy
     */

    public AggregationUnit deepCopy(boolean copyMetrics) {
        AggregationUnit u = new AggregationUnit(aggregationID);
        u.outputData = outputData;
        u.sepChar = sepChar;
        u.aggregationID = aggregationID;
        u.eliminateDuplicates=eliminateDuplicates;
        u.poolPairs = poolPairs;
        u.pairPrecision = pairPrecision;
        u.stripNullMembers = stripNullMembers;
        u.statDependent = statDependent;
        u.bootstrap = bootstrap;
        u.forcDateFormat = forcDateFormat;
        u.obsDateFormat = obsDateFormat;
        u.write = write;
        if(weights.size()>0) {
            ArrayList<Double> copy = new ArrayList<Double>();
            copy.addAll(weights);            
            u.weights = copy;
        }
        if(verifUnits != null) {
            ArrayList<VerificationUnit> units = new ArrayList<VerificationUnit>();
            units.addAll(verifUnits);
            u.verifUnits = units;
//            //Coordinate the verification units
//            for(int i = 0; i < verifUnits.length; i++) {
//                units[i].addAggregationUnit(u);
//            }
        }
        return u;
    }

    /**
     * Returns true if the aggregation unit has two or more verification units
     * set.
     *
     * @return true if verification units are set
     */

    public boolean hasVerificationUnits() {
        return verifUnits.size()>0;
    }

    /**
     * Returns the number of verification units associated with the aggregation
     * unit.
     *
     * @return the number of verification units associated with the aggregation unit
     */

    public int getVerificationUnitCount() {
        return verifUnits.size();
    }

    /**
     * Returns a deep copy of the weights assigned to the verification units.
     *
     * @return a deep copy of the weights
     */

    public ArrayList<Double> getWeights() {
        ArrayList<Double> d = new ArrayList<Double>();
        d.addAll(weights);
        return d;
    }

/********************************************************************************
 *                                                                              *
 *                               MUTATOR METHODS                                *
 *                                                                              *
 *******************************************************************************/

    /**
     * Sets the verification units, removing all existing units.
     *
     * @param verifUnits the verification units
     * @param weights the weights
     */

    public void setVerificationUnits(ArrayList<VerificationUnit> verifUnits, ArrayList<Double> weights) throws IllegalArgumentException {
        if(verifUnits==null) {
            throw new IllegalArgumentException("Specify a non-null array of verification units to associate with aggregation unit '"+this+"'.");
        }
        if(weights == null) {
            throw new IllegalArgumentException("The aggregation weights must be non-null.");
        }
        if(verifUnits.size() < 2) {
            throw new IllegalArgumentException("Specify at least two verification units to aggregate.");
        }
        if(verifUnits.size() != weights.size()) {
            throw new IllegalArgumentException("The number of weights must match the number of verification units.");
        }
        if (weights.get(0) != SAMPLE_WEIGHTS_FIRST_TIME) {
            double sum = FunctionLibrary.total().apply(new DenseDoubleMatrix1D(EVSUtilities.toDoubleArray(weights)));
            if (sum < 0.999 || sum > 1.001) {
                throw new IllegalArgumentException("Weights must sum to 1.0: " + sum);
            }
        }
        IllegalArgumentException e = new IllegalArgumentException("All verification units must be non-null.");
        if(verifUnits.get(0)==null) {
            throw e;
        }
        VerificationUnit first = verifUnits.get(0);
        int rows = verifUnits.size();
        for(int i = 1; i < rows; i++) {
            if(verifUnits.get(i)==null) {
                throw e;
            }
            if(verifUnits.get(i).getLocationID().equals(aggregationID)) {
                throw new IllegalArgumentException("The name of the aggregation unit must be different from the location IDs of its component verification units.");
            }
            if(!verifUnits.get(i).aggregationEquals(first,false)) {
                throw new IllegalArgumentException("Some of the verification units have unequal parameter values: aggregation requires equivalent inputs.");
            }
        }
        this.verifUnits = verifUnits;
        this.weights = weights;
        //Set the parent aggregation units
        for(int i = 0; i < rows; i++) {
            verifUnits.get(i).addAggregationUnit(this);
        }
    }

    /**
     * Removes all verification units from the aggregation unit and updates any
     * references in the verification units if required (i.e. fully deletes if
     * true).
     *
     * @param fullyDelete is true to delete the associated references in the verification units
     */

    public void deleteVerificationUnits(boolean fullyDelete) {
        if(fullyDelete) {
            VerificationUnit[] units = 
                    verifUnits.toArray(new VerificationUnit[verifUnits.size()]);
            for(VerificationUnit v : units) {
                v.deleteAndUpdateAggregationUnit(this);
                //System.out.println("Deleting '"+v+"' from '"+this+"'.");
            }
        }
        verifUnits.clear();
        weights.clear();
    }
    
    /**
     * Removes the specified verification unit from this aggregation unit. Optionally,
     * any weights associated with the unit may be re-balanced to equality. If, after
     * the update, only one unit is remaining, all units and weights are cleared.
     *
     * @param unit the verification unit to remove
     * @param balanceWeights is true to balance the weights
     */

    public void deleteVerificationUnit(VerificationUnit unit, boolean balanceWeights) {
        int index = verifUnits.indexOf(unit);
        if(index > -1) {
            verifUnits.remove(unit);
            weights.remove(index);
            if(balanceWeights) {
                //Update aggregation unit: reset weights to default of equal weights
                ArrayList<Double> weights = new ArrayList<Double>();
                int rows = verifUnits.size();
                double d = 1.0 / rows;
                for (int i = 0; i < rows; i++) {
                    weights.add(d);
                }
                this.weights = weights;
            }
        }
        //Clean up
        if(verifUnits.size()==1) {
            verifUnits.get(0).deleteAndUpdateAggregationUnit(this);
            verifUnits.clear();
            weights.clear();            
        }
    }    
    
    /**
     * Set the status for pooling pairs (true) or computing averages of the
     * metrics (false). Throws an exception if the bootstrap parameter is true
     * and the input pooled pair status is false.
     *
     * @param pPairs is true to pool pairs across locations
     */

    public void setPoolPairs(boolean pPairs) {
        if(!pPairs && bootstrap) {
            throw new IllegalArgumentException("Pairs must be pooled for conducting bootstrapping of aggregated metrics: "
                    + "set the bootstrap option to false in the aggregation unit before setting the"
                    + "pooled pair status to false.");
        }
        poolPairs = pPairs;
    }

    /**
     * Is true if the verification units that comprise the aggregation unit are
     * statistically dependent in space, false otherwise.
     *
     * @param statDependent is true if the units are dependent, false otherwise
     */

    public void setStatDependent(boolean statDependent) {
        this.statDependent=statDependent;
    }

    /**
     * If the input is true, the aggregated metrics will be boostrapped according
     * to the options set for boostrapping in the component verification units,
     * false to not conduct bootstrapping, regardless of the options set for the
     * component units.  Throws an exception if the input bootstrap parameter is
     * true and the pooled pair status is false.
     *
     * @param bootstrap is true to conduct bootstrapping when set for the component units, false otherwise
     */

    public void setBootstrap(boolean bootstrap) {
        if(bootstrap && !poolPairs) {
            throw new IllegalArgumentException("Pairs must be pooled for conducting bootstrapping of aggregated metrics: "
                    + "set the pooled pairs option to true in the aggregation unit before setting the"
                    + "bootstrap status to true.");
        }
        this.bootstrap=bootstrap;
    }

    /**
     * Sets the ID separator character for placing between the river section ID
     * and the time-series ID.
     *
     * @param sep the separator character
     */

    public static void setIDSepChar(char sep) {
        sepChar = sep;
    }

    /**
     * Sets the aggregation unit ID.
     *
     * @param aggregationID the aggregation ID
     */

    public void setAggregationID(String aggregationID) throws IllegalArgumentException {
        Vector timeID = new Vector();
        if(verifUnits != null) {
            for(VerificationUnit v : verifUnits) {
                timeID.add(v.getLocationID());
            }
        }
        if(aggregationID.equals("")) {
            throw new IllegalArgumentException("Specify a name for the aggregation unit.");
        } else if(timeID.contains(aggregationID)) {
            throw new IllegalArgumentException("The name of the aggregation unit cannot be a location ID ("+aggregationID+").");
        }
        this.aggregationID = aggregationID;
    }

    /**
     * Attempts to compute a set of metrics associated with an analysis unit.
     * Throws an exception if the pairs have not been set in each child verification
     * unit or valid metrics have not been defined.  Returns true if successful, false
     * otherwise.
     *
     * @param ref a vector of reference forecasts (may be null)
     * @return true if the metrics were generated successfully
     */

    public boolean computeMetrics(Vector<VerificationUnit> ref) throws IllegalArgumentException {
        if(poolPairs) {
            System.out.println("Conducting aggregation by pooling pairs across locations: all weighed averaging parameters have been ignored.");
            return computeMetricsByPooling(ref);
        }
        else {
            System.out.println("Conducting aggregation by averaging metrics across locations: all weighed averaging parameters will be used.");
            return computeMetricsByAveraging(ref);
        }
    }   
    
/********************************************************************************
 *                                                                              *
 *                                PRIVATE METHODS                               *
 *                                                                              *
 *******************************************************************************/

    /**
     * Attempts to compute a set of metrics associated with an analysis unit.
     * Throws an exception if the pairs have not been set in each child verification
     * unit or valid metrics have not been defined.  Returns true if successful, false
     * otherwise.  Computes aggregate verification statistics by averaging the metrics.
     *
     * @param ref a vector of reference forecasts (may be null)
     * @return true if the metrics were generated successfully
     */

    private boolean computeMetricsByAveraging(Vector<VerificationUnit> ref) throws IllegalArgumentException {
        if(verifUnits == null) {
            throw new IllegalArgumentException("No verification units have been set for aggregation unit '"+toString()+"'.");
        } else if(weights==null) {
            throw new IllegalArgumentException("No weights have been set for the verification units.");
        }
        computeErrors = null;
        //Reset progress
        progress.reset();
        boolean returnMe = true;

        //Set a timer for updating progress: assign 95% to metric computation
        Timer t = new Timer();
        try {
            TimerTask task = new TimerTask() {

                public void run() {
                    //Sum the total progress of all units
                    double sum = 0.0;
                    for (VerificationUnit v : verifUnits) {
                        sum += v.getProgress();
                    }
                    double prog = (sum / (double) verifUnits.size()) * 0.95;
                    progress.setProgress((int)prog);
                    if (prog > 95) {
                        cancel();
                    }
                }
            };
            t.scheduleAtFixedRate(task, 0, 100);

            //Check the units for paired data and metrics
            for (VerificationUnit v : verifUnits) {
                if (!v.hasMetrics()) {
                    throw new IllegalArgumentException("One or more of the children " +
                            "verification units for aggregation unit '" + toString() + "' does not " +
                            "have metrics set.");
                }
            }

            //Take the metrics from the first unit, as they must be equal for all units.
            Vector<Metric> mets = verifUnits.get(0).getMetrics();
            //Compute results for each unit
            int tot = mets.size();
            //Check that no bootstrap options have been set
            for(Metric m : mets) {
                if (m.isBootstrap()) {
                    throw new IllegalArgumentException("Cannot compute the aggregated metrics for unit "
                            + "'" + getAggregationID() + "', as one or more metrics require bootstrapping, but "
                            + "bootstrapping is not allowed when averaging the metrics of the component units: "
                            + "must choose to pool pairs instead.");
                }
            }

            //Collect all metrics of the same type and with the same parameter values together
            TreeMap<String, Vector<Metric>> metVec = new TreeMap<String, Vector<Metric>>();
            for (VerificationUnit v : verifUnits) {
                //If the verification unit has no results or uncomputed results, compute them
                if (!v.hasMetricsWithResults() || !v.hasResultsForAllMetrics()) {
                    //Check that no bootstrap options have been set
                    try {
                        v.computeMetrics(ref);
                    } catch (Exception e) {
                        computeErrors = computeErrors + StringUtilities.stackTraceToString(e);
                        throw new IllegalArgumentException(StringUtilities.stackTraceToString(e));
                    }
                }
                //Iterate through the results and add to the store
                TreeMap<String, Metric> res = v.getMetricsWithResults();
                for (Iterator j = res.keySet().iterator(); j.hasNext();) {
                    String next = (String) j.next();
                    if (metVec.containsKey(next)) {
                        Metric test = metVec.get(next).get(0);
                        if (test.paramEquals(res.get(next),false)) {
                            metVec.get(next).add(res.get(next));
                        }
                    } else {
                        Vector<Metric> vv = new Vector<Metric>();
                        Metric m = res.get(next);
                        vv.add(m);
                        metVec.put(next, vv);
                    }
                }
            }

            if(!VerificationUnit.getEqualDateValConds(verifUnits)) {
                System.out.println("*************************************************WARNING****WARNING****WARNING*************************************************");
                System.out.println("Some of the verification units that comprise aggregation unit '"+ aggregationID+"' have different date or value conditions.");
                System.out.println("*******************************************************************************************************************************");
            }

            //Do not aggregate any metrics for which only some results are available
            for (Iterator j = metVec.keySet().iterator(); j.hasNext();) {
                Object next = j.next();
                if (metVec.get(next).size() != verifUnits.size()) {
                    System.out.println("Will not aggregate results for " + next + " as there are only " + metVec.get(next).size() + " of " + verifUnits.size() + " results available.");
                    j.remove();
                }
            }

            double inc = 5.0 / tot;  //5% of progress assigned to aggregation
            progress.setIncrement(inc);

            //Set the weights if based on sample size at the first time
            ArrayList<Double> wgh = weights;
            int rows = verifUnits.size();
            if (wgh.get(0) == SAMPLE_WEIGHTS_FIRST_TIME) {
                double tot2 = 0;
                for (int i = 0; i < rows; i++) {
                    wgh.set(i,new Double(verifUnits.get(i).lastPairFirstLeadCount));
                    tot2 += wgh.get(i);
                }
                for (int i = 0; i < rows; i++) {
                     wgh.set(i,new Double(wgh.get(i) / tot2));
                }
            }
            //Aggregate the metrics
            for (Iterator j = metVec.keySet().iterator(); j.hasNext();) {
                try {
                    String next = (String) j.next();
                    Metric[] data = new Metric[metVec.get(next).size()];
                    data = metVec.get(next).toArray(data);
                    //Note that the function is a summation, not an average, because the weights sum to 1.0
                    Metric aggregated = Metric.aggregate(data, FunctionLibrary.total(), EVSUtilities.toDoubleArray(wgh));
                    metrics.put(next, aggregated);
                } catch (Exception e) {
                    e.printStackTrace();
                    computeErrors = computeErrors + StringUtilities.stackTraceToString(e);
                    returnMe = false;
                }
                progress.increment();
            }
            return returnMe;
        } catch (Exception e) {
            throw new IllegalArgumentException(e.getMessage());
        } finally {
            t.cancel();
        }
    }

    /**
     * Attempts to compute a set of metrics associated with an aggregation unit.
     * Throws an exception if valid metrics have not been defined for one or more
     * of the child verification units.  Returns true if successful, false otherwise.
     * Computes aggregate verification statistics by pooling the pairs and then
     * computing the metrics from the pooled pairs.
     *
     * @return true if the metrics were generated successfully
     * @param ref a vector of reference forecasts (may be null)
     */

    private boolean computeMetricsByPooling(Vector<VerificationUnit> ref) throws IllegalArgumentException {
        if(verifUnits == null) {
            throw new IllegalArgumentException("No verification units have been set for aggregation unit '"+toString()+"'.");
        }
        computeErrors = null;
        //Reset progress
        progress.reset();
        //Show progress for bootstrapping
        if(willBootstrap()) {
            progress.display(this+". Percent complete: ", 5);
        }
        boolean returnMe = true;
        //Pairs are pre-read, requiring more memory, but increasing
        //the calculation speed.  However, it should be noted that there must
        //be enough memory to pool pairs anyway, and the pooled pairs are shallow copies.
        //For reference forecasts, more memory will be required if the reference forecasts
        //differ for each skill metric, but this is unlikely, and (re)reading the reference
        //forecasts on the fly would significantly increase the computational time
        PairedData[] mainPairsCond = null;
        PairedData[] mainPairsUncond = null;
        //Pooled pairs, which are shallow copies of the above
        PairedData pooledMainCond = null;
        PairedData pooledMainUncond = null;
        TreeMap<String,PairedData> refPairsCond = new TreeMap<String,PairedData>();
        TreeMap<String,PairedData> refPairsUncond = new TreeMap<String,PairedData>();
        Vector<String> sref = null;

        //Set a timer for updating progress: assign 75% to paired computation
        int rows = verifUnits.size();
        final double total = 75.0 * rows;
        Timer t = new Timer();
        TimerTask task = new TimerTask() {
            public void run() {
                //Sum the total progress of all units
                double sum = 0.0;
                for(VerificationUnit v : verifUnits) {
                    sum+=v.getProgress();
                }
                double prog = (sum / total) * 75;
                    progress.setProgress((int)prog);
            }
        };
        t.scheduleAtFixedRate(task,0,100);
        //Check the units for metrics and reference forecasts
        for(VerificationUnit v : verifUnits) {
            if(!v.hasMetrics()) {
                throw new IllegalArgumentException("One or more of the children verification units for aggregation unit '"+toString()+"' does not have metrics set.");
            }
            //Check that the reference forecasts are covered
            sref = v.checkRefs(ref);
        }
        //Get the required pairs
        //Which pairs are required?  Only need to check first unit.
        Vector<Metric> mets = verifUnits.get(0).getMetrics();
        int tot = mets.size();
        boolean needConPairs = false;
        boolean needUnconPairs = false;
        for(int i = 0; i < tot; i++) {
            if(mets.get(i).willIgnoreConditions()) {
                needUnconPairs = true;
            } else {
                needConPairs = true;
            }
        }
        //Read conditioned pairs
        if(needConPairs) {
            mainPairsCond = new PairedData[rows];
            for(int i = 0; i < rows; i++) {
                 mainPairsCond[i] = verifUnits.get(i).getConditionedPairs(true);
            }
            pooledMainCond = PairedData.getPooledPairs(mainPairsCond,false);  //Skip ordering by trace
        }
        //Read the unconditioned pairs
        if(needUnconPairs) {
            mainPairsUncond = new PairedData[rows];
            for(int i = 0; i < rows; i++) {
                 mainPairsUncond[i] = verifUnits.get(i).getConditionedPairs(false);
            }
            pooledMainUncond = PairedData.getPooledPairs(mainPairsUncond,false);  //Skip ordering by trace
        }
        t.cancel();  //Cancel timer

        //Compute the metrics
        //Assign 25% of processing time evenly to metric calculation
        double inc = 25.0 / tot;
        //Deflate the increment when bootstrapping metrics with shared samples (i.e. non-skill)
        double bInc = 10.0 / tot;  //Retain 15% for shared bootstrapping
        int bDone = 0; //Number of metrics bootstrapped without a shared sample
        Vector<Metric> sharedBootstrap = new Vector<Metric>();
        for(int i = 0; i < tot; i++) {
            Metric m = mets.get(i).deepCopy();
            metrics.put(m.toString(),m);
            //Set the reference pairs if required
            boolean skill = m.isSkillMetric();
            //Set the reference pairs required for the current metric
            Vector<PairedData> refPairsStore = new Vector<PairedData>();
            if (skill) {
                //Reference forecasts are the same for all thresholds, just get the first.
                //Read the reference pairs for all units for the current metric
                //If not already read
                for (VerificationUnit v : verifUnits) {
                    if (v.hasMetric(m.toString())) {
                        Metric n = v.getMetric(m.toString());
                        SkillScore sm = null;
                        if (n instanceof SkillScore) {
                            sm = (SkillScore) n;
                        } else if (m instanceof ThresholdMetricStore) {
                            sm = (SkillScore) ((ThresholdMetricStore) n).getFirstMetricInStore();
                        }
                        String ra = sm.getRefFcst().getParVal();
                        //Reference forecast: may not always be present (e.g. sample climatology has no VU)
                        if (sref.contains(ra)) {
                            VerificationUnit rf = ref.get(sref.indexOf(ra));
                            //Use unconditional pairs
                            if (rf.hasValueConditions() && ((Metric) n).willIgnoreConditions()) {
                                PairedData p1 = null;
                                if (refPairsUncond.containsKey(rf.toString())) {
                                    p1 = refPairsUncond.get(rf.toString());
                                } else {
                                    System.out.println("Obtaining pairs for reference forecast '" + rf.toString() + "', ignoring value conditions.");
                                    p1 = rf.getConditionedPairs(false);
                                    refPairsUncond.put(rf.toString(), p1);
                                }
                                refPairsStore.add(p1);
                            } //Use conditional pairs
                            else {
                                PairedData p2 = null;
                                if (refPairsCond.containsKey(rf.toString())) {
                                    p2 = refPairsCond.get(rf.toString());
                                } else {
                                    System.out.println("Obtaining pairs for reference forecast '" + rf.toString() + "'.");
                                    p2 = rf.getConditionedPairs(true);
                                    refPairsCond.put(rf.toString(), p2);
                                }
                                refPairsStore.add(p2);
                            }
                        }
                    }
                    if(progress.isStopped()) {
                        return false;
                    }
                }
            }
            double addToInc = 0;  //Increment
            try {
                //Set the main pairs
                PairedData mainPairs = null;  //Pairs of the numerator in skill or pairs for non-skill
                PairedData[] mainPairsArray = null;
                if (hasValueConditions() && ((Metric) m).willIgnoreConditions()) {
                    mainPairs = pooledMainUncond;
                    mainPairsArray = mainPairsUncond;
                } else {
                    mainPairs = pooledMainCond;
                    mainPairsArray = mainPairsCond;
                }

                //Compute the nominal values of the metric
                //Compute the reference forecasts first
                PairedData[] refPairs = null;
                MetricResultByLeadTime reference = null;
                if(refPairsStore.size()>0) {
                    refPairs = refPairsStore.toArray(new PairedData[refPairsStore.size()]);
                    PairedData pooledRefPairs = PairedData.getPooledPairs(refPairs,false);
                    reference = ((Metric) m).computeByLeadTime(ForecastTypeParameter.REFERENCE_FORECAST,
                            pooledRefPairs,null,false);
                }
                ((Metric) m).computeByLeadTime(ForecastTypeParameter.REGULAR_FORECAST,
                        mainPairs,reference,false);
                //Bootstrap skill metrics or store for shared bootstrap
                //Bootstrap required? If so, skill score requires dependent bootstrap
                if (m.isBootstrap() && m.hasResults()) {
                    boolean isSkill = m.isSkillMetric();
                    if(isSkill && m instanceof SkillScore) {
                        isSkill = !((SkillScore)m).getRefFcst().isSampleClimatology();
                    } else if(isSkill && m instanceof ThresholdMetricStore) {
                        isSkill = !((SkillScore)((ThresholdMetricStore)m).getFirstMetricInStore()).
                                getRefFcst().isSampleClimatology();
                    }
                    if (isSkill) {
                        String append = "";
                        if (threadCount > 1) {
                            append = "  Conducting parallel processing with " + threadCount + " threads.";
                        }
                        System.out.println("Performing bootstrapping of skill metric '" + m + "' for unit '" + this + "' "
                                + "using a separate bootstrap sample." + append);
                        doSkillBootstrap(m, mainPairsArray, refPairs);
                        System.out.println("Completed bootstrap of skill metric '" + m + "' for unit '" + this + "'.");
                        addToInc = inc;
                        bDone++;
                    } else{
                        sharedBootstrap.add(m);
                        addToInc = bInc;
                    }
                }
            }
            catch(Exception e) {
                e.printStackTrace();
                computeErrors = computeErrors + StringUtilities.stackTraceToString(e);
                returnMe = false;
            }
            progress.setProgress((int)(progress.getProgress()+addToInc));
        }
        //Shared bootstrap? Complete here.
        //Perform shared-sample bootstrapping if required
        if(sharedBootstrap.size()>0) {
            try {
                int bTot = sharedBootstrap.size() + bDone;
                String append = "";
                if (threadCount > 1) {
                    append = "  Conducting parallel processing with " + threadCount + " threads.";
                }
                System.out.println("Bootstrapping " + bTot + " of " + metrics.size() + " metrics for "
                        + "unit '" + this + "'. Using a shared sample for " + sharedBootstrap.size() + " "
                        + "of "+bTot+" metrics."+append);
                doSharedBootstrap(sharedBootstrap.toArray(new Metric[sharedBootstrap.size()]),
                        mainPairsCond,mainPairsUncond);
                System.out.println("Completed bootstrap of "+bTot+" metrics for "
                        + "unit '"+this+"'.");
            }
            catch(Exception e) {
                e.printStackTrace();
                computeErrors = computeErrors + StringUtilities.stackTraceToString(e);
                returnMe = false;
            }
        }
        return returnMe;
    }

    /**
     * Performs bootstrap resampling on the input metrics, updating the results
     * with the bootstrap intervals defined in the bootstrap parameter of the
     * metric.  Uses the same samples on all metrics.  Either the conditioned pairs
     * or the unconditioned pairs may be null, but both cannot be null.
     *
     * @param m the metric for which bootstrapping is required
     * @param pairsCond the conditional pairs (may be null)
     * @param pairsUncond the unconditional pairs (may be null)
     */

    private void doSharedBootstrap(Metric[] m, PairedData[] pairsCond, PairedData[] pairsUncond)
            throws InterruptedException, ExecutionException {
        long start = System.currentTimeMillis();
        Vector<Metric> uncond = new Vector<Metric>();
        Vector<Metric> cond = new Vector<Metric>();
        Vector<BootstrapParameter> condBP = new Vector<BootstrapParameter>();
        Vector<BootstrapParameter> uncondBP = new Vector<BootstrapParameter>();
      
        int maxSamplesCond = 0;
        int maxSamplesUncond = 0;
        int uncondCount = 0;
        int condCount = 0;

        //Check inputs
        for (int i = 0; i < m.length; i++) {
            BootstrapParameter p = null;
            boolean store = false;
            if (m[i] instanceof BootstrapableMetric) {
                p = ((BootstrapableMetric) m[i]).getBootstrapPar();
            } else if (m[i] instanceof ThresholdMetricStore) {
                p = ((BootstrapableMetric) ((ThresholdMetricStore) m[i]).getFirstMetricInStore()).getBootstrapPar();
                store = true;
            } else {
                throw new IllegalArgumentException("Bootstrap error: cannot bootstrap metric '" + m[i] + "' of unit '" + this + "', "
                        + "as the bootstrap parameter could not be obtained.");
            }
            if(m[i].isSkillMetric()) {
                SkillScore check = null;
                if(store) {
                    check = (SkillScore)((ThresholdMetricStore)m[i]).getFirstMetricInStore();
                } else {
                    check = (SkillScore)m[i];
                }
                if(!check.getRefFcst().isSampleClimatology()) {
                    throw new IllegalArgumentException("Incorrect method call: cannot bootstrap skill metric with shared "
                            + "samples unless the reference forecast is sample climatology.");
                }
            }
            if(m[i].willIgnoreConditions()&&pairsUncond==null) {
                throw new IllegalArgumentException("Expected non-null unconditional pairs for bootstrapping metric '"
                        +m[i]+ "' of unit '"+this+"'.");
            }
            if(!m[i].willIgnoreConditions()&&pairsCond==null) {
                throw new IllegalArgumentException("Expected non-null conditional pairs for bootstrapping metric '"
                        +m[i]+ "' of unit '"+this+"'.");
            }
            if(m[i].willIgnoreConditions()) {
                if(uncondBP.size()>0) {
                    if(uncondBP.get(0).getNominalBlockSizeInMillis()!=
                            p.getNominalBlockSizeInMillis()) {
                        throw new MetricCalculationException("When computing block bootstrap intervals "
                                + "across multiple metrics, the block size must be constant.");
                    }
                }
                uncondBP.add(p);
                int nextSamples = p.getSampleCount();
                if (nextSamples > maxSamplesUncond) {
                    maxSamplesUncond = nextSamples;
                }
                uncondCount+=1;
                //Create a base metric for computation
                Metric copy = m[i].deepCopy();
                //Clear existing results from the copy
                copy.clearResults();
                uncond.add(copy);
            } else {
                if(condBP.size()>0) {
                    if(condBP.get(0).getNominalBlockSizeInMillis()!=
                            p.getNominalBlockSizeInMillis()) {
                        throw new MetricCalculationException("When computing block bootstrap intervals "
                                + "across multiple metrics, the block size must be constant.");
                    }
                }
                condBP.add(p);
                int nextSamples = p.getSampleCount();
                if (nextSamples > maxSamplesCond) {
                    maxSamplesCond = nextSamples;
                }
                condCount+=1;
                //Create a base metric for computation
                Metric copy = m[i].deepCopy();
                //Clear existing results from the copy
                copy.clearResults();
                cond.add(copy);
            }
        }
        boolean doCond = cond.size()>0;
        boolean doUncond = uncond.size()>0;

        //Determine lead times to process (may not all be available)
        Vector<PairedData> pt = new Vector<PairedData>();
        if(doCond) {
            Collections.addAll(pt,pairsCond);
        }
        if(doUncond) {
            Collections.addAll(pt,pairsUncond);
        }
        //Determine unique lead times
        DoubleMatrix1D leadTimes = PairedData.getUnionOfLeadTimes(pt.toArray(new PairedData[pt.size()]));

        //Progress increment: use the remaining time, increment after each sample
        int times = leadTimes.getRowCount();
        double remainder = 100.0 - progress.getProgress();
        double startInc = progress.getIncrement();  //Increment that the monitor started with
        double incCond = remainder / (double)(condCount*maxSamplesCond*times);
        double incUncond = remainder /(double)(condCount*maxSamplesUncond*times);

        //Iterate through the samples and obtain a metric result for each one
        //Bootstrap each lead-time separately to conserve memory.
        TreeMap<Integer,TreeMap<ProbabilityIntervalParameter,MetricResult[]>> intervalsByTime =
                new TreeMap<Integer,TreeMap<ProbabilityIntervalParameter,MetricResult[]>>();
        for (int t = 0; t < times; t++) {
            double time = leadTimes.get(t);
            TreeMap<Integer, PairedData[]> bsIn = null;
            TreeMap<Integer, PairedData[]> bsInWithUncond = null;

            //Results store for current time
            TreeMap<Integer,Vector<MetricResult>> results =
                    new TreeMap<Integer,Vector<MetricResult>>();
            //Add empty stores
            for (int i = 0; i < m.length; i++) {
                results.put(m[i].getID(), new Vector<MetricResult>());
            }

            //Do conditional first
            if (doCond) {
                progress.setIncrement(incCond);
                bsIn = new TreeMap<Integer, PairedData[]>();
                Vector<PairedData> pCT = new Vector<PairedData>();
                for(int tt = 0; tt < pairsCond.length; tt++) {
                    if(pairsCond[tt].hasLeadTime(time)) {
                        pCT.add(new PairedData(pairsCond[tt].getPairsByLeadTime(time),false,
                                pairsCond[tt].getNullValue()));
                    }
                }
                PairedData[] pairsCondT = pCT.toArray(new PairedData[pCT.size()]);

                bsIn.put(ForecastTypeParameter.REGULAR_FORECAST, pairsCondT);

                //Do bootstrap in thread pool
                ExecutorService pool = Executors.newFixedThreadPool(threadCount);
                Collection<Callable<TreeMap<Metric,MetricResult>>> tasks =
                        new ArrayList<Callable<TreeMap<Metric,MetricResult>>>();
                //Construct the bootstrap samples
                for (int i = 0; i < maxSamplesCond; i++) {
                    ArrayList<Metric> ms = new ArrayList<Metric>();
                    for (int j = 0; j < condCount; j++) {
                        if(i<condBP.get(j).getSampleCount()) {
                            ms.add(cond.get(j));
                        }
                    }
                    Bootstrap b = new Bootstrap(bsIn,ms.toArray(
                            new Metric[ms.size()]),isStatDependent(), i > 0,progress);
                    tasks.add(b);
                }

                //Execute the bootstrap and set the results
                try {
                    List<Future<TreeMap<Metric,MetricResult>>> booted =
                            pool.invokeAll(tasks);
                    for(Future<TreeMap<Metric,MetricResult>> next : booted) {
                        TreeMap<Metric,MetricResult> mm = next.get();
                        Iterator it = mm.keySet().iterator();
                        while (it.hasNext()) {
                            Metric me = (Metric)it.next();
                            results.get(me.getID()).add(mm.get(me));
                        }
                    }
                } catch(ProgressStoppedException e) {
                    e.printStackTrace();
                    return;
                } finally {
                    pool.shutdown();
                }
            }
            //Do unconditional next
            if (doUncond) {
                progress.setIncrement(incUncond);
                bsInWithUncond = new TreeMap<Integer, PairedData[]>();
                Vector<PairedData> pCU = new Vector<PairedData>();
                for(int tt = 0; tt < pairsUncond.length; tt++) {
                    if(pairsUncond[tt].hasLeadTime(time)) {
                        pCU.add(new PairedData(pairsUncond[tt].getPairsByLeadTime(time),false,
                                pairsUncond[tt].getNullValue()));
                    }
                }
                PairedData[] pairsUncondT = pCU.toArray(new PairedData[pCU.size()]);
                bsInWithUncond.put(ForecastTypeParameter.REGULAR_FORECAST, pairsUncondT);
                //Do bootstrap in thread pool
                ExecutorService pool = Executors.newFixedThreadPool(threadCount);
                Collection<Callable<TreeMap<Metric,MetricResult>>> tasks =
                        new ArrayList<Callable<TreeMap<Metric,MetricResult>>>();
                //Construct the bootstrap samples
                for (int i = 0; i < maxSamplesUncond; i++) {
                    ArrayList<Metric> ms = new ArrayList<Metric>();
                    for (int j = 0; j < uncondCount; j++) {
                        if(i<uncondBP.get(j).getSampleCount()) {
                            ms.add((Metric)uncond.get(j));
                        }
                    }
                    Bootstrap b = new Bootstrap(bsInWithUncond,ms.toArray(
                            new Metric[ms.size()]),false, i > 0,progress);
                    tasks.add(b);
                }

                //Execute the bootstrap and set the results
                try {
                    List<Future<TreeMap<Metric,MetricResult>>> booted =
                            pool.invokeAll(tasks);
                    for(Future<TreeMap<Metric,MetricResult>> next : booted) {
                        TreeMap<Metric,MetricResult> mm = next.get();
                        Iterator it = mm.keySet().iterator();
                        while (it.hasNext()) {
                            Metric me = (Metric)it.next();
                            results.get(me.getID()).add(mm.get(me));
                        }
                    }
                } catch(ProgressStoppedException e) {
                    e.printStackTrace();
                    return;
                } finally {
                    pool.shutdown();
                }
            }
            //Prepare the intervals for the current time
            for(Metric nextMet : m) {
                Vector<MetricResult> r = results.get(nextMet.getID());
                MetricResult[] nxR = r.toArray(new MetricResult[r.size()]);
                BootstrapParameter bp = null;
                if (nextMet instanceof BootstrapableMetric) {
                    bp = ((BootstrapableMetric) nextMet).getBootstrapPar();
                } else {
                    bp = ((BootstrapableMetric) ((ThresholdMetricStore) nextMet).
                            getFirstMetricInStore()).getBootstrapPar();
                }
                try {
                    //Compute the intervals for the current time
                    TreeMap<ProbabilityIntervalParameter, MetricResult[]> nextIntervals =
                            r.get(0).getIntervalsFromResults(bp.getIntervals(),
                            nxR, Metric.NULL_DATA, bp.getMinSampleCount());

                    //Prior times computed: append
                    if (intervalsByTime.containsKey(nextMet.getID())) {
                        System.out.println("Updating interval for metric '"+nextMet+"': adding time "+time+".");
                        TreeMap<ProbabilityIntervalParameter, MetricResult[]> priorInt =
                                intervalsByTime.get(nextMet.getID());
                        //Add the new time for each interval
                        Iterator timeIt = priorInt.keySet().iterator();
                        while (timeIt.hasNext()) {
                            ProbabilityIntervalParameter nI = (ProbabilityIntervalParameter) timeIt.next();
                            MetricResult[] existingBound = priorInt.get(nI);
                            MetricResultByLeadTime lower = (MetricResultByLeadTime) existingBound[0];
                            MetricResultByLeadTime upper = (MetricResultByLeadTime) existingBound[1];
                            MetricResultByLeadTime samples = (MetricResultByLeadTime) existingBound[2];
                            //Add new times
                            MetricResult[] currentBound = nextIntervals.get(nI);
                            lower.addResult(time, ((MetricResultByLeadTime) currentBound[0]).getResult(time));
                            upper.addResult(time, ((MetricResultByLeadTime) currentBound[1]).getResult(time));
                            samples.addResult(time, ((MetricResultByLeadTime) currentBound[2]).getResult(time));
                        }
                    } //No prior times computed: add new
                    else {
                        System.out.println("Updating interval for metric '"+nextMet+"': adding time "+time+".");
                        intervalsByTime.put(nextMet.getID(), nextIntervals);
                    }
                } catch (SamplingIntervalException e) {
                    System.err.println("Unable to compute the sampling interval for metric '"+nextMet+"' of unit '"+toString()+"' at "
                            + "lead time: " + time + ".  " + System.getProperty("line.separator") + e.getMessage());
                }
            }
        }

        //Set the new intervals for each metric across all lead times
        for(Metric nx : m) {
            int fType = ForecastTypeParameter.REGULAR_FORECAST;
            //Skill metric with sample climatology
            if (nx.isSkillMetric()) {
                fType = ForecastTypeParameter.SKILL;
            }
            BootstrapParameter bp = null;
            if (nx instanceof BootstrapableMetric) {
                bp = ((BootstrapableMetric) nx).getBootstrapPar();
            } else {
                bp = ((BootstrapableMetric) ((ThresholdMetricStore) nx).
                        getFirstMetricInStore()).getBootstrapPar();
            }
            MetricResultByLeadTime addToMe = (MetricResultByLeadTime)nx.getResult(fType);
            addToMe.addSamplingIntervals(intervalsByTime.get(nx.getID()),bp.getMainInterval());
            nx.setResult(fType,addToMe);
        }
        if(startInc>0) {
            progress.setIncrement(startInc);
        }
        long stop = System.currentTimeMillis();
        System.out.println("Time taken for bootstrapping: " + Mathematics.round((stop - start) / 60000.0,1) + " minutes.");
    }

    /**
     * Performs bootstrap resampling on the input skill metric, updating the results
     * with the bootstrap intervals defined in the bootstrap parameter of the
     * metric.
     *
     * @param m the skill metric for which bootstrapping is required
     * @param mainPairs the main pairs
     * @param refPairs the pairs associated with a reference forecast for a skill metric (may be null)
     */

    private void doSkillBootstrap(Metric m, PairedData[] mainPairs, PairedData[] refPairs) {
        BootstrapParameter bp = null;
        if(!m.isSkillMetric()) {
            throw new IllegalArgumentException("Bootstrap error: cannot bootstrap the non-skill metric '"+m+"' with a skill bootstrap.");
        }
        if(m instanceof BootstrapableMetric) {
            bp = ((BootstrapableMetric)m).getBootstrapPar();
        } else if (m instanceof ThresholdMetricStore) {
            bp = ((BootstrapableMetric)((ThresholdMetricStore)m).getFirstMetricInStore()).getBootstrapPar();
        } else {
            throw new IllegalArgumentException("Bootstrap error: cannot bootstrap metric '"+m+"' of unit '"+toString()+"', "
                    + "as the bootstrap parameter could not be obtained.");
        }
        //Iterate through the samples and obtain a metric result for each one
        Vector<MetricResult> results = new Vector<MetricResult>();
        final int samples = bp.getSampleCount();
        Metric copy = m.deepCopy();
        MetricResult useMe = null;
        //Compute the reference forecast first
        TreeMap<Integer, PairedData[]> bsInput = new TreeMap<Integer, PairedData[]>();
        //Set-up reference forecast if required: not required if sample climatology
        boolean sampleClim = false;
        if (m instanceof SkillScore) {
            sampleClim = ((SkillScore)m).getRefFcst().isSampleClimatology();
        } else if (m instanceof ThresholdMetricStore) {
            sampleClim = ((SkillScore)((ThresholdMetricStore)m).getFirstMetricInStore())
                    .getRefFcst().isSampleClimatology();
        }
        if(!sampleClim) {
            bsInput.put(ForecastTypeParameter.REFERENCE_FORECAST, refPairs);
        }
        //Set-up regular forecast
        bsInput.put(ForecastTypeParameter.REGULAR_FORECAST, mainPairs);
        for (int i = 0; i < samples; i++) {
            copy.clearResults();
            //Obtain the next bootstrap resample
            //Get resampled pairs
            TreeMap<Integer, PairedData[]> bsOutput =
                    PairedData.getBootstrapSample(bsInput, bp, isStatDependent(), i > 0);
            //Compute reference with resample reference pairs if required
            MetricResultByLeadTime reference = null;
            if (!sampleClim) {
                PairedData pooledRef = PairedData.getPooledPairs(bsOutput.get(
                        ForecastTypeParameter.REFERENCE_FORECAST), false);
                reference = copy.computeByLeadTime(ForecastTypeParameter.REFERENCE_FORECAST,
                        pooledRef,null,true);
            }
            //Compute main with resampled main pairs
            PairedData pooledMain = PairedData.getPooledPairs(bsOutput.get(
                    ForecastTypeParameter.REGULAR_FORECAST), false);
            copy.computeByLeadTime(ForecastTypeParameter.REGULAR_FORECAST, pooledMain, reference,true);
            results.add(copy.getResult(ForecastTypeParameter.SKILL));
            if (useMe == null) {
                useMe = results.get(0);
            }
            if (progress.isStopped()) {
                return;
            }
        }
        MetricResult[] rr = results.toArray(new MetricResult[results.size()]);
        MetricResultByLeadTime mm = m.getResult(ForecastTypeParameter.SKILL);
        try {
            mm.addSamplingIntervals(useMe.getIntervalsFromResults(bp.getIntervals(),
                rr,Metric.NULL_DATA,bp.getMinSampleCount()),bp.getMainInterval());
            //Set the new results with intervals
            m.setResult(ForecastTypeParameter.SKILL,mm);
        } catch (SamplingIntervalException e) {
                    System.err.println("Unable to compute the sampling interval for metric '"+m+"' of unit "
                            + "'"+toString()+"'.  "+System.getProperty("line.separator")+e.getMessage());
        }
    }


}