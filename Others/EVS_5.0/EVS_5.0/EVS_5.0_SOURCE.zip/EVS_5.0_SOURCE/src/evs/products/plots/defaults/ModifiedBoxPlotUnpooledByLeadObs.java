package evs.products.plots.defaults;

//JFreeChart dependencies
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.JFreeChart;    
import org.jfree.chart.labels.BoxAndWhiskerXYToolTipGenerator;

//Java awt dependencies
import java.awt.Font;
import java.awt.Color;

//EVS dependencies
import evs.metric.results.MetricResult;
import evs.metric.results.DoubleMatrix2DResult;
import evs.products.plots.defaults.boxplotutilities.BoxPlotItem;
import evs.products.plots.defaults.boxplotutilities.BoxPlotRenderer;
import evs.products.plots.defaults.boxplotutilities.ConcreteBoxPlotDataset;

/**
 * Constructs a modified box plot with error values (as boxes) against time from 
 * forecast start time (in hours) for a single lead time.  
 *
 * @author evs@hydrosolved.com
 */

public class ModifiedBoxPlotUnpooledByLeadObs extends DefaultXYPlotByLeadTime implements EVSPlot, RealValuedPlot  {
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/    
    
    /**
     * Constructs a modified box plot with no input arguments.  The data must be set later.
     */
    
    public ModifiedBoxPlotUnpooledByLeadObs() {
        //Set some default axes
        final NumberAxis xAxis = new NumberAxis("Observed value");
        //Set name in subclass
        final NumberAxis yAxis = new NumberAxis("Forecast errors (forecast - observed)");
        xAxis.setTickLabelFont(new Font("Verdana", Font.PLAIN, 8));
        yAxis.setTickLabelFont(new Font("Verdana", Font.PLAIN, 8));
        yAxis.setAutoRangeIncludesZero(false);
        setDomainAxis(xAxis);
        setRangeAxis(yAxis);
        //Hide the grid lines
        setDomainGridlinesVisible(false);
        setRangeGridlinesVisible(false);                     
    }

    /*******************************************************************************
     *                                                                             *
     *                              ACCESSOR METHODS                               *
     *                                                                             *
     ******************************************************************************/     
    
    /**
     * Returns a default chart with a plot that extends evs.products.plots.EVSPlot.
     *
     * @return a default chart
     */

    public static JFreeChart getDefaultChart() {
        String name = "Modified box plot of ensemble forecast errors against observed value.";
        ModifiedBoxPlotUnpooledByLeadObs plot = new ModifiedBoxPlotUnpooledByLeadObs();            
        final JFreeChart chart = new JFreeChart(name,new Font("Verdana", Font.BOLD, 12),plot,true);
        chart.setBackgroundPaint(Color.white);
        chart.getTitle().setMargin(7,0,7,0);
        chart.setAntiAlias(false);
        chart.removeLegend();
        return chart;        
    }

    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/          
    
    /**
     * Adds a dataset to the plot or throws an exception if the data are of an 
     * incorrect type.
     *
     * @param data the data
     */
    
    public void addDataset(String key, MetricResult data) throws IllegalArgumentException {
        if(!(data instanceof DoubleMatrix2DResult)) {
            throw new IllegalArgumentException("Unexpected input data for the modified box plot by observed amount.");
        }
        ConcreteBoxPlotDataset d = new ConcreteBoxPlotDataset(key);
        double[][] dp = ((DoubleMatrix2DResult)data).getResult().toArray();
        //Add the boxes
        for(int i = 1; i < dp.length; i++) {  //First row contains thresholds
            double[] nextBox = new double[dp[i].length-1];
            System.arraycopy(dp[i],1,nextBox,0,nextBox.length);  //First column contains observation
            BoxPlotItem item = new BoxPlotItem(nextBox);
            d.add(dp[i][0],item);  //Observation
        }
               
        //Add new dataset
        int count = getDatasetCount();
        setDataset(count,d);       
        //Set the renderer
        final BoxPlotRenderer renderer = new BoxPlotRenderer();
        renderer.setArtifactPaint(Color.red);  //Red whiskers
        renderer.setToolTipGenerator(new BoxAndWhiskerXYToolTipGenerator());
        setRenderer(count,renderer);  
        
    }    
    
    /**
     * Appends the real units to the appropriate axes of the plot.
     * 
     * @param units the units to appendRowsShallow
     */
    
    public void setRealUnits(String units) {
        String c = getRangeAxis().getLabel();
        String d = getDomainAxis().getLabel();
        c = c + " in '" + units + "'";
        d = d + " in '" + units + "'";
        getRangeAxis().setLabel(c);  
        getDomainAxis().setLabel(d);  
    }      
    
}
