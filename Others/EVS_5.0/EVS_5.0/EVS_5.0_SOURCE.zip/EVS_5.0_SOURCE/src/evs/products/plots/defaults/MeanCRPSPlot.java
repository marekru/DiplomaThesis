package evs.products.plots.defaults;

//JFreeChart dependencies
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;

//EVS dependencies
import evs.metric.metrics.Metric;
import evs.metric.metrics.DecomposableScore;
import evs.metric.results.MetricResult;
import evs.metric.results.MetricResultByLeadTime;

//Java awt dependencies
import java.awt.Color;
import java.awt.Font;

/**
 * Constructs a default plot of the mean Continuous Ranked Probability Score (CRPS)
 * based on multiple lead times.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class MeanCRPSPlot extends DefaultXYPlotByLeadTime implements EVSPlot, RealValuedPlot, ScoreDecompositionPlot {
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/    
    
    /**
     * Constructs a mean CRPS plot with no input arguments.  The data must be set later.
     */
    
    public MeanCRPSPlot() {
        super();
        ((NumberAxis)getRangeAxis()).setAutoRangeIncludesZero(true);       
    }

    /*******************************************************************************
     *                                                                             *
     *                              ACCESSOR METHODS                               *
     *                                                                             *
     ******************************************************************************/     
    
    /**
     * Returns a default chart with a plot that extends evs.products.plots.EVSPlot.
     *
     * @return a default chart
     */

    public static JFreeChart getDefaultChart() {
        return getDefaultChart(Metric.CRPS);
    }
    
    /**
     * Returns a default chart with a plot that extends evs.products.plots.EVSPlot.
     *
     * @param type the chart type: one of the static final variables in evs.metric.results.EnsembleScoreDecomposition
     * @return a default chart
     */

    public static JFreeChart getDefaultChart(int type) {
        String name = "";
        String rangeAx = "";
        switch(type) {
            case DecomposableScore.OVERALL_SCORE: {
                name = "Mean Continuous Ranked Probability Score (CRPS) by forecast lead time.";
                rangeAx = "CRPS";
            }; break;
            case DecomposableScore.RELIABILITY: {
                name = "Mean Continuous Ranked Probability Score (CRPS) reliability component by forecast lead time.";
                rangeAx = "CRPS reliability";
            }; break;
            case DecomposableScore.RESOLUTION: {
                name = "Mean Continuous Ranked Probability Score (CRPS) resolution component by forecast lead time.";
                rangeAx = "CRPS resolution";
            }; break;
            case DecomposableScore.UNCERTAINTY: {
                name = "Mean Continuous Ranked Probability Score (CRPS) uncertainty component by forecast lead time.";
                rangeAx = "CRPS uncertainty";
            }; break;
            case DecomposableScore.POTENTIAL: {
                name = "Mean Continuous Ranked Probability Score (CRPS) potential by forecast lead time.";
                rangeAx = "Potential CRPS";
            }; break;
            default : {
                throw new IllegalArgumentException("Unrecognized score type identifier for MeanCRPSPlot.");
            }
        }
        MeanCRPSPlot plot = new MeanCRPSPlot();            
        final JFreeChart chart = new JFreeChart(name,new Font("Verdana", Font.BOLD, 12),plot,true);
        chart.setBackgroundPaint(Color.white);
        chart.getTitle().setMargin(7,0,7,0);
        chart.setAntiAlias(false);
        plot.getRangeAxis().setLabel(rangeAx); 
        chart.getLegend().setBorder(org.jfree.chart.block.BlockBorder.NONE);
        return chart;                    
    }    
    
    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/          
    
    /**
     * Adds a dataset to the plot or throws an exception if the data are of an 
     * incorrect type.
     *
     * @param data the data
     */
    
    public void addDataset(String key, MetricResult data) throws IllegalArgumentException {
        if(!(data instanceof MetricResultByLeadTime)) {
            throw new IllegalArgumentException("Unexpected input data for the plot.");
        }
        addThresholdDataset(key,data);
    }       
    
    /**
     * Appends the real units to the appropriate axes of the plot.
     * 
     * @param units the units to append
     */
    
    public void setRealUnits(String units) {
        String c = getRangeAxis().getLabel();
        c = c + " in '" + units + "'";
        getRangeAxis().setLabel(c);        
    }    
    
}
