package evs.products.plots.defaults;

//JFreeChart dependencies
import java.awt.Color;
import java.awt.Font;

import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CombinedDomainXYPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYErrorRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.DefaultIntervalXYDataset;
import org.jfree.data.xy.DefaultXYDataset;
import org.jfree.data.xy.XYDataset;

import evs.metric.metrics.Metric;
import evs.metric.results.DoubleMatrix2DResult;
import evs.metric.results.MetricResult;

/**
 * Constructs a default plot of XY data with sample counts in a secondary plot.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DefaultXYAndSamplePlot extends CombinedDomainXYPlot implements EVSPlot, EVSThresholdPlot {
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/    
    
    /**
     * Constructs a default XY plot.
     */
    
    public DefaultXYAndSamplePlot() {
        super();
        
        //Create two XYPlots.
        final XYPlot relPlot = new XYPlot();
        final XYPlot samplePlot = new XYPlot();
        
        //Set some default axes
        final NumberAxis xAxis = new NumberAxis("Untitled x axis");
        final NumberAxis yAxis = new NumberAxis("Untitled y axis");
        final NumberAxis yAxis2 = new NumberAxis("");
        xAxis.setTickLabelFont(new Font("Verdana", Font.PLAIN, 8));
        yAxis.setTickLabelFont(new Font("Verdana", Font.PLAIN, 8));
        yAxis2.setTickLabelFont(new Font("Verdana", Font.PLAIN, 8));
        yAxis.setAutoRangeIncludesZero(false);
        setDomainAxis(xAxis);
        setRangeAxis(yAxis);          
        relPlot.setDomainAxis(xAxis);
        relPlot.setRangeAxis(yAxis);    
        samplePlot.setDomainAxis(xAxis);
        samplePlot.setDomainAxisLocation(AxisLocation.TOP_OR_LEFT);
        samplePlot.setRangeAxis(yAxis2);
        //Hide the grid lines
        relPlot.setDomainGridlinesVisible(false);
        relPlot.setRangeGridlinesVisible(false);  
        samplePlot.setDomainGridlinesVisible(false);
        samplePlot.setRangeGridlinesVisible(false);  
        setGap(10.0);        
        //Add the subplots...
        add(relPlot, 5);
        add(samplePlot, 1);
        setOrientation(PlotOrientation.VERTICAL);
    }

    /*******************************************************************************
     *                                                                             *
     *                              ACCESSOR METHODS                               *
     *                                                                             *
     ******************************************************************************/     
    
    /**
     * Returns a default chart with a plot that extends evs.products.plots.EVSPlot.
     *
     * @return a default chart
     */
    
    public static JFreeChart getDefaultChart() {
        final String name = "Untitled.";
        final DefaultXYAndSamplePlot plot = new DefaultXYAndSamplePlot();            
        final JFreeChart chart = new JFreeChart(name,new Font("Verdana", Font.BOLD, 12),plot,true);
        chart.setBackgroundPaint(Color.white);
        chart.getTitle().setMargin(7,0,7,0);
        chart.setAntiAlias(false);
        chart.removeLegend();
        return chart;                    
    }      
    
    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/          
    
    /**
     * Adds a dataset to the plot or throws an exception if the data are of an 
     * incorrect type.
     *
     * @param data the data
     */
    
    public void addThresholdDataset(final String key, final MetricResult data) throws IllegalArgumentException {
        if(!(data instanceof DoubleMatrix2DResult)) {
            throw new IllegalArgumentException("Unexpected input data for the xy plot.");
        }

        //Set the reliability data first (then samples data)
        //The reliability data may have sampling uncertainty intervals
        final XYPlot rel = (XYPlot)getSubplots().get(0);
        XYDataset d = null;
        final DoubleMatrix2DResult dr = (DoubleMatrix2DResult)data;
        final double[][] source = dr.getResult().toArray();
        if(source.length < 3) {
            throw new IllegalArgumentException("Unexpected input for the xy plot: expected at least three rows with samples in last row.");
        }
        double[][] nextRes = null;
        final boolean interval = dr.hasMainInterval();
        if (interval) {
            d = new DefaultIntervalXYDataset();
            nextRes = new double[6][source[0].length];
            nextRes[0] = source[0];
            nextRes[1] = source[0];
            nextRes[2] = source[0];
            nextRes[3] = source[1];

            //Add lower and upper bounds for Y
            final MetricResult[] bounds = dr.getMainIntervalResults();
            final double[][] lowerY = ((DoubleMatrix2DResult)bounds[0]).getResult().toArray();
            final double[][] upperY = ((DoubleMatrix2DResult)bounds[1]).getResult().toArray();
            for(int i = 0; i < lowerY[1].length; i++) {
                if(lowerY[1][i]==Metric.NULL_DATA) {
                    lowerY[1][i]=nextRes[3][i];
                }
                if(upperY[1][i]==Metric.NULL_DATA) {
                    upperY[1][i]=nextRes[3][i];
                }
            }
            nextRes[4] = lowerY[1];
            nextRes[5] = upperY[1];
            ((DefaultIntervalXYDataset) d).addSeries(key, nextRes);
        } else {
            d = new DefaultXYDataset();
            nextRes = new double[][]{source[0],source[1]};
            ((DefaultXYDataset) d).addSeries(key, nextRes);
        }

        final int count = rel.getDatasetCount();
        rel.setDataset(count, d);

        //Set a renderer for the reliability data
        XYLineAndShapeRenderer rend = null;
        if (interval) {
            rend = new XYErrorRenderer();
            ((XYErrorRenderer) rend).setDrawYError(true);
            ((XYErrorRenderer) rend).setDrawXError(false);
            ((XYErrorRenderer) rend).setCapLength(ERROR_BAR_CAP_LENGTH);  //Cap length of error bars
            rend.setLinesVisible(true);
        } else {
            rend = new XYLineAndShapeRenderer(true, true);
        }
        rend.setShapesVisible(!interval);
        rend.setShapesFilled(false);

        rel.setRenderer(count, rend);
        final Color c = (Color) rel.getRenderer(count).getSeriesPaint(0);
        //Avoid yellow, for which red and green are always 255, but blue varies
        //because the colors are determined automatically to maximize visual differences
        //between datasets
        if (c!= null && c.getRed() == 255 && c.getGreen() == 255) {
            rel.getRenderer(count).setSeriesPaint(0, Color.orange);
            if (interval) {
                ((XYErrorRenderer) rend).setErrorPaint(Color.orange);
            }
        }

        //Set the samples data
        final XYPlot samples = (XYPlot)getSubplots().get(1);
        final DefaultXYDataset d2 = new DefaultXYDataset();
        d2.addSeries(key,new double[][]{source[0],source[2]});
        samples.setDataset(count, d2);
        samples.getRangeAxis().setLabel("Samples");
        final XYLineAndShapeRenderer rend2 = new XYLineAndShapeRenderer(true,true);       
        rend2.setShapesFilled(false);       
        rend2.setSeriesPaint(0,rel.getRenderer(count).getSeriesPaint(0));
        rend2.setSeriesShape(0,rel.getRenderer(count).getSeriesShape(0));
        samples.setRenderer(count,rend2);
        rend2.setSeriesVisibleInLegend(false);        
        Color c2 = (Color)samples.getRenderer(count).getSeriesPaint(0);
        //Avoid yellow, for which red and green are always 255, but blue varies
        //because the colors are determined automatically to maximize visual differences 
        //between datasets
        if(c2!= null && c2.getRed()==255 && c2.getGreen()==255) {
            samples.getRenderer(count).setSeriesPaint(0,Color.orange);
        }
        
    }

    /**
     * Adds a dataset to the plot or throws an exception if the data are of an
     * incorrect type.
     *
     * @param key a unique string identifier for the result
     * @param data the data
     */

    public void addDataset(final String key, final MetricResult data) throws IllegalArgumentException {
        addThresholdDataset(key,data);
    }
     
    
}
