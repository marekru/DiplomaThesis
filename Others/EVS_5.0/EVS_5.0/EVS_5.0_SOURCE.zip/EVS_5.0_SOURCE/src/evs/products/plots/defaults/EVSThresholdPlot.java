package evs.products.plots.defaults;

import evs.metric.results.MetricResult;

/**
 * Identifies a plot that shows data for a series of threshold values. By default,
 * the implementation of addThresholdDataset(String key, MetricResult data) should
 * only plot results for "main" thresholds, as identified by the DoubleProcedureParameter
 * associated with a specific threshold metric result.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */
public interface EVSThresholdPlot {

    /**
     * Adds a multi-threshold dataset.  Plots the results for "main" thresholds
     * only.
     *
     * @param key the dataset key
     * @param data the data
     */

    void addThresholdDataset(String key, MetricResult data) throws IllegalArgumentException;

}
