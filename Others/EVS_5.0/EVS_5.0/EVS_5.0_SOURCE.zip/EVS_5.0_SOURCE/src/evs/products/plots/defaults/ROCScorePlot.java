package evs.products.plots.defaults;

//JFreeChart dependencies
import evs.metric.metrics.Metric;
import org.jfree.chart.*;
import org.jfree.data.xy.*;
import org.jfree.chart.renderer.xy.*;

//Java awt dependencies
import java.awt.Color;
import java.awt.Font;

//Java util dependencies
import java.util.Iterator;
import java.util.TreeMap;
import java.util.Vector;

//EVS dependencies
import evs.metric.results.*;
import evs.metric.parameters.*;
import evs.utilities.matrix.*;

/**
 * Constructs a default plot of the ROC Score based on multiple lead times.
 *
 * @author james.empirical.brown@noaa.gov
 * @version 4.0
 */

public class ROCScorePlot extends DefaultXYPlotByLeadTime implements EVSPlot {
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/    
    
    /**
     * Constructs a ROC score plot with no input arguments.  The data must be set later.
     */
    
    public ROCScorePlot() {
        super();
        getRangeAxis().setLabel("ROC Score");
        getRangeAxis().setRange(-1.0,1.0);
    }

    /*******************************************************************************
     *                                                                             *
     *                              ACCESSOR METHODS                               *
     *                                                                             *
     ******************************************************************************/     
    
    /**
     * Returns a default chart with a plot that extends evs.products.plots.EVSPlot.
     *
     * @return a default chart
     */
    
    public static JFreeChart getDefaultChart() {
        String name = "ROC Score against forecast lead time for different event probability thesholds.";
        ROCScorePlot plot = new ROCScorePlot();            
        final JFreeChart chart = new JFreeChart(name,new Font("Verdana", Font.BOLD, 12),plot,true);
        chart.setBackgroundPaint(Color.white);
        chart.getTitle().setMargin(7,0,7,0);
        chart.setAntiAlias(false);
        chart.getLegend().setBorder(org.jfree.chart.block.BlockBorder.NONE);
        return chart;                  
    }
    
    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/          
    
    /**
     * Adds a dataset to the plot or throws an exception if the data are of an 
     * incorrect type.
     *
     * @param data the data
     */
    
    public void addDataset(String key, MetricResult data) throws IllegalArgumentException {
        if(!(data instanceof MetricResultByLeadTime)) {
            throw new IllegalArgumentException("Unexpected input data for the ROC Score plot: expected result by lead time, got: "+data.getClass()+".");
        }
        addThresholdDataset(key,data);
    }

    /**
     * Adds a multi-threshold dataset.  Use this method when plotting both empirical
     * and fitted AUC.
     *
     * @param key the dataset key
     * @param data the data
     */

    public void addThresholdDataset(String key, MetricResult data) throws IllegalArgumentException {
        try {
            MetricResultByLeadTime dp = (MetricResultByLeadTime)data;
            TreeMap<Double,MetricResult> res = dp.getResults();
            Iterator i = res.keySet().iterator();
            Object[] thresholds = ((MetricResultByThreshold) res.get(i.next())).
                    getResults().keySet().toArray();

            //Add a dataset for each "main" threshold
            for (int j = 0; j < thresholds.length; j++) {
                DoubleProcedureParameter nP = (DoubleProcedureParameter) thresholds[j];
                if (nP.isMainThreshold().getParVal()) {
                    //Construct the threshold dataset
                    //Include only non-null points
                    Vector<double[]> empiricalPoints = new Vector<double[]>();
                    Vector<double[]> fittedPoints = new Vector<double[]>();

                    boolean interval = false;
                    Iterator k = res.keySet().iterator();
                    while (k.hasNext()) {
                        double next = (Double) k.next();
                        MetricResultByThreshold r = (MetricResultByThreshold) res.get(next);
                        if (r.hasResult(nP)) {
                            MetricResult r2 = r.getResult(nP);
                            double empirical = Metric.NULL_DATA;
                            double fitted = Metric.NULL_DATA;
                            if (r2 instanceof DoubleMatrix1DResult) {
                                DoubleMatrix1D da = ((DoubleMatrix1DResult)r2).getResult();
                                empirical = da.get(0);
                                fitted = da.get(1);
                            }
                            //Add sampling intervals for EITHER empirical (if not fitted) OR fitted (if available)
                            //Empirical ROC scores
                            if (empirical != Metric.NULL_DATA) {
                                //Only add if NO fitted (fitted will have interval, since they both do or do not)
                                if(r2.hasMainInterval() && fitted==Metric.NULL_DATA) {
                                    MetricResult[] bounds = r2.getMainIntervalResults();
                                    DoubleMatrix1DResult lower = ((DoubleMatrix1DResult) bounds[0]);
                                    DoubleMatrix1DResult upper = ((DoubleMatrix1DResult) bounds[1]);
                                    double low = lower.getResult().get(0);
                                    double high = upper.getResult().get(0);
                                    if (low != Metric.NULL_DATA && high != Metric.NULL_DATA) {
                                        interval = true;
                                        empiricalPoints.add(new double[]{next, empirical, low, high});
                                    } else {
                                        empiricalPoints.add(new double[]{next, empirical});
                                    }
                                } else {
                                    empiricalPoints.add(new double[]{next, empirical});                                    
                                }
                            }
                            //Fitted ROC scores
                            if (fitted!=Metric.NULL_DATA) {
                                if(r2.hasMainInterval()) {
                                    MetricResult[] bounds = r2.getMainIntervalResults();
                                    DoubleMatrix1DResult lower = ((DoubleMatrix1DResult) bounds[0]);
                                    DoubleMatrix1DResult upper = ((DoubleMatrix1DResult) bounds[1]);
                                    double low = lower.getResult().get(1);
                                    double high = upper.getResult().get(1);    
                                    if (low != Metric.NULL_DATA && high != Metric.NULL_DATA) {
                                        interval = true;
                                        fittedPoints.add(new double[]{next, fitted, low, high});
                                    } else {
                                        fittedPoints.add(new double[]{next, fitted});
                                    }
                                } else {
                                    fittedPoints.add(new double[]{next, fitted});
                                }
                            }
                        }
                    }
                    //Fitted available?
                    boolean fitted = !fittedPoints.isEmpty();

                    //Construct the dataset for the empirical ROC
                    int sizeEmpirical = empiricalPoints.size();
                    double[][] nextEmpiricalRes = null;
                    XYDataset d = null;
                    if (interval&&!fitted) {
                        d = new DefaultIntervalXYDataset();
                        nextEmpiricalRes = new double[6][sizeEmpirical];
                    } else {
                        d = new DefaultXYDataset();
                        nextEmpiricalRes = new double[2][sizeEmpirical];
                    }
                    for (int m = 0; m < sizeEmpirical; m++) {
                        double[] p = empiricalPoints.get(m);
                        //Interval
                        if(interval&&!fitted) {
                            nextEmpiricalRes[0][m] = p[0];
                            nextEmpiricalRes[1][m] = p[0];
                            nextEmpiricalRes[2][m] = p[0];
                            nextEmpiricalRes[3][m] = p[1];
                            //Only show non-null interval bounds: use nominal value otherwise
                            if (p.length>2 && p[2] != Metric.NULL_DATA && p[3] != Metric.NULL_DATA) {
                                nextEmpiricalRes[4][m] = p[2];
                                nextEmpiricalRes[5][m] = p[3];
                            } else {
                                nextEmpiricalRes[4][m] = p[1];
                                nextEmpiricalRes[5][m] = p[1];
                            }
                        }
                        //No interval
                        else {
                            nextEmpiricalRes[0][m] = p[0];
                            nextEmpiricalRes[1][m] = p[1];
                        }
                    }
                    String empName = "";
                    if (!fitted) {  //Add actual name if no fitted ROC
                        empName = nP + "";
                    }
                    if (interval&&!fitted) {
                        ((DefaultIntervalXYDataset) d).addSeries(empName, nextEmpiricalRes);
                    } else {
                        ((DefaultXYDataset) d).addSeries(empName, nextEmpiricalRes);
                    }
                    int count = getDatasetCount() + 1;
                    setDataset(count, d);                    
                    
                    //Add fitted ROC if available
                    if (fitted) {
                        int sizeFitted = fittedPoints.size();
                        double[][] nextFittedRes = null;
                        XYDataset e = null;
                        if (interval) {
                            e = new DefaultIntervalXYDataset();
                            nextFittedRes = new double[6][sizeFitted];
                        } else {
                            e = new DefaultXYDataset();
                            nextFittedRes = new double[2][sizeFitted];
                        }
                        for (int m = 0; m < sizeFitted; m++) {
                            double[] p = fittedPoints.get(m);
                            //Interval
                            if(interval) {
                                nextFittedRes[0][m] = p[0];
                                nextFittedRes[1][m] = p[0];
                                nextFittedRes[2][m] = p[0];
                                nextFittedRes[3][m] = p[1];
                                //Only show non-null interval bounds: use nominal value otherwise
                                if (p.length>2 && p[2] != Metric.NULL_DATA && p[3] != Metric.NULL_DATA) {
                                    nextFittedRes[4][m] = p[2];
                                    nextFittedRes[5][m] = p[3];
                                } else {
                                    nextFittedRes[4][m] = p[1];
                                    nextFittedRes[5][m] = p[1];
                                }
                            }
                            //No interval
                            else {
                                nextFittedRes[0][m] = p[0];
                                nextFittedRes[1][m] = p[1];
                            }
                        }
                        String fittedName = nP + "";
                        if (interval) {
                            ((DefaultIntervalXYDataset) e).addSeries(fittedName, nextFittedRes);
                        } else {
                            ((DefaultXYDataset) e).addSeries(fittedName, nextFittedRes);
                        }
                        setDataset(count + 1, e);
                    }
                    
                    //Set renderers for the empirical points
                    XYLineAndShapeRenderer empiricalRend = null;
                    XYLineAndShapeRenderer fittedRend = null;
                    //Need empirical renderer only
                    if (!fitted) {
                        if(interval) {
                            empiricalRend = new XYErrorRenderer();
                            empiricalRend.setLinesVisible(true);
                            empiricalRend.setShapesVisible(true);  //Show nominal value if only one time
                            ((XYErrorRenderer) empiricalRend).setDrawYError(true);
                            ((XYErrorRenderer) empiricalRend).setDrawXError(false);
                            ((XYErrorRenderer) empiricalRend).setCapLength(ERROR_BAR_CAP_LENGTH);  //Cap length of error bars
                        } else {
                            empiricalRend = new XYLineAndShapeRenderer(true, true);
                        }
                        empiricalRend.setShapesFilled(false);
                        setRenderer(count, empiricalRend);
                    } 
                    //Empirical and fitted renderers
                    else {
                        //Empirical renderer: use unfilled shapes only
                        empiricalRend = new XYLineAndShapeRenderer(false,true);
                        empiricalRend.setShapesFilled(false);
                        //Use line only for fitted renderer
                        if(interval) {
                            fittedRend = new XYErrorRenderer();
                            fittedRend.setLinesVisible(true);
                            fittedRend.setShapesVisible(false);
                            ((XYErrorRenderer) fittedRend).setDrawYError(true);
                            ((XYErrorRenderer) fittedRend).setDrawXError(false);
                            ((XYErrorRenderer) fittedRend).setCapLength(ERROR_BAR_CAP_LENGTH);                            
                        } else {
                            fittedRend = new XYLineAndShapeRenderer(true,false);
                        }
                        fittedRend.setShapesFilled(false);
                        setRenderer(count, empiricalRend);
                        setRenderer(count+1, fittedRend);
                    }

                    Color c = (Color) empiricalRend.getSeriesPaint(0);
                    //Avoid yellow, for which red and green are always 255, but blue varies
                    //because the colors are determined automatically to maximize visual differences
                    //between datasets
                    if (c.getRed() == 255 && c.getGreen() == 255) {
                        c=Color.orange;
                        empiricalRend.setSeriesPaint(0,c);
                        //Set the error paint (only one will have the error paint)
                        if (empiricalRend instanceof XYErrorRenderer) {
                            ((XYErrorRenderer) empiricalRend).setErrorPaint(c);
                        }
                        //Fitted has the error paint
                        if(fittedRend instanceof XYErrorRenderer) {
                            ((XYErrorRenderer) fittedRend).setErrorPaint(c);
                        }
                    }
                    //Coordinate colors for empirical and fitted
                    if (fitted) {
                        fittedRend.setSeriesPaint(0,c);
                    }
                }
            }
            setTimeTicks(dp,defTCount);
        } catch(ClassCastException e) {
            e.printStackTrace();
            throw new IllegalArgumentException("Unexpected input data for the ROC Score plot.");
        }
    }
     
}
