package evs.products.plots.defaults;

//JFreeChart dependencies
import evs.metric.metrics.Metric;
import org.jfree.chart.*;
import org.jfree.chart.plot.*;
import org.jfree.chart.axis.*;
import org.jfree.chart.renderer.xy.*;
import org.jfree.data.xy.*;

//Java awt dependencies
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;

//Java util dependencies
import java.util.Iterator;
import java.util.TreeMap;
import java.util.Vector;

//EVS dependencies
import evs.metric.results.*;
import evs.metric.parameters.*;

/**
 * Constructs a default plot of a statistic that comprises a single number for
 * multiple lead times.
 *
 * @author evs@hydrosolved.com
 */

public class DefaultXYPlotByLeadTime extends XYPlot implements EVSPlot, EVSThresholdPlot {
    
    /*******************************************************************************
     *                                                                             *
     *                                  VARIABLES                                  *
     *                                                                             *
     ******************************************************************************/      
    
    /**
     * Default number of ticks to display for a time-series, where a fixed time
     * axis is preferred to an auto-ranged axis.
     */
    
    protected int defTCount = 20;
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/    
    
    /**
     * Constructs a plot with no input arguments.  The data must be set later.
     */
    
    public DefaultXYPlotByLeadTime() {
        super();
        //Set some default axes
        final NumberAxis xAxis = new NumberAxis("Forecast lead time (hours)");
        //Set name in subclass
        final NumberAxis yAxis = new NumberAxis("Unnamed statistic");
        xAxis.setTickLabelFont(new Font("Verdana", Font.PLAIN, 8));
        yAxis.setTickLabelFont(new Font("Verdana", Font.PLAIN, 8));
        yAxis.setAutoRangeIncludesZero(false);
        setDomainAxis(xAxis);
        setRangeAxis(yAxis);
        //Hide the grid lines
        setDomainGridlinesVisible(false);
        setRangeGridlinesVisible(false);     
        //Show zero line
        final XYLineAndShapeRenderer pRend = new XYLineAndShapeRenderer(true,true);
        pRend.setSeriesStroke(0,new BasicStroke(2));
        pRend.setShapesVisible(false);
        pRend.setSeriesPaint(0,Color.black);
        setRenderer(pRend);      
        setRangeZeroBaselineVisible(true);
    }

    /*******************************************************************************
     *                                                                             *
     *                              ACCESSOR METHODS                               *
     *                                                                             *
     ******************************************************************************/     
    
    /**
     * Returns a default chart with a plot that extends evs.products.plots.EVSPlot.
     *
     * @return a default chart
     */
    
    public static JFreeChart getDefaultChart() {
        String name = "Untitled";
        DefaultXYPlotByLeadTime plot = new DefaultXYPlotByLeadTime();            
        final JFreeChart chart = new JFreeChart(name,new Font("Verdana", Font.BOLD, 12),plot,true);
        chart.setBackgroundPaint(Color.white);
        chart.getTitle().setMargin(7,0,7,0);
        chart.setAntiAlias(false);
        chart.removeLegend();
        return chart;        
    }   
    
    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/          
    
    /**
     * Adds a dataset to the plot or throws an exception if the data are of an 
     * incorrect type.
     *
     * @param key the key
     * @param data the data
     */
    
    public void addDataset(String key, MetricResult data) throws IllegalArgumentException {
        if(!(data instanceof MetricResultByLeadTime) || (((MetricResultByLeadTime)data).getIDForStoredResults() != MetricResult.DOUBLE_RESULT)) {
            throw new IllegalArgumentException("Unexpected input data for the plot.");
        }
        
        MetricResultByLeadTime dp = (MetricResultByLeadTime)data;
        TreeMap<Double,MetricResult> res = dp.getResults();
        Vector<double[]> points = new Vector<double[]>();
        Iterator i = res.keySet().iterator();
        boolean interval = false;
        while(i.hasNext()) {
            double next = (Double) i.next();
            DoubleResult dr = (DoubleResult)res.get(next);
            double da = dr.getResult();
            if(da != Metric.NULL_DATA) {
                if(dr.hasMainInterval()) {
                    MetricResult[] bounds = dr.getMainIntervalResults();
                    double lower = ((DoubleResult)bounds[0]).getResult();
                    double upper = ((DoubleResult)bounds[1]).getResult();
                    points.add(new double[]{next, da, lower, upper});
                    //Add points, but only set interval flag for display if some stats
                    //have valid intervals
                    if(lower != Metric.NULL_DATA && upper != Metric.NULL_DATA) {
                        interval = true;
                    }
                } else {
                    points.add(new double[]{next, da});
                }
            }
        }

        //Construct the dataset
        int size = points.size();
        double[][] nextRes = null;
        XYDataset d = null;
        if (interval) {
            d = new DefaultIntervalXYDataset();
            nextRes = new double[6][size];
        } else {
            d = new DefaultXYDataset();
            nextRes = new double[2][size];
        }
        for (int m = 0; m < size; m++) {
            double[] p = points.get(m);
            //No interval
            if (p.length == 2) {
                nextRes[0][m] = p[0];
                nextRes[1][m] = p[1];
            } //Interval
            else {
                nextRes[0][m] = p[0];
                nextRes[1][m] = p[0];
                nextRes[2][m] = p[0];
                nextRes[3][m] = p[1];
                //Only show non-null interval bounds: use nominal value otherwise
                if(p[2]!=Metric.NULL_DATA && p[3]!=Metric.NULL_DATA) {
                    nextRes[4][m] = p[2];
                    nextRes[5][m] = p[3];
                } else {
                    nextRes[4][m] = p[1];
                    nextRes[5][m] = p[1];
                }
            }
        }
        if (interval) {
            ((DefaultIntervalXYDataset) d).addSeries(key, nextRes);
        } else {
            ((DefaultXYDataset) d).addSeries(key, nextRes);
        }
        int count = getDatasetCount() + 1;
        setDataset(count, d);

        //Set a renderer
        XYLineAndShapeRenderer rend = null;
        if (interval) {
            rend = new XYErrorRenderer();
            ((XYErrorRenderer) rend).setDrawYError(true);
            ((XYErrorRenderer) rend).setDrawXError(false);
            ((XYErrorRenderer) rend).setCapLength(ERROR_BAR_CAP_LENGTH);  //Cap length of error bars
            rend.setLinesVisible(true);
        } else {
            rend = new XYLineAndShapeRenderer(true, true);
        }
        rend.setShapesVisible(!interval || interval && size==1);  //Show nominal value if only one point.
        rend.setShapesFilled(false);

        setRenderer(count, rend);
        Color c = (Color) getRenderer(count).getSeriesPaint(0);
        //Avoid yellow, for which red and green are always 255, but blue varies
        //because the colors are determined automatically to maximize visual differences
        //between datasets
        if (c.getRed() == 255 && c.getGreen() == 255) {
            getRenderer(count).setSeriesPaint(0, Color.orange);
            if (interval) {
                ((XYErrorRenderer) rend).setErrorPaint(Color.orange);
            }
        }
    }
    
    /**
     * Adds a multi-threshold dataset.  Use this method when overriding addDataset()
     * in a subclass for which multiple thresholds are required by lead time in a
     * single plot.
     * 
     * @param key the dataset key
     * @param data the data
     */
    
    public void addThresholdDataset(String key, MetricResult data) throws IllegalArgumentException {
        try {
            MetricResultByLeadTime dp = (MetricResultByLeadTime)data;
            TreeMap<Double,MetricResult> res = dp.getResults();
            Iterator i = res.keySet().iterator();
            Object[] thresholds = ((MetricResultByThreshold) res.get(i.next())).getResults().keySet().toArray();

            //Add a dataset for each "main" threshold
            for (int j = 0; j < thresholds.length; j++) {
                DoubleProcedureParameter nP = (DoubleProcedureParameter) thresholds[j];
                if (nP.isMainThreshold().getParVal()) {
                    //Construct the threshold dataset
                    //Include only non-null points
                    Vector<double[]> points = new Vector();
                    Iterator k = res.keySet().iterator();
                    boolean interval = false;
                    while (k.hasNext()) {
                        double next = (Double) k.next();
                        MetricResultByThreshold r = (MetricResultByThreshold) res.get(next);
                        if (r.hasResult(nP)) {
                            MetricResult r2 = r.getResult(nP);
                            double d = Metric.NULL_DATA;
                            double lower = Metric.NULL_DATA;
                            double upper = Metric.NULL_DATA;
                            if (r2 instanceof DoubleResult) {
                                d = ((DoubleResult) r2).getResult();
                                if(r2.hasMainInterval()) {
                                    MetricResult[] bounds = r2.getMainIntervalResults();
                                    lower = ((DoubleResult)bounds[0]).getResult();
                                    upper = ((DoubleResult) bounds[1]).getResult();
                                    //Add points, but only set interval flag for display if some stats
                                    //have valid intervals
                                    if (lower != Metric.NULL_DATA && upper != Metric.NULL_DATA) {
                                        interval = true;
                                    }
                                }
                            }
                            if (d != Metric.NULL_DATA) {
                                if(lower!=Metric.NULL_DATA && upper !=Metric.NULL_DATA) {
                                    points.add(new double[]{next, d ,lower, upper});
                                } else {
                                    points.add(new double[]{next, d});
                                }
                            }
                        }
                    }

                    //Construct the dataset
                    int size = points.size();
                    double[][] nextRes = null;
                    XYDataset d = null;
                    if(interval) {
                        d = new DefaultIntervalXYDataset();
                        nextRes = new double[6][size];
                    } else {
                        d = new DefaultXYDataset();
                        nextRes = new double[2][size];
                    }
                    for (int m = 0; m < size; m++) {
                        double[] p = points.get(m);
                        //No interval
                        if(p.length==2) {
                            nextRes[0][m] = p[0];
                            nextRes[1][m] = p[1];
                        }
                        //Interval
                        else {
                            nextRes[0][m] = p[0];
                            nextRes[1][m] = p[0];
                            nextRes[2][m] = p[0];
                            nextRes[3][m] = p[1];
                            //Only show non-null interval bounds: use nominal value otherwise
                            if (p[2] != Metric.NULL_DATA && p[3] != Metric.NULL_DATA) {
                                nextRes[4][m] = p[2];
                                nextRes[5][m] = p[3];
                            } else {
                                nextRes[4][m] = p[1];
                                nextRes[5][m] = p[1];
                            }
                        }
                    }
                    if(interval) {
                        ((DefaultIntervalXYDataset)d).addSeries(nP + "", nextRes);
                    } else {
                        ((DefaultXYDataset)d).addSeries(nP + "", nextRes);
                    }
                    int count = getDatasetCount() + 1;  //Default dataset added already
                    setDataset(count, d);

                    //Set a renderer
                    XYLineAndShapeRenderer rend = null;
                    if(interval) {
                        rend = new XYErrorRenderer();
                        ((XYErrorRenderer)rend).setDrawYError(true);
                        ((XYErrorRenderer)rend).setDrawXError(false);
                        ((XYErrorRenderer)rend).setCapLength(ERROR_BAR_CAP_LENGTH);  //Cap length of error bars
                        rend.setLinesVisible(true);
                    } else {
                        rend = new XYLineAndShapeRenderer(true, true);
                    }
                    rend.setShapesVisible(!interval || interval && size==1);
                    rend.setShapesFilled(false);
                    
                    setRenderer(count, rend);
                    Color c = (Color) getRenderer(count).getSeriesPaint(0);
                    //Avoid yellow, for which red and green are always 255, but blue varies
                    //because the colors are determined automatically to maximize visual differences
                    //between datasets
                    if (c!= null && c.getRed() == 255 && c.getGreen() == 255) {
                    	getRenderer(count).setSeriesPaint(0, Color.orange);
                        if(interval) {
                            ((XYErrorRenderer)getRenderer(count)).setErrorPaint(Color.orange);
                        }
                    }
                }
            }
            setTimeTicks(dp,defTCount);
        } catch(ClassCastException e) {
            e.printStackTrace();
            throw new IllegalArgumentException("Unexpected input data for the plot.");
        }
    }    
    
    /**
     * Sets the number of ticks to display for the time axis.
     *
     * @param defTCount the tick count
     */
    
    public final void setDefaultTickCount(int defTCount) throws IllegalArgumentException {
        if(defTCount < 1) {
            throw new IllegalArgumentException("Specify a positive number of ticks.");
        }
        this.defTCount = defTCount;
    }    
    
    /**
     * Sets the time tick labels to the resolution of the specified dataset.
     *
     * @param res the dataset from which to determine resolution
     * @param tickCount the number of ticks
     */
    
    protected final void setTimeTicks(MetricResultByLeadTime res, int tickCount) {
        Double[] times = res.getResults().keySet().toArray(new Double[res.getResultCount()]);
        if(times.length > 1 && tickCount > 1) {
            NumberAxis y = (NumberAxis)getDomainAxis();
            double sep = times[1]-times[0];
            double unit = (times[times.length-1]-times[0]) / tickCount;          
            //Find nearest to unit that is divisible with sep
            double near = Math.ceil(unit/sep)*sep;
            y.setTickUnit(new NumberTickUnit(near));
        }
    }
     
}
