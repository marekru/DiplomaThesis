package evs.products.plots.defaults;

/**
 * Interface that identifies a plot that contains real units on one or more axes
 * and a method for setting those units.
 * 
 * @author evs@hydrosolved.com
 */
public interface RealValuedPlot {

    /**
     * Appends the real units to the appropriate axes of the plot.
     * 
     * @param units the units to append
     */
    
    public void setRealUnits(String units);
    
}
