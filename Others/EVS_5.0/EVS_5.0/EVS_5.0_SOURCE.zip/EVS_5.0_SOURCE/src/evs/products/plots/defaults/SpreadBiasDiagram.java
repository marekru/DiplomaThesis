package evs.products.plots.defaults;

//JFreeChart dependencies
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.DefaultXYDataset;
import org.jfree.chart.JFreeChart;
      
//EVS dependencies
import evs.metric.results.MetricResult;
import evs.metric.parameters.DoubleProcedureParameter;
import evs.metric.results.MetricResultByThreshold;

//Java util dependencies
import java.util.TreeMap;
import java.util.Iterator;

//Java awt dependencies
import java.awt.Font;
import java.awt.BasicStroke;
import java.awt.Color;

/**
 * Constructs a default spread-bias diagram.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class SpreadBiasDiagram extends DefaultXYPlot {
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/    
    
    /**
     * Constructs a spread-bias diagram with no input arguments.  The data must be set
     * later.
     */
    
    public SpreadBiasDiagram() {
        super();
        
        //Set some default axes
        getRangeAxis().setLabel("Fraction of observation falling in window of forecast distribution");
        getRangeAxis().setRange(0.0,1.0);
        getDomainAxis().setLabel("Size of window in probability units (starting at lowest forecast)");
        getDomainAxis().setRange(0.0,1.0);
        
        //Add a default line for the perfect score
        double[][] perfect = new double[][] {
            {0.0,1.0},
            {0.0,1.0}
        };
        DefaultXYDataset d = new DefaultXYDataset();
        d.addSeries("Perfect",perfect);
        setDataset(d);
        //Set the renderer for the default line
        final XYLineAndShapeRenderer pRend = new XYLineAndShapeRenderer(true,true);
        pRend.setShapesVisible(false);
        pRend.setSeriesStroke(0,new BasicStroke(2));
        pRend.setSeriesPaint(0,Color.black);
        setRenderer(0,pRend);
    }

    /*******************************************************************************
     *                                                                             *
     *                              ACCESSOR METHODS                               *
     *                                                                             *
     ******************************************************************************/         

    /**
     * Returns a default chart with a plot that extends evs.products.plots.EVSPlot.
     *
     * @return a default chart
     */
    
    public static JFreeChart getDefaultChart() {
        String name = "Spread-bias diagram.";
        SpreadBiasDiagram plot = new SpreadBiasDiagram();
        final JFreeChart chart = new JFreeChart(name,new Font("Verdana", Font.BOLD, 12),plot,true);
        chart.setBackgroundPaint(Color.white);
        chart.getTitle().setMargin(7,0,7,0);
        chart.setAntiAlias(false);
        chart.getLegend().setBorder(org.jfree.chart.block.BlockBorder.NONE);
        return chart;        
    }            

    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/             
    
    /**
     * Adds a dataset to the plot or throws an exception if the data are of an 
     * incorrect type.
     *
     * @param data the data
     */
    
    public void addDataset(String key, MetricResult data) throws IllegalArgumentException {
        //Iterate through the thresholds, calling addDataset in the superclass each time
        if(!(data instanceof MetricResultByThreshold) || ((MetricResultByThreshold)data).getIDForStoredResults()!=data.DOUBLE_MATRIX_2D_RESULT) {
            throw new IllegalArgumentException("Unexpected input data for the spread-bias diagram: "+data.getClass());
        }
        TreeMap<DoubleProcedureParameter,MetricResult> res = ((MetricResultByThreshold)data).getResults();
        Iterator k = res.keySet().iterator();
        while (k.hasNext()) {
            DoubleProcedureParameter key2 = (DoubleProcedureParameter) k.next();
            if (key2.isMainThreshold().getParVal()) {
                super.addDataset(key2 + "",res.get(key2));
            }
        }
    }         
    
}
