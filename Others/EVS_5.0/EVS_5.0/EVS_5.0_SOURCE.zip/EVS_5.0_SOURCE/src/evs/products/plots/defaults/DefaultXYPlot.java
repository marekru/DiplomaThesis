package evs.products.plots.defaults;

//JFreeChart dependencies
import org.jfree.chart.*;
import org.jfree.chart.plot.*;
import org.jfree.chart.axis.*;
import org.jfree.chart.renderer.xy.*;
import org.jfree.data.xy.*;
        
//Java awt dependencies
import java.awt.*;
        
//EVS dependencies
import evs.metric.results.*;
import evs.analysisunits.*;
import evs.metric.metrics.Metric;

/**
 * Constructs a default plot of XY data.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DefaultXYPlot extends XYPlot implements EVSPlot, EVSThresholdPlot {
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/    
    
    /**
     * Constructs a default XY plot.
     */
    
    public DefaultXYPlot() {
        super();
        
        //Set some default axes
        final NumberAxis xAxis = new NumberAxis("Untitled x axis");
        final NumberAxis yAxis = new NumberAxis("Untitled y axis");
        xAxis.setTickLabelFont(new Font("Verdana", Font.PLAIN, 8));
        yAxis.setTickLabelFont(new Font("Verdana", Font.PLAIN, 8));
        yAxis.setAutoRangeIncludesZero(false);
        setDomainAxis(xAxis);
        setRangeAxis(yAxis);        
        //Hide the grid lines
        setDomainGridlinesVisible(false);
        setRangeGridlinesVisible(false);   
        //Show zero line
        final XYLineAndShapeRenderer pRend = new XYLineAndShapeRenderer(true,true);
        pRend.setSeriesStroke(0,new BasicStroke(2));
        pRend.setShapesVisible(false);
        pRend.setSeriesPaint(0,Color.black);
        setRenderer(pRend);      
        setRangeZeroBaselineVisible(true);        
    }

    /*******************************************************************************
     *                                                                             *
     *                              ACCESSOR METHODS                               *
     *                                                                             *
     ******************************************************************************/     
    
    /**
     * Returns a default chart with a plot that extends evs.products.plots.EVSPlot.
     *
     * @return a default chart
     */
    
    public static JFreeChart getDefaultChart() {
        String name = "Untitled.";
        DefaultXYPlot plot = new DefaultXYPlot();            
        final JFreeChart chart = new JFreeChart(name,new Font("Verdana", Font.BOLD, 12),plot,true);
        chart.setBackgroundPaint(Color.white);
        chart.getTitle().setMargin(7,0,7,0);
        chart.setAntiAlias(false);
        chart.removeLegend();
        return chart;                    
    }      
    
    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/          
    
    /**
     * Adds a dataset to the plot or throws an exception if the data are of an 
     * incorrect type.
     *
     * @param data the data
     */
    
    public void addThresholdDataset(String key, MetricResult data) throws IllegalArgumentException {
        if(!(data instanceof DoubleMatrix2DResult)) {
            throw new IllegalArgumentException("Unexpected input data for the xy plot.");
        }
        XYDataset d = null;
        DoubleMatrix2DResult dr = (DoubleMatrix2DResult)data;
        double[][] source = dr.getResult().toArray();
        double[][] nextRes = null;
        boolean interval = dr.hasMainInterval();
        if (interval) {
            d = new DefaultIntervalXYDataset();
            nextRes = new double[6][source[0].length];
            nextRes[0] = source[0];
            nextRes[1] = source[0];
            nextRes[2] = source[0];
            nextRes[3] = source[1];

            //Add lower and upper bounds for Y
            //If any bound values correspond to the null value identifier replace them
            //with the nominal value of the statistic
            MetricResult[] bounds = dr.getMainIntervalResults();
            double[][] lowerY = ((DoubleMatrix2DResult)bounds[0]).getResult().toArray();
            double[][] upperY = ((DoubleMatrix2DResult)bounds[1]).getResult().toArray();
            for(int i = 0; i < lowerY[1].length; i++) {
                if(lowerY[1][i]==Metric.NULL_DATA) {
                    lowerY[1][i]=nextRes[3][i];
                }
                if(upperY[1][i]==Metric.NULL_DATA) {
                    upperY[1][i]=nextRes[3][i];
                }
            }
            nextRes[4] = lowerY[1];
            nextRes[5] = upperY[1];
            ((DefaultIntervalXYDataset) d).addSeries(key, nextRes);
        } else {
            d = new DefaultXYDataset();
            nextRes = source;
            ((DefaultXYDataset) d).addSeries(key, nextRes);
        }

        int count = getDatasetCount();
        setDataset(count, d);

        //Set a renderer
        XYLineAndShapeRenderer rend = null;
        if (interval) {
            rend = new XYErrorRenderer();
            ((XYErrorRenderer) rend).setDrawYError(true);
            ((XYErrorRenderer) rend).setDrawXError(false);
            ((XYErrorRenderer) rend).setCapLength(ERROR_BAR_CAP_LENGTH);  //Cap length of error bars
            rend.setLinesVisible(true);
        } else {
            rend = new XYLineAndShapeRenderer(true, true);
        }
        rend.setShapesVisible(!interval);
        rend.setShapesFilled(false);

        setRenderer(count, rend);
        Color c = (Color) getRenderer(count).getSeriesPaint(0);
        //Avoid yellow, for which red and green are always 255, but blue varies
        //because the colors are determined automatically to maximize visual differences
        //between datasets
        if (c!= null && c.getRed() == 255 && c.getGreen() == 255) {
            getRenderer(count).setSeriesPaint(0, Color.orange);
            if (interval) {
                ((XYErrorRenderer) rend).setErrorPaint(Color.orange);
            }
        }
    }

    /**
     * Adds a dataset to the plot or throws an exception if the data are of an
     * incorrect type.
     *
     * @param key a unique string identifier for the result
     * @param data the data
     */

    public void addDataset(String key, MetricResult data) throws IllegalArgumentException {
        addThresholdDataset(key,data);
    }
     
    
}
