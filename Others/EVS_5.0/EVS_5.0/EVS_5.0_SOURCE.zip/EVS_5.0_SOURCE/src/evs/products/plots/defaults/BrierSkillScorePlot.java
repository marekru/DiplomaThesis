package evs.products.plots.defaults;

//JFreeChart dependencies
import org.jfree.chart.JFreeChart;

//EVS dependencies
import evs.metric.results.MetricResult;
import evs.metric.metrics.DecomposableScore;

//Java awt dependencies
import java.awt.Color;
import java.awt.Font;

/**
 * Constructs a default plot of the BSS based on multiple lead times.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class BrierSkillScorePlot extends DefaultXYPlotByLeadTime implements EVSPlot {
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/    
    
    /**
     * Constructs a correlation plot with no input arguments.  The data must be set later.
     */
    
    public BrierSkillScorePlot() {
        super();
        getRangeAxis().setLabel("Brier Skill Score");
    }

    /*******************************************************************************
     *                                                                             *
     *                              ACCESSOR METHODS                               *
     *                                                                             *
     ******************************************************************************/     
    
    /**
     * Returns a default chart with a plot that extends evs.products.plots.EVSPlot.
     *
     * @return a default chart
     */

    public static JFreeChart getDefaultChart() {
        String name = "Brier Skill Score by forecast lead time.";
        BrierSkillScorePlot plot = new BrierSkillScorePlot();            
        final JFreeChart chart = new JFreeChart(name,new Font("Verdana", Font.BOLD, 12),plot,true);
        chart.setBackgroundPaint(Color.white);
        chart.getTitle().setMargin(7,0,7,0);
        chart.setAntiAlias(false);
        chart.getLegend().setBorder(org.jfree.chart.block.BlockBorder.NONE);
        return chart;                  
    }

    /**
     * Returns a default chart with a plot that extends evs.products.plots.EVSPlot.
     *
     * @param type the chart type: one of the static final variables in evs.metric.metrics.DecomposableScore
     * @return a default chart
     */

    public static JFreeChart getDefaultChart(int type) {
        String name = "";
        String rangeAx = "";
        boolean fixedRange = false;
        switch(type) {
            case DecomposableScore.OVERALL_SCORE: {
                name = "Brier Skill Score by forecast lead time.";
                rangeAx = "Brier Skill Score";
                fixedRange = true;
            }; break;
            case DecomposableScore.RELIABILITY: {
                name = "Brier Skill Score reliability component by forecast lead time.";
                rangeAx = "Relative reliability";
            }; break;
            case DecomposableScore.RESOLUTION: {
                name = "Brier Skill Score resolution component by forecast lead time.";
                rangeAx = "Relative resolution";
            }; break;
            case DecomposableScore.UNCERTAINTY: {
                name = "Brier Skill Score uncertainty component by forecast lead time.";
                rangeAx = "Relative uncertainty";
            }; break;
            case DecomposableScore.TYPE_II_BIAS: {
                name = "Brier Skill Score Type-II bias component by forecast lead time.";
                rangeAx = "Relative Type-II bias";
            }; break;
            case DecomposableScore.DISCRIMINATION: {
                name = "Brier Skill Score discrimination component by forecast lead time.";
                rangeAx = "Relative discrimination";
            }; break;
            case DecomposableScore.SHARPNESS: {
                name = "Brier Skill Score sharpness component by forecast lead time.";
                rangeAx = "Relative sharpness";
            }; break;
            case DecomposableScore.SCORE_GIVEN_OBS_TRUE: {
                name = "Brier Skill Score conditional on observed event by forecast lead time.";
                rangeAx = "Brier Skill Score conditional on observed event";
            }; break;
            case DecomposableScore.SCORE_GIVEN_OBS_FALSE: {
                name = "Brier Skill Score conditional on observed non-event by forecast lead time.";
                rangeAx = "Brier Skill Score conditional on observed non-event";
            }; break;
            case DecomposableScore.TYPE_II_BIAS_GIVEN_OBS_TRUE: {
                name = "Brier Skill Score Type-II bias conditional on observed event by forecast lead time.";
                rangeAx = "Relative Type-II bias conditional on observed event";
            }; break;
            case DecomposableScore.TYPE_II_BIAS_GIVEN_OBS_FALSE: {
                name = "Brier Skill Score Type-II bias conditional on observed non-event by forecast lead time.";
                rangeAx = "Relative Type-II bias conditional on observed non-event";
            }; break;
            case DecomposableScore.DISCRIMINATION_GIVEN_OBS_TRUE: {
                name = "Brier Skill Score discrimination conditional on observed event by forecast lead time.";
                rangeAx = "Relative discrimination conditional on observed event";
            }; break;
            case DecomposableScore.DISCRIMINATION_GIVEN_OBS_FALSE: {
                name = "Brier Skill Score discrimination conditional on observed non-event by forecast lead time.";
                rangeAx = "Relative discrimination conditional on observed non-event";
            }; break;
            default : {
                throw new IllegalArgumentException("Unrecognized score type identifier for Brier Skill Score plot: "+type+".");
            }
        }
        BrierSkillScorePlot plot = new BrierSkillScorePlot();
        final JFreeChart chart = new JFreeChart(name,new Font("Verdana", Font.BOLD, 12),plot,true);
        chart.setBackgroundPaint(Color.white);
        chart.getTitle().setMargin(7,0,7,0);
        chart.setAntiAlias(false);
        plot.getRangeAxis().setLabel(rangeAx);
        if(fixedRange) {
            plot.getRangeAxis().setRange(-1.0,1.0);
        }
        chart.getLegend().setBorder(org.jfree.chart.block.BlockBorder.NONE);
        return chart;
    }
    
    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/          
    
    /**
     * Adds a dataset to the plot or throws an exception if the data are of an 
     * incorrect type.
     *
     * @param data the data
     */
    
    public void addDataset(String key, MetricResult data) throws IllegalArgumentException {
        addThresholdDataset(key,data);
    }
    
}
