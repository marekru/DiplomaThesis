package evs.products.plots.defaults;

//JFreeChart dependencies
import org.jfree.chart.*;
import org.jfree.chart.renderer.xy.*;
import org.jfree.data.xy.*;

//EVS dependencies
import evs.metric.results.*;
import evs.metric.parameters.*;
import evs.analysisunits.*;
import evs.utilities.matrix.*;

//Java util dependencies
import java.util.*;

//Java awt dependencies
import java.awt.*;

/**
 * Constructs a default quantile-quantile plot.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class QQPlot extends DefaultXYPlot implements RealValuedPlot {
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/    
    
    /**
     * Constructs an CED plot with no input arguments.
     */
    
    public QQPlot() {
        super();
        //Set some default axes
        getDomainAxis().setLabel("Forecast quantile");
        getRangeAxis().setLabel("Observed quantile");
    }

    /*******************************************************************************
     *                                                                             *
     *                              ACCESSOR METHODS                               *
     *                                                                             *
     ******************************************************************************/     
    
    /**
     * Returns a default chart with a plot that extends evs.products.plots.EVSPlot.
     *
     * @return a default chart
     */
    
    public static JFreeChart getDefaultChart() {
        String name = "Quantile-Quantile plot for the ensemble average.";
        QQPlot plot = new QQPlot();
        final JFreeChart chart = new JFreeChart(name,new Font("Verdana", Font.BOLD, 12),plot,true);
        chart.setBackgroundPaint(Color.white);
        chart.getTitle().setMargin(7,0,7,0);
        chart.setAntiAlias(false); 
        chart.getLegend().setBorder(org.jfree.chart.block.BlockBorder.NONE);
        return chart;                               
    }        
    
    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/             
    
    /**
     * Adds a dataset to the plot or throws an exception if the data are of an 
     * incorrect type.
     *
     * @param data the data
     */
    
    public final void addDataset(String key, MetricResult data) throws IllegalArgumentException {
        //Iterate through the thresholds, calling addDataset in the superclass each time
        if(!(data instanceof MetricResultByThreshold) || ((MetricResultByThreshold)data).getIDForStoredResults()!=data.DOUBLE_MATRIX_2D_RESULT) {
            throw new IllegalArgumentException("Unexpected input data for the QQ plot: "+data.getClass());
        }
        TreeMap<DoubleProcedureParameter,MetricResult> res = ((MetricResultByThreshold)data).getResults();
        Iterator k = res.keySet().iterator();
        double min = -999;
        double max = -999;
        while(k.hasNext()) {
            DoubleProcedureParameter key2 = (DoubleProcedureParameter)k.next();
            if (key2.isMainThreshold().getParVal()) {
                DoubleMatrix2DResult result = (DoubleMatrix2DResult) res.get(key2);
                double[] rankedObs = result.getResult().toArray()[0];
                double[] rankedEns = result.getResult().toArray()[1];
                double tMax = Math.max(rankedObs[rankedObs.length-1],rankedEns[rankedEns.length-1]);
                double tMin = Math.min(rankedObs[0],rankedEns[0]);
                if(max!=-999) {
                    max = Math.max(max,tMax);
                    min = Math.min(min,tMin);
                } else {
                    max = tMax;
                    min = tMin;
                }
                super.addDataset(key2 + "", result);
            }
        } 

        //Retain zero-boundary
        if(min!=0) {
            min = min - (0.1 * Math.abs(min));
        }
        max = max + (0.1 * Math.abs(max));

        //Add base line
        double[][] perfect = new double[][] {
            {min,max},
            {min,max},
        };

        DefaultXYDataset d = new DefaultXYDataset();
        d.addSeries("Perfect",perfect);
        setDataset(d);
        //Set the renderer for the default line
        final XYLineAndShapeRenderer pRend = new XYLineAndShapeRenderer(true,true);
        pRend.setSeriesStroke(0,new BasicStroke(2));
        pRend.setShapesVisible(false);
        pRend.setSeriesPaint(0,Color.black);
        setRenderer(0,pRend);
        getDomainAxis().setRange(min,max);
        getRangeAxis().setRange(min,max);
    }

    /**
     * Appends the real units to the appropriate axes of the plot.
     *
     * @param units the units to append
     */

    public final void setRealUnits(String units) {
        String c = getRangeAxis().getLabel();
        String d = getDomainAxis().getLabel();
        c = c + " in '" + units + "'";
        d = d + " in '" + units + "'";
        getRangeAxis().setLabel(c);
        getDomainAxis().setLabel(d);
    }
    
    
}
