package evs.products.plots.defaults.boxplotutilities;

//Java awt dependencies
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

//JFreeChart dependencies
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.RectangleEdge;
import org.jfree.util.PaintUtilities;
import org.jfree.util.PublicCloneable;
import org.jfree.chart.renderer.xy.AbstractXYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.renderer.xy.XYItemRenderer;

/**
 * A renderer that draws box plot items on an {@link org.jfree.chart.plot.XYPlot}.
 * 
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class BoxPlotRenderer extends AbstractXYItemRenderer implements XYItemRenderer {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLES                              *
     *                                                                              *
     *******************************************************************************/       
    
    /** 
     * The box width. 
     */
    
    private double boxWidth;
    
    /** 
     * The paint used to draw various artifacts. 
     */
    
    private Paint artifactPaint = Color.black;
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/ 
    
    /**
     * Creates a new renderer.
     */
    
    public BoxPlotRenderer() {
        this(-1.0);
    }

    /**
     * Creates a new renderer.
     * <P>
     * Use -1 for the box width if you prefer the width to be calculated 
     * automatically.
     *
     * @param boxWidth  the box width.
     */
    
    public BoxPlotRenderer(double boxWidth) {
        super();
        this.boxWidth = boxWidth;
    }

    /*******************************************************************************
     *                                                                             *
     *                              ACCESSOR METHODS                               *
     *                                                                             *
     ******************************************************************************/       
    
    /**
     * Returns the width of each box.
     *
     * @return The box width.
     */
    public double getBoxWidth() {
        return boxWidth;
    }

    /**
     * Returns the paint used to paint the various artifacts.
     *
     * @return the paint.
     */
    
    public Paint getArtifactPaint() {
        return artifactPaint;
    }
    
    /**
     * Tests this renderer for equality with another object.
     *
     * @param obj  the object (<code>null</code> permitted).
     * @return <code>true</code> or <code>false</code>.
     */
    
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof BoxPlotRenderer)) {
            return false;
        }
        if (!super.equals(obj)) {
            return false;
        }
        BoxPlotRenderer that = (BoxPlotRenderer) obj;
        if (this.boxWidth != that.getBoxWidth()) {
            return false;
        }
        if (!PaintUtilities.equal(this.artifactPaint, that.artifactPaint)) {
            return false;
        }
        return true;
    }
    
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        assert false : "hashCode not implemented for BoxPlotRenderer.";
        return 1;
    }   
    
    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/     
    
    /**
     * Sets the box width.
     * <P>
     * If you set the width to a negative value, the renderer will calculate
     * the box width automatically based on the space available on the chart.
     *
     * @param boxWidth the box width.
     */
    
    public void setBoxWidth(double boxWidth) {
        if (boxWidth != this.boxWidth) {
            this.boxWidth = boxWidth;
            notifyListeners(new RendererChangeEvent(this));
        }
    }    
    
    /**
     * Sets the paint used to paint the various artifacts.
     * 
     * @param artifactPaint the paint.
     */
    public void setArtifactPaint(Paint artifactPaint) {
        this.artifactPaint = artifactPaint;
    }

    /**
     * Draws the visual representation of a single data item.
     *
     * @param g2  the graphics device.
     * @param state  the renderer state.
     * @param dataArea  the area within which the plot is being drawn.
     * @param info  collects info about the drawing.
     * @param plot  the plot (can be used to obtain standard color 
     *              information etc).
     * @param domainAxis  the domain axis.
     * @param rangeAxis  the range axis.
     * @param dataset  the dataset.
     * @param series  the series index (zero-based).
     * @param item  the item index (zero-based).
     * @param crosshairState  crosshair information for the plot 
     *                        (<code>null</code> permitted).
     * @param pass  the pass index.
     */
    public void drawItem(Graphics2D g2, 
                         XYItemRendererState state,
                         Rectangle2D dataArea,
                         PlotRenderingInfo info,
                         XYPlot plot, 
                         ValueAxis domainAxis, 
                         ValueAxis rangeAxis,
                         XYDataset dataset, 
                         int series, 
                         int item,
                         CrosshairState crosshairState,
                         int pass) {

        PlotOrientation orientation = plot.getOrientation();

        if (orientation == PlotOrientation.HORIZONTAL) {
            drawHorizontalItem(
                g2, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, pass
            );
        }
        else if (orientation == PlotOrientation.VERTICAL) {
            drawVerticalItem(
                g2, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, pass
            );
        }

    }

    /**
     * Draws the visual representation of a single data item.
     *
     * @param g2  the graphics device.
     * @param dataArea  the area within which the plot is being drawn.
     * @param info  collects info about the drawing.
     * @param plot  the plot (can be used to obtain standard color 
     *              information etc).
     * @param domainAxis  the domain axis.
     * @param rangeAxis  the range axis.
     * @param dataset  the dataset.
     * @param series  the series index (zero-based).
     * @param item  the item index (zero-based).
     * @param crosshairState  crosshair information for the plot 
     *                        (<code>null</code> permitted).
     * @param pass  the pass index.
     */
    public void drawHorizontalItem(Graphics2D g2, 
                                   Rectangle2D dataArea,
                                   PlotRenderingInfo info,
                                   XYPlot plot, 
                                   ValueAxis domainAxis, 
                                   ValueAxis rangeAxis,
                                   XYDataset dataset, 
                                   int series, 
                                   int item,
                                   CrosshairState crosshairState,
                                   int pass) {

                                   //NOT IMPLEMENTED
        
    }
    
    /**
     * Draws the visual representation of a single data item.
     *
     * @param g2  the graphics device.
     * @param dataArea  the area within which the plot is being drawn.
     * @param info  collects info about the drawing.
     * @param plot  the plot (can be used to obtain standard color 
     *              information etc).
     * @param domainAxis  the domain axis.
     * @param rangeAxis  the range axis.
     * @param dataset  the dataset.
     * @param series  the series index (zero-based).
     * @param item  the item index (zero-based).
     * @param crosshairState  crosshair information for the plot 
     *                        (<code>null</code> permitted).
     * @param pass  the pass index.
     */
    public void drawVerticalItem(Graphics2D g2, 
                                 Rectangle2D dataArea,
                                 PlotRenderingInfo info,
                                 XYPlot plot, 
                                 ValueAxis domainAxis, 
                                 ValueAxis rangeAxis,
                                 XYDataset dataset, 
                                 int series, 
                                 int item,
                                 CrosshairState crosshairState,
                                 int pass) {

        // setup for collecting optional entity info...
//        EntityCollection entities = null;
//        if (info != null) {
//            entities = info.getOwner().getEntityCollection();
//        }

        ConcreteBoxPlotDataset boxData 
            = (ConcreteBoxPlotDataset) dataset;

        Number x = boxData.getX(series, item);

        double xx = domainAxis.valueToJava2D(x.doubleValue(), dataArea, 
                plot.getDomainAxisEdge());

        double exactboxWidth = getBoxWidth();
        double width = exactboxWidth;
        double dataAreaX = dataArea.getMaxX() - dataArea.getMinX();
        double maxboxPercent = 0.1;
        double maxboxWidth = dataAreaX * maxboxPercent;
        
        if (exactboxWidth <= 0.0) {
            int itemCount = boxData.getItemCount(series);
            exactboxWidth = dataAreaX / itemCount * 4.5 / 7;
            if (exactboxWidth < 3) {
                width = 3;
            } 
            else if (exactboxWidth > maxboxWidth) {
                width = maxboxWidth;
            } 
            else {
                width = exactboxWidth;
            }
        }

        Paint p = getArtifactPaint();
        if (p != null) {
            g2.setPaint(p);
        }
        Stroke s = getItemStroke(series, item);

        g2.setStroke(s);

//        // add an entity for the item...
//        String url = null;
//        String tip = null;
//        if (entities != null) {
//            XYToolTipGenerator generator = getToolTipGenerator(series, item);
//            if (generator != null) {
//                tip = generator.generateToolTip(dataset, series, item);
//            }
//            if (getURLGenerator() != null) {
//                url = getURLGenerator().generateURL(dataset, series, item);
//            }
//        }
        
        //Draw the box 
        double[] data = boxData.getItem(series,item).getPoints();
        int bBound = (int)Math.round(0.2 * (data.length-1));  //20%
        int tBound = (int)Math.round(0.8 * (data.length-1));  //80%
        if(data.length > 3) {
            double yLower = (Double)data[bBound];
            double yUpper = (Double)data[tBound];
            double yyLower = rangeAxis.valueToJava2D(yLower,dataArea,plot.getRangeAxisEdge());
            double yyUpper = rangeAxis.valueToJava2D(yUpper,dataArea,plot.getRangeAxisEdge());
            Shape box = new Rectangle2D.Double(xx - width / 2, yyUpper, width, Math.abs(yyUpper-yyLower));
            g2.setPaint(Color.green);
            g2.draw(box);
            g2.fill(box);
        }
        //Draw the lines
        int tot = data.length-1;
        for(int i = 0; i < tot; i++) {
            double yLower = (Double)data[i];
            double yUpper = (Double)data[i+1];
            double yyLower = rangeAxis.valueToJava2D(yLower,dataArea,plot.getRangeAxisEdge());
            double yyUpper = rangeAxis.valueToJava2D(yUpper,dataArea,plot.getRangeAxisEdge());
            Shape line1 = new Line2D.Double(xx - width / 2, yyUpper, xx + width / 2, yyUpper);
            Shape line2 = new Line2D.Double(xx - width / 2, yyLower, xx + width / 2, yyLower);
            g2.setPaint(p);
            g2.draw(line1);
            g2.draw(line2);
            if(i < bBound || i >=tBound) {
                Shape line3 = new Line2D.Double(xx, yyLower, xx, yyUpper);
                g2.draw(line3);
            }
            yLower = yUpper;    
        }
           
        //Draw the box centre line
        BoxPlotItem b = ((ConcreteBoxPlotDataset)boxData).getItem(series,item);
        double cent = b.getCenter();
        double cent2 = rangeAxis.valueToJava2D(cent,dataArea,plot.getRangeAxisEdge());
        Shape line = new Line2D.Double(xx - width / 2, cent2, xx + width / 2, cent2);
        g2.setPaint(Color.black);
        g2.draw(line);
        g2.setPaint(p);     
        
    }

}
