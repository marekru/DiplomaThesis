package evs.products.plots.defaults;

/**
 * Identifies a plot that comprises a score decomposition. Each score decomposition
 * plot should implement the following static method:
 * 
 * public static JFreeChart getDefaultChart(int type)
 * 
 * Returning a chart for each available decomposition specified by type.
 * 
 * @author evs@hydrosolved.com
 */

public interface ScoreDecompositionPlot {}
