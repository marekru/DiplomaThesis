package evs.products.plots.defaults;

//JFreeChart dependencies
import org.jfree.chart.renderer.xy.XYBarRenderer;      
import org.jfree.chart.*;
import org.jfree.chart.plot.*;
import org.jfree.chart.axis.*;
import org.jfree.chart.renderer.xy.*;
import org.jfree.data.xy.*;

//EVS dependencies
import evs.metric.parameters.DoubleProcedureParameter;
import evs.metric.results.*;
import evs.metric.metrics.Metric;
import evs.utilities.mathutil.FunctionLibrary;
import evs.utilities.matrix.*;

//Java util dependencies
import java.util.TreeMap;
import java.util.Iterator;

//Java awt dependencies
import java.awt.Font;
import java.awt.BasicStroke;
import java.awt.Color;

//Other Java dependencies
import java.text.DecimalFormat;

/**
 * Constructs a default rank histogram.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class RankHistogramPlot extends DefaultXYPlot {
    
    /*******************************************************************************
     *                                                                             *
     *                               VARIABLES                                     *
     *                                                                             *
     ******************************************************************************/     
    
    /**
     * Identifier for relative frequency.
     */
    
    public static final int RELATIVE = 101;
    
    /**
     * Identifier for absolute frequency.
     */
    
    public static final int ABSOLUTE = 102;    

    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/    
    
    /**
     * Constructs a rank histogram with no input arguments.  The data must be set
     * later.
     * 
     * @param isRelative is true to use relative frequencies, false for absolute sample counts.
     */
    
    public RankHistogramPlot(boolean isRelative) {
        //Set some default axes
        final NumberAxis domainAxis = new NumberAxis("Bin separating ranked ensemble members");
        String relative = "Relative frequency";
        if(!isRelative) {
            relative = "Frequency";
        }
        final NumberAxis rangeAxis = new NumberAxis(relative);
        domainAxis.setTickLabelFont(new Font("Verdana", Font.PLAIN, 8));
        rangeAxis.setTickLabelFont(new Font("Verdana", Font.PLAIN, 8));
        domainAxis.setAutoRangeIncludesZero(false);
        domainAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());  //Integer ticks
        setDomainAxis(domainAxis);
        setRangeAxis(rangeAxis);        
        //Hide the grid lines
        setDomainGridlinesVisible(false);
        setRangeGridlinesVisible(false);   
    }

    /*******************************************************************************
     *                                                                             *
     *                              ACCESSOR METHODS                               *
     *                                                                             *
     ******************************************************************************/         

    /**
     * Returns a default chart with a plot that extends evs.products.plots.EVSPlot.
     *
     * @param isRelative is true for relative frequencies, false for absolute
     * @return a default chart
     */
    
    public static JFreeChart getDefaultChart(boolean isRelative) {
        String name = "Rank histogram.";
        RankHistogramPlot plot = new RankHistogramPlot(isRelative);
        final JFreeChart chart = new JFreeChart(name,new Font("Verdana", Font.BOLD, 12),plot,true);
        chart.setBackgroundPaint(Color.white);
        chart.getTitle().setMargin(7,0,7,0);
        chart.setAntiAlias(false);
        chart.getLegend().setBorder(org.jfree.chart.block.BlockBorder.NONE);
        return chart;        
    }            

    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/             
    
    /**
     * Adds a dataset to the plot or throws an exception if the data are of an 
     * incorrect type.
     *
     * @param data the data
     */
    
    public void addDataset(String key, MetricResult data) throws IllegalArgumentException {
        //Iterate through the thresholds, calling addDataset in the superclass each time
        if(!(data instanceof MetricResultByThreshold) || ((MetricResultByThreshold)data).getIDForStoredResults()!=data.DOUBLE_MATRIX_2D_RESULT) {
            throw new IllegalArgumentException("Unexpected input data for the rank histogram: "+data.getClass());
        }
        TreeMap<DoubleProcedureParameter,MetricResult> res = ((MetricResultByThreshold)data).getResults();
        if (countMainThresholds(res) == 1) {
            addBarDataset(res.firstKey()+"",res.get(res.firstKey()));
            
        } else {
            Iterator k = res.keySet().iterator();
            while (k.hasNext()) {
                DoubleProcedureParameter key2 = (DoubleProcedureParameter) k.next();
                if (key2.isMainThreshold().getParVal()) {
                    super.addDataset(key2 + "", res.get(key2));
                }
            }
        }
        
    }        
    
    /**
     * Adds an interval dataset for plotting a bar chart. If the dataset does
     * not have a sampling interval, a bar chart and associated renderer is set.
     * If the dataset has a sampling interval, an error renderer is used.
     *
     * @param key the data key
     * @param data the data
     */
    
    private void addBarDataset(String key, MetricResult data) throws IllegalArgumentException {
        if(!(data instanceof DoubleMatrix2DResult)) {
            throw new IllegalArgumentException("Unexpected input data for the xy plot.");
        }
        DefaultIntervalXYDataset d = new DefaultIntervalXYDataset();
        
        DoubleMatrix2DResult dr = (DoubleMatrix2DResult)data;
        double[][] source = dr.getResult().toArray();
        double[][] nextRes = new double[6][source[0].length];
        boolean samplingInterval = dr.hasMainInterval();
        
        if (samplingInterval) {
            
            //No x-width for histogram bars, as sampling interval present
            nextRes[0] = source[0];          
            nextRes[1] = source[0];
            nextRes[2] = source[0];  
            nextRes[3] = source[1];
            
            //Add lower and upper bounds for Y
            //If any bound values correspond to the null value identifier replace them
            //with the nominal value of the statistic
            MetricResult[] bounds = dr.getMainIntervalResults();
            double[][] lowerY = ((DoubleMatrix2DResult) bounds[0]).getResult().toArray();
            double[][] upperY = ((DoubleMatrix2DResult) bounds[1]).getResult().toArray();
            for (int i = 0; i < lowerY[1].length; i++) {
                if (lowerY[1][i] == Metric.NULL_DATA) {
                    lowerY[1][i] = nextRes[3][i];
                }
                if (upperY[1][i] == Metric.NULL_DATA) {
                    upperY[1][i] = nextRes[3][i];
                }
            }
            //Y-width for error bars
            nextRes[4] = lowerY[1];
            nextRes[5] = upperY[1];
            
            //Add series to interval dataset    
            ((DefaultIntervalXYDataset) d).addSeries(key, nextRes);
            
            int count = getDatasetCount();
            setDataset(count, d);       
            
            XYErrorRenderer rend = new XYErrorRenderer();
            ((XYErrorRenderer) rend).setDrawYError(true);
            ((XYErrorRenderer) rend).setDrawXError(false);
            ((XYErrorRenderer) rend).setCapLength(ERROR_BAR_CAP_LENGTH);  //Cap length of error bars
            rend.setLinesVisible(true);
            rend.setShapesVisible(!samplingInterval);
            rend.setShapesFilled(false);
            setRenderer(count, rend);

            Color c = (Color) getRenderer(count).getSeriesPaint(0);
            //Avoid yellow, for which red and green are always 255, but blue varies
            //because the colors are determined automatically to maximize visual differences
            //between datasets
            if (c != null && c.getRed() == 255 && c.getGreen() == 255) {
                getRenderer(count).setSeriesPaint(0, Color.orange);
                ((XYErrorRenderer) rend).setErrorPaint(Color.orange);
            }              
        } else {
            //Add x-widths for histogram bars
            nextRes[0] = source[0];
            DoubleMatrix1D m = new DenseDoubleMatrix1D(source[0]);
            DoubleMatrix1D n = new DenseDoubleMatrix1D(source[0]);
            m = (DoubleMatrix1D) m.assign(FunctionLibrary.minus(0.35), false);
            n = (DoubleMatrix1D) n.assign(FunctionLibrary.plus(0.35), false);
            nextRes[1] = m.toArray();
            nextRes[2] = n.toArray();
            
            //No y-width
            nextRes[3] = source[1];          
            nextRes[4] = source[1];
            nextRes[5] = source[1];

            //Add series to interval dataset    
            ((DefaultIntervalXYDataset) d).addSeries(key, nextRes);
            int count = getDatasetCount();
            setDataset(count, d);
            XYBarRenderer rend = new XYBarRenderer();
            rend.setDrawBarOutline(false);
            setRenderer(count, rend);            
        }
    }    
    
    /**
     * Returns the number of main thresholds in the input.
     * 
     * @return the number of main thresholds
     */
    
    private int countMainThresholds(TreeMap<DoubleProcedureParameter,MetricResult> res) {
        Iterator<DoubleProcedureParameter> it = res.keySet().iterator();
        int count = 0;
        while(it.hasNext()) {
            if(it.next().isMainThreshold().getParVal()) {
                count++;
            }
        }
        return count;
    }
    
}
