package evs.products.plots.defaults;

//JFreeChart dependencies
import org.jfree.chart.renderer.xy.*;
import org.jfree.data.xy.*;
import org.jfree.chart.plot.*;
import org.jfree.chart.*;
import org.jfree.ui.*;

//Java awt dependencies
import java.awt.*;
    
//EVS dependencies
import evs.metric.results.*;
import evs.metric.parameters.*;
import evs.utilities.matrix.*;

//Java util dependencies
import java.util.*;

/**
 * Constructs a default reliability diagram.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ReliabilityDiagram extends DefaultXYAndSamplePlot {
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/    
    
    /**
     * Constructs a reliability plot with no input arguments.
     */
    
    public ReliabilityDiagram() {
        super();
        XYPlot rel = (XYPlot)getSubplots().get(0);
        
        //Set some default axes
        rel.getDomainAxis().setLabel("Forecast probability");
        rel.getDomainAxis().setRange(0.0,1.0);
        rel.getRangeAxis().setRange(0.0,1.0);
        rel.getRangeAxis().setLabel("Observed probability given forecast probability");
        //Add a default line for the perfect score
        double[][] perfect = new double[][] {
            {0.0,1.0},
            {0.0,1.0}
        };
        DefaultXYDataset d = new DefaultXYDataset();
        d.addSeries("Perfect",perfect);
        rel.setDataset(d);
        //Set the renderer for the default line
        final XYLineAndShapeRenderer pRend = new XYLineAndShapeRenderer(true,true);
        pRend.setSeriesStroke(0,new BasicStroke(2));
        pRend.setShapesVisible(false);
        pRend.setSeriesPaint(0,Color.black);
        rel.setRenderer(0,pRend);    
    }

    /*******************************************************************************
     *                                                                             *
     *                              ACCESSOR METHODS                               *
     *                                                                             *
     ******************************************************************************/     
    
    /**
     * Returns a default chart with a plot that extends evs.products.plots.EVSPlot.
     *
     * @return a default chart
     */
    
    public static JFreeChart getDefaultChart() {
        String name = "Reliability diagram for various event thresholds (upper) and sample counts (lower).";
        ReliabilityDiagram plot = new ReliabilityDiagram();
        final JFreeChart chart = new JFreeChart(name,new Font("Verdana", Font.BOLD, 12),plot,true);
        chart.setBackgroundPaint(Color.white);
        chart.getTitle().setMargin(7,0,7,0);
        chart.setAntiAlias(false);
        chart.getLegend().setPosition(RectangleEdge.RIGHT);
        chart.getLegend().setVerticalAlignment(VerticalAlignment.TOP);
        chart.getLegend().setBorder(org.jfree.chart.block.BlockBorder.NONE);
        return chart;                               
    }        
    
    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/          
    
    /**
     * Adds a dataset to the plot or throws an exception if the data are of an 
     * incorrect type.
     *
     * @param data the data
     */
    
    public void addDataset(String key, MetricResult data) throws IllegalArgumentException {
        if(!(data instanceof MetricResultByThreshold) || ((MetricResultByThreshold)data).getIDForStoredResults()!=data.DOUBLE_MATRIX_2D_RESULT) {
            throw new IllegalArgumentException("Unexpected input data for the reliability diagram: "+data.getClass());
        }
        TreeMap<DoubleProcedureParameter,MetricResult> res = ((MetricResultByThreshold)data).getResults();
        Iterator k = res.keySet().iterator();
        while (k.hasNext()) {
            DoubleProcedureParameter key2 = (DoubleProcedureParameter) k.next();
            if (key2.isMainThreshold().getParVal()) {
                DoubleMatrix2DResult result = (DoubleMatrix2DResult) res.get(key2);
                //Strip columns with zero sample data
                result = result.stripNullSamples(0,2);
                super.addDataset(key2 + "", result);
            }
        }
    }    

}
