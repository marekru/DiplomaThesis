package evs.products.plots.defaults;

//JFreeChart dependencies
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;

//EVS dependencies
import evs.metric.results.MetricResult;

//Java awt dependencies
import java.awt.Color;
import java.awt.Font;

/**
 * Constructs a default relative mean error plot based on multiple lead times.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class RMEPlot extends DefaultXYPlotByLeadTime implements EVSPlot, RealValuedPlot  {
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/    
    
    /**
     * Constructs a relative mean error plot with no input arguments.  The data must be set later.
     */
    
    public RMEPlot() {
        super();
        getRangeAxis().setLabel("Relative Mean Error (forecast - observed)");
        ((NumberAxis)getRangeAxis()).setAutoRangeIncludesZero(true);
    }

    /*******************************************************************************
     *                                                                             *
     *                              ACCESSOR METHODS                               *
     *                                                                             *
     ******************************************************************************/     
    
    /**
     * Returns a default chart with a plot that extends evs.products.plots.EVSPlot.
     *
     * @return a default chart
     */
    
    public static JFreeChart getDefaultChart() {
        String name = "Relative Mean Error of the ensemble average by forecast lead time.";
        RMEPlot plot = new RMEPlot();            
        final JFreeChart chart = new JFreeChart(name,new Font("Verdana", Font.BOLD, 12),plot,true);
        chart.setBackgroundPaint(Color.white);
        chart.getTitle().setMargin(7,0,7,0);
        chart.setAntiAlias(false);
        chart.getLegend().setBorder(org.jfree.chart.block.BlockBorder.NONE);
        return chart;                  
    }
     
    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/          
    
    /**
     * Adds a dataset to the plot or throws an exception if the data are of an 
     * incorrect type.
     *
     * @param data the data
     */
    
    public void addDataset(String key, MetricResult data) throws IllegalArgumentException {
        addThresholdDataset(key,data);    
    }        
    
    /**
     * Appends the real units to the appropriate axes of the plot.
     * 
     * @param units the units to append
     */
    
    public void setRealUnits(String units) {
        String c = getRangeAxis().getLabel();
        c = c + " in '" + units + "'";
        getRangeAxis().setLabel(c);        
    }      
    
}
