package evs.products.plots.defaults;

//JFreeChart dependencies
import org.jfree.chart.renderer.xy.*;
import org.jfree.data.xy.*;
import org.jfree.chart.*;
        
//Java awt dependencies
import java.awt.*;
    
//EVS dependencies
import evs.metric.results.*;
import evs.metric.parameters.*;
import evs.utilities.matrix.*;
import evs.analysisunits.*;

//Java util dependencies
import evs.metric.metrics.Metric;
import java.util.*;

/**
 * Constructs a default Relative Operating Characteristic (ROC) plot.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ROCPlot extends DefaultXYPlot {
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/    
    
    /**
     * Constructs an ROC plot with no input arguments.
     */
    
    public ROCPlot() {
        super();
        //Set some default axes
        getDomainAxis().setLabel("Probability of False Detection (false alarms)");
        getDomainAxis().setRange(0.0,1.0);
        getRangeAxis().setRange(0.0,1.0);
        getRangeAxis().setLabel("Probability of Detection (true alarms)");
        //Add a default line for the no-skill score
        double[][] noSkill = new double[][] {
            {0.0,1.0},
            {0.0,1.0}
        };
        DefaultXYDataset d = new DefaultXYDataset();
        d.addSeries("Random guess (no skill)",noSkill);
        setDataset(d);
        //Set the renderer for the default line
        final XYLineAndShapeRenderer pRend = new XYLineAndShapeRenderer(true,true);
        pRend.setShapesVisible(false);
        pRend.setSeriesStroke(0,new BasicStroke(2));
        pRend.setSeriesPaint(0,Color.black);
        setRenderer(0,pRend);
    }

    /*******************************************************************************
     *                                                                             *
     *                              ACCESSOR METHODS                               *
     *                                                                             *
     ******************************************************************************/     
    
    /**
     * Returns a default chart with a plot that extends evs.products.plots.EVSPlot.
     *
     * @return a default chart
     */
    
    public static JFreeChart getDefaultChart() {
        String name = "Relative Operating Characteristic for different event (probability) thresholds.";
        ROCPlot plot = new ROCPlot();            
        final JFreeChart chart = new JFreeChart(name,new Font("Verdana", Font.BOLD, 12),plot,true);
        chart.setBackgroundPaint(Color.white);
        chart.getTitle().setMargin(7,0,7,0);
        chart.setAntiAlias(false);
        chart.getLegend().setBorder(org.jfree.chart.block.BlockBorder.NONE);
        return chart;                               
    }        
    
    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/          
    
    /**
     * Adds a dataset to the plot or throws an exception if the data are of an 
     * incorrect type.
     *
     * @param data the data
     */
    
    public void addThresholdDataset(String key, MetricResult data) throws IllegalArgumentException {
        if(!(data instanceof MetricResultByThreshold) || ((MetricResultByThreshold)data).getIDForStoredResults()!=data.DOUBLE_MATRIX_2D_RESULT) {
            throw new IllegalArgumentException("Unexpected input data for the ROC plot: "+data.getClass());
        }
        TreeMap<DoubleProcedureParameter,MetricResult> res = ((MetricResultByThreshold)data).getResults();
        Iterator k = res.keySet().iterator();
        while(k.hasNext()) {
            DoubleProcedureParameter key2 = (DoubleProcedureParameter)k.next();
            if(key2.isMainThreshold().getParVal()) {
                DoubleMatrix2DResult result = (DoubleMatrix2DResult)res.get(key2);
                DoubleMatrix2D r = result.getResult();
                if(r.getRowCount()==2) {
                    super.addThresholdDataset(key2+"",result);
                }
                else if(r.getRowCount()==4) {
                    DoubleMatrix2D empirical = (DoubleMatrix2D)r.getSubmatrixByRow(0,1);
                    DoubleMatrix2D fitted = (DoubleMatrix2D)r.getSubmatrixByRow(2,3);
                    DoubleMatrix2D fittedLower = null;
                    DoubleMatrix2D fittedUpper = null;
                    if(result.hasMainInterval()) {
                        MetricResult[] bounds = result.getMainIntervalResults();
                        DoubleMatrix2DResult low = (DoubleMatrix2DResult)bounds[0];
                        DoubleMatrix2DResult high = (DoubleMatrix2DResult)bounds[1];
                        fittedLower = (DoubleMatrix2D)low.getResult().getSubmatrixByRow(2,3);
                        fittedUpper = (DoubleMatrix2D)high.getResult().getSubmatrixByRow(2,3);
                    }
                    addFittedDataset(key2.toString(),empirical,fitted,fittedLower,fittedUpper);
                }
                else {
                    throw new IllegalArgumentException("Unexpected input for the ROC plot: expected one curve (empirical) or two curves (empirical and fitted).");
                }
            }
        } 
    }

    /**
     * Adds an empirical and fitted dataset to the plot or throws an exception
     * if the data are of an incorrect type.
     *
     * @param key the key
     * @param empirical the empirical ROC points
     * @param fitted the fitted ROC points
     * @param fittedLower the lower bound of a sampling interval on the fitted ROC points (may be null)
     * @param fittedUpper the upper bound of a sampling interval on the fitted ROC points (may be null)
     */

    private void addFittedDataset(String key, DoubleMatrix2D empirical, DoubleMatrix2D fitted,
            DoubleMatrix2D fittedLower, DoubleMatrix2D fittedUpper) throws IllegalArgumentException {
        DefaultXYDataset d = new DefaultXYDataset();
        XYDataset e = null;
        double[][] emp = empirical.toArray();
        double[][] fit = fitted.toArray();
        boolean interval = fittedLower!=null && fittedUpper!=null;
        //Interval data
        if (interval) {
            e = new DefaultIntervalXYDataset();
            double[][] data = new double[6][fit[0].length];
            double[][] lower = fittedLower.toArray();
            double[][] upper = fittedUpper.toArray();
            for(int i = 0; i < lower[1].length; i++) {
                if(lower[1][i]==Metric.NULL_DATA) {
                    lower[1][i]=fit[1][i];
                }
                if(upper[1][i]==Metric.NULL_DATA) {
                    upper[1][i]=fit[1][i];
                }
            }
            data[0]=fit[0];
            data[1]=fit[0];
            data[2]=fit[0];
            data[3]=fit[1];
            data[4]=lower[1];
            data[5]=upper[1];
            fit = data;
            ((DefaultIntervalXYDataset)e).addSeries("",fit);
        }
        //No interval
        else {
            e = new DefaultXYDataset();
            ((DefaultXYDataset)e).addSeries("",fit);
        }
        d.addSeries(key,emp);
        int count = getDatasetCount();
        setDataset(count,e);
        setDataset(count+1,d);
        //Set a default renderer for the empirical data
        final XYLineAndShapeRenderer empRend = new XYLineAndShapeRenderer(false,true);
        empRend.setShapesFilled(false);
        setRenderer(count+1,empRend);

        //Set a default renderer for the fitted data
        XYLineAndShapeRenderer fitRend = null;
        if (interval) {
            fitRend = new XYErrorRenderer();
            ((XYErrorRenderer)fitRend).setDrawYError(true);
            ((XYErrorRenderer)fitRend).setDrawXError(false);
            ((XYErrorRenderer)fitRend).setCapLength(ERROR_BAR_CAP_LENGTH);  //Cap length of error bars
            fitRend.setLinesVisible(true);
            fitRend.setShapesVisible(false);
        } else {
            fitRend = new XYLineAndShapeRenderer(true,false);
        }

        setRenderer(count,fitRend);
        fitRend.setSeriesPaint(0,empRend.getSeriesPaint(0));
        Color c = (Color)getRenderer(count).getSeriesPaint(0);
        //Avoid yellow, for which red and green are always 255, but blue varies
        //because the colors are determined automatically to maximize visual differences
        //between datasets
        if(c.getRed()==255 && c.getGreen()==255) {
            getRenderer(count).setSeriesPaint(0,Color.orange);
            getRenderer(count+1).setSeriesPaint(0,Color.orange);
        }

    }
    
}
