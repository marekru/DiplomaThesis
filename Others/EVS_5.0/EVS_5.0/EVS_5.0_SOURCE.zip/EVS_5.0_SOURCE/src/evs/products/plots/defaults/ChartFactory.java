package evs.products.plots.defaults;

//EVS dependencies
import evs.metric.metrics.Metric;
import evs.metric.metrics.DecomposableScore;

//JFreeChart dependencies
import org.jfree.chart.JFreeChart;

/**
 * Returns a default chart for different verification metrics.
 * 
 * @author evs@hydrosolved.com
 */

public class ChartFactory {
    
    /*******************************************************************************
     *                                                                             *
     *                              ACCESSOR METHODS                               *
     *                                                                             *
     ******************************************************************************/  
    
     /**
      * Returns a default chart for a given metric identifier from {@link evs.metric.metrics.Metric}
      * Results may be added through the instance methods.  The parameters of the chart can
      * also be modified via its instance methods.    
      *
      * Optionally, an additional identifier may be included. Currently, this may 
      * comprise a score decomposition identifier, {@link evs.metric.metrics.DecomposableScore}, 
      * or an identifier for the rank histogram frequency (relative or absolute), 
      * {@link evs.products.plots.defaults.RankHistogramPlot}
      * 
      * Throws an exception if the metric type is not recognized.
      *
      * @param metric the metric identifier
      * @param additional an additional identifier, such as a decomposition identifier 
      * @return a default chart
      */
    
    public static JFreeChart getDefaultChart(int metric, Integer additional) throws IllegalArgumentException {
        //Set the default to the overall score
        if(additional==null) {
            additional = DecomposableScore.OVERALL_SCORE;
        }
        switch(metric) {
            case Metric.SPREAD_BIAS_DIAGRAM: {
                return SpreadBiasDiagram.getDefaultChart();
            } 
            case Metric.MEDIAN_CENTRAL_SPREAD_BIAS: {
                return MedianCentralSpreadBiasDiagram.getDefaultChart();
            } 
            case Metric.RANK_HISTOGRAM: {
                return RankHistogramPlot.getDefaultChart(additional==RankHistogramPlot.RELATIVE);  
            }                 
            case Metric.RMSE: {
                return RMSEPlot.getDefaultChart();
            }
            case Metric.MEAN_ERROR: {
                return MEPlot.getDefaultChart();
            }
            case Metric.RELATIVE_MEAN_ERROR: {
                return RMEPlot.getDefaultChart();
            }
            case Metric.CORRELATION: {
                return CorrelationPlot.getDefaultChart();
            }
            case Metric.SAMPLE_SIZE: {
                return SampleSizePlot.getDefaultChart();
            }
            case Metric.BOX_DIAGRAM_POOLED_BY_LEAD: {
                return ModifiedBoxPlotPooledByLead.getDefaultChart();
            }
            case Metric.BOX_DIAGRAM_UNPOOLED_BY_LEAD: {
                return ModifiedBoxPlotUnpooledByLead.getDefaultChart();
            }
            case Metric.BOX_DIAGRAM_UNPOOLED_BY_LEAD_OBS: {
                return ModifiedBoxPlotUnpooledByLeadObs.getDefaultChart();
            }
            case Metric.MCRD: {
                return MCRDiagram.getDefaultChart();
            }
            case Metric.BRIER_SCORE: {
                return BrierScorePlot.getDefaultChart(additional);
            }
            case Metric.ROC: {
                return ROCPlot.getDefaultChart();
            }
            case Metric.RELIABILITY_DIAGRAM: {
                return ReliabilityDiagram.getDefaultChart();
            }
            case Metric.CRPS: {
                return MeanCRPSPlot.getDefaultChart(additional);
            }
            case Metric.MEPD: {
                return MEPDiagram.getDefaultChart();
            }
            case Metric.ROCS: {
                return ROCScorePlot.getDefaultChart();
            }
            case Metric.BRIER_SKILL_SCORE: {
                return BrierSkillScorePlot.getDefaultChart(additional);
            }
            case Metric.CRPS_SKILL_SCORE: {
                return MeanCRPSSPlot.getDefaultChart(additional);
            }
            case Metric.MEAN_ABSOLUTE_ERROR: {
                return MAEPlot.getDefaultChart();
            }
            case Metric.SVQQ: {
                return QQPlot.getDefaultChart();
            }
            default: {
                throw new IllegalArgumentException("Unrecognized metric for plotting: " +
                        "add an option to the getDefaultChart method of the " +
                        "ChartFactory class.");
            }
        }
    }
    
}
