package evs.products.plots.defaults.boxplotutilities;

//Java util dependencies
import java.util.ArrayList;
import java.util.List;

//JFreeChart dependencies
import org.jfree.data.Range;
import org.jfree.data.RangeInfo;
import org.jfree.data.xy.AbstractXYDataset;

/**
 * A simple implementation of the BoxPlotDataset.  The dataset can hold 
 * only one series.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ConcreteBoxPlotDataset extends AbstractXYDataset implements RangeInfo {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLES                              *
     *                                                                              *
     *******************************************************************************/
    
    /** 
     * The series key. 
     */
    
    private Comparable seriesKey;

    /** 
     * Storage for the x values. 
     */
    
    private List<Number> xVals;

    /** 
     * Storage for the box and whisker statistics. 
     */
    
    private List<BoxPlotItem> items;

    /** 
     * The minimum range value. 
     */
    
    private Number minimumRangeValue;

    /** 
     * The maximum range value. 
     */
    
    private Number maximumRangeValue;

    /** 
     * The range of values. 
     */
    
    private Range rangeBounds;

    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/    
    
    /**
     * Constructs a new box dataset.
     * <p>
     *
     * The current implementation allows only one series in the dataset.
     * This may be extended in a future version.
     *
     * @param seriesKey  the key for the series.
     */
    public ConcreteBoxPlotDataset(Comparable seriesKey) {
        this.seriesKey = seriesKey;
        this.xVals = new ArrayList<Number>();
        this.items = new ArrayList<BoxPlotItem>();
        this.minimumRangeValue = null;
        this.maximumRangeValue = null;
        this.rangeBounds = null; 
    }

    /*******************************************************************************
     *                                                                             *
     *                              ACCESSOR METHODS                               *
     *                                                                             *
     ******************************************************************************/       
    
    /**
     * Returns the name of the series stored in this dataset.
     *
     * @param i  the index of the series. Currently ignored.
     * 
     * @return the name of this series.
     */
    public Comparable getSeriesKey(int i) {
        return this.seriesKey;
    }
    
    /**
     * Return an item from within the dataset.
     * 
     * @param series  the series index (ignored, since this dataset contains
     *                only one series).
     * @param item  the item within the series (zero-based index)
     * 
     * @return the item.
     */
    public BoxPlotItem getItem(int series, int item) {
        return (BoxPlotItem) this.items.get(item);  
    }

    /**
     * Returns the x-value for one item in a series.
     * <p>
     *
     * @param series  the series (zero-based index).
     * @param item  the item (zero-based index).
     *
     * @return The x-value.
     */
    
    public Number getX(int series, int item) {
        return xVals.get(item);
    }

    /**
     * Returns the y-value for one item in a series.
     * <p>
     * This method (from the XYDataset interface) is mapped to the 
     * getMaxNonOutlierValue() method.
     *
     * @param series  the series (zero-based index).
     * @param item  the item (zero-based index).
     *
     * @return The y-value.
     */
    
    public Number getY(int series, int item) {
        return null; 
    }

    /**
     * Returns the min-value for the specified series and item.
     *
     * @param series  the series (zero-based index).
     * @param item  the item (zero-based index).
     *
     * @return The min-value for the specified series and item.
     */
    public Number getMinRegularValue(int series, int item) {
        Number result = null;
        BoxPlotItem stats = (BoxPlotItem) this.items.get(item);
        if (stats != null) {
            result = stats.getMinRegularValue();
        }
        return result;
    }

    /**
     * Returns the max-value for the specified series and item.
     *
     * @param series  the series (zero-based index).
     * @param item  the item (zero-based index).
     *
     * @return The max-value for the specified series and item.
     */
    public Number getMaxRegularValue(int series, int item) {
        Number result = null;
        BoxPlotItem stats = (BoxPlotItem) this.items.get(item);
        if (stats != null) {
            result = stats.getMaxRegularValue();
        }
        return result;
    }

    /**
     * Returns the number of series in the dataset.
     * <p>
     * This implementation only allows one series.
     *
     * @return The number of series.
     */
    public int getSeriesCount() {
        return 1;
    }

    /**
     * Returns the number of items in the specified series.
     *
     * @param series  the index (zero-based) of the series.
     *
     * @return The number of items in the specified series.
     */
    public int getItemCount(int series) {
        return xVals.size();
    }

    /**
     * Returns the minimum y-value in the dataset.
     *
     * @param includeInterval  a flag that determines whether or not the
     *                         y-interval is taken into account.
     * 
     * @return The minimum value.
     */
    public double getRangeLowerBound(boolean includeInterval) {
        double result = Double.NaN;
        if (this.minimumRangeValue != null) {
            result = this.minimumRangeValue.doubleValue();
        }
        return result;        
    }

    /**
     * Returns the maximum y-value in the dataset.
     *
     * @param includeInterval  a flag that determines whether or not the
     *                         y-interval is taken into account.
     * 
     * @return The maximum value.
     */
    public double getRangeUpperBound(boolean includeInterval) {
        double result = Double.NaN;
        if (this.maximumRangeValue != null) {
            result = this.maximumRangeValue.doubleValue();
        }
        return result;        
    }

    /**
     * Returns the range of the values in the range of this dataset.
     *
     * @param includeInterval  a flag that determines whether or not the
     *                         y-interval is taken into account.
     * 
     * @return The range.
     */
    public Range getRangeBounds(boolean includeInterval) {
        return this.rangeBounds;
    }
    
    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/     
    
    /**
     * Adds an item to the dataset.
     * 
     * @param xVal the x value.
     * @param item  the item.
     */
    
    public void add(Number xVal, BoxPlotItem item) {
        this.xVals.add(xVal);
        this.items.add(item);
        if (this.minimumRangeValue == null) {
            this.minimumRangeValue = item.getMinRegularValue();
        }
        else {
            if (item.getMinRegularValue().doubleValue() 
                    < this.minimumRangeValue.doubleValue()) {
                this.minimumRangeValue = item.getMinRegularValue();
            }
        }
        if (this.maximumRangeValue == null) {
            this.maximumRangeValue = item.getMaxRegularValue();
        }
        else {
            if (item.getMaxRegularValue().doubleValue() 
                    > this.maximumRangeValue.doubleValue()) {
                this.maximumRangeValue = item.getMaxRegularValue();
            }
        }
        this.rangeBounds = new Range(
            this.minimumRangeValue.doubleValue(), 
            this.maximumRangeValue.doubleValue()
        );
    }    

}
