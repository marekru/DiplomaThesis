package evs.products.plots.defaults;

//JFreeChart dependencies
import org.jfree.chart.axis.NumberAxis;
import org.jfree.data.xy.DefaultXYDataset;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.BoxAndWhiskerXYToolTipGenerator;

//Java awt dependencies
import java.awt.Font;
import java.awt.Color;
        
//Java util dependencies
import java.util.TreeMap;
import java.util.Iterator;

//EVS dependencies
import evs.metric.results.MetricResult;
import evs.metric.results.MetricResultByLeadTime;
import evs.metric.results.DoubleMatrix2DResult;
import evs.products.plots.defaults.boxplotutilities.BoxPlotItem;
import evs.products.plots.defaults.boxplotutilities.BoxPlotRenderer;
import evs.products.plots.defaults.boxplotutilities.ConcreteBoxPlotDataset;

/**
 * Constructs a modified box plot with error values (as boxes) against forecast lead 
 * time for multiple lead times if requested.  For any given lead time, the results 
 * are pooled across all forecasts at that lead time.
 *
 * @author evs@hydrosolved.com
 */

public class ModifiedBoxPlotPooledByLead extends DefaultXYPlotByLeadTime implements EVSPlot, RealValuedPlot  {
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/    
    
    /**
     * Constructs a modified box plot with no input arguments.  The data must be set later.
     */
    
    public ModifiedBoxPlotPooledByLead() {
        //Set some default axes
        final NumberAxis xAxis = new NumberAxis("Lead time (hours)");
        //Set name in subclass
        final NumberAxis yAxis = new NumberAxis("Forecast errors (forecast - observed)");
        xAxis.setTickLabelFont(new Font("Verdana", Font.PLAIN, 8));
        yAxis.setTickLabelFont(new Font("Verdana", Font.PLAIN, 8));
        yAxis.setAutoRangeIncludesZero(false);
        setDomainAxis(xAxis);
        setRangeAxis(yAxis);
        //Hide the grid lines
        setDomainGridlinesVisible(false);
        setRangeGridlinesVisible(false);                     
    }

    /*******************************************************************************
     *                                                                             *
     *                              ACCESSOR METHODS                               *
     *                                                                             *
     ******************************************************************************/     
    
    /**
     * Returns a default chart with a plot that extends evs.products.plots.EVSPlot.
     *
     * @return a default chart
     */

    public static JFreeChart getDefaultChart() {
        String name = "Modified box plot of ensemble forecast errors against forecast lead time.";
        ModifiedBoxPlotPooledByLead plot = new ModifiedBoxPlotPooledByLead();            
        final JFreeChart chart = new JFreeChart(name,new Font("Verdana", Font.BOLD, 12),plot,true);
        chart.setBackgroundPaint(Color.white);
        chart.getTitle().setMargin(7,0,7,0);
        chart.setAntiAlias(false);
        chart.removeLegend();
        return chart;        
    }

    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/          
    
    /**
     * Adds a dataset to the plot or throws an exception if the data are of an 
     * incorrect type.
     *
     * @param data the data
     */
    
    public void addDataset(String key, MetricResult data) throws IllegalArgumentException {
        if(!(data instanceof MetricResultByLeadTime) || (((MetricResultByLeadTime)data).getIDForStoredResults() != MetricResult.DOUBLE_MATRIX_2D_RESULT)) {
            throw new IllegalArgumentException("Unexpected input data for the modified box plot (pooled by lead time).");
        }
        ConcreteBoxPlotDataset d = new ConcreteBoxPlotDataset(key);
        MetricResultByLeadTime dp = (MetricResultByLeadTime)data;
        TreeMap<Double,MetricResult> res = dp.getResults();
        Iterator i = res.keySet().iterator();
        while(i.hasNext()) {
            double next = (Double)i.next();
            DoubleMatrix2DResult nextD = (DoubleMatrix2DResult)res.get(next);
            double[][] result = nextD.getResult().toArray();
            double[] dt = result[1];
            //Use the expected value as the center line: assumes equal increments, but this is the case 
            //double mean = FunctionLibrary.mean().apply(new DenseDoubleMatrix1D(result[1]));
            BoxPlotItem item = new BoxPlotItem(dt);
            d.add(next,item);
        }
      
        //Add new dataset
        int count = getDatasetCount();
        setDataset(count,d);       
        //Set the renderer
        final BoxPlotRenderer renderer = new BoxPlotRenderer();
        renderer.setArtifactPaint(Color.red);  //Red whiskers
        renderer.setToolTipGenerator(new BoxAndWhiskerXYToolTipGenerator());
        setRenderer(count,renderer);      
        setTimeTicks(dp,defTCount);
    }    
    
    /**
     * Appends the real units to the appropriate axes of the plot.
     * 
     * @param units the units to appendRowsShallow
     */
    
    public void setRealUnits(String units) {
        String c = getRangeAxis().getLabel();
        c = c + " in '" + units + "'";
        getRangeAxis().setLabel(c);        
    }      
    
}
