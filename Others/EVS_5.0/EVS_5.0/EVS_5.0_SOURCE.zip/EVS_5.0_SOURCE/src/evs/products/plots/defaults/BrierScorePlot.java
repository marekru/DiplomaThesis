package evs.products.plots.defaults;

//JFreeChart dependencies
import org.jfree.chart.JFreeChart;
        
//Java awt dependencies
import java.awt.Font;
import java.awt.Color;
       
//EVS dependencies
import evs.metric.metrics.DecomposableScore;
import evs.metric.results.MetricResult;

/**
 * Constructs a default plot of the Brier Score based on multiple lead times.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class BrierScorePlot extends DefaultXYPlotByLeadTime implements EVSPlot {
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/    
    
    /**
     * Constructs a Brier score plot with no input arguments.  The data must be set later.
     */
    
    public BrierScorePlot() {
        super();
        getRangeAxis().setLabel("Brier Score");
        getRangeAxis().setRange(0.0,1.0);
    }

    /*******************************************************************************
     *                                                                             *
     *                              ACCESSOR METHODS                               *
     *                                                                             *
     ******************************************************************************/     
    
    /**
     * Returns a default chart with a plot that extends evs.products.plots.EVSPlot.
     *
     * @return a default chart
     */
    
    public static JFreeChart getDefaultChart() {
        String name = "Brier Score by forecast lead time for different event probability thesholds.";
        BrierScorePlot plot = new BrierScorePlot();
        final JFreeChart chart = new JFreeChart(name,new Font("Verdana", Font.BOLD, 12),plot,true);
        chart.setBackgroundPaint(Color.white);
        chart.getTitle().setMargin(7,0,7,0);
        chart.setAntiAlias(false);
        chart.getLegend().setBorder(org.jfree.chart.block.BlockBorder.NONE);
        return chart;                  
    }
    
    /**
     * Returns a default chart with a plot that extends evs.products.plots.EVSPlot.
     *
     * @param type the chart type: one of the static final variables in evs.metric.metrics.DecomposableScore
     * @return a default chart
     */

    public static JFreeChart getDefaultChart(int type) {
        String name = "";
        String rangeAx = "";
        switch(type) {
            case DecomposableScore.OVERALL_SCORE: {
                name = "Brier Score by forecast lead time.";
                rangeAx = "Brier Score";
            }; break;
            case DecomposableScore.RELIABILITY: {
                name = "Brier Score reliability component by forecast lead time.";
                rangeAx = "Brier Score reliability";
            }; break;
            case DecomposableScore.RESOLUTION: {
                name = "Brier Score resolution component by forecast lead time.";
                rangeAx = "Brier Score resolution";
            }; break;
            case DecomposableScore.UNCERTAINTY: {
                name = "Brier Score uncertainty component by forecast lead time.";
                rangeAx = "Brier Score uncertainty";
            }; break;
            case DecomposableScore.TYPE_II_BIAS: {
                name = "Brier Score Type-II bias component by forecast lead time.";
                rangeAx = "Brier Score Type-II bias";
            }; break;
            case DecomposableScore.DISCRIMINATION: {
                name = "Brier Score discrimination component by forecast lead time.";
                rangeAx = "Brier Score discrimination";
            }; break;
            case DecomposableScore.SHARPNESS: {
                name = "Brier Score sharpness component by forecast lead time.";
                rangeAx = "Brier Score sharpness";
            }; break;
            case DecomposableScore.SCORE_GIVEN_OBS_TRUE: {
                name = "Brier Score conditional on observed event by forecast lead time.";
                rangeAx = "Brier Score conditional on observed event";
            }; break;
            case DecomposableScore.SCORE_GIVEN_OBS_FALSE: {
                name = "Brier Score conditional on observed non-event by forecast lead time.";
                rangeAx = "Brier Score conditional on observed non-event";
            }; break;
            case DecomposableScore.TYPE_II_BIAS_GIVEN_OBS_TRUE: {
                name = "Brier Score Type-II bias conditional on observed event by forecast lead time.";
                rangeAx = "Brier Score Type-II bias conditional on observed event";
            }; break;
            case DecomposableScore.TYPE_II_BIAS_GIVEN_OBS_FALSE: {
                name = "Brier Score Type-II bias conditional on observed non-event by forecast lead time.";
                rangeAx = "Brier Score Type-II bias conditional on observed non-event";
            }; break;
            case DecomposableScore.DISCRIMINATION_GIVEN_OBS_TRUE: {
                name = "Brier Score discrimination conditional on observed event by forecast lead time.";
                rangeAx = "Brier Score discrimination conditional on observed event";
            }; break;
            case DecomposableScore.DISCRIMINATION_GIVEN_OBS_FALSE: {
                name = "Brier Score discrimination conditional on observed non-event by forecast lead time.";
                rangeAx = "Brier Score discrimination conditional on observed non-event";
            }; break;
            default : {
                throw new IllegalArgumentException("Unrecognized score type identifier for Brier Score plot.");
            }
        }
        BrierScorePlot plot = new BrierScorePlot();
        final JFreeChart chart = new JFreeChart(name,new Font("Verdana", Font.BOLD, 12),plot,true);
        chart.setBackgroundPaint(Color.white);
        chart.getTitle().setMargin(7,0,7,0);
        chart.setAntiAlias(false);
        plot.getRangeAxis().setLabel(rangeAx); 
        chart.getLegend().setBorder(org.jfree.chart.block.BlockBorder.NONE);
        return chart;                    
    }        
    
    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/          
    
    /**
     * Adds a dataset to the plot or throws an exception if the data are of an 
     * incorrect type.
     *
     * @param key a unique string identifier for the result
     * @param data the data
     */
    
    public void addDataset(String key, MetricResult data) throws IllegalArgumentException {
        addThresholdDataset(key,data);
    }    
     
}
