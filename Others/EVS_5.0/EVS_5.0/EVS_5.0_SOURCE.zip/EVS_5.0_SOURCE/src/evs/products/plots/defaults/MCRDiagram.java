package evs.products.plots.defaults;

//JFreeChart dependencies
import org.jfree.chart.JFreeChart;
        
//EVS dependencies
import evs.metric.results.MetricResult;
import evs.metric.results.DoubleMatrix2DResult;
import evs.metric.parameters.DoubleProcedureParameter;
import evs.metric.results.MetricResultByThreshold;

//Java util dependencies
import java.util.TreeMap;
import java.util.Iterator;

//Java awt dependencies
import java.awt.Font;
import java.awt.Color;

/**
 * Constructs a default Mean Capture Rate (MCR) diagram.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class MCRDiagram extends DefaultXYPlot implements RealValuedPlot {
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/    
    
    /**
     * Constructs an MCR diagram with no input arguments.
     */
    
    public MCRDiagram() {
        super();
        //Set some default axes
        getDomainAxis().setLabel("Non-exceedence probability");
        getDomainAxis().setRange(0.0,1.0);
        getRangeAxis().setLabel("Absolute error");
    }

    /*******************************************************************************
     *                                                                             *
     *                              ACCESSOR METHODS                               *
     *                                                                             *
     ******************************************************************************/     
    
    /**
     * Returns a default chart with a plot that extends evs.products.plots.EVSPlot.
     *
     * @return a default chart
     */
    
    public static JFreeChart getDefaultChart() {
        String name = "Mean Capture Rate diagram.";
        MCRDiagram plot = new MCRDiagram();
        final JFreeChart chart = new JFreeChart(name,new Font("Verdana", Font.BOLD, 12),plot,true);
        chart.setBackgroundPaint(Color.white);
        chart.getTitle().setMargin(7,0,7,0);
        chart.setAntiAlias(false);
        chart.getLegend().setBorder(org.jfree.chart.block.BlockBorder.NONE);
        return chart;                               
    }        
    
    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/             
    
    /**
     * Adds a dataset to the plot or throws an exception if the data are of an 
     * incorrect type.
     *
     * @param data the data
     */
    
    public void addDataset(String key, MetricResult data) throws IllegalArgumentException {
        //Iterate through the thresholds, calling addDataset in the superclass each time
        if(!(data instanceof MetricResultByThreshold) || ((MetricResultByThreshold)data).getIDForStoredResults()!=data.DOUBLE_MATRIX_2D_RESULT) {
            throw new IllegalArgumentException("Unexpected input data for the MCR diagram: "+data.getClass());
        }
        TreeMap<DoubleProcedureParameter,MetricResult> res = ((MetricResultByThreshold)data).getResults();
        Iterator k = res.keySet().iterator();
        while(k.hasNext()) {
            DoubleProcedureParameter key2 = (DoubleProcedureParameter)k.next();
            if(key2.isMainThreshold().getParVal()) {
                DoubleMatrix2DResult result = (DoubleMatrix2DResult)res.get(key2);
                super.addDataset(key2+"",result);
            }
        } 
    }     
    
    /**
     * Appends the real units to the appropriate axes of the plot.
     * 
     * @param units the units to append
     */
    
    public void setRealUnits(String units) {
        String c = getRangeAxis().getLabel();
        c = c + " in '" + units + "'";
        getRangeAxis().setLabel(c);        
    }  
    
}
