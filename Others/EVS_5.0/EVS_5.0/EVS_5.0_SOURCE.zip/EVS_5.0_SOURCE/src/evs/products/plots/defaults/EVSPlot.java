package evs.products.plots.defaults;

//EVS dependencies
import evs.metric.results.MetricResult;

/**
 * An interface for EVS plots.
 * 
 * @author evs@hydrosolved.com
 */

public interface EVSPlot { 

    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/

    /**
     * Default cap length for displaying error bars.
     */

    public static final double ERROR_BAR_CAP_LENGTH = 5;

    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/      
    
    /**
     * Sets the plot data or throws an exception if the data are of an incorrect
     * type.
     *
     * @param key the dataset identifier
     * @param data the data
     */
    
    public abstract void addDataset(String key, MetricResult data) throws IllegalArgumentException;
    
}
