package evs.external.fewsadapter;

// Java dependencies
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Arrays;

import ohd.hseb.util.Logger;
import ohd.hseb.util.fews.Diagnostics;
import ohd.hseb.util.fews.FewsAdapterDAO;
import ohd.hseb.util.fews.FewsXMLParser;
import ohd.hseb.util.fews.RunInfo;
import ohd.hseb.util.io.ExceptionParser;
import evs.analysisunits.AggregationUnit;
import evs.analysisunits.AnalysisUnit;
import evs.analysisunits.VerificationUnit;
import evs.analysisunits.scale.MeasurementUnitsChangeLibrary;
import evs.data.DataSource;
import evs.data.FileArrayDataSource;
import evs.data.FileDataSource;
import evs.data.fileio.GlobalUnitsReader;
import evs.data.fileio.ProjectFileIO;
import evs.gui.windows.EVSMainWindow;
import evs.utilities.EVSUtilities;

/**
 * This class is the connection between the Flood Early Warning System (FEWS)
 * and the EVS. The FEWS invokes the main method of this class. The diagnostics
 * from the EVS are written to XML for display in the CHPS output dialog.
 *
 * @author evs@hydrosolved.com
 * @author xiaoshen.li@noaa.gov
 * @version 2.0
 */
public class EVSToFEWSAdapter {

    /**
     * *****************************************************************************
     * * VARIABLES * *
     ******************************************************************************
     */
    /**
     * Adapter version.
     */
    public static final double ADAPTER_VERSION = 2.0;
    // Logging for diagnostic information.
    private final Logger logger = new Diagnostics();
    private String diagnosticsFile;
    //EVS project files are copied from input/ to output/, where they will be used
    //and saved. If multiple evs project files, run in sequence
    private String[] evsProjFilesInOutputDir;

    /**
     * *****************************************************************************
     * * PUBLIC METHODS * *
     ******************************************************************************
     */
    /**
     * This is the entry point for FEWS to call the EVS.
     *
     * @param args contains the path to a properties file.
     * @throws Exception - true exceptional conditions (not caused by the
     * data/model) are propagated upwards.
     */
    public static void main(final String[] args) {

        // Instance of the adapter
        final EVSToFEWSAdapter fewsAdapter = new EVSToFEWSAdapter();

        // Log current time
        final long startTime = System.currentTimeMillis();

        try {
            /*
             * All the System.out.println(..) will goes to the console
             * progressively when running and be saved into output/diag.xml
             * through fewsAdapter.logger
             */

            final TeeOutputStream teeOutputStream = new TeeOutputStream(System.out, fewsAdapter.logger);

            System.setOut(new PrintStream(teeOutputStream));

            // Process the input arguments to the adapter
            fewsAdapter.processFewsAdapterArgs(args);
            fewsAdapter.logger.log(Logger.INFO, "Using FEWS-EVS Adapter version: " + ADAPTER_VERSION);
            fewsAdapter.logger.log(Logger.INFO, EVSUtilities.getVersionInfo());

            fewsAdapter.logger.log(Logger.INFO, "Executing the Ensemble Verification System (EVS).....");

            // Run the EVS projects
            EVSMainWindow.runProjectsSilently(fewsAdapter.evsProjFilesInOutputDir);

            // Clean up and print timing diagnostics
            final String header = "**************************************************************************";
            final String timingInfo = "Total run time: " + (System.currentTimeMillis() - startTime) / 1000.0
                    + " seconds.";
            final String footer = "******************************EXECUTION TIME******************************";

            fewsAdapter.logger.log(header);
            fewsAdapter.logger.log(timingInfo);
            fewsAdapter.logger.log(footer);

        } catch (final Exception e) {
            fewsAdapter.logger.log(Logger.FATAL, ExceptionParser.multiLineStackTrace(e));
        } finally {
            try {
                FewsAdapterDAO.writeLog(fewsAdapter.logger, fewsAdapter.diagnosticsFile);
            } catch (final Exception e) {
                System.err.println("Cannot write log file for execution of " + fewsAdapter.getClass().getSimpleName() + ": " + e);
            }
        }
    }

    /**
     * @param args only one element, which is the run_info.xml file
     */
    private void processFewsAdapterArgs(final String[] args) throws Exception {

        final FewsXMLParser xmlParser = new FewsXMLParser(logger);

        if (args != null && args.length == 1) {
            String run_info_file_name = args[0];

            if (run_info_file_name == null) {
                throw new Exception("run info file name does not exist!");
            }

            run_info_file_name = run_info_file_name.trim();

            final RunInfo runInfo = new RunInfo(logger);

            xmlParser.parseRunInfoFile(run_info_file_name, runInfo);

            diagnosticsFile = runInfo.getDiagnosticFile(); // retrieving
            // diag.xml path

            //Based on the property "rootDir" in run_info.xml, get the root
            //directory
            final String rootDir = runInfo.getProperties().getProperty("rootDir");

            logger.log(Logger.INFO, "Root directory = " + rootDir);

            /*
             * Copy every EVS project file from input to output, where they will
             * be used and modified; if there are multiple evs project files,
             * they will be run in sequence
             */

            final String sep = System.getProperty("file.separator");

            final String inputDir = rootDir + sep + "input" + sep;
            final String outputDir = rootDir + sep + "output" + sep;

            final File inputDirFile = new File(inputDir);

            //Selects only ".evs" files
            final EVSProjFileFilter evsProjFileFilter = new EVSProjFileFilter();
            //Returns only file names, without path
            final String[] evsProjFiles = inputDirFile.list(evsProjFileFilter);

            logger.log(Logger.INFO, "Running EVS project files '" + Arrays.toString(evsProjFiles) + "'.");

            evsProjFilesInOutputDir = new String[evsProjFiles.length];

//            //TODO Currently, these methods need to be called before some of the static methods in the 
//            //EVS can be called, which is a design flaw that needs to be addressed for correct use of
//            //the EVS as a library. 
//            new GlobalUnitsReader();
//            new MeasurementUnitsChangeLibrary();

            for (int i = 0; i < evsProjFiles.length; i++) {
                //Write the EVS project files to the output directory
                final AnalysisUnit[] units = ProjectFileIO.read(new File(inputDir + evsProjFiles[i]));
                //Modify the directories for each unit
                for (final AnalysisUnit nextUnit : units) {
                    if (nextUnit instanceof VerificationUnit) {
                        final VerificationUnit v = (VerificationUnit) nextUnit;
                        //Set output path
                        final DataSource out = v.getOutputData();
                        if (out instanceof FileDataSource) {
                            final String path = ((File) ((FileDataSource) out).getData()).getPath();
                            final String newPath = rootDir + sep + path;
                            v.setOutputData(new FileDataSource(new File(newPath)));
                        } else {
                            throw new IOException("Unexpected class for " + "output data source: " + out.getClass());
                        }
                        final DataSource forecasts = v.getForecastData();
                        //Set the forecast data source
                        if (forecasts instanceof FileDataSource) {
                            final String path = ((File) ((FileDataSource) forecasts).getData()).getPath();
                            final String newPath = rootDir + sep + path;
                            v.setForecastData(new FileDataSource(new File(newPath)));
                        } else if (forecasts instanceof FileArrayDataSource) {
                            final File[] f = (File[]) forecasts.getData();
                            final File[] newF = new File[f.length];
                            for (int j = 0; j < f.length; j++) {
                                final String newPathF = rootDir + sep + f[j].getPath();
                                newF[j] = new File(newPathF);
                            }
                            v.setForecastData(new FileArrayDataSource(newF));
                        } else {
                            String fileClass = "";
                            if (forecasts != null) {
                                fileClass = forecasts.getClass().toString();
                            }
                            throw new IOException("Unexpected class for forecast data source: " + fileClass);
                        }
                        //Set the observed data source
                        final DataSource observed = v.getObservedData();
                        //Set the forecast data source
                        if (observed instanceof FileDataSource) {
                            final String path = ((File) ((FileDataSource) observed).getData()).getPath();
                            final String newPath = rootDir + sep + path;
                            v.setObservedData(new FileDataSource(new File(newPath)));
                        } else {
                            throw new IOException("Unexpected class for " + "observed data source: "
                                    + observed.getClass());
                        }

                    } else if (nextUnit instanceof AggregationUnit) {
                        final AggregationUnit a = (AggregationUnit) nextUnit;
                        //Set output path (the only path for an Aggregation Unit)
                        final DataSource out = a.getOutputData();
                        if (out instanceof FileDataSource) {
                            final String path = ((File) ((FileDataSource) out).getData()).getPath();
                            final String newPath = rootDir + sep + path;
                            a.setOutputData(new FileDataSource(new File(newPath)));
                        } else {
                            throw new IOException("Unexpected class for output data source: " + out.getClass());
                        }
                    }
                }
                //Write the updated EVS project file to the output directory
                final String writeMe = outputDir + evsProjFiles[i];
                ProjectFileIO.write(new File(writeMe), units);
                evsProjFilesInOutputDir[i] = writeMe;
                logger.log(Logger.INFO, "Updated and written EVS project file: " + writeMe);
            }
            logger.log(Logger.INFO, "Completed processing of FEWS Adapter arguments.");
        } else {
            throw new Exception("The arguments to EVSToFEWSAdapter is either null or comprises more than one element.");
        }
    }

    /**
     * Only selects files ends with ".evs". Used in File's list(filter) method,
     * which returns an array of String.
     */
    private static class EVSProjFileFilter implements FilenameFilter {

        public boolean accept(final File dir, final String name) {
            return name.endsWith(".evs");
        }
    }
}
