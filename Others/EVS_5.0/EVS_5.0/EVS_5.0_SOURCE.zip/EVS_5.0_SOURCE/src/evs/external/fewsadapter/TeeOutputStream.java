package evs.external.fewsadapter;

//Java dependencies
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;

//OHD dependencies
import ohd.hseb.util.Logger;
import ohd.hseb.util.fews.Diagnostics;
import ohd.hseb.util.fews.FewsAdapterDAO;

/**
 * Progressively writes the output of an EVS adapter run within FEWS to the FEWS 
 * output dialog, in order to update users of the progress of an EVS run within FEWS
 * as those updates become available.
 * 
 * @author xiaoshen.li@noaa.gov
 * @version 1.0
 */

class TeeOutputStream extends OutputStream {
	private final OutputStream os1;
	private final Logger _logger;

	public TeeOutputStream(final OutputStream os1, final Logger log) {
		this.os1 = os1;
		this._logger = log;
	}

	@Override
	public void write(final byte[] b) throws IOException {
		os1.write(b);
		this._logger.log(Logger.INFO, new String(b));
	}

	@Override
	public void write(final byte[] b, final int off, final int len)
			throws IOException {
		os1.write(b, off, len);
		this._logger.log(Logger.INFO, new String(b, off, len));
	}

	@Override
	public void write(final int b) throws IOException {
		os1.write(b);
		this._logger.log(Logger.INFO, String.valueOf((char) b));
	}

	@Override
	public void flush() throws IOException {
		os1.flush();
	}

	@Override
	public void close() throws IOException {
		os1.close();
		this._logger.close();
	}

	public static void test2() {
		System.out.println("This is test2");
	}

	public static void test1() {
		System.out.println("This is test1");
	}

	public static void main(final String[] args) throws Exception {
		System.out.println("normal A");
		final PrintStream sav = System.out;

		final Logger log = new Diagnostics();

		/*
		 * All the System.out.println(..) will go to the console progressively
		 * when running and be saved into junk_diag.xml
		 */
		
		final TeeOutputStream teeOutputStream = new TeeOutputStream(System.out,
				log);
		System.setOut(new PrintStream(teeOutputStream));
		test1();
		test2();

		final String diagFile = "junk_diag.xml"; // will be at HEFS/evs
		FewsAdapterDAO.writeLog(log, diagFile);
		System.setOut(sav);
		System.out.println("normal B");
	}
}
