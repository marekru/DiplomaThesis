package evs.utilities.matrix;

//EVS dependencies
import evs.utilities.mathutil.DoubleFunction;
import evs.utilities.mathutil.DoubleDoubleFunction;

/**
 * An interface for matrices of doubles.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public interface DoubleMatrix {
  
/*******************************************************************************
 *                                                                             *
 *                            MUTATOR METHODS                                  *
 *                                                                             *
 ******************************************************************************/
    
    /**
     * Assigns a function to each element in the matrix.  This implementation is
     * based on that in cern.colt.matrix class.  For example, to multiply every element
     * in the matrix by a number x:
     *
     * Functions F = Functions.functions;
     * DoubleFunction a = F.mult(x);
     * myMatrix.assign(a);
     *
     * @param function a function to assign
     * @param overwrite is true to overwrite the existing matrix
     * @return this matrix modified by the function
     */
    
    abstract DoubleMatrix assign(DoubleFunction function, boolean overwrite) throws ArithmeticException, IllegalArgumentException;
    
    /**
     * Assigns a function to each element in the matrix ignoring a specified value.  
     * This implementation is based on that in cern.colt.matrix class.  For example, 
     * to multiply every element in the matrix by a number x:
     *
     * Functions F = Functions.functions;
     * DoubleFunction a = F.mult(x);
     * myMatrix.assign(a);
     *
     * @param function a function to assign
     * @param overwrite is true to overwrite the existing matrix
     * @param avoid a number to avoid
     * @return this matrix modified by the function
     */
    
    abstract DoubleMatrix assign(DoubleFunction function, boolean overwrite, double avoid) throws ArithmeticException, IllegalArgumentException;

    /**
     * Applies a binary function to the current matrix and a numeric input matrix.
     * 
     * @param input a matrix with identical dimensions
     * @param function a binary function
     * @return this f.apply(this, input)
     */
    
    abstract DoubleMatrix assign(DoubleMatrix input, DoubleDoubleFunction function, boolean overwrite) throws ArithmeticException, IllegalArgumentException;    
    
    /**
     * Applies a binary function to the current matrix and a numeric input matrix,
     * ignoring the specified value in the current matrix.  The result may be assigned 
     * to the current matrix.
     *
     * @param input a matrix with identical dimensions
     * @param function a binary function
     * @param overwrite is true to assign the result to the current matrix, false for a deep copy
     * @param avoid a number to avoid
     * @return this f.apply(this, input)
     */
    
    abstract DoubleMatrix assign(DoubleMatrix input, DoubleDoubleFunction function, boolean overwrite, double avoid) throws ArithmeticException, IllegalArgumentException;
    
}
