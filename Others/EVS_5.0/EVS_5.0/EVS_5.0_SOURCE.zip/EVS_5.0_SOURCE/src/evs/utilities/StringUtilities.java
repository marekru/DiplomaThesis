package evs.utilities;

//Java dependencies
import java.io.*;
import java.util.*;
import java.text.*;

//EVS dependencies
import evs.utilities.matrix.*;

/** 
 * Collection of static methods for manipulating strings.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class StringUtilities {

/*******************************************************************************
 *                                                                             *
 *                               CLASS VARIABLES                               *
 *                                                                             *
 ******************************************************************************/    
    
    /**
     * Default date format.
     */

    public static final String DEFAULT_DATE_FORMAT = "MM/dd/yyyy HH";  
    //public static final String DEFAULT_DATE_FORMAT = "yyyyMMddHH";  

    /**
     * Simple date format.
     */
        
    private static ThreadSafeSimpleDateFormat simple = null;
    
    /**
     * Format used for reading dates.
     */
    
    private static String format = null;
    
    /**
     * Format used for writing dates.
     */
    
    private static ThreadSafeSimpleDateFormat writeDateFormat = 
            new ThreadSafeSimpleDateFormat("yyyyMMdd",false);    

    /**
     * Array of accepted date formats.  Date formats must use a constant separator.
     * The separator must be one of: .-/+ or no space
     */
    
    private static final String[] DATE_FORMATS = new String[] {
        "yyyy.MM.dd.HH",
        "yyyy.MM.dd",
        "dd.MM.yyyy.HH",
        "dd.MM.yyyy",
        "yyyyMMddHH",
        "yyyyMMdd",
        "ddMMyyyyHH",
        "HHddMMyyyy",        
        "ddMMyyyy",        
        "yyyy-MM-dd-HH",
        "yyyy-MM-dd",
        "dd-MM-yyyy-HH",
        "dd-MM-yyyy",
        "MM/dd/yyyy/HH",
        "MM/dd/yyyy HH",
        "MM/dd/yyyy",
        "dd/MM/yyyy/HH",
        "dd/MM/yyyy",
        "yyyy.MM",
        "yyyyMM",
        "yyyy-MM",
        "yyyy/MM",
        "yyyy"
    };    
    
/*******************************************************************************
 *                                                                             *
 *                               ACCESSOR METHODS                              *
 *                                                                             *
 ******************************************************************************/    
        
    /**
     * Returns an absolute path for the specified relative path, eliminating 
     * problems with white spaces (%20) in Java for windows and safe for 
     * reference to resources with JAR archives.
     *
     * @param relativePath the relative path
     * @return the correct absolute path
     */
    
    public static String getAbsolutePath(String relativePath) throws IllegalArgumentException {
        try {
            String rp = relativePath;
            if(relativePath.startsWith("/")) {
                rp = relativePath.substring(1,relativePath.length());
            }
            else {
                relativePath = "/"+relativePath;
            }
            java.net.URL or = StringUtilities.class.getResource(relativePath);
            String temp = or.getPath();
            temp = temp.substring(0,temp.indexOf("/evs"));
            if(temp.indexOf("jar!") > -1) {
                temp = temp.substring(0,temp.lastIndexOf("/")+1);
            }
            else {
                temp = temp+"/";
            }
            if(temp.startsWith("file:/")) {
                temp = temp.substring(6);
            }
            else {
                temp = temp.substring(1);
            }
            temp = temp+rp;
            temp = temp.replaceAll("%20"," ");
            temp = temp.replace('/', java.io.File.separatorChar);
            return temp;
        }
        //File does not exist
        catch(NullPointerException e) {
            throw new IllegalArgumentException("File '"+relativePath+"' does not exist"); 
        }        
    }    
    
    /**
     * Returns true if both inputs are null or both inputs are not null and equal,
     * false otherwise.
     * 
     * @param first the first string
     * @param second the second string
     * @param emptyAsNull is true to treat empty strings as null, false otherwise
     * @return true if both inputs are null or both inputs are not null and equal, false otherwise
     */
    
    public static boolean nullEquals(String first, String second, boolean emptyAsNull) {
        String f = first;
        String s = second;
        if(emptyAsNull) {
            if("".equals(f)) {
                f=null;
            }
            if("".equals(s)) {
                s=null;
            }
        }
        if(f == null && s == null) {  //Both are null
            return true;
        }
        if((f == null) != (s == null)) {  //One is null
            return false;
        }
        return f.equals(s);  //Neither are null
    }
    
    /**
     * Processes an input path, stripping %20 on Windows.
     *
     * @param path the input path
     * @return the processed path
     */
    
    public static String processPath(String path) {
        String returnMe = path;
        returnMe = returnMe.replaceAll("%20"," ");
        return returnMe;
    }
    
    /**
     * Processes an input path, stripping %20 on Windows and JAR related additions.
     *
     * @param path the input path
     * @return the processed path
     */
    
    public static String processJARPath(String path) {
        String returnMe = path;
        returnMe = returnMe.replaceAll("%20"," ");
        returnMe = returnMe.replaceFirst("jar:file:/","");
        returnMe = returnMe.replaceFirst("EVS.jar!","nonsrc");
//@JB 15th OCtober 2012        
//        int index = returnMe.indexOf(".jar!");
//        int breakIndex = 0;
//        for(int i = index; i > -1; i--) {
//            if(returnMe.charAt(i)=='/') {
//                breakIndex = i;
//                break;
//            }
//        }
//        returnMe = returnMe.substring(0,breakIndex);
//        returnMe = returnMe + path.substring(path.indexOf(EVSConstants.EVS_NONSRC_DIR),path.length());
        return returnMe;
    }    
    
    /**
     * Processes an input string so that it comprises a legal file name on any OS.
     * All blanks and '.' characters are replaced with underscore '_' characters.
     * 
     * @param input the input name
     * @return the valid file name
     */
    
    public static String processFileName(String input) {
        String s = input+"";
        s = s.replaceAll("\\.","_");
        return removeWhiteSpace(s,"_");
    }
    
    /**
     * Cleans a path to remove all backslashes and replace with the System.getProperty("file.separator")
     * 
     * @param path the input path
     */
    
    public static String cleanPath(String path) {
    	String sep = System.getProperty("file.separator");
    	char last='.';
    	int length = path.length();
    	StringBuffer b = new StringBuffer();
        for(int i = 0; i < length; i++) {
    		char next = path.charAt(i);
    		if(next=='\\') {
    			if(last!='\\') {
    				b.append(sep);
    			}
    		} else if(next=='/') {
    			if(last!='/') {
    				b.append(sep);
    			}
    		} 
    		else {
    			b.append(next);
    		}
    		last = next;
    	}
    	return b.toString();
    }
    
    /**
     * Parses a string with a specified date format to an instance of Calendar.
     * The parser will interpret the input token using the specified date format.
     * The parser may adopt a lenient or non-lenient interpretation of the token
     * using the input date format. See 
     * {@link java.text.DateFormat#parse(java.lang.String, java.text.ParsePosition)}.
     *
     * @param token the date 
     * @param timeZone the timeZone
     * @param lenient is true to conduct lenient parsing, false otherwise
     * @return an instance of Calendar or null if the date was not parsed
     */
    
    public static Calendar parseDate(String token,String format,TimeZone timeZone,boolean lenient) throws DateFormatException {
        if(token==null||format==null||timeZone==null) {
            throw new DateFormatException("Cannot process date with null entries: enter a valid token, format and time zone.");
        }
//        if(token.length()!=format.length()) {
//            throw new DateFormatException("Cannot process date: input token has different length than format string ["+token+","+format+"].");
//        }
        Calendar date = null;
        ParsePosition pos = new ParsePosition(0);
        try {
            ThreadSafeSimpleDateFormat simple = new ThreadSafeSimpleDateFormat(format, lenient);
            simple.setTimeZone(timeZone);
            Date next = simple.parse(token, pos);
            if (next != null) {
                date = Calendar.getInstance(timeZone);
                date.clear();
                date.setTime(next);
                return date;
            }
            return date;
        } catch(Exception e) {
            if(e instanceof IllegalArgumentException) {
                throw new DateFormatException("Unrecognized date format '"+format+"'.");
            } else {
                throw new IllegalArgumentException(e.getMessage());
            }
        }
    }

    /**
     * Parses an object representing a time and returns a string.  If the object is 
     * an instance of Calendar, the default date format is used.  Set the default 
     * format with setDateString().
     *
     * @param time the date 
     * @return a string representation of the time
     */
    
    public static String parseDate(Object time) {
        if(time instanceof Calendar) {
            writeDateFormat.setTimeZone(((Calendar)time).getTimeZone());
            return writeDateFormat.format(((Calendar)time).getTime());
        }
        return time.toString();  
    }

    /**
     * Parses a Calendar representing a time and returns a string.
     *
     * @param time the date
     * @param format the format
     * @return a string representation of the time
     */

    public static String parseDate(Calendar time,String format) {
        SimpleDateFormat f = new SimpleDateFormat(format);
        f.setTimeZone(time.getTimeZone());
        return f.format(((Calendar)time).getTime());
    }

    /**
     * Returns a string representation of the stack trace for an error or 
     * exception.
     *
     * @param ex the throwable item
     * @return the stack trace
     */
    
    public static String stackTraceToString(Throwable ex) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        PrintWriter writer = new PrintWriter(bytes, true);
        ex.printStackTrace(writer);
        return bytes.toString();
    }    
    
    /**
     * Pretty prints a double matrix with hours relative to the epoch in the 
     * specified column. The output is printed to standard out and uses real dates 
     * in the format specified by {@link #writeDateFormat} in this class.
     * The remaining columns are printed as normal.  The time system of the output
     * is UTC.
     * 
     * @param column the column containing times in hours relative to the epoch
     * @param input the input matrix
     */
    
    public static void printWithDates(int column, DoubleMatrix2D input) throws IllegalArgumentException {
        if(column < 0 || column >= input.getColumnCount()) {
            throw new IllegalArgumentException("Invalid column specified for dates.");
        }
        int rows = input.getRowCount();
        int cols = input.getColumnCount();
        Calendar d = Calendar.getInstance();
        d.clear();
        d.setTimeZone(TimeZone.getTimeZone("UTC"));
        for(int i = 0; i < rows; i++) {
            StringBuffer append = new StringBuffer();
            long val = (long)(input.get(i,column)*60*60*1000);
            d.clear();
            d.setTimeInMillis(val);
            for(int j = 0; j < cols; j++) {
                if(j==column) {
                    append.append("\t"+parseDate(d));
                }
                else {
                    append.append("\t"+input.get(i,j)); 
                }
            }
            System.out.println(append);           
        }
    }
    
    /**
     * Returns a string representation of the number with a given number of digits
     * padding on the left.
     * 
     * @param n the number
     * @param count the digit count on the left 
     */
    
    public static String getPaddedNumber(double n, int count) {
        String left = ((int)Math.abs(n))+"";
        String en = Math.abs(((int)n)-n)+"";
        en = en.substring(1,en.length());

        int ln = en.length();       
        //remove trailing zeros from end
        int tot = ln;
        for (int i = (ln - 1); i > 1; i--) {  //Leave last zero
            if (en.charAt(i) == '0') {
                tot--;
            } else {
                break;
            }
        }
        en = en.substring(0, tot);

        StringBuffer s = new StringBuffer();
        for(int i = 0; i < count; i++) {
            s.append("0");
        }
        left=s.toString()+left;
        if(n<0) {
            left = "-"+left;
        }
        return left+""+en;
    }
    
    /**
     * Returns the index of an input string in the specified array or -1.
     * 
     * @param input the input array
     * @param test the string to test
     * @return the index of the test string in the input or -1
     */
    
    public static int indexOf(String[] input, String test) {
        int ind = -1;
        if(input != null) {
            for(int i = 0; i < input.length; i++) {
                if(input[i].equals(test)) {
                    return i; 
                }
            }
        }
        return ind;
    } 

    /**
     * Checks the input date format and throws an exception if the format is
     * unsupported.
     *
     * @param dateFormat the date format
     */
    
    public static void checkDateFormat(String dateFormat) throws IllegalArgumentException {
        if(dateFormat==null) {
            throw new IllegalArgumentException("Enter a non-null date format.");
        }
        for (int i = 0; i < DATE_FORMATS.length; i++) {
            if (dateFormat.equals(DATE_FORMATS[i])) {
                return;
            }
        }
        throw new IllegalArgumentException("Unsupported date format: "+dateFormat);
    }
    
     /**
     * Checks for a recognized date format and returns true if the format was
     * recognized. 
     *
     * @param dateFormat the date format
     * @return true for a known date format, false otherwise 
     */
    
    public static boolean isCheckDateFormat(String dateFormat) throws IllegalArgumentException {
        try {
            checkDateFormat(dateFormat);
            return true;
        } catch(IllegalArgumentException e) {
            return false;
        }
    }   

/*******************************************************************************
 *                                                                             *
 *                                MUTATOR METHODS                              *
 *                                                                             *
 ******************************************************************************/    
    
    /**
     * Removes white spaces in a string and replaces them with the specified 
     * string.
     *
     * @param input the input string
     * @param replace the replacement string for white space
     * @return a string with no white spaces
     */
    
    public static String removeWhiteSpace(String input, String replace) throws IllegalArgumentException {
        if(input == null) {
            throw new IllegalArgumentException("Non-null input string expected."); 
        }
        StringTokenizer t = new StringTokenizer(input,", \t\n\r\f",true);
        StringBuffer nxt = new StringBuffer();
        while(t.hasMoreElements()) {
            String n = t.nextToken();
            if(n.equals(" ") || n.equals("\t") || n.equals("\n") || n.equals("\r") || n.equals("\f")) {
                if(! nxt.toString().endsWith(replace)) {
                    nxt.append(replace);
                }
            }
            else {
                nxt.append(n);
            }
        } 
        return nxt.toString();
    }

    /**
     * Sets the date string for writing.
     *
     * @param format the date format 
     */
    
    public static void setDateString(String format) throws IllegalArgumentException {
        //checkDateFormat(format);
        writeDateFormat = new ThreadSafeSimpleDateFormat(format,false);
    }
    

}