package evs.utilities.matrix;
 
/**
 * Abstract base class for a 2D boolean matrix.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public abstract class BooleanMatrix2D extends Matrix2D implements BooleanMatrix {
    
    /*******************************************************************************
     *                                                                             *
     *                  ABSTRACT METHODS TO OVERRIDE IN A SUBCLASS                 *
     *                                                                             *
     ******************************************************************************/
    /**
     * Used to set the element value with internal coordinates.
     *
     * @param a row index
     * @param b column index
     * @param value the value
     */
    
    public abstract void set(int a, int b, boolean value);

    /**
     * Returns the element value for the given internal row-column coordinates.
     *
     * @param a row index
     * @param b column index
     * @return element (a,b)
     */
    
    public abstract boolean get(int a, int b) throws IndexOutOfBoundsException;
        
    /**
     * Returns an array of elements.
     *
     * @return the data array
     */
    
    public abstract boolean[][] toArray();
    
    /**
     * Returns a transpose view of the current matrix.
     *
     * @return a transpose of the current matrix.
     */
    
    public abstract BooleanMatrix2D transpose();
    
    /*******************************************************************************
     *                                                                             *
     *                              CONCRETE METHODS                               *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Returns a string representation of the matrix.  
     *
     * @return a string representation of the matrix.
     */
    
    public String toString() {
        StringBuffer s = new StringBuffer();
        for(int  i = 0; i < nRows; i++) {       
            if (i==0) {
                s.append("\t");
                for (int p=0; p < nColumns; p++) {
                    s.append("["+p+"]"+"\t");
                }
            }
            s.append(System.getProperty("line.separator")+"["+i+"]"+"\t");
            for(int j = 0; j < nColumns; j++) {       
                s.append(get(i,j)+"\t");
            }
        } 
        return s.toString();
    }
}