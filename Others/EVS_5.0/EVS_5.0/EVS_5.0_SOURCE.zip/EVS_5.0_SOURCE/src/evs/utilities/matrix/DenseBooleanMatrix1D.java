package evs.utilities.matrix;

/**
 * A dense 1D matrix of boolean values.  
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DenseBooleanMatrix1D extends BooleanMatrix1D {
    
    /**
     * Store the matrix values
     */
    
    private boolean[] matrixValues = null;
    
    /*******************************************************************************
     *                                                                             *
     *                                CONSTRUCTORS                                 *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Construct a regular matrix.
     *
     * @param rows the number of rows in the dense matrix
     */
    
    public DenseBooleanMatrix1D(int rows) throws IllegalArgumentException {
        if(rows <= 0) {
            throw new IllegalArgumentException("Error: numbers of rows must exceed 0.");
        }
        nRows = rows;
        matrixValues = new boolean[rows];
    }
    
    /**
     * Construct a regular dense matrix with an array of values.  
     *
     * @param matrixValues an array of values
     */
    
    public DenseBooleanMatrix1D(boolean[] matrixValues) throws IllegalArgumentException {
        if(matrixValues == null) {
            throw new IllegalArgumentException("Specify non-null input for the matrix values.");
        }
        nRows = matrixValues.length;
        this.matrixValues = matrixValues;
    }
    
    /*******************************************************************************
     *                                                                             *
     *                            ACCESSOR METHODS                                 *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Returns a deep copy of the current matrix.  Changes in one matrix are not reflected
     * in the other matrix.
     *
     * @return a deep copy of the current matrix.
     */
    
    public Matrix deepCopy() {
        //Create an empty matrix
        DenseBooleanMatrix1D newDenseMatrix = new DenseBooleanMatrix1D(nRows);        
        for (int i = 0; i < nRows; i++) {
            newDenseMatrix.matrixValues[i] = matrixValues[i];
        }
        newDenseMatrix.nRows = nRows;
        return newDenseMatrix;
    }
    
   /**
     * Returns a deep copy of the current matrix in 2D form with a specified 
     * number of rows.  The matrix is filled row-wise from the top left corner.
     *
     * @param rowCount the number of rows
     * @return a deep copy in 2D form. 
     */
    
    public Matrix2D to2D(int rowCount) throws IllegalArgumentException {
        if(rowCount < 1 || rowCount > nRows) {
            throw new IllegalArgumentException("The row count must be greater than 1 and less than the number of cells in the 1D matrix ["+rowCount+"].");
        }
        int colCount = (int)java.lang.Math.ceil(((double)nRows)/(double)rowCount);
        DenseBooleanMatrix2D data = new DenseBooleanMatrix2D(rowCount,colCount);
        int total = 0;
        for(int i = 0; i < rowCount; i++) {
            for(int j = 0; j < colCount; j++) {
                data.set(i,j, matrixValues[total]);
                total++;
            }
        }
        return data;
    }    
    
    /**
     * Returns the array elements.
     *
     * @return the data array
     */
    
    public boolean[] toArray() {
        return matrixValues;
    }
    
    /**
     * Returns the element value for the given internal row coordinate.
     *
     * @param a row index
     * @return element (a)
     */
    
    public boolean get(int a) throws IndexOutOfBoundsException {
        return matrixValues[a];
    }        
    
    /**
     * Returns a subset of the current matrix between (and including) the two rows.
     *
     * @param startRow the start row
     * @param endRow the end row
     * @return a subset of the current matrix by row
     */
    
    public Matrix1D getSubmatrixByRow(int startRow, int endRow) throws IllegalArgumentException {
        if(startRow < 0 || endRow >= nRows || endRow < startRow) {
            throw new IllegalArgumentException("Invalid submatrix requested.");
        }
        if(startRow == 0 && endRow == nRows-1) {
            return this;
        }
        boolean[] r = new boolean[endRow-startRow+1];
        System.arraycopy(matrixValues,startRow,r,0,r.length);
        return new DenseBooleanMatrix1D(r);
    }    
    
    /*******************************************************************************
     *                                                                             *
     *                            MUTATOR METHODS                                  *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Used to set the element value with internal row-column coordinates.
     *
     * @param a row index
     * @param value the value to enter
     */
    
    public void set(int a, boolean value) throws IndexOutOfBoundsException {
        matrixValues[a] = value;
    }

    /**
     * Returns the transpose of the current matrix as a new matrix object.
     *
     * @return the transpose of the current matrix.
     */
    
    public BooleanMatrix1D transpose() {
        
        //Create a dummy matrix for copying
        DenseBooleanMatrix1D newTranspose = new DenseBooleanMatrix1D(nRows);

        //Add the transposed values to the new matrix
        for (int i = 0; i < nRows; i++) {
            newTranspose.matrixValues[i] = matrixValues[(nRows-1)-i];
        }
        newTranspose.nRows=nRows;
        return newTranspose;
    }

    /**
     * Returns the matrix values.
     *
     * @return the matrix values
     */
    
    public Object getMatrixValues() {
        return matrixValues;
    }
    
    /*******************************************************************************
     *                                                                             *
     *                             MUTATOR METHODS                                 *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Sets the matrix values as a java array of primitives or throws an exception
     * if the object is incorrect.
     *
     * @param matrixValues the matrix values
     */
    
    public void setMatrixValues(Object matrixValues) throws IllegalArgumentException {
        if(!(matrixValues instanceof boolean[])) {
            throw new IllegalArgumentException("One dimensional array of booleans expected.");
        }
        boolean[] vals = (boolean[])matrixValues;
        if(vals.length != nRows) {
            throw new IllegalArgumentException("Incorrect number of rows: ["+nRows+": "+vals.length+"].");
        }
        this.matrixValues = vals;       
    }    
    
    /** 
     * Sets the matrix values to null (i.e. an empty matrix).
     */
    
    public void clearValues() {
        matrixValues = new boolean[matrixValues.length];
    }        
    
    /**
     * Takes an input matrix and conflates with the current matrix, returning
     * either a copy or overwriting the existing matrix. Returns true for each
     * index whose current and input values are true, false otherwise.
     * 
     * @param input the input matrix
     * @param deepCopy is true to return the conflation in a copy
     * @return the conflated matrix
     * @throws ArrayIndexOutOfBoundsException if the dimensions of the current and input matrix are inconsistent
     */
    
    public BooleanMatrix conflate(BooleanMatrix input, boolean deepCopy) throws ArrayIndexOutOfBoundsException {
        if(!(input instanceof BooleanMatrix1D) || 
                ((BooleanMatrix1D)input).getRowCount()!=nRows) {
            throw new ArrayIndexOutOfBoundsException("Requires a BooleanMatrix1D with '"+nRows+"' rows as input ["
                    +((BooleanMatrix1D)input).getRowCount()+"].");
        }
        BooleanMatrix1D returnMe = this;
        BooleanMatrix1D in = (BooleanMatrix1D)input;
        if(deepCopy) {
            returnMe = new DenseBooleanMatrix1D(nRows);
        }
        for(int i = 0; i < nRows; i++) {
            returnMe.set(i,get(i)&&in.get(i));
        }
        return returnMe;
    }
        
    
}

