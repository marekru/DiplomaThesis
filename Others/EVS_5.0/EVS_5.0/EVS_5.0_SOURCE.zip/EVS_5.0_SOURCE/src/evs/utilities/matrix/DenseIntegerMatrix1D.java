package evs.utilities.matrix;

/**
 * A dense 1D matrix of integer values.  
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DenseIntegerMatrix1D extends IntegerMatrix1D {
    
    /**
     * Store the matrix values 
     */
    
    private int[] matrixValues = null;
    
    /*******************************************************************************
     *                                                                             *
     *                                CONSTRUCTORS                                 *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Construct a regular matrix.
     *
     * @param rows the number of rows in the dense matrix
     */
    
    public DenseIntegerMatrix1D(int rows) throws IllegalArgumentException {
        if(rows <= 0) {
            throw new IllegalArgumentException("Error: numbers of rows must exceed 0.");
        }
        nRows = rows;
        matrixValues = new int[rows];
    }
    
    /**
     * Construct a regular dense matrix with an array of values.  
     *
     * @param matrixValues an array of values
     */
    
    public DenseIntegerMatrix1D(int[] matrixValues) throws IllegalArgumentException {
        if(matrixValues == null) {
            throw new IllegalArgumentException("Specify non-null input for the matrix values.");
        }
        nRows = matrixValues.length;
        this.matrixValues = matrixValues;
    }
    
    /*******************************************************************************
     *                                                                             *
     *                            ACCESSOR METHODS                                 *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Returns a deep copy of the current matrix.  Changes in one matrix are not reflected
     * in the other matrix.
     *
     * @return a deep copy of the current matrix.
     */
    
    public Matrix deepCopy() {
        //Create an empty matrix
        DenseIntegerMatrix1D newDenseMatrix = new DenseIntegerMatrix1D(nRows);        
        for (int i = 0; i < nRows; i++) {
            newDenseMatrix.matrixValues[i] = matrixValues[i];
        }
        newDenseMatrix.nRows = nRows;
        return newDenseMatrix;
    }
    
   /**
     * Returns a deep copy of the current matrix in 2D form with a specified 
     * number of rows.  The matrix is filled row-wise from the top left corner.
     *
     * @param rowCount the number of rows
     * @return a deep copy in 2D form. 
     */
    
    public Matrix2D to2D(int rowCount) throws IllegalArgumentException {
        if(rowCount < 1 || rowCount > nRows) {
            throw new IllegalArgumentException("The row count must be greater than 1 and less than the number of cells in the 1D matrix ["+rowCount+"].");
        }
        int colCount = (int)java.lang.Math.ceil(((double)nRows)/(double)rowCount);
        DenseIntegerMatrix2D data = new DenseIntegerMatrix2D(rowCount,colCount);
        int total = 0;
        for(int i = 0; i < rowCount; i++) {
            for(int j = 0; j < colCount; j++) {
                data.set(i,j, matrixValues[total]);
                total++;
            }
        }
        return data;
    }    
    
    /**
     * Returns the array elements.
     *
     * @return the data array
     */
    
    public int[] toArray() throws OutOfMemoryError {
        return matrixValues;
    }
    
    /**
     * Returns the element value for the given internal row coordinate.
     *
     * @param a row index
     * @return element (a)
     */
    
    public int get(int a) throws IndexOutOfBoundsException {
        return matrixValues[a];
    }        
    
    /**
     * Returns a subset of the current matrix between (and including) the two rows.
     *
     * @param startRow the start row
     * @param endRow the end row
     * @return a subset of the current matrix by row
     */
    
    public Matrix1D getSubmatrixByRow(int startRow, int endRow) throws IllegalArgumentException {
        if(startRow < 0 || endRow >= nRows || endRow < startRow) {
            throw new IllegalArgumentException("Invalid submatrix requested.");
        }
        if(startRow == 0 && endRow == nRows-1) {
            return this;
        }
        int[] r = new int[endRow-startRow+1];
        System.arraycopy(matrixValues,startRow,r,0,r.length);
        return new DenseIntegerMatrix1D(r);
    }    
    
    /*******************************************************************************
     *                                                                             *
     *                            MUTATOR METHODS                                  *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Used to set the element value with internal row-column coordinates.
     *
     * @param a row index
     * @param value the value to enter
     */
    
    public void set(int a, int value) throws IndexOutOfBoundsException {
        matrixValues[a] = value;
    }

    /**
     * Returns the transpose of the current matrix as a new matrix object.
     *
     * @return the transpose of the current matrix.
     */
    
    public IntegerMatrix1D transpose() {
        
        //Create a dummy matrix for copying
        DenseIntegerMatrix1D newTranspose = new DenseIntegerMatrix1D(nRows);

        //Add the transposed values to the new matrix
        for (int i = 0; i < nRows; i++) {
            newTranspose.matrixValues[i] = matrixValues[(nRows-1)-i];
        }
        newTranspose.nRows=nRows;
        return newTranspose;
    }

    /**
     * Returns the matrix values.
     *
     * @return the matrix values
     */
    
    public Object getMatrixValues() {
        return matrixValues;
    }
    
    /*******************************************************************************
     *                                                                             *
     *                             MUTATOR METHODS                                 *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Sets the matrix values as a java array of primitives or throws an exception
     * if the object is incorrect.
     *
     * @param matrixValues the matrix values
     */
    
    public void setMatrixValues(Object matrixValues) throws IllegalArgumentException {
        if(!(matrixValues instanceof int[])) {
            throw new IllegalArgumentException("One dimensional array of integers expected.");
        }
        int[] vals = (int[])matrixValues;
        if(vals.length != nRows) {
            throw new IllegalArgumentException("Incorrect number of rows: ["+nRows+": "+vals.length+"].");
        }
        this.matrixValues = vals;       
    }    
    
    /** 
     * Sets the matrix values to null (i.e. an empty matrix).
     */
    
    public void clearValues() {
        matrixValues = new int[matrixValues.length];
    }        
    
}

