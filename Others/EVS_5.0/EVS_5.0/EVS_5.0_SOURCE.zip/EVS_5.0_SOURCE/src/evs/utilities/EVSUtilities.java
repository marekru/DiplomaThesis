package evs.utilities;

import java.util.ArrayList;
import ohd.hseb.util.fews.OHDConfigurationInfoReader;
import ohd.hseb.util.fews.OHDConstants;

/**
 * A class doing various house keeping jobs in EVS
 */
public class EVSUtilities {

    /**
     * Get version information from the xml file {@link EVSConstants#EVS_CONFIG_FILE}.
     */
    public static String getVersionInfo() {

        final StringBuilder strBuilder = new StringBuilder();

        try {
            //Get version information from xml file
            final OHDConfigurationInfoReader config = new OHDConfigurationInfoReader(OHDConstants.DUMMY_LOG,
                    EVSConstants.EVS_CONFIG_FILE);

            strBuilder.append("EVS version: " + config.getVersionControl().getVersion() + ", "
                    + config.getVersionControl().getDate()).append(OHDConstants.NEW_LINE);
            strBuilder.append("OHD Core version: " + config.getVersionControl().getOHDCoreVersion()).append(OHDConstants.NEW_LINE);
            strBuilder.append("FEWS version: " + config.getVersionControl().getFewsVersion()).append(OHDConstants.NEW_LINE);
        } catch (final Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        return strBuilder.toString();
    }

    /**
     * Converts the input list of doubles to a primitive double array.
     * 
     * @param input the input list
     * @return a primitive array of doubles
     */
    
    public static double[] toDoubleArray(ArrayList<Double> input) {
        int rows = input.size();
        double[] d = new double[rows];
        for(int i = 0; i < rows; i++) {
            d[i]=input.get(i);
        }
        return d;
    }    
    
    /**
     * Converts the input list of doubles to a primitive double array.
     * 
     * @param input the input list
     * @return a primitive array of doubles
     */
    
    public static ArrayList<Double> toArrayList(double[] input) {
        int rows = input.length;
        ArrayList<Double> d = new ArrayList<Double>();
        for(int i = 0; i < rows; i++) {
            d.add(input[i]);
        }
        return d;
    }      

}
