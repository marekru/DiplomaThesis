package evs.utilities.matrix;

/**
 * An abstract base class for 2D matrices.  When constructing a subclass with a
 * Java array, the subclasses do not currently require the input array to contain
 * a constant number of columns, but great care should be taken when constructing a
 * subclass in this way, as some of the methods will fail with an ArrayIndexOutOfBoundsException
 * if a non-existing index is referenced in the original Java array. 
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public abstract class Matrix2D extends Matrix {  
    
    /**
     * Number of rows in the matrix.
     */
    
    protected int nRows = 0;
    
    /**
     * Number of columns in the matrix.
     */
    
    protected int nColumns = 0;
    
/*******************************************************************************
 *                                                                             *
 *                            ACCESSOR METHODS                                 *
 *                                                                             *
 ******************************************************************************/           

    /**
     * Returns true if the input matrix has equivalent dimensions to this matrix.
     *
     * @param matrix the matrix for comparison
     * @return true if the matrices have equivalent dimensions
     */   
    
    public boolean hasEquivalentDimensions(Matrix matrix) {        
        if(! (matrix instanceof Matrix2D) ) {
            return false;
        }
        return ((Matrix2D)matrix).getRowCount() == nRows && ((Matrix2D)matrix).getColumnCount() == nColumns;
    }                

    /**
     * Returns the number of rows in the matrix.  
     *
     * @return number of rows
     */
    
    public int getRowCount() {
        return nRows;
    }
    
    /**
     * Returns the number of columns in the matrix.
     *
     * @return number of columns
     */
    
    public int getColumnCount() {
        return nColumns;
    }
    
    /**
     * Return the number of elements in the matrix domain.
     *
     * @return number of elements
     */
    
    public int getElementCount() {
        return nRows*nColumns;
    }

    /**
     * Returns the specified row from the matrix.
     *
     * @param row the row index
     * @return the row
     */
    
    public abstract Matrix1D getRowAt(int row) throws ArrayIndexOutOfBoundsException;

    /**
     * Returns the specified column from the matrix.
     *
     * @param column the column index
     * @return the column
     */
    
    public abstract Matrix1D getColumnAt(int column) throws ArrayIndexOutOfBoundsException;    
    
    /**
     * Returns a subset of the current matrix between (and including) the two rows.
     *
     * @param startRow the start row
     * @param endRow the end row
     * @return a subset of the current matrix by row
     */
    
    public abstract Matrix2D getSubmatrixByRow(int startRow, int endRow) throws IllegalArgumentException;
    
    /**
     * Returns a subset of the current matrix between (and including) the two columns.
     *
     * @param startCol the start column
     * @param endCol the end column
     * @return a subset of the current matrix by column
     */
     
    public abstract Matrix2D getSubmatrixByColumn(int startCol, int endCol) throws IllegalArgumentException;

}
