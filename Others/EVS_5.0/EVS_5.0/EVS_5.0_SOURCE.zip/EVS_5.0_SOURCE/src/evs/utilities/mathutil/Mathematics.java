package evs.utilities.mathutil;
import java.math.BigDecimal;

/** 
 * Class for common mathematical operations.
 * The methods for binomial, gamma and beta functions are taken directly from
 * <A HREF="http://hoscheck.home.cern.ch/hoscheck/colt/"> CERN </A>.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class Mathematics {
    
    /**
     * Constants
     */
    
    private static final double MACHEP =  1.11022302462515654042E-16;
    private static final double MAXLOG =  7.09782712893383996732E2;
    private static final double MINLOG = -7.451332191019412076235E2;
    private static final double MAXGAM = 171.624376956302725;
    private static final double LOGPI  =  1.14472988584940017414;
    private static final double SQTPI  =  2.50662827463100050242E0;
    private static final double BIG = 4.503599627370496e15;
    private static final double BIGINV =  2.22044604925031308085e-16;
    private static final double EULER = 0.577215664901532860606512090082402431042;
    private static final double SQRTH  =  7.07106781186547524401E-1;

    // z! for a = 0, ..., 20
    
    private static final long[] LONG_FACTORIALS = {
        1L,
        1L,
        2L,
        6L,
        24L,
        120L,
        720L,
        5040L,
        40320L,
        362880L,
        3628800L,
        39916800L,
        479001600L,
        6227020800L,
        87178291200L,
        1307674368000L,
        20922789888000L,
        355687428096000L,
        6402373705728000L,
        121645100408832000L,
        2432902008176640000L
    };
    
    // z! for a = 21, ..., 170
    
    private static final double[] DOUBLE_FACTORIALS = {
        5.109094217170944E19,
        1.1240007277776077E21,
        2.585201673888498E22,
        6.204484017332394E23,
        1.5511210043330984E25,
        4.032914611266057E26,
        1.0888869450418352E28,
        3.048883446117138E29,
        8.841761993739701E30,
        2.652528598121911E32,
        8.222838654177924E33,
        2.6313083693369355E35,
        8.68331761881189E36,
        2.952327990396041E38,
        1.0333147966386144E40,
        3.719933267899013E41,
        1.3763753091226346E43,
        5.23022617466601E44,
        2.0397882081197447E46,
        8.15915283247898E47,
        3.34525266131638E49,
        1.4050061177528801E51,
        6.041526306337384E52,
        2.6582715747884495E54,
        1.196222208654802E56,
        5.502622159812089E57,
        2.5862324151116827E59,
        1.2413915592536068E61,
        6.082818640342679E62,
        3.0414093201713376E64,
        1.5511187532873816E66,
        8.06581751709439E67,
        4.274883284060024E69,
        2.308436973392413E71,
        1.2696403353658264E73,
        7.109985878048632E74,
        4.052691950487723E76,
        2.350561331282879E78,
        1.386831185456898E80,
        8.32098711274139E81,
        5.075802138772246E83,
        3.146997326038794E85,
        1.9826083154044396E87,
        1.2688693218588414E89,
        8.247650592082472E90,
        5.443449390774432E92,
        3.6471110918188705E94,
        2.48003554243683E96,
        1.7112245242814127E98,
        1.1978571669969892E100,
        8.504785885678624E101,
        6.123445837688612E103,
        4.470115461512686E105,
        3.307885441519387E107,
        2.4809140811395404E109,
        1.8854947016660506E111,
        1.451830920282859E113,
        1.1324281178206295E115,
        8.94618213078298E116,
        7.15694570462638E118,
        5.797126020747369E120,
        4.7536433370128435E122,
        3.94552396972066E124,
        3.314240134565354E126,
        2.8171041143805494E128,
        2.4227095383672744E130,
        2.107757298379527E132,
        1.854826422573984E134,
        1.6507955160908465E136,
        1.4857159644817605E138,
        1.3520015276784033E140,
        1.2438414054641305E142,
        1.156772507081641E144,
        1.0873661566567426E146,
        1.0329978488239061E148,
        9.916779348709491E149,
        9.619275968248216E151,
        9.426890448883248E153,
        9.332621544394415E155,
        9.332621544394418E157,
        9.42594775983836E159,
        9.614466715035125E161,
        9.902900716486178E163,
        1.0299016745145631E166,
        1.0813967582402912E168,
        1.1462805637347086E170,
        1.2265202031961373E172,
        1.324641819451829E174,
        1.4438595832024942E176,
        1.5882455415227423E178,
        1.7629525510902457E180,
        1.974506857221075E182,
        2.2311927486598138E184,
        2.543559733472186E186,
        2.925093693493014E188,
        3.393108684451899E190,
        3.96993716080872E192,
        4.6845258497542896E194,
        5.574585761207606E196,
        6.689502913449135E198,
        8.094298525273444E200,
        9.875044200833601E202,
        1.2146304367025332E205,
        1.506141741511141E207,
        1.882677176888926E209,
        2.3721732428800483E211,
        3.0126600184576624E213,
        3.856204823625808E215,
        4.974504222477287E217,
        6.466855489220473E219,
        8.471580690878813E221,
        1.1182486511960037E224,
        1.4872707060906847E226,
        1.99294274616152E228,
        2.690472707318049E230,
        3.6590428819525483E232,
        5.0128887482749884E234,
        6.917786472619482E236,
        9.615723196941089E238,
        1.3462012475717523E241,
        1.8981437590761713E243,
        2.6953641378881633E245,
        3.8543707171800694E247,
        5.550293832739308E249,
        8.047926057471989E251,
        1.1749972043909107E254,
        1.72724589045464E256,
        2.5563239178728637E258,
        3.8089226376305687E260,
        5.7133839564458575E262,
        8.627209774233244E264,
        1.3113358856834527E267,
        2.0063439050956838E269,
        3.0897696138473515E271,
        4.789142901463393E273,
        7.471062926282892E275,
        1.1729568794264134E278,
        1.8532718694937346E280,
        2.946702272495036E282,
        4.714723635992061E284,
        7.590705053947223E286,
        1.2296942187394494E289,
        2.0044015765453032E291,
        3.287218585534299E293,
        5.423910666131583E295,
        9.003691705778434E297,
        1.5036165148649983E300,
        2.5260757449731988E302,
        4.2690680090047056E304,
        7.257415615308004E306
    };
    
    // for method stirlingCorrection(...)
    private static final double[] STIRLING_CORRECTION =  {
        0.0,
        8.106146679532726e-02, 4.134069595540929e-02,
        2.767792568499834e-02, 2.079067210376509e-02,
        1.664469118982119e-02, 1.387612882307075e-02,
        1.189670994589177e-02, 1.041126526197209e-02,
        9.255462182712733e-03, 8.330563433362871e-03,
        7.573675487951841e-03, 6.942840107209530e-03,
        6.408994188004207e-03, 5.951370112758848e-03,
        5.554733551962801e-03, 5.207655919609640e-03,
        4.901395948434738e-03, 4.629153749334029e-03,
        4.385560249232324e-03, 4.166319691996922e-03,
        3.967954218640860e-03, 3.787618068444430e-03,
        3.622960224683090e-03, 3.472021382978770e-03,
        3.333155636728090e-03, 3.204970228055040e-03,
        3.086278682608780e-03, 2.976063983550410e-03,
        2.873449362352470e-03, 2.777674929752690e-03,
    };
    
    // for method logFactorial(...)
    // log(k!) for k = 0, ..., 29
    private static final double[] LOG_FACTORIALS = {
        0.00000000000000000, 0.00000000000000000, 0.69314718055994531,
        1.79175946922805500, 3.17805383034794562, 4.78749174278204599,
        6.57925121201010100, 8.52516136106541430, 10.60460290274525023,
        12.80182748008146961, 15.10441257307551530, 17.50230784587388584,
        19.98721449566188615, 22.55216385312342289, 25.19122118273868150,
        27.89927138384089157, 30.67186010608067280, 33.50507345013688888,
        36.39544520803305358, 39.33988418719949404, 42.33561646075348503,
        45.38013889847690803, 48.47118135183522388, 51.60667556776437357,
        54.78472939811231919, 58.00360522298051994, 61.26170176100200198,
        64.55753862700633106, 67.88974313718153498, 71.25703896716800901
    };
    /*************************************************
     *    COEFFICIENTS FOR METHOD  normalInverse()   *
     *************************************************/
    /* approximation for 0 <= |y - 0.5| <= 3/8 */
    private static final double[] P0 = {
        -5.99633501014107895267E1,
        9.80010754185999661536E1,
        -5.66762857469070293439E1,
        1.39312609387279679503E1,
        -1.23916583867381258016E0,};
    private static final double[] Q0 = {
        /* 1.00000000000000000000E0,*/
        1.95448858338141759834E0,
        4.67627912898881538453E0,
        8.63602421390890590575E1,
        -2.25462687854119370527E2,
        2.00260212380060660359E2,
        -8.20372256168333339912E1,
        1.59056225126211695515E1,
        -1.18331621121330003142E0,};
    /* Approximation for interval z = sqrt(-2 log y ) between 2 and 8
     * i.e., y between exp(-2) = .135 and exp(-32) = 1.27e-14.
     */
    private static final double[] P1 = {
        4.05544892305962419923E0,
        3.15251094599893866154E1,
        5.71628192246421288162E1,
        4.40805073893200834700E1,
        1.46849561928858024014E1,
        2.18663306850790267539E0,
        -1.40256079171354495875E-1,
        -3.50424626827848203418E-2,
        -8.57456785154685413611E-4,};
    private static final double[] Q1 = {
        /*  1.00000000000000000000E0,*/
        1.57799883256466749731E1,
        4.53907635128879210584E1,
        4.13172038254672030440E1,
        1.50425385692907503408E1,
        2.50464946208309415979E0,
        -1.42182922854787788574E-1,
        -3.80806407691578277194E-2,
        -9.33259480895457427372E-4,};

    /* Approximation for interval z = sqrt(-2 log y ) between 8 and 64
     * i.e., y between exp(-32) = 1.27e-14 and exp(-2048) = 3.67e-890.
     */
    private static final double[] P2 = {
        3.23774891776946035970E0,
        6.91522889068984211695E0,
        3.93881025292474443415E0,
        1.33303460815807542389E0,
        2.01485389549179081538E-1,
        1.23716634817820021358E-2,
        3.01581553508235416007E-4,
        2.65806974686737550832E-6,
        6.23974539184983293730E-9,};
    private static final double[] Q2 = {
        /*  1.00000000000000000000E0,*/
        6.02427039364742014255E0,
        3.67983563856160859403E0,
        1.37702099489081330271E0,
        2.16236993594496635890E-1,
        1.34204006088543189037E-2,
        3.28014464682127739104E-4,
        2.89247864745380683936E-6,
        6.79019408009981274425E-9,};

    /**
     * Rounds the given input to a specified number of decimal places (useful for
     * removing floating point errors). Uses the java.math.BigDecimal class
     * with the BigDecimal.ROUND_HALF_UP technique. Constructs the BigDecimal
     * object with a string, input+"".
     *
     * @param input the double to round
     * @param n the number of decimal places
     * @return a number rounded to n decimal places
     */
    
    public static double round(double input, int n) {
        if(Double.isInfinite(input) || Double.isNaN(input)) {
            return input;
        }
        BigDecimal bd = new BigDecimal(input+"");  //Use String constructor
        bd = bd.setScale(n,BigDecimal.ROUND_HALF_UP);  //
        return bd.doubleValue();
    }

    /**
     * Integrates the input using the Trapezoidal rule.
     *
     * @param input the input with the domain in the first row and range in the second row
     * @return the approximate integral of the input
     */

    public static double trapIntegrate(double[][] input) {
        if(input.length!=2 && input[0].length<2) {
            throw new IllegalArgumentException("Unexpected input dimensions for "
                    + "integration by the Trapezoid rule. "
                    + "Expected [2][>1]: ["+input.length+"]["+input[0].length+"].");
        }
        double area = 0;  //Initialize
        for (int i = 1; i < input[0].length; i++) {
            area += (input[0][i] - input[0][i - 1]) * (input[1][i] + input[1][i - 1]);
        }
        area = 0.5 * area;
        return area;
    }

    /** 
     * Returns the factorial of a positive integer argument <tt>z</tt> from a
     * look-up table. Returns positive infinity if <tt>z</tt> > 170
     *
     * @param z positive integer.
     * @return the factorial of z
     */
    
    public static double getFactorial(int z) {
        
        if (z < 0) throw new IllegalArgumentException("Factorial not defined");
        
        int a = LONG_FACTORIALS.length;
        int b = DOUBLE_FACTORIALS.length;
        
        if (z < a) {
            return LONG_FACTORIALS[z];
        }
        
        else if ( z < (a + b) ) {
            return DOUBLE_FACTORIALS[z-a];
        }
        else {
            return Double.POSITIVE_INFINITY;
        }
    }
    
    
    /**
     * Returns <tt>log(k!)</tt>.
     * Tries to avoid overflows.
     * For <tt>k<30</tt> simply looks up a table in O(1).
     * For <tt>k>=30</tt> uses Stirling's approximation.
     * 
     * @param k must hold <tt>k &gt;= 0</tt>.
     * @return <tt>log(k!)</tt>.
     */
    
    public static double logFactorial(int k) {
        if (k >= 30) {
            double  r, rr;
            final double C0 =  9.18938533204672742e-01;
            final double C1 =  8.33333333333333333e-02;
            final double C3 = -2.77777777777777778e-03;
            final double C5 =  7.93650793650793651e-04;
            final double C7 = -5.95238095238095238e-04;
            
            r  = 1.0 / (double) k;
            rr = r * r;
            return (k + 0.5)*Math.log(k) - k + C0 + r*(C1 + rr*(C3 + rr*(C5 + rr*C7)));
        }
        else {
            return LOG_FACTORIALS[k];
        }
    }
    
    /**
     * Returns the sum of the terms <tt>0</tt> through <tt>k</tt> of the Binomial
     * probability density.
     * <pre>
     *   k
     *   --  ( n )   j      n-j
     *   >   (   )  p  (1-p)
     *   --  ( j )
     *  j=0
     * </pre>
     * The terms are not summed directly; instead the incomplete
     * beta integral is employed, according to the formula
     * <p>
     * <tt>y = binomial( k, n, p ) = incompleteBeta( n-k, k+1, 1-p )</tt>.
     * <p>
     * All arguments must be positive.
     *
     * @param k end term.
     * @param n the number of trials.
     * @param p the probability of success (must be in <tt>(0.0,1.0)</tt>).
     * @return sum to k the binomial density
     */
    
    public static double binomial(int k, int n, double p) {
        if( (p < 0.0) || (p > 1.0) ) throw new IllegalArgumentException();
        if( (k < 0) || (n < k) ) throw new IllegalArgumentException();
        
        if( k == n ) return( 1.0 );
        if( k == 0 ) return Math.pow( 1.0-p, n-k );
        
        return incompleteBeta( n-k, k+1, 1.0 - p );
    }
    
    /**
     * Returns the Gamma function of the argument.
     * 
     * @param x A double argument
     * @return gamma(x)
     */
    
    public static double gamma(double x) throws ArithmeticException {
        
        double[] P = {
            1.60119522476751861407E-4,
            1.19135147006586384913E-3,
            1.04213797561761569935E-2,
            4.76367800457137231464E-2,
            2.07448227648435975150E-1,
            4.94214826801497100753E-1,
            9.99999999999999996796E-1
        };
        
        double[] Q = {
            -2.31581873324120129819E-5,
            5.39605580493303397842E-4,
            -4.45641913851797240494E-3,
            1.18139785222060435552E-2,
            3.58236398605498653373E-2,
            -2.34591795718243348568E-1,
            7.14304917030273074085E-2,
            1.00000000000000000320E0
        };
        
        //double MAXGAM = 171.624376956302725;
        //double LOGPI  = 1.14472988584940017414;
        
        double p, z;
        
        double q = Math.abs(x);
        
        if( q > 33.0 ) {
            if( x < 0.0 ) {
                p = Math.floor(q);
                if( p == q ) throw new ArithmeticException("gamma: overflow");
                z = q - p;
                
                if( z > 0.5 ) {
                    p += 1.0;
                    z = q - p;
                }
                
                z = q * Math.sin( Math.PI * z );
                if( z == 0.0 ) throw new ArithmeticException("gamma: overflow");
                z = Math.abs(z);
                z = Math.PI/(z * stirlingFormula(q) );
                
                return -z;
            }
            
            else {
                return stirlingFormula(x);
            }
        }
        
        z = 1.0;
        while( x >= 3.0 ) {
            x -= 1.0;
            z *= x;
        }
        
        while( x < 0.0 ) {
            if( x == 0.0 ) {
                throw new ArithmeticException("gamma: singular");
            }
            else
                if( x > -1.E-9 ) {
                    return( z/((1.0 + 0.5772156649015329 * x) * x) );
                }
            z /= x;
            x += 1.0;
        }
        
        while( x < 2.0 ) {
            if( x == 0.0 ) {
                throw new ArithmeticException("gamma: singular");
            }
            else
                if( x < 1.e-9 ) {
                    return( z/((1.0 + 0.5772156649015329 * x) * x) );
                }
            z /= x;
            x += 1.0;
        }
        
        if( (x == 2.0) || (x == 3.0) ) return z;
        
        x -= 2.0;
        p = polevl( x, P, 6 );
        q = polevl( x, Q, 7 );
        
        return  z * p / q;
    }
    
    /**
     * Returns the integral from zero to <tt>x</tt> of the gamma probability
     * density function.
     * <pre>
     *                x
     *        b       -
     *       a       | |   b-1  -at
     * y =  -----    |    t    e    dt
     *       -     | |
     *      | (b)   -
     *               0
     * </pre>
     * The incomplete gamma integral is used, according to the
     * relation
     *
     * <tt>y = incompleteGamma( b, a*x )</tt>.
     *
     * @param a the parameter a (alpha) of the gamma distribution.
     * @param b the parameter b (beta, lambda) of the gamma distribution.
     * @param x integration end point.
     * @return the gamma integral to x
     */
    
    public static double gamma(double a, double b, double x ) {
        if( x < 0.0 ) return 0.0;
        return incompleteGamma(b, a*x);
    }
    
    /**
     * Returns the integral from <tt>x</tt> to infinity of the gamma
     * probability density function:
     * <pre>
     *               inf.
     *        b       -
     *       a       | |   b-1  -at
     * y =  -----    |    t    e    dt
     *       -     | |
     *      | (b)   -
     *               x
     * </pre>
     * The incomplete gamma integral is used, according to the
     * relation
     * <p>
     * y = incompleteGammaComplement( b, a*x ).
     *
     * @param a the parameter a (alpha) of the gamma distribution.
     * @param b the parameter b (beta, lambda) of the gamma distribution.
     * @param x integration start point.
     * @return the gamma integral from x to infinity
     */
    
    static public double gammaComplemented(double a, double b, double x ) {
        if( x < 0.0 ) return 0.0;
        return incompleteGammaComplement(b, a*x);
    }
    
    /**
     * Returns the Incomplete Gamma integral.
     *
     * @param a the parameter of the gamma distribution.
     * @param x the integration end point.
     * @return the incomplete gamma integral to x.
     */
    
    public static double incompleteGamma(double a, double x) throws ArithmeticException {
        
        double ans, ax, c, r;
        
        if( x <= 0 || a <= 0 ) return 0.0;
        
        if( x > 1.0 && x > a ) return 1.0 - incompleteGammaComplement(a,x);
        
        /* Compute  x**a * exp(-x) / gamma(a)  */
        ax = a * Math.log(x) - x - logGamma(a);
        if( ax < -MAXLOG ) return( 0.0 );
        
        ax = Math.exp(ax);
        
        /* power series */
        r = a;
        c = 1.0;
        ans = 1.0;
        
        do {
            r += 1.0;
            c *= x/r;
            ans += c;
        }
        while( c/ans > MACHEP );
        
        return( ans * ax/a );
        
    }
    
    /**
     * Returns the Complemented Incomplete Gamma integral.
     *
     * @param a the parameter of the gamma distribution.
     * @param x the integration start point.
     * @return the complemented incomplete gamma integral from x.
     */
    
    public static double incompleteGammaComplement( double a, double x ) throws ArithmeticException {
        double ans, ax, c, yc, r, t, y, z;
        double pk, pkm1, pkm2, qk, qkm1, qkm2;
        
        if( x <= 0 || a <= 0 ) return 1.0;
        
        if( x < 1.0 || x < a ) return 1.0 - incompleteGamma(a,x);
        
        ax = a * Math.log(x) - x - logGamma(a);
        if( ax < -MAXLOG ) return 0.0;
        
        ax = Math.exp(ax);
        
        /* continued fraction */
        y = 1.0 - a;
        z = x + y + 1.0;
        c = 0.0;
        pkm2 = 1.0;
        qkm2 = x;
        pkm1 = x + 1.0;
        qkm1 = z * x;
        ans = pkm1/qkm1;
        
        do {
            c += 1.0;
            y += 1.0;
            z += 2.0;
            yc = y * c;
            pk = pkm1 * z  -  pkm2 * yc;
            qk = qkm1 * z  -  qkm2 * yc;
            
            if( qk != 0 ) {
                r = pk/qk;
                t = Math.abs( (ans - r)/r );
                ans = r;
            } else
                t = 1.0;
            
            pkm2 = pkm1;
            pkm1 = pk;
            qkm2 = qkm1;
            qkm1 = qk;
            
            if( Math.abs(pk) > BIG ) {
                pkm2 *= BIGINV;
                pkm1 *= BIGINV;
                qkm2 *= BIGINV;
                qkm1 *= BIGINV;
            }
            
        } while( t > MACHEP );
        return ans * ax;
    }
    
    /**
     * Returns the natural logarithm of the gamma function.
     *
     * @param x A double value
     * @return natural log of gamma to x
     */
    
    public static double logGamma(double x) throws ArithmeticException {
        double p, q, w, z;
        
        double[] A = {
            8.11614167470508450300E-4,
            -5.95061904284301438324E-4,
            7.93650340457716943945E-4,
            -2.77777777730099687205E-3,
            8.33333333333331927722E-2
        };
        
        double[] B = {
            -1.37825152569120859100E3,
            -3.88016315134637840924E4,
            -3.31612992738871184744E5,
            -1.16237097492762307383E6,
            -1.72173700820839662146E6,
            -8.53555664245765465627E5
        };
        
        double[] C = {
            /* 1.00000000000000000000E0, */
            -3.51815701436523470549E2,
            -1.70642106651881159223E4,
            -2.20528590553854454839E5,
            -1.13933444367982507207E6,
            -2.53252307177582951285E6,
            -2.01889141433532773231E6
        };
        
        if( x < -34.0 ) {
            q = -x;
            w = logGamma(q);
            p = Math.floor(q);
            if( p == q ) throw new ArithmeticException("lgam: Overflow");
            z = q - p;
            if( z > 0.5 ) {
                p += 1.0;
                z = p - q;
            }
            z = q * Math.sin( Math.PI * z );
            if( z == 0.0 ) throw new ArithmeticException("lgamma: Overflow");
            z = LOGPI - Math.log( z ) - w;
            return z;
        }
        
        if( x < 13.0 ) {
            z = 1.0;
            
            while( x >= 3.0 ) {
                x -= 1.0;
                z *= x;
            }
            
            while( x < 2.0 ) {
                if( x == 0.0 ) throw new ArithmeticException("lgamma: Overflow");
                z /= x;
                x += 1.0;
            }
            
            if( z < 0.0 ) z = -z;
            if( x == 2.0 ) return Math.log(z);
            x -= 2.0;
            p = x * polevl( x, B, 5 ) / p1evl( x, C, 6);
            return( Math.log(z) + p );
        }
        
        if( x > 2.556348e305 ) throw new ArithmeticException("lgamma: Overflow");
        
        q = ( x - 0.5 ) * Math.log(x) - x + 0.91893853320467274178;
        //if( x > 1.0e8 ) return( q );
        if( x > 1.0e8 ) return( q );
        
        p = 1.0/(x*x);
        if( x >= 1000.0 )
            q += (( 7.9365079365079365079365e-4 * p
            - 2.7777777777777777777778e-3) *p
            + 0.0833333333333333333333) / x;
        else
            q += polevl( p, A, 4 ) / x;
        return q;
    }
    
    /**
     * Returns the beta function of the arguments.
     * <pre>
     *                   -     -
     *                  | (a) | (b)
     * beta( a, b )  =  -----------.
     *                     -
     *                    | (a+b)
     * </pre>
     * @param a alpha
     * @param b beta
     * @return beta function
     */
    
    public static double beta(double a, double b) throws ArithmeticException {
        double y;
        
        y = a + b;
        y = gamma(y);
        if( y == 0.0 ) return 1.0;
        
        if( a > b ) {
            y = gamma(a)/y;
            y *= gamma(b);
        }
        else {
            y = gamma(b)/y;
            y *= gamma(a);
        }
        
        return(y);
    }
    
    /**
     * Returns the Incomplete Beta Function evaluated from zero to <tt>xx</tt>.
     *
     * @param aa the alpha parameter of the beta distribution.
     * @param bb the beta parameter of the beta distribution.
     * @param xx the integration end point.
     * @return the incomplete beta function to xx.
     */
    public static double incompleteBeta(double aa, double bb, double xx) throws ArithmeticException {
        double a, b, t, x, xc, w, y;
        boolean flag;
        
        if( aa <= 0.0 || bb <= 0.0 ) throw new ArithmeticException("ibeta: Domain error!");
        
        if( (xx <= 0.0) || ( xx >= 1.0) ) {
            if( xx == 0.0 ) return 0.0;
            if( xx == 1.0 ) return 1.0;
            throw new ArithmeticException("ibeta: Domain error!");
        }
        
        flag = false;
        if( (bb * xx) <= 1.0 && xx <= 0.95) {
            t = powerSeries(aa, bb, xx);
            return t;
        }
        
        w = 1.0 - xx;
        
        /* Reverse a and b if x is greater than the mean. */
        if( xx > (aa/(aa+bb)) ) {
            flag = true;
            a = bb;
            b = aa;
            xc = xx;
            x = w;
        } else {
            a = aa;
            b = bb;
            xc = w;
            x = xx;
        }
        
        if( flag  && (b * x) <= 1.0 && x <= 0.95) {
            t = powerSeries(a, b, x);
            if( t <= MACHEP ) 	t = 1.0 - MACHEP;
            else  		        t = 1.0 - t;
            return t;
        }
        
        /* Choose expansion for better convergence. */
        y = x * (a+b-2.0) - (a-1.0);
        
        if( y < 0.0 ) w = incompleteBetaFraction1( a, b, x );
        else w = incompleteBetaFraction2( a, b, x ) / xc;
        
        /* Multiply w by the factor
        a      b   _             _     _
        x  (1-x)   | (a+b) / ( a | (a) | (b) ) .   */
        
        y = a * Math.log(x);
        t = b * Math.log(xc);
        
        if( (a+b) < MAXGAM && Math.abs(y) < MAXLOG && Math.abs(t) < MAXLOG ) {
            t = Math.pow(xc,b);
            t *= Math.pow(x,a);
            t /= a;
            t *= w;
            t *= gamma(a+b) / (gamma(a) * gamma(b));
            if( flag ) {
                if( t <= MACHEP ) 	t = 1.0 - MACHEP;
                else  		        t = 1.0 - t;
            }
            return t;
        }
        
        /* Resort to logarithms.  */
        y += t + logGamma(a+b) - logGamma(a) - logGamma(b);
        y += Math.log(w/a);
        
        if( y < MINLOG ) t = 0.0;
        else t = Math.exp(y);
        
        if( flag ) {
            if( t <= MACHEP ) t = 1.0 - MACHEP;
            else t = 1.0 - t;
        }
        
        return t;
    }
    
    /**
     * Continued fraction expansion #1 for incomplete beta integral.
     */
    
    private static double incompleteBetaFraction1( double a, double b, double x ) throws ArithmeticException {
        double xk, pk, pkm1, pkm2, qk, qkm1, qkm2;
        double k1, k2, k3, k4, k5, k6, k7, k8;
        double r, t, ans, thresh;
        int n;
        
        k1 = a;
        k2 = a + b;
        k3 = a;
        k4 = a + 1.0;
        k5 = 1.0;
        k6 = b - 1.0;
        k7 = k4;
        k8 = a + 2.0;
        
        pkm2 = 0.0;
        qkm2 = 1.0;
        pkm1 = 1.0;
        qkm1 = 1.0;
        ans = 1.0;
        r = 1.0;
        n = 0;
        thresh = 3.0 * MACHEP;
        
        do {
            xk = -( x * k1 * k2 )/( k3 * k4 );
            pk = pkm1 +  pkm2 * xk;
            qk = qkm1 +  qkm2 * xk;
            pkm2 = pkm1;
            pkm1 = pk;
            qkm2 = qkm1;
            qkm1 = qk;
            
            xk = ( x * k5 * k6 )/( k7 * k8 );
            pk = pkm1 +  pkm2 * xk;
            qk = qkm1 +  qkm2 * xk;
            pkm2 = pkm1;
            pkm1 = pk;
            qkm2 = qkm1;
            qkm1 = qk;
            
            if( qk != 0 )		r = pk/qk;
            if( r != 0 ) {
                t = Math.abs( (ans - r)/r );
                ans = r;
            }	else
                t = 1.0;
            
            if( t < thresh ) return ans;
            
            k1 += 1.0;
            k2 += 1.0;
            k3 += 2.0;
            k4 += 2.0;
            k5 += 1.0;
            k6 -= 1.0;
            k7 += 2.0;
            k8 += 2.0;
            
            if( (Math.abs(qk) + Math.abs(pk)) > BIG ) {
                pkm2 *= BIGINV;
                pkm1 *= BIGINV;
                qkm2 *= BIGINV;
                qkm1 *= BIGINV;
            }
            if( (Math.abs(qk) < BIGINV) || (Math.abs(pk) < BIGINV) ) {
                pkm2 *= BIG;
                pkm1 *= BIG;
                qkm2 *= BIG;
                qkm1 *= BIG;
            }
        }
        
        while( ++n < 300 );
        
        return ans;
    }
    
    /**
     * Continued fraction expansion #2 for incomplete beta integral.
     */
    
    private static double incompleteBetaFraction2( double a, double b, double x ) throws ArithmeticException {
        double xk, pk, pkm1, pkm2, qk, qkm1, qkm2;
        double k1, k2, k3, k4, k5, k6, k7, k8;
        double r, t, ans, z, thresh;
        int n;
        
        k1 = a;
        k2 = b - 1.0;
        k3 = a;
        k4 = a + 1.0;
        k5 = 1.0;
        k6 = a + b;
        k7 = a + 1.0;;
        k8 = a + 2.0;
        
        pkm2 = 0.0;
        qkm2 = 1.0;
        pkm1 = 1.0;
        qkm1 = 1.0;
        z = x / (1.0-x);
        ans = 1.0;
        r = 1.0;
        n = 0;
        thresh = 3.0 * MACHEP;
        
        do {
            xk = -( z * k1 * k2 )/( k3 * k4 );
            pk = pkm1 +  pkm2 * xk;
            qk = qkm1 +  qkm2 * xk;
            pkm2 = pkm1;
            pkm1 = pk;
            qkm2 = qkm1;
            qkm1 = qk;
            
            xk = ( z * k5 * k6 )/( k7 * k8 );
            pk = pkm1 +  pkm2 * xk;
            qk = qkm1 +  qkm2 * xk;
            pkm2 = pkm1;
            pkm1 = pk;
            qkm2 = qkm1;
            qkm1 = qk;
            
            if( qk != 0 )  r = pk/qk;
            if( r != 0 ) {
                t = Math.abs( (ans - r)/r );
                ans = r;
            } else
                t = 1.0;
            
            if( t < thresh ) return ans;
            
            k1 += 1.0;
            k2 -= 1.0;
            k3 += 2.0;
            k4 += 2.0;
            k5 += 1.0;
            k6 += 1.0;
            k7 += 2.0;
            k8 += 2.0;
            
            if( (Math.abs(qk) + Math.abs(pk)) > BIG ) {
                pkm2 *= BIGINV;
                pkm1 *= BIGINV;
                qkm2 *= BIGINV;
                qkm1 *= BIGINV;
            }
            if( (Math.abs(qk) < BIGINV) || (Math.abs(pk) < BIGINV) ) {
                pkm2 *= BIG;
                pkm1 *= BIG;
                qkm2 *= BIG;
                qkm1 *= BIG;
            }
        }
        
        while( ++n < 300 );
        
        return ans;
    }
    
    /**
     * Returns the error function.
     *
     * Code adapted from the <A HREF="http://www.bndev.sourceforge.net"> Bayesian Network tools in Java (BNJ) project </A>, based on
     * the <A HREF="http://www.sci.usq.edu.au/staff/leighb/graph/Top.html"> Java 2D Graph Package 2.4</A>,
     * which is ported from the <A HREF="http://people.ne.mediaone.net/moshier/index.html#Cephes">Cephes 2.2</A> Math Library (C).
     *
     * @param x a real value for computing the error function.
     * @return the error function
     */
    
    public static double errorFunction(double x) throws ArithmeticException {
        double y, z;
        
        final double[] T = {
            9.60497373987051638749E0,
            9.00260197203842689217E1,
            2.23200534594684319226E3,
            7.00332514112805075473E3,
            5.55923013010394962768E4
        };
        
        final double[] U = {
            //1.00000000000000000000E0,
            3.35617141647503099647E1,
            5.21357949780152679795E2,
            4.59432382970980127987E3,
            2.26290000613890934246E4,
            4.92673942608635921086E4
        };
        
        if( Math.abs(x) > 1.0 ) return( 1.0 - errorFunctionComplemented(x) );
        z = x * x;
        y = x * Mathematics.polevl( z, T, 4 ) / Mathematics.p1evl( z, U, 5 );
        return y;
    }
    
    /**
     * Returns the complementary error function.
     *
     * Code adapted from the <A HREF="http://www.bndev.sourceforge.net"> Bayesian Network tools in Java (BNJ) project </A>, based on
     * the <A HREF="http://www.sci.usq.edu.au/staff/leighb/graph/Top.html"> Java 2D Graph Package 2.4</A>,
     * which is ported from the <A HREF="http://people.ne.mediaone.net/moshier/index.html#Cephes">Cephes 2.2</A> Math Library (C).
     *
     * @param a real value for computing the complementary error function.
     * @return the error function complement
     */
    
    public static double errorFunctionComplemented(double a) throws ArithmeticException {
        double x,y,z,p,q;
        double[] P = {
            2.46196981473530512524E-10,
            5.64189564831068821977E-1,
            7.46321056442269912687E0,
            4.86371970985681366614E1,
            1.96520832956077098242E2,
            5.26445194995477358631E2,
            9.34528527171957607540E2,
            1.02755188689515710272E3,
            5.57535335369399327526E2
        };
        double[] Q = {
            //1.0
            1.32281951154744992508E1,
            8.67072140885989742329E1,
            3.54937778887819891062E2,
            9.75708501743205489753E2,
            1.82390916687909736289E3,
            2.24633760818710981792E3,
            1.65666309194161350182E3,
            5.57535340817727675546E2
        };
        
        double[] R = {
            5.64189583547755073984E-1,
            1.27536670759978104416E0,
            5.01905042251180477414E0,
            6.16021097993053585195E0,
            7.40974269950448939160E0,
            2.97886665372100240670E0
        };
        double[] S = {
            // 1.00000000000000000000E0
            2.26052863220117276590E0,
            9.39603524938001434673E0,
            1.20489539808096656605E1,
            1.70814450747565897222E1,
            9.60896809063285878198E0,
            3.36907645100081516050E0
        };
        
        if( a < 0.0 )   x = -a;
        else            x = a;
        
        if( x < 1.0 )   return 1.0 - errorFunction(a);
        
        z = -a * a;
        
        if( z < -MAXLOG ) {
            if( a < 0 )  return( 2.0 );
            else         return( 0.0 );
        }
        
        z = Math.exp(z);
        
        if( x < 8.0 ) {
            p = Mathematics.polevl( x, P, 8 );
            q = Mathematics.p1evl( x, Q, 8 );
        }
        else {
            p = Mathematics.polevl( x, R, 5 );
            q = Mathematics.p1evl( x, S, 6 );
        }
        
        y = (z * p)/q;
        
        if( a < 0 ) y = 2.0 - y;
        
        if( y == 0.0 ) {
            if( a < 0 ) return 2.0;
            else        return( 0.0 );
        }
        
        return y;
    }

    /**
     * Returns the area under the Normal (Gaussian) probability density
     * function, integrated from minus infinity to <tt>x</tt> (assumes mean is zero, variance is one).
     * <pre>
     *                            x
     *                             -
     *                   1        | |          2
     *  normal(x)  = ---------    |    exp( - t /2 ) dt
     *               sqrt(2pi)  | |
     *                           -
     *                          -inf.
     *
     *             =  ( 1 + erf(z) ) / 2
     *             =  erfc(z) / 2
     * </pre>
     * where <tt>z = x/sqrt(2)</tt>.
     * Computation is via the functions <tt>errorFunction</tt> and <tt>errorFunctionComplement</tt>.
     */
    static public double normal(double a) throws ArithmeticException {
        double x, y, z;

        x = a * SQRTH;
        z = Math.abs(x);

        if (z < SQRTH) {
            y = 0.5 + 0.5 * errorFunction(x);
        } else {
            y = 0.5 * errorFunctionComplemented(z);
            if (x > 0) {
                y = 1.0 - y;
            }
        }

        return y;
    }

    /**
     * Returns the value, <tt>x</tt>, for which the area under the
     * Normal (Gaussian) probability density function (integrated from
     * minus infinity to <tt>x</tt>) is equal to the argument <tt>y</tt> (assumes mean is zero, variance is one); formerly named <tt>ndtri</tt>.
     * <p>
     * For small arguments <tt>0 < y < exp(-2)</tt>, the program computes
     * <tt>z = sqrt( -2.0 * log(y) )</tt>;  then the approximation is
     * <tt>x = z - log(z)/z  - (1/z) P(1/z) / Q(1/z)</tt>.
     * There are two rational functions P/Q, one for <tt>0 < y < exp(-32)</tt>
     * and the other for <tt>y</tt> up to <tt>exp(-2)</tt>.
     * For larger arguments,
     * <tt>w = y - 0.5</tt>, and  <tt>x/sqrt(2pi) = w + w**3 R(w**2)/S(w**2))</tt>.
     *
     */
    static public double normalInverse(double y0) throws ArithmeticException {
        double x, y, z, y2, x0, x1;
        int code;

        final double s2pi = Math.sqrt(2.0 * Math.PI);

        if (y0 <= 0.0) {
            throw new IllegalArgumentException("Cannot compute normal inverse for <= 0.0.");
        }
        if (y0 >= 1.0) {
            throw new IllegalArgumentException("Cannot compute normal inverse for >= 1.0.");
        }
        code = 1;
        y = y0;
        if (y > (1.0 - 0.13533528323661269189)) { /* 0.135... = exp(-2) */
            y = 1.0 - y;
            code = 0;
        }

        if (y > 0.13533528323661269189) {
            y = y - 0.5;
            y2 = y * y;
            x = y + y * (y2 * polevl(y2, P0, 4) / p1evl(y2, Q0, 8));
            x = x * s2pi;
            return (x);
        }

        x = Math.sqrt(-2.0 * Math.log(y));
        x0 = x - Math.log(x) / x;

        z = 1.0 / x;
        if (x < 8.0) /* y > exp(-32) = 1.2664165549e-14 */ {
            x1 = z * polevl(z, P1, 8) / p1evl(z, Q1, 8);
        } else {
            x1 = z * polevl(z, P2, 8) / p1evl(z, Q2, 8);
        }
        x = x0 - x1;
        if (code != 0) {
            x = -x;
        }
        return (x);
    }

    /**
     * Evaluates the given polynomial of degree <tt>N</tt> at <tt>x</tt>,
     * assuming coefficient of N is 1.0. Otherwise same as <tt>polevl()</tt>.
     * <pre>
     *                     2          N
     * y  =  C  + C x + C x  +...+ C x
     *        0    1     2          N
     *
     * where C  = 1 and hence is omitted from the array.
     *        N
     *
     * Coefficients are stored in reverse order:
     *
     * coef[0] = C  , ..., coef[N-1] = C  .
     *            N-1                   0
     *
     * Calling arguments are otherwise the same as polevl().
     * </pre>
     * In the interests of speed, there are no checks for out of bounds arithmetic.
     *
     * @param x argument to the polynomial.
     * @param coef the coefficients of the polynomial.
     * @param N the degree of the polynomial.
     * @return the evaluated polynomial
     */
    
    public static double p1evl(double x, double[] coef, int N) throws ArithmeticException {
        double ans;
        ans = x + coef[0];
        for(int i=1; i<N; i++) { ans = ans*x+coef[i]; }
        return ans;
    }
    
    /**
     * Evaluates the given polynomial of degree <tt>N</tt> at <tt>x</tt>.
     * <pre>
     *                     2          N
     * y  =  C  + C x + C x  +...+ C x
     *        0    1     2          N
     *
     * Coefficients are stored in reverse order:
     *
     * coef[0] = C  , ..., coef[N] = C  .
     *            N                   0
     * </pre>
     * In the interest of speed, there are no checks for out of bounds arithmetic.
     *
     * @param x argument to the polynomial.
     * @param coef the coefficients of the polynomial.
     * @param N the degree of the polynomial.
     * @return the evaluated polynomial.
     */
    
    public static double polevl( double x, double[] coef, int N ) throws ArithmeticException {
        double ans;
        ans = coef[0];
        for(int i=1; i<=N; i++) ans = ans*x+coef[i];
        return ans;
    }
    
    /**
     * Power series for incomplete beta integral; formerly named <tt>pseries</tt>.
     * Use when b*x is small and x not too close to 1.
     * 
     * @param a alpha
     * @param b beta
     * @param x integration end point.
     * @return the power series for the incomplete beta integral to x.
     */
    
    public static double powerSeries( double a, double b, double x ) throws ArithmeticException {
        double s, t, u, v, n, t1, z, ai;
        
        ai = 1.0 / a;
        u = (1.0 - b) * x;
        v = u / (a + 1.0);
        t1 = v;
        t = u;
        n = 2.0;
        s = 0.0;
        z = MACHEP * ai;
        
        while( Math.abs(v) > z ) {
            u = (n - b) * x / n;
            t *= u;
            v = t / (a + n);
            s += v;
            n += 1.0;
        }
        
        s += t1;
        s += ai;
        
        u = a * Math.log(x);
        
        if( (a+b) < MAXGAM && Math.abs(u) < MAXLOG ) {
            t = gamma(a+b)/(gamma(a)*gamma(b));
            s = s * t * Math.pow(x,a);
        }
        else {
            t = logGamma(a+b) - logGamma(a) - logGamma(b) + u + Math.log(s);
            if( t < MINLOG ) 	s = 0.0;
            else  	            s = Math.exp(t);
        }
        return s;
    }
    
    /**
     * Returns the Gamma function computed by Stirling's formula.
     * The polynomial STIR is valid for 33 <= x <= 172.
     *
     * @param x A double value
     * @return Stirling's formula for x
     */
    
    public static double stirlingFormula(double x) throws ArithmeticException {
        double[] STIR = {
            7.87311395793093628397E-4,
            -2.29549961613378126380E-4,
            -2.68132617805781232825E-3,
            3.47222221605458667310E-3,
            8.33333333333482257126E-2,
        };
        double MAXSTIR = 143.01608;
        
        double w = 1.0/x;
        double  y = Math.exp(x);
        
        w = 1.0 + w * polevl( w, STIR, 4 );
        
        if( x > MAXSTIR ) {
            /* Avoid overflow in Math.pow() */
            double v = Math.pow( x, 0.5 * x - 0.25 );
            y = v * (v / y);
        }
        else {
            y = Math.pow( x, x - 0.5 ) / y;
        }
        y = SQTPI * y * w;
        return y;
    }
    
    /**
     * Returns the StirlingCorrection.
     * <p>
     * Correction term of the Stirling approximation for <tt>log(k!)</tt>
     * (series in 1/k, or table values for small k)
     * with int parameter k.
     * <p>
     * <tt>
     * log k! = (k + 1/2)log(k + 1) - (k + 1) + (1/2)log(2Pi) +
     *          stirlingCorrection(k + 1)
     * <p>
     * log k! = (k + 1/2)log(k)     -  k      + (1/2)log(2Pi) +
     *          stirlingCorrection(k)
     * </tt>
     * 
     * @param k an integer value
     * @return Stirling's correction for k
     */
    
    public static double stirlingCorrection(int k) {
        final double C1 =  8.33333333333333333e-02;     //  +1/12
        final double C3 = -2.77777777777777778e-03;     //  -1/360
        final double C5 =  7.93650793650793651e-04;     //  +1/1260
        final double C7 = -5.95238095238095238e-04;     //  -1/1680
        
        double r, rr;
        
        if (k > 30) {
            r = 1.0 / (double) k;
            rr = r * r;
            return r*(C1 + rr*(C3 + rr*(C5 + rr*C7)));
        }
        else return STIRLING_CORRECTION[k];
    }
}

/*
Copyright 1999 CERN - European Organization for Nuclear Research.
Permission to use, copy, modify, distribute and sell this software and its documentation for any purpose
is hereby granted without fee, provided that the above copyright notice appear in all copies and
that both that copyright notice and this permission notice appear in supporting documentation.
CERN makes no representations about the suitability of this software for any purpose.
It is provided "as is" without expressed or implied warranty.
 */
