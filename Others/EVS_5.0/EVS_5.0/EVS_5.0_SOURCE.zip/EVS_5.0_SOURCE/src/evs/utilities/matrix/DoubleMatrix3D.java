package evs.utilities.matrix;

/**
 * Abstract base class for a 3D double matrix.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public abstract class DoubleMatrix3D extends Matrix3D implements DoubleMatrix {
    
    /*******************************************************************************
     *                                                                             *
     *                  ABSTRACT METHODS TO OVERRIDE IN A SUBCLASS                 *
     *                                                                             *
     ******************************************************************************/

    /**
     * Used to set the element value with internal coordinates.
     *
     * @param a row index
     * @param b column index
     * @param c depth index
     * @param value the matrix value
     */
    
    public abstract void set(int a, int b, int c, double value) throws IndexOutOfBoundsException;

    /**
     * Returns the element value for the given internal row-column-depth coordinates.
     *
     * @param a row index
     * @param b column index
     * @param c depth index
     * @return element (a,b,c)
     */
    
    public abstract double get(int a, int b, int c) throws IndexOutOfBoundsException;      
    
    /**
     * Returns the array elements.
     *
     * @return the data array
     */
    
    public abstract double[][][] toArray() throws OutOfMemoryError;
    
    /**
     * Returns a transpose view of the current matrix.
     *
     * @return a transpose of the current matrix.
     */
    
    public abstract DoubleMatrix3D transpose();
    
    /*******************************************************************************
     *                                                                             *
     *                              CONCRETE METHODS                               *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Returns a string representation of a layer in a double matrix with as many
     * decimal places as required for its elements.  
     *
     * @param depth the depth reference
     * @return a string representation of the matrix.
     */
    
    public String toString(int depth) throws IllegalArgumentException {
        if(depth < 0 || depth > nDepth) {
            throw new IllegalArgumentException("Invalid layer declaration.");
        }
        StringBuffer s = new StringBuffer();
        for(int  i = 0; i < nRows; i++) {
            if (i==0) {
                s.append("\t");
                for (int p=0; p < nColumns; p++) {
                    s.append("["+p+"]"+"\t");
                }
            }
            s.append(System.getProperty("line.separator")+"["+i+"]"+"\t");
            for(int  j = 0; j < nColumns; j++) {
                s.append(get(i,j,depth)+"\t");
            }
        }
        return s.toString();
    }
    
    /**
     * Returns a string representation of a double matrix with a specified number of
     * decimal places for its elements.  
     *
     * @param depth the depth reference 
     * @param decimalPlaces the number of decimal places required for the matrix elements.
     * @return a string representation of the matrix.
     */

    public String toString(int depth, int decimalPlaces) throws IllegalArgumentException {
        if(depth < 0 || depth > nDepth) {
            throw new IllegalArgumentException("Invalid layer declaration.");
        }
        StringBuffer s = new StringBuffer();
        for(int  i = 0; i < nRows; i++) {
            if (i==0) {
                s.append("\t");
                for (int p=0; p < nColumns; p++) {
                    s.append("["+p+"]"+"\t");
                }
            }
            s.append(System.getProperty("line.separator")+"["+i+"]"+"\t");
            for(int  j = 0; j < nColumns; j++) {
                s.append(Math.floor(get(i,j,depth)*Math.pow(10,decimalPlaces))/Math.pow(10,decimalPlaces)+"\t");
            }
        }
        return s.toString();
    }
    
}
