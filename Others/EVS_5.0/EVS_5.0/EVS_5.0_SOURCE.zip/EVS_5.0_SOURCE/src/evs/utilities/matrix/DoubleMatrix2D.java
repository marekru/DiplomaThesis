package evs.utilities.matrix;

//EVS dependencies
import evs.utilities.mathutil.DoubleProcedure;
import evs.utilities.mathutil.DoubleFunction;
import evs.utilities.mathutil.VectorFunction;
import evs.utilities.mathutil.DoubleDoubleFunction;

/**
 * Abstract base class for a 2D double matrix.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public abstract class DoubleMatrix2D extends Matrix2D implements DoubleMatrix {
    
    /*******************************************************************************
     *                                                                             *
     *                  ABSTRACT METHODS TO OVERRIDE IN A SUBCLASS                 *
     *                                                                             *
     ******************************************************************************/

    /**
     * Used to set the element value with internal coordinates.
     *
     * @param a row index
     * @param b column index
     * @param value the value
     */
    
    public abstract void set(int a, int b, double value);
    
    /**
     * Returns the element value for the given internal row-column coordinates.
     *
     * @param a row index
     * @param b column index
     * @return element (a,b)
     */
    
    public abstract double get(int a, int b) throws IndexOutOfBoundsException;
        
    /**
     * Returns the array elements.
     *
     * @return the data array
     */
    
    public abstract double[][] toArray() throws OutOfMemoryError;
    
    /**
     * Returns a transpose view of the current matrix.
     *
     * @return a transpose of the current matrix.
     */
    
    public abstract DoubleMatrix2D transpose();

    /**
     * Applies a double function to the current matrix and a numeric input matrix,
     * ignoring the specified value in the current matrix.  Specify a sub-matrix
     * on which to apply the function. The rows and columns defined by the boundaries
     * are included in the calculation.  The result may be assigned to the current matrix,
     * in which case the cells outside the sub-matrix will remain unchanged. Otherwise,
     * they will contain the default double value.
     *
     * @param input a matrix with identical dimensions
     * @param function a function
     * @param overwrite is true to assign the result to the current matrix, false for a deep copy
     * @param avoid a number to avoid
     * @param startRow the start row
     * @param startCol the start column
     * @param endRow the end row
     * @param endCol the end column
     * @return this f.apply(this, input)
     */

    public abstract DoubleMatrix2D assign(DoubleMatrix2D input, DoubleDoubleFunction function,
            boolean overwrite, double avoid, int startRow, int startCol, int endRow, int endCol)
            throws ArithmeticException, IllegalArgumentException, ArrayIndexOutOfBoundsException;

    /**
     * Applies a double function to the current matrix ignoring the specified value
     * in the current matrix.  Specify a sub-matrix on which to apply the function.
     * The rows and columns defined by the boundaries are included in the calculation.
     * The result may be assigned to the current matrix, in which case the cells
     * outside the sub-matrix will remain unchanged. Otherwise, they will contain
     * the default double value.
     *
     * @param function a function
     * @param overwrite is true to assign the result to the current matrix, false for a deep copy
     * @param avoid a number to avoid
     * @param startRow the start row
     * @param startCol the start column
     * @param endRow the end row
     * @param endCol the end column
     * @return this f.apply(this, input)
     */

    public abstract DoubleMatrix2D assign(DoubleFunction function,
            boolean overwrite, double avoid, int startRow, int startCol, int endRow, int endCol)
            throws ArithmeticException, IllegalArgumentException, ArrayIndexOutOfBoundsException;

    /**
     * Assigns a vector function row-wise. Transpose first to assign column-wise.
     *
     * @param function a vector function
     * @return a 1D matrix with as many elements as rows in the input, each containing
     * the result of applying the vector function to that row
     */

    public abstract DoubleMatrix1D assignByRow(VectorFunction function)
            throws ArithmeticException;

    /**
     * Assigns a vector function row-wise. Transpose first to assign column-wise.
     *
     * @param function a vector function
     * @param avoid a number to avoid
     * @return a 1D matrix with as many elements as rows in the input, each containing
     * the result of applying the vector function to that row
     */

    public abstract DoubleMatrix1D assignByRow(VectorFunction function, double avoid)
            throws ArithmeticException;

    /**
     * Assigns a vector function row-wise. Transpose first to assign column-wise.
     *
     * @param function a vector function
     * @param avoid a number to avoid
     * @param start a start column index
     * @param end the end column index
     * @return a 1D matrix with as many elements as rows in the input, each containing
     * the result of applying the vector function to that row
     */

    public abstract DoubleMatrix1D assignByRow(VectorFunction function, double avoid, int start, int end)
            throws ArithmeticException;

    /**
     * Returns a subset of rows in which the specified column meets the specified
     * condition or throws an exception if the column index is out of range or
     * no such rows exist.  If the column contains the avoid number, the corresponding
     * row is not returned.
     *
     * @param condition the condition
     * @param col the column
     * @param avoid a number to avoid (may be null)
     * @return the rows in which the specified column value meets the condition
     */

    public abstract DoubleMatrix2D subRowsbyColCond(DoubleProcedure condition, int col, Double avoid) throws IllegalArgumentException;

    /**
     * Returns a subset of rows in which any of the columns meets the specified
     * condition or throws an exception if no such rows exist.  Optionally,
     * the function may be inverted, such that the opposite rows are returned.
     * The condition is not evaluated for a column whose value equals the non-null
     * avoid number.
     *
     * @param condition the condition
     * @param avoid a number to avoid (may be null)
     * @param invert is true to inverse the function
     * @return the rows in which the specified column value meets the condition
     */

    public abstract DoubleMatrix2D subRowsbyColCond(DoubleProcedure condition, Double avoid, boolean invert) throws IllegalArgumentException;

    /**
     * Returns a subset of rows that meet the row condition after applying the
     * specified row function.
     *
     * @param condition the row condition
     * @param rowFunc the row function
     * @param startCol the start column at which to apply the row function
     * @param endCol the end column at which to apply the row function
     * @param avoid a number to avoid (may be null)
     * @return the rows that meet the specified condition
     */

    public abstract DoubleMatrix2D subRowsbyRowCond(DoubleProcedure condition,VectorFunction rowFunc,int startCol,int endCol,Double avoid) throws IllegalArgumentException;

    /**
     * Append the input matrix to the bottom of the current matrix. The input
     * matrix must have the same number of columns as the current matrix. Rows
     * are shallow copied. returns the result in a new matrix.
     *
     * @param input the input matrix
     * @return a shallow appended matrix
     */

    public abstract DoubleMatrix2D appendRowsShallow(DoubleMatrix2D input) throws IllegalArgumentException;

    /**
     * Inserts a specified row or column into the matrix and returns the deep
     * copied matrix.
     *
     * @param insertMe the row or column to insert
     * @param index the zero based index at which to insert
     * @param isRow is true if the insertion is a row, false for column
     * @return the deep copied matrix with the inserted vector
     */

    public abstract DoubleMatrix2D insert(DoubleMatrix1D insertMe, int index,boolean isRow) throws ArrayIndexOutOfBoundsException;

    /**
     * Removes a specified row or column from the matrix and returns the deep
     * copied matrix.
     *
     * @param removeMe the row or column index to remove
     * @param isRow is true to remove a row, false to remove a column
     * @return the deep copied matrix with the removed vector
     */

    public abstract DoubleMatrix2D remove(int removeMe,boolean isRow) throws ArrayIndexOutOfBoundsException;

    /*******************************************************************************
     *                                                                             *
     *                              CONCRETE METHODS                               *
     *                                                                             *
     ******************************************************************************/

    /**
     * Returns a string representation of a double matrix with as many decimal places
     * as required for its elements.  This method is not specifically intended for
     * raw screen output as tabs are used.
     *
     * @return a string representation of the matrix.
     */
    
    public String toString() {
        StringBuffer s = new StringBuffer();
        double[][] array = toArray();
        String sep = System.getProperty("line.separator");
        for(int  i = 0; i < nRows; i++) {       
            if (i==0) {
                s.append("\t");
                for (int p=0; p < nColumns; p++) {
                    s.append("[").append(p).append("]").append("\t");
                }
            }
            s.append(sep).append("[")
                    .append(i).append("]").append("\t");
            for(int j = 0; j < array[i].length; j++) {
                s.append(array[i][j]).append("\t");
            }
        } 
        return s.toString();
    }
    
    /**
     * Returns a string representation of a double matrix with a specified number of
     * decimal places for its elements.  This method is not specifically intended for
     * raw screen output; appearance will vary with the number of decimal places as
     * tabs are used.
     *
     * @param decimalPlaces the number of decimal places required for the matrix elements.
     * @return a string representation of the matrix.
     */
    
    public String toString(int decimalPlaces) {
        StringBuffer s = new StringBuffer();
        for(int  i = 0; i < nRows; i++) {       
            if (i==0) {
                s.append("\t");
                for (int p=0; p < nColumns; p++) {
                    s.append("["+p+"]"+"\t");
                }
            }
            s.append(System.getProperty("line.separator")+"["+i+"]"+"\t");
            for(int j = 0; j < nColumns; j++) {      
                s.append(Math.floor(get(i,j)*Math.pow(10,decimalPlaces))/Math.pow(10,decimalPlaces)+"\t");
            }
        }
        return s.toString();
    }
}