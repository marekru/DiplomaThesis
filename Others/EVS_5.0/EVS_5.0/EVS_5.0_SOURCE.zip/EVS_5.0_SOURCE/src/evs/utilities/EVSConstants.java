package evs.utilities;

import java.util.TimeZone;

import evs.data.fileio.FileIO;
import evs.data.fileio.GlobalUnitsReader;

/**
 * Constants used by the EVS.
 * 
 * @author evs@hydrosolved.com
 * @version EVS 4.0
 */
public class EVSConstants {
    
    /**
     * Directory containing images used by the EVS GUI.
     */
    final public static String IMAGE_DIR = "/images/";

    /**
     * Directory containing EVS parameter files.
     */
    final public static String PARAMETER_FILE_DIR = "/parameterfiles/";

    /**
     * Directory containing HMTL help files for the EVS metrics.
     */
    final public static String STATS_EXPLAINED_DIR = "/statsexplained/";

    /**
     * Default time zone.
     */
    final public static TimeZone DEFAULT_ZONE = GlobalUnitsReader.getTimeSystem("Coordinated Universal Time (UTC)");

    /**
     * Default input file type.
     */
    final public static int DEFAULT_INPUT_TYPE = FileIO.ASCII;

    /**
     * xml file containing the version information.
     */
    final public static String EVS_CONFIG_FILE = "version/evs_config.xml";
    
    /*
     * Note: unlike "/images/" or "/parameterfiles/", "version/evs_config.xml" cannot start with "/" even though inside
     * EVS.jar, the three directories are parallel. The reason is that this file is accessed by the code
     * ClassLoader.getSystemResourceAsStream() in OHDConfigurationInfoReader.java, while the other files are accessed by
     * the code getClass().getResource(). It has to do where to start to search for these non-java files.
     */
       

}
