package evs.utilities.mathutil;

//EVS dependencies
import evs.utilities.matrix.DoubleMatrix1D;

/**
 * Interface representing a function that applies a double procedure to a vector 
 * and returns a boolean value.
 *
 * @author evs@hydrosolved.com
 * @version 5.0
 */

public interface VectorDoubleProcedure extends Function {
    
    /**
     * Applies a function to an argument.  Throws an exception if the specified 
     * function cannot be applied to the input matrix.
     *
     * @param argument argument passed to the function.
     * @return the result of the function.
     */
    
    public boolean apply(DoubleMatrix1D argument) throws IllegalArgumentException;
    
    /**
     * Applies a function to an argument.  Throws an exception if the specified 
     * function cannot be applied to the input matrix.
     *
     * @param argument argument passed to the function.
     * @param ignore a value to ignore in the input
     * @return the result of the function.
     */
    
    public boolean apply(DoubleMatrix1D argument, double ignore) throws IllegalArgumentException;

    /**
     * Returns the {@link DoubleProcedure} used to construct the function.
     *
     * @return the {@link DoubleProcedure}
     */

    public DoubleProcedure getProcedure();    
    

}
