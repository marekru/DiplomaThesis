package evs.utilities.matrix;

/**
 * Abstract base class for a 1D boolean matrix.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public abstract class BooleanMatrix1D extends Matrix1D implements BooleanMatrix {
    
    /*******************************************************************************
     *                                                                             *
     *                  ABSTRACT METHODS TO OVERRIDE IN A SUBCLASS                 *
     *                                                                             *
     ******************************************************************************/

    /**
     * Used to set the element value with internal coordinates.
     *
     * @param a row index
     * @param value the value to enter
     */
    
    public abstract void set(int a, boolean value) throws IndexOutOfBoundsException;

    /**
     * Returns the element value for the given internal row coordinate.
     *
     * @param a row index
     * @return element (a)
     */
    
    public abstract boolean get(int a) throws IndexOutOfBoundsException;
    
    /**
     * Returns an array of elements.
     *
     * @return the data array
     */
    
    public abstract boolean[] toArray();
    
    /**
     * Returns a transpose view of the current matrix.
     *
     * @return a transpose of the current matrix.
     */
    
    public abstract BooleanMatrix1D transpose();
    
    /*******************************************************************************
     *                                                                             *
     *                              CONCRETE METHODS                               *
     *                                                                             *
     ******************************************************************************/

    /**
     * Returns a string representation of the matrix.  
     *
     * @return a string representation of the matrix.
     */
    
    public String toString() {
        StringBuffer s = new StringBuffer();
        for(int  i = 0; i < nRows; i++) {   
            s.append(System.getProperty("line.separator")+"["+i+"]"+"\t");
            s.append(get(i)+"\t");
        }
        return s.toString();
    }
    
}