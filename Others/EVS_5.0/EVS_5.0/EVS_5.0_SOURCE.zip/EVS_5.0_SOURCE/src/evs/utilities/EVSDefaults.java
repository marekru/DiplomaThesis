package evs.utilities;

import evs.data.fileio.WriteOption;

/**
 * A class that stores default options for the EVS. 
 * 
 * @author evs@hydrosolved.com
 */
public final class EVSDefaults {
    
/*******************************************************************************
 *                                                                             *
 *                                  VARIABLES                                  *
 *                                                                             *
 ******************************************************************************/    
    
    /**
     * Write options for the EVS graphical and numerical outputs.
     */
    
    private static WriteOption write = new WriteOption(WriteOption.PNG_GRAPHICS);
    
/*******************************************************************************
 *                                                                             *
 *                               ACCESSOR METHODS                              *
 *                                                                             *
 ******************************************************************************/        
    
    /**
     * Returns the default write options.
     * 
     * @return the default write options
     */
    
    public static final WriteOption getWriteOptions() {
        return write;
    }

/*******************************************************************************
 *                                                                             *
 *                                MUTATOR METHODS                              *
 *                                                                             *
 ******************************************************************************/    
    
    /**
     * Sets the default write options.
     * 
     * @param writeOptions the default write options
     */
    
    public static final void setWriteOptions(WriteOption writeOptions) {
        if(writeOptions==null) {
            throw new IllegalArgumentException("Cannot set default write options to null: "
                    + "specify a non-null default.");
        }
        write=writeOptions;
    }    
    
}
