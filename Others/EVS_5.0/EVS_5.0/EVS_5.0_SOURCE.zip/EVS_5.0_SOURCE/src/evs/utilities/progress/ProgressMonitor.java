package evs.utilities.progress;

/**
 * Monitors the progress of a long running operation.
 *
 * @author evs@hydrosolved.com
 */

public class ProgressMonitor implements ProgressMonitorInterface {

    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLES                              *
     *                                                                              *
     *******************************************************************************/

    /**
     * State of completion.
     */

    private double progress = 0;

    /**
     * Factor by which to increment progress.
     */

    private double factor = 0;

    /**
     * Is true if the process associated with the monitor has been stopped.
     */

    private boolean stopped = false;

    /**
     * Optional interval at which to display information about progress to standard
     * out.
     */

    private int displayInterval = 0;

    /**
     * Last progress state at which information was displayed to standard out.
     */

    private int lastDisplay = 0;

    /**
     * Message to place before the progress status displayed on standard out.
     */

    private String start = "";

    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/

    /**
     * Returns the state of completion for the monitored operation.
     *
     * @return the state of completion
     */

    public synchronized int getProgress() {
        return (int)progress;
    }

    /**
     * Returns the factor by which progress is incremented when calling
     * {@link evs.utilities.progress.ProgressMonitor#increment()}()
     *
     * @return the progress increment
     */

    public synchronized double getIncrement() {
        return factor;
    }    

    /**
     * Returns true of the process associated with the monitor has been asked to
     * stop, false otherwise.
     *
     * @return true if the process is stopped, false otherwise
     */

    public boolean isStopped() {
        return stopped;
    }

    /********************************************************************************
     *                                                                              *
     *                                MUTATOR METHODS                               *
     *                                                                              *
     *******************************************************************************/

    /**
     * Sets the progress to the specified amount.
     *
     * @param progress the progress
     */

    public synchronized void setProgress(int progress) {
        this.progress = progress;
    }

    /**
     * Increments the progress by the factor currently set.
     */

    public synchronized void increment() {
        progress+=factor;
        if(displayInterval>0) {
            if(progress-lastDisplay>=displayInterval) {
                int dis = (int)(progress/displayInterval)*displayInterval;
                System.out.println(start+""+dis+".");
                lastDisplay = dis;
            }
        }
    }

    /**
     * Sets the non-negative factor by which to increment the progress when calling
     * {@link evs.utilities.progress.ProgressMonitor#increment()}()
     *
     * @param factor the factor
     */

    public synchronized void setIncrement(double factor) throws IllegalArgumentException {
        if(factor<=0) {
            throw new IllegalArgumentException("Enter a non-negative factor by which to increment "
                    + "the progress.");
        }
        this.factor=factor;
    }

    /**
     * Displays information about progress on standard out.  Specify the start of
     * the message to be displayed when each interval is reached on calling
     * {@link evs.utilities.progress.ProgressMonitor#increment()}()
     *
     * @param start the start of the message
     * @param displayInterval the display interval
     */

    public synchronized void display(String start, int displayInterval) {
        this.start = start;
        this.displayInterval = displayInterval;
    }

    /**
     * Resets the progress monitor to its default status on construction.
     */

    public synchronized void reset() {
        progress= 0;
        factor = 0;
        stopped = false;
        displayInterval = 0;
        lastDisplay = 0;
        start = "";
    }

    /**
     * Sets the process associated with the monitor to "stopped".
     * After calling this method {@link evs.utilities.progress.ProgressMonitor#isStopped()}()
     * will always return true.
     */

    public void stop() {
        stopped = true;
    }

}
