package evs.utilities.matrix;

/**
 * An interface for 1D matrices.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public abstract class Matrix1D extends Matrix {
    
    /**
     * Number of rows in the matrix.
     */
    
    protected int nRows = 0;    
    
/*******************************************************************************
 *                                                                             *
 *                            ACCESSOR METHODS                                 *
 *                                                                             *
 ******************************************************************************/      
  
    /**
     * Returns true if the input matrix has equivalent dimensions to this matrix.
     *
     * @param matrix the matrix for comparison
     * @return true if the matrices have equivalent dimensions
     */   
    
    public boolean hasEquivalentDimensions(Matrix matrix) {
        if(! (matrix instanceof Matrix1D) ) {
            return false;
        }
        return nRows == ((Matrix1D)matrix).getRowCount();        
    }
    
    /**
     * Return the number of elements in the matrix domain.
     *
     * @return number of elements
     */
      
    public int getElementCount() {
        return nRows;
    }     
    
    /**
     * Returns the number of rows in the matrix.
     *
     * @return number of rows
     */
      
    public int getRowCount() {
        return nRows;
    } 
    
    /**
     * Returns a deep copy of the current matrix in 1D form.  The matrix is filled
     * row-wise (i.e. one row at a time) and, in the case of a 3D matrix, from the 
     * top layer downwards.
     *
     * @return a deep copy in 1D form. 
     */
    
    public Matrix1D to1D() {
        return (Matrix1D)deepCopy();
    }    
    
   /**
     * Returns a deep copy of the current matrix in 2D form with a specified 
     * number of rows.  The matrix is filled row-wise from the top left corner.
     *
     * @param rowCount the number of rows
     * @return a deep copy in 2D form. 
     */
    
    public abstract Matrix2D to2D(int rowCount) throws IllegalArgumentException;
    
    /**
     * Returns a subset of the current matrix between (and including) the two rows.
     *
     * @param startRow the start row
     * @param endRow the end row
     * @return a subset of the current matrix by row
     */
    
    public abstract Matrix1D getSubmatrixByRow(int startRow, int endRow) throws IllegalArgumentException;
      

}
