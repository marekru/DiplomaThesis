package evs.utilities.matrix;

/**
 * A dense 2D matrix of boolean values.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DenseBooleanMatrix2D extends BooleanMatrix2D {
    
    /**
     * Store the matrix values
     */
    
    private boolean[][] matrixValues = null;
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTORS                                  *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Construct a regular matrix.
     *
     * @param rows the number of rows in the dense matrix
     * @param columns the number of columns in the dense matrix
     */
    
    public DenseBooleanMatrix2D(int rows, int columns) throws IllegalArgumentException {
        if (rows <= 0 || columns <= 0) {
            throw new IllegalArgumentException("Error: numbers of rows and columns must both exceed 0.");
        }
        nRows = rows;
        nColumns = columns;
        matrixValues = new boolean[rows][columns];
    }
     
    /**
     * Construct a regular dense matrix with an array.
     *
     * @param matrixValues an array of values
     */
    
    public DenseBooleanMatrix2D(boolean[][] matrixValues) throws IllegalArgumentException {
        if(matrixValues == null) {
            throw new IllegalArgumentException("Specify non-null input for the matrix values.");
        }
        if (matrixValues.length <= 0 || matrixValues[0].length <= 0) {
            throw new IllegalArgumentException("Error: numbers of rows and columns must both exceed 0.");
        }
        nRows = matrixValues.length;
        nColumns = matrixValues[0].length;
        if(nRows>1) {
            for(int i = 1; i < nRows; i++) {
                if(matrixValues[i].length>nColumns) {
                    nColumns = matrixValues[i].length;
                }
            }
        }
        this.matrixValues = matrixValues;
    }
    
    /*******************************************************************************
     *                                                                             *
     *                            ACCESSOR METHODS                                 *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Returns a deep copy of the current matrix.  Changes in one matrix are not reflected
     * in the other matrix.
     *
     * @return a deep copy of the current matrix.
     */
    
    public Matrix deepCopy() {
        //Create an empty matrix
        DenseBooleanMatrix2D newDenseMatrix = new DenseBooleanMatrix2D(nRows,nColumns);        
        for (int i = 0; i < nRows; i++) {
            for (int j = 0; j < matrixValues[i].length; j++) {
                newDenseMatrix.matrixValues[i][j] = matrixValues[i][j];
            }
        }
        newDenseMatrix.nRows = nRows;
        newDenseMatrix.nColumns = nColumns;
        return newDenseMatrix;
    }
    
    /**
     * Returns a deep copy of the current matrix in 1D form.  The matrix is filled
     * row-wise (i.e. one row at a time) and, in the case of a 3D matrix, from the 
     * top layer downwards.
     *
     * @return a deep copy in 1D form. 
     */
    
    public Matrix1D to1D() {
        int length = nRows*nColumns;
        boolean[] mat = new boolean[length];
        int index = 0;
        for(int i = 0; i < nRows; i++) {
            for(int j = 0; j < matrixValues[i].length; j++) {
                mat[index] = matrixValues[i][j];
                index++;
            }
        }
        return new DenseBooleanMatrix1D(mat);
    }    
    
    /**
     * Returns the array elements.
     *
     * @return the data array
     */
    
    public boolean[][] toArray() {
        return matrixValues;
    }
    
    /**
     * Returns the element value for the given internal row-column coordinates.
     *
     * @param a row index
     * @param b column index
     * @return element (a,b)
     */
    
    public boolean get(int a, int b) throws IndexOutOfBoundsException {
        return matrixValues[a][b];
    }      
    
    /**
     * Returns the specified row from the matrix.
     *
     * @param row the row index
     * @return the row
     */
    
    public Matrix1D getRowAt(int row) throws ArrayIndexOutOfBoundsException {
        return new DenseBooleanMatrix1D(matrixValues[row]);
    }

    /**
     * Returns the specified column from the matrix.
     *
     * @param column the column index
     * @return the column
     */
    
    public Matrix1D getColumnAt(int column) throws ArrayIndexOutOfBoundsException {
        DenseBooleanMatrix1D mat = new DenseBooleanMatrix1D(matrixValues.length);
        for(int i = 0; i < matrixValues.length; i++) {
            mat.set(i, matrixValues[i][column]);
        }
        return mat;
    }    

    /**
     * Returns a subset of the current matrix between (and including) the two rows.
     *
     * @param startRow the start row
     * @param endRow the end row
     * @return a subset of the current matrix by row
     */
    
    public Matrix2D getSubmatrixByRow(int startRow, int endRow) throws IllegalArgumentException {
        if(startRow < 0 || startRow > endRow || endRow >= nRows) {
            throw new IllegalArgumentException("Invalid submatrix requested.");
        }
        if(startRow == 0 && endRow == nRows-1) {
            return this;
        }
        int rowCount = endRow-startRow+1;
        boolean[][] newMatrix = new boolean[rowCount][nColumns];
        for(int i = 0; i < rowCount; i++) {
            newMatrix[i] = matrixValues[i+startRow];
        }
        return new DenseBooleanMatrix2D(newMatrix);
    }
    
    /**
     * Returns a subset of the current matrix between (and including) the two columns.
     *
     * @param startCol the start column
     * @param endCol the end column
     * @return a subset of the current matrix by column
     */
    
    public Matrix2D getSubmatrixByColumn(int startCol, int endCol) throws IllegalArgumentException {
        if(startCol < 0 || startCol > endCol || endCol >= nColumns) {
            throw new IllegalArgumentException("Invalid submatrix requested.");
        }
        if(startCol == 0 && endCol == nColumns-1) {
            return this;
        }
        int colStop = endCol-startCol+1;  //One more to include both column indices
        boolean[][] newMatrix = new boolean[nRows][colStop];
        for(int i = 0; i < nRows; i++) {
            for(int j = 0; j < colStop; j++) {
                newMatrix[i][j] = matrixValues[i][j+startCol];
            }
        }
        return new DenseBooleanMatrix2D(newMatrix);
    }  
    
    /*******************************************************************************
     *                                                                             *
     *                            MUTATOR METHODS                                  *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Used to set the element value with internal row-column coordinates.
     *
     * @param a row index
     * @param b column index 
     * @param value the value 
     */
    
    public void set(int a, int b, boolean value) throws IndexOutOfBoundsException {
        matrixValues[a][b] = value;
    }    

    /**
     * Returns the transpose of the current matrix as a new matrix object.
     *
     * @return the transpose of the current matrix.
     */
    
    public BooleanMatrix2D transpose() {
        
        //Create a dummy matrix for copying
        DenseBooleanMatrix2D newTranspose = new DenseBooleanMatrix2D(nColumns,nRows);
        
        //Copy the matrix        
        //Add the transposed values to the new matrix
        for (int i = 0; i < nRows; i++) {
            for (int j = 0; j < nColumns; j++) {
                newTranspose.matrixValues[j][i] = matrixValues[i][j];
            }
        }
        newTranspose.nRows=nRows;
        newTranspose.nColumns=nColumns;
        return newTranspose;
    }
    
    /**
     * Returns the matrix values as an array.
     *
     * @return the matrix values
     */
    
    public Object getMatrixValues() {
        return matrixValues;
    }
    
    /*******************************************************************************
     *                                                                             *
     *                             MUTATOR METHODS                                 *
     *                                                                             *
     ******************************************************************************/
        
    /**
     * Sets the matrix values with an array of primitives or throws an exception
     * if the object is incorrect.
     *
     * @param matrixValues the matrix values
     */
    
    public void setMatrixValues(Object matrixValues) throws IllegalArgumentException {
        if(!(matrixValues instanceof boolean[][])) {
            throw new IllegalArgumentException("Two dimensional array of booleans expected.");
        }
        boolean[][] vals = (boolean[][])matrixValues;
        if(vals.length != nRows) {
            throw new IllegalArgumentException("Incorrect number of rows: ["+nRows+": "+vals.length+"].");
        }
        if(vals[0].length != nColumns) {
            throw new IllegalArgumentException("Incorrect number of columns: ["+nColumns+": "+vals[0].length+"].");
        }        
        this.matrixValues = vals;
    }       
    
    /** 
     * Sets the matrix values to null (i.e. an empty matrix).
     */
    
    public void clearValues() {
        matrixValues = new boolean[nRows][nColumns];
    }       
    
    /**
     * Takes an input matrix and conflates with the current matrix, returning
     * either a copy or overwriting the existing matrix. Returns true for each
     * index whose current and input values are true, false otherwise.
     * 
     * @param input the input matrix
     * @param deepCopy is true to return the conflation in a copy
     * @return the conflated matrix
     * @throws ArrayIndexOutOfBoundsException if the dimensions of the current and input matrix are inconsistent
     */
    
    public BooleanMatrix conflate(BooleanMatrix input, boolean deepCopy) throws ArrayIndexOutOfBoundsException {
        if(!(input instanceof BooleanMatrix2D) || 
                ((BooleanMatrix2D)input).getRowCount()!=nRows || 
                ((BooleanMatrix2D)input).getColumnCount() != nColumns) {
            throw new ArrayIndexOutOfBoundsException("Requires a BooleanMatrix2D with "
                    + "'"+nRows+"' rows and '"+nColumns+"' columns as input ["+
                    ((BooleanMatrix2D)input).getRowCount()+","+((BooleanMatrix2D)input).getColumnCount()+"].");
        }
        BooleanMatrix2D returnMe = this;
        BooleanMatrix2D in = (BooleanMatrix2D)input;
        if(deepCopy) {
            returnMe = new DenseBooleanMatrix2D(nRows,nColumns);
        }
        for(int i = 0; i < nRows; i++) {
            for(int j = 0; j < nColumns; j++) {
                returnMe.set(i,j,get(i,j)&&in.get(i,j));
            }
        }
        return returnMe;
    }    
    
}

