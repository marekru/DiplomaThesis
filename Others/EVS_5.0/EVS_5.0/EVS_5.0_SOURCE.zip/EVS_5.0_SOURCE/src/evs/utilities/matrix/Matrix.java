package evs.utilities.matrix;

/**
 * An abstract base class for matrices.
 * 
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public abstract class Matrix implements java.io.Serializable {

/*******************************************************************************
 *                                                                             *
 *                            ACCESSOR METHODS                                 *
 *                                                                             *
 ******************************************************************************/      
   
    /**
     * Returns true if the input matrix has equivalent dimensions to this matrix.
     *
     * @param matrix the matrix for comparison
     * @return true if the matrices have equivalent dimensions
     */    
    
    public abstract boolean hasEquivalentDimensions(Matrix matrix);

    /**
     * Return the number of elements in the matrix domain.
     *
     * @return number of elements
     */
    
    public abstract int getElementCount();
    
    /**
     * Returns a deep copy of the current matrix.  Changes in one matrix are not reflected
     * in the other matrix.
     *
     * @return a deep copy of the receiver.
     */
    
    public abstract Matrix deepCopy();

    /**
     * Returns a deep copy of the current matrix in 1D form.  The matrix is filled
     * row-wise (i.e. one row at a time) and, in the case of a 3D matrix, from the 
     * top layer downwards.
     *
     * @return a deep copy in 1D form. 
     */
    
    public abstract Matrix1D to1D();
        
    /**
     * Returns the matrix values as a java array of primitives.
     *
     * @return the matrix values
     */
    
    public abstract Object getMatrixValues();    

    /**
     * Convenience method for returning a new dense matrix from a primitive Java 
     * array.  Throws an exception if the input is not recognised.
     *
     * @param input the input.
     * @return a new matrix.
     */
    
    public static Matrix createNewDenseMatrix(Object input) throws IllegalArgumentException {
        //1D matrices
        if(input instanceof double[]) {
            return new DenseDoubleMatrix1D(((double[])input));
        }
        else if(input instanceof int[]) {
            return new DenseIntegerMatrix1D(((int[])input));
        }
        //2D matrices
        if(input instanceof double[][]) {
            return new DenseDoubleMatrix2D(((double[][])input));
        }
        else if(input instanceof int[][]) {
            return new DenseIntegerMatrix2D(((int[][])input));
        }
        //3D matrices
        if(input instanceof double[][][]) {
            return new DenseDoubleMatrix3D(((double[][][])input));
        }
        else if(input instanceof int[][][]) {
            return new DenseIntegerMatrix3D(((int[][][])input));
        }
        else {
            throw new IllegalArgumentException("Cannot create a new dense matrix with the specified input: the input is of unrecognised type.");
        }
    }
    
/*******************************************************************************
 *                                                                             *
 *                             MUTATOR METHODS                                 *
 *                                                                             *
 ******************************************************************************/          
    
    /**
     * Sets the matrix values to null (i.e. an empty matrix).
     */
    
    public abstract void clearValues();
    
    /**
     * Sets the matrix values with an array of primitives or throws an exception
     * if the object is incorrect.
     *
     * @param matrixValues the matrix values
     */
    
    public abstract void setMatrixValues(Object matrixValues) throws IllegalArgumentException;
    
}
