package evs.utilities.matrix;

/**
 * An interface for matrices of booleans.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public interface BooleanMatrix {
    
    /**
     * Takes an input matrix and conflates with the current matrix, returning
     * either a copy or overwriting the existing matrix. Returns true for each
     * index whose current and input values are true, false otherwise.
     * 
     * @param input the input matrix
     * @param deepCopy is true to return the conflation in a copy
     * @return the conflated matrix
     * @throws ArrayIndexOutOfBoundsException if the dimensions of the current and input matrix are inconsistent
     */
    
    public BooleanMatrix conflate(BooleanMatrix input, boolean deepCopy) throws ArrayIndexOutOfBoundsException;
    
}
