package evs.utilities.mathutil;

/**
 * Interface that represents a function object: a function that takes
 * a single, double valued, argument and returns a single value.
 */

public interface DoubleFunction extends DoubleOperation {

    /**
     * Applies a function to an argument.
     *
     * @param argument argument passed to the function.
     * @return the result of the function.
     */
    
    abstract double apply(double argument);

    /**
     * Returns any constants defined on construction of the function.  When
     * functions are chained, the constants should be returned from inner functions
     * to outer functions, with the innermost function at the start of the returned
     * array, and working from left to right if an outer function operates on two or more
     * inner functions together. For example, f( g(a), h(b) ) would return constants
     * for functions g, h, and f in that order.
     *
     * @return the input parameter value
     */

    abstract double[] getConstants();
    
}

