package evs.utilities.matrix;

/**
 * An abstract base class for 3D matrices.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public abstract class Matrix3D extends Matrix {

    /**
     * Number of rows in the matrix.
     */
    
    protected int nRows = 0;
    
    /**
     * Number of columns in the matrix.
     */
    
    protected int nColumns = 0;
    
    /**
     * Depth of the matrix.
     */
    
    protected int nDepth = 0;

/*******************************************************************************
 *                                                                             *
 *                              ACCESSOR METHODS                               *
 *                                                                             *
 ******************************************************************************/      

    /**
     * Returns true if the input matrix has equivalent dimensions to this matrix.
     *
     * @param matrix the matrix for comparison
     * @return true if the matrices have equivalent dimensions
     */   
    
    public boolean hasEquivalentDimensions(Matrix matrix) {        
        if(! (matrix instanceof Matrix3D) ) {
            return false;
        }
        return ((Matrix3D)matrix).getRowCount() == nRows && ((Matrix3D)matrix).getColumnCount() == nColumns && ((Matrix3D)matrix).getMatrixDepth() == nDepth;
    }

    /**
     * Returns the number of accessible rows in the matrix.
     *
     * @return number of rows
     */
    
    public int getRowCount() {
        return nRows;
    }
    
    /**
     * Returns the number of columns in the matrix.
     *
     * @return number of columns
     */
    
    public int getColumnCount() {
        return nColumns;
    }
    
    /**
     * Returns the depth of the matrix.
     *
     * @return depth of the matrix
     */
    
    public int getMatrixDepth() {
        return nDepth;
    }
    
    /**
     * Return the number of elements in the matrix domain.
     *
     * @return number of elements
     */
    
    public int getElementCount() {
        return nRows * nColumns * nDepth;
    }
    
}
