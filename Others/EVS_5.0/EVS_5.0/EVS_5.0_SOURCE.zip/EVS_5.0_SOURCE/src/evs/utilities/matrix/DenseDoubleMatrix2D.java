package evs.utilities.matrix;

//Java dependencies
import java.util.Vector;
import java.util.Arrays;

//EVS dependencies
import evs.utilities.mathutil.DoubleProcedure;
import evs.utilities.mathutil.DoubleFunction;
import evs.utilities.mathutil.VectorFunction;
import evs.utilities.mathutil.DoubleDoubleFunction;

/**
 * A dense 2D matrix of double values.  
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DenseDoubleMatrix2D extends DoubleMatrix2D {
    
    /**
     * Store the matrix values
     */
    
    private double[][] matrixValues = null;
    
    /**
     * Compass direction for concatenation of matrices: north
     */
    
    public static final int N = 100;
    
    /**
     * Compass direction for concatenation of matrices: south
     */
    
    public static final int S = 101;

    /**
     * Compass direction for concatenation of matrices: east
     */
    
    public static final int E = 102;
    
    /**
     * Compass direction for concatenation of matrices: west
     */
    
    public static final int W = 103;
    
    /**
     * Compass direction for concatenation of matrices: north east
     */
    
    public static final int NE = 104;
    
    /**
     * Compass direction for concatenation of matrices: north west
     */
    
    public static final int NW = 105;
    
    /**
     * Compass direction for concatenation of matrices: south east
     */
    
    public static final int SE = 106;
    
    /**
     * Compass direction for concatenation of matrices: south west
     */
    
    public static final int SW = 107;
        
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTORS                                  *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Construct a regular matrix.
     *
     * @param rows the number of rows in the dense matrix
     * @param columns the number of columns in the dense matrix
     */
    
    public DenseDoubleMatrix2D(int rows, int columns) throws IllegalArgumentException {
        if (rows <= 0 || columns <= 0) {
            throw new IllegalArgumentException("Error: numbers of rows and columns must both exceed 0.");
        }
        nRows = rows;
        nColumns = columns;
        matrixValues = new double[rows][columns];
    }
    
    /**
     * Construct a regular dense matrix with an array.
     *
     * @param matrixValues an array of values
     */
    
    public DenseDoubleMatrix2D(double[][] matrixValues) throws IllegalArgumentException {
        if(matrixValues == null) {
            throw new IllegalArgumentException("Specify non-null input for the matrix values.");
        }
        if (matrixValues.length <= 0 || matrixValues[0].length <= 0) {
            throw new IllegalArgumentException("Error: numbers of rows and columns must both exceed 0.");
        }
        nRows = matrixValues.length;
        nColumns = matrixValues[0].length;
        if(nRows>1) {
            for(int i = 1; i < nRows; i++) {
                if(matrixValues[i]==null) {
                    throw new IllegalArgumentException("Row "+i+" of the input was null, which is not allowed.");
                }
                if(matrixValues[i].length>nColumns) {
                    nColumns = matrixValues[i].length;
                }
            }
        }
        this.matrixValues = matrixValues;
    }
    
    /*******************************************************************************
     *                                                                             *
     *                            ACCESSOR METHODS                                 *
     *                                                                             *
     ******************************************************************************/

    /**
     * Returns a deep copy of the current matrix.  Changes in one matrix are not reflected
     * in the other matrix.
     *
     * @return a deep copy of the current matrix.
     */
    
    public Matrix deepCopy() {
        //Create an empty matrix
        double[][] returnMe = new double[nRows][];
        for (int i = 0; i < nRows; i++) {
            returnMe[i]=new double[matrixValues[i].length];
            System.arraycopy(matrixValues[i],0,returnMe[i],0,returnMe[i].length);
        }
        DenseDoubleMatrix2D newDenseMatrix = new DenseDoubleMatrix2D(returnMe);
        newDenseMatrix.nRows = nRows;
        newDenseMatrix.nColumns = nColumns;
        return newDenseMatrix;
    }
    
    /**
     * Returns a deep copy of the current matrix in 1D form.  The matrix is filled
     * row-wise (i.e. one row at a time) and, in the case of a 3D matrix, from the 
     * top layer downwards.
     *
     * @return a deep copy in 1D form. 
     */
    
    public Matrix1D to1D() {
        int length = nRows*nColumns;
        double[] mat = new double[length];
        int index = 0;
        for(int i = 0; i < nRows; i++) {
            for(int j = 0; j < matrixValues[i].length; j++) {
                mat[index] = matrixValues[i][j];
                index++;
            }
        }
        return new DenseDoubleMatrix1D(mat);
    }   
    
    /**
     * Returns the array elements.
     *
     * @return the data array
     */
    
    public double[][] toArray() {
        return matrixValues;
    }
    
    /**
     * Returns the element value for the given internal row-column coordinates.
     *
     * @param a row index
     * @param b column index
     * @return element (a,b)
     */
    
    public double get(int a, int b) throws IndexOutOfBoundsException {
        return matrixValues[a][b];
    }      
    
    /**
     * Returns the specified row from the matrix.
     *
     * @param row the row index
     * @return the row
     */
    
    public Matrix1D getRowAt(int row) throws ArrayIndexOutOfBoundsException {
        return new DenseDoubleMatrix1D(matrixValues[row]);
    }

    /**
     * Returns the specified column from the matrix.
     *
     * @param column the column index
     * @return the column
     */
    
    public Matrix1D getColumnAt(int column) throws ArrayIndexOutOfBoundsException {
        DenseDoubleMatrix1D mat = new DenseDoubleMatrix1D(matrixValues.length);
        for(int i = 0; i < matrixValues.length; i++) {
            mat.set(i, matrixValues[i][column]);
        }
        return mat;
    }    
        
    /**
     * Returns a subset of rows in which the specified column meets the specified
     * condition or throws an exception if the column index is out of range or 
     * no such rows exist.  If the column contains the avoid number, the corresponding
     * row is not returned. The existing matrix remains unchanged.
     * 
     * @param condition the condition
     * @param col the column
     * @param avoid a number to avoid (may be null)
     * @return the rows in which the specified column value meets the condition
     */
    
    public DoubleMatrix2D subRowsbyColCond(DoubleProcedure condition, int col, Double avoid) throws IllegalArgumentException {
        if(col < 0 || col > (nColumns-1)) {
            throw new IllegalArgumentException("Invalid column index: [0:"+(nColumns-1)+"] allowed.");
        }
        DoubleMatrix2D t = (DoubleMatrix2D)getSubmatrixByColumn(col,col);
        return subRowsbyCondition(condition, t, avoid, false);        
    }

    /**
     * Returns a subset of rows in which any of the columns meets the specified
     * condition or throws an exception if no such rows exist.  Optionally,
     * the function may be inverted, such that the opposite rows are returned.
     * The condition is not evaluated for a column whose value equals the non-null
     * avoid number.
     *
     * @param condition the condition
     * @param avoid a number to avoid (may be null)
     * @param invert is true to inverse the function
     * @return the rows in which the specified column value meets the condition
     */

    public DoubleMatrix2D subRowsbyColCond(DoubleProcedure condition, Double avoid, boolean invert) throws IllegalArgumentException {
        return subRowsbyCondition(condition,this, avoid, invert);
    }

    /**
     * Returns a subset of rows that meet the row condition after applying the
     * specified row function.
     *
     * @param condition the row condition
     * @param rowFunc the row function
     * @param startCol the start column at which to apply the row function
     * @param endCol the end column at which to apply the row function
     * @param avoid a number to avoid (may be null)
     * @return the rows that meet the specified condition
     */

    public DoubleMatrix2D subRowsbyRowCond(DoubleProcedure condition,VectorFunction rowFunc,int startCol,int endCol,Double avoid) throws IllegalArgumentException {
        DoubleMatrix1D byRow = assignByRow(rowFunc, avoid, startCol, endCol);
        DoubleMatrix2D t = new DenseDoubleMatrix2D(new double[][]{byRow.toArray()}).transpose();
        return subRowsbyCondition(condition, t, avoid, false);
    }

    /*******************************************************************************
     *                                                                             *
     *                            MUTATOR METHODS                                  *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Used to set the element value with internal row-column coordinates.
     *
     * @param a row index
     * @param b column index 
     * @param value the value 
     */
    
    public void set(int a, int b, double value) throws IndexOutOfBoundsException {
        matrixValues[a][b] = value;
    }    

    /**
     * Returns the transpose of the current matrix as a new matrix object.
     *
     * @return the transpose of the current matrix.
     */
    
    public DoubleMatrix2D transpose() {
        
        //Create a dummy matrix for copying
        DenseDoubleMatrix2D newTranspose = new DenseDoubleMatrix2D(nColumns,nRows);
        
        //Copy the matrix
        //Add the transposed values to the new matrix
        for (int i = 0; i < nRows; i++) {
            for (int j = 0; j < matrixValues[i].length; j++) {
                newTranspose.matrixValues[j][i] = matrixValues[i][j];
            }
        }
        return newTranspose;
    }

    /**
     * Assigns a function to each element in the matrix.  This implementation is
     * based on that in cern.colt.matrix class.  For example, to multiply every element
     * in the matrix by a number x:
     *
     * Functions F = Functions.functions;
     * DoubleFunction a = F.mult(x);
     * myMatrix.assign(a);
     *
     * @param function a function to assign
     * @param overwrite is true to overwrite the existing matrix
     * @return this matrix modified by the function
     */

    public DoubleMatrix assign(DoubleFunction function, boolean overwrite) throws ArithmeticException, IllegalArgumentException {
        DenseDoubleMatrix2D newMatrix = null;
        if(overwrite) {
            newMatrix = (DenseDoubleMatrix2D)this;
        }
        else {
            newMatrix = (DenseDoubleMatrix2D)deepCopy();
        }
        for(int i = 0; i < nRows; i++) {
            for(int j = 0; j < matrixValues[i].length; j++) {
                newMatrix.matrixValues[i][j]=function.apply(matrixValues[i][j]);
            }
        }
        return newMatrix;
    }

    /**
     * Assigns a function to each element in the matrix ignoring a specified value.
     * This implementation is based on that in cern.colt.matrix class.  For example,
     * to multiply every element in the matrix by a number x:
     *
     * Functions F = Functions.functions;
     * DoubleFunction a = F.mult(x);
     * myMatrix.assign(a);
     *
     * @param function a function to assign
     * @param overwrite is true to overwrite the existing matrix
     * @param avoid a number to avoid
     * @return this matrix modified by the function
     */

    public DoubleMatrix assign(DoubleFunction function, boolean overwrite, double avoid) throws ArithmeticException, IllegalArgumentException {
        return assign(function,overwrite,avoid,0,0,nRows-1,nColumns-1);
    }

    /**
     * Applies a binary function to the current matrix and a numeric input matrix.
     *
     * @param input a matrix with identical dimensions
     * @param function a binary function
     * @return this f.apply(this, input)
     */

    public DoubleMatrix assign(DoubleMatrix input, DoubleDoubleFunction function, boolean overwrite) throws ArithmeticException, IllegalArgumentException {
        if(!hasEquivalentDimensions((Matrix)input)) {
            throw new IllegalArgumentException("Error: the matrix dimensions are inconsistent.");
        }
        DenseDoubleMatrix2D newMatrix = null;
        //Overwrite the existing matrix
        if(overwrite) {
            newMatrix = (DenseDoubleMatrix2D)this;
        }
        else {
            newMatrix = (DenseDoubleMatrix2D)deepCopy();
        }
        for(int i = 0; i < nRows; i++) {
            for(int j = 0; j < matrixValues[i].length; j++) {
                newMatrix.matrixValues[i][j]=function.apply(matrixValues[i][j],((DoubleMatrix2D)input).get(i,j));
            }
        }
        return newMatrix;
    }

    /**
     * Applies a binary function to the current matrix and a numeric input matrix,
     * ignoring the specified value in the current matrix.
     *
     * @param input a 2D matrix with identical dimensions
     * @param function a binary function
     * @param overwrite is true to assign the result to the current matrix, false for a deep copy
     * @param avoid a number to avoid
     * @return this f.apply(this, input)
     */

    public DoubleMatrix assign(DoubleMatrix input, DoubleDoubleFunction function, boolean overwrite, double avoid) throws ArithmeticException, IllegalArgumentException {
        if(!(input instanceof Matrix2D)) {
            throw new IllegalArgumentException("Error: the matrix dimensions are inconsistent.");
        }
        return assign((DoubleMatrix2D)input,function,overwrite,avoid,0,0,nRows-1,nColumns-1);
    }

    /**
     * Applies a double function to the current matrix ignoring the specified value
     * in the current matrix.  Specify a sub-matrix on which to apply the function.
     * The rows and columns defined by the boundaries are included in the calculation.
     * The result may be assigned to the current matrix, in which case the cells
     * outside the sub-matrix will remain unchanged. Otherwise, they will contain
     * the default double value.
     *
     * @param function a function
     * @param overwrite is true to assign the result to the current matrix, false for a deep copy
     * @param avoid a number to avoid
     * @param startRow the start row
     * @param startCol the start column
     * @param endRow the end row
     * @param endCol the end column
     * @return this f.apply(this, input)
     */

    public DoubleMatrix2D assign(DoubleFunction function,
            boolean overwrite, double avoid, int startRow, int startCol, int endRow, int endCol)
            throws ArithmeticException, IllegalArgumentException, ArrayIndexOutOfBoundsException {
        if(startRow<0 || startCol<0 || endRow >= nRows ||
                endCol >= nColumns) {
            throw new ArrayIndexOutOfBoundsException("Invalid submatrix for assign function.");
        }
        DenseDoubleMatrix2D newMatrix = null;
        if(overwrite) {
            newMatrix = (DenseDoubleMatrix2D)this;
        }
        else {
            newMatrix = (DenseDoubleMatrix2D)deepCopy();
        }
        for(int i = startRow; i <= endRow; i++) {
            for(int j = startCol; j <= endCol; j++) {
                if(matrixValues[i][j] != avoid) newMatrix.matrixValues[i][j]=function.apply(matrixValues[i][j]);
                else newMatrix.matrixValues[i][j] = avoid;
            }
        }
        return newMatrix;
    }

    /**
     * Applies a double function to the current matrix and a numeric input matrix,
     * ignoring the specified value in the current matrix.  Specify a sub-matrix
     * on which to apply the function. The rows and columns defined by the boundaries
     * are included in the calculation. The result may be assigned to the current matrix,
     * in which case the cells outside the sub-matrix will remain unchanged. Otherwise,
     * they will contain the default double value.
     *
     * @param input a matrix with identical dimensions
     * @param function a function
     * @param overwrite is true to assign the result to the current matrix, false for a deep copy
     * @param avoid a number to avoid
     * @param startRow the start row
     * @param startCol the start column
     * @param endRow the end row
     * @param endCol the end column
     * @return this f.apply(this, input)
     */

    public DoubleMatrix2D assign(DoubleMatrix2D input, DoubleDoubleFunction function,
            boolean overwrite, double avoid, int startRow, int startCol, int endRow, int endCol)
            throws ArithmeticException, IllegalArgumentException, ArrayIndexOutOfBoundsException {
        if(startRow<0 || startCol<0 || endRow >= nRows ||
                endCol >= nColumns) {
            throw new ArrayIndexOutOfBoundsException("Invalid submatrix for assign function.");
        }
        if(!hasEquivalentDimensions((Matrix)input)) {
            throw new IllegalArgumentException("Error: the matrix dimensions are inconsistent.");
        }
        DenseDoubleMatrix2D newMatrix = null;
        //Overwrite the existing matrix
        if(overwrite) {
            newMatrix = (DenseDoubleMatrix2D)this;
        }
        //Create a new matrix
        else {
            newMatrix = (DenseDoubleMatrix2D)deepCopy();
        }
        for(int i = startRow; i <= endRow; i++) {
            for(int j = startCol; j <= endCol; j++) {
                double in = input.get(i,j);
                if(matrixValues[i][j] != avoid && in !=avoid) newMatrix.matrixValues[i][j]=function.apply(matrixValues[i][j],in);
                else newMatrix.matrixValues[i][j]=avoid;
            }
        }
        return newMatrix;
    }

    /**
     * Assigns a vector function row-wise. Transpose first to assign column-wise.
     *
     * @param function a vector function
     * @return a 1D matrix with as many elements as rows in the input, each containing
     * the result of applying the vector function to that row
     */

    public DoubleMatrix1D assignByRow(VectorFunction function) throws ArithmeticException {
        if(function==null) {
            throw new IllegalArgumentException("Specify a non-null function to assign by row.");
        }
        DenseDoubleMatrix1D result = new DenseDoubleMatrix1D(nRows);
        for(int i = 0; i < nRows; i++) {
            result.set(i,function.apply(getRowAt(i)));
        }
        return result;
    }

    /**
     * Assigns a vector function row-wise. Transpose first to assign column-wise.
     *
     * @param function a vector function
     * @param avoid a number to ignore
     * @return a 1D matrix with as many elements as rows in the input, each containing
     * the result of applying the vector function to that row
     */

    public DoubleMatrix1D assignByRow(VectorFunction function, double avoid) throws ArithmeticException {
        if(function==null) {
            throw new IllegalArgumentException("Specify a non-null function to assign by row.");
        }
        DenseDoubleMatrix1D result = new DenseDoubleMatrix1D(nRows);
        for(int i = 0; i < nRows; i++) {
            result.set(i,function.apply(getRowAt(i),avoid));
        }
        return result;
    }

    /**
     * Assigns a vector function row-wise. Transpose first to assign column-wise.
     *
     * @param function a vector function
     * @param avoid a number to avoid
     * @param start the start column index
     * @param end the end column index
     * @return a 1D matrix with as many elements as rows in the input, each containing
     * the result of applying the vector function to that row
     */

    public DoubleMatrix1D assignByRow(VectorFunction function, double avoid, int start, int end)
            throws ArithmeticException {
        if(function==null) {
            throw new IllegalArgumentException("Specify a non-null function to assign by row.");
        }
        DenseDoubleMatrix1D result = new DenseDoubleMatrix1D(nRows);
        for (int i = 0; i < nRows; i++) {
            result.set(i, function.apply(getRowAt(i).getSubmatrixByRow(start,end), avoid));
        }
        return result;
    }

    /**
     * Inserts a specified row or column into the matrix and returns the deep
     * copied matrix.
     *
     * @param insertMe the row or column to insert
     * @param index the zero based index at which to insert
     * @param isRow is true if the insertion is a row, false for column
     * @return the deep copied matrix with the inserted vector
     */

    public DoubleMatrix2D insert(DoubleMatrix1D insertMe, int index,boolean isRow) throws ArrayIndexOutOfBoundsException {
        double[][] rMe = null;
        //Convert to row view if required
        if(isRow) {
            rMe = toArray();
        } else {
            rMe = transpose().toArray();
        }
        int rows = rMe.length+1;
        int cols = rMe[0].length;

        //Insert the row
        double[][] returnMe = new double[rows][cols];
        for(int i = 0; i < rows; i++) {
            if(i<index) {
                System.arraycopy(rMe[i],0,returnMe[i],0,
                        rMe[i].length);
            }
            else if(i == index) {
                System.arraycopy(insertMe.toArray(),0,returnMe[i],0,
                        insertMe.getRowCount());
            } else {
                System.arraycopy(rMe[i-1],0,returnMe[i],0,
                        rMe[i-1].length);
            }
        }
        if(isRow) {
            return new DenseDoubleMatrix2D(returnMe);
        }
        return new DenseDoubleMatrix2D(returnMe).transpose();
    }

    /**
     * Removes a specified row or column from the matrix and returns the deep
     * copied matrix.
     *
     * @param removeMe the row or column index to remove
     * @param isRow is true to remove a row, false to remove a column
     * @return the deep copied matrix with the removed vector
     */

    public DoubleMatrix2D remove(int removeMe,boolean isRow) throws ArrayIndexOutOfBoundsException {
        double[][] rMe = null;
        //Convert to row view if required
        if(isRow) {
            rMe = toArray();
        } else {
            rMe = transpose().toArray();
        }
        int rows = rMe.length-1;
        int cols = rMe[0].length;

        //Remove the row
        double[][] returnMe = new double[rows][cols];
        for(int i = 0; i < rMe.length; i++) {
            if(i<removeMe) {
                System.arraycopy(rMe[i],0,returnMe[i],0,
                        rMe[i].length);
            }
            else if(i>removeMe){
                System.arraycopy(rMe[i],0,returnMe[i-1],0,
                        rMe[i].length);
            }
        }
        if(isRow) {
            return new DenseDoubleMatrix2D(returnMe);
        }
        return new DenseDoubleMatrix2D(returnMe).transpose();
    }

    /**
     * Concatenates this matrix with another matrix, placing the input matrix in a 
     * specified compass direction relative to the current matrix. See the 
     * {@link #appendRowsShallow(evs.utilities.matrix.DoubleMatrix2D)} method
     * for a shallow copy appendRowsShallow method that consumes much less memory.
     *
     * TODO: place an abstract method in a parent class and implement for other
     * matrices.
     *
     * @param input the input matrix
     * @param direction the concatenation direction
     */
    
    public DoubleMatrix2D concatenate(DoubleMatrix2D input, int direction) {
        return concatenate(input,direction,0.0);
    }

    /**
     * Concatenates this matrix with another matrix, placing the input matrix in a
     * specified compass direction relative to the current matrix. See the
     * {@link #appendRowsShallow(evs.utilities.matrix.DoubleMatrix2D)} method
     * for a shallow copy appendRowsShallow method that consumes much less memory.
     * Specify a null value to place in areas where the input matrix and current
     * matrix differ in size.
     *
     * TODO: place an abstract method in a parent class and implement for other
     * matrices.
     *
     * @param input the input matrix
     * @param direction the concatenation direction
     * @return the concatenated matrix
     */

    public DoubleMatrix2D concatenate(DoubleMatrix2D input, int direction, double nV) {
        double[][] c = null;
        double[][] in = input.toArray();
        int rows = nRows;
        int cols = nColumns;
        int inRows = input.nRows;
        int inCols = input.nColumns;
        int cMax = Math.max(cols,inCols);
        int rMax = Math.max(rows,inRows);
        switch(direction) {
            case N: {
                c = new double[rows+inRows][cMax];

                //Could speed up by filling null values 
                //as part of the existing loop over data: 
                //this applies to all concatenation directions
                for(double[] n : c) {
                    Arrays.fill(n,nV);
                }
                //Current data
                int startRow = inRows;
                int stop = rows+inRows;
                int rw = 0;
                for(int i = startRow; i < stop; i++) {
                    for(int j = 0; j < cols; j++) {
                        c[i][j] = matrixValues[rw][j];
                    }
                    rw++;
                }
                //Concatenation data
                for(int i = 0; i < inRows; i++) {
                    for(int j = 0; j < inCols; j++) {
                        c[i][j] = in[i][j];
                    }
                }
            }; break;
            case S: {
                c = new double[rows+inRows][cMax];
                for(double[] n : c) {
                    Arrays.fill(n,nV);
                }
                //Current data
                for(int i = 0; i < rows; i++) {
                    for(int j = 0; j < cols; j++) {
                        c[i][j] = matrixValues[i][j];
                    }
                }
                //Concatenation data
                int startRow = rows;
                int stop = rows+inRows;
                int rw = 0;
                for(int i = startRow; i < stop; i++) {
                    for(int j = 0; j < inCols; j++) {
                        c[i][j] = in[rw][j];
                    }
                    rw++;
                }
            }; break;
            case E: {
                c = new double[rMax][cols+inCols];
                for(double[] n : c) {
                    Arrays.fill(n,nV);
                }
                //Current data
                for(int i = 0; i < rows; i++) {
                    for(int j = 0; j < cols; j++) {
                        c[i][j] = matrixValues[i][j];
                    }
                }
                //Concatenation data
                int startCol = cols;
                int stop = cols+inCols;
                for(int i = 0; i < inRows; i++) {
                    int cl = 0;
                    for(int j = startCol; j < stop; j++) {
                        c[i][j] = in[i][cl];
                        cl++;
                    }
                }
            }; break;
            case W: {
                c = new double[rMax][cols+inCols];
                for(double[] n : c) {
                    Arrays.fill(n,nV);
                }
                //Current data
                int startCol = inCols;
                int stop = cols+inCols;
                for(int i = 0; i < rows; i++) {
                    int cl = 0;
                    for(int j = startCol; j < stop; j++) {
                        c[i][j] = matrixValues[i][cl];
                        cl++;
                    }
                }
                //Concatenation data
                for(int i = 0; i < inRows; i++) {
                    for(int j = 0; j < inCols; j++) {
                        c[i][j] = in[i][j];
                    }
                }
            }; break;
            case NE: {
                c = new double[rows+inRows][cols+inCols];
                for(double[] n : c) {
                    Arrays.fill(n,nV);
                }
                //Current data
                int startRow = inRows;
                int stop = rows+inRows;
                int rw = 0;
                for(int i = startRow; i < stop; i++) {
                    for(int j = 0; j < cols; j++) {
                        c[i][j] = matrixValues[rw][j];
                    }
                    rw++;
                }
                //Concatenation data
                int startCol = cols;
                int stp = cols + inCols;
                for(int i = 0; i < inRows; i++) {
                    int cl = 0;
                    for(int j = startCol; j < stp; j++) {
                        c[i][j] = in[i][cl];
                        cl++;
                    }
                }
            }; break;
            case NW: {
                c = new double[rows+inRows][cols+inCols];
                for(double[] n : c) {
                    Arrays.fill(n,nV);
                }
                //Current data
                int startRow = inRows;
                int stopRow = rows + inRows;
                int stopCol = cols + inCols;
                int rw = 0;
                for(int i = startRow; i < stopRow; i++) {
                    int cl = 0;
                    for(int j = inCols; j < stopCol; j++) {
                        c[i][j] = matrixValues[rw][cl];
                        cl++;
                    }
                    rw++;
                }
                //Concatenation data
                for(int i = 0; i < inRows; i++) {
                    for(int j = 0; j < inCols; j++) {
                        c[i][j] = in[i][j];
                    }
                }
            }; break;
            case SE: {
                c = new double[rows+inRows][cols+inCols];
                for(double[] n : c) {
                    Arrays.fill(n,nV);
                }
                //Current data
                for(int i = 0; i < rows; i++) {
                    for(int j = 0; j < cols; j++) {
                        c[i][j] = matrixValues[i][j];
                    }
                }
                //Concatenation data
                int startRow = rows;
                int stopRow = rows + inRows;
                int stopCol = cols + inCols;
                int rw = 0;
                for(int i = startRow; i < stopRow; i++) {
                    int cl = 0;
                    for(int j = cols; j < stopCol; j++) {
                        c[i][j] = in[rw][cl];
                        cl++;
                    }
                    rw++;
                }
            }; break;
            case SW: {
                c = new double[rows+inRows][cols+inCols];
                for(double[] n : c) {
                    Arrays.fill(n,nV);
                }
                //Current data
                int startCol = inCols;
                int stp = cols + inCols;
                for(int i = 0; i < rows; i++) {
                    int cl = 0;
                    for(int j = startCol; j < stp; j++) {
                        c[i][j] = matrixValues[i][cl];
                        cl++;
                    }
                }
                //Concatenation data
                int startRow = rows;
                int stop = rows + inRows;
                int rw = 0;
                for(int i = startRow; i < stop; i++) {
                    for(int j = 0; j < inCols; j++) {
                        c[i][j] = in[rw][j];
                    }
                    rw++;
                }
            }; break;
        }
        return new DenseDoubleMatrix2D(c);
    }
    
    /**
     * Performs a shallow appendRowsShallow on the current matrix and an input matrix,
     * appending the input to the bottom of the current matrix and copying both
     * row-wise (i.e. only pointers to rows are duplicated in memory).  The input
     * matrix must have the same number of columns as the current matrix
     * 
     * @param input the input matrix
     * @return a shallow appended matrix
     */ 
    
    public DoubleMatrix2D appendRowsShallow(DoubleMatrix2D input) throws IllegalArgumentException {
        if(input == null) {
            throw new IllegalArgumentException("Invalid input for the append operation.");
        }
        if(input.getColumnCount()!=nColumns) {
            throw new IllegalArgumentException("The input must have the same number of columns as the current matrix to append: ["+input.getColumnCount()+","+nColumns+"].");
        }
        double[][] newArr = new double[nRows+input.getRowCount()][];
        for(int i = 0; i < matrixValues.length; i++) {
            newArr[i]=matrixValues[i];
        }
        double[][] vals = input.toArray();
        int start = matrixValues.length;
        for(int i = 0; i < vals.length; i++) {
            newArr[start+i]=vals[i];
        }
        return new DenseDoubleMatrix2D(newArr);
    }

    /**
     * Returns a subset of the current matrix between (and including) the two rows.
     *
     * @param startRow the start row
     * @param endRow the end row
     * @return a subset of the current matrix by row
     */
    
    public Matrix2D getSubmatrixByRow(int startRow, int endRow) throws IllegalArgumentException {
        if(startRow < 0 || startRow > endRow || endRow >= nRows) {
            throw new IllegalArgumentException("Invalid submatrix requested.");
        }
        if(startRow == 0 && endRow == nRows-1) {
            return this;
        }
        int rowCount = endRow-startRow+1;
        double[][] newMatrix = new double[rowCount][nColumns];
        for(int i = 0; i < rowCount; i++) {
            newMatrix[i] = matrixValues[i+startRow];
        }
        return new DenseDoubleMatrix2D(newMatrix);
    }
    
    /**
     * Returns a subset of the current matrix between (and including) the two columns.
     *
     * @param startCol the start column
     * @param endCol the end column
     * @return a subset of the current matrix by column
     */
    
    public Matrix2D getSubmatrixByColumn(int startCol, int endCol) throws IllegalArgumentException {
        if(startCol < 0 || startCol > endCol || endCol >= nColumns) {
            throw new IllegalArgumentException("Invalid submatrix requested.");
        }
        if(startCol == 0 && endCol == nColumns-1) {
            return this;
        }
        int colStop = endCol-startCol+1;  //One more to include both column indices
        double[][] newMatrix = new double[nRows][colStop];
        for(int i = 0; i < nRows; i++) {
            for(int j = 0; j < colStop; j++) {
                newMatrix[i][j] = matrixValues[i][(j+startCol)];
            }
        }
        return new DenseDoubleMatrix2D(newMatrix);
    }
    
    /**
     * Returns the matrix values as a java array of primitives.
     *
     * @return the matrix values
     */
    
    public Object getMatrixValues() {
        return matrixValues;
    }
    
    /*******************************************************************************
     *                                                                             *
     *                             MUTATOR METHODS                                 *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Sets the matrix values as an array of primitives or throws an exception
     * if the object is incorrect.
     *
     * @param matrixValues the matrix values
     */
    
    public void setMatrixValues(Object matrixValues) throws IllegalArgumentException {
        if(!(matrixValues instanceof double[][])) {
            throw new IllegalArgumentException("Two dimensional array of doubles expected.");
        }
        double[][] vals = (double[][])matrixValues;
        if(vals.length != nRows) {
            throw new IllegalArgumentException("Incorrect number of rows: ["+nRows+": "+vals.length+"].");
        }
        if(vals[0].length != nColumns) {
            throw new IllegalArgumentException("Incorrect number of columns: ["+nColumns+": "+vals[0].length+"].");
        }        
        this.matrixValues = vals;
    }       
    
    /** 
     * Sets the matrix values to null (i.e. an empty matrix).
     */
    
    public void clearValues() {
        matrixValues = new double[nRows][nColumns];
    }

    /**
     * Returns a subset of rows in which any of the columns in the associated
     * column matrix meets the specified condition or throws an exception if no
     * such rows exist.
     *
     * @param condition the condition
     * @param col the matrix to test with as many rows as the current matrix
     * @param avoid a number to avoid (may be null)
     * @param invert is true to inverse the function
     * @return the rows in which the specified column value meets the condition
     */

    private DoubleMatrix2D subRowsbyCondition(DoubleProcedure condition,DoubleMatrix2D col, Double avoid, boolean invert) throws IllegalArgumentException {
        Vector<double[]> result = new Vector();
        int nCols = col.getColumnCount();
        for(int i = 0; i < nRows; i++) {
            double[] addMe = null;
            for (int j = 0; j < nCols; j++) {
                double test = col.get(i, j);
                if (avoid == null || test != avoid) {
                    if (condition.apply(test)) {
                        addMe = matrixValues[i];
                        break;
                    }
                }
            }
            if(invert && addMe==null) {
                result.add(matrixValues[i]);
            } else if(!invert && addMe!=null) {
                result.add(addMe);
            }
        }
        int rs = result.size();
        if(rs==0) {
            throw new IllegalArgumentException("No rows meet the specified column condition.");
        }
        double[][] sub = new double[rs][];
        for(int i = 0; i < rs; i++) {
            sub[i]=result.get(i);
        }
        return new DenseDoubleMatrix2D(sub);
    }


    
}

