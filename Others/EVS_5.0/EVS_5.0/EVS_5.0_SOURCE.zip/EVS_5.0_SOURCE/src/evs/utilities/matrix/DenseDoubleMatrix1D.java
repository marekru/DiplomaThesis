package evs.utilities.matrix;

import evs.utilities.mathutil.DoubleFunction;
import evs.utilities.mathutil.DoubleDoubleFunction;

/**
 * A dense 1D matrix of double values.  
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DenseDoubleMatrix1D extends DoubleMatrix1D {
    
    /**
     * Store the matrix values 
     */
    
    private double[] matrixValues = null;
    
    /*******************************************************************************
     *                                                                             *
     *                                CONSTRUCTORS                                 *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Construct a regular matrix.
     *
     * @param rows the number of rows in the dense matrix
     */
    
    public DenseDoubleMatrix1D(int rows) throws IllegalArgumentException {
        if(rows <= 0) {
            throw new IllegalArgumentException("Error: numbers of rows must exceed 0.");
        }
        nRows = rows;
        matrixValues = new double[rows];
    }
    
    /**
     * Construct a regular dense matrix with an array of values.  
     *
     * @param matrixValues an array of values
     */
    
    public DenseDoubleMatrix1D(double[] matrixValues) throws IllegalArgumentException {
        if(matrixValues == null) {
            throw new IllegalArgumentException("Specify non-null input for the matrix values.");
        }
        nRows = matrixValues.length;
        this.matrixValues = matrixValues;
    }
    
    /*******************************************************************************
     *                                                                             *
     *                            ACCESSOR METHODS                                 *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Returns a deep copy of the current matrix.  Changes in one matrix are not reflected
     * in the other matrix.
     *
     * @return a deep copy of the current matrix.
     */
    
    public Matrix deepCopy() {
        //Create an empty matrix
        DenseDoubleMatrix1D newDenseMatrix = new DenseDoubleMatrix1D(nRows);        
        for(int i = 0; i < nRows; i++) {
            newDenseMatrix.matrixValues[i] = matrixValues[i];
        }
        newDenseMatrix.nRows = nRows;
        return newDenseMatrix;
    }
    
   /**
     * Returns a deep copy of the current matrix in 2D form with a specified 
     * number of rows.  The matrix is filled row-wise from the top left corner.
     *
     * @param rowCount the number of rows
     * @return a deep copy in 2D form. 
     */
    
    public Matrix2D to2D(int rowCount) throws IllegalArgumentException {
        if(rowCount < 1 || rowCount > nRows) {
            throw new IllegalArgumentException("The row count must be greater than 1 and less than the number of cells in the 1D matrix ["+rowCount+"].");
        }
        int colCount = (int)java.lang.Math.ceil(((double)nRows)/(double)rowCount);
        DenseDoubleMatrix2D data = new DenseDoubleMatrix2D(rowCount,colCount);
        int total = 0;
        for(int i = 0; i < rowCount; i++) {
            for(int j = 0; j < colCount; j++) {
                data.set(i,j,matrixValues[total]);
                total++;
            }
        }
        return data;
    }    
    
    /**
     * Returns the array elements.
     *
     * @return the data array
     */
    
    public double[] toArray() throws OutOfMemoryError {
        return matrixValues;
    }
    
    /**
     * Returns the element value for the given internal row coordinate.
     *
     * @param a row index
     * @return element (a)
     */
    
    public double get(int a) throws IndexOutOfBoundsException {
        return matrixValues[a];
    }        
    
    /**
     * Returns a subset of the current matrix between (and including) the two rows.
     *
     * @param startRow the start row
     * @param endRow the end row
     * @return a subset of the current matrix by row
     */
    
    public Matrix1D getSubmatrixByRow(int startRow, int endRow) throws IllegalArgumentException {
        if(startRow < 0 || endRow >= nRows || endRow < startRow) {
            throw new IllegalArgumentException("Invalid submatrix requested.");
        }
        if(startRow == 0 && endRow == nRows-1) {
            return this;
        }
        double[] r = new double[endRow-startRow+1];
        System.arraycopy(matrixValues,startRow,r,0,r.length);
        return new DenseDoubleMatrix1D(r);
    }

    /**
     * Append the input matrix to the bottom of the current matrix and return the
     * result in a new matrix.
     *
     * @param input the input matrix
     * @return an appended matrix
     */

    public DoubleMatrix1D append(DoubleMatrix1D input) throws IllegalArgumentException {
        if(input == null) {
            throw new IllegalArgumentException("Specify a non-null input matrix to append.");
        }
        double[] d = new double[input.getRowCount()+getRowCount()];
        System.arraycopy(matrixValues,0,d,0,nRows);
        System.arraycopy(input.toArray(),0,d,nRows,input.getRowCount());
        return new DenseDoubleMatrix1D(d);
    }
    
    /*******************************************************************************
     *                                                                             *
     *                            MUTATOR METHODS                                  *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Used to set the element value with internal row-column coordinates.
     *
     * @param a row index
     * @param value the value to enter
     */
    
    public void set(int a, double value) throws IndexOutOfBoundsException {
        matrixValues[a] = value;
    }

    /**
     * Returns the transpose of the current matrix as a new matrix object.
     *
     * @return the transpose of the current matrix.
     */
    
    public DoubleMatrix1D transpose() {
        
        //Create a dummy matrix for copying
        DenseDoubleMatrix1D newTranspose = new DenseDoubleMatrix1D(nRows);

        //Add the transposed values to the new matrix
        for(int i = 0; i < nRows; i++) {
            newTranspose.matrixValues[i] = matrixValues[(nRows-1)-i];
        }
        newTranspose.nRows=nRows;
        return newTranspose;
    }

    /**
     * Returns the matrix values.
     *
     * @return the matrix values
     */
    
    public Object getMatrixValues() {
        return matrixValues;
    }

    /**
     * Assigns a function to each element in the matrix.  This implementation is
     * based on that in cern.colt.matrix class.  For example, to multiply every element
     * in the matrix by a number x:
     *
     * Functions F = Functions.functions;
     * DoubleFunction a = F.mult(x);
     * myMatrix.assign(a);
     *
     * @param function a function to assign
     * @param overwrite is true to overwrite the existing matrix
     * @return this matrix modified by the function
     */

    public DoubleMatrix assign(DoubleFunction function, boolean overwrite) throws ArithmeticException, IllegalArgumentException {
        DenseDoubleMatrix1D newMatrix = null;
        if(overwrite) {
            newMatrix = (DenseDoubleMatrix1D)this;
        }
        else {
            newMatrix = new DenseDoubleMatrix1D(nRows);
        }
        for(int i = 0; i < nRows; i++) {
            newMatrix.matrixValues[i]=function.apply(matrixValues[i]);
        }
        return newMatrix;
    }

    /**
     * Assigns a function to each element in the matrix ignoring a specified value.
     * This implementation is based on that in cern.colt.matrix class.  For example,
     * to multiply every element in the matrix by a number x:
     *
     * Functions F = Functions.functions;
     * DoubleFunction a = F.mult(x);
     * myMatrix.assign(a);
     *
     * @param function a function to assign
     * @param overwrite is true to overwrite the existing matrix
     * @param avoid a number to avoid
     * @return this matrix modified by the function
     */

    public DoubleMatrix assign(DoubleFunction function, boolean overwrite, double avoid) throws ArithmeticException, IllegalArgumentException {
        DenseDoubleMatrix1D newMatrix = null;
        if(overwrite) {
            newMatrix = (DenseDoubleMatrix1D)this;
        }
        else {
            newMatrix = new DenseDoubleMatrix1D(nRows);
        }
        for(int i = 0; i < nRows; i++) {
            if(matrixValues[i]!=avoid) newMatrix.matrixValues[i]=function.apply(matrixValues[i]);
            else newMatrix.matrixValues[i]=avoid;
        }
        return newMatrix;
    }

    /**
     * Applies a binary function to the current matrix and a numeric input matrix.
     *
     * @param input a matrix with identical dimensions
     * @param function a binary function
     * @return this f.apply(this, input)
     */

    public DoubleMatrix assign(DoubleMatrix input, DoubleDoubleFunction function, boolean overwrite) throws ArithmeticException, IllegalArgumentException {
        if(!hasEquivalentDimensions((Matrix)input)) {
            throw new IllegalArgumentException("Error: the matrix dimensions are inconsistent.");
        }
        DenseDoubleMatrix1D newMatrix = null;
        //Overwrite the existing matrix
        if(overwrite) {
            newMatrix = (DenseDoubleMatrix1D)this;
        }
        else {
            newMatrix = new DenseDoubleMatrix1D(nRows);
        }
        for(int i = 0; i < nRows; i++) {
            newMatrix.matrixValues[i]=function.apply(matrixValues[i],((DoubleMatrix1D)input).get(i));
        }
        return newMatrix;
    }

    /**
     * Applies a binary function to the current matrix and a numeric input matrix,
     * ignoring the specified value in the current matrix.
     *
     * @param input a 2D matrix with identical dimensions
     * @param function a binary function
     * @param overwrite is true to assign the result to the current matrix, false for a deep copy
     * @param avoid a number to avoid
     * @return this f.apply(this, input)
     */

    public DoubleMatrix assign(DoubleMatrix input, DoubleDoubleFunction function, boolean overwrite, double avoid) throws ArithmeticException, IllegalArgumentException {
        if(!hasEquivalentDimensions((Matrix)input)) {
            throw new IllegalArgumentException("Error: the matrix dimensions are inconsistent.");
        }
        DenseDoubleMatrix1D newMatrix = null;
        //Overwrite the existing matrix
        if(overwrite) {
            newMatrix = (DenseDoubleMatrix1D)this;
        }
        //Create a new matrix
        else {
            newMatrix = new DenseDoubleMatrix1D(nRows);
        }
        DoubleMatrix1D inp = (DoubleMatrix1D)input;
        for(int i = 0; i < nRows; i++) {
            double in = inp.get(i);
            if(matrixValues[i] != avoid && in != avoid) newMatrix.matrixValues[i]=function.apply(matrixValues[i],in);
            else newMatrix.matrixValues[i]=avoid;
        }
        return newMatrix;
    }
    
    /*******************************************************************************
     *                                                                             *
     *                             MUTATOR METHODS                                 *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Sets the matrix values with an array of primitives or throws an exception
     * if the object is incorrect.
     *
     * @param matrixValues the matrix values
     */
    
    public void setMatrixValues(Object matrixValues) throws IllegalArgumentException {
        if(!(matrixValues instanceof double[])) {
            throw new IllegalArgumentException("One dimensional array of doubles expected.");
        }
        double[] vals = (double[])matrixValues;
        if(vals.length != nRows) {
            throw new IllegalArgumentException("Incorrect number of rows: ["+nRows+": "+vals.length+"].");
        }
        this.matrixValues = vals;       
    }    
    
    /** 
     * Sets the matrix values to null (i.e. an empty matrix).
     */
    
    public void clearValues() {
        matrixValues = new double[matrixValues.length];
    }        
    
}

