package evs.utilities.progress;

/**
 * Throws an exception if a process is stopped.
 *
 * @author james.brown@hydrosolved.com
 * @version 4.0
 */

public class ProgressStoppedException extends RuntimeException {

    /**
     * Constructs a StoppedException with no message.
     */

    public ProgressStoppedException() {
        super();
    }

    /**
     * Constructs a StoppedException with the specified message.
     *
     * 
     * @param s the message.
     */

    public ProgressStoppedException(String s) {
	super(s);
    }
}

