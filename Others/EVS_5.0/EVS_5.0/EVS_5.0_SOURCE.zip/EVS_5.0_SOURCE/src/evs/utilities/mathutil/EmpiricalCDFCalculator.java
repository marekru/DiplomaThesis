package evs.utilities.mathutil;

//Java util dependencies
import java.util.Arrays;
import java.util.TreeMap;
import java.util.Iterator;
import java.util.Vector;

/**
 * Utility class for empirical probability distributions.  
 * 
 * @author evs@hydrosolved.com
 */

public class EmpiricalCDFCalculator {
          
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHOD                                *
     *                                                                              *
     *******************************************************************************/      

    /**
     * Returns the percentile position of a value in an array, which may be ordered
     * or unordered (specify).  Throws an exception if all values are equal to 
     * the ignore value.  
     *
     * @param vals the values
     * @param val the value for which a percentile is required
     * @param ignore a value to ignore
     * @param sort is true to sort the array, false if the input values are already sorted 
     */
    
    public static double getPerc(double[] vals, double val, double ignore, boolean sort)  throws IllegalArgumentException {
        return getProb(vals,val,ignore,sort)*100.0;
    }        

    /**
     * Returns the cumulative probabilistic position of a value in an array, which 
     * may be ordered or unordered (specify).  Throws an exception if all values are 
     * equal to the ignore value.  
     *
     * @param vals the values
     * @param val the value for which a probability is required
     * @param ignore a value to ignore
     * @param sort is true to sort the array, false if the input values are already sorted 
     * @return the probability
     */
    
    public static double getProb(double[] vals, double val, double ignore, boolean sort) throws IllegalArgumentException {
        //Determine the null count
        int ind = 0;
        double[] copy = new double[vals.length];  //If non-null elements, last few will remain unset
        for(int i = 0; i < vals.length; i++) {
            if(vals[i]!=ignore) {
                copy[ind] = vals[i];
                ind++;
            }
        }
        //All elements are null
        int nC = vals.length - ind;
        if(ind == 0) {
            throw new IllegalArgumentException("All elements in the requested sample correspond to the ignore value.");
        }
        //Some elements are null
        if(ind != vals.length-1) {
            double[] c2 = new double[vals.length-nC];
            System.arraycopy(copy,0,c2,0,c2.length);
            copy = c2;
        }
        if(sort) {
            Arrays.sort(copy);
        }
        if(val < copy[0]) {
            return 0.0;
        }
        else if(val >= copy[copy.length-1]) {
            return 1.0;
        }
        int length = copy.length;
        double returnMe = 0.0;
        for(int i = 0; i < length; i++) {
            if(copy[i]>val) {
                double lower = copy[i-1];
                double range = copy[i]-lower;
                double fraction = (val-lower) / range;
                double probRange = 1.0/length; 
                returnMe = (i * probRange) + (fraction * probRange);
                break;
            } 
        }
        return returnMe;        
    }
    
    /**
     * Returns the value in an array corresponding to a given cumulative probability.
     * The array may be ordered or unordered (specify).  Throws an exception if all 
     * values are equal to the ignore value or the probability is invalid.  Returns the
     * ignore value if fewer than two valid, non-null, entries are available. Note that
     * the lowermost and uppermost values in the array are returned for probabilities
     * 0.0 and 1.0, respectively.
     *
     * @param vals the values
     * @param prob the probability for which a value is required
     * @param nV a null value to ignore
     * @param sort is true to sort the array, false if the input values are already sorted 
     * @return the value corresponding to the probability
     */
    
    public static double getVal(double[] vals, double prob, double nV, boolean sort) throws IllegalArgumentException {
        if (prob < 0 || prob > 1) {
            throw new IllegalArgumentException(prob + " is not a valid probability.");
        }
        if (vals.length == 0) {
            throw new IllegalArgumentException("Cannot determine the inverse cdf value for null input.");
        }
        double[][] cdf = getRawEmpiricalCDF(vals,nV,sort);
        double val = getValFromCDF(cdf,prob);
        if(!Double.isInfinite(val)&&!Double.isNaN(val)) {
            return val;
        }
        return nV;
    }     
    
    /**
     * Returns the raw empirical cdf from the input whereby a probability is 
     * assigned to each non-null data value arranged in ascending order. Unlike
     * {@link EmpiricalCDFCalculator#getRawEmpiricalCDF(double[], double, boolean)} 
     * tied values are not explicitly handled and the cdf is not filtered using 
     * {@link EmpiricalCDFCalculator#filterCDF(double[][])} to remove steps.
     *
     * @param vals the values
     * @param nV a null value to ignore
     * @param sort is true to sort the array, false if the input values are already sorted 
     * @return the raw empirical CDF with probabilities in the first row
     */
    
    public static double[][] getRawEmpiricalCDF(double[] vals, double nV, boolean sort) throws IllegalArgumentException {
        if (vals.length == 0) {
            throw new IllegalArgumentException("Cannot determine the inverse cdf value for null input.");
        }
        //Determine the null count
        int ind = 0;
        double[] copy = new double[vals.length];  //If non-null elements, last few will remain unset
        for(int i = 0; i < vals.length; i++) {
            if(vals[i]!=nV) {
                copy[ind] = vals[i];
                ind++;
            }
        }
        //All elements are null
        int nC = vals.length - ind;
        if(ind == 0) {
            throw new IllegalArgumentException("All elements in the requested sample correspond to the ignore value.");
        }
        if(ind<2) {
            throw new IllegalArgumentException("Insufficient non-null values to compute the raw cdf.");
        }
        //Some elements are null
        if(ind != vals.length-1) {
            double[] c2 = new double[vals.length-nC];
            System.arraycopy(copy,0,c2,0,c2.length);
            copy = c2;
        }
        if(sort) {
            Arrays.sort(copy);
        }
        //Compute the empirical cumulative probabilities for each observation
        double[][] cdf = new double[2][copy.length];
        for(int i = 0; i < copy.length; i++) {
            double i_count = 0;
            for(int j = 0; j < copy.length; j++) {
                if(copy[j]<=copy[i]) {
                    i_count+=1;
                }
                else {
                    break;
                }
            }   
            cdf[0][i]=i_count/copy.length;
            cdf[1][i]=copy[i];
        }
        return cdf;
    }         
    
    /**
     * Returns a set of cumulative probabilities from cumulative counts.
     * 
     * @param counts the counts
     * @param overwrite is true to overwrite
     * @return cumulative probabilities
     */
    
    public static double[] getCumProbsFromCumCounts(double[] counts, boolean overwrite) {
        int length = counts.length;
        double div = counts[length-1];
        double[] returnMe = counts;
        if(! overwrite) {
            returnMe = new double[length];
        }
        for(int i = 0; i < length; i++) {
            returnMe[i] = counts[i]/div;
        }
        return returnMe;
    }

    /**
     * Returns an empirical cdf with the cumulative probabilities in the first
     * row and the values in the second row using the specified thresholds as input.  
     * The thresholds may be defined in terms of probabilities or real values.
     *
     * @param samples the input data
     * @param thresh the cumulative probability thresholds
     * @param ignore a number to ignore
     * @param pThresh is true if the thresholds are probabilities
     * @param filter is true to reduce stepped elements to the first and last points defining that step
     * @param weibull is true for unbiased estimates of probability (n+1 as denominator)
     * @return a cdf
     */
    
    public static double[][] getEmpiricalCDF(double[] samples, double[] thresh, double ignore, boolean pThresh, boolean filter, boolean weibull) throws IllegalArgumentException {    
        if(samples==null) {
            throw new IllegalArgumentException("Specify non-null sample data.");
        }
        if(thresh==null) {
            throw new IllegalArgumentException("Specify non-null thresholds.");
        }
        if (pThresh) {
            //Determine the null count
            int ind = 0;
            double[] copy = new double[samples.length];  //If non-null elements, last few will remain unset
            for (int i = 0; i < samples.length; i++) {
                if (samples[i] != ignore) {
                    copy[ind] = samples[i];
                    ind++;
                }
            }
            //All elements are null
            int nC = samples.length - ind;
            if (ind == 0) {
                throw new IllegalArgumentException("All elements in the requested sample correspond to the ignore value.");
            }
            //Some elements are null
            if (nC > 0) {
                double[] c2 = new double[samples.length - nC];
                System.arraycopy(copy, 0, c2, 0, c2.length);
                copy = c2;
            }
            Arrays.sort(copy);
            double[][] returnMe = new double[2][thresh.length];
            returnMe[0] = thresh;
            try {
                for (int i = 0; i < thresh.length; i++) {
                    if(thresh[i]<0.0||thresh[i]>1.0) {
                        throw new IllegalArgumentException("Some probabilities are out of the allowed range [0,1].");
                    }
                    else if(thresh[i] > 0.0) {
                        double nx = thresh[i] * (copy.length - 1.0); //Zero-based index
                        double frac = nx - (int) nx;
                        if (frac > 0.0) {
                            int nx2 = (int) nx;
                            returnMe[1][i] = copy[nx2] + (frac * (copy[nx2 + 1] - copy[nx2]));
                        } else {
                            returnMe[1][i] = copy[(int) nx];
                        }
                    } else if (i == 0 && thresh[i] == 0.0) {
                        returnMe[1][0] = copy[0];
                    }
                }
                if(filter) {
                    returnMe = filterCDF(returnMe);
                }
                return returnMe;
            } catch (Exception e) {
                e.printStackTrace();
                throw new IllegalArgumentException("Invalid probability thresholds.");
            }
        }
        else {
            //Copy inputs
            double[] s_copy = new double[samples.length];
            double[] t_copy = new double[thresh.length];
            System.arraycopy(samples, 0, s_copy, 0, s_copy.length);
            System.arraycopy(thresh, 0, t_copy, 0, t_copy.length);
            //Sort inputs
            Arrays.sort(s_copy);
            Arrays.sort(t_copy);
            //Count number of non null items <= threshold
            double[] counts = new double[t_copy.length];
            double last = 0;
            double nullCount = 0;
            int start = 0;
            for (int i = 0; i < t_copy.length; i++) {
                counts[i]=last;  //Cumulative
                for (int j = start; j < s_copy.length; j++) {
                    if (s_copy[j] != ignore) {
                        if (s_copy[j] <= t_copy[i]) {
                            counts[i] += 1;
                        } else {
                            start = j;
                            last = counts[i];
                            break;
                        }
                    }
                    else {
                        nullCount++;
                    }
                }
            }
            double total = s_copy.length-nullCount;
            //Weibull position
            if(weibull) {
                total+=1;
            }
            double[][] cdf = new double[2][t_copy.length];
            cdf[1] = t_copy;
            for (int i = 0; i < cdf[0].length; i++) {
                cdf[0][i] = counts[i] / total;
            }
            if(filter) {
                cdf = filterCDF(cdf);
            }
            return cdf;
        }
    }
    
    /**
     * Returns an empirical cdf with thresholds corresponding to the data values
     * provided.  Ranks the observations and tied ranks are given the average of the
     * intermediate positions.  The probability is then given by the Weibull plotting
     * position (divide by n+1) if requested, otherwise no plotting position (divide
     * by n).   
     * 
     * @param obs the observations
     * @param nV the null value
     * @param weibull is true to use the Weibull plotting position, false for no plotting position
     * @return the empirical cdf
     */
    
    public static double[][] getEmpiricalCDF(double[] obs, double nV, boolean weibull) throws IllegalArgumentException {   
        double[] stripped = stripNulls(obs,nV);
        //Sort the values, then rank
        Arrays.sort(stripped);
        double[][] ranked = new double[2][stripped.length];
        
        //Compute the ranks
        ranked[0][0]=1;
        for(int i = 1; i < ranked[0].length; i++) {
            if(stripped[i] == stripped[i-1]) {
                ranked[0][i] = ranked[0][i-1];
            }
            else {
                ranked[0][i] = i+1;
            }
        }
        //Average any tied values
        int cont = 1;
        for(cont = 1; cont < ranked[0].length; cont++) {
            if(ranked[0][cont] == ranked[0][cont-1]) { 
                int start = cont-1;
                int stop = cont;
                double total = ranked[0][cont-1];
                for(int j = cont; j < ranked[0].length; j++) {
                    if(ranked[0][j] == ranked[0][j-1]) {
                        stop = j;
                        total = total + j + 1;
                    }
                    else {
                        cont = j+1;
                        break;
                    }
                }
                for(int k = start; k < stop+1; k++) {
                    ranked[0][k] = total/((stop - start)+1); 
                }
            }
        }    
   
        //Compute the probabilities 
        for(int i = 0; i < ranked[0].length; i++) {
            ranked[1][i] = stripped[i];
            if(weibull) {
                ranked[0][i] = ranked[0][i]/(ranked[0].length+1);
            } else {
                ranked[0][i] = ranked[0][i]/(ranked[0].length);
            }
        }          
        return filterCDF(ranked);    
    }
    
    /**
     * Removes redundant (repeated pairs of) values from a cdf. 
     *
     * @param empiricalCDF the empirical cdf
     * @return the filtered cdf
     */
    
    public static double[][] filterCDF(double[][] empiricalCDF) {
                TreeMap<Double, Vector<double[]>> unique = new TreeMap();
        int total = 0;
        for (int i = 0; i < empiricalCDF[0].length; i++) {
            if (!unique.containsKey(empiricalCDF[0][i])) {
                Vector<double[]> v = new Vector<double[]>();
                double[] d = new double[]{empiricalCDF[0][i],empiricalCDF[1][i]};
                v.add(d);
                unique.put(empiricalCDF[0][i],v);
                total++;
            } else {
                Vector<double[]> g = unique.get(empiricalCDF[0][i]);
                if(g.size()==1) {
                    double[] d = new double[]{empiricalCDF[0][i],empiricalCDF[1][i]};
                    g.add(d);
                    total++;
                } else {
                    double[] r = g.get(1);
                    r[1]=empiricalCDF[1][i];
                }
            }
        }
        double[][] cdf = new double[2][total];
        Iterator i = unique.keySet().iterator();
        int t = 0;
        while (i.hasNext()) {
            Vector<double[]> next = unique.get(i.next());
            for(int j = 0; j < next.size(); j++) {
                double[] d = next.get(j);
                cdf[0][t]= d[0];
                cdf[1][t]= d[1];
                t++;
            }
        }
        return cdf;

//        TreeMap<Double,Double> unique = new TreeMap();
//        TreeMap<Double,Double> unique2 = new TreeMap();
//        for(int i = 0; i < empiricalCDF[0].length; i++) {
//            if(!unique.containsKey(empiricalCDF[0][i])) {
//                unique.put(empiricalCDF[0][i],empiricalCDF[1][i]);
//            }
//            unique2.put(empiricalCDF[0][i],empiricalCDF[1][i]);
//        }
//
//        Vector<double[]> v = new Vector();
//        Iterator i = unique.keySet().iterator();
//        while(i.hasNext()) {
//            Double key = (Double)i.next();
//            Double val = unique.get(key);
//            //Larger thresh also exists
//            if(unique2.containsKey(key)) {
//                //If prob is zero, use last instance only
//                if(key==0.0) {
//                    v.add(new double[]{key,unique2.get(key)});
//                }
//                //If prob is one, use first instance only
//                else if(key==1.0) {
//                    v.add(new double[]{key,val});
//                }
//                //Otherwise add both
//                else {
//                    v.add(new double[]{key,val});
//                    //Only add both if the real values differ
//                    if(!val.equals(unique2.get(key))) {
//                        v.add(new double[]{key,unique2.get(key)});
//                    }
//                }
//            }
//            else {
//                v.add(new double[]{key,val});
//            }
//        }
//        int tot = v.size();
//        double[][] complete = new double[2][tot];
//        for(int k = 0; k < tot; k++) {
//            double[] next = v.get(k);
//            complete[0][k]=next[0];
//            complete[1][k]=next[1];
//        }
//        return complete;
    }         
    
    /**
     * Returns the (cumulative) probability that a value is less than or equal to
     * the input value given an empirical cdf whose cumulative probabilities are 
     * defined in the first row and whose corresponding values are defined in the 
     * second row.  
     *
     * @param empiricalCDF the empirical cdf
     * @param x the upper limit
     * @return the empirical cumulative probability
     */
    
    public static double getProbFromCDF(double[][] empiricalCDF, double x) {                
        //Lower
        if(x<empiricalCDF[1][0]) {
            return 0.0;
        }
        //Upper
        else if(x>=empiricalCDF[1][empiricalCDF[1].length-1]) {
            return 1.0;
        }
        //Between
        double returnMe = 0.0;
        for(int i = 1; i < empiricalCDF[1].length; i++) {
            if (x <= empiricalCDF[1][i] && empiricalCDF[1][i] > empiricalCDF[1][i-1]) {  //Check for steps
                //Determine fractional position
                double frac = (x - empiricalCDF[1][i - 1]) / (empiricalCDF[1][i] - empiricalCDF[1][i - 1]);
                returnMe = empiricalCDF[0][i - 1] + ((empiricalCDF[0][i] - empiricalCDF[0][i - 1]) * frac);
                break;
            }
        }
        return returnMe;
    }
    
    /**
     * Returns the value corresponding to a given probability for an empirical
     * cdf whose cumulative probabilities are defined in the first row and whose
     * corresponding values are defined in the second row.  
     *
     * @param empiricalCDF the empirical cdf
     * @param prob the probability
     * @return the corresponding value
     */
    
    public static double getValFromCDF(double[][] empiricalCDF, double prob) {
        //Lower
        if(prob<=empiricalCDF[0][0]) {
            return empiricalCDF[1][0];
        }
        //Upper
        else if(prob>=empiricalCDF[0][empiricalCDF[0].length-1]) {
            return empiricalCDF[1][empiricalCDF[0].length-1];
        }
        //Between
        double returnMe = 0.0;
        for(int i = 1; i < empiricalCDF[0].length; i++) {
            if (prob <= empiricalCDF[0][i] && empiricalCDF[0][i] > empiricalCDF[0][i-1]) {  //Check for steps
                //Determine fractional position
                double frac = (prob-empiricalCDF[0][i-1])/(empiricalCDF[0][i]-empiricalCDF[0][i-1]);
                returnMe = empiricalCDF[1][i-1]+((empiricalCDF[1][i]-empiricalCDF[1][i-1])*frac);
                break;
            }
        }
        return returnMe;
    }    
    
    /**
     * Converts a cdf to a pdf
     *
     * @param cdf the cdf with probabilities in the first row
     * @return a pdf
     */
    
    public static double[][] getPDFFromCDF(double[][] cdf) {
        double[][] data = new double[cdf.length][cdf[0].length];
        data[0][0] = cdf[0][0];
        data[1][0] = cdf[1][0];
        for(int i = 1; i < data[0].length; i++) {
            data[0][i] = cdf[0][i] - cdf[0][i-1];
            data[1][i] = cdf[1][i];
        }
        return data;
    }    
    
    /**
     * Returns the integral of an empirical function from its minimum to its maximum. 
     * The empirical function should be described in two rows.  
     *
     * @param input the empirical function 
     * @return the integral
     */
    
    public static double getIntegral(double[][] input) {
        double sum = 0.0;
        for(int i = 1; i < input[0].length; i++) {
            double diff = input[0][i]-input[0][i-1];
            double av = 0.5*(input[1][i]+input[1][i-1]);
            sum += Math.abs(diff*av); //Sum product
        }
        return sum;
    }
   
    /**
     * Strips null values from an input vector.
     * 
     * @param input the input
     * @param nV the null value
     * @return the non-null data
     */
    
    public static double[] stripNulls(double[] input, double nV) {
        Vector<Double> nonNull = new Vector();
        for(int i = 0; i < input.length; i++) {
            if(input[i]!=nV) {
                nonNull.add(input[i]);
            }
        }
        int nn = nonNull.size();
        if(nn==0) {
            return null;
        }
        double[] returnMe = new double[nn];
        for(int i = 0; i < nn; i++) {
            returnMe[i]=nonNull.get(i);
        }
        return returnMe;
    }    
    
    /*******************************************************************************
     *                                                                             *
     *                                  TEST METHOD                                *
     *                                                                             *
     ******************************************************************************/    
    
    
    
    public static void main(String[] args) {
        
        //double[] obs = new double[]{1,2,3,4,5,6,6,7,8,9,9,10};
        //System.out.println(new evs.utilities.matrix.DenseDoubleMatrix2D(getEmpiricalCDF(obs,-999)));
        
       /* double[] dat = new double[]{3,1,2,4,5,6,8,10,9,7};
       // System.out.println(getVal(dat,1.0,-999,true));
        
        double[] data = new double[10000];
        for(int i = 0; i < data.length; i++) {
            data[i] = Math.random();
        }
        double[] pThresh = new double[]{0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.8,1.0};
        double[] pThresh2 = new double[]{11.1,12.2,13.3,14.4,15.5,25.6,34.7,435.8,1244.8,13434.0};
        double[][] test = new double[][]{pThresh,pThresh2};
        
       // System.out.println(getValFromCDF(test,getProbFromCDF(test,14.4)));
        
        double[] samples = new double[]{22.1,34.2,34.0,0,0,0,0,0,14.2,12.3,-999,-999,-999};
        double[] thresh = new double[]{0,5,10,15,20,25,30,50};
        
        System.out.println(new evs.utilities.matrix.DenseDoubleMatrix2D(getEmpiricalCDF(samples,thresh,-999,false,true)));
        */
        
        
        //double[][] cdf = getEmpiricalCDF(data,pThresh,-999);
        
        //System.out.println(FunctionLibrary.maximum().apply(new evs.utilities.matrix.DenseDoubleMatrix1D(data)));
        //System.out.println(new DenseDoubleMatrix2D(cdf));
        //double[][] pdf = getPDFFromCDF(cdf);
        //System.out.println(new DenseDoubleMatrix2D(pdf));
        //double result = integrate(pdf);
        //System.out.println(result);
    }
    
    
    
}
