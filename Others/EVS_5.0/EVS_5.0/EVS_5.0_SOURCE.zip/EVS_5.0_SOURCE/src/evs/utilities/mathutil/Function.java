package evs.utilities.mathutil;

/**
 * Interface that represents a function object for performing calculations on 
 * numeric data. 
 * 
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public interface Function {}
