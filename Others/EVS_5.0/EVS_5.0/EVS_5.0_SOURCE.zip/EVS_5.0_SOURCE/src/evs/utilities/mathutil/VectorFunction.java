package evs.utilities.mathutil;

//EVS dependencies
import evs.utilities.matrix.Matrix1D;

/**
 * Interface that represents a vector function, which takes a 1D matrix argument and
 * returns a double value.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public interface VectorFunction extends Function {
    
    /**
     * Applies a function to an argument.  Throws an exception if the specified 
     * function cannot be applied to the input matrix.
     *
     * @param argument argument passed to the function.
     * @return the result of the function.
     */
    
    public double apply(Matrix1D argument) throws IllegalArgumentException;
    
    /**
     * Applies a function to an argument.  Throws an exception if the specified 
     * function cannot be applied to the input matrix.
     *
     * @param argument argument passed to the function.
     * @param ignore a value to ignore in the input
     * @return the result of the function.
     */
    
    public double apply(Matrix1D argument, Number ignore) throws IllegalArgumentException;

    /**
     * Returns any constants defined on construction of the function.
     *
     * @return the input parameter values
     */

    public double[] getConstants();

}
