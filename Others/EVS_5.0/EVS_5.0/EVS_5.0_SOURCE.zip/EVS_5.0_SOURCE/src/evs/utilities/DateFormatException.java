package evs.utilities;

/**
 * Class for throwing exceptions that signify an invalid date format.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DateFormatException extends RuntimeException {
    
    /**
     * Constructs a DateFormatException with no message.
     */
    
    public DateFormatException() {
        super();
    }

    /**
     * Constructs a DateFormatException with the specified message.
     * 
     * 
     * @param s the message.
     */
    
    public DateFormatException(String s) {
	super(s);
    }
}
