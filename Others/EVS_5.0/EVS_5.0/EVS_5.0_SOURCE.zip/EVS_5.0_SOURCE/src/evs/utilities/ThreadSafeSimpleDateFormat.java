package evs.utilities;

//Java dependencies
import java.util.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.TimeZone;
        
/**
 * Thread safe date format.
 * 
 * @author evs@hydrosolved.com
 */

public class ThreadSafeSimpleDateFormat {

    /**
     * The date format.
     */
    private DateFormat df;

    /**
     * Constructor that allows for lenient parsing. See {@link 
     * java.text.DateFormat#setLenient(boolean)}.
     * 
     * @param format the format
     * @param lenient is true to interpret the format leniently
     */
    
    public ThreadSafeSimpleDateFormat(String format, boolean lenient) {
        this.df = new SimpleDateFormat(format);
        df.setLenient(lenient);
    }

    /**
     * Conduct formatting.
     * 
     * @param date the date
     * @return the formatted date
     */
    
    public synchronized String format(Date date) {
        return df.format(date);
    }

    /**
     * Set the time zone.
     * 
     * @param zone the time zone
     */
    
    public void setTimeZone(TimeZone zone) {
        df.setTimeZone(zone);
    }
    
    /**
     * Parse the string to a date.
     * @param string the input string
     * @return the date
     * @throws ParseException
     */
    public synchronized Date parse(String string) throws ParseException {
        return df.parse(string);
    }
    
    /**
     * Parse the string to a date.
     * @param string the input string
     * @param pos the parse position
     * @return the date
     * @throws ParseException
     */
    public synchronized Date parse(String string, ParsePosition pos) {
        return df.parse(string,pos);
    }    
}    

