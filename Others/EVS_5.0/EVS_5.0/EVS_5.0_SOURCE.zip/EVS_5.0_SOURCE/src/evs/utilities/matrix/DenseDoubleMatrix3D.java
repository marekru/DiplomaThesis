package evs.utilities.matrix;

import evs.utilities.mathutil.DoubleFunction;
import evs.utilities.mathutil.DoubleDoubleFunction;

/**
 * A dense 3D matrix of double values.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DenseDoubleMatrix3D extends DoubleMatrix3D {
    
    /**
     * Store the matrix values
     */
    
    private double[][][] matrixValues = null;
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTORS                                  *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Construct a regular matrix.
     *
     * @param rows the number of rows in the dense matrix
     * @param columns the number of columns in the dense matrix
     * @param depth the depth of the matrix
     */
    
    public DenseDoubleMatrix3D(int rows, int columns, int depth) throws IllegalArgumentException {
        if (rows <= 0 || columns <= 0 || depth <= 0) {
            throw new IllegalArgumentException("Error: numbers of rows, columns and matrix depth must all exceed 0.");
        }
        nRows = rows;
        nColumns = columns;
        nDepth = depth;
        matrixValues = new double[rows][columns][depth];
    }
    
    /**
     * Construct a regular dense matrix with an array of double values.
     *
     * @param matrixValues the matrix values
     */
    
    public DenseDoubleMatrix3D(double[][][] matrixValues) throws IllegalArgumentException {
        if(matrixValues == null) {
            throw new IllegalArgumentException("Specify non-null input for the matrix values.");
        }
        if (matrixValues.length <= 0 || matrixValues[0].length <= 0 || matrixValues[0][0].length <=0) {
            throw new IllegalArgumentException("Error: numbers of elements must exceed zero in all three dimensions.");
        }
        nRows = matrixValues.length;
        nColumns = matrixValues[0].length;
        nDepth = matrixValues[0][0].length;
        for(int i = 0; i < nRows; i++) {
            for(int j = 0; j < nColumns; j++) {
                for(int k = 0; k < nDepth; k++) {
                    try {
                        double in = matrixValues[i][j][k];
                    }
                    catch(Exception e) {
                        throw new IllegalArgumentException("Error referencing index ["+i+","+j+","+k+"]: each dimension " +
                                "of the input array must be constant (e.g. each row must contain a common number of elements). " +
                                "However, a non-regular array is accepted.");
                    }
                }
            }
        }
        this.matrixValues = matrixValues;
    }
    
    /*******************************************************************************
     *                                                                             *
     *                            ACCESSOR METHODS                                 *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Returns a deep copy of the current matrix.  Changes in one matrix are not reflected
     * in the other matrix.
     *
     * @return a deep copy of the current matrix.
     */
    
    public Matrix deepCopy() {
        //Create an empty matrix
        DenseDoubleMatrix3D newDenseMatrix = new DenseDoubleMatrix3D(nRows,nColumns,nDepth);
        for (int i = 0; i < nDepth; i++) {
            for (int j = 0; j < nRows; j++) {
                for (int k = 0; k < nColumns; k++) {
                    newDenseMatrix.matrixValues[j][k][i] = matrixValues[j][k][i];
                }
            }
        }
        newDenseMatrix.nRows = nRows;
        newDenseMatrix.nColumns = nColumns;
        newDenseMatrix.nDepth = nDepth;
        return newDenseMatrix;
    }

    /**
     * Returns a deep copy of the current matrix in 1D form.  The matrix is filled
     * row-wise (i.e. one row at a time) and, in the case of a 3D matrix, from the 
     * top layer downwards.
     *
     * @return a deep copy in 1D form. 
     */
    
    public Matrix1D to1D() {
        int length = nRows*nColumns*nDepth;
        double[] mat = new double[length];
        int index = 0;
        for(int i = 0; i < nRows; i++) {
            for(int j = 0; j < nColumns; j++) {
                for(int k = 0; k < nDepth; k++) {
                    mat[index] = matrixValues[i][j][k];
                    index++;
                }
            }
        }
        return new DenseDoubleMatrix1D(mat);
    }    
    
    /**
     * Returns the array elements.
     *
     * @return the data array
     */
    
    public double[][][] toArray() throws OutOfMemoryError {
        return matrixValues;
    }
    
    /**
     * Returns the element value for the given internal row-column-depth coordinates.
     *
     * @param a row index
     * @param b column index
     * @param c depth index
     * @return element (a,b,c)
     */
    
    public double get(int a, int b, int c) throws IndexOutOfBoundsException {
        return matrixValues[a][b][c];
    }     
    
    /*******************************************************************************
     *                                                                             *
     *                            MUTATOR METHODS                                  *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Used to set the element value with internal row-column coordinates.
     *
     * @param a row index
     * @param b column index
     * @param c depth index
     * @param value the matrix value
     */
    
    public void set(int a, int b, int c, double value) throws IndexOutOfBoundsException {
        matrixValues[a][b][c] = value;
    }      
    
    /**
     * Returns the transpose of the current matrix as a new matrix object.  Rows are
     * switched with columns and layers are reversed.
     *
     * @return the transpose of the current matrix.
     */
    
    public DoubleMatrix3D transpose() {
        //Create a dummy matrix for copying
        DenseDoubleMatrix3D newTranspose = new DenseDoubleMatrix3D(nColumns,nRows,nDepth);
        //Add the transposed values to the new matrix
        for (int i = 0; i < nDepth; i++) {
            for (int j = 0; j < nRows; j++) {
                for (int k = 0; k < nColumns; k++) {
                    newTranspose.matrixValues[k][j][(nDepth-1)-i] = matrixValues[j][k][i];
                }
            }
        }
        return newTranspose;
    }
    
    /**
     * Returns the matrix values as an array of primitives.
     *
     * @return the matrix values
     */
    
    public Object getMatrixValues() {
        return matrixValues;
    }

    /**
     * Assigns a function to each element in the matrix.  This implementation is
     * based on that in cern.colt.matrix class.  For example, to multiply every element
     * in the matrix by a number x:
     *
     * Functions F = Functions.functions;
     * DoubleFunction a = F.mult(x);
     * myMatrix.assign(a);
     *
     * @param function a function to assign
     * @param overwrite is true to overwrite the existing matrix
     * @return this matrix modified by the function
     */

    public DoubleMatrix assign(DoubleFunction function, boolean overwrite) throws ArithmeticException, IllegalArgumentException {
        DenseDoubleMatrix3D newMatrix = null;
        if(overwrite) {
            newMatrix = (DenseDoubleMatrix3D)this;
        }
        else {
            newMatrix = new DenseDoubleMatrix3D(nRows, nColumns, nDepth);
        }
        for(int i = 0; i < nRows; i++) {
            for(int j = 0; j < nColumns; j++) {
                for(int k = 0; k < nDepth; k++) {
                    newMatrix.matrixValues[i][j][k] = function.apply(matrixValues[i][j][k]);
                }
            }
        }
        return newMatrix;
    }

    /**
     * Assigns a function to each element in the matrix ignoring a specified value.
     * This implementation is based on that in cern.colt.matrix class.  For example,
     * to multiply every element in the matrix by a number x:
     *
     * Functions F = Functions.functions;
     * DoubleFunction a = F.mult(x);
     * myMatrix.assign(a);
     *
     * @param function a function to assign
     * @param overwrite is true to overwrite the existing matrix
     * @param avoid a number to avoid
     * @return this matrix modified by the function
     */

    public DoubleMatrix assign(DoubleFunction function, boolean overwrite, double avoid) throws ArithmeticException, IllegalArgumentException {
        DenseDoubleMatrix3D newMatrix = null;
        if(overwrite) {
            newMatrix = (DenseDoubleMatrix3D)this;
        }
        else {
            newMatrix = new DenseDoubleMatrix3D(nRows,nColumns,nDepth);
        }
        for(int i = 0; i < nRows; i++) {
            for(int j = 0; j < nColumns; j++) {
                for(int k = 0; k < nDepth; k++) {
                    if(matrixValues[i][j][k] != avoid) newMatrix.matrixValues[i][j][k] = function.apply(matrixValues[i][j][k]);
                    else newMatrix.matrixValues[i][j][k]=avoid;
                }
            }
        }
        return newMatrix;
    }

    /**
     * Applies a binary function to the current matrix and a numeric input matrix.
     *
     * @param input a matrix with identical dimensions
     * @param function a binary function
     * @return this f.apply(this, input)
     */

    public DoubleMatrix assign(DoubleMatrix input, DoubleDoubleFunction function, boolean overwrite) throws ArithmeticException, IllegalArgumentException {
        if(!hasEquivalentDimensions((Matrix)input)) {
            throw new IllegalArgumentException("Error: the matrix dimensions are inconsistent.");
        }
        DenseDoubleMatrix3D newMatrix = null;
        if(overwrite) {
            newMatrix = (DenseDoubleMatrix3D)this;
        }
        else {
            newMatrix = new DenseDoubleMatrix3D(nRows, nColumns, nDepth);
        }
        for(int i = 0; i < nRows; i++) {
            for(int j = 0; j < nColumns; j++) {
                for(int k = 0; k < nDepth; k++) {
                    newMatrix.matrixValues[i][j][k] = function.apply(matrixValues[i][j][k],((DoubleMatrix3D)input).get(i,j,k));
                }
            }
        }
        return newMatrix;
    }

    /**
     * Applies a binary function to the current matrix and a numeric input matrix,
     * ignoring the specified value in the current matrix.
     *
     * @param input a 3D matrix with identical dimensions
     * @param function a binary function
     * @param overwrite is true to assign the result to the current matrix, false for a deep copy
     * @param avoid a number to avoid
     * @return this f.apply(this, input)
     */

    public DoubleMatrix assign(DoubleMatrix input, DoubleDoubleFunction function, boolean overwrite, double avoid) throws ArithmeticException, IllegalArgumentException {
        if(!hasEquivalentDimensions((Matrix)input)) {
            throw new IllegalArgumentException("Error: the matrix dimensions are inconsistent.");
        }
        DenseDoubleMatrix3D newMatrix = null;
        if(overwrite) {
            newMatrix = (DenseDoubleMatrix3D)this;
        } else {
            newMatrix = new DenseDoubleMatrix3D(nRows, nColumns, nDepth);
        }
        DoubleMatrix3D inp = (DoubleMatrix3D)input;
        for(int i = 0; i < nRows; i++) {
            for(int j = 0; j < nColumns; j++) {
                for(int k = 0; k < nDepth; k++) {
                    double in = inp.get(i,j,k);
                    if(matrixValues[i][j][k] != avoid && in !=avoid) newMatrix.matrixValues[i][j][k] = function.apply(matrixValues[i][j][k],in);
                    else newMatrix.matrixValues[i][j][k]=avoid;
                }
            }
        }
        return newMatrix;
    }

    /*******************************************************************************
     *                                                                             *
     *                             MUTATOR METHODS                                 *
     *                                                                             *
     ******************************************************************************/
       
    /**
     * Sets the matrix values as an array of primitives or throws an exception
     * if the object is incorrect.
     *
     * @param matrixValues the matrix values
     */
    
    public void setMatrixValues(Object matrixValues) throws IllegalArgumentException {
        if(!(matrixValues instanceof double[][][])) {
            throw new IllegalArgumentException("Three dimensional array of doubles expected.");
        }
        double[][][] vals = (double[][][])matrixValues;
        if(vals.length != nRows) {
            throw new IllegalArgumentException("Incorrect number of rows: ["+nRows+": "+vals.length+"].");
        }
        if(vals[0].length != nColumns) {
            throw new IllegalArgumentException("Incorrect number of columns: ["+nColumns+": "+vals[0].length+"].");
        }   
        if(vals[0][0].length != nDepth) {
            throw new IllegalArgumentException("Incorrect number of depth elements: ["+nDepth+": "+vals[0][0].length+"].");
        }          
        this.matrixValues = vals;
    }       
    
    /** 
     * Sets the matrix values to null (i.e. an empty matrix).
     */
    
    public void clearValues() {
        matrixValues = new double[matrixValues.length][matrixValues[0].length][matrixValues[0][0].length];
    }          
    
}

