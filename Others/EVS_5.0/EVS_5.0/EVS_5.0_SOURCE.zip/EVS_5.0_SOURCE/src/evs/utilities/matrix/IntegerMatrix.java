package evs.utilities.matrix;

/**
 * An interface for matrices of integers.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */
 
public interface IntegerMatrix {
    
}
