package evs.utilities.mathutil;

/**
 * Interface that represents a function object: a function that takes
 * a single object argument and returns a single object value.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public interface ObjectFunction extends Function {
    
    /**
     * Applies a function to an argument.
     *
     * @param argument argument passed to the function.
     * @return the result of the function.
     */
    
    public abstract Object apply(Object argument);
    
}

