package evs.utilities.matrix;

/**
 * A dense 3D matrix of int values.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DenseIntegerMatrix3D extends IntegerMatrix3D {
    
    /**
     * Store the matrix values
     */
    
    private int[][][] matrixValues = null;
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTORS                                  *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Construct a regular matrix.
     *
     * @param rows the number of rows in the dense matrix
     * @param columns the number of columns in the dense matrix
     * @param depth the depth of the matrix
     */
    
    public DenseIntegerMatrix3D(int rows, int columns, int depth) throws IllegalArgumentException {
        if (rows <= 0 || columns <= 0 || depth <= 0) {
            throw new IllegalArgumentException("Error: numbers of rows, columns and matrix depth must all exceed 0.");
        }
        nRows = rows;
        nColumns = columns;
        nDepth = depth;
        matrixValues = new int[rows][columns][depth];
    }
    
    /**
     * Construct a regular dense matrix with an array.
     *
     * @param matrixValues the matrix values
     */
    
    public DenseIntegerMatrix3D(int[][][] matrixValues) throws IllegalArgumentException {
        if (matrixValues.length <= 0 || matrixValues[0].length <= 0 || matrixValues[0][0].length <=0) {
            throw new IllegalArgumentException("Error: numbers of elements must exceed zero in all three dimensions.");
        }          
        nRows = matrixValues.length;
        nColumns = matrixValues[0].length;
        nDepth = matrixValues[0][0].length;
        for(int i = 0; i < nRows; i++) {
            for(int j = 0; j < nColumns; j++) {
                for(int k = 0; k < nDepth; k++) {
                    try {
                        int in = matrixValues[i][j][k];
                    }
                    catch(Exception e) {
                        throw new IllegalArgumentException("Error referencing index ["+i+","+j+","+k+"]: each dimension " +
                                "of the input array must be constant (e.g. each row must contain a common number of elements). " +
                                "However, a non-regular array is accepted.");
                    }
                }
            }
        }
        this.matrixValues = matrixValues;
    }
    
    /*******************************************************************************
     *                                                                             *
     *                            ACCESSOR METHODS                                 *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Returns a deep copy of the current matrix.  Changes in one matrix are not reflected
     * in the other matrix.
     *
     * @return a deep copy of the current matrix.
     */
    
    public Matrix deepCopy() {
        //Create an empty matrix
        DenseIntegerMatrix3D newDenseMatrix = new DenseIntegerMatrix3D(nRows,nColumns,nDepth);
        for (int i = 0; i < nDepth; i++) {
            for (int j = 0; j < nRows; j++) {
                for (int k = 0; k < nColumns; k++) {
                    newDenseMatrix.matrixValues[j][k][i] = matrixValues[j][k][i];
                }
            }
        }
        newDenseMatrix.nRows = nRows;
        newDenseMatrix.nColumns = nColumns;
        newDenseMatrix.nDepth = nDepth;
        return newDenseMatrix;
    }

    /**
     * Returns a deep copy of the current matrix in 1D form.  The matrix is filled
     * row-wise (i.e. one row at a time) and, in the case of a 3D matrix, from the 
     * top layer downwards.
     *
     * @return a deep copy in 1D form. 
     */
    
    public Matrix1D to1D() {
        int length = nRows*nColumns*nDepth;
        int[] mat = new int[length];
        int index = 0;
        for(int i = 0; i < nRows; i++) {
            for(int j = 0; j < nColumns; j++) {
                for(int k = 0; k < nDepth; k++) {
                    mat[index] = matrixValues[i][j][k];
                    index++;
                }
            }
        }
        return new DenseIntegerMatrix1D(mat);
    }    
    
    /**
     * Returns the array elements.
     *
     * @return the data array
     */
    
    public int[][][] toArray() throws OutOfMemoryError {
        return matrixValues;
    }
    
    /**
     * Returns the element value for the given internal row-column-depth coordinates.
     *
     * @param a row index
     * @param b column index
     * @param c depth index
     * @return element (a,b,c)
     */
    
    public int get(int a, int b, int c) throws IndexOutOfBoundsException {
        return matrixValues[a][b][c];
    }     
    
    /*******************************************************************************
     *                                                                             *
     *                            MUTATOR METHODS                                  *
     *                                                                             *
     ******************************************************************************/

    /**
     * Used to set the element value with internal row-column coordinates.
     *
     * @param a row index
     * @param b column index
     * @param c depth index
     * @param value the matrix value
     */
    
    public void set(int a, int b, int c, int value) throws IndexOutOfBoundsException {
        matrixValues[a][b][c] = value;
    }      
    
    /**
     * Returns the transpose of the current matrix as a new matrix object.  Rows are
     * switched with columns and layers are reversed.
     *
     * @return the transpose of the current matrix.
     */
    
    public IntegerMatrix3D transpose() {
        
        //Create a dummy matrix for copying
        DenseIntegerMatrix3D newTranspose = new DenseIntegerMatrix3D(nColumns,nRows,nDepth);
        
        //Copy the matrix
        //Add the transposed values to the new matrix
        for (int i = 0; i < nDepth; i++) {
            for (int j = 0; j < nRows; j++) {
                for (int k = 0; k < nColumns; k++) {
                    newTranspose.matrixValues[k][j][(nDepth-1)-i] = matrixValues[j][k][i];
                }
            }
        }
        newTranspose.nRows=nRows;
        newTranspose.nColumns=nColumns;
        newTranspose.nDepth=nDepth;
        return newTranspose;
    }
    
    /**
     * Returns the matrix values as an array of primitives.
     *
     * @return the matrix values
     */
    
    public Object getMatrixValues() {
        return matrixValues;
    }
    
    /*******************************************************************************
     *                                                                             *
     *                             MUTATOR METHODS                                 *
     *                                                                             *
     ******************************************************************************/
       
    /**
     * Sets the matrix values with an array of primitives or throws an exception
     * if the object is incorrect.
     *
     * @param matrixValues the matrix values
     */
    
    public void setMatrixValues(Object matrixValues) throws IllegalArgumentException {
        if(!(matrixValues instanceof int[][][])) {
            throw new IllegalArgumentException("Three dimensional array of integers expected.");
        }
        int[][][] vals = (int[][][])matrixValues;
        if(vals.length != nRows) {
            throw new IllegalArgumentException("Incorrect number of rows: ["+nRows+": "+vals.length+"].");
        }
        if(vals[0].length != nColumns) {
            throw new IllegalArgumentException("Incorrect number of columns: ["+nColumns+": "+vals[0].length+"].");
        }   
        if(vals[0][0].length != nDepth) {
            throw new IllegalArgumentException("Incorrect number of depth elements: ["+nDepth+": "+vals[0][0].length+"].");
        }          
        this.matrixValues = vals;
    }       
    
    /** 
     * Sets the matrix values to null (i.e. an empty matrix).
     */
    
    public void clearValues() {
        matrixValues = new int[matrixValues.length][matrixValues[0].length][matrixValues[0][0].length];
    }          
    
}

