package evs.utilities;

/**
 * Static classes that require initialization on start-up should implement this
 * interface to initialize the required static members.
 *
 * @author evs@hydrosolved.com
 */
public interface StaticClassInitializer {

    /**
     * Initialize the static class members.
     */

    public void initialize();

}
