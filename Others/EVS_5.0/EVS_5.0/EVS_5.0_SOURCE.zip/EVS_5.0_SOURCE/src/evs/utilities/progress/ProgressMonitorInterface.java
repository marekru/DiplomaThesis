package evs.utilities.progress;

/**
 * Interface for monitoring the percentage progress of a long-running operation.
 * 
 * @author evs@hydrosolved.com
 */

public interface ProgressMonitorInterface {
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/    
    
    /**
     * Returns the state of completion for the monitored operation as an integer
     * percentage.
     *
     * @return the percent complete
     */
    
    public abstract int getProgress();    
    
}
