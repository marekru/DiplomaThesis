package evs.utilities.matrix;

/**
 * Abstract base class for a 1D double matrix.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public abstract class DoubleMatrix1D extends Matrix1D implements DoubleMatrix {
    
    /*******************************************************************************
     *                                                                             *
     *                  ABSTRACT METHODS TO OVERRIDE IN A SUBCLASS                 *
     *                                                                             *
     ******************************************************************************/
  
    /**
     * Used to set the element value with internal coordinates.
     *
     * @param a row index
     * @param value the value to enter
     */
    
    public abstract void set(int a, double value) throws IndexOutOfBoundsException;

    /**
     * Returns the element value for the given internal row coordinate.
     *
     * @param a row index
     * @return element (a)
     */
    
    public abstract double get(int a) throws IndexOutOfBoundsException;
    
    /**
     * Returns the array elements.
     *
     * @return the data array
     */
    
    public abstract double[] toArray();
    
    /**
     * Returns a transpose view of the current matrix.
     *
     * @return a transpose of the current matrix.
     */
    
    public abstract DoubleMatrix1D transpose();

    /**
     * Append the input matrix to the bottom of the current matrix and return the
     * result in a new matrix.
     *
     * @param input the input matrix
     * @return an appended matrix
     */

    public abstract DoubleMatrix1D append(DoubleMatrix1D input) throws IllegalArgumentException;

    /*******************************************************************************
     *                                                                             *
     *                              CONCRETE METHODS                               *
     *                                                                             *
     ******************************************************************************/

    /**
     * Returns a string representation of the matrix.  
     *
     * @return a string representation of the matrix.
     */
    
    public String toString() {
        StringBuffer s = new StringBuffer();
        for(int  i = 0; i < nRows; i++) {       
            s.append(System.getProperty("line.separator")+"["+i+"]"+"\t");
            s.append(get(i)+"\t");
        }
        return s.toString();
    }
    
    /**
     * Returns a string representation of a double matrix with a specified number of
     * decimal places for its elements.  
     *
     * @param decimalPlaces the number of decimal places required for the matrix elements.
     * @return a string representation of the matrix.
     */
    
    public String toString(int decimalPlaces) {
        StringBuffer s = new StringBuffer();
        for(int  i = 0; i < nRows; i++) {       
            s.append(System.getProperty("line.separator")+"["+i+"]"+"\t");
            s.append(Math.floor(get(i)*Math.pow(10,decimalPlaces))/Math.pow(10,decimalPlaces)+"\t");
        }
        return s.toString();
    }
    
}