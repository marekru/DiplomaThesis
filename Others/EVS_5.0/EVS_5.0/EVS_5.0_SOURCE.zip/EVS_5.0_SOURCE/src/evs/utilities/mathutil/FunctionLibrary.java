package evs.utilities.mathutil;

//EVS dependencies
import evs.utilities.matrix.DoubleMatrix1D;
import evs.utilities.matrix.IntegerMatrix1D;
import evs.utilities.matrix.Matrix1D; 

//java util dependencies
import java.util.Arrays;
import java.util.TreeMap;

/**
 * IMPORTANT: WHEN ADDING NEW FUNCTIONS, ENSURE THEY ARE ACCESSIBLE TO THE 
 * GENERIC METHODS GETUNARYFUNCTION(), GETBINARYFUNCTION() ETC. DEPENDING ON
 * THE FUNCTION TYPE.
 * 
 * Function objects to be passed to generic methods.
 * <p>Function objects conveniently allow to express arbitrary functions in a generic
 * manner. Essentially, a function object is an object that can perform a function
 * on some arguments. It has a minimal interface: a method <tt>apply</tt> that
 * takes the arguments, computes something and returns some result value. Function
 * objects are comparable to function pointers in C used for call-backs.
 * <p>Unary functions are of type due.utilities.mathutil.DoubleFunction, binary functions
 * of type due.utilities.mathutil.DoubleDoubleFunction. All can be retrieved via <tt>public
 * static final</tt> variables named after the function.
 * Unary predicates are of type due.utilities.mathutil.DoubleProcedure, binary predicates
 * of type due.utilities.mathutil.DoubleDoubleProcedure. All can be retrieved via <tt>public
 * static final</tt> variables named <tt>isXXX</tt>.
 *  
 * <p> Binary functions and predicates also exist as unary functions with the second argument being
 * fixed to a constant. These are generated and retrieved via factory methods (again
 * with the same name as the function). Example:
 * <ul>
 * <li><tt>FunctionLibrary.pow</tt> gives the function <tt>a<sup>b</sup></tt>.
 * <li><tt>FunctionLibrary.pow.apply(2,3)==8</tt>.
 * <li><tt>FunctionLibrary.pow(3)</tt> gives the function <tt>a<sup>3</sup></tt>.
 * <li><tt>FunctionLibrary.pow(3).apply(2)==8</tt>.
 * </ul>
 * More general, any binary function can be made an unary functions by fixing either
 * the first or the second argument. See methods #bindArg1(DoubleDoubleFunction,double)
 * and #bindArg2(DoubleDoubleFunction,double). The order of arguments
 * can be swapped so that the first argument becomes the second and vice-versa. See
 * method #swapArgs(DoubleDoubleFunction). Example:
 * <ul>
 * <li><tt>FunctionLibrary.pow</tt> gives the function <tt>a<sup>b</sup></tt>.
 * <li><tt>FunctionLibrary.bindArg2(FunctionLibrary.pow,3)</tt> gives the function <tt>x<sup>3</sup></tt>.
 * <li><tt>FunctionLibrary.bindArg1(FunctionLibrary.pow,3)</tt> gives the function <tt>3<sup>x</sup></tt>.
 * <li><tt>FunctionLibrary.swapArgs(FunctionLibrary.pow)</tt> gives the function <tt>b<sup>a</sup></tt>.
 * </ul>
 * <p>
 * Even more general, functions can be chained (composed, assembled). Assume we have two unary
 * functions <tt>g</tt> and <tt>h</tt>. The unary function <tt>g(h(a))</tt> applying
 * both in sequence can be generated via #chain(DoubleFunction,DoubleFunction):
 * <ul>
 * <li><tt>FunctionLibrary.chain(g,h);</tt>
 * </ul>
 * Assume further we have a binary function <tt>f</tt>. The binary function <tt>g(f(a,b))</tt>
 * can be generated via #chain(DoubleFunction,DoubleDoubleFunction):
 * <ul>
 * <li><tt>FunctionLibrary.chain(g,f);</tt>
 * </ul>
 * The binary function <tt>f(g(a),h(b))</tt>
 * can be generated via #chain(DoubleDoubleFunction,DoubleFunction,DoubleFunction):
 * <ul>
 * <li><tt>FunctionLibrary.chain(f,g,h);</tt>
 * </ul>
 * Arbitrarily complex functions can be composed from these building blocks. For example
 * <tt>sin(a) + cos<sup>2</sup>(b)</tt> can be specified as follows:
 * <ul>
 * <li><tt>chain(plus,sin,chain(square,cos));</tt>
 * </ul>
 * or, of course, as
 * <pre>
 * new DoubleDoubleFunction() {
 * &nbsp;&nbsp;&nbsp;public final double apply(double a, double b) { return Math.sin(a) + Math.pow(Math.cos(b),2); }
 * }
 * </pre>
 * <p>
 * For aliasing see #functions.
 * Try this
 * <table>
 * <td class="PRE">
 * <pre>
 * // should yield 1.4399560356056456 in all cases
 * double a = 0.5;
 * double b = 0.2;
 * double v = Math.sin(a) + Math.pow(Math.cos(b),2);
 * System.out.println(v);
 * FunctionLibrary F = FunctionLibrary.functions;
 * DoubleDoubleFunction f = F.chain(F.plus,F.sin,F.chain(F.square,F.cos));
 * System.out.println(f.apply(a,b));
 * DoubleDoubleFunction g = new DoubleDoubleFunction() {
 * &nbsp;&nbsp;&nbsp;public double apply(double a, double b) { return Math.sin(a) + Math.pow(Math.cos(b),2); }
 * };
 * System.out.println(g.apply(a,b));
 * </pre>
 * </td>
 * </table>
 * 
 * <p>
 * <H3>Performance</H3>
 * 
 * Surprise. Using modern non-adaptive JITs such as SunJDK 1.2.2 (java -classic)
 * there seems to be no or only moderate performance penalty in using function
 * objects in a loop over traditional code in a loop. For complex nested function
 * objects (e.g. <tt>F.chain(F.abs,F.chain(F.plus,F.sin,F.chain(F.square,F.cos)))</tt>)
 * the penalty is zero, for trivial functions (e.g. <tt>F.plus</tt>) the penalty
 * is often acceptable.
 * <center>
 * <table border cellpadding="3" cellspacing="0" align="center">
 * <tr valign="middle" bgcolor="#33CC66" nowrap align="center">
 * <td nowrap colspan="7"> <font size="+2">Iteration Performance [million function
 * evaluations per second]</font><br>
 * <font size="-1">Pentium Pro 200 Mhz, SunJDK 1.2.2, NT, java -classic,
 * </font></td>
 * </tr>
 * <tr valign="middle" bgcolor="#66CCFF" nowrap align="center">
 * <td nowrap bgcolor="#FF9966" rowspan="2">&nbsp;</td>
 * <td bgcolor="#FF9966" colspan="2">
 * <p> 30000000 iterations</p>
 * </td>
 * <td bgcolor="#FF9966" colspan="2"> 3000000 iterations (10 times less)</td>
 * <td bgcolor="#FF9966" colspan="2">&nbsp;</td>
 * </tr>
 * <tr valign="middle" bgcolor="#66CCFF" nowrap align="center">
 * <td bgcolor="#FF9966"> <tt>F.plus</tt></td>
 * <td bgcolor="#FF9966"><tt>a+b</tt></td>
 * <td bgcolor="#FF9966"> <tt>F.chain(F.abs,F.chain(F.plus,F.sin,F.chain(F.square,F.cos)))</tt></td>
 * <td bgcolor="#FF9966"> <tt>Math.abs(Math.sin(a) + Math.pow(Math.cos(b),2))</tt></td>
 * <td bgcolor="#FF9966">&nbsp;</td>
 * <td bgcolor="#FF9966">&nbsp;</td>
 * </tr>
 * <tr valign="middle" bgcolor="#66CCFF" nowrap align="center">
 * <td nowrap bgcolor="#FF9966">&nbsp;</td>
 * <td nowrap>10.8</td>
 * <td nowrap>29.6</td>
 * <td nowrap>0.43</td>
 * <td nowrap>0.35</td>
 * <td nowrap>&nbsp;</td>
 * <td nowrap>&nbsp;</td>
 * </tr>
 * </table></center>
 * 
 * @author wolfgang.hoschek@cern.ch and evs@hydrosolved.com
 * @version 4.0, 09/24/99
 */

public class FunctionLibrary implements java.io.Serializable {
    
/*******************************************************************************
 *                                                                             *
 *                             INSTANCE VARIABLES                              *
 *                                                                             *
 ******************************************************************************/     
    
    /**
     * Names of supported unary functions.
     */
    
    private static String[] unary = new String[] {
        "plus","minus","div","mult","abs","acos","acosh","asin","asinh","atan",
        "atanh","ceil","cos","cosh","cot","erf","erfc","exp","floor","gamma",
        "identity","inv","log","log10","log2","logGamma","rint","sign","sin",
        "sinh","sqrt","square","tan","tanh","compare","constant","assign",
        "equals","greater","IEEEremainder","less","lessEqual","lg","max","min","minusMult",
        "mod","plusMult","pow","round"
    };
    
    /**
     * Names of supported binary functions.
     */
    
    private static String[] binary = new String[] {
        "plus","minus","div","mult","less","lg","max","min","minus","mod","mult",
        "plusAbs","pow","atan2","logBeta","compare","div","equals","greater",
        "IEEEremainder","minusMult","plusMult","swapArgs"
    };
    
    /**
     * Names of supported vector functions.
     */
    
    private static String[] vector = new String[] {
        "maximum","minimum","mean","median","mode","range","stdev","total","valueForProbability",
        "probabilityForValue","first","last"
    };     
    
    /**
     * Names of supported functions for space-time aggregation/disaggregation
     */
     
    private static String[] aggregation = {"mean","total","maximum","minimum","median","mode","first","last"};
    
    /** The smallest relative spacing for doubles.*/
    public final static double EPSILON_SMALL = 1.1102230246252e-16;
    
    /** The largest relative spacing for doubles. */
    public final static double EPSILON_LARGE = 2.2204460492503e-16;
	
    // Series on [0,0.0625]
    private static final double[] COT_COEF = {
		.240259160982956302509553617744970e+0,
		-.165330316015002278454746025255758e-1,
		-.429983919317240189356476228239895e-4,
		-.159283223327541046023490851122445e-6,
		-.619109313512934872588620579343187e-9,
		-.243019741507264604331702590579575e-11,
		-.956093675880008098427062083100000e-14,
		-.376353798194580580416291539706666e-16,
		-.148166574646746578852176794666666e-18
    };

    // Series on the interval [0,1]
    private static final double[] SINH_COEF = {
		0.1730421940471796,
		0.08759422192276048,
		0.00107947777456713,
		0.00000637484926075,
		0.00000002202366404,
		0.00000000004987940,
		0.00000000000007973,
		0.00000000000000009};
                
    // Series on [0,1]
    private static final double[] TANH_COEF = {
		-.25828756643634710,
		-.11836106330053497,
		.009869442648006398,
		-.000835798662344582,
		.000070904321198943,
		-.000006016424318120,
		.000000510524190800,
		-.000000043320729077,
		.000000003675999055,
		-.000000000311928496,
		.000000000026468828,
		-.000000000002246023,
		.000000000000190587,
		-.000000000000016172,
		.000000000000001372,
		-.000000000000000116,
		.000000000000000009};
    
    // Series on the interval [0,1]
    private static final double[] ASINH_COEF = {
		 -.12820039911738186343372127359268e+0,
		-.58811761189951767565211757138362e-1,
		.47274654322124815640725249756029e-2,
		-.49383631626536172101360174790273e-3,
		.58506207058557412287494835259321e-4,
		-.74669983289313681354755069217188e-5,
		.10011693583558199265966192015812e-5,
		-.13903543858708333608616472258886e-6,
		.19823169483172793547317360237148e-7,
		-.28847468417848843612747272800317e-8,
		.42672965467159937953457514995907e-9,
		-.63976084654366357868752632309681e-10,
		.96991686089064704147878293131179e-11,
		-.14844276972043770830246658365696e-11,
		.22903737939027447988040184378983e-12,
		-.35588395132732645159978942651310e-13,
		.55639694080056789953374539088554e-14,
		-.87462509599624678045666593520162e-15,
		.13815248844526692155868802298129e-15,
		-.21916688282900363984955142264149e-16,
		.34904658524827565638313923706880e-17
    };

    // Series on the interval [0,0.25]
    private static final double[] ATANH_COEF = {
		.9439510239319549230842892218633e-1,
		.4919843705578615947200034576668e-1,
		.2102593522455432763479327331752e-2,
		.1073554449776116584640731045276e-3,
		.5978267249293031478642787517872e-5,
		.3505062030889134845966834886200e-6,
		.2126374343765340350896219314431e-7,
		.1321694535715527192129801723055e-8,
		.8365875501178070364623604052959e-10,
		.5370503749311002163881434587772e-11,
		.3486659470157107922971245784290e-12,
		.2284549509603433015524024119722e-13,
		.1508407105944793044874229067558e-14,
		.1002418816804109126136995722837e-15,
		.6698674738165069539715526882986e-17,
		.4497954546494931083083327624533e-18
    };

    // Series on the interval [0,1]
    private static final double[] GAMMA_COEF = {
		.8571195590989331421920062399942e-2,
		.4415381324841006757191315771652e-2,
		.5685043681599363378632664588789e-1,
		-.4219835396418560501012500186624e-2,
		.1326808181212460220584006796352e-2,
		-.1893024529798880432523947023886e-3,
		.3606925327441245256578082217225e-4,
		-.6056761904460864218485548290365e-5,
		.1055829546302283344731823509093e-5,
		-.1811967365542384048291855891166e-6,
		.3117724964715322277790254593169e-7,
		-.5354219639019687140874081024347e-8,
		.9193275519859588946887786825940e-9,
		-.1577941280288339761767423273953e-9,
		.2707980622934954543266540433089e-10,
		-.4646818653825730144081661058933e-11,
		.7973350192007419656460767175359e-12,
		-.1368078209830916025799499172309e-12,
		.2347319486563800657233471771688e-13,
		-.4027432614949066932766570534699e-14,
		.6910051747372100912138336975257e-15,
		-.1185584500221992907052387126192e-15,
		.2034148542496373955201026051932e-16,
		-.3490054341717405849274012949108e-17,
		.5987993856485305567135051066026e-18,
		-.1027378057872228074490069778431e-18
    };

    //Series for the interval [0,0.01]
    private static final double[] R9LGMC_COEF = {
		.166638948045186324720572965082e0,
		-.138494817606756384073298605914e-4,
		.981082564692472942615717154749e-8,
		-.180912947557249419426330626672e-10,
		.622109804189260522712601554342e-13,
		-.339961500541772194430333059967e-15,
		.268318199848269874895753884667e-17
    };

    // Series on [-0.375,0.375]
    private static final double[] ALNRCS_COEF = {
	   .103786935627437698006862677191e1,
	  -.133643015049089180987660415531,
	  .194082491355205633579261993748e-1,
	  -.301075511275357776903765377766e-2,
	  .486946147971548500904563665091e-3,
	  -.810548818931753560668099430086e-4,
	  .137788477995595247829382514961e-4,
	  -.238022108943589702513699929149e-5,
	  .41640416213865183476391859902e-6,
	  -.73595828378075994984266837032e-7,
	  .13117611876241674949152294345e-7,
	  -.235467093177424251366960923302e-8,
	  .425227732760349977756380529626e-9,
	  -.771908941348407968261081074933e-10,
	  .140757464813590699092153564722e-10,
	  -.257690720580246806275370786276e-11,
	  .473424066662944218491543950059e-12,
	  -.872490126747426417453012632927e-13,
	  .161246149027405514657398331191e-13,
	  -.298756520156657730067107924168e-14,
	  .554807012090828879830413216973e-15,
	  -.103246191582715695951413339619e-15,
	  .192502392030498511778785032449e-16,
	  -.359550734652651500111897078443e-17,
	  .672645425378768578921945742268e-18,
	  -.126026241687352192520824256376e-18
    };
	
    // Series on [0,1]
    private static final double[] ERFC_COEF = {
	 -.490461212346918080399845440334e-1,
	 -.142261205103713642378247418996e0,
	 .100355821875997955757546767129e-1,
	 -.576876469976748476508270255092e-3,
	 .274199312521960610344221607915e-4,
	 -.110431755073445076041353812959e-5,
	 .384887554203450369499613114982e-7,
	 -.118085825338754669696317518016e-8,
	 .323342158260509096464029309534e-10,
	 -.799101594700454875816073747086e-12,
	 .179907251139614556119672454866e-13,
	 -.371863548781869263823168282095e-15,
	 .710359900371425297116899083947e-17,
	 -.126124551191552258324954248533e-18
    };

    // Series on [0.25,1.00]
    private static final double[] ERFC2_COEF = {
	 -.69601346602309501127391508262e-1,
	 -.411013393626208934898221208467e-1,
	 .391449586668962688156114370524e-2,
	 -.490639565054897916128093545077e-3,
	 .715747900137703638076089414183e-4,
	 -.115307163413123283380823284791e-4,
	 .199467059020199763505231486771e-5,
	 -.364266647159922287393611843071e-6,
	 .694437261000501258993127721463e-7,
	 -.137122090210436601953460514121e-7,
	 .278838966100713713196386034809e-8,
	 -.581416472433116155186479105032e-9,
	 .123892049175275318118016881795e-9,
	 -.269063914530674343239042493789e-10,
	 .594261435084791098244470968384e-11,
	 -.133238673575811957928775442057e-11,
	 .30280468061771320171736972433e-12,
	 -.696664881494103258879586758895e-13,
	 .162085454105392296981289322763e-13,
	 -.380993446525049199987691305773e-14,
	 .904048781597883114936897101298e-15,
	 -.2164006195089607347809812047e-15,
	 .522210223399585498460798024417e-16,
	 -.126972960236455533637241552778e-16,
	 .310914550427619758383622741295e-17,
	 -.766376292032038552400956671481e-18,
	 .190081925136274520253692973329e-18
  	};

    // Series on [0,0.25]
    private static final double[] ERFCC_COEF = {
	 .715179310202924774503697709496e-1,
	 -.265324343376067157558893386681e-1,
	 .171115397792085588332699194606e-2,
	 -.163751663458517884163746404749e-3,
	 .198712935005520364995974806758e-4,
	 -.284371241276655508750175183152e-5,
	 .460616130896313036969379968464e-6,
	 -.822775302587920842057766536366e-7,
	 .159214187277090112989358340826e-7,
	 -.329507136225284321486631665072e-8,
	 .72234397604005554658126115389e-9,
	 -.166485581339872959344695966886e-9,
	 .401039258823766482077671768814e-10,
	 -.100481621442573113272170176283e-10,
	 .260827591330033380859341009439e-11,
	 -.699111056040402486557697812476e-12,
	 .192949233326170708624205749803e-12,
	 -.547013118875433106490125085271e-13,
	 .158966330976269744839084032762e-13,
	 -.47268939801975548392036958429e-14,
	 .14358733767849847867287399784e-14,
	 -.444951056181735839417250062829e-15,
	 .140481088476823343737305537466e-15,
	 -.451381838776421089625963281623e-16,
	 .147452154104513307787018713262e-16,
	 -.489262140694577615436841552532e-17,
	 .164761214141064673895301522827e-17,
	 -.562681717632940809299928521323e-18,
	 .194744338223207851429197867821e-18
    };    
    
/*******************************************************************************
 *                                                                             *
 *                              DUMMY CONSTRUCTOR                              *
 *                                                                             *
 ******************************************************************************/
    
    /**
     * Makes this class non instantiable, but still let's others inherit from it.
     */
    
    protected FunctionLibrary() {}
    
/*******************************************************************************
 *                                                                             *
 *                              ACCESSOR METHODS                               *
 *                                                                             *
 ******************************************************************************/     
    
    /**
     * Returns true if the function represented by the String argument is supported.
     * 
     * @return true if the function is supported.
     */  
    
    public static boolean isSupportedFunction(String s) {
        try {
            getUnaryFunction(s);
            return true;
        }
        catch(UnsupportedOperationException e) {
            try {
                getBinaryFunction(s);
                return true;
            }
            catch(UnsupportedOperationException f) {
                try {
                    getVectorFunction(s);
                    return true;
                }
                catch(UnsupportedOperationException g) {
                    try {
                        getAggregationFunction(s);
                        return true;
                    }
                    catch(UnsupportedOperationException h) {
                        return false;
                    }
                }
            }
        }            
    }
    
    /**
     * Returns true if the unary function represented by the String argument is 
     * supported.
     * 
     * @return true if the function is supported.
     */  
    
    public static boolean isSupportedUnaryFunction(String s) {
        try {
            getUnaryFunction(s,0);
            return true;
        }
        catch(UnsupportedOperationException e) {
            return false;
        }        
    }    
    
    /**
     * Returns true if the binary function represented by the String argument is 
     * supported.
     * 
     * @return true if the function is supported.
     */  
    
    public static boolean isSupportedBinaryFunction(String s) {
        try {
            getBinaryFunction(s);
            return true;
        }
        catch(UnsupportedOperationException e) {
            return false;
        }        
    }    
    
    /**
     * Returns true if the vector function represented by the String argument is 
     * supported.
     * 
     * @return true if the function is supported.
     */  
    
    public static boolean isSupportedVectorFunction(String s) {
        try {
            getVectorFunction(s);
            return true;
        }
        catch(UnsupportedOperationException e) {
            try {
                getVectorFunction(s,0.0);
                return true;
            }
            catch(Exception f) {
                return false;
            }
        }        
    }       

    /**
     * Returns true if the aggregation function represented by the String argument 
     * is supported.
     * 
     * @return true if the function is supported.
     */  
    
    public static boolean isSupportedAggregationFunction(String s) {
        String[] a = Arrays.copyOf(aggregation,aggregation.length);
        Arrays.sort(a);
        return java.util.Arrays.binarySearch(a,s.toLowerCase()) > -1;
    }       
    
    /**
     * Returns the names of supported unary functions in an array.
     *
     * @return an array of supported unary functions
     */
    
    public static String[] getSupportedUnaryFunctions() {
        return Arrays.copyOf(unary,unary.length);
    }
    
    /**
     * Returns the names of supported binary functions in an array.
     *
     * @return an array of supported binary functions
     */
    
    public static String[] getSupportedBinaryFunctions() {
        return Arrays.copyOf(binary,binary.length);
    }    
    
    /**
     * Returns the names of supported vector functions in an array.
     *
     * @return an array of supported vector functions
     */
    
    public static String[] getSupportedVectorFunctions() {
        return Arrays.copyOf(vector,vector.length);
    }     
    
    /**
     * Returns the names of supported aggregation functions in an array.
     *
     * @return an array of supported aggregation functions
     */
    
    public static String[] getSupportedAggregationFunctions() {
        return Arrays.copyOf(aggregation,aggregation.length);
    }     
    
    /**
     * Returns an instance of the unary function represented by the string argument 
     * or throws an exception if the function does not exist.
     *
     * @param a the function constant 
     * @param s the function
     * @return a function corresponding to the string
     */
    
    public static DoubleFunction getUnaryFunction(String s, double a) throws UnsupportedOperationException {
        try {
            if(s.equals("+")) s = "plus";
            if(s.equals("-")) s = "minus";
            if(s.equals("/")) s = "div";
            if(s.equals("*")) s = "mult";            
            return (DoubleFunction)FunctionLibrary.class.getMethod(s,new Class[]{double.class}).invoke(null,new Object[]{new Double(a)});
        }
        catch(Exception e) {  //Functions accessed by field calls
            throw new UnsupportedOperationException("Function '"+s+"' is not supported.");
        }
    }
    
    /**
     * Returns an instance of the double procedure represented by the string argument
     * or throws an exception if the function does not exist.
     *
     * @param a the function constant 
     * @param s the function
     * @return a function corresponding to the string
     */
    
    public static DoubleProcedure getDoubleProcedure(String s, double a) throws UnsupportedOperationException {
        try {
            return (DoubleProcedure)FunctionLibrary.class.getMethod(s,new Class[]{double.class}).invoke(null,new Object[]{new Double(a)});
        }
        catch(Exception e) {  
            throw new UnsupportedOperationException("Function '"+s+"' is not supported.");
        }
    }

    /**
     * Returns an instance of the vector function represented by the string argument
     * or throws an exception if the function does not exist.
     *
     * @param a the function constant
     * @param s the function
     * @return a function corresponding to the string
     */

    public static VectorFunction getVectorFunction(String s, double a) throws UnsupportedOperationException {
        try {
            return (VectorFunction)FunctionLibrary.class.getMethod(s,new Class[]{double.class}).invoke(null,new Object[]{new Double(a)});
        }
        catch(Exception e) {
            String message  = "Function '"+s+"' is not supported with parameter value '"+a+"'.";
            throw new UnsupportedOperationException(message);
        }
    }

    /**
     * Returns an instance of the unary function represented by the string argument 
     * or throws an exception if the function does not exist.
     *
     * @param s the function
     * @return a function corresponding to the string
     */
    
    public static DoubleFunction getUnaryFunction(String s) throws UnsupportedOperationException {
            if(s.equals("abs")) return FunctionLibrary.abs;
            else if(s.equalsIgnoreCase("acos")) return FunctionLibrary.acos;
            else if(s.equalsIgnoreCase("acosh")) return FunctionLibrary.acosh;
            else if(s.equalsIgnoreCase("asin")) return FunctionLibrary.asin;
            else if(s.equalsIgnoreCase("assign")) return FunctionLibrary.assign;
            else if(s.equalsIgnoreCase("asinh")) return FunctionLibrary.asinh;
            else if(s.equalsIgnoreCase("atan")) return FunctionLibrary.atan;
            else if(s.equalsIgnoreCase("atanh")) return FunctionLibrary.atanh;
            else if(s.equalsIgnoreCase("ceil")) return FunctionLibrary.ceil;
            else if(s.equalsIgnoreCase("cos")) return FunctionLibrary.cos;
            else if(s.equalsIgnoreCase("cosh")) return FunctionLibrary.cosh;
            else if(s.equalsIgnoreCase("cot")) return FunctionLibrary.cot;
            else if(s.equalsIgnoreCase("erf")) return FunctionLibrary.erf;
            else if(s.equalsIgnoreCase("erfc")) return FunctionLibrary.erfc;
            else if(s.equalsIgnoreCase("exp")) return FunctionLibrary.exp;
            else if(s.equalsIgnoreCase("floor")) return FunctionLibrary.floor;
            else if(s.equalsIgnoreCase("gamma")) return FunctionLibrary.gamma;
            else if(s.equalsIgnoreCase("identity")) return FunctionLibrary.identity;
            else if(s.equalsIgnoreCase("inv")) return FunctionLibrary.inv;
            else if(s.equalsIgnoreCase("log")) return FunctionLibrary.log;
            else if(s.equalsIgnoreCase("log10")) return FunctionLibrary.log10;
            else if(s.equalsIgnoreCase("log2")) return FunctionLibrary.log2;
            else if(s.equalsIgnoreCase("logGamma")) return FunctionLibrary.logGamma;
            else if(s.equalsIgnoreCase("rint")) return FunctionLibrary.rint;
            else if(s.equalsIgnoreCase("sign")) return FunctionLibrary.sign;
            else if(s.equalsIgnoreCase("sin")) return FunctionLibrary.sin;
            else if(s.equalsIgnoreCase("sinh")) return FunctionLibrary.sinh;
            else if(s.equalsIgnoreCase("sqrt")) return FunctionLibrary.sqrt;
            else if(s.equalsIgnoreCase("square")) return FunctionLibrary.square;
            else if(s.equalsIgnoreCase("tan")) return FunctionLibrary.tan;
            else if(s.equalsIgnoreCase("tanh")) return FunctionLibrary.tanh;               
            else throw new UnsupportedOperationException("Function '"+s+"' is not supported.");
    }    
    

    /**
     * Returns an instance of the binary function represented by the string argument 
     * or throws an exception if the function does not exist.
     *
     * @param s the function name
     * @return a function corresponding to the string
     */
    
    public static DoubleDoubleFunction getBinaryFunction(String s) throws UnsupportedOperationException {
        try {
            if(s.equals("+")) s = "plus";
            if(s.equals("-")) s = "minus";
            if(s.equals("/")) s = "div";
            if(s.equals("*")) s = "mult";
            if(s.equals("=")) s = "equals";
            return (DoubleDoubleFunction)FunctionLibrary.class.getMethod(s, (Class[])null).invoke(null,(Object[])null);
        }
        catch(Exception e) { //FunctionLibrary accessed by field calls
            if(s.equals("less")) return FunctionLibrary.less;
            else if(s.equalsIgnoreCase("lg")) return FunctionLibrary.lg;
            else if(s.equalsIgnoreCase("max")) return FunctionLibrary.max;
            else if(s.equalsIgnoreCase("min")) return FunctionLibrary.min;
            else if(s.equalsIgnoreCase("minus")) return FunctionLibrary.minus;
            else if(s.equalsIgnoreCase("mod")) return FunctionLibrary.mod;
            else if(s.equalsIgnoreCase("mult")) return FunctionLibrary.mult;
            else if(s.equalsIgnoreCase("plus")) return FunctionLibrary.plus;
            else if(s.equalsIgnoreCase("plusAbs")) return FunctionLibrary.plusAbs;
            else if(s.equalsIgnoreCase("pow")) return FunctionLibrary.pow;
            else if(s.equalsIgnoreCase("atan2")) return FunctionLibrary.atan2;
            else if(s.equalsIgnoreCase("logBeta")) return FunctionLibrary.logBeta;
            else if(s.equalsIgnoreCase("compare")) return FunctionLibrary.compare;
            else if(s.equalsIgnoreCase("div")) return FunctionLibrary.div;
            else if(s.equalsIgnoreCase("equals")) return FunctionLibrary.equals;
            else if(s.equalsIgnoreCase("greater")) return FunctionLibrary.greater;
            else if(s.equalsIgnoreCase("IEEEremainder")) return FunctionLibrary.IEEEremainder;           
            else throw new UnsupportedOperationException("Function '"+s+"' is not supported.");
        }
    }   
    
    /**
     * Returns an instance of the vector function represented by the string argument 
     * or throws an exception if the function does not exist.
     *
     * @param s the function name
     * @return a function corresponding to the string
     */
    
    public static VectorFunction getVectorFunction(String s) throws UnsupportedOperationException {
        try {            
            return (VectorFunction)FunctionLibrary.class.getMethod(s.toLowerCase(), (Class[])null).invoke(null,(Object[])null);
        }
        catch(Exception e) { 
            e.printStackTrace();
            throw new UnsupportedOperationException("Function '"+s+"' is not supported.");
        }
    }       
    
    /**
     * Returns an instance of the aggregation function represented by the string argument 
     * or throws an exception if the function does not exist.
     *
     * @param s the function name
     * @return a function corresponding to the string
     */
    
    public static VectorFunction getAggregationFunction(String s) throws UnsupportedOperationException {
        try {
            Arrays.sort(aggregation);
            if(! (java.util.Arrays.binarySearch(aggregation,s) > -1)) {
                throw new UnsupportedOperationException();
            }
            return (VectorFunction)FunctionLibrary.class.getMethod(s.toLowerCase(), (Class[])null).invoke(null,(Object[])null);
        }
        catch(Exception e) { 
            throw new UnsupportedOperationException("Function '"+s+"' is not supported.");
        }
    }

    /**
     * Allows for "aliasing" of the class. Writing code like
     * <p>
     * <tt>FunctionLibrary.chain(FunctionLibrary.plus,FunctionLibrary.sin,FunctionLibrary.chain(FunctionLibrary.square,FunctionLibrary.cos));</tt>
     * <p>
     * is a bit awkward.  Using aliasing you can instead write
     * <p>
     * <tt>FunctionLibrary F = FunctionLibrary.functions; <br>
     * F.chain(F.plus,F.sin,F.chain(F.square,F.cos));</tt>
     */
        
    public static final FunctionLibrary FUNCTIONS = new FunctionLibrary();
    
    /*****************************
     * <H3>Unary functions</H3>
     *****************************/
    
    /**
     * Function that returns <tt>Math.abs(a)</tt>.
     */
    
    public static final DoubleFunction abs = new DoubleFunction() {
        public final double apply(double a) { return Math.abs(a); }
        public String toString() {return "abs";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    }; 
    
    /**
     * Function that returns <tt>Math.acos(a)</tt>.
     */
    
    public static final DoubleFunction acos = new DoubleFunction() {
        public final double apply(double a) { return Math.acos(a); }
        public String toString() {return "acos";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>acosh(a)</tt>.
     */
    
    public static final DoubleFunction acosh = new DoubleFunction() {
        public final double apply(double a) { return acosh(a); }
        public String toString() {return "acosh";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>Math.asin(a)</tt>.
     */
    
    public static final DoubleFunction asin = new DoubleFunction() {
        public final double apply(double a) { return Math.asin(a); }
        public String toString() {return "asin";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>asinh(a)</tt>.
     */
    
    public static final DoubleFunction asinh = new DoubleFunction() {
        public final double apply(double a) { return asinh(a); }
        public String toString() {return "asinh";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>Math.atan(a)</tt>.
     */
    
    public static final DoubleFunction atan = new DoubleFunction() {
        public final double apply(double a) { return Math.atan(a); }
        public String toString() {return "atan";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>atanh(a)</tt>.
     */
    
    public static final DoubleFunction atanh = new DoubleFunction() {
        public final double apply(double a) { return atanh(a); }
        public String toString() {return "atanh";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>Math.ceil(a)</tt>.
     */
        
    public static final DoubleFunction ceil = new DoubleFunction() {
        public final double apply(double a) { return Math.ceil(a); }
        public String toString() {return "ceil";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>Math.cos(a)</tt>.
     */
    
    public static final DoubleFunction cos = new DoubleFunction() {
        public final double apply(double a) { return Math.cos(a); }
        public String toString() {return "cos";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>cosh(a)</tt>.
     */
    
    public static final DoubleFunction cosh = new DoubleFunction() {
        public final double apply(double a) { return cosh(a); }
        public String toString() {return "cosh";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>cot(a)</tt>.
     */
    
    public static final DoubleFunction cot = new DoubleFunction() {
        public final double apply(double a) { return cot(a); }
        public String toString() {return "cot";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>erf(a)</tt>.
     */
    
    public static final DoubleFunction erf = new DoubleFunction() {
        public final double apply(double a) { return erf(a); }
        public String toString() {return "erf";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>erfc(a)</tt>.
     */
    
    public static final DoubleFunction erfc = new DoubleFunction() {
        public final double apply(double a) { return erfc(a); }
        public String toString() {return "erfc";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>Math.exp(a)</tt>.
     */
    
    public static final DoubleFunction exp = new DoubleFunction() {
        public final double apply(double a) { return Math.exp(a); }
        public String toString() {return "exp";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>Math.floor(a)</tt>.
     */
    
    public static final DoubleFunction floor = new DoubleFunction() {
        public final double apply(double a) { return Math.floor(a); }
        public String toString() {return "floor";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>gamma(a)</tt>.
     */
    
    public static final DoubleFunction gamma = new DoubleFunction() {
        public final double apply(double a) { return gamma(a); }
        public String toString() {return "gamma";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns its argument.
     */
    
    public static final DoubleFunction identity = new DoubleFunction() {
        public final double apply(double a) { return a; }
        public String toString() {return "identity";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>1.0 / a</tt>.
     */
    
    public static final DoubleFunction inv = new DoubleFunction() {
        public final double apply(double a) { return 1.0 / a; }
        public String toString() {return "inv";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>Math.log(a)</tt>.
     */
    
    public static final DoubleFunction log = new DoubleFunction() {
        public final double apply(double a) { return Math.log(a); }
        public String toString() {return "log";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>com.imsl.math.log10(a)</tt>.
     */
    
    public static final DoubleFunction log10 = new DoubleFunction() {
        public final double apply(double a) { return log10(a); }
        public String toString() {return "log10";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>Math.log(a) / Math.log(2)</tt>.
     */
    public static final DoubleFunction log2 = new DoubleFunction() {
        // 1.0 / Math.log(2) == 1.4426950408889634
        public final double apply(double a) { return Math.log(a) * 1.4426950408889634; }
        public String toString() {return "log2";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>logGamma(a)</tt>.
     */
    
    public static final DoubleFunction logGamma = new DoubleFunction() {
        public final double apply(double a) { return logGamma(a); }
        public String toString() {return "logGamma";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>-a</tt>.
     */
    
    public static final DoubleFunction neg = new DoubleFunction() {
        public final double apply(double a) { return -a; }
        public String toString() {return "neg";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>Math.rint(a)</tt>.
     */
    
    public static final DoubleFunction rint = new DoubleFunction() {
        public final double apply(double a) { return Math.rint(a); }
        public String toString() {return "rint";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>a < 0 ? -1 : a > 0 ? 1 : 0</tt>.
     */
    
    public static final DoubleFunction sign = new DoubleFunction() {
        public final double apply(double a) { return a < 0 ? -1 : a > 0 ? 1 : 0; }
        public String toString() {return "sign";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>Math.sin(a)</tt>.
     */
    
    public static final DoubleFunction sin = new DoubleFunction() {
        public final double apply(double a) { return Math.sin(a); }
        public String toString() {return "sin";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>sinh(a)</tt>.
     */
    
    public static final DoubleFunction sinh = new DoubleFunction() {
        public final double apply(double a) { return sinh(a); }
        public String toString() {return "sinh";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>Math.sqrt(a)</tt>.
     */
    
    public static final DoubleFunction sqrt = new DoubleFunction() {
        public final double apply(double a) { return Math.sqrt(a); }
        public String toString() {return "sqrt";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>a * a</tt>.
     */
    
    public static final DoubleFunction square = new DoubleFunction() {
        public final double apply(double a) { return a * a; }
        public String toString() {return "square";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>Math.tan(a)</tt>.
     */
    
    public static final DoubleFunction tan = new DoubleFunction() {
        public final double apply(double a) { return Math.tan(a); }
        public String toString() {return "tan";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that assigns a value to an input
     */
    
    public static final DoubleFunction assign = new DoubleFunction() {
        public final double apply(double a) { return a; }
        public String toString() {return "assign";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };    
    
    /**
     * Function that returns <tt>tanh(a)</tt>.
     */
    
    public static final DoubleFunction tanh = new DoubleFunction() {
        public final double apply(double a) { return tanh(a); }
        public String toString() {return "tanh";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };   

    /**
     * Constructs a function that assigns a value to an input.
     *
     * @param c the input
     */

    public static ObjectFunction assign(final Object c) {
        return new ObjectFunction() {
            public final Object apply(Object a) { return c; }
            public String toString() {return "assign";}
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }    
    
    /*****************************
     * <H3>Binary functions</H3>
     *****************************/
    
    /**  
     * Function that returns <tt>Math.atan2(a,b)</tt>.
     */
    
    public static final DoubleDoubleFunction atan2 = new DoubleDoubleFunction() {
        public final double apply(double a, double b) { return Math.atan2(a,b); }
        public String toString() {return "atan2";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>logBeta(a,b)</tt>.
     */
    
    public static final DoubleDoubleFunction logBeta = new DoubleDoubleFunction() {
        public final double apply(double a, double b) { return logBeta(a,b); }
        public String toString() {return "logBeta";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>a < b ? -1 : a > b ? 1 : 0</tt>.
     */
    
    public static final DoubleDoubleFunction compare = new DoubleDoubleFunction() {
        public final double apply(double a, double b) { return a < b ? -1 : a > b ? 1 : 0; }
        public String toString() {return "compare";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>a / b</tt>.
     */
    
    public static final DoubleDoubleFunction div = new DoubleDoubleFunction() {
        public final double apply(double a, double b) { return a / b; }
        public String toString() {return "div";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>a == b ? 1 : 0</tt>.
     */
    
    public static final DoubleDoubleFunction equals = new DoubleDoubleFunction() {
        public final double apply(double a, double b) { return a == b ? 1 : 0; }
        public String toString() {return "equals";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };   
    
    /**
     * Function that returns <tt>a > b ? 1 : 0</tt>.
     */
    
    public static final DoubleDoubleFunction greater = new DoubleDoubleFunction() {
        public final double apply(double a, double b) { return a > b ? 1 : 0; }
        public String toString() {return "greater";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>Math.IEEEremainder(a,b)</tt>.
     */
    
    public static final DoubleDoubleFunction IEEEremainder = new DoubleDoubleFunction() {
        public final double apply(double a, double b) { return Math.IEEEremainder(a,b); }
        public String toString() {return "IEEEremainder";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>a == b</tt>.
     */

    public static final DoubleDoubleProcedure isEqual = new DoubleDoubleProcedure() {
        public final boolean apply(double a, double b) { return a == b; }
        public String toString() {return "isEqual";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>a < b</tt>.
     */
    
    public static final DoubleDoubleProcedure isLess = new DoubleDoubleProcedure() {
        public final boolean apply(double a, double b) { return a < b; }
        public String toString() {return "isLess";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>a > b</tt>.
     */
    
    public static final DoubleDoubleProcedure isGreater = new DoubleDoubleProcedure() {
        public final boolean apply(double a, double b) { return a > b; }
        public String toString() {return "isGreater";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>a >= b</tt>.
     */
    
    public static final DoubleDoubleProcedure isGreaterEqual = new DoubleDoubleProcedure() {
        public final boolean apply(double a, double b) { return a >= b; }
        public String toString() {return "isGreaterEqual";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };    
    
    /**
     * Function that returns <tt>a <= b</tt>.
     */
    
    public static final DoubleDoubleProcedure isLessEqual = new DoubleDoubleProcedure() {
        public final boolean apply(double a, double b) { return a <= b; }
        public String toString() {return "isLessEqual";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };     
    
    /**
     * Function that returns <tt>a < b ? 1 : 0</tt>.
     */
    
    public static final DoubleDoubleFunction less = new DoubleDoubleFunction() {
        public final double apply(double a, double b) { return a < b ? 1 : 0; }
        public String toString() {return "less";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>Math.log(a) / Math.log(b)</tt>.
     */
    
    public static final DoubleDoubleFunction lg = new DoubleDoubleFunction() {
        public final double apply(double a, double b) { return Math.log(a) / Math.log(b); }
        public String toString() {return "lg";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>Math.max(a,b)</tt>.
     */
    
    public static final DoubleDoubleFunction max = new DoubleDoubleFunction() {
        public final double apply(double a, double b) { return Math.max(a,b); }
        public String toString() {return "max";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>Math.min(a,b)</tt>.
     */
    
    public static final DoubleDoubleFunction min = new DoubleDoubleFunction() {
        public final double apply(double a, double b) { return Math.min(a,b); }
        public String toString() {return "min";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>a - b</tt>.
     */
    
    public static final DoubleDoubleFunction minus = new DoubleDoubleFunction() {
        private final DoubleDoubleFunction func = plusMult(-1);
        public final double apply(double a, double b) { return func.apply(a,b); }
        public String toString() {return "minus";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>a % b</tt>.
     */
    
    public static final DoubleDoubleFunction mod = new DoubleDoubleFunction() {
        public final double apply(double a, double b) { return a % b; }
        public String toString() {return "mod";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };   
    
    /**
     * Function that returns <tt>a * b</tt>.
     */
    
    public static final DoubleDoubleFunction mult = new DoubleDoubleFunction() {
        public final double apply(double a, double b) { return a * b; }
        public String toString() {return "mult";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>a + b</tt>.
     */
    
    public static final DoubleDoubleFunction plus = new DoubleDoubleFunction() {
        private final DoubleDoubleFunction func = plusMult(1);
        public final double apply(double a, double b) { return func.apply(a,b); }
        public String toString() {return "plus";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>Math.abs(a) + Math.abs(b)</tt>.
     */
    
    public static final DoubleDoubleFunction plusAbs = new DoubleDoubleFunction() {
        public final double apply(double a, double b) { return Math.abs(a) + Math.abs(b); }
        public String toString() {return "plusAbs";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Function that returns <tt>Math.pow(a,b)</tt>.
     */
    
    public static final DoubleDoubleFunction pow = new DoubleDoubleFunction() {
        public final double apply(double a, double b) { return Math.pow(a,b); }
        public String toString() {return "pow";}
        public double[] getConstants() {return null;};
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
        }
        public int hashCode() {
            assert false : "hashCode not implemented for Function.";
            return 1;
        }
    };
    
    /**
     * Constructs a function that returns <tt>(from<=a && a<=to) ? 1 : 0</tt>.
     * <tt>a</tt> is a variable, <tt>from</tt> and <tt>to</tt> are fixed.
     */
    
    public static DoubleFunction between(final double from, final double to) {
        return new DoubleFunction() {
            public final double apply(double a) { return (from<=a && a<=to) ? 1 : 0; }
            public String toString() {return "between";}
            public double[] getConstants() {return new double[]{from,to};};
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass()) 
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a unary function from a binary function with the first operand (argument) fixed to the given constant <tt>c</tt>.
     * The second operand is variable (free).
     *
     * @param function a binary function taking operands in the form <tt>function.apply(c,var)</tt>.
     * @param c a constant
     * @return the unary function <tt>function(c,var)</tt>.
     */
    
    public static DoubleFunction bindArg1(final DoubleDoubleFunction function, final double c) {
        return new DoubleFunction() {
            public final double apply(double var) { return function.apply(c,var); }
            public String toString() {return "bindArg1";}
            public double[] getConstants() {
                double[] d = function.getConstants();
                double[] e = new double[d.length+1];
                System.arraycopy(d,0,e,1,d.length);
                e[0]=c;
                return e;
            };
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass()) 
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a unary function from a binary function with the second operand (argument) fixed to the given constant <tt>c</tt>.
     * The first operand is variable (free).
     *
     * @param function a binary function taking operands in the form <tt>function.apply(var,c)</tt>.
     * @param c a constant
     * @return the unary function <tt>function(var,c)</tt>.
     */
    
    public static DoubleFunction bindArg2(final DoubleDoubleFunction function, final double c) {
        return new DoubleFunction() {
            public final double apply(double var) { return function.apply(var,c); }
            public String toString() {return "bindArg2";}
            public double[] getConstants() {
                double[] d = function.getConstants();
                double[] e = new double[d.length+1];
                System.arraycopy(d,0,e,0,d.length);
                e[d.length]=c;
                return e;
            };
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs the function <tt>f( g(a), h(b) )</tt>.
     *
     * @param f a binary function.
     * @param g a unary function.
     * @param h a unary function.
     * @return the binary function <tt>f( g(a), h(b) )</tt>.
     */
    
    public static DoubleDoubleFunction chain(final DoubleDoubleFunction f, final DoubleFunction g, final DoubleFunction h) {
        return new DoubleDoubleFunction() {
            public final double apply(double a, double b) { return f.apply(g.apply(a), h.apply(b)); }
            public String toString() {return "chain";}
            public double[] getConstants() {
                double[] c = g.getConstants();
                double[] d = h.getConstants();
                double[] e = f.getConstants();
                double[] rm = new double[c.length+d.length+e.length];
                System.arraycopy(c,0,rm,0,c.length);
                System.arraycopy(d,0,rm,c.length,d.length);
                System.arraycopy(e,0,rm,d.length,e.length);
                return rm;
            };
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs the function <tt>g( h(a,b) )</tt>.
     *
     * @param g a unary function.
     * @param h a binary function.
     * @return the unary function <tt>g( h(a,b) )</tt>.
     */
    public static DoubleDoubleFunction chain(final DoubleFunction g, final DoubleDoubleFunction h) {
        return new DoubleDoubleFunction() {
            public final double apply(double a, double b) { return g.apply(h.apply(a,b)); }
            public String toString() {return "chain";}
            public double[] getConstants() {
                double[] d = h.getConstants();
                double[] e = g.getConstants();
                double[] rm = new double[d.length+e.length];
                System.arraycopy(d,0,rm,0,d.length);
                System.arraycopy(e,0,rm,d.length,e.length);
                return rm;
            };
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs the function <tt>g( h(a) )</tt>.
     *
     * @param g a unary function.
     * @param h a unary function.
     * @return the unary function <tt>g( h(a) )</tt>.
     */
    
    public static DoubleFunction chain(final DoubleFunction g, final DoubleFunction h) {
        return new DoubleFunction() {
            public final double apply(double a) { return g.apply(h.apply(a)); }
            public String toString() {return "chain";}
            public double[] getConstants() {
                double[] d = h.getConstants();
                double[] e = g.getConstants();
                double[] rm = new double[d.length+e.length];
                System.arraycopy(d,0,rm,0,d.length);
                System.arraycopy(e,0,rm,d.length,e.length);
                return rm;
            };
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }

    /**
     * Constructs the function ?h(a) : g(a) a
     *
     * @param g a unary function.
     * @param h a double procedure.
     * @return the unary function <tt>g( h(a) )</tt>.
     */

    public static DoubleFunction chain(final DoubleFunction g, final DoubleProcedure h) {
        return new DoubleFunction() {
            public final double apply(double a) {
                if(h.apply(a)) {
                    return g.apply(a);
                }
                return a;
            }
            public String toString() {return "chain";}
            public double[] getConstants() {
                double[] d = h.getConstants();
                double[] e = g.getConstants();
                double[] rm = new double[d.length+e.length];
                System.arraycopy(d,0,rm,0,d.length);
                System.arraycopy(e,0,rm,d.length,e.length);
                return rm;
            };
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that returns <tt>a < b ? -1 : a > b ? 1 : 0</tt>.
     * <tt>a</tt> is a variable, <tt>b</tt> is fixed.
     *
     * @param b the input
     */
    
    public static DoubleFunction compare(final double b) {
        return new DoubleFunction() {
            public final double apply(double a) { return a < b ? -1 : a > b ? 1 : 0; }
            public String toString() {return "chain";}
            public double[] getConstants() {return new double[]{b};};
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that returns the constant <tt>c</tt>.
     *
     * @param c the constant
     */
    
    public static DoubleFunction constant(final double c) {
        return new DoubleFunction() {
            public final double apply(double a) { return c; }
            public String toString() {return "constant";}
            public double[] getConstants() {return new double[]{c};};
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that assigns a value to an input.
     *
     * @param c the input
     */

    public static DoubleFunction assign(final double c) {
        return new DoubleFunction() {
            public final double apply(double a) { return c; }
            public String toString() {return "assign";}
            public double[] getConstants() {return new double[]{c};};
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }      
    
    /**
     * Constructs a function that returns <tt>a / b</tt>.
     * <tt>a</tt> is a variable, <tt>b</tt> is fixed.
     *
     * @param b the input
     */
    
    public static DoubleFunction div(final double b) {
        return mult(1 / b);
    }
    
    /**
     * Constructs a function that returns <tt>a == b ? 1 : 0</tt>.
     * <tt>a</tt> is a variable, <tt>b</tt> is fixed.
     *
     * @param b the input
     */
    
    public static DoubleFunction equals(final double b) {
        return new DoubleFunction() {
            public final double apply(double a) { return a == b ? 1 : 0; }
            public String toString() {return "equals";}
            public double[] getConstants() {return new double[]{b};};
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that returns <tt>a > b ? 1 : 0</tt>.
     * <tt>a</tt> is a variable, <tt>b</tt> is fixed.
     *
     * @param b the input
     */
    
    public static DoubleFunction greater(final double b) {
        return new DoubleFunction() {
            public final double apply(double a) { return a > b ? 1 : 0; }
            public String toString() {return "greater";}
            public double[] getConstants() {return new double[]{b};};
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that returns <tt>Math.IEEEremainder(a,b)</tt>.
     * <tt>a</tt> is a variable, <tt>b</tt> is fixed.
     *
     * @param b the input
     */
    
    public static DoubleFunction ieeeRemainder(final double b) {
        return new DoubleFunction() {
            public final double apply(double a) { return Math.IEEEremainder(a,b); }
            public String toString() {return "IEEEremainder";}
            public double[] getConstants() {return new double[]{b};};
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that returns <tt>from>a || a>to</tt>.
     * <tt>a</tt> is a variable, <tt>from</tt> and <tt>to</tt> are fixed.
     *
     * @param from lower limit
     * @param to upper limit
     */
    
    public static DoubleProcedure isNotBetween(final double from, final double to) {
        return new DoubleProcedure() {
            public final boolean apply(double a) { return from>a || a>to; }
            public final double[] getConstants() {return new double[]{from,to};}
            public String toString() {return "isNotBetween";}
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }

    /**
     * Constructs a function that returns <tt>from<=a && a<=to</tt>.
     * <tt>a</tt> is a variable, <tt>from</tt> and <tt>to</tt> are fixed.
     *
     * @param from lower limit
     * @param to upper limit
     */

    public static DoubleProcedure isBetween(final double from, final double to) {
        return new DoubleProcedure() {
            public final boolean apply(double a) { return from<=a && a<=to; }
            public final double[] getConstants() {return new double[]{from,to};}
            public String toString() {return "isBetween";}
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }

    /**
     * Constructs a function that returns <tt>from<=a && a<to</tt>.
     * <tt>a</tt> is a variable, <tt>from</tt> and <tt>to</tt> are fixed.
     *
     * @param from lower limit
     * @param to upper limit
     */

    public static DoubleProcedure isBetweenUpperNotInc(final double from, final double to) {
        return new DoubleProcedure() {
            public final boolean apply(double a) { return from<=a && a<to; }
            public final double[] getConstants() {return new double[]{from,to};}
            public String toString() {return "isBetweenUpperNotInc";}
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) &&
                        equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }

    /**
     * Constructs a function that returns <tt>from<a && a<=to</tt>.
     * <tt>a</tt> is a variable, <tt>from</tt> and <tt>to</tt> are fixed.
     *
     * @param from lower limit
     * @param to upper limit
     */

    public static DoubleProcedure isBetweenLowerNotInc(final double from, final double to) {
        return new DoubleProcedure() {
            public final boolean apply(double a) { return from<a && a<=to; }
            public final double[] getConstants() {return new double[]{from,to};}
            public String toString() {return "isBetweenLowerNotInc";}
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) &&
                        equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }

    /**
     * Constructs a function that returns <tt>from<b && b<to</tt>.
     * <tt>b</tt> is a variable, <tt>from</tt> and <tt>to</tt> are fixed.
     *
     * @param from lower limit
     * @param to upper limit
     */

    public static DoubleProcedure isBetweenNotInc(final double from, final double to) {
        return new DoubleProcedure() {
            public final boolean apply(double b) { return from<b && b<to; }
            public final double[] getConstants() {return new double[]{from,to};}
            public String toString() {return "isBetweenNotInc";}
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) &&
                        equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that returns <tt>a == b</tt>.
     * <tt>a</tt> is a variable, <tt>b</tt> is fixed.
     *
     * @param b the input
     */
    
    public static DoubleProcedure isEqual(final double b) {
        return new DoubleProcedure() {
            public final boolean apply(double a) { return a==b; }
            public final double[] getConstants() {return new double[]{b};}
            public String toString() {return "isEqual";}
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }

    /**
     * Constructs a function that returns true if the input is finite.
     */

    public static DoubleProcedure isFinite() {
        return new DoubleProcedure() {
            public final boolean apply(double a) { return !(Double.isInfinite(a)||Double.isNaN(a)); }
            public final double[] getConstants() {return new double[]{};}
            public String toString() {return "isFinite";}
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }

    /**
     * Constructs a function that returns true if the input is not finite, i.e.
     * if either of the following return true: {@link java.lang.Double#isInfinite(double)}
     * or {@link java.lang.Double#isNaN(double)}
     */

    public static DoubleProcedure isNotFinite() {
        return new DoubleProcedure() {
            public final boolean apply(double a) { return Double.isInfinite(a)||Double.isNaN(a); }
            public final double[] getConstants() {return new double[]{};}
            public String toString() {return "isNotFinite";}
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }    
    
    /**
     * Constructs a function that returns <tt>a > b</tt>.
     * <tt>a</tt> is a variable, <tt>b</tt> is fixed.
     *
     * @param b the input
     */
    
    public static DoubleProcedure isGreater(final double b) {
        return new DoubleProcedure() {
            public final boolean apply(double a) { return a > b; }
            public final double[] getConstants() {return new double[]{b};}
            public String toString() {return "isGreater";}
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that returns <tt>a < b</tt>.
     * <tt>a</tt> is a variable, <tt>b</tt> is fixed.
     *
     * @param b the input
     */
      
    public static DoubleProcedure isLess(final double b) {
        return new DoubleProcedure() {
            public final boolean apply(double a) { return a < b; }
            public final double[] getConstants() {return new double[]{b};}
            public String toString() {return "isLess";}
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that returns <tt>a <= b</tt>.
     * <tt>a</tt> is a variable, <tt>b</tt> is fixed.
     *
     * @param b the input
     */
    
    public static DoubleProcedure isLessEqual(final double b) {
        return new DoubleProcedure() {
            public final boolean apply(double a) { return a <= b; }
            public final double[] getConstants() {return new double[]{b};}
            public String toString() {return "isLessEqual";}
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that returns <tt>a >= b</tt>.
     * <tt>a</tt> is a variable, <tt>b</tt> is fixed.
     *
     * @param b the input
     */
    
    public static DoubleProcedure isGreaterEqual(final double b) {
        return new DoubleProcedure() {
            public final boolean apply(double a) { return a >= b; }
            public final double[] getConstants() {return new double[]{b};}
            public String toString() {return "isGreaterEqual";}
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }

    /**
     * Returns the reverse of the input procedure.
     *
     *
     * @param input the input procedure
     * @return the reverse of the input
     */

    public static DoubleProcedure reverse(final DoubleProcedure input) {
        return new DoubleProcedure() {
            public final boolean apply(double a) { return !input.apply(a); }
            public final double[] getConstants() {return input.getConstants();}
            public String toString() {return "reverse";}
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }

    /**
     * Constructs a function that returns <tt>a < b ? 1 : 0</tt>.
     * <tt>a</tt> is a variable, <tt>b</tt> is fixed.
     *
     * @param b the input
     */
    
    public static DoubleFunction less(final double b) {
        return new DoubleFunction() {
            public final double apply(double a) { return a < b ? 1 : 0; }
            public String toString() {return "less";}
            public double[] getConstants() {return new double[]{b};};
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }

    /**
     * Constructs a function that returns <tt>a <= b ? 1 : 0</tt>.
     * <tt>a</tt> is a variable, <tt>b</tt> is fixed.
     *
     * @param b the input
     */

    public static DoubleFunction lessEqual(final double b) {
        return new DoubleFunction() {
            public final double apply(double a) { return a <= b ? 1 : 0; }
            public String toString() {return "lessEqual";}
            public double[] getConstants() {return new double[]{b};};
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that returns <tt><tt>Math.log(a) / Math.log(b)</tt></tt>.
     * <tt>a</tt> is a variable, <tt>b</tt> is fixed.
     *
     * @param b the input
     */
    
    public static DoubleFunction lg(final double b) {
        return new DoubleFunction() {
            private final double logInv = 1 / Math.log(b); // cached for speed
            public final double apply(double a) { return Math.log(a) * logInv; }
            public String toString() {return "lg";}
            public double[] getConstants() {return new double[]{b};};
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that returns <tt>Math.max(a,b)</tt>.
     * <tt>a</tt> is a variable, <tt>b</tt> is fixed.
     *
     * @param b the input
     */
    
    public static DoubleFunction max(final double b) {
        return new DoubleFunction() {
            public final double apply(double a) { return Math.max(a,b); }
            public String toString() {return "max";}
            public double[] getConstants() {return new double[]{b};};
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that returns <tt>Math.min(a,b)</tt>.
     * <tt>a</tt> is a variable, <tt>b</tt> is fixed.
     *
     * @param b the input
     */
    
    public static DoubleFunction min(final double b) {
        return new DoubleFunction() {
            public final double apply(double a) { return Math.min(a,b); }
            public String toString() {return "min";}
            public double[] getConstants() {return new double[]{b};};
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that returns <tt>a - b</tt>.
     * <tt>a</tt> is a variable, <tt>b</tt> is fixed.
     *
     * @param b the input
     */
    
    public static DoubleFunction minus(final double b) {
        return plus(-b);
    }
    
    /**
     * Constructs a function that returns <tt>a - b*constant</tt>.
     * <tt>a</tt> and <tt>b</tt> are variables, <tt>constant</tt> is fixed.
     *
     * @param constant the constant
     */
    
    public static DoubleDoubleFunction minusMult(final double constant) {
        return plusMult(-constant);
    }
    
    /**
     * Constructs a function that returns <tt>a % b</tt>.
     * <tt>a</tt> is a variable, <tt>b</tt> is fixed.
     *
     * @param b the input
     */
    
    public static DoubleFunction mod(final double b) {
        return new DoubleFunction() {
            public final double apply(double a) { return a % b; }
            public String toString() {return "mod";}
            public double[] getConstants() {return new double[]{b};};
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that returns <tt>a * b</tt>.
     * <tt>a</tt> is a variable, <tt>b</tt> is fixed.
     *
     * @param b the input
     */
    
    public static DoubleFunction mult(final double b) {
        return new DoubleFunction() {
            public final double apply(double a) { return a * b; }
            public String toString() {return "mult";}
            public double[] getConstants() {return new double[]{b};};
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that returns <tt>a + b</tt>.
     * <tt>a</tt> is a variable, <tt>b</tt> is fixed.
     *
     * @param b the input
     */
    
    public static DoubleFunction plus(final double b) {
        return new DoubleFunction() {
            public final double apply(double a) { return a + b; }
            public String toString() {return "plus";}
            public double[] getConstants() {return new double[]{b};};
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that returns <tt>a + b*constant</tt>.
     * <tt>a</tt> and <tt>b</tt> are variables, <tt>constant</tt> is fixed.
     *
     * @param constant the constant
     */
    
    public static DoubleDoubleFunction plusMult(final double constant) {
        return new DoubleDoubleFunction() {
            public final double apply(double a, double b) { return a + b * constant; }
            public String toString() {return "plusMult";}
            public double[] getConstants() {return new double[]{constant};};
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that returns <tt>Math.pow(a,b)</tt>.
     * <tt>a</tt> is a variable, <tt>b</tt> is fixed.
     *
     * @param b the input
     */
    
    public static DoubleFunction pow(final double b) {
        return new DoubleFunction() {
            public final double apply(double a) { return Math.pow(a,b); }
            public String toString() {return "pow";}
            public double[] getConstants() {return new double[]{b};};
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that returns the number rounded to a given number of 
     * decimal places. 
     *
     * @param precision the precision
     */
      
    public static DoubleFunction round(final int precision) {
        return new DoubleFunction() {
            public final double apply(double a) { return Mathematics.round(a,precision); }
            public String toString() {return "round";}
            public double[] getConstants() {return new double[]{precision};};
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that returns <tt>function.apply(b,a)</tt>, i.e. applies the function with the first operand as second operand and the second operand as first operand.
     *
     * @param function a function taking operands in the form <tt>function.apply(a,b)</tt>.
     * @return the binary function <tt>function(b,a)</tt>.
     */
    
    public static DoubleDoubleFunction swapArgs(final DoubleDoubleFunction function) {
        return new DoubleDoubleFunction() {
            public final double apply(double a, double b) { return function.apply(b,a); }
            public String toString() {return "swapArgs";}
            double[] c = function.getConstants();
            public double[] getConstants() {return new double[]{c[1],c[0]};};
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString()) && equalConstants((DoubleOperation)obj,this);
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
        };
    }
    
    /**
     * Constructs a function that returns the maximum value of the input vector,
     * ignoring the specified number.
     *
     * @return the maximum function
     */
    
    public static VectorFunction maximum() {
        return new VectorFunction() {
            
            public final double apply(Matrix1D argument) { 
                int length = argument.getElementCount();
                if(argument instanceof DoubleMatrix1D) {
                    DoubleMatrix1D d = (DoubleMatrix1D)argument;
                    double max = d.get(0);
                    for(int i = 1; i < length; i++) {
                        double next = d.get(i);
                        if(next > max) max = next;
                    }
                    return max;
                } 
                else if (argument instanceof IntegerMatrix1D) {
                    IntegerMatrix1D d = (IntegerMatrix1D)argument;
                    int max = d.get(0);
                    for(int i = 1; i < length; i++) {
                        int next = d.get(i);
                        if(next > max) max = next;
                    }
                    return (double)max;
                } 
                else {
                    throw new IllegalArgumentException("Cannot compute the maximum of non-numeric input.");
                }
            }
            
            public final double apply(Matrix1D argument, Number ignore) { 
                int length = argument.getElementCount();
                if(argument instanceof DoubleMatrix1D) {
                    double ig = ignore.doubleValue();
                    DoubleMatrix1D d = (DoubleMatrix1D)argument;
                    double max = d.get(0);
                    for(int i = 1; i < length; i++) {
                        double next = d.get(i);
                        if(next != ig && next > max) max = next;
                    }
                    return max;
                } 
                else if (argument instanceof IntegerMatrix1D) {
                    int ig = ignore.intValue();
                    IntegerMatrix1D d = (IntegerMatrix1D)argument;
                    int max = d.get(0);
                    for(int i = 1; i < length; i++) {
                        int next = d.get(i);
                        if(next != ig && next > max) max = next;
                    }
                    return (double)max;
                } 
                else {
                    throw new IllegalArgumentException("Cannot compute the maximum of non-numeric input.");
                }
            }
                        
            //Override toString()
            public String toString() {
                return "Maximum";
            }
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
            public double[] getConstants() {
                return null;
            }
        };
    }    
    
    /**
     * Constructs a function that returns the minimum value of the input vector,
     * ignoring the specified number.
     *
     * @return the minimum function
     */
    
    public static VectorFunction minimum() {
        return new VectorFunction() {
            
            public final double apply(Matrix1D argument) { 
                int length = argument.getElementCount();
                if(argument instanceof DoubleMatrix1D) {
                    DoubleMatrix1D d = (DoubleMatrix1D)argument;
                    double min = d.get(0);
                    for(int i = 1; i < length; i++) {
                        double next = d.get(i);
                        if(next < min) min = next;
                    }
                    return min;
                } 
                else if (argument instanceof IntegerMatrix1D) {
                    IntegerMatrix1D d = (IntegerMatrix1D)argument;
                    int min = d.get(0);
                    for(int i = 1; i < length; i++) {
                        int next = d.get(i);
                        if(next < min) min = next;
                    }
                    return (double)min;
                } 
                else {
                    throw new IllegalArgumentException("Cannot compute the minimum of non-numeric input.");
                }    
            }
            
            public final double apply(Matrix1D argument, Number ignore) { 
                int length = argument.getElementCount();
                if(argument instanceof DoubleMatrix1D) {
                    double ig = ignore.doubleValue();
                    DoubleMatrix1D d = (DoubleMatrix1D)argument;
                    double min = d.get(0);
                    for(int i = 1; i < length; i++) {
                        double next = d.get(i);
                        if(next != ig && next < min) min = next;
                    }
                    return min;
                } 
                else if (argument instanceof IntegerMatrix1D) {
                    int ig = ignore.intValue();
                    IntegerMatrix1D d = (IntegerMatrix1D)argument;
                    int min = d.get(0);
                    for(int i = 1; i < length; i++) {
                        int next = d.get(i);
                        if(next != ig && next < min) min = next;
                    }
                    return (double)min;
                } 
                else {
                    throw new IllegalArgumentException("Cannot compute the minimum of non-numeric input.");
                }    
            }
            
            //Override toString()
            public String toString() {
                return "Minimum";
            }
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
            public double[] getConstants() {
                return null;
            }
        };
    }  
    
    /**
     * Constructs a function that returns the mean value of the input vector,
     * ignoring the specified number.
     *
     * @return the mean function
     */
    
    public static VectorFunction mean() {
        return new VectorFunction() {

            public final double apply(Matrix1D argument) {
                int length = argument.getElementCount();
                double sum = 0.0;
                if(argument instanceof DoubleMatrix1D) {
                    DoubleMatrix1D d = (DoubleMatrix1D)argument;
                    for(int i = 0; i < length; i++) {
                        double next = d.get(i);
                        sum+=next;
                    }
                    return sum/length;
                } 
                else if(argument instanceof IntegerMatrix1D) {
                    IntegerMatrix1D d = (IntegerMatrix1D)argument;
                    for(int i = 0; i < length; i++) {
                        int next = d.get(i);
                        sum+=next;
                    }
                    return sum/length;
                } 
                else {
                    throw new IllegalArgumentException("Cannot compute the mean of non-numeric input.");
                }
            }

            public final double apply(Matrix1D argument, Number ignore) {
                int length = argument.getElementCount();
                double sum = 0;
                int count = 0;
                if(argument instanceof DoubleMatrix1D) {
                    double ig = ignore.doubleValue();
                    DoubleMatrix1D d = (DoubleMatrix1D)argument;
                    for(int i = 0; i < length; i++) {
                        double next = d.get(i);
                        if(next != ig) {
                            sum+=next;
                            count++;
                        }
                    }
                    if(count==0) {
                        return ig;
                    }
                    return sum/count;
                }
                else if(argument instanceof IntegerMatrix1D) {
                    int ig = ignore.intValue();
                    IntegerMatrix1D d = (IntegerMatrix1D)argument;
                    for(int i = 0; i < length; i++) {
                        int next = d.get(i);
                        if(next!=ig) {
                            sum+=next;
                            count++;
                        }
                    }
                    if(count==0) {
                        return ig;
                    }
                    return sum/count;
                }
                else {
                    throw new IllegalArgumentException("Cannot compute the mean of non-numeric input.");
                }
            }
            
            //Override toString()
            public String toString() {
                return "Mean";
            }        
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
            public double[] getConstants() {
                return null;
            }
        };
    }

    /**
     * Constructs a function that returns the unbiased sample standard deviation 
     * of the input vector, ignoring the specified number.
     *
     * @return the unbiased sample standard deviation function
     */
    
    public static VectorFunction stdev() {
        return new VectorFunction() {
            public final double apply(Matrix1D argument) {
                int length = argument.getElementCount();
                double mean = mean().apply(argument);
                double sum = 0.0;
                if(argument instanceof DoubleMatrix1D) {
                    DoubleMatrix1D d = (DoubleMatrix1D)argument;
                    for(int i = 0; i < length; i++) {
                        double next = d.get(i);
                        double nx = Math.abs(next - mean);
                        sum+=nx*nx;
                    }
                    return Math.sqrt(sum/((double)length-1.0)); //bias corrected
                } 
                else if(argument instanceof IntegerMatrix1D) {
                    IntegerMatrix1D d = (IntegerMatrix1D)argument;
                    for(int i = 0; i < length; i++) {
                        double next = d.get(i);
                        double nx = Math.abs(next - mean);
                        sum+= nx*nx;
                    }
                    return Math.sqrt(sum/((double)length-1.0)); //bias corrected
                } 
                else {
                    throw new IllegalArgumentException("The standard deviation is not defined for non-numeric input.");
                }
            }
                        
            public final double apply(Matrix1D argument, Number ignore) {
                
                int length = argument.getElementCount();
                double mean = mean().apply(argument,ignore);
                double sum = 0;
                int count = 0;
                if(argument instanceof DoubleMatrix1D) {
                    double ig = ignore.doubleValue();
                    DoubleMatrix1D d = (DoubleMatrix1D)argument;
                    for(int i = 0; i < length; i++) {
                        double next = d.get(i);
                        double nx = Math.abs(next - mean);
                        if(next!=ig) {
                            sum+= nx*nx;
                            count++;
                        }
                    }
                    if(count > 0) {
                        return Math.sqrt(sum/((double)count-1.0)); //bias corrected
                    }
                    return ig;
                } 
                else if(argument instanceof IntegerMatrix1D) {
                    int ig = ignore.intValue();
                    IntegerMatrix1D d = (IntegerMatrix1D)argument;
                    for(int i = 0; i < length; i++) {
                        int next = d.get(i);
                        double nx = Math.abs(next - mean);
                        if(next!=ig) {
                            sum+= nx*nx;
                            count++;
                        }
                    }
                    if(count > 0) {
                        return Math.sqrt(sum/((double)count-1.0)); //bias corrected
                    }
                    return ig;
                } 
                else {
                    throw new IllegalArgumentException("Cannot compute the standard deviation of non-numeric input.");
                }
            }
            
            //Override toString()
            public String toString() {
                return "Stdev";
            }                        
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
            public double[] getConstants() {
                return null;
            }
        };
    }
    
    /**
     * Constructs a function that returns the range of the input vector, ignoring 
     * the specified number.
     *
     * @return the range function
     */
    
    public static VectorFunction range() {
        return new VectorFunction() {
            public final double apply(Matrix1D argument) {
                try {
                    return maximum().apply(argument) - minimum().apply(argument); 
                }
                catch(IllegalArgumentException e) {
                    throw new IllegalArgumentException("Cannot compute the range of non-numeric input.");
                }
            }
            
            public final double apply(Matrix1D argument, Number ignore) {
                try {
                    double max = maximum().apply(argument,ignore);
                    double min = minimum().apply(argument,ignore);
                    double nV = ignore.doubleValue();
                    if(max==nV || min == nV) {
                        return nV;
                    }
                    return max-min; 
                }
                catch(IllegalArgumentException e) {
                    throw new IllegalArgumentException("Cannot compute the range of non-numeric input.");
                }
            }
            
            //Override toString()
            public String toString() {
                return "Range";
            }            
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
            public double[] getConstants() {
                return null;
            }
        };
    }  
    
    /**
     * Constructs a function that returns the median of the input vector, ignoring 
     * the specified number.
     *
     * @return the median function
     */
    
    public static VectorFunction median() {
        return new VectorFunction() {
            public final double apply(Matrix1D argument) {
                int length = argument.getElementCount();
                if(argument instanceof DoubleMatrix1D) {
                    double[] values = ((DoubleMatrix1D)argument).toArray();
                    java.util.Arrays.sort(values);
                    double diff = Math.abs((((double)length)/2) - (double)(length/2));
                    if(diff>.00000001) {
                        return (double)values[length/2];
                    }
                    return (values[length/2] + values[(length/2)-1])/2;
                } 
                else if(argument instanceof IntegerMatrix1D) {
                    int[] values = ((IntegerMatrix1D)argument).toArray();
                    java.util.Arrays.sort(values);
                    double diff = Math.abs((((double)length)/2) - (double)(length/2));
                    if(diff>.00000001) {
                        return (double)values[length/2];
                    }
                    return ((double)(values[length/2] + values[(length/2)-1]))/2;
                } 
                else {
                    throw new IllegalArgumentException("Cannot compute the median of non-numeric input.");
                }                
            }

            public final double apply(Matrix1D argument, Number ignore) {
                int length = argument.getElementCount();
                if(argument instanceof DoubleMatrix1D) {
                    double nv = ignore.doubleValue();
                    double[] temp = ((DoubleMatrix1D)argument).toArray();
                    int[] ind = new int[length];
                    int count = 0;
                    for(int i = 0; i < length; i++) {
                        if(temp[i] != nv) {
                            ind[i]=i;
                            count++;
                        }
                    }
                    if(count==0) {
                        return nv;
                    }
                    double[] values = new double[count];
                    for(int j = 0; j < count; j++) {
                        values[j] = temp[ind[j]];
                    }
                    java.util.Arrays.sort(values);
                    double x = ((double)length)/2;
                    double y = (double)(length/2);

                    if (Math.abs(x - y) > .0000001) {
                        return (double)values[length/2];
                    }
                    return (values[length/2] + values[(length/2)-1])/2;
                } 
                else if(argument instanceof IntegerMatrix1D) {
                    int nv = ignore.intValue();
                    int[] temp = ((IntegerMatrix1D)argument).toArray();
                    int[] ind = new int[length];
                    int count = 0;
                    for(int i = 0; i < length; i++) {
                        if(temp[i] != nv) {
                            ind[i]=i;
                            count++;
                        }
                    }
                    if(count==0) {
                        return nv;
                    }
                    int[] values = new int[count];
                    for(int j = 0; j < count; j++) {
                        values[j] = temp[ind[j]];
                    }
                    java.util.Arrays.sort(values);
                    if(((double)length)/2 != (double)(length/2) ) {
                        return (double)values[length/2];
                    }
                    return ((double)(values[length/2] + values[(length/2)-1]))/2;
                } 
                else {
                    throw new IllegalArgumentException("Cannot compute the median of non-numeric input.");
                }                
            }
            
            //Override toString()
            public String toString() {
                return "Median";
            }            
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
            public double[] getConstants() {
                return null;
            }
        };
    }
  
    /**
     * Constructs a function that returns the sum of the input vector, ignoring 
     * the specified number.
     *
     * @return the sum function
     */
    
    public static VectorFunction total() {
        return new VectorFunction() {
            public final double apply(Matrix1D argument) {
                int length = argument.getElementCount();
                if(argument instanceof DoubleMatrix1D) {
                    double[] values = ((DoubleMatrix1D)argument).toArray();
                    double sum = 0;
                    for(int i = 0; i < length; i++) {
                        sum+=values[i];
                    }
                    return sum;
                } 
                else if(argument instanceof IntegerMatrix1D) {
                    int[] values = ((IntegerMatrix1D)argument).toArray();
                    double sum = 0;
                    for(int i = 0; i < length; i++) {
                        sum+=values[i];
                    }
                    return sum;
                } 
                else {
                    throw new IllegalArgumentException("Cannot sum non-numeric input.");
                }                
            }

            public final double apply(Matrix1D argument, Number ignore) {
                int length = argument.getElementCount();
                if(argument instanceof DoubleMatrix1D) {
                    double nv = ignore.doubleValue();
                    double[] temp = ((DoubleMatrix1D)argument).toArray();
                    double sum = 0;
                    int count = 0;
                    for(int i = 0; i < length; i++) {
                        if(temp[i] != nv) {
                            sum+=temp[i];
                            count++;
                        }
                    }
                    if(count==0) {
                        return nv;
                    }
                    return sum;
                } 
                else if(argument instanceof IntegerMatrix1D) {
                    int nv = ignore.intValue();
                    int[] temp = ((IntegerMatrix1D)argument).toArray();
                    double sum = 0;
                    int count = 0;
                    for(int i = 0; i < length; i++) {
                        if(temp[i] != nv) {
                            sum+=temp[i];
                            count++;
                        }
                    }
                    if(count==0) {
                        return nv;
                    }
                    return sum;
                } 
                else {
                    throw new IllegalArgumentException("Cannot sum non-numeric input.");
                }                
            }
            
            //Override toString()
            public String toString() {
                return "Total";
            }            
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
            public double[] getConstants() {
                return null;
            }
        };
    }    
    
    /**
     * Constructs a function that returns the first number in the input vector, ignoring 
     * a specified number if required.
     *
     * @return a function that returns the first number in the input vector
     */
    
    public static VectorFunction first() {
        return new VectorFunction() {
            public final double apply(Matrix1D argument) {
                if(argument instanceof DoubleMatrix1D) {
                    return ((DoubleMatrix1D)argument).get(0);
                } 
                else if(argument instanceof IntegerMatrix1D) {
                    return ((IntegerMatrix1D)argument).get(0);
                } 
                else {
                    throw new IllegalArgumentException("Cannot apply function to non-numeric input.");
                }                 
            }

            public final double apply(Matrix1D argument, Number ignore) {
                int length = argument.getElementCount();
                if(argument instanceof DoubleMatrix1D) {
                    double nv = ignore.doubleValue();
                    double[] temp = ((DoubleMatrix1D)argument).toArray();
                    for(int i = 0; i < length; i++) {
                        if(temp[i] != nv) {
                            return temp[i];
                        }
                    }
                    return nv;
                } 
                else if(argument instanceof IntegerMatrix1D) {
                    int nv = ignore.intValue();
                    int[] temp = ((IntegerMatrix1D)argument).toArray();
                    for(int i = 0; i < length; i++) {
                        if(temp[i] != nv) {
                            return temp[i];
                        }
                    }
                    return nv;
                } 
                else {
                    throw new IllegalArgumentException("Cannot apply function to non-numeric input.");
                }                 
            }
            
            //Override toString()
            public String toString() {
                return "First";
            }            
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
            public double[] getConstants() {
                return null;
            }
        };
    }      
    
    /**
     * Constructs a function that returns the last number in the input vector, ignoring 
     * a specified number if required.
     *
     * @return a function that returns the last number in the input vector
     */
    
    public static VectorFunction last() {
        return new VectorFunction() {
            public final double apply(Matrix1D argument) {
                if(argument instanceof DoubleMatrix1D) {
                    return ((DoubleMatrix1D)argument).
                            get(((DoubleMatrix1D)argument).getRowCount()-1);
                } 
                else if(argument instanceof IntegerMatrix1D) {
                    return ((IntegerMatrix1D)argument).
                            get(((IntegerMatrix1D)argument).getRowCount()-1);
                } 
                else {
                    throw new IllegalArgumentException("Cannot apply function to non-numeric input.");
                }               
            }

            public final double apply(Matrix1D argument, Number ignore) {
                int length = argument.getElementCount();
                if(argument instanceof DoubleMatrix1D) {
                    double nv = ignore.doubleValue();
                    double[] temp = ((DoubleMatrix1D)argument).toArray();
                    int total = length-1;
                    for(int i = total; i > -1; i--) {
                        if(temp[i] != nv) {
                            return temp[i];
                        }
                    }
                    return nv;
                } 
                else if(argument instanceof IntegerMatrix1D) {
                    int nv = ignore.intValue();
                    int[] temp = ((IntegerMatrix1D)argument).toArray();
                    int total = length-1;
                    for(int i = total; i > -1; i--) {
                        if(temp[i] != nv) {
                            return temp[i];
                        }
                    }
                    return nv;
                } 
                else {
                    throw new IllegalArgumentException("Cannot apply function to non-numeric input.");
                }                
            }
            
            //Override toString()
            public String toString() {
                return "Last";
            }            
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
            public double[] getConstants() {
                return null;
            }
        };
    }     
    
    /**
     * Constructs a function that returns the mode of the input vector, ignoring 
     * the specified number.
     *
     * @return the mode function
     */
    
    public static VectorFunction mode() {
        return new VectorFunction() {
            public final double apply(Matrix1D argument) {
                int length = argument.getElementCount();
                if(argument instanceof DoubleMatrix1D) {
                    double[] temp = ((DoubleMatrix1D)argument).toArray();
                    Arrays.sort(temp);
                    int count = 0; //Count for current value
                    double last = 0; //Last value
                    int maxCount = 0; //Maximum count
                    double max = 0; //Mode so far, return null value if all null
                    for(int i = 0; i < length; i++) {
                        if(last == temp[i]) {
                            count++;
                            if(count > maxCount) { //Returns first occurrence of max by default
                                maxCount = count;
                                max = temp[i];
                            }
                        } else {
                            count = 0;
                            last = temp[i];
                        }
                    }
                    return max;
                } 
                else if(argument instanceof IntegerMatrix1D) {
                    int[] temp = ((IntegerMatrix1D)argument).toArray();
                    Arrays.sort(temp);
                    int count = 0; //Count for current value
                    int last = 0; //Last value
                    int maxCount = 0; //Maximum count
                    int max = 0; //Mode so far, return null value if all null
                    for(int i = 0; i < length; i++) {
                        if(last == temp[i]) {
                            count++;
                            if(count > maxCount) { //Returns first occurrence of max by default
                                maxCount = count;
                                max = temp[i];
                            }
                        } else {
                            count = 0;
                            last = temp[i];
                        }
                        
                    }
                    return max;
                } 
                else {
                    throw new IllegalArgumentException("Cannot sum non-numeric input.");
                }                
            }
            
            public final double apply(Matrix1D argument, Number ignore) {
                int length = argument.getElementCount();
                if(argument instanceof DoubleMatrix1D) {
                    double nv = ignore.doubleValue();
                    double[] temp = ((DoubleMatrix1D)argument).toArray();
                    Arrays.sort(temp);
                    int count = 0; //Count for current value
                    int nonNull = 0;
                    double last = 0; //Last value
                    int maxCount = 0; //Maximum count
                    double max = nv; //Mode so far, return null value if all null
                    for(int i = 0; i < length; i++) {
                        if(temp[i] != nv) {
                            if(last == temp[i]) {
                                count++;
                                if(count > maxCount) { //Returns first occurrence of max by default
                                    maxCount = count;
                                    max = temp[i];
                                }
                            }
                            else {
                                count = 0;
                                last = temp[i];
                            }
                            nonNull++;
                        }
                    }
                    if(nonNull==0) {
                        return nv;
                    }
                    return max;
                } 
                else if(argument instanceof IntegerMatrix1D) {
                    int nv = ignore.intValue();
                    int[] temp = ((IntegerMatrix1D)argument).toArray();
                    Arrays.sort(temp);
                    int count = 0; //Count for current value
                    int last = 0; //Last value
                    int maxCount = 0; //Maximum count
                    int max = nv; //Mode so far, return null value if all null
                    int nonNull = 0;
                    for(int i = 0; i < length; i++) {
                        if(temp[i] != nv) {
                            if(last == temp[i]) {
                                count++;
                                if(count > maxCount) { //Returns first occurrence of max by default
                                    maxCount = count;
                                    max = temp[i];
                                }
                            }
                            else {
                                count = 0;
                                last = temp[i];
                            }
                            nonNull++;
                        }
                    }
                    if(nonNull==0) {
                        return nv;
                    }
                    return max;
                } 
                else {
                    throw new IllegalArgumentException("Cannot sum non-numeric input.");
                }                
            }
            
            //Override toString()
            public String toString() {
                return "Mode";
            }
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
            public double[] getConstants() {
                return null;
            }
            
        };
    }      

    /**
     * Constructs a function that returns a positive number if all values in the
     * input are equal and a negative number otherwise, ignoring the specified number.
     *
     * @return the function that determines if all values are equal
     */
    
    public static VectorFunction uniform() {
        return new VectorFunction() {
            public final double apply(Matrix1D argument) {
                VectorFunction r = range();
                if(r.apply(argument)==0) {
                    return 1;
                }
                return -1;
            }
            
            public final double apply(Matrix1D argument, Number ignore) {
                VectorFunction r = range();
                if(r.apply(argument,ignore)==0) {
                    return 1;
                }
                return -1;                
            }
            
            //Override toString()
            public String toString() {
                return "Uniform";
            }
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
            public double[] getConstants() {
                return null;
            }
            
        };
    }

    /**
     * Constructs a function that returns the unique number of cases in the input.
     *
     * @return the function that determines the unique number of cases
     */
    
    public static VectorFunction unique() {
        return new VectorFunction() {
            public final double apply(Matrix1D argument) {
                TreeMap map = new TreeMap();
                if(argument instanceof DoubleMatrix1D) {
                    DoubleMatrix1D a = (DoubleMatrix1D)argument;
                    int rows = a.getElementCount();
                    for(int i = 0; i < rows; i++) {
                        map.put(a.get(i),null);
                    }
                    return map.size();
                }
                else if(argument instanceof IntegerMatrix1D) {
                    IntegerMatrix1D a = (IntegerMatrix1D)argument;
                    int rows = a.getElementCount();
                    for(int i = 0; i < rows; i++) {
                        map.put(a.get(i),null);
                    }
                    return map.size();
                }
                else {
                    throw new IllegalArgumentException("Cannot apply function to non-numeric input.");
                }
            }

            public final double apply(Matrix1D argument, Number ignore) {
                TreeMap map = new TreeMap();
                double nV = ignore.doubleValue();
                if(argument instanceof DoubleMatrix1D) {
                    DoubleMatrix1D a = (DoubleMatrix1D)argument;
                    int rows = a.getElementCount();
                    for(int i = 0; i < rows; i++) {
                        double next = a.get(i);
                        if(next!=nV) {
                            map.put(next,null);
                        }
                    }
                    return map.size();
                }
                else if(argument instanceof IntegerMatrix1D) {
                    IntegerMatrix1D a = (IntegerMatrix1D)argument;
                    int rows = a.getElementCount();
                    for(int i = 0; i < rows; i++) {
                        int next = a.get(i);
                        if(next!=((int)nV)) {
                            map.put(next,null);
                        }
                    }
                    return map.size();
                }
                else {
                    throw new IllegalArgumentException("Cannot apply function to non-numeric input.");
                }
            }

            //Override toString()
            public String toString() {
                return "Unique";
            }
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString());
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
            public double[] getConstants() {
                return null;
            }

        };
    }

    /**
     * Constructs a function that counts the number of null values in the input.
     * The default null is -999 if not specified.
     *
     * @return the function that determines the number of null values
     */

    public static VectorFunction countNulls() {
        return new VectorFunction() {
            public final double apply(Matrix1D argument) {
                int rows = argument.getElementCount();
                int count = 0;
                if(argument instanceof DoubleMatrix1D) {
                    DoubleMatrix1D a = (DoubleMatrix1D)argument;
                    for(int i = 0; i < rows; i++) {
                        if(a.get(i)==-999.0) {
                            count++;
                        }
                    }
                    return count;
                }
                else if(argument instanceof IntegerMatrix1D) {
                    IntegerMatrix1D a = (IntegerMatrix1D)argument;
                    for(int i = 0; i < rows; i++) {
                        if(a.get(i)==-999) {
                            count++;
                        }
                    }
                    return count;
                }
                else {
                    throw new IllegalArgumentException("Cannot apply function to non-numeric input.");
                }
            }

            public final double apply(Matrix1D argument, Number ignore) {
                int rows = argument.getElementCount();
                int count = 0;
                if(argument instanceof DoubleMatrix1D) {
                    DoubleMatrix1D a = (DoubleMatrix1D)argument;
                    for(int i = 0; i < rows; i++) {
                        if(a.get(i)==ignore.doubleValue()) {
                            count++;
                        }
                    }
                    return count;
                }
                else if(argument instanceof IntegerMatrix1D) {
                    IntegerMatrix1D a = (IntegerMatrix1D)argument;
                    for(int i = 0; i < rows; i++) {
                        if(a.get(i)==ignore.intValue()) {
                            count++;
                        }
                    }
                    return count;
                }
                else {
                    throw new IllegalArgumentException("Cannot apply function to non-numeric input.");
                }
            }

            //Override toString()
            public String toString() {
                return "Count_nulls";
            }
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass())
                        && obj.toString().equals(toString());
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
            public double[] getConstants() {
                return null;
            }

        };
    }

    /**
     * Constructs a function that returns the non-exceedence probability for the
     * specified value.  No plotting position formula is used.
     *
     * @param value the value for which the probability is required
     * @return the function that returns the (non-exceedence) probability
     */

    public static VectorFunction probabilityForValue(final double value) {
        return new VectorFunction() {
            public final double apply(Matrix1D argument) {
                if(argument instanceof DoubleMatrix1D) {
                    return EmpiricalCDFCalculator.getProb(((DoubleMatrix1D)argument).toArray(),
                            value,Double.NaN,true); //Double.NaN is a place holder
                }
                else {
                    throw new IllegalArgumentException("Can only apply function to a vector of double values.");
                }
            }

            public final double apply(Matrix1D argument, Number ignore) {
                double nV = ignore.doubleValue();
                if(argument instanceof DoubleMatrix1D) {
                    return EmpiricalCDFCalculator.getProb(((DoubleMatrix1D)argument).toArray(),
                            value,nV,true);
                }
                else {
                    throw new IllegalArgumentException("Can only apply function to a vector of double values.");
                }
            }

            //Override toString()
            public String toString() {
                return "probabilityForValue";
            }
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString())
                        && Arrays.equals(((VectorFunction)obj).getConstants(),getConstants());
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
            public double[] getConstants() {
                return new double[]{value};
            }

        };
    }

     /**
     * Constructs a function that returns the value corresponding to a given
     * non-exceedence probability.  No plotting position formula is used.
     *
     * @param probability the probability for which the value is required
     * @return the function that returns the (non-exceedence) value
     */

    public static VectorFunction valueForProbability(final double probability) {
        if(probability<0||probability>1.0) {
            throw new IllegalArgumentException("Enter a valid probability in [0,1].");
        }
        return new VectorFunction() {
            public final double apply(Matrix1D argument) {
                if(argument instanceof DoubleMatrix1D) {
                    return EmpiricalCDFCalculator.getVal(((DoubleMatrix1D)argument).toArray(),
                            probability,Double.NaN,true); //Double.NaN is a place holder
                }
                else {
                    throw new IllegalArgumentException("Can only apply function to a vector of double values.");
                }
            }

            public final double apply(Matrix1D argument, Number ignore) {
                double nV = ignore.doubleValue();
                if(argument instanceof DoubleMatrix1D) {
                    return EmpiricalCDFCalculator.getVal(((DoubleMatrix1D)argument).toArray(),
                            probability,nV,true);
                }
                else {
                    throw new IllegalArgumentException("Can only apply function to a vector of double values.");
                }
            }

            //Override toString()
            public String toString() {
                return "valueForProbability";
            }
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString())
                        && Arrays.equals(((VectorFunction)obj).getConstants(),getConstants());
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
            public double[] getConstants() {
                return new double[]{probability};
            }

        };
    }
    
    /**
     * Constructs a function that returns true if the input {@link evs.utilities.mathutil.DoubleProcedure}
     * returns true for all inputs.
     *
     * @param p the double procedure
     * @return the function that returns true if the specified procedure returns true for all values in the matrix
     */
    
    public static VectorDoubleProcedure isAll(final DoubleProcedure p) {
        return new VectorDoubleProcedure() {
            public final boolean apply(DoubleMatrix1D argument) {
                double[] data = argument.toArray();
                for (int i = 0; i < data.length; i++) {
                    if (!p.apply(data[i])) {
                        return false;
                    }
                }
                return true;
            }           
            public final boolean apply(DoubleMatrix1D argument, double ignore) {
                double[] data = argument.toArray();
                int ignoreCount = 0;
                for (int i = 0; i < data.length; i++) {
                    if (data[i] != ignore) {
                        if(!p.apply(data[i])) {
                            return false;
                        }
                    } else {
                        ignoreCount++;
                    }
                }
                if(ignoreCount==data.length) {
                    return false;
                }
                return true;                              
            }
            
            //Override toString()
            public String toString() {
                return "isAll";
            }
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString())
                        &&((VectorDoubleProcedure)obj).getProcedure().equals(getProcedure());
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
            public DoubleProcedure getProcedure() {
                return p;
            }
            
        };
    }
    
    /**
     * Constructs a function that returns true if the input {@link evs.utilities.mathutil.DoubleProcedure}
     * returns true for at least one of the values in the matrix.
     *
     * @param p the double procedure
     * @return the function that returns true if the specified procedure returns true for at least one value in the matrix
     */
    
    public static VectorDoubleProcedure isOneOrMore(final DoubleProcedure p) {
        return new VectorDoubleProcedure() {
            public final boolean apply(DoubleMatrix1D argument) {
                double[] data = argument.toArray();
                for (int i = 0; i < data.length; i++) {
                    if (p.apply(data[i])) {
                        return true;
                    }
                }
                return false;
            }           
            public final boolean apply(DoubleMatrix1D argument, double ignore) {
                double[] data = argument.toArray();
                for (int i = 0; i < data.length; i++) {
                    if (data[i] != ignore) {
                        if(p.apply(data[i])) {
                            return true;
                        }
                    }
                }
                return false;                              
            }
            
            //Override toString()
            public String toString() {
                return "isOneOrMore";
            }
            public boolean equals(Object obj) {
                return obj != null && obj.getClass().equals(getClass()) && obj.toString().equals(toString())
                        &&((VectorDoubleProcedure)obj).getProcedure().equals(getProcedure());
            }
            public int hashCode() {
                assert false : "hashCode not implemented for Function.";
                return 1;
            }
            public DoubleProcedure getProcedure() {
                return p;
            }
            
        };
    }    
    
    /**
     * Returns the inverse (arc) hyperbolic cosine of a double.
     *	
     * @param	x A double value.
     * @return  The arc hyperbolic cosine of x.
     * If x is NaN or less than one, the result is NaN.
     */
    
    public static double acosh(double x) {
        double ans;
        
        if (Double.isNaN(x) || x < 1) {
            ans = Double.NaN;
        } else if (x < 94906265.62) {
            // 94906265.62 = 1.0/Math.sqrt(EPSILON_SMALL)
            ans = Math.log(x+Math.sqrt(x*x-1.0));
        } else {
            ans = 0.69314718055994530941723212145818 + Math.log(x);
        }
        return ans;
    }
    
    /**
     * Returns the inverse (arc) hyperbolic sine of a double.
     * 
     * @param	x A double value.
     * @return  The arc hyperbolic sine of x.
     * If x is NaN, the result is NaN.
     */
    
    public static double asinh(double x) {
        double	ans;
        double	y = Math.abs(x);
        
        if (Double.isNaN(x)) {
            ans = Double.NaN;
        } else if (y <= 1.05367e-08) {
            // 1.05367e-08 = Math.sqrt(EPSILON_SMALL)
            ans = x;
        } else if (y <= 1.0) {
            ans = x*(1.0+csevl(2.0*x*x-1.0,ASINH_COEF));
        } else if (y < 94906265.62) {
            // 94906265.62 = 1/Math.sqrt(EPSILON_SMALL)
            ans = Math.log(y+Math.sqrt(y*y+1.0));
        } else {
            ans = 0.69314718055994530941723212145818 + Math.log(y);
        }
        if (x < 0.0) ans = -ans;
        return ans;
    }
    
    /**
     * Evaluate a Chebyschev series
     * 
     * @param x A double value
     * @param coef the coefficient array 
     */
    
    static double csevl(double x, double[] coef) {
        double	b0, b1, b2, twox;
        int		i;
        b1 = 0.0;
        b0 = 0.0;
        b2 = 0.0;
        twox = 2.0*x;
        for (i = coef.length-1;  i >= 0;  i--) {
            b2 = b1;
            b1 = b0;
            b0 = twox*b1 - b2 + coef[i];
        }
        return 0.5*(b0-b2);
    }
    
    /**
     * Returns the inverse (arc) hyperbolic tangent of a double.
     *	
     * @param x A double value.
     * @return The arc hyperbolic tangent of x.
     * If x is NaN or |x|>1, the result is NaN.
     */
    
    public static double atanh(double x) {
        double	y = Math.abs(x);
        double	ans;
        
        if (Double.isNaN(x)) {
            ans = Double.NaN;
        } else if (y < 1.82501e-08) {
            // 1.82501e-08 = Math.sqrt(3.0*EPSILON_SMALL)
            ans = x;
        } else if (y <= 0.5) {
            ans = x*(1.0+csevl(8.0*x*x-1.0,ATANH_COEF));
        } else if (y < 1.0) {
            ans = 0.5*Math.log((1.0+x)/(1.0-x));
        } else if (y == 1.0) {
            ans = x*Double.POSITIVE_INFINITY;
        } else {
            ans = Double.NaN;
        }
        return ans;
    }
    
    /**
     * Returns the hyperbolic cosine of a double.
     * 
     * @param x A double value.
     * @return The hyperbolic cosine of x.
     * If x is NaN, the result is NaN.
     */
    
    public static double cosh(double x) {
        double	ans;
        double	y = Math.exp(Math.abs(x));
        
        if (Double.isNaN(x)) {
            ans = Double.NaN;
        } else if (Double.isInfinite(x)) {
            ans = x;
        } else if (y < 94906265.62) {
            // 94906265.62 = 1.0/Math.sqrt(EPSILON_SMALL)
            ans = 0.5*(y+1.0/y);
        } else {
            ans = 0.5*y;
        }
        return ans;
    }
    
    /**
     * Returns the cotangent of a double.
     *	
     * @param	x A double value.
     * @return  The cotangent of x.
     * If x is NaN, the result is NaN.
     */
    
    public static double cot(double x) {
        double ans, ainty, ainty2, prodbg, y, yrem;
        double pi2rec = 0.011619772367581343075535053490057; //  2/PI - 0.625
        
        y = Math.abs(x);
        
        if (y > 4.5036e+15) {
            // 4.5036e+15 = 1.0/EPSILON_LARGE
            return Double.NaN;
        }
        
        // Compute
        // Y * (2/PI) = (AINT(Y) + REM(Y)) * (.625 + PI2REC)
        //		= AINT(.625*Y) + REM(.625*Y) + Y*PI2REC  =  AINT(.625*Y) + Z
        //		= AINT(.625*Y) + AINT(Z) + REM(Z)
        
        ainty  = (int)y;
        yrem   = y - ainty;
        prodbg = 0.625*ainty;
        ainty  = (int)prodbg;
        y      = (prodbg-ainty) + 0.625*yrem + y*pi2rec;
        ainty2 = (int)y;
        ainty  = ainty + ainty2;
        y      = y - ainty2;
        
        int ifn = (int)(ainty%2.0);
        if (ifn == 1) y = 1.0 - y;
        
        if (y == 0.0) {
            ans = Double.POSITIVE_INFINITY;
        } else if (y <= 1.82501e-08) {
            // 1.82501e-08 = Math.sqrt(3.0*EPSILON_SMALL)
            ans = 1.0/y;
        } else if (y <= 0.25) {
            ans = (0.5+csevl(32.0*y*y-1.0,COT_COEF))/y;
        } else if (y <= 0.5) {
            ans = (0.5+csevl(8.0*y*y-1.0,COT_COEF))/(0.5*y);
            ans = (ans*ans-1.0)*0.5/ans;
        } else {
            ans = (0.5+csevl(2.0*y*y-1.0,COT_COEF))/(0.25*y);
            ans = (ans*ans-1.0)*0.5/ans;
            ans = (ans*ans-1.0)*0.5/ans;
        }
        if (x != 0.0) ans = sign(ans,x);
        if (ifn == 1) ans = -ans;
        return ans;
    }
    
    /*
     * Correction term used by logBeta.
     */
    
    private static double dlnrel(double x) {
        double ans;
        
        if (x <= -1.0) {
            ans = Double.NaN;
        } else if (Math.abs(x) <= 0.375) {
            ans = x*(1.0 - x*csevl(x/.375, ALNRCS_COEF));
        } else {
            ans = Math.log(1.0 + x);
        }
        return ans;
    }

    /**
     * Returns the error function of a double.
     *	
     * @param	x A double value.
     * @return  The error function of x.
     */
    
    public static double erf(double x) {
        double	ans;
        double	y = Math.abs(x);
        
        if (y <= 1.49012e-08) {
            // 1.49012e-08 = Math.sqrt(2*EPSILON_SMALL)
            ans = 2 * x / 1.77245385090551602729816748334;
        } else if (y <= 1) {
            ans = x * (1 + csevl(2 * x * x - 1, ERFC_COEF));
        } else if (y < 6.013687357) {
            // 6.013687357 = Math.sqrt(-Math.log(1.77245385090551602729816748334 * EPSILON_SMALL))
            ans = sign(1 - erfc(y), x);
        } else {
            ans = sign(1, x);
        }
        return ans;
    }
        
    /**
     * Returns the complementary error function of a double.
     * 
     * @param	x A double value.
     * @return  The complementary error function of x.
     */
    
    public static double erfc(double x) {
        double	ans;
        double	y = Math.abs(x);
        
        if (x <= -6.013687357) {
            // -6.013687357 = -Math.sqrt(-Math.log(1.77245385090551602729816748334 * EPSILON_SMALL))
            ans = 2;
        } else if (y < 1.49012e-08) {
            // 1.49012e-08 = Math.sqrt(2*EPSILON_SMALL)
            ans = 1 - 2*x/1.77245385090551602729816748334;
        } else {
            double ysq = y*y;
            if (y < 1) {
                ans = 1 - x*(1+csevl(2*ysq-1,ERFC_COEF));
            } else if (y <= 4.0) {
                ans = Math.exp(-ysq)/y*(0.5+csevl((8.0/ysq-5.0)/3.0,ERFC2_COEF));
                if (x < 0)  ans = 2.0 - ans;if (x < 0)  ans = 2.0 - ans;
                if (x < 0)  ans = 2.0 - ans;
            } else {
                ans = Math.exp(-ysq)/y*(0.5+csevl(8.0/ysq-1,ERFCC_COEF));
                if (x < 0)  ans = 2.0 - ans;
            }
        }
        return ans;
    }
    
    /**
     * Returns the Gamma function of a double.
     *	
     * @param	x A double value.
     * @return  The Gamma function of x.
     * If x is a negative integer, the result is NaN.
     */
    
    public static double gamma(double x) {
        double	ans;
        double	y = Math.abs(x);
        
        if (y <= 10.0) {
                        /*
                         * Compute gamma(x) for |x|<=10.
                         * First reduce the interval and  find gamma(1+y) for 0 <= y < 1.
                         */
            int n = (int)x;
            if (x < 0.0)  n--;
            y = x - n;
            n--;
            ans = 0.9375 + csevl(2.0*y-1.0, GAMMA_COEF);
            if (n == 0) {
            } else if (n < 0) {
                // Compute gamma(x) for x < 1
                n = -n;
                if (x == 0.0) {
                    ans = Double.NaN;
                } else if (y < 1.0/Double.MAX_VALUE) {
                    ans = Double.POSITIVE_INFINITY;
                } else {
                    double xn = n - 2;
                    if (x < 0.0 && x + xn == 0.0) {
                        ans = Double.NaN;
                    } else {
                        for (int i = 0; i < n; i++) {
                            ans /= x + i;
                        }
                    }
                }
            } else {	// gamma(x) for x >= 2.0
                for (int i = 1; i <= n; i++) {
                    ans *= y + i;
                }
            }
        } else {  // gamma(x) for |x| > 10
            if (x > 171.614) {
                ans = Double.POSITIVE_INFINITY;
            } else if (x < -170.56) {
                ans = 0.0; // underflows
            } else {
                // 0.9189385332046727 = 0.5*log(2*PI)
                ans = Math.exp((y-0.5)*Math.log(y)-y+0.9189385332046727+r9lgmc(y));
                if (x < 0.0) {
                    double sinpiy = Math.sin(Math.PI * y);
                    if (sinpiy == 0 || Math.round(y) == y) {
                        ans = Double.NaN;
                    } else {
                        ans = -Math.PI / (y * sinpiy * ans);
                    }
                }
            }
        }
        return ans;
    }
    
    /**
     * Returns the common (base 10) logarithm of a double.
     *	
     * @param	x A double value.
     * @return  The common logarithm of x.
     */
    
    public static double log10(double x) {
        //if (Double.isNaN(x)) return Double.NaN;
        return 0.43429448190325182765*Math.log(x);
    }
        
    /**
     * Returns the logarithm of the Beta function.
     *	
     * @param	a A double value.
     * @param	b A double value.
     * @return  The natural logarithm of the Beta function.
     */
    
    public static double logBeta(double a, double b) {
        double  corr, ans;
        double	p = Math.min(a, b);
        double	q = Math.max(a, b);
        
        if (p <= 0.0) {
            ans = Double.NaN;
        } else if (p >= 10.0) {
            // P and Q are large;
            corr = r9lgmc(p) + r9lgmc(q) - r9lgmc(p+q);
            double temp = dlnrel(-p/(p+q));
            ans = -0.5*Math.log(q) + 0.918938533204672741780329736406 + corr + (p-0.5)*Math.log(p/(p+q)) + q*temp;
        } else if (q >= 10.0) {
            // P is small, but Q is large
            corr = r9lgmc(q) - r9lgmc(p+q);
            //  Check from underflow from r9lgmc
            ans = logGamma(p) + corr + p - p*Math.log(p+q) + (q-0.5)*dlnrel(-p/(p+q));
        } else {
            // P and Q are small;
            ans = Math.log(gamma(p)*(gamma(q)/gamma(p+q)));
        }
        return ans;
    }
    
    /**
     * Returns the logarithm of the Gamma function of a double.
     *	
     * @param	x A double value.
     * @return  The natural logarithm of the Gamma function of x.
     * If x is a negative integer, the result is NaN.
     */
    
    public static double logGamma(double x) {
        double	ans, sinpiy, y;
        
        y = Math.abs(x);
        
        if (y <= 10) {
            ans = Math.log(Math.abs(gamma(x)));
        } else if (x > 0) {
            // A&S 6.1.40
            // 0.9189385332046727 = 0.5*log(2*PI)
            ans = 0.9189385332046727 + (x-0.5)*Math.log(x) - x + r9lgmc(y);
        } else {
            sinpiy = Math.abs(Math.sin(Math.PI * y));
            if (sinpiy == 0  || Math.round(y) == y) {
                // The argument for the function can not be a negative integer.
                ans = Double.NaN;
            } else {
                ans = 0.22579135264472743236 + (x-0.5)*Math.log(y) - x - Math.log(sinpiy) - r9lgmc(y);
            }
        }
        return ans;
    }
    
    /**
     * Returns the log gamma correction term for argument values greater than or 
     * equal to 10.0.
     * 
     * @param x A double value
     * @return log gamma correction >=10
     */
    
    static double r9lgmc(double x) {
        double	ans;
        
        if (x < 10.0) {
            ans = Double.NaN;
        } else if (x < 9.490626562e+07) {
            // 9.490626562e+07 = 1/Math.sqrt(EPSILON_SMALL)
            double y = 10.0/x;
            ans = csevl(2.0*y*y-1.0, R9LGMC_COEF) /  x;
        } else if (x < 1.39118e+11) {
            // 1.39118e+11 = exp(min(log(amach(2) / 12.0), -log(12.0 * amach(1))));
            // See A&S 6.1.41
            ans = 1.0/(12.0*x);
        } else {
            ans = 0.0; // underflows
        }
        return ans;
    }
    
    /**
     * Returns the value of x with the sign of y.
     *
     * @param x A double value
     * @param y A double value
     * @return x signed by y
     */
    
    static private double sign(double x, double y) {
        double abs_x = ((x < 0) ? -x : x);
        return (y < 0.0) ? -abs_x : abs_x;
    }
    
    /**
     * Returns the inverse (arc) hyperbolic sine of a double.
     *	
     * @param	x A double value.
     * @return  The arc hyperbolic sine of x.
     * If x is NaN or less than one, the result is NaN.
     */
    
    public static double sinh(double x) {
        double	ans;
        double	y = Math.abs(x);
        
        if (Double.isNaN(x)) {
            ans = Double.NaN;
        } else if (Double.isInfinite(y)) {
            return x;
        } else if (y < 2.58096e-08) {
            // 2.58096e-08 = Math.sqrt(6.0*EPSILON_SMALL)
            ans = x;
        } else if (y <= 1.0) {
            ans = x*(1.0+csevl(2.0*x*x-1.0,SINH_COEF));
        } else {
            y = Math.exp(y);
            if (y >= 94906265.62) {
                // 94906265.62 = 1.0/Math.sqrt(EPSILON_SMALL)
                ans = sign(0.5*y,x);
            } else {
                ans = sign(0.5*(y-1.0/y),x);
            }
        }
        return ans;
    }
    
    /**
     * Returns the hyperbolic tangent of a double.
     *	
     * @param	x A double value.
     * @return  The hyperbolic tangent of x.
     */
    
    public static double tanh(double x) {
        double	ans, y;
        y = Math.abs(x);
        
        if (Double.isNaN(x)) {
            ans = Double.NaN;
        } else if (y < 1.82501e-08) {
            // 1.82501e-08 = Math.sqrt(3.0*EPSILON_SMALL)
            ans = x;
        } else if (y <= 1.0) {
            ans = x*(1.0+csevl(2.0*x*x-1.0,TANH_COEF));
        } else if (y < 7.977294885) {
            // 7.977294885 = -0.5*Math.log(EPSILON_SMALL)
            y = Math.exp(y);
            ans = sign((y-1.0/y)/(y+1.0/y),x);
        } else {
            ans = sign(1.0,x);
        }
        return ans;
    }
    
    /**
     * Returns true if two sets of constants associated with the inputs are equal,
     * false otherwise.
     *
     * @param a the first operation
     * @param b the second operation
     * @return true if the operations contain equal constants
     */

    private static final boolean equalConstants(DoubleOperation a, DoubleOperation b) {
        return Arrays.equals(a.getConstants(),b.getConstants());
    }

}

 /* -------------------------------------------------------------------------
 *	$Id: Sfun.java,v 1.1.1.1 1999/03/05 21:43:39 brophy Exp $
 * -------------------------------------------------------------------------
 * Copyright (c) 1997 - 1998 by Visual Numerics, Inc. All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software is freely
 * granted by Visual Numerics, Inc., provided that the copyright notice
 * above and the following warranty disclaimer are preserved in human
 * readable form.
 *
 * Because this software is licenses free of charge, it is provided
 * "AS IS", with NO WARRANTY.  TO THE EXTENT PERMITTED BY LAW, VNI
 * DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO ITS PERFORMANCE, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 * VNI WILL NOT BE LIABLE FOR ANY DAMAGES WHATSOEVER ARISING OUT OF THE USE
 * OF OR INABILITY TO USE THIS SOFTWARE, INCLUDING BUT NOT LIMITED TO DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, PUNITIVE, AND EXEMPLARY DAMAGES, EVEN
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. 
 *
 * -------------------------------------------------------------------------/

/*
Copyright 1999 CERN - European Organization for Nuclear Research.
Permission to use, copy, modify, distribute and sell this software and its documentation for any purpose 
is hereby granted without fee, provided that the above copyright notice appear in all copies and 
that both that copyright notice and this permission notice appear in supporting documentation. 
CERN makes no representations about the suitability of this software for any purpose. 
It is provided "as is" without expressed or implied warranty.
*/

