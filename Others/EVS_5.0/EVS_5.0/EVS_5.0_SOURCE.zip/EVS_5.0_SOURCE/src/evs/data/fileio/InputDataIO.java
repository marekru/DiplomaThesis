package evs.data.fileio;

/**
 * Interface for reading files that contain forecasts or observations.
 * 
 * @author evs@hydrosolved.com
 */

public interface InputDataIO {

    /*******************************************************************************
     *                                                                             *
     *                                FINAL VARIABLES                              *
     *                                                                             *
     ******************************************************************************/

    /**
     * Identifier for observed data.
     */
    
    static final int OBSERVED  = 201;
    
    /**
     * Identifier for ensemble forecast data.
     */    
    
    static final int ENSEMBLE_FORECAST = 202;        

}
