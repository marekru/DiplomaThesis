package evs.data.fileio;

//Java dependencies
import java.io.*;
import javax.xml.transform.*;
import javax.xml.transform.stream.*;

/**
 * Controls the conversion of an XML file to another format defined by an stylesheet
 * using XSLT.
 * 
 * @author evs@hydrosolved.com
 * @version 1.0
 */

public class XSLTControl {
    
    /**
     * Main method.
     * 
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        String path = "C:/Users/jamesbrown/Google Drive/ECMWF/EVS_collaboration/EVS_R_prototypes/Tests/XSLT/";
        File input = new File(path+"QUAO2.Temperature.Correlation_coefficient.xml");
        File style = new File(path+"style.xsl");
        PrintStream output = null;
        try {
            output = new PrintStream(new FileOutputStream(new File(path+"Output.csv"),true));
            transform(input,style,output);
        }           
        catch(Exception e) {  
            e.printStackTrace();
        }
    }
    
    /**
     * Converts an XML input file using the specified XSLT stylesheet and writing to
     * the specified output. Throws an exception if either the input file or stylesheet
     * are null. If the output is null, the results are written to standard out.
     * 
     * @param input the input XML file
     * @param style the input XSLT stylesheet
     * @param output the output (may be null)
     */
    
    public static void transform(File input, File style, PrintStream output) 
            throws IOException, TransformerConfigurationException, TransformerException {
        if(input == null || !input.exists()) {
            throw new IOException("Specify a valid input XML file: "+input+"");
        }
        if(style == null || !style.exists()) {
            throw new IOException("Specify a valid stylesheet file: "+style+"");
        }
        Source xmlSource = new StreamSource(input);
        Source xsltSource = new StreamSource(style);
        PrintStream out = output;
        if(output==null) {
            out = System.out;
        }
        Result result = new StreamResult(out);
        //Transform
        TransformerFactory transFact = TransformerFactory.newInstance();
        Transformer trans = transFact.newTransformer(xsltSource);
        trans.transform(xmlSource, result);                
    }
    
}
