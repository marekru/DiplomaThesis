package evs.data;

//EVS dependencies
import evs.utilities.matrix.DenseDoubleMatrix2D;
import evs.data.fileio.PairedFileIO;

//Java util dependencies
import java.util.Calendar;

//Java io dependencies
import java.io.File;
import java.io.IOException;

/**
 * A class for generating synthetic paired data for testing purposes.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class SyntheticPairs {
    
    /**
     * Returns some synthetic, normally distributed, correlated pairs according to 
     * the inputs.  The process mean and spread are used to sample an underlying process
     * for the forecasts and observations (i.e. more interesting than a constant).
     * The temporal correlation of the underlying process itself cannot be specified
     * yet.  The observed value is sampled with mean equal to a sample from the 
     * process distribution and spread equal to the observed spread.  The forecast 
     * is generated around the process distribution.  The forecast mean is sampled
     * from the forecast distribution with correlation equal to the specified
     * correlation and any bias specified.  A specified number of ensemble members 
     * is then generated around the forecast mean with the specified forecast spread.     
     * In addition to the ensemble member count, the artificial start and end dates, 
     * the lead period in hours and the forecast time-step in hours.
     *
     * @param start the start date
     * @param end the end date
     * @param lead the forecast lead period in hours
     * @param tStep the resolution of the forecasts in hours
     * @param eCount the ensemble member count
     * @param pMean the process mean 
     * @param pSpread the process spread
     * @param obsSpread the observed spread
     * @param forcBias the forecast bias
     * @param forcSpread the forecast spread
     * @param rho the correlation of the forecasts and observations
     * @return synthetic pairs
     */
    
    public static PairedData getSyntheticPairs(Calendar start, Calendar end, 
            int tStep, int lead, int eCount, double pMean, 
            double pSpread, double obsSpread, double forcBias, 
            double forcSpread, double rho, double nV) {
        PairedData pairs = null;
        //Set an imaginary start date 
        int startHours = (int)(start.getTimeInMillis()/(1000.0 * 60.0 * 60.0));
        int endHours = (int)(end.getTimeInMillis()/(1000.0 * 60.0 * 60.0));
        
        //Number of forecasts to make
        int fCount = Math.abs(endHours-startHours)/tStep;
        int leadCount = lead/tStep;
        
        DenseDoubleMatrix2D data = new DenseDoubleMatrix2D(fCount * leadCount,eCount+3);
        
        //Iterate through the forecasts
        int tot = 0;  //marker
        for(int i = 0; i < fCount; i++) {
            //Next forecast time
            int nextF = startHours + (i * tStep);
            
            //Iterate through the lead periods
            for(int j = 0; j < leadCount; j++) {
                int nextL = (j+1) * tStep;
                data.set(tot,0,nextF+nextL);
                data.set(tot,1,nextL);
                
                //Obtain correlated forecasts and observations
                //First, generate a random number for the base mean to make things interesting
                double mean = nextNorm(pMean,pSpread)[0];
                double oMean = mean;   //Observed mean is equal to base mean
                double fMean = mean + forcBias;// + (0.05 * nextL); //  (0.05 * nextL) = 5% mean bias with lead
                
                //Get the random numbers: one column, eCount +1 rows, obs in first index position
                double[][] rand = getCorrelatedObsForc(oMean,obsSpread,fMean,forcSpread,rho,1,eCount);  //1 timestep
                
                //Set the observation
                data.set(tot,2,rand[0][0]);
                //Set the forecast members
                int stop = eCount + 3;
                for(int k = 3; k < stop; k++) {
                    data.set(tot,k,rand[k-2][0]);  //k-2 starts after observation
                }
                 
                /**
                //Set the synthetic data
                double obs = Math.random();
                data.set(tot,2,obs);
                //Set the forecast members
                for(int k = 0; k < eCount; k++) {
                    //Add increasing noise with lead period
                    //so equivalent to total at max
                    double varMult = ((double)(j+1))/leadCount;
                    double f = obs+(Math.random()*j*varMult);
                    //double f = obs+((Math.random()-0.5));
                    data.set(tot,k+3,f);
                }*/
                     
                tot++;
            }
        }
        return new PairedData(data,true,nV);
    }
    
    /**
     * Supports writing of datacard output files from a set of synthetically
     * generated paired data.  
     *
     * @param data the pairs
     * @param file the output file 
     * @param nV the null value
     */
    
    protected static void writeSyntheticPairs(File file,PairedData data, double nV)  throws IOException {
        PairedFileIO.write(file,data,true,5,PairedDataSource.getIOState(),nV);
    }
    
    /**
     * Returns a dataset of observed vs. forecast values for normally distributed
     * observations and forecasts with specified parameters and correlation between
     * the observed value and forecast mean.  Returns an array with as many columns 
     * as forecast time-steps.  The first row contains the observations.  The remaining
     * rows contain the forecasts.  Thus, the matrix contains n+1 rows where n is the 
     * ensemble member count. 
     *
     * @param obsMean the observed mean
     * @param obsSpread the observed spread
     * @param forcMean the forecast mean
     * @param forcSpread the forecast spread
     * @param rho the correlation coefficient 
     * @param timeCount the time-step count
     * @param memberCount the ensemble member count
     * @return correlated forecasts and observations
     */
    
    protected static double[][] getCorrelatedObsForc(double obsMean, double obsSpread, double forcMean, double forcSpread, double rho, int timeCount, int memberCount) {
        double[][] data = new double[memberCount+1][timeCount];
        double nextSD = (1.0-(rho*rho))*(forcSpread*forcSpread);  //Correlation-reduced forecast SD
        for(int i = 0; i < timeCount; i++) {
            final double nextObs = nextNorm(obsMean,obsSpread)[0];
            final double nextFMean = nextNorm(forcMean,nextSD)[0];
            data[0][i] = nextObs;
            //Sample a corresponding forecast set around the forecast mean
            for(int j = 0; j < memberCount; j++) {
                data[j+1][i] = nextFMean + nextNorm(0.0,forcSpread)[0];
            }
        }
        return data;
    }    
    
    /**
     * Returns two random numbers from the Normal distribution with specified 
     * mean and standard deviation using the polar method (since the second number 
     * comes at very little extra cost).
     *
     * @param mu the mean
     * @param sigma the spread
     * @return two random numbers
     */
    
    private static double[] nextNorm(double mu, double sigma) {
        double u1, u2, y, z;
        do {
            u1 = (2.0 * Math.random())-1.0;
            u2 = (2.0 * Math.random())-1.0;
            y = (u1*u1) + (u2*u2);
        }
        while (y >= 1.0);
        z = Math.sqrt( (-2.0 * Math.log(y) )/ y );
        double first = mu+(sigma * z * u1);
        double second = mu+(sigma * z * u2);
        return new double[]{first,second};
    }
    
    /**
     * Returns an array with forecast-observation pairs from an input array 
     * with observations and ensemble members for each forecast time (as columns).
     * The returned array has observations in the first row.
     *
     * @param input the time-ordered forecasts and observations
     * @return the forecast-observation pairs
     */
    
    private static double[][] getScatter(double[][] input) {
        int mCount = input.length-1;
        double[][] returnMe = new double[2][mCount*input[0].length];
        int total = 0;
        for(int i = 0; i < input[0].length; i++) {
            for(int j = 1; j < input.length; j++) {
                returnMe[0][total] = input[0][i];
                returnMe[1][total] = input[j][i];
                total++;
            }
        }        
        return returnMe;        
    }    
    
    /*******************************************************************************
     *                                                                             *
     *                                  TEST METHOD                                *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Test method.
     *
     * @param args the args
     */
    
    public static void main(String[] args) {  
        /*double[][] data = getCorrelatedObsForc(2.0,5.0,2.0,5.0,0.95,1000,20);
        double[][] scatter = getScatter(data);
        
        final CheckSyntheticScatter sp = new CheckSyntheticScatter(scatter,"Scatter plot of observed vs forecast values","x","y");
        
        sp.pack();
        sp.setVisible(true);
        sp.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                sp.dispose();
            }
        });
        */
        //Set the synthetic parameters 
        Calendar start = Calendar.getInstance();
        start.clear();
        start.set(2006,4,1);
        //int startHours = (int)(start.getTimeInMillis()/(1000.0 * 60.0 * 60.0));
        
        //Set an imaginary stop date 
        Calendar end = Calendar.getInstance();
        end.clear();
        end.set(2006,8,30);
        //int endHours = (int)(end.getTimeInMillis()/(1000.0 * 60.0 * 60.0));
        
        //Forecast resolution
        int tStep = 6;
        
        //Lead period
        int lead = 240;
        
        //Ensemble member count
        int eCount = 50;        
        
        //Distributional properties
        double pMean = 80.0;  //Process mean
        double pSpread = 10.0;  //Process spread
        double obsSpread = 3.0;
        double forcBias = 0.0;  //Unbiased
        double forcSpread = 1.0 * obsSpread;  //Unbiased
        double rho = 0.99;
        
        double nV  = -999.0;
        
        //Generate pairs
        PairedData pairs = getSyntheticPairs(start,end,tStep,lead,eCount,pMean,pSpread,obsSpread,forcBias,forcSpread,rho,nV);
        File out = new File("C:/Documents and Settings/James Brown/Desktop/","Vegas_Vegas_Temperature_Biased_spread_pairs.xml");
        try { 
            writeSyntheticPairs(out,pairs,nV);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        
    }
    
    
}
