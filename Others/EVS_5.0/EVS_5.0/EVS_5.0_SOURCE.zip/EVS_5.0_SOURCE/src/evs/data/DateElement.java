package evs.data;

import java.util.Calendar;

/**
 * Class for representing a date element, comprising one of:
 * 
 * {@link java.util.Calendar#YEAR}
 * {@link java.util.Calendar#MONTH}
 * {@link java.util.Calendar#WEEK_OF_YEAR}
 * {@link java.util.Calendar#DAY_OF_WEEK}
 * {@link java.util.Calendar#HOUR_OF_DAY}
 * 
 * The date element may be specified in valid time or forecast basis time (issue time).
 *
 * @author evs@hydrosolved.com
 * @version 1.0
 */

public class DateElement implements Comparable {

    /**
     * The date element. One of: 
     * 
     * {@link java.util.Calendar#YEAR}
     * {@link java.util.Calendar#MONTH}
     * {@link java.util.Calendar#WEEK_OF_YEAR}
     * {@link java.util.Calendar#DAY_OF_WEEK}
     * {@link java.util.Calendar#HOUR_OF_DAY}
     */

    private int dateElement;

    /**
     * Is true if the date element refers to valid time, false for issue time.
     */

    private boolean isValidTime;

    /**
     * Construct the element. The date element must be one of:
     * 
     * {@link java.util.Calendar#YEAR}
     * {@link java.util.Calendar#MONTH}
     * {@link java.util.Calendar#WEEK_OF_YEAR}
     * {@link java.util.Calendar#DAY_OF_WEEK}
     * {@link java.util.Calendar#HOUR_OF_DAY}
     *
     * @param dateElement the date element
     * @param isValidTime is true if the date element refers to valid time, false for issue time
     */
    public DateElement(int dateElement, boolean isValidTime) {
        switch(dateElement) {
            case java.util.Calendar.YEAR: this.dateElement = dateElement; break;
            case java.util.Calendar.MONTH: this.dateElement = dateElement; break;
            case java.util.Calendar.WEEK_OF_YEAR: this.dateElement = dateElement; break;
            case java.util.Calendar.DAY_OF_WEEK: this.dateElement = dateElement; break;   
            case java.util.Calendar.HOUR_OF_DAY: this.dateElement = dateElement; break;   
            default: throw new IllegalArgumentException("Unsupported date element from java.util.Calendar.");    
        }
        this.isValidTime = isValidTime;
    }

    /**
     * Returns the date element identifier. One of:
     * 
     * {@link java.util.Calendar#YEAR}
     * {@link java.util.Calendar#MONTH}
     * {@link java.util.Calendar#WEEK_OF_YEAR}
     * {@link java.util.Calendar#DAY_OF_WEEK}
     * {@link java.util.Calendar#HOUR_OF_DAY}
     * 
     * @return the date element identifier
     */
    
    public int getDateElement() {
        return dateElement;
    }

    /**
     * Returns true if the date element is defined in valid time, false for
     * basis time (issue time).
     * 
     * @return true if the element is in valid time, false for basis time
     */
    
    public boolean isValidTime() {
        return isValidTime;
    }    
    
    /**
     * Returns an integer with respect to the input DateExcludeElement to allow
     * sorting.
     *
     * @param input the input object to compare
     * @return an integer: less than if the input is less, 0 if equal, positive otherwise
     */

    @Override
    public int compareTo(Object input) {
        DateElement in = (DateElement) input;
        if (in.dateElement < dateElement) {
            return -1;
        } else if (in.dateElement > dateElement) {
            return 1;
        } else {
            if(in.isValidTime == isValidTime) {
                return 0;
            } else {
                if(in.isValidTime) {
                    return 1;
                }
                return -1;
            }
        }
    }

    /**
     * For hashing.
     *
     * @return  hashcode
     */
    public int hashCode() {
        return toString().hashCode();
    }

    /**
     * String representation.
     *
     * @return a string representation.
     */

    public String toString() {
        switch(dateElement) {
            case java.util.Calendar.YEAR: if(isValidTime) return "Year (valid time)"; else return "Year (basis time)";
            case java.util.Calendar.MONTH: if(isValidTime) return "Months of year (valid time)"; else return "Months of year (basis time)";
            case java.util.Calendar.WEEK_OF_YEAR: if(isValidTime) return "Weeks of year (valid time)"; else return "Weeks of year (basis time)";
            case java.util.Calendar.DAY_OF_WEEK: if(isValidTime) return "Days of week (valid time)"; else return "Days of week (basis time)"; 
            case java.util.Calendar.HOUR_OF_DAY: if(isValidTime) return "Hours of day in UTC (valid time)"; else return "Hours of day in UTC (basis time)";    
            default: return "Unknown date element";
        }
    }

    /**
     * Returns true if the input class is a DateExcludeElement and has the same 
     * date element and valid time status.
     *
     * @param o the object to test for equality
     * @return true if the objects are equal
     */

    @Override
    public boolean equals(Object o) {
        if(o==null || o.getClass()!=getClass()) {
            return false;
        }
        DateElement v  = ((DateElement)o);
        return v.dateElement==dateElement && v.isValidTime==isValidTime;
    }
    
    /**
     * Returns a deep copy of the date element
     *
     * @return a deep copy
     */
    
    public DateElement deepCopy() { 
        return new DateElement(dateElement,isValidTime);
    }      

    /**
     * Test method.
     *
     * @param args command line arguments
     */

    public static void main(String[] args) {
        DateElement v = new DateElement(Calendar.YEAR,true);
        DateElement u = new DateElement(Calendar.YEAR,false);
        System.out.println(v.equals(u));
        System.out.println(v.compareTo(u));
        System.out.println(v.hashCode()+":"+u.hashCode());
    }

}
