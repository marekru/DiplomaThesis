package evs.data.fileio;

//EVS dependencies
import evs.data.*;
import evs.analysisunits.*;
import evs.utilities.matrix.*;
import evs.utilities.*;
import evs.utilities.mathutil.*;

//Java io dependencies
import java.io.*;

//Java util dependencies
import java.util.*;

//Other XML dependencies
import org.apache.xerces.parsers.*;
import org.xml.sax.*;

/**
 * Reads and writes paired data files in XML format and generates a paired dataset
 * from an analysis unit containing an appropriate file data source.
 * 
 * @author evs@hydrosolved.com
 */

public class PairedFileIO extends FileIO {

    /********************************************************************************
     *                                                                              *
     *                                 VARIABLES                                    *
     *                                                                              *
     *******************************************************************************/    

    /**
     * Default date format for reading and writing text.
     */

    public static final String DEFAULT_DATE_FORMAT = 
            StringUtilities.DEFAULT_DATE_FORMAT;

    /**
     * Progress monitor for reading input.
     */
    
    private static double perc = 0;

    /**
     * Date format for reading and writing text.
     */

    private static String dateFormat = DEFAULT_DATE_FORMAT;

    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/

    /**
     * Reads a file containing paired data and returns a paired dataset.
     *
     * Eliminates duplicate pairs (same forecast valid time and lead time).
     * 
     * @param pairedFile the pairedFile
     * @param ioState the I/O state
     * @param nV the null value
     * @return a paired dataset
     */

    public static PairedData read(final File pairedFile, final IOState ioState, double nV) throws IOException {
        return read(pairedFile,ioState,true,nV);
    }

    /**
     * Reads a file containing paired data and returns a paired dataset.
     *
     * Specify whether to eliminate duplicate pairs (same forecast valid time
     * and lead time).
     * 
     * @param pairedFile the pairedFile
     * @param ioState the I/O state
     * @param eliminateDuplicates is true to eliminate duplicate pairs
     * @param nV the null value
     * @return a paired dataset
     */

    public static PairedData read(final File pairedFile, final IOState ioState, 
            boolean eliminateDuplicates, double nV) throws IOException {
        return new PairedData(readRawPairs(pairedFile,ioState,nV),eliminateDuplicates,nV);
    }

    /**
     * Reads a file containing paired data and returns a matrix of double values.
     * This method is useful for reading paired data that contains multiple
     * forecasts with the same valid time and lead time, which is not allowed for
     * a regular paired dataset (e.g. if pooling across several locations).
     *
     * @param pairedFile the pairedFile
     * @param ioState the I/O state 
     * @param nV the null value
     * @return a paired dataset
     */
    
    public static DoubleMatrix2D readRawPairs(final File pairedFile, final IOState ioState,
            double nV) throws IOException {
        final Timer t = new Timer();
        final BufferedReader r = new BufferedReader(new FileReader(pairedFile));
        try {
            final PairedFileSAXHandler f = new PairedFileSAXHandler(nV);
            final SAXParser p = new SAXParser();
            final InputSource input= new InputSource(r);
            p.setContentHandler(f);
            TimerTask task = new TimerTask() {
                public void run() {
                    double count = f.getPairCount();
                    if(count>0) {
                        double cn = f.getPairsReadCount();
                        perc = (cn/count)*100;
                        if(cn==count) {
                            cancel();
                        }
                    }
                    if(!ioState.getIOState()) {
                        try {
                            System.out.println("Reading of pairs cancelled.");
                            r.close();
                            t.cancel();
                        } catch(Exception e) {
                            //e.printStackTrace();
                            //Do nothing
                        }
                        cancel();
                    }
                }
            };
            t.scheduleAtFixedRate(task, 0, 50);            
            p.parse(input);
            return f.getPairs();
        } catch(Throwable e) {
            e.printStackTrace();
            String text = "Error reading the paired file '"+pairedFile+"'.";
            if(e.getMessage()!=null) {
                text = text + e.getMessage();
            }
            throw new IOException(text);
        } finally {
            perc = 0;
            r.close();
            t.cancel();
        }
    }

    /**
     * Reads a text file containing paired data where each row contains the forecast
     * date (month, day, year, hour), lead time, observation and ensemble members.
     *
     * Assumes UTC time.
     *
     * Eliminates duplicate pairs (same forecast valid time and lead time).
     *
     * @param pairedFile the paired file to read
     * @param valDelims the data value delimiter(s)
     * @param nV the null value
     * @return the paired data set
     */

    public static PairedData readText(File pairedFile, String valDelims, double nV) throws IOException {
        return readASCIIPairs(pairedFile,valDelims,TimeZone.getTimeZone("UTC"),true,0, nV);
    }

    /**
     * Reads a text file containing paired data where each row contains the forecast
     * date (month, day, year, hour), lead time, observation and ensemble members.
     *
     * @param pairedFile the paired file to read
     * @param valDelims the data value delimiter(s)
     * @param removeDuplicates is true to remove duplicates
     * @param timeZone the time zone
     * @param skipRows the number of rows to skip in the header
     * @param nV the null value
     * @return the paired data set
     */
    
    public static PairedData readText(File pairedFile, String valDelims, 
            TimeZone timeZone,boolean removeDuplicates,int skipRows, double nV) throws IOException {
        return readASCIIPairs(pairedFile,valDelims,timeZone,removeDuplicates,skipRows,nV);
    }    
    
    /**
     * Reads a text file containing paired data where each row contains the forecast
     * date (month, day, year, hour), lead time, observation and ensemble members. 
     *
     * Specify whether to eliminate duplicate pairs (same forecast valid time
     * and lead time).
     *
     * Currently reads ASCII with a fixed date format.
     *
     * TODO: update to support date formats specified by the ASCII format variable
     * in this class.
     * 
     * @param pairedFile the paired file to read
     * @param valDelims the data value delimiter(s)
     * @param timeZone the time zone
     * @param eliminateDuplicates is true to eliminate duplicate pairs
     * @param skipRows an optional number of rows to skip in the header
     * @param nV the null value
     * @return the paired data set
     */
    
    public static PairedData readASCIIPairs(File pairedFile, String valDelims, TimeZone timeZone,
            boolean eliminateDuplicates, int skipRows, double nV) throws IOException {
        if(skipRows<0) {
            throw new IllegalArgumentException("The number of rows to skip must be "
                    + "greater than or equal to zero.");
        }
        BufferedReader in = null;
        try {
            BufferedInputStream bIN = new BufferedInputStream(new FileInputStream(pairedFile));
            in = new BufferedReader(new InputStreamReader(bIN));
            String line = null;
            int maxCols = 0;
            Vector<double[]> tempData = new Vector();
            //Skip rows as necessary
            if (skipRows > 0) {
                for (int i = 0; i < skipRows; i++) {
                    in.readLine();
                }
            }
            while ((line = in.readLine()) != null) {
                //StringTokenizer stb = new StringTokenizer(line, "-/, \t\n\r\f", false);
                StringTokenizer stb = new StringTokenizer(line,valDelims, false);
//                int m = Integer.parseInt(stb.nextToken());
//                int d = Integer.parseInt(stb.nextToken());
//                int y = Integer.parseInt(stb.nextToken());
//                int h = Integer.parseInt(stb.nextToken());
                Calendar cal = StringUtilities.parseDate(stb.nextToken(),dateFormat,timeZone,false);
                if(cal==null) {
                    throw new IOException("Could not parse dates in file "
                            + ""+pairedFile+" using date format "+dateFormat+".");
                }

//                Calendar cal = Calendar.getInstance();
//                cal.clear();
//                cal.set(cal.YEAR, y);
//                cal.set(cal.MONTH,getCalMonthFromAct(m));
//                cal.set(cal.DAY_OF_MONTH, d);
//                cal.set(cal.HOUR_OF_DAY,h);
                
                long millis = cal.getTimeInMillis();
                long hours = millis/(1000*60*60);  
                
                
//                //Hours relative to the epoch
//                double lead = new Double(stb.nextToken(valDelims));
//                //If observed data only, the next call will fail
//                double obs = -999;
//                try {
//                    obs = new Double(stb.nextToken(valDelims));
//                } catch(NoSuchElementException e) {
//                    obs = lead; //Update obs, which was read as lead.
//                }
                
                Vector<Double> vec = new Vector();
                while (stb.hasMoreTokens()) {
                    vec.add(new Double(stb.nextToken(valDelims)));                    
                }
                int tot = vec.size();
                double[] nextLine = new double[tot+1];
                nextLine[0]=hours;
//                nextLine[1]=lead;
//                nextLine[2]=obs;
                for(int i = 0; i < tot; i++) {
                    nextLine[i+1]=vec.get(i);
                }
                tempData.add(nextLine);
                if(nextLine.length > maxCols) {
                    maxCols = nextLine.length;
                }
            }
            //Construct the paired matrix
            double[][] data = new double[tempData.size()][maxCols];
            for (int i = 0; i < data.length; i++) {
                //Must explicitly initialize for the full space required: allocation 
                //of a 1D array in a 2D array is NOT sufficient
                double[] nextD = new double[maxCols];
                Arrays.fill(nextD,nV);
                System.arraycopy(tempData.get(i), 0, nextD, 0, tempData.get(i).length);
                data[i] = nextD;
            }
            return new PairedData(new DenseDoubleMatrix2D(data),eliminateDuplicates,nV);
        } catch(Exception e) {
            e.printStackTrace();
            throw new IllegalArgumentException(e.getMessage());
        } finally {
            if(in != null) {
                try {
                    in.close();
                } catch(Exception e) {
                    //Do nothing
                }
            }
        }  
    }

    /**
     * Returns the date format used for reading.
     *
     * @return the date format
     */

    public static String getDateFormat() {
        return dateFormat;
    }

    /**
     * Returns the percentage progress of the IO.
     * 
     * @return the percentage progress of the IO.
     */
    
    public static int getProgress() {
        return (int)perc;
    }

    /**
     * Returns the actual numeric month from the specified java.util.Calendar month.
     *
     * @param month the input month from java.util.Calendar
     * @return the actual month
     */

    public static int getActMonthFromCal(int month) {
        switch(month) {
            case Calendar.JANUARY: return 1;
            case Calendar.FEBRUARY: return 2;
            case Calendar.MARCH: return 3;
            case Calendar.APRIL: return 4;
            case Calendar.MAY: return 5;
            case Calendar.JUNE: return 6;
            case Calendar.JULY: return 7;
            case Calendar.AUGUST: return 8;
            case Calendar.SEPTEMBER: return 9;
            case Calendar.OCTOBER: return 10;
            case Calendar.NOVEMBER: return 11;
            case Calendar.DECEMBER: return 12;
            default: throw new IllegalArgumentException("Unrecognized month.");
        }
    }

    /**
     * Returns the java.util.Calendar numeric month from the actual calendar month.
     *
     * @param month the input month
     * @return the java.util.Calendar month
     */

    public static int getCalMonthFromAct(int month) {
        switch(month) {
            case 1: return Calendar.JANUARY;
            case 2: return Calendar.FEBRUARY;
            case 3: return Calendar.MARCH;
            case 4: return Calendar.APRIL;
            case 5: return Calendar.MAY;
            case 6: return Calendar.JUNE;
            case 7: return Calendar.JULY;
            case 8: return Calendar.AUGUST;
            case 9: return Calendar.SEPTEMBER;
            case 10: return Calendar.OCTOBER;
            case 11: return Calendar.NOVEMBER;
            case 12: return Calendar.DECEMBER;
            default: throw new IllegalArgumentException("Unrecognized month.");
        }
    }

    /**
     * Returns true if the input file is of the PI-XML type.
     *
     * @param file the input file
     * @return true if the input file can be read
     * @deprecated
     */

    public boolean isOfType(File file) throws IOException {
        if(file==null) {
            return false;
        }
        //Read the first two lines
        //If the second line starts with <TimeSeries return true, else false
        BufferedInputStream bIN = null;
        BufferedReader in = null;
        try {
            bIN = new BufferedInputStream(new FileInputStream(file));
            in = new BufferedReader(new InputStreamReader(bIN));
            String check = in.readLine();
            if(check==null) {
                return false;
            }
            return check.startsWith("<!--Paired");
        } catch (Exception e) {
            return false;
        } finally {
            if (bIN != null) {
                bIN.close();
            }
            if(in != null) {
                in.close();
            }
        }
    }
    
    /********************************************************************************
     *                                                                              *
     *                               MUTATOR METHODS                                *
     *                                                                              *
     *******************************************************************************/

    /**
     * Sets the date format for reading and writing ASCII.  Throws an exception if
     * the format is not supported. See {@link evs.utilities.StringUtilities} for
     * supported types.
     *
     * @param format the date format
     */

    public static void setASCIIDateFormat(String format) throws IllegalArgumentException {
//        StringUtilities.checkDateFormat(format);
        dateFormat=format;
    }

    /**
     * Writes the specified paired data to a specified file.
     *
     * @param pairedFile the paired file
     * @param pairs the paired data
     * @param stripNulls is true to strip null values, false otherwise
     * @param precision the number of decimal places (>=1) for writing pairs
     * @param ioState the I/O state
     * @param nV the null value
     */
    
    public static void write(File pairedFile, PairedData pairs, boolean stripNulls, 
            int precision, final IOState ioState,  double nV) throws IOException {
        if(pairs==null) {
            throw new IllegalArgumentException("Specify non-null paired dataset for writing.");
        }
        write(pairedFile,pairs.getPairs(),stripNulls,precision, ioState, nV);
    }

    /**
     * Writes the specified paired data, contained in a matrix of double values,
     * to a specified file.
     *
     * @param pairedFile the paired file
     * @param pairs the paired data
     * @param stripNulls is true to strip null values, false otherwise
     * @param precision the number of decimal places (>=1) for writing pairs
     * @param ioState the I/O state
     * @param nV the null value
     */

    public static void write(File pairedFile, DoubleMatrix2D pairs, boolean stripNulls, 
            int precision, final IOState ioState, double nV) throws IOException {
        write(pairedFile, new DoubleMatrix2D[]{pairs},stripNulls,precision, ioState,nV);
    }

    /**
     * Writes the specified array of paired datasets to the specified file.
     *
     * @param pairedFile the paired file
     * @param pairs the array of paired datasets
     * @param stripNulls is true to strip null values, false otherwise
     * @param precision the number of decimal places (>=1) for writing pairs
     * @param ioState the I/O state
     * @param nV the null value
     */

    public static void write(File pairedFile, DoubleMatrix2D[] pairs, boolean stripNulls, 
            int precision, final IOState ioState, double nV) throws IOException {
        if(pairedFile == null) {
            throw new IllegalArgumentException("Specify a writeable file for the paired data.");
        }
        if(pairs==null) {
            throw new IllegalArgumentException("Specify a non-null paired dataset for writing.");
        }
        if(precision<0) {
            throw new IllegalArgumentException("The precision for writing verification pairs must be one decimal place or more.");
        }
        if(ioState == null) {
            throw new IllegalArgumentException("Specify a non-null IO state variable for recording the IO state.");
        }
        int pairSum = 0;
        for(DoubleMatrix2D p: pairs) {
            if(p==null) {
                throw new IllegalArgumentException("One or more of the input paired datasets for writing was null.");
            }
            pairSum+=p.getRowCount();
        }
        if(!pairedFile.exists()) {
            boolean create = pairedFile.createNewFile();
            if(!create) {
                throw new IOException("Unable to create paired file for writing.");
            }
        }
        final BufferedWriter b = new BufferedWriter(new FileWriter(pairedFile));
        final Timer t = new Timer();
        boolean success = false;
        TimerTask task = new TimerTask() {
            public void run() {
                if (!ioState.getIOState()) {
                    System.out.println("Writing of pairs cancelled.");
                    t.cancel();
                    try {
                        b.close();
                    } catch (Exception e) {
                        //Do nothing
                    }
                    cancel();
                }
            }
        };
        t.scheduleAtFixedRate(task, 0, 50);

        try {
                String nl = System.getProperty("line.separator");
                //DO NOT WANT TO CONSTRUCT AN ENTIRE XML DOCUMENT HERE.
                //WRITE SEQUENTIALY INSTEAD
                //Explain
                b.write("<!--Paired data file for the Ensemble Verification System (EVS).  Each pair comprises one or more " + nl
                        + "forecasts and one observation, and is stored under a 'pr' tag.  Each pair has a readable date in UTC, a " + nl
                        + "lead time in hours ('ld_h'), an observation ('ob'), one or more forecast values ('fc'), and an internal " + nl
                        + "time in hours (in_h) used by EVS to read the pairs (in preference to the UTC date).  The internal time " + nl
                        + "is incremented in hours from the forecast start time (represented in internal hours) to the end of the " + nl
                        + "forecast lead period.  When multiple forecasts are present, each forecast represents an ensemble member, " + nl
                        + "and each ensemble member is listed in trace-order, from the first trace to the last.-->");
                //Pair count
                b.write(nl + "<pairs>" + nl);
                b.write("<pair_count>" + pairSum + "</pair_count>" + nl);

                //Write the paired data, actual date, observed value, forecast values
                for (DoubleMatrix2D pD : pairs) {

                    int length = pD.getRowCount();
                    double[][] pData = pD.toArray();

                    //Iterate through each pair
                    for (int i = 0; i < length; i++) {
                        b.write("<pr>" + nl);
                        //Date for ease of reading
                        Calendar c = Calendar.getInstance();
                        c.setTimeZone(SimpleTimeZone.getTimeZone("UTC"));
                        c.clear();
                        double hours = pD.get(i, 0);
                        long millis = (long) (hours * 1000.0 * 60.0 * 60.0);
                        c.setTimeInMillis(millis);
                        b.write("<dt>" + nl);
                        b.write("<y>" + c.get(c.YEAR) + "</y>" + nl);
                        b.write("<m>" + (getActMonthFromCal(c.get(c.MONTH))) + "</m>" + nl);  //Add 1 to zero-based month
                        b.write("<d>" + c.get(c.DAY_OF_MONTH) + "</d>" + nl);
                        //Add decimal to hour of day in case of fractional hours
                        double writeHours = c.get(c.HOUR_OF_DAY) + (hours - ((int) hours));
                        b.write("<h>" + writeHours + "</h>" + nl);
                        b.write("</dt>" + nl);
                        //Lead hours
                        b.write("<ld_h>" + pD.get(i, 1) + "</ld_h>" + nl);
                        //Observation
                        b.write("<ob>" + Mathematics.round(pD.get(i, 2), precision) + "</ob>" + nl);
                        //Forecasts
                        String forecasts = "";
                        double[] dat = new double[pData[i].length - 3];
                        //Strip any null values from the paired file
                        System.arraycopy(pData[i], 3, dat, 0, dat.length);
                        if (stripNulls) {
                            int nCount = 0;
                            for (int j = 0; j < dat.length; j++) {
                                if (dat[j] == nV) {
                                    nCount += 1;
                                }
                            }
                            if (nCount > 0) {
                                double[] dat2 = new double[dat.length - nCount];
                                int tot = 0;
                                for (int j = 0; j < dat.length; j++) {
                                    if (dat[j] != nV) {
                                        dat2[tot] = dat[j];
                                        tot++;
                                    }
                                }
                                dat = dat2;
                            }
                        }
                        forecasts = getDoubleArrayString(dat, precision);
                        b.write("<fc>" + forecasts + "</fc>" + nl);
                        b.write("<in_h>" + hours + "</in_h>" + nl);
                        b.write("</pr>" + nl);
                    }
                }
                b.write("</pairs>");
                success = true;
        } catch (Throwable e) {
            e.printStackTrace();
            throw new IOException(e.getMessage());
        } finally {
            if(b != null) {
                b.close();
            }
            t.cancel();
            if(!success) {
                if(pairedFile.exists()) {
                    try {
                        pairedFile.delete();
                    } catch(Exception e) {
                        //Do nothing
                    }
                }
            }
        }
    }
    
    /**
     * Writes a flat text format file from a paired dataset where each row comprises 
     * the forecast date and time, the forecast lead time, the observation, and 
     * the ensemble members. 
     *
     * @param pairs the paired data
     * @param output the output file
     * @param sep the separator string
     */
    
    public static void writeASCIIPairs(PairedData pairs, File output, String sep) throws IOException {
        writeASCIIPairs(pairs.getPairs(),output,sep);
    }

    /**
     * Writes a flat text format file from a paired dataset where each row comprises
     * the forecast date and time, the forecast lead time, the observation, and
     * the ensemble members.
     *
     * @param pairs the paired data
     * @param output the output file
     * @param sep the separator string
     */

    public static void writeASCIIPairs(DoubleMatrix2D pairs, File output, String sep) throws IOException {
        writeASCIIPairs(new DoubleMatrix2D[]{pairs}, output, sep);
    }

    /**
     * Writes a flat text format file from a paired dataset where each row comprises
     * the forecast date and time, the forecast lead time, the observation, and
     * the ensemble members.
     *
     * @param pairs the paired data
     * @param output the output file
     * @param sep the separator string
     */

    public static void writeASCIIPairs(DoubleMatrix2D[] pairs, File output, String sep) throws IOException {
        if(pairs == null) {
            throw new IllegalArgumentException("Specify non-null paired file.");
        }
        if(output == null) {
            throw new IllegalArgumentException("Specify non-null output file.");
        }
        if(sep == null) {
            throw new IllegalArgumentException("Specify non-null separator string.");
        }
        String nL = System.getProperty("line.separator");
        BufferedWriter b = new BufferedWriter(new FileWriter(output));
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));

        try {
            for (DoubleMatrix2D next : pairs) {
                double[][] data = next.toArray();
                for (int i = 0; i < data.length; i++) {
                    for (int j = 0; j < data[i].length; j++) {
                        //Date
                        if (j == 0) {
                            c.clear();
                            c.setTimeInMillis((long) (data[i][0] * 60 * 60 * 1000));
                            b.write(StringUtilities.parseDate(c,dateFormat)+ sep);
                        } //Last element
                        else if (j == (data[i].length - 1)) {
                            b.write(data[i][j] + nL);
                        } //Other elements
                        else {
                            b.write(data[i][j] + sep);
                        }
                    }
                }
            }
        } catch(IOException e) {
            throw e;
        } finally {
            if(b!= null) {
                try {
                    b.close();
                }
                catch(Exception f) {
                    //Do nothing
                }
            }
        }
    }
    
    /**
     * Reads a paired data file and converts the output to a flat text format
     * where each row comprises the forecast date and time, the forecast lead time,
     * the observation, and the ensemble members. 
     *
     * Eliminates duplicate pairs (same forecast valid time and lead time). 
     * 
     * @param pairedFile the paired file
     * @param ioState the I/O state
     * @param output the output file
     * @param sep the separator string
     * @param nV the null value
     */
    
    public static void readPairedFileWriteASCII(File pairedFile, File output, IOState ioState, String sep,
            double nV) throws IOException {
        PairedData pairs = read(pairedFile,ioState,true,nV);
        writeASCIIPairs(pairs,output,sep);
    }    
    
    /**
     * Reads a paired data file and converts the output to a flat text format
     * where each row comprises the forecast date and time, the forecast lead time,
     * the observation, and the ensemble members. 
     *
     * Specify whether to eliminate duplicate pairs (same forecast valid time
     * and lead time). 
     * 
     * @param pairedFile the paired file
     * @param ioState the I/O state
     * @param output the output file
     * @param sep the separator string
     * @param eliminateDuplicates is true to eliminate duplicate pairs
     * @param nV the null value
     */
    
    public static void readPairedFileWriteASCII(File pairedFile, File output, IOState ioState, 
            String sep, boolean eliminateDuplicates, double nV) throws IOException {
        PairedData pairs = read(pairedFile,ioState,eliminateDuplicates,nV);
        writeASCIIPairs(pairs,output,sep);
    }

/*******************************************************************************
 *                                                                             *
 *                                  TEST METHOD                                *
 *                                                                             *
 ******************************************************************************/     
    
    /**
     * Test method.
     *
     * @param args the args
     */
    
    public static void main(String[] args) {
//        try {
//            File f = new File("C:/Documents and Settings/James Brown/Desktop/Real_time_pairs_ensembles_cond.xml");
//            PairedData p = read(f,new IOState(),true);
//            /**double[][] data = new double[200][20];
//            for(int i = 0; i < data.length; i++) {
//                data[i][0] = i;
//                data[i][1] = i;
//                for(int j = 2; j < data[0].length; j++) {
//                    data[i][j] = Math.random();
//                }
//            }*/
//            
//            //DoubleMatrix2D pairs = new evs.utilities.matrix.DenseDoubleMatrix2D(data);
//            writeASCIIPairs(p,new File("C:/Documents and Settings/James Brown/Desktop/test2.txt")," ");
//            PairedData p2 = readASCIIPairs(new File("C:/Documents and Settings/James Brown/Desktop/test2.txt"),true);
//            writeASCIIPairs(p2,new File("C:/Documents and Settings/James Brown/Desktop/test3.txt"), " ");
//            
//        } catch(Exception e) {
//            e.printStackTrace();
//        }
    }   
    
}
