package evs.data;

/**
 * Class for throwing exceptions that signify an invalid unit.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class InvalidUnitException extends RuntimeException {
    
    /**
     * Constructs an InvalidUnitException with no message.
     */
    
    public InvalidUnitException() {
        super();
    }

    /**
     * Constructs an InvalidUnitException with the specified message. 
     * 
     * 
     * @param s the message.
     */
    
    public InvalidUnitException(String s) {
	super(s);
    }
}
