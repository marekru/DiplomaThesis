package evs.data;

/**
 * Class for indexing data by Verification Unit, which stores a unique combination
 * of location ID and variable ID.
 *
 * @author evs@hydrosolved.com
 */

public class VUIdentifier implements Comparable {

    /**
     * Location ID.
     */

    private String locationID;

    /**
     * Variable ID.
     */

    private String variableID;

    /**
     * Construct a VUIdentifier.
     *
     * @param locationID the location ID
     * @param variableID the variable ID
     */

    public VUIdentifier(String locationID, String variableID) {
        if(locationID==null || variableID == null) {
            throw new IllegalArgumentException("The location ID and variable ID must both be non-null.");
        }
        if(locationID.equals(variableID)) {
            throw new IllegalArgumentException("The location ID and variable ID must be different.");
        }
        this.locationID = locationID;
        this.variableID = variableID;
    }

    /**
     * Throws an exception if the input object is not of the same type.
     *
     * Returns input.locationID.compareTo(this.locationID) or, if zero,
     * input.variableID.compareTo(this.variableID).
     *
     * @param input the input object to compare
     * @return an integer: less than if the input is less, 0 if equal, positive otherwise
     */

    public int compareTo(Object input) {
        if(!(input instanceof VUIdentifier)) {
            throw new IllegalArgumentException("Expected an object of class '"+VUIdentifier.class+"'.");
        }
        VUIdentifier compare = (VUIdentifier)input;
        int locIDComp = compare.locationID.compareTo(locationID);
        if(locIDComp!=0) {
            return locIDComp;
        }
        return compare.variableID.compareTo(variableID);
    }

    /**
     * For hashing.
     *
     * @return  hashcode
     */
    public int hashCode() {
        return toString().hashCode();
    }
    
    /**
     * Return the location ID.
     */

    public String getLocationID() {
        return locationID;
    }
    
    /**
     * Return the variable ID.
     */

    public String getVariableID() {
        return variableID;
    }    
    
    /**
     * String representation.
     *
     * @return a string representation.
     */

    public String toString() {
        return locationID + "." + variableID;
    }

    /**
     * Returns true if the input is a VUIdentifier and has the same locationID
     * and variableID as the current object.
     *
     * @param o the object to test for equality
     * @return true if the objects are equal
     */

    public boolean equals(Object o) {
        if(!(o instanceof VUIdentifier)) {
            return false;
        }
        VUIdentifier v  = ((VUIdentifier)o);
        return v.locationID.equals(locationID) && v.variableID.equals(variableID);
    }
    
    /**
     * Returns a deep copy of the object
     * 
     * @return a deep copy
     */

    public VUIdentifier deepCopy() {
        return new VUIdentifier(locationID,variableID);
    }
    
}

