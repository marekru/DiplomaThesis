package evs.data;

//Java dependencies
import evs.analysisunits.VerificationUnit;
import evs.utilities.StringUtilities;
import java.util.*;

//EVS dependencies
import evs.utilities.matrix.*;
import evs.utilities.mathutil.*;

/**
 * A class for specifying a simple date condition comprising a start and end date
 * within which the data must fall. The conditions refer to valid dates with times in UTC.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class SimpleDateCondition extends Condition {
    
    /********************************************************************************
     *                                                                              *
     *                             INSTANCE VARIABLES                               *
     *                                                                              *
     *******************************************************************************/    

    /**
     * The verification unit associated with this condition.
     */
    
    protected VerificationUnit vu = null;
    
    /**
     * Start date
     */
    
    private Calendar start = null;

    /**
     * End date
     */
    
    private Calendar end = null;

    /********************************************************************************
     *                                                                              *
     *                                 CONSTRUCTOR                                  *
     *                                                                              *
     *******************************************************************************/        
    
    /**
     * Constructs a condition on the start and end dates of the verification window
     * specified in the input verification unit, together with the time system used
     * for the verification window. The input verification unit must have start
     * and end dates defined.
     *
     * @param vu the verification unit
     */
     
    public SimpleDateCondition(final VerificationUnit vu) throws IllegalArgumentException {
        if(!vu.hasDates()) {
            throw new IllegalArgumentException("Start and end dates cannot be null.");
        }
        this.vu = vu;
        this.start = vu.getStartDate();
        this.end = vu.getEndDate();
    }    

    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/        
    
    /**
     * Returns true if a condition can be applied to a specified verification 
     * unit, otherwise returns false or throws an exception if the condition is false 
     * and throwEx is true.
     *
     * @param vu the verification unit
     * @param throwEx the exception
     * @return true if the condition can be applied, false otherwise
     */
    @Override
    public final boolean canApplyCondition(VerificationUnit vu, boolean throwEx) throws IllegalArgumentException {
        if(vu == null) {
            throw new IllegalArgumentException("The input verification unit cannot be null.");
        }
        boolean returnMe = true;
        if(!vu.hasDates()) {
            returnMe = false;
            if(throwEx) {
                throw new IllegalArgumentException("Set the start and end dates of the parent unit '"+vu+"' before associating more specific conditions with this unit.");
            }
        }        
        return returnMe;
    }      

    /**
     * Applies the condition, returning a 1D matrix of boolean values whose elements
     * indicate which rows should be used, where true indicates a row should be
     * used. The input data may contain either observed data (i.e. two columns,
     * with valid time and observations), forecasts (valid time, lead time, and members) 
     * or paired data (valid time, lead time, observations and members).  
     *
     * @param data the data
     * @param dataType the data type
     * @return the rows that should be used given the condition
     */

    @Override
    public BooleanMatrix1D apply(DoubleMatrix2D data, int dataType) throws IllegalArgumentException {
        if(data==null) {
            throw new IllegalArgumentException("Cannot subset null input data.");
        }
        if(dataType!=OBSERVED_DATA && data.getColumnCount()<3) { //JB @ 8th May 2013
            String format = "FORECAST_DATA";
            if(dataType==PAIRED_DATA) {
                format = "PAIRED_DATA"; 
            }
            throw new IllegalArgumentException("Insufficient columns in input data ("+data.getColumnCount()+") for specified format, '"+format+"'.");
        }
        //Find the hours in UTC
        double st = start.getTimeInMillis();
        double en = end.getTimeInMillis();
        int off = start.getTimeZone().getOffset((long)st);
        int off2 = end.getTimeZone().getOffset((long)en);
        st = st + off;
        en = en + off2;
        st = st/(1000.0*60.0*60.0);
        en = en/(1000.0*60.0*60.0);
        boolean issueTime = false;
        //Data type is forecast or paired and time system is issue time
        //JB @ 8th May 2013
        if(!vu.isVerifWindowInValidTime() && dataType!=OBSERVED_DATA) {
            issueTime = true;
        }
        DoubleProcedure bet = FunctionLibrary.isBetween(st,en);
        int rows = data.getRowCount();
        boolean[] include = new boolean[rows];
        for(int i = 0; i < rows; i++) {
            if(issueTime) { //JB @ 8th May 2013
                include[i] = bet.apply(data.get(i,0)-data.get(i,1));  //Subtract lead time from valid time
            } else {
                include[i] = bet.apply(data.get(i,0));
            }
        }        
        DenseBooleanMatrix1D returnMe = new DenseBooleanMatrix1D(include);
        return returnMe;        
//        if(data == null) {
//            throw new IllegalArgumentException("No data have been defined for conditioning purposes.");
//        }
//        boolean checkStart = start!=null;
//        boolean checkEnd = end!=null;
//        int rows = data.getRowCount();
//        boolean[] include = new boolean[rows];
//        DoubleProcedure test = null;
//        if(checkStart && checkEnd) {
//            test = FunctionLibrary.isBetween(start.getTimeInMillis(),end.getTimeInMillis());
//        } else {
//            if(checkStart) {
//                test = FunctionLibrary.isGreaterEqual(start.getTimeInMillis());
//            } else if(checkEnd){
//                test = FunctionLibrary.isLessEqual(end.getTimeInMillis());
//            } 
//            //None defined
//            else {
//                Arrays.fill(include,true);
//                return new DenseBooleanMatrix1D(include);
//            }
//        }
//        //Check whether conditions met
//        for(int i = 0; i < rows; i++) {
//            long millis = (long)(data.get(i,0)*3600000);
//            include[i] = test.apply(millis);
//        }
//        DenseBooleanMatrix1D returnMe = new DenseBooleanMatrix1D(include);
//        return returnMe;
    }

    /**
     * Returns true if the input object is a simple date condition and the conditions
     * are equal to those in the current object, false otherwise
     *
     * @param obj the input object
     * @return true if the object has equivalent date conditions
     */
    
    @Override
    public boolean equals(Object obj) {
        if(!(obj instanceof SimpleDateCondition)) {
            return false;
        }
        boolean returnMe = false;
        //All null or all equal or null pointer exception
        try {
            returnMe = (start==null && end == null && 
                    ((SimpleDateCondition)obj).start == null
                    && ((SimpleDateCondition)obj).end == null) || 
                    (((SimpleDateCondition)obj).start.equals(start) && 
                    ((SimpleDateCondition)obj).end.equals(end));
            //JB @ 8th May 2013
            returnMe = returnMe && vu.isVerifWindowInValidTime()==
                    ((SimpleDateCondition)obj).vu.isVerifWindowInValidTime();      
        } catch(NullPointerException e) {
            returnMe = false;
        }
        return returnMe;
    }
    
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        assert false : "hashCode not implemented for DateCondition.";
        return 1;
    }
    
    /**
     * Returns a deep copy of the verification condition.
     *
     * @return a deep copy
     */
    
    public Condition deepCopy() {   
        return new SimpleDateCondition(vu);
    }
    
    /**
     * Print a string representation.
     * 
     * @return a string representation
     */
    
    @Override
    public String toString() {
        String startDate = "Start date: "+StringUtilities.parseDate(start,"yyyyMMddHH");
        String endDate = "End date: "+StringUtilities.parseDate(end,"yyyyMMddHH");
        String nL = System.getProperty("line.separator");
        return startDate + nL + endDate;
    }    
    
}
