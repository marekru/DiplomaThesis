package evs.data.fileio.ohdfile.data;

import evs.data.fileio.ohdfile.misc.HBinaryInputStream;
import evs.data.fileio.ohdfile.misc.HString;
import evs.data.fileio.ohdfile.misc.HCalendar;
import evs.data.fileio.ohdfile.misc.Messenger;
import evs.data.fileio.ohdfile.misc.SegmentedLine;
import evs.utilities.matrix.DenseDoubleMatrix2D;
import evs.analysisunits.AnalysisUnit;
import java.util.*;
import java.io.*;
import java.text.NumberFormat;

/**
 * This class reads in and stores the data contained within an ESPTS file.  It can also write it
 * out to a new ESPTS file.  The variables in the data set are <Julian hour> <value>, where the
 * Julian hour is in GMT.  Hence, ALL JULIAN HOUR VALUES ARE CONVERTED TO GMT PRIOR TO STORAGE!
 * It uses the _nlstz to get the GMT adjustment value to do the conversion.  Note that all there
 * are, as of ob4, no get methods for the attributes (this is laziness on my part).  Hence, the
 * attributes should be accessed directly, such as <object>._formatver, for example.
 * @author hank
 */

public class ESPData extends DataSet {
    private static final long serialVersionUID = 1L;
    final static String CLASSNAME = "ESPData";
    final static int NUMBER_OF_FILENAME_SEGMENTS = 5;  //Required number of components of the file name.
    final static int DEFAULT_GROWTH_SIZE = 100;        //This is currently unused.
    final public static int JULIAN_HOUR = 0;
    final public static int VALUE = 1;

    //Data from the file name...
    public String _segmentID;
    public String _timeSeriesID;
    public String _dataType;
    public String _timeSeriesTypeExtension;
    public boolean _hsFlag;

    //Straight From The File Header!!!
    //These attribute names will match those seen in ESPTraceEns_readTraceEnsHdr.cxx for ESPADP.
    //The only difference is that I will remove any _'s from the middle.
    public float  _formatver;//formatting version number.
    public String _fsegid;   //8 chars -- segment id.
    public String _ftsid;    //8 chars -- ts id.
    public String _ftype;    //4 chars -- data type.
    public int    _tsdt;     //TS time step
    public int    _simflag;  //simulation flag, whatever that means.
    public String _tsunit;   //4 chars
    public int[]  _now;      //5 integers
    public int    _im;       //First month of data
    public int    _iy;       //First year of data
    public int    _idarun;   //Initial Julian day of run, from Jan 1, 1900, in the time zone specified by _nlstz.
    public int    _ldarun;   //Last Julian day of run, from Jan 1, 1900, in the time zone specified by _nlstz
    public int    _ijdlst;   //Carryover Julian day, from Jan 1, 1900, in the time zone specified by _nlstz
    public int    _ihlst;    //Carryover Julian hour, from Jan 1, 1900, in the time zone specified by _nlstz
    public int    _ljdlst;   //Forecast ending Julian day, from Jan 1, 1900, in the time zone specified by _nlstz
    public int    _lhlst;    //Forecast ending Julian hour, from Jan 1, 1900, in the time zone specified by _nlstz
    public int    _ntraces;  //Number of traces?
    public int    _ncm;      //Number of conditional months per trace
    public int    _nlstz;    //time zone number
    public int    _noutds;   //This is a daylight savings adjustment to the time zone number.  When 1, I'm in
    //daylight savings time.
    public int    _irec;     //REC# trace data ???
    public String _dim;      //4 chars -- unit dimensions
    public String _tscale;   //4 chars -- time scale of code (inst, mean, etc.)
    public String _segdesc;  //20 chars -- segment description
    public float  _lat;      //latitude
    public float  _long;     //longitude
    public String _fgrp;     //8 chars -- forecast group
    public String _cgrp;     //8 chars -- carryover group
    public String _rfcname;  //8 chars -- rfc name
    public String _espfile;  //80 chars -- trace file name
    public String _prsfstr;  //80 chars -- prsf string -- if it is "PRSF", then I've got a prsf.
    public String _esptext;  //80 chars -- user comments
    public int    _adjcount; //adjustment counter 0-9

    //The Processed File Header Variables!!!
    public Calendar _fcstStart;     //The beginning of the requested forecast time period, specified by the user of ESP.
    public Calendar _fcstEnd;       //The end.
    public Calendar _runStart;      //When the data actually starts...
    public Calendar _runEnd;        //and ends.
    public int      _numberPerMonth;   //The number of trace values to read in for each month.
    public int      _numberPerTrace;   //The number of trace values for each trace.

    private double nV = -999; //The null value
    
    
    /////////////////////////////////////////////////////////////////////////
    //Constructors
    /////////////////////////////////////////////////////////////////////////

    private ESPData() {}

    /**
     * @param filename The name of the file to load.
     * @param nV the null value
     * @throws ESPDataException if the file name is unacceptable or the data is bad.
     */
    public ESPData(String filename, double nV) throws ESPDataException {

        //Create the _now array...
        _now = new int[5];

        FileInputStream filein;
        HBinaryInputStream datafile;

        //Look at the file info.
        File thefile = new File(filename);

        //Check for existence and reability.
        if ( !thefile.exists() || !thefile.canRead() ) {
            Messenger.writeMsg(Messenger.EVT_SOURCE_IO + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,
                    "File \"" + filename + "\" either does not exist or is not readable.\n");
            throw new ESPDataException();
        }
        //Try to open the data file for reading.
        try {
            filein   = new FileInputStream(thefile);
            datafile = new HBinaryInputStream(filein);
        } catch (FileNotFoundException e1) {
            //JOptionPane.showMessageDialog(null, "Unable to open sac_sma file: " + binfilename,
            //    CLASSNAME + ": ERROR", JOptionPane.ERROR_MESSAGE);
            Messenger.writeMsg(Messenger.EVT_SOURCE_IO + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,
                    "Failed to open requested file " + filename + "\n");
            throw new ESPDataException();
        }

        //Try to read in the header of the file.
        int status = 0;
        try {
            //if ( !processFileName(thefile.getName()) ) {
            //    Messenger.writeMsg(Messenger.EVT_DATA + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,
             //           "The file name \"" + thefile.getName() + "\" is of improper format.\n");
                //throw new ESPDataException();
            //}

            //Read in the header information.
            readInHeader(datafile);
            status = 1;

            //Process the header information
            processHeader();

            //Initialize the data set.  This should create a bit too large of a data set,
            //but that shouldn't do any harm.
            initialize(( (_numberPerTrace + 1) * _ntraces), 2, false,nV);
            //Read in the data.
            readInData(datafile);
            //Close the input file.
            datafile.close();
        } catch (IOException e) {
            Messenger.writeMsg(Messenger.EVT_SOURCE_IO + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,
                    "Failed to read in ESP output time series file for this reason:\n");
            if (status == 0)
                Messenger.writeMsg(Messenger.EVT_SOURCE_IO + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,
                        "  Unable to read in the header.\n");
            else
                Messenger.writeMsg(Messenger.EVT_SOURCE_IO + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,
                        "  Unable to read in the data or it does not match what the header states.\n");

            throw new ESPDataException(e.getMessage());
        }
    }

    /**
     * Copy constructor.
     * 
     * @param nV the null value
     */
    public ESPData(ESPData base, double nV) {
        super(base);
        this.nV = nV;
        int i;

        //Set all the attributes.//Data from the file name...
        _segmentID    = base._segmentID;
        _timeSeriesID = base._timeSeriesID;
        _dataType     = base._dataType;
        _timeSeriesTypeExtension    = new String(base._timeSeriesTypeExtension);
        _hsFlag       = base._hsFlag;

        _formatver    = base._formatver;
        _fsegid       = base._fsegid;
        _ftsid        = base._ftsid;
        _ftype        = base._ftype;
        _tsdt         = base._tsdt;
        _simflag      = base._simflag;
        _tsunit       = base._tsunit;
        int[] _now = new int[5];
        for (i = 0; i < 5; i ++) {
            _now[i] = base._now[i];
        }
        _im           = base._im;
        _iy           = base._iy;
        _idarun       = base._idarun;
        _ldarun       = base._ldarun;
        _ijdlst       = base._ijdlst;
        _ihlst        = base._ihlst;
        _ljdlst       = base._ljdlst;
        _lhlst        = base._lhlst;
        _ntraces      = base._ntraces;
        _ncm          = base._ncm;
        _nlstz        = base._nlstz;
        _noutds       = base._noutds;
        _irec         = base._irec;
        _dim          = base._dim;
        _tscale       = base._tscale;
        _segdesc      = base._segdesc;
        _lat          = base._lat;
        _long         = base._long;
        _fgrp         = base._fgrp;
        _cgrp         = base._cgrp;
        _rfcname      = base._rfcname;
        _espfile      = base._espfile;
        _prsfstr      = base._prsfstr;
        _esptext      = base._esptext;
        _adjcount     = base._adjcount;

        Calendar _fcststart = (Calendar)(base._fcstStart.clone());
        Calendar _fcstend   = (Calendar)(base._fcstEnd.clone());
        Calendar _runstart  = (Calendar)(base._runStart.clone());
        Calendar _runend    = (Calendar)(base._runEnd.clone());
        _numberPerMonth  = base._numberPerMonth;
        _numberPerTrace  = base._numberPerTrace;
    }



    /////////////////////////////////////////////////////////////////////////
    //FILE I/O
    /////////////////////////////////////////////////////////////////////////


    /**
     * Check the file name for validity.  The file name MUST NOT include the path.
     * A name is bad if it has fewer than 5 segments, separated by '.'s.  Further,
     * the first two segments may not have more than 8 character, the 3rd 4, the
     * 4th 2, and the 5th segment must have at least 1 character.
     */
    public static boolean checkFileName(String filename) {
        //Segment the name.
        SegmentedLine segline = new SegmentedLine(filename, ".", SegmentedLine.MODE_ALLOW_EMPTY_SEGS);

        //Make sure the number of segments is acceptable.
        if (segline.getNumberOfSegments() < ESPData.NUMBER_OF_FILENAME_SEGMENTS)
            return false;

        //The temporary string.
        String temp;

        //Get the segment id.
        temp = segline.getASegment(0);
        if ((temp.length() > 8) || (temp.length() <= 0))
            return false;

        //Get the time series id.
        temp = segline.getASegment(1);
        if ((temp.length() > 8) || (temp.length() <= 0))
            return false;

        //Get the data type.
        temp = segline.getASegment(2);
        if ((temp.length() > 4) || (temp.length() <= 0))
            return false;

        //Check the time step.
        temp = segline.getASegment(3);
        if ((temp.length() > 2) || (temp.length() <= 0))
            return false;

        //Get the time series type extension.
        temp = segline.getASegment(4);
        if (temp.length() <= 0)
            return false;

        return true;
    }

    /**
     * Returns true if the data can be read.
     *
     * @param file
     * @return true if the data can be read
     * @deprecated
     */

    public static boolean isOfType(File  file) throws IOException {
        if(file == null) {
            return false;
        }
        if(!file.canRead()) {
            throw new IOException("Cannot check the file: "+file);
        }
        HBinaryInputStream head = null;
        try {
            ESPData es = new ESPData();
            head = new HBinaryInputStream(new FileInputStream(file.getCanonicalPath()));
            es.readInHeader(head);

            //In principle, this test could be made more stringent
            //Check that several parameters are within bounds
            if(es._ntraces > 0 && es._im> 0 && es._im <13 && es._lat <=90.0
                    && es._long <=180.0 && es._lat >=-90.0 && es._long >=-180.0) {
                return true;
            }
            return false;
        }
        catch(Throwable e) {
            //e.printStackTrace();
            return false;
        }
        finally {
            if(head!=null) {
                head.close();
            }
        }
    }

    /**
     * Read in the components from the file name.  This function may also serve the purpose of verifying
     * the name of the ESP file.  The file name MUST NOT include the path.
     * @param filename the file name
     * @return true if success
     */
    private boolean processFileName(String filename) {
        SegmentedLine segline = new SegmentedLine(filename, ".", SegmentedLine.MODE_ALLOW_EMPTY_SEGS);

//JB @ 13th July 07: no need for segments length check

        //Make sure the number of segments is acceptable.
        //if (segline.getNumberOfSegments() != NUMBER_OF_FILENAME_SEGMENTS)
        //    return false;
        //
        //The temporary string.
        String temp;

        //Get the segment id.
        temp = segline.getASegment(0);
        if ((temp.length() > 8) || (temp.length() <= 0))
            return false;
        _segmentID = temp;

        //Get the time series id.
        temp = segline.getASegment(1);
        if ((temp.length() > 8) || (temp.length() <= 0))
            return false;
        _timeSeriesID = temp;

        //Get the data type.
        temp = segline.getASegment(2);
        if ((temp.length() > 4) || (temp.length() <= 0))
            return false;
        _dataType = temp;

        //Check the time step.
        temp = segline.getASegment(3);
        if ((temp.length() > 2) || (temp.length() <= 0))
            return false;

        //Get the time series type extension.
        temp = segline.getASegment(4);
        if (temp.length() <= 0)
            return false;
        _timeSeriesTypeExtension = temp;

        return true;
    }

    /**
     * read in the header portion of the file.
     */
    private void readInHeader(HBinaryInputStream datafile) throws IOException {
        int i;

        //Read in the parameters one at a time.  All numbers are written as FLOATS, so they must be cast to ints.
        _formatver = datafile.readFloatSwap();                      //0   <-- float position!
        _fsegid    = HString.readBinaryString(datafile, 8);         //1,2 <-- float position!
        _ftsid     = HString.readBinaryString(datafile, 8);         //3,4 <-- float position!
        _ftype     = HString.readBinaryString(datafile, 4);         //5   <-- float position!
        _tsdt      = (int)datafile.readFloatSwap();                 //6   <-- float position!
        _simflag   = (int)datafile.readFloatSwap();                 //7   <-- etc.
        _tsunit    = HString.readBinaryString(datafile, 4);         //8
        if(_now ==null) { //JB: change allows checking of file in static context
            _now = new int[5];
        }
        for (i = 0; i < 5; i ++)                                    //9,10,11,12,13
        {
            _now[i] = (int)datafile.readFloatSwap();
        }
        _im        = (int)datafile.readFloatSwap();                 //14
        _iy        = (int)datafile.readFloatSwap();                 //15
        _idarun    = (int)datafile.readFloatSwap();                 //16
        _ldarun    = (int)datafile.readFloatSwap();                 //17
        _ijdlst    = (int)datafile.readFloatSwap();                 //18
        _ihlst     = (int)datafile.readFloatSwap();                 //19
        _ljdlst    = (int)datafile.readFloatSwap();                 //20
        _lhlst     = (int)datafile.readFloatSwap();                 //21
        _ntraces   = (int)datafile.readFloatSwap();                 //22
        _ncm       = (int)datafile.readFloatSwap();                 //23
        _nlstz     = (int)datafile.readFloatSwap();                 //24
        _noutds    = (int)datafile.readFloatSwap();                 //25
        _irec      = (int)datafile.readFloatSwap();                 //26
        _dim       = HString.readBinaryString(datafile, 4);         //27
        _tscale    = HString.readBinaryString(datafile, 4);         //28
        _segdesc   = HString.readBinaryString(datafile, 20);        //29,30,31,32,33
        _lat       = datafile.readFloatSwap();                      //34
        _long      = datafile.readFloatSwap();                      //35
        _fgrp      = HString.readBinaryString(datafile, 8);         //36,37
        _cgrp      = HString.readBinaryString(datafile, 8);         //38,39
        _rfcname   = HString.readBinaryString(datafile, 8);         //40,41
        _espfile   = HString.readBinaryString(datafile, 80);        //42-61
        _prsfstr   = HString.readBinaryString(datafile, 80);        //62-81
        _esptext   = HString.readBinaryString(datafile, 80);        //82-101
        _adjcount  = (int)datafile.readFloatSwap();                 //102

        //The header contains 124 floats.  The last value corresponds to the 103rd float, since I started
        //counting at 0.  So, I need to read 104 - 124, or 21 more floats, or 84 more bytes.
        HString.readBinaryString(datafile, 84); //103-123.

    }

    /**
     * Compute class variables using header data.
     */
    private void processHeader() {
        //NOTE: (!#!)
        //At this point, I will apply the time zone shift.  The value of _nlstz represents the
        //number of hours to add to GMT to acquire the time zone in which the data is stored.
        //Since the Julian hours are in GMT, to get the true Julian hour, I need to go from the
        //true time zone to GMT.  Hence, SUBTRACT _nlstz from this value!

        //Compute the calendar objects adjusted to GMT.  The values in the header may not be in
        //GMT!
        _fcstStart = HCalendar.computeCalendarFromJulianHour( (_ijdlst - 1) * 24 + _ihlst - _nlstz );
        _fcstEnd   = HCalendar.computeCalendarFromJulianHour( (_ljdlst - 1) * 24 + _lhlst - _nlstz );
        _runStart  = HCalendar.computeCalendarFromJulianHour( (_idarun - 1) * 24 + _ihlst - _nlstz );
        _runEnd    = HCalendar.computeCalendarFromJulianHour( (_ldarun - 1) * 24 + _lhlst - _nlstz );

        //Get the number of values to read in per 31 day chunk.  This is 31 * 24 divided by time step!
        _numberPerMonth = (int) (31.0 * 24.0/(double)_tsdt);

        //Get the number of values per trace as the difference in Julian hours between _fcstStart and _fcstEnd
        //divided by the time step, and +1 for the end points.
        int startjhr = HCalendar.computeJulianHourFromCalendar(_fcstStart, true);
        int endjhr   = HCalendar.computeJulianHourFromCalendar(_fcstEnd,   true);
        _numberPerTrace = (int)( ((double)endjhr - (double)startjhr)/(double)_tsdt );

        //Set the hs flag to true only if the type is HS.  HS type is true if
        //_simflag == 1.
        _hsFlag = false;
        if (_simflag == 1)
            _hsFlag = true;

        //Now, if the _hsFlag is true, meaning this is an HS time series, then the numbertrace
        //is actually 366 * 24/_tsdt... i.e. I know I have a year of data.
        if (_hsFlag)
            _numberPerTrace = (int)( 366.0 * 24.0/(double)_tsdt );

    }

    /**
     * Read in the data.
     */
    private void readInData(HBinaryInputStream datafile) throws IOException {
        //Messenger.writeMsg(Messenger.EVT_PROGRESS + Messenger.SEV_INFO + Messenger.ALWAYS_PRINT,
                //"Reading in the data...\n");

        //Setup the limiting Julian hours.  The fcst* hours are for any NON-HS run.
        //The HS runs use the run* hours.
        int fcststartjhr = HCalendar.computeJulianHourFromCalendar(_fcstStart, true);
        int fcstendjhr   = HCalendar.computeJulianHourFromCalendar(_fcstEnd,   true);
        int runstartjhr  = HCalendar.computeJulianHourFromCalendar(_runStart,  true);
        int runendjhr    = HCalendar.computeJulianHourFromCalendar(_runEnd,    true);

        //Some variables...
        int workingjhr;      //Keeps track of the Julian hour being examined in the file.
        int datajhr;         //Keeps track of the Julian hour as it is recorded in the DataSet.
        Calendar datadate;   //The date corresponding to datajhr, without time zone adjustment.

        int i, j, k;
        float[] values = new float[_numberPerMonth];
        double[] sample = new double[getNumberOfVariables()];
        int workingmonth;
        int ncmloop;

        //Added by Hank Herr (1/2/2002)...
        //I'm trying to see if, by switching _ncm to 12 when HS is
        //used, will the HS file be processed correctly?...
        //The answer is yes.
        ncmloop = _ncm;
        if (_hsFlag) {
            ncmloop = 12;
        }

        //Loop on the number of traces...
        for (i = 0; i < _ntraces; i ++) {
            //For this trace, setup the working Julian hour and date.  This is hour _tsdt of day 1 of the
            //initial month for the year of the FORECAST start date IN _nlstz TIMEZONE!!!  I subtract one from
            //the month since month counting starts at 0, and I subtract the _nlstz from the hour to get it
            //into GMT.  Note that if _tsdt - _nlstz is NEGATIVE, this should still work correctly (it will back
            //it up into the previous day).
            workingjhr  = HCalendar.computeJulianHour(_fcstStart.get(Calendar.YEAR), _im - 1, 1, _tsdt - _nlstz);

            //This is the Julian hour that is associated with the stored data value.  It is the same as
            //above, except the year is the initial year plus the current trace number (which starts at 0).
            //NOTE: I NEED datadate in the form of ESP TZ, because the end of the month for each block of data
            //  depends on _nlstz.  So, get datajhr without considering timezone, first...
            datajhr     = HCalendar.computeJulianHour(_iy + i, _im - 1, 1, _tsdt);
            datadate    = HCalendar.computeCalendarFromJulianHour(datajhr);

            //... and, next, with the time zone to get the Julian hour.
            datajhr     = HCalendar.computeJulianHour(_iy + i, _im - 1, 1, _tsdt - _nlstz);

            //Loop on the number of months per trace.
            for (j = 0; j < ncmloop; j ++) {
                //Get the working month -- which is equal to the data month.
                workingmonth = datadate.get(Calendar.MONTH);

                //Read in the values array.
                for (k = 0; k < values.length; k ++) {
                    values[k] = datafile.readFloatSwap();
                }

                //Process the floats one at a time.
                for (k = 0; k < values.length; k ++) {
                    //If (1) this is not an HS run and the current working jhr is within the forecast
                    //  start and end jhr OR (2) this is an HS run and the data jhr is within the
                    //  run start and end jhr, then...
                    //(Note that the fcststart time does not have corresponding data: its the start
                    //time, not the first time period with data!, so I use a '>' and not '>=' )
                    if ( ((!_hsFlag) && (workingjhr > fcststartjhr) && (workingjhr <= fcstendjhr)) ||
                            ((_hsFlag)  && (datajhr    > runstartjhr)  && (datajhr    <= runendjhr)) ) {
                        //Then we have data that we must record...

                        //This time zone shifting has actually been moved to adjust the start and end times.
                        //Hence, if they are in the correct time zone, then datajhr, which uses them, is in
                        //the correct zone.
                        sample = new double[getNumberOfVariables()];
                        sample[JULIAN_HOUR] = datajhr;
                        sample[VALUE]       = values[k];
                        addSample(sample);
                    }

                    //This if will hold true until by incrementing the hour, I reach the next month.
                    //It should, theoretically, end when I reach hour 0 of day 1 of the next month,
                    //which is also hour 24 of the last day of this month.
                    if (datadate.get(Calendar.MONTH) == workingmonth) {
                        workingjhr += _tsdt;
                        datajhr += _tsdt;
                        datadate.add(Calendar.HOUR, _tsdt);
                    }
                    //Break from the for loop -- I can get no more data from this block.
                    //But first, I want to do one last increment of the date, so as to initialize for
                    //the next time through.  The reason is because the previous if will stop at hour
                    //0 of day 1 of the next month, which in the ESP world is hour 24 of the last day
                    //of this month.  So, we just processed hour 0 with this month, and I want to move on
                    //to the next hour before breaking from this month.
                    else {
                        workingjhr += _tsdt;
                        datajhr += _tsdt;
                        datadate.add(Calendar.HOUR, _tsdt);
                        break;
                    }
                }
            }
        }
    }

    /**
     * Write out the header portion of the binary output file.
     */
    private void writeBinaryOutputHeader(DataOutputStream datafile) throws IOException {
        int i;

        //Read in the parameters one at a time.  All numbers are written as FLOATS, so they must be cast to ints.
        datafile.writeFloat(_formatver);                      //0 <-- float position!
        HString.writeBinaryString(datafile, _fsegid, 8);      //1,2
        HString.writeBinaryString(datafile, _ftsid, 8);       //3,4
        HString.writeBinaryString(datafile, _ftype, 4);       //5
        datafile.writeFloat(_tsdt);                           //6
        datafile.writeFloat(_simflag);                        //7
        HString.writeBinaryString(datafile, _tsunit, 4);      //8
        for (i = 0; i < 5; i ++)                              //9,10,11,12,13
        {
            datafile.writeFloat(_now[i]);
        }
        datafile.writeFloat(_im);                             //14
        datafile.writeFloat(_iy);                             //15
        datafile.writeFloat(_idarun);                         //16
        datafile.writeFloat(_ldarun);                         //17
        datafile.writeFloat(_ijdlst);                         //18
        datafile.writeFloat(_ihlst);                          //19
        datafile.writeFloat(_ljdlst);                         //20
        datafile.writeFloat(_lhlst);                          //21
        datafile.writeFloat(_ntraces);                        //22
        datafile.writeFloat(_ncm);                            //23
        datafile.writeFloat(_nlstz);                          //24
        datafile.writeFloat(_noutds);                         //25
        datafile.writeFloat(_irec);                           //26
        HString.writeBinaryString(datafile, _dim, 4);         //27
        HString.writeBinaryString(datafile, _tscale, 4);      //28
        HString.writeBinaryString(datafile, _segdesc, 20);    //29,30,31,32,33
        datafile.writeFloat(_lat);                            //34
        datafile.writeFloat(_long);                           //35
        HString.writeBinaryString(datafile, _fgrp, 8);        //36,37
        HString.writeBinaryString(datafile, _cgrp, 8);        //38,39
        HString.writeBinaryString(datafile, _rfcname, 8);     //40,41
        HString.writeBinaryString(datafile, _espfile, 80);    //42-61
        HString.writeBinaryString(datafile, _prsfstr, 80);    //62-81
        HString.writeBinaryString(datafile, _esptext, 80);    //82-101
        datafile.writeFloat(_adjcount);       //102

        //The header contains 124 floats.  The last value corresponds to the 103rd float, since I started
        //counting at 0.  So, I need to read 104 - 124, or 21 more floats, or 84 more bytes.
        HString.writeBinaryString(datafile, "", 84);       //103-123.
    }

    /**
     * Write out the blocks of data for the output file.
     */
    private void writeBinaryOutputData(DataOutputStream datafile) throws IOException {
        Messenger.writeMsg(Messenger.EVT_PROGRESS + Messenger.SEV_INFO + Messenger.ALWAYS_PRINT,
                "Writing out the data...\n");

        //Sort the data by Julian hour.
        Messenger.writeMsg(Messenger.EVT_PROGRESS + Messenger.SEV_INFO + Messenger.ALWAYS_PRINT,
                "Sorting by Julian hour...\n");
        sortBy(JULIAN_HOUR);

        //Setup the limiting Julian hours.
        int fcstendjhr   = HCalendar.computeJulianHourFromCalendar(_fcstEnd,   true);

        //Some variables...
        int workingjhr, datajhr;
        Calendar datadate;

        int i, j, k;
        int numvalueswritten;
        int currentmonth;

        //Reset the data set pointer.
        resetPtr();

        //Loop on the number of traces...
        for (i = 0; i < _ntraces; i ++) {
            //For this trace, setup the working Julian hour and date.  This is hour _tsdt of day 1 of the
            //initial month for the year of the FORECAST start date.
            //This is the current Julian hour within the forecasted period.
            workingjhr  = HCalendar.computeJulianHour(_fcstStart.get(Calendar.YEAR), _im - 1, 1, _tsdt);

            //This is the Julian hour that is associated with the stored data value.  It is the same as
            //above, except the year is the initial year plus the current trace number (which starts at 0).
            datajhr     = HCalendar.computeJulianHour(_iy + i, _im - 1, 1, _tsdt);
            datadate    = HCalendar.computeCalendarFromJulianHour(datajhr);

            //ELIMINATE THIS LINE OF CODE IF WE EVER TRAIN ESP TO GO FROM 0..23 AND NOT 1..24!!!
            //By subtracting a SECOND from the data date, an hour of 0 will actually correspond
            //to an our of 23:59:59.  Hence, 0 is now on the previous day, which corresponds to how ESP
            //thinks... that hour 0 is actually hour 24 of the previous day.  This will not affect how I
            //search the data set, because I'm not changing the Julian hour.
            datadate.add(Calendar.SECOND, -1);

            //Loop on the number of months per trace.
            for (j = 0; j < _ncm; j ++) {
                //Initialize the number of values written.
                numvalueswritten = 0;

                //Get the currentmonth being written -- that month assigned to workingjhr plus the current
                //conditional month.
                currentmonth = _im - 1 + j;  //0...11

                //Loop through all values of this month, increasing working hour until I'm at the first
                //value outside this month thats NOT 0 hours... because 0 is actually 24.
                for (k = 0; k < _numberPerMonth; k ++) {
                    //Check for the data only if the data month is in the current month.
                    if ((datadate.get(Calendar.MONTH) == currentmonth) &&
                            (workingjhr <= fcstendjhr)) {
                        //Is the current data set value the same as the data Julian hour?
                        if (getCurrentValue(JULIAN_HOUR,nV) == datajhr) {
                            //Write out the value
                            datafile.writeFloat((float)getCurrentValue(VALUE,nV));

                            //Goto the next value -- if this fails then it just means I have no more data to
                            //print and no increment will occur.  So, all future getCurrentValue checks will fail.
                            next();
                        }
                        //Otherwise, since I sorted the data, I know that the current hour must be LARGER than
                        //the data Julian hour...
                        else {
                            //Print out a missing value.
                            datafile.writeFloat((float)nV);
                        }

                        workingjhr += _tsdt;
                        datajhr += _tsdt;
                        datadate.add(Calendar.HOUR, _tsdt);
                    }
                    //If the data month is already set for the next month, then I'm in that area
                    //where the data value corresponds to, for example, 2/30, 2/31, 4/31, etc... days
                    //that don't exist.
                    else {
                        //Print out a missing value.
                        datafile.writeFloat((float)nV);
                    }
                }
            }
        }
    }

    /**
     * Call the writeOutHeader and writeOutData routines to put together a binary for the data contained here in.
     * @return true if success
     */
    public boolean writeBinaryOutputFile() {

        FileOutputStream fileout;
        DataOutputStream datafile;
        NumberFormat nf = NumberFormat.getInstance();
        nf.setMaximumFractionDigits(0);
        nf.setMinimumFractionDigits(0);
        nf.setMaximumIntegerDigits(2);
        nf.setMinimumIntegerDigits(2);

        String filename = computeFileName();

        //Try to open the data file for reading.
        try {
            fileout  = new FileOutputStream(filename);
            datafile = new DataOutputStream(fileout);
        } catch (IOException e1) {
            Messenger.writeMsg(Messenger.EVT_SOURCE_IO + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,
                    "Failed to open requested file for writing " + filename + "\n");
            return false;
        }

        //Try to writeout the file contents.
        try {
            writeBinaryOutputHeader(datafile);
            writeBinaryOutputData(datafile);
        } catch (IOException e) {
            Messenger.writeMsg(Messenger.EVT_SOURCE_IO + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,
                    "Failed to write out file information.\n");
            return false;
        }

        return true;
    }

/*    //Write a NetCDF format file containing the ESP data.
    boolean writeNetCDFFile(String filename)
    {

        //Define a Net CDF object...
        NetcdfFileWriteable ncfile = new NetcdfFileWriteable();
        ncfile.setName(filename);

        //Define the dimensions
        Dimension timedim = ncfile.addDimension("time", -1);

        //Define Variables.
        Dimension[] dim1 = new Dimension[1];
        dim1[0] = timedim;

        //Variable: int Julianhour(time)
        ncfile.addVariable("jhr", int.class, dim1);

        //Variable: double value(time)
        ncfile.addVariable("value", double.class, dim1);

        //Global attribution
        ncfile.addGlobalAttribute("ESP_Filename",    computeFileName());
        ncfile.addGlobalAttribute("SimFlag",         "" +_simflag);
        ncfile.addGlobalAttribute("units",           _tsunit);
        ncfile.addGlobalAttribute("TScale",          _tscale);
        ncfile.addGlobalAttribute("Seg_Description", _segdesc);
        ncfile.addGlobalAttribute("data_type",       _datatype);
        ncfile.addGlobalAttribute("Num_Traces",      "" + _ntraces);
        ncfile.addGlobalAttribute("TZ_Number",       "" + _nlstz);
        ncfile.addGlobalAttribute("Lat",             "" + _lat);
        ncfile.addGlobalAttribute("Long",            "" + _long);
        ncfile.addGlobalAttribute("FGroup",          "" + _fgrp);
        ncfile.addGlobalAttribute("CGroup",          "" + _cgrp);
        ncfile.addGlobalAttribute("Dim",             _dim);

        //Processed Stuff
        ncfile.addGlobalAttribute("FCST_Start",
            HCalendar.convertCalendarToString(_fcstStart, HCalendar.DEFAULT_DATETZ_FORMAT));
        ncfile.addGlobalAttribute("FCST_End",
            HCalendar.convertCalendarToString(_fcstEnd,   HCalendar.DEFAULT_DATETZ_FORMAT));
        ncfile.addGlobalAttribute("RUN_Start",
            HCalendar.convertCalendarToString(_runStart,  HCalendar.DEFAULT_DATETZ_FORMAT));
        ncfile.addGlobalAttribute("RUN_End",
            HCalendar.convertCalendarToString(_runEnd,    HCalendar.DEFAULT_DATETZ_FORMAT));

        //Create the file.
        try
        {
            ncfile.create();
        }
        catch (IOException e)
        {
            HMessage.printMessage(CLASSNAME, HMessage.ERROR, HMessage.ALWAYS_PRINT,
                "ESPData ERROR: Failed to create NetCDF file " + filename + ".");
            return false;
        }

        //I have the _data array containing the data, with variable 0 being jhr and variable 1
        //being value.  I just need to create ArrayAbstract classes for them.
        ArrayInt.D1    jhrA   = new ArrayInt.D1(getSampleSize());
        ArrayDouble.D1 valueA = new ArrayDouble.D1(getSampleSize());
        int i;
        for (i = 0; i < getSampleSize(); i ++)
        {
            jhrA.set( i, (int)(getValue(i, JULIAN_HOUR)) );
            valueA.set( i, (double)(getValue(i, VALUE)) );
        }

        //Write jhr data to disk.
        try
        {
            ncfile.write("jhr", jhrA);
        }
        catch (IOException e)
        {
            HMessage.printMessage(CLASSNAME, HMessage.ERROR, HMessage.ALWAYS_PRINT,
                "ESPData ERROR: Failed to write out NetCDF Julian hour data.");
            return false;
        }

        //Write value data to disk.
        try
        {
            ncfile.write("value", valueA);
        }
        catch (IOException e)
        {
            HMessage.printMessage(CLASSNAME, HMessage.ERROR, HMessage.ALWAYS_PRINT,
                "ESPData ERROR: Failed to write out NetCDF Julian hour data.");
            return false;
        }

        //Close the file... we are done!
        try
        {
            ncfile.close();
        }
        catch (IOException e)
        {
            HMessage.printMessage(CLASSNAME, HMessage.ERROR, HMessage.ALWAYS_PRINT,
                "ESPData ERROR: Unable to close the NetCDF file " + filename + ".");
            return false;
        }

        return true;

    }
 */

    //Dump the header to standard out.
    public void dumpHeader() {
        int i;

        System.out.println("========== ESP HEADER ==============================");
        System.out.println("_formatver = " + _formatver);
        System.out.println("_fsegid    = \"" + _fsegid + "\"");
        System.out.println("_ftsid     = \"" + _ftsid + "\"");
        System.out.println("_ftype     = \"" + _ftype + "\"");
        System.out.println("_tsdt      = " + _tsdt);
        System.out.println("_simflag   = " + _simflag);
        System.out.println("_tsunit    = \"" + _tsunit + "\"");
        for (i = 0; i < 5; i ++)               //9,10,11,12,13
        {
            System.out.println("_now[" + i + "]    = " + _now[i]);
        }
        System.out.println("_im        = " + _im);
        System.out.println("_iy        = " + _iy);
        System.out.println("_idarun    = " + _idarun + " (days from Jan 1, 1900)");
        System.out.println("_ldarun    = " + _ldarun + " (days from Jan 1, 1900)");
        System.out.println("_ijdlst    = " + _ijdlst + " (days from Jan 1, 1900)");
        System.out.println("_ihlst     = " + _ihlst + " (hour of day in ESP timezone)");
        System.out.println("_ljdlst    = " + _ljdlst + " (days from Jan 1, 1900)");
        System.out.println("_lhlst     = " + _lhlst + " (hour of day in ESP timezone)");
        System.out.println("_ntraces   = " + _ntraces);
        System.out.println("_ncm       = " + _ncm);
        System.out.println("_nlstz     = " + _nlstz + " (modifier to get from GMT to the ESP timezone of this data)");
        System.out.println("_noutds    = " + _noutds);
        System.out.println("_irec      = " + _irec);
        System.out.println("_dim       = \"" + _dim + "\"");
        System.out.println("_tscale    = \"" + _tscale + "\"");
        System.out.println("_segdesc   = \"" + _segdesc + "\"");
        System.out.println("_lat       = " + _lat);
        System.out.println("_long      = " + _long);
        System.out.println("_fgrp      = \"" + _fgrp + "\"");
        System.out.println("_cgrp      = \"" + _cgrp + "\"");
        System.out.println("_rfcname   = \"" + _rfcname + "\"");
        System.out.println("_espfile   = \"" + _espfile + "\"");
        System.out.println("_prsfstr   = \"" + _prsfstr + "\"");
        System.out.println("_esptext   = \"" + _esptext + "\"");
        System.out.println("_adjcount  = " + _adjcount);
        System.out.println("====================================================");
    }

    //Dump the processed header variables.
    public void dumpProcessedHeader() {
        //Dump the calendar objects.
        System.out.println("========== ESP PROCESSED HEADER ====================");
        System.out.println("_fcstStart   = " +
                HCalendar.convertCalendarToString(_fcstStart, HCalendar.DEFAULT_DATETZ_FORMAT) );
        System.out.println("_fcstEnd     = " +
                HCalendar.convertCalendarToString(_fcstEnd,   HCalendar.DEFAULT_DATETZ_FORMAT) );
        System.out.println("_runStart    = " +
                HCalendar.convertCalendarToString(_runStart,  HCalendar.DEFAULT_DATETZ_FORMAT) );
        System.out.println("_runEnd      = " +
                HCalendar.convertCalendarToString(_runEnd,    HCalendar.DEFAULT_DATETZ_FORMAT) );
        System.out.println("_numberPerMonth = " + _numberPerMonth);
        System.out.println("_numberPerTrace = " + _numberPerTrace);
        System.out.println("_hsFlag      = " + _hsFlag);
        System.out.println("====================================================");
    }

    //Dump the data
    public void dumpData() {
        System.out.println("========== ESP DATA ================================");
        System.out.println(new DenseDoubleMatrix2D(getData()));
        System.out.println("====================================================");
    }

    //Dump the data
    public void dumpDataUsingDates() {
        System.out.println("========== ESP DATA ================================");
        System.out.println(new DenseDoubleMatrix2D(getData()));
        System.out.println("====================================================");
    }

    //Compute what the file name of this file was.
    public String computeFileName() {
        //Define a two digit integer formatter.
        NumberFormat nf = NumberFormat.getInstance();
        nf.setMaximumFractionDigits(0);
        nf.setMinimumFractionDigits(0);
        nf.setMaximumIntegerDigits(2);
        nf.setMinimumIntegerDigits(2);

        return _segmentID + "." + _timeSeriesID + "." + _dataType +
                "." + nf.format(_tsdt) + "." + _timeSeriesTypeExtension;
    }

    /////////////////////////////////////////////////////////////////////////
    //TOOLS
    /////////////////////////////////////////////////////////////////////////

    //Return the value of _hsFlag.
    public boolean isHistoricalSimulation() {
        return _hsFlag;
    }

    //ESPData is strange in that to do any temporal averaging, you need to make sure to treat all
    //years independently (as different traces) instead of merging them into one long record.  So,
    //to do temporal averaging, one must first extract a subset of the data for the forecast period
    //from the data set for the year associated with the trace, do the averaging, and then do the
    //same for the next trace, combining data sets as you go along.

    //CREATE AN ACCUMULATION THING HERE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    //Daily Average...
    //The time associated with each value is the end of the day for that value... for ESP, hour 24
    //of that day, but for the rest of the known universe, hour 0 of the NEXT day!

    //CREATE A NOISE GENERATOR THING HERE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


    /////////////////////////////////////////////////////////////////////////
    //Sets and Gets
    /////////////////////////////////////////////////////////////////////////

    //
    //FOR MY OWN SANITY, I HAVE NOT CREATED ALL THE GETS THAT SHOULD BE CREATED.  If someone else
    //wants to create the 30+ gets, one for each of the parameters passed in, feel free.  Otherwise, just
    //access the attributes directly.
    //
    //THERE SHOULD BE NO REASON FOR ANYONE TO HAVE TO SET ANY OF THE VALUES.  So, you should not have
    //any of these attributes on the left hand side of an equal sign.
    //

    /**
     * Create a data set containing only data for the passed in trace number.
     * THE NUMBER STARTS AT 0!!! (i.e. 0 is the first trace).
     *
     */
    public DataSet getTrace(int number) {
        //check the number
        if ( (number < 0) || (number >= _ntraces) ) {
            return null;
        }

        //Create the bounds for an extract subset call.
        //Clone the forecast start and end dates.
        Calendar start = (Calendar)_fcstStart.clone();
        Calendar end = (Calendar)_fcstEnd.clone();
        int startjhr;
        int endjhr;

        //Set both to be the same year -- _iy + number.
        start.set(Calendar.YEAR, _iy + number);
        end.set(  Calendar.YEAR, _iy + number);
        startjhr = HCalendar.computeJulianHourFromCalendar(start, true);
        endjhr   = HCalendar.computeJulianHourFromCalendar(end, true);

        //If start is now larger than end, then the trace must wrap around years.
        if (startjhr > endjhr) {
            end.set(Calendar.YEAR, _iy + number + 1);
            endjhr   = HCalendar.computeJulianHourFromCalendar(end, true);
        }

        //Extract the subset of this data for which the Julian hour is between start and end.
        //NOTE: Since the actual first data value is the first time AFTER the _fcstStart time,
        //  I need to use strictly GREATER_THAN for the lower bound.
        return extractSubset(JULIAN_HOUR, DataSet.GREATER_THAN, startjhr, DataSet.AND,
                DataSet.LESS_THAN_OR_EQUAL_TO, endjhr,nV);
    }

    /**
     * Returns the number of traces associated with the reader.
     *
     * @return the number of traces
     */

    public int getTraceCount() {
        return _ntraces;
    }

    /**
     * Returns the forecast start date.
     *
     * @return the forecast start date
     */

    public Calendar getStartDate() {
        return _fcstStart;
    }

    /**
     * Returns the forecast end date.
     *
     * @return the forecast end date
     */

    public Calendar getEndDate() {
        return _fcstEnd;
    }

    //A test main.
    public static void main(String args[])
    {

        int[] testlevels = { Messenger.ALWAYS_PRINT, Messenger.ALWAYS_PRINT,
            Messenger.ALWAYS_PRINT, Messenger.ALWAYS_PRINT, Messenger.ALWAYS_PRINT,
            Messenger.ALWAYS_PRINT, Messenger.ALWAYS_PRINT, Messenger.ALWAYS_PRINT,
            Messenger.ALWAYS_PRINT, Messenger.ALWAYS_PRINT, Messenger.ALWAYS_PRINT};
        Messenger.initMsg(-1, null, "stdout", testlevels);

        //Process the arguments.
        if ((args.length != 1) && (args.length != 2))
        {
            System.out.println("");
            System.out.println("Invalid command line.  The execution command is:");
            System.out.println("");
            System.out.println("    <program> [h,dd,dj,a,todc] <file>");
            System.out.println("");
            System.out.println("where <file> is the file to read in and the options are:");
            System.out.println("");
            System.out.println("  h    -- only print out header");
            System.out.println("  dd   -- print out header and data using dates");
            System.out.println("  dj   -- print out header and data using Julian hours");
            System.out.println("  a    -- print out header, data using Julian hours,");
            System.out.println("          and convert to 24-hour data.");
            System.out.println("  todc -- convert ESP time series to datacard, with");
            System.out.println("          same names as <file> and \".txt\" extension.");
            System.out.println("");
            System.out.println("Conversion to 24-hour for 'a' option begins at the hour");
            System.out.println("0 of the first day of the data (in local standard time).");
            System.out.println("");
            return;
        }

        //Process the second arg, if there is one.
        int outputlevel = 1;
        boolean dateprint = false;
        boolean netcdf    = false;
        if (args.length == 2)
        {
            if (args[0].equals("h"))
                outputlevel = 0;
            if (args[0].equals("dj"))
                outputlevel = 1;
            if (args[0].equals("a"))
                outputlevel = 2;
            if (args[0].equals("dd"))
            {
                outputlevel = 1;
                dateprint = true;
            }
            if (args[0].equals("todc"))
            {
                outputlevel = 3;
            }

/*            if (args[0].equals("netcdf"))
            {
                outputlevel = (int)DataSet.MISSING;
                netcdf = true;
            }
*/
        }

        double nV = -999.0;

        try
        {
            ESPData data;
            if (args.length == 1)
                data = new ESPData(args[0],nV);
            else
                data = new ESPData(args[1],nV);

            //if the user specified netcdf as the first argument of the command.  Then, just call
            //the writeNetCDFFile method with the file name of the passed in file name plus ".netcdf".
/*            if (netcdf)
            {
                data.writeNetCDFFile("" + data.computeFileName() + ".netcdf");
                return;
            }
*/

            //Special case for conversion to datacard.
            if (outputlevel == 3)
            {
                //try
                //{

                    //System.out.println("Trying to create datacard file...");
                    //DatacardData dcdata = new DatacardData(data);
                    //dcdata.writeDatacardOutputFile("C:/Documents and Settings/brownj/EVS_02/src/evs/resources/testdata.txt");
                    //System.out.println("Completed successfully.");
                //}
                //catch (DatacardDataException e)
                //{
                //    System.out.println("Failed to create datacard file.");
                //}

                //Quit at this point.
                return;
            }

            //Dump the header if output level is at least 0.
            System.out.println("##################### File Contents Read In: ####################");
            if (outputlevel >= 0)
            {
                data.dumpHeader();
                data.dumpProcessedHeader();
            }

            //Dump out data if at least 1.
            if (outputlevel >= 1)
            {
                if (dateprint)
                    data.dumpDataUsingDates();
                else
                    data.dumpData();
            }
            System.out.println("#################################################################");
            System.out.println("");
            System.out.println("");

            //Only continue on if the 'a' option is set... i.e. if the user wants to accumulate
            //to 24-hour data.
            if (outputlevel < 2)
                return;

            //ACCUMLATE TO 24-HOURS...

            //Get the smallest Julian hour.
            double startjhr = data.getSmallest(0,nV);

            //startjhr is the Julian hours in GMT!  Now, I want to get the first hour of THAT day
            //in the timezone of the ESPData!  So, add _nsltz to get the Julian hour in
            //the time zone of the ESPData file.
            startjhr += data._nlstz;

            //If I convert the Julian hour to a calendar, now, it will have the date components
            //in local time.
            Calendar startdate = HCalendar.computeCalendarFromJulianHour((int)startjhr);

            //Set the hour to be 0 to get hour 0 of that day to be the start hour.
            startdate.add(Calendar.HOUR, -1 * startdate.get(Calendar.HOUR_OF_DAY));

            //Now, when I convert back, I'll get the Julian hour in the ESPData time zone that
            //corresponds to hour 0 of the first day.
            startjhr = HCalendar.computeJulianHourFromCalendar(startdate, true);

            //But, I need the Julian hour in GMT for it to be the same timezone as the data I have.
            startjhr -= data._nlstz;

//THSE LINES CREATE AN OUTPUT FILE
            //Output the read in data.
            //System.out.println("##################### Creating Output File ####################");
            //data._tstypeext = "TEST";
            //data.writeBinaryOutputFile();

//THESE LINES SPIT OUT ONE TRACE
            //Testing getTrace
            //DataSet atrace = data.getTrace(7);
            //System.out.println("##################### Here is trace number 7 ##################");
            //MatrixMath.printMatrix(atrace.getData());

//THESE LINES SPIT OUT THE TRACES IN A DATACARD FORMAT
            //Output stuff in Datacard Format
            //try
            //{
                //DatacardData dcdata = new DatacardData(data);

            //System.out.println("##################### File Contents Read In: ####################");
            //System.out.println("  THIS IS THE DATACARD DATASET");
            //System.out.println("#################################################################");
            //dcdata.dumpHeader();
            //dcdata.dumpProcessedHeader();
            //dcdata.dumpData();
            //System.out.println("#################################################################");

             //   dcdata.writeDatacardOutputFile(data.computeFileName() + ".txt");
            //}
            //catch (DatacardDataException e)
            //{
            //    System.out.println("FAILURE!!!!!!");
            //    System.out.println("Could not produce Datacard file!");
            //}

        }
        catch (ESPDataException e)
        {
            System.out.println("FAILURE!!!!!!");
        }

    }

}