package evs.data;

/**
 * A simple wrapper class for a data location, such as a file data location.  The data
 * location should be set on construction of an object from a concrete subclass. A data 
 * object should not contain a null data source.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

 public abstract class DataSource {

    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLES                              *
     *                                                                              *
     *******************************************************************************/

     /**
      * The data source, set on construction of a concrete subclass.
      */

      protected Object data = null;  

    /*******************************************************************************
     *                                                                             *
     *                                ACCESSOR METHODS                             *
     *                                                                             *
     ******************************************************************************/

	/**
	 * Returns true if the data source can be read, false otherwise.
	 * 
	 * @return true if the data source can be read
	 */

	public abstract boolean canRead();
	
	/**
	 * Returns true if the data source can be written, false otherwise.
	 * 
	 * @return true if the data source can be written
	 */

	public abstract boolean canWrite();
	
	/**
	 * Returns the data source.
	 * 
	 * @return the data source or null.
	 */
      
      public Object getData() {
          return data;          
      }
      
 }