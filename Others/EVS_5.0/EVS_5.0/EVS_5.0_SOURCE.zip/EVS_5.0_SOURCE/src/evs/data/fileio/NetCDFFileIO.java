package evs.data.fileio;

//EVS dependencies
import evs.data.ConditioningException;
import evs.data.ConditionArray;
import evs.data.Condition;
import evs.utilities.matrix.DoubleMatrix2D;
import evs.data.VUIdentifier;
import evs.utilities.StringUtilities;
import evs.data.fileio.netcdf.*;
import evs.analysisunits.*;

//Java util dependencies
import java.util.*;

//Java io dependencies
import java.io.*;

/**
 * Reads one or more time-series files in the NetCDF. Reads both files containing 
 * ensemble forecasts and files containing observations.
 *
 * This class coordinates the reading of several files and stores the resulting
 * data centrally. 
 * 
 * @author evs@hydrosolved.com
 * @version 1.0
 */

public class NetCDFFileIO extends FileIO implements InputDataIO {

    /*******************************************************************************
     *                                                                             *
     *                                 VARIABLES                                   *
     *                                                                             *
     ******************************************************************************/ 
    
    /**
     * Store of data (either forecasts or observations) by unique identifier in
     * a map.
     */
    
    private HashMap<VUIdentifier, Vector<DoubleMatrix2D>> store = null;

    /**
     * The data to read.
     */

    private Vector<VUIdentifier> readMe = null;

    /**
     * Store of forecast support by unique location identifier in a map.
     * 
     * Format for storage TBD
     */
    
    private HashMap<String, Object[]> support = null;    
    
    /********************************************************************************
     *                                                                              *
     *                                 CONSTRUCTOR                                  *
     *                                                                              *
     *******************************************************************************/

    /**
     * Default constructor.
     */
    
    public NetCDFFileIO() throws IOException {
        store = new HashMap();
        support = new HashMap();
    }
    
    /**
     * Reads an array of file containing ensemble forecasts or observations.  The 
     * data are then accessible via the instance methods. Throws an exception if 
     * the expected time zone does not match the time zone on file.
     *
     * @param files the files containing the ensemble forecasts
     * @param readMe the data to read
     * @param zone the time zone to check against the time zone on file
     * @param forecastData is true if the data to be passed are forecasts, false for observations
     * @param conditions an array of conditions upon which to restrict reading (may be null)
     */
    
    public NetCDFFileIO(File[] files,Vector<VUIdentifier> readMe,
    		TimeZone zone, boolean forecastData, ConditionArray conditions) throws IOException {
        this();
        if(files==null || files.length==0) {
            throw new IOException("Specify at least one NetCDF file for reading.");
        }
        this.readMe = readMe;
        Throwable ex = null;
        //Iterate through the files
        for (int i = 0; i < files.length; i++) {
            read(files[i],readMe, zone, forecastData, conditions);
        }     
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/
    
    /**
     * Returns the data for a specified identifier or throws an exception if not
     * available.
     *
     * @param id the identifier
     * @return the data
     */

    public Vector<DoubleMatrix2D> getData(VUIdentifier id) throws IOException {
        if(!store.containsKey(id)) {
            throw new IOException("No data were read for identifier '"+id+"': " +
                    "check that the identifier is valid and that the corresponding data are on file.");
        }
        return store.get(id);
    }
    
    /**
     * Returns all data in the NetCDF store indexed by unique identifier. 
     * 
     * @return all data
     */

    public HashMap<VUIdentifier, Vector<DoubleMatrix2D>> getAllData() {
        HashMap<VUIdentifier,Vector<DoubleMatrix2D>> returnMe = 
                new HashMap<VUIdentifier,Vector<DoubleMatrix2D>>();
        Iterator it = store.keySet().iterator();
        while(it.hasNext()) {
            VUIdentifier next = (VUIdentifier)it.next();
            Vector<DoubleMatrix2D> v  = new Vector<DoubleMatrix2D>();
            v.addAll(store.get(next));
            returnMe.put(next.deepCopy(),v);
        }        
        return returnMe;
    }
    
    /**
     * Returns true if the store contains data.
     *
     * @return true if the store contains data, false otherwise
     */

    public boolean containsData() {
        return store.size()>0;
    }

    /********************************************************************************
     *                                                                              *
     *                                MUTATOR METHODS                               *
     *                                                                              *
     *******************************************************************************/    
    
    /**
     * Reads a file in the NetCDF format and stores the results for the specified
     * identifiers. Throws an exception if the expected time zone does not match
     * the time zone on file.
     * 
     * @param file the file containing the data
     * @param readMe the data to read
     * @param zone the time zone to check against the time zone on file
     * @param forecastData is true if the data to be passed are forecasts, false for observations
     * @param conditions an array of conditions upon which to restrict reading (may be null)
     */
    
    public final void read(File file, Vector<VUIdentifier> readMe, TimeZone zone,
            boolean forecastData, ConditionArray conditions) throws IOException, ConditioningException {
        System.out.println("Attempting to read file '" + file + "'...");
        //Check the time zone for consistency with the expected time zone
        //Currently, assumes UTC, since the content handler always returns 
        //times in UTC.
        TimeZone checkMe = TimeZone.getTimeZone("UTC");
        if (checkMe == null || zone.getRawOffset() != checkMe.getRawOffset()) {
            String checkId = null;
            if (checkMe != null) {
                checkId = checkMe.getID();
            }
            throw new IOException("The expected time zone (" + zone.getID() + ") "
                    + "does not correspond to the time zone read from the NetCDF file ("
                    + checkId + ").");
        }
        int tot = readMe.size();
        int handledCount = 0;
        if (forecastData) {
            NetCDFEnsembleHandler handler = new NetCDFEnsembleHandler(readMe);
            SimpleEnsembleNetcdfDataReader forecasts = new SimpleEnsembleNetcdfDataReader(handler);
            for (int i = 0; i < tot; i++) {
                VUIdentifier id = readMe.get(i);
                forecasts.parse(file, id.getLocationID(), id.getVariableID());
                if (store.containsKey(id)) {
                    Vector current = store.get(id);
                    //JB@10th December 2012
                    DoubleMatrix2D handled = handler.getData(id);
                    if (conditions != null) {
                        try {
                            handled = conditions.apply(handled, Condition.FORECAST_DATA);
                            handledCount++;
                        } catch (Exception e) {
                            System.err.println("The conditions failed to select data for '" + id + "' in file '" + file + "'.");
                        }
                    } else {
                        handledCount++;
                    }
                    current.add(handled);
                } else {
                    Vector<DoubleMatrix2D> v = new Vector();
                    //JB@10th December 2012
                    DoubleMatrix2D handled = handler.getData(id);
                    if (conditions != null) {
                        try {
                            handled = conditions.apply(handled, Condition.FORECAST_DATA);
                            handledCount++;
                        } catch (Exception e) {
                            System.err.println("The conditions failed to select data for '" + id + "' in file '" + file + "'.");
                        }
                    } else {
                        handledCount++;
                    }
                    v.add(handled);
                    store.put(id, v);
                }
            }
        } else {
            NetCDFSingleValuedHandler handler = new NetCDFSingleValuedHandler(readMe);
            SimpleSingleValuedNetcdfDataReader observations = new SimpleSingleValuedNetcdfDataReader(handler);
            for (int i = 0; i < tot; i++) {
                VUIdentifier id = readMe.get(i);
                observations.parse(file, id.getLocationID(), id.getVariableID());
                if (store.containsKey(id)) {
                    Vector current = store.get(id);
                    //JB@10th December 2012
                    DoubleMatrix2D handled = handler.getData(id);
                    if (conditions != null) {
                        try {
                            handled = conditions.apply(handled, Condition.OBSERVED_DATA);
                            handledCount++;
                        } catch (Exception e) {
                            System.err.println("The conditions failed to select data for '" + id + "' in file '" + file + "'.");
                        }
                    } else {
                        handledCount++;
                    }
                    current.add(handled);
                } else {
                    Vector<DoubleMatrix2D> v = new Vector();
                    //JB@10th December 2012
                    DoubleMatrix2D handled = handler.getData(id);
                    if (conditions != null) {
                        try {
                            handled = conditions.apply(handled, Condition.OBSERVED_DATA);
                            handledCount++;
                        } catch (Exception e) {
                            System.err.println("The conditions failed to select data for '" + id + "' in file '" + file + "'.");
                        }
                    } else {
                        handledCount++;
                    }
                    v.add(handled);
                    store.put(id, v);
                }
            }
        }
        if (handledCount == 0) {
            throw new ConditioningException("The conditions failed to select data for any of the locations and variables requested in file '" + file + "'.");
        }
        System.out.println("File read successfully '" + file + "'.");
    }
    
    /**
     * Clears the data store of any data read from file.
     */
    
    public void clearDataStore() {
        if(readMe!=null) {
            readMe.clear();
        }
        store.clear();
        support.clear();
    }     
    
/*******************************************************************************
 *                                                                             *
 *                                  TEST METHOD                                *
 *                                                                             *
 ******************************************************************************/     
    
    /**
     * Test method.
     *
     * @param args the args
     */
    
    public static void main(String[] args) {
        
        try {        
            File f1 = new File("D:/NOAA_work/HEP_projects/Ensemble_verification/EVS/EVS_test_projects/Deltares_NetCDF_tests/meas/200310011200_HistSQME_clearwater.nc");
            File f2 = new File("D:/NOAA_work/HEP_projects/Ensemble_verification/EVS/EVS_test_projects/Deltares_NetCDF_tests/esp/194910011200_SQME_clearwater.nc");
  
            Vector v1 = new Vector();
            v1.add(new VUIdentifier("DWRI1I","SQME"));
            
            Vector v2 = new Vector();
            v2.add(new VUIdentifier("DWRI1I","SQME"));
            
            NetCDFFileIO pi1 = new NetCDFFileIO(new File[]{f1},v1,TimeZone.getTimeZone("UTC"),false,null);     
            NetCDFFileIO pi2 = new NetCDFFileIO(new File[]{f2},v2,TimeZone.getTimeZone("UTC"),true,null);        

            StringUtilities.setDateString("yyyyMMddHHm");
            StringUtilities.printWithDates(0,pi1.getData((VUIdentifier)v1.get(0)).get(0));
            StringUtilities.printWithDates(0,pi2.getData((VUIdentifier)v2.get(0)).get(0));
            
        } catch(Exception e) {
            e.printStackTrace();
        }        
    }   
    
}
