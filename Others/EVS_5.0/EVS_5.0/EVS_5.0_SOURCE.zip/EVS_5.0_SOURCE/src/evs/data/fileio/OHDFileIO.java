package evs.data.fileio;

//Java dependencies
import evs.data.ConditioningException;
import evs.data.ConditionArray;
import evs.data.Condition;
import java.util.*;
import java.io.*;

//EVS dependencies
import evs.utilities.matrix.*;
import evs.data.fileio.ohdfile.data.*;
import evs.data.fileio.ohdfile.misc.*;
import evs.utilities.mathutil.*;
import evs.analysisunits.*;
import evs.utilities.*;

/**
 * ALL TIME ZONES IN THIS CLASS MUST RETURN INTEGER OFFSETS IN MILLISECONDS RELATIVE
 * TO UTC FROM getRawOffset().  note: this java method reports to use values in
 * hours but actually requires milliseconds.
 * 
 * A wrapper class for reading NOAA OHD files of the Datacard type and ESP
 * binary files and returning paired forecasts and observations with corresponding
 * times in UTC milliseconds from the epoch. The time zones of the forecasts 
 * and observations may be specified or are otherwise assumed to be in UTC.
 *
 * @author evs@hydrosolved.com
 */

public class OHDFileIO extends FileIO implements InputDataIO {
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/
    
    /**
     * Reads in an array of files containing observations and returns a vector of matrices, 
     * which may be input to the pairing process.  Each matrix contains the data from 
     * one file.  The first column contains the time in hours from the epoch and the 
     * remaining columns contain the data.  The data should be in OHD Datacard format.  
     * This method assumes that the data are already in UTC time.  See below for a 
     * method with a specified time zone.
     *
     * @param input the input data
     * @param fileType the file type
     * @param conditions an array of conditions upon which to restrict reading (may be null) 
     * @param nV the null value
     * @return vector of matrices
     */
    
    public static Vector<DoubleMatrix2D> readObservations(File[] input, int fileType, 
            ConditionArray conditions, double nV) throws IOException {
        return readObservations(input,TimeZone.getTimeZone("UTC"),fileType,conditions,nV);
    }
  
    /**
     * Reads in an array of files and returns a vector of matrices, which may
     * be input to the pairing process.  See the constructor above also.  This
     * constructor allows an explicit time zone if not the default UTC.
     *
     * @param input the data
     * @param timeZone the time zone with integer offset from UTC
     * @param fileType the file type
     * @param conditions an array of conditions upon which to restrict reading (may be null)  
     * @param nV the null value
     * @return the a vector of matrices containing the data
     */
    
    public static Vector<DoubleMatrix2D> readObservations(File[] input, TimeZone timeZone, 
            int fileType, ConditionArray conditions, double nV) throws IOException {
        //Check for files to read
        if(input == null || input.length == 0) {
            throw new IOException("No files specified.");
        }
        if(fileType!=FileIO.NWSCARD && fileType!=FileIO.NWSBIN) {
            throw new IOException("Unsupported NWS file type identifier for reading observations: expected NWS CARD or CS format.");
        }
        //Check for the file types by reading the header, which removes dependence on naming
        Vector<DoubleMatrix2D> rawData = new Vector<DoubleMatrix2D>();
        //Attempt to read the files and construct the vector of matrices
        for (int i = 0; i < input.length; i++) {
            System.out.println("Attempting to read file '" + input[i] + "'...");
            switch (fileType) {
                //Simulations in HS file
                case FileIO.NWSBIN:
                    rawData.add(readESPBinaryFile(input[i], timeZone,
                            conditions, false, nV));
                    break;
                //Actual observations or any other vector representing verifying observations
                case FileIO.NWSCARD:
                    rawData.add(readDatacardObservedFile(input[i], timeZone,
                            conditions, nV));
                    break;
            }
            System.out.println("done.");
        }
        return rawData;
    }    
    
    /**
     * Reads in an array of files containing forecasts and returns a vector of matrices, 
     * which may be input to the pairing process.  Each matrix contains the data from 
     * one file.  The first column contains the time in hours from the epoch, the
     * second column contains the forecast lead time in hours and the remaining 
     * columns contain the data.  The data should be in OHD Datacard format 
     * or ESP binary format.  This method assumes that the data are already in 
     * UTC time.  See below for a constructor with an alternative time zone.
     *
     * @param input the input data
     * @param fileType the file type
     * @param conditions an array of conditions upon which to restrict reading (may be null) 
     * @param nV the null value
     * @return vector of matrices
     */
    
    public static Vector<DoubleMatrix2D> readForecasts(File[] input, int fileType, 
            ConditionArray conditions, double nV) throws IOException {
        return readForecasts(input,TimeZone.getTimeZone("UTC"),conditions,fileType,nV);
    }
  
    /**
     * Reads in an array of files and returns a vector of matrices, which may
     * be input to the pairing process.  See the constructor above also.  This
     * constructor allows an explicit time zone if not the default UTC.  If required,
     * specify a maximum forecast lead time in hours relative to the start time or null.
     *
     * @param input the data
     * @param timeZone the time zone with integer offset from UTC
     * @param conditions an array of conditions upon which to restrict reading (may be null) 
     * @param fileType the file type
     * @param nV the null value
     * @return the a vector of matrices
     */
    
    public static Vector<DoubleMatrix2D> readForecasts(File[] input, TimeZone timeZone, 
            ConditionArray conditions, int fileType, double nV) throws IOException {
        //Check for files to read
        if(input == null || input.length == 0) {
            throw new IOException("No files specified.");
        }
        if(timeZone == null) {
            throw new IOException("The time zone for reading forecasts cannot be null.");
        }
        if(!FileIO.isSupportedForecastFileType(fileType)) {
            throw new IOException("Unsupported NWS file type identifier for reading forecasts.");
        }

        //Check for the file types by reading the header, which removes dependence on naming
        Vector<DoubleMatrix2D> rawData = new Vector<DoubleMatrix2D>();
        //Attempt to read the files and construct the vector of matrices
        for (int i = 0; i < input.length; i++) {
            System.out.println("Attempting to read file '" + input[i] + "'...");
            switch (fileType) {
                case FileIO.NWSBIN:
                    rawData.add(readESPBinaryFile(input[i], timeZone, conditions, false, nV));
                    break;
                case FileIO.NWSCARD:
                    rawData.add(readDatacardForecastFile(input[i], timeZone, conditions, nV));
                    break;
            }
            System.out.println("done.");

        }
        return rawData; 
    }

    /** 
     * Processes a Datacard file of observations and returns a 2D matrix of values 
     * with their corresponding times in UTC hours from the epoch using the specified time 
     * zone to determine any offset.  
     * 
     * @param file the file to read
     * @param timeZone the time zone with integer offset from UTC
     * @param conditions an array of conditions upon which to restrict reading (may be null) 
     * @param nV the null value
     * @return the observations
     */
    
    public static DoubleMatrix2D readDatacardObservedFile(File file, TimeZone timeZone, 
            ConditionArray conditions, double nV) throws IOException {
        if(timeZone == null) {
            throw new IOException("The time zone for reading observations cannot be null.");
        }
        DatacardData d = new DatacardData(file.getAbsolutePath(),timeZone,nV);  //UTC
        double[][] data = d.getData();
        //Change the date to hours relative to UTC.
        for(int i = 0; i < data.length; i++) {
            //Next date
            Calendar next = HCalendar.computeCalendarFromJulianHour((int)data[i][0]);  //UTC
            //System.out.println(next.get(next.YEAR)+" "+(next.get(next.MONTH)+1)+" "+next.get(next.DAY_OF_MONTH)+" "+next.get(next.HOUR_OF_DAY)+" "+next.getTimeZone().getID()+" "+data[i][1]);
            long millis = next.getTimeInMillis();
            double hours = millis/(1000.0*60.0*60.0);
            data[i][0] = Mathematics.round(hours,1);
        }
        DoubleMatrix2D returnMe = new DenseDoubleMatrix2D(data);
        if (conditions != null) {
            returnMe = conditions.apply(returnMe, Condition.OBSERVED_DATA);
        }       
        return returnMe;
    }
    
    /** 
     * Processes a Datacard file and returns a 2D matrix of values with their 
     * corresponding times in UTC hours from the epoch using the specified time 
     * zone to determine any offset.  The matrix contains dates in the first 
     * column and ensemble members in the remaining columns.  Each column then 
     * corresponds to a specific ensemble trace.    If required, specify a maximum 
     * forecast lead time in hours relative to the start time or null.
     * 
     * TODO: implement the lead time constraints in the ohd file readers
     *
     * @param file the file to read
     * @param conditions an array of conditions upon which to restrict reading (may be null)
     * @param timeZone the time zone with integer offset from UTC
     * @param nV the null value
     * @return the forecasts
     */
    
    public static DoubleMatrix2D readDatacardForecastFile(File file, TimeZone timeZone, 
            ConditionArray conditions, double nV) throws IOException {
        if(timeZone == null) {
            throw new IOException("The time zone for reading forecasts cannot be null.");
        }
        DatacardData d = new DatacardData(file.getAbsolutePath(),timeZone,nV);   
        double[][] data = d.getData();
        //Change the dates in the first column so that the years match the forecast
        //year (by default they correspond to the date of the historical observed data).
        //Then change the corrected date to milliseconds relative to UTC.
        
        //A MESSY WORKAROUND IS REQUIRED HERE BECAUSE ENSEMBLE FORECASTS IN DATACARD
        //FORMAT CURRENTLY STORE NO REFERENCE TO THE ACTUAL START DATE OF THE FORECASTS
        //BEYOND THE FILE NAME.  THE DATES IN THE FILE ITSELF HAVE THE DATE CORRESPONDING 
        //TO THE HISTORICAL OBSERVATIONS FROM WHICH THE TRACES ARE GENERATED.
        //FOR THE OBSERVED DATA, THIS DOES NOT APPEAR IN THE FILE NAME, SO WHEN
        //THE FIRST CHARACTERS OF THE FILE NAME PASSES AS A DATE, USE THIS

        //Set offset 
        int startYear = 0;
        int startMonth = 0;
        int startDay = 0;
        int startHour = -999;

        try {
            startYear = new Integer(file.getName().substring(0,4));  
            startMonth = new Integer(file.getName().substring(4,6));
            startDay = new Integer(file.getName().substring(6,8));
            try {
                startHour = new Integer(file.getName().substring(8,10));
            } catch(Exception e) {
                //Do nothing, no hour available
            }
        }
        catch(Exception e) {
            throw new IllegalArgumentException("Could not determine the forecast start date from the datacard file name: " +
            		"the datacard file name must contain the forecast start date.");
        }
        
        //Forecast start time
        Calendar reference = Calendar.getInstance(timeZone);
        reference.clear();
        reference.set(startYear, startMonth-1, startDay);  //Zero-based month
        if(startHour!=-999) {
            reference.set(reference.HOUR_OF_DAY,startHour);
        }
        //reference.set(reference.HOUR_OF_DAY,0);  //Zero UTC

        //Each trace begins at the reference time above. The trace then increments
        //in a fixed number of hours until the next trace is reached, i.e. by the
        //forecast frequency. The next trace can be detected by the increment
        //between times not being equal to the forecast frequency.  At that point,
        //the next trace should be started. There are as many traces as ensemble
        //members: 1) determine the forecast frequency in hours; 2) determine
        //the forecast valid time by incrementing from the reference time; 3)
        //determine the forecast lead time by incrementing from the first lead time.

        //Check and determine the data dimensions
        int traceLength = 0;  //Length of first trace
        int traceCount = 0; //Trace number
        double frequency = data[1][0] - data[0][0];  //Frequency in hours
        for (int i = 1; i < data.length; i++) {
            if (data[i][0] - data[i - 1][0] > frequency) {
                if (traceLength == 0) {
                    traceLength = i;
                } else {  //EDITED 01/22/11 TO CHECK FOR CONSISTENCY OF TRACE LENGTH
                    int length = i - (traceCount * traceLength);
                    if (length != traceLength) {
                        throw new IOException("Two or more traces have unequal length, which is not allowed.");
                    }
                }
                traceCount++;
            }
        }
        Vector<double[]> traces = new Vector<double[]>();
        //Read the traces
        int pos = 1;
        double[] dt = new double[traceLength];
        dt[0] = data[0][1]; //Add very first index to the first trace and loop the rest, checking increment
        for (int i = 1; i < data.length; i++) {
            //ith data point is the start of the next trace
            if (data[i][0] - data[i - 1][0] > frequency) {
                traces.add(dt);  //Add the last trace
                dt = new double[traceLength];  //Create space for new trace
                dt[0] = data[i][1]; //Add ith point
                pos = 1;  //Reset index
            } //Fill current trace
            else {
                dt[pos] = data[i][1];
                pos++;
            }
        }
        //Add the last trace, which had been filled but not added
        traces.add(dt);

        //To be transposed
        int trCount = traces.size();
        double[][] returnMe = new double[trCount + 2][traceLength];
        for (int i = 0; i < trCount; i++) {
            //Dates and lead times
            if (i == 0) {
                for (int j = 0; j < traceLength; j++) {
                    //Roll the date by the frequency
                    reference.add(reference.HOUR, (int) frequency);
                    long millis = reference.getTimeInMillis();
                    double hours = millis / (1000.0 * 60.0 * 60.0);
                    returnMe[0][j] = Mathematics.round(hours, 1);
                    returnMe[1][j] = ((j + 1) * frequency);
                }
            }
            Arrays.fill(returnMe[i + 2], nV);
            double[] t = traces.get(i);
            System.arraycopy(t, 0, returnMe[i + 2], 0, t.length);
        }
        //Create and transpose the matrix
        DoubleMatrix2D returnMeFinal = new DenseDoubleMatrix2D(returnMe);
        returnMeFinal = returnMeFinal.transpose();
        if (conditions != null) {
            returnMeFinal = conditions.apply(returnMeFinal, Condition.FORECAST_DATA);
        }
        return returnMeFinal;

//        //Correct the dates
//        int useYear = startYear;
//        int lastMonth = -999;
//        for(int i = 0; i < data.length; i++) {
//            //Next date
//            Calendar next = HCalendar.computeCalendarFromJulianHour((int)data[i][0]);  //UTC
//            //Compute offset in milliseconds (automatically UTC) from reference time and add to start date
//
//
//            int month = next.get(next.MONTH);
//            int dayMonth = next.get(next.DAY_OF_MONTH);
//            int hourDay = next.get(next.HOUR_OF_DAY);
//
//            //Does the file cover a transition between years?
//            if(month != lastMonth) {  //Retain current year until month change
//                if(lastMonth == next.DECEMBER && month == next.JANUARY) {  //Establish nature of change
//                    useYear = startYear+1;
//                }
//                else {
//                    useYear = startYear;
//                }
//            }
//            lastMonth = month;
//            next.set(next.YEAR,useYear);
//
//            long millis = next.getTimeInMillis();
//            double hours = millis/(1000.0*60.0*60.0);
//            data[i][0] = Mathematics.round(hours,1);
//        }
//
//        //Determine the number of rows for subsetting
//        int count = 0;
//        int start = (int)data[0][0];
//        for(int i = 1; i < data.length; i++) {
//            if(data[i][0]==start) {
//                count = i; break;
//            }
//        }
//        if(count == 0) {
//            throw new IllegalArgumentException("Could not determine the number of ensemble members in "+file+"." +
//                    "This problem is most likely related to an incorrect incrementation of forecast years.");
//        }
//        //Check for divisibility by the total
//        if(data.length%count>0.0) {
//            throw new IOException("Unexpected inequality of trace dates in the input file '"+file+"': "+data.length+" records does not divide exactly by "+count+" ensemble members found in first data block.");
//        }
//        Vector<double[]> cols = new Vector<double[]>();
//
//        for(int i = 0; i < data.length; i+=count) {
//            //Add the times
//            if(i == 0) {
//                double[] times = new double[count];
//                double[] leads = new double[count];
//                double period = data[1][0] - data[0][0];  //Period in hours
//                for(int j = 0; j < count; j++) {
//                    times[j] = data[j][0];
//                    leads[j] = (j+1) * period;
//                }
//                cols.add(times);
//                cols.add(leads);
//            }
//            double[] next = new double[count];
//            for(int j = 0; j < count; j++) {
//                next[j] = data[i+j][1];
//            }
//            cols.add(next);
//        }
//
//        //Create the double matrix and transpose
//        Vector<double[]> newData = new Vector<double[]>();
//        int tot = cols.size();
//        for(int i = 0; i < tot; i++) {
//            double[] trace = cols.get(i);
//            if(!isNull(trace,AnalysisUnit.getNullValue())) {
//                //Fill with null values
//                double[] next = new double[count];
//                Arrays.fill(next,AnalysisUnit.getNullValue());
//                System.arraycopy(trace,0,next,0,trace.length);
//                newData.add(next);
//            }
//        }
//        //Create the result
//        int size = newData.size();
//        double[][] result = new double[size][count];
//        for(int i = 0; i < size; i++){
//            result[i] = newData.get(i);
//        }
//
//        //Create and transpose the matrix
//        DoubleMatrix2D mat = new DenseDoubleMatrix2D(result);
//        mat = mat.transpose();
//        return mat;
    }    
    
    /** 
     * Processes an ESP binary file and returns a 2D matrix of values with their 
     * corresponding times in UTC hours from the epoch using the specified time 
     * zone to determine any offset.  The matrix contains dates in the first
     * column, forecast lead times in the second column (if applicable) and ensemble 
     * members in the remaining columns (or a vector of, for example, streamflow 
     * simulations). For ensemble forecasts, each column corresponds to a specific 
     * ensemble trace. If required, specify a maximum forecast lead time in hours 
     * relative to the start time or null.
     *
     * TODO: implement the lead time constraints in the ohd file readers
     *
     * @param file the file to read
     * @param timeZone the time zone with integer offset from UTC
     * @param conditions an array of conditions upon which to restrict reading (may be null)
     * @param skipZoneCheck is true to avoid checking the input time zone for 
     * equality with the time zone offset from UTC on file, which otherwise throws 
     * an exception if incompatible
     * @param nV the null value
     * @return the forecasts
     */
    
    public static DoubleMatrix2D readESPBinaryFile(File file, TimeZone timeZone,ConditionArray conditions,
            boolean skipZoneCheck, double nV) throws IOException {
        if(timeZone == null) {
            throw new IOException("The time zone for reading forecasts cannot be null.");
        }
        ESPData d = new ESPData(file.getCanonicalPath(),nV);
        int count = d.getTraceCount();

        //Simulation
        if(d.isHistoricalSimulation()) {
            double[][] sims = d.getData();
            for (int i = 0; i < sims.length; i++) {
                //Next date
                Calendar next = HCalendar.computeCalendarFromJulianHour((int) sims[i][0]);  //Time in UTC
                long millis = next.getTimeInMillis();
                double hours = millis / (1000.0 * 60.0 * 60.0);
                if (!skipZoneCheck) {
                    //Throw an exception if the input offset does not match the offset specified in the file
                    int hourCheck = (int) (timeZone.getOffset(millis) / (1000.0 * 60.0 * 60.0));
                    //d._nlstz=-16;
                    if (hourCheck != d._nlstz) {
                        throw new IOException("The specified time zone " + timeZone.getID() + " does not "
                                + "match the time zone recorded in the file data source: [" + hourCheck + "," + d._nlstz + "].");
                    }
                }
                sims[i][0]=Mathematics.round(hours, 1);
            }
            return new DenseDoubleMatrix2D(sims);
        }
        //Forecast
        else {
            Vector<double[]> traces = new Vector<double[]>();
            int max = 0;
            for (int i = 0; i < count; i++) {
                //Add the dates
                if (i == 0) {
                    double[] next = d.getTrace(i).getVariable(0);  //Times in Julian hours
                    int length = next.length;
                    traces.add(next);
                    //Add the lead times
                    double[] leads = new double[length];
                    double period = d._tsdt;
                    if (next.length > 1) {
                        period = next[1] - next[0]; //Forecast resolution in hours
                    }
                    for (int j = 0; j < length; j++) {
                        leads[j] = (j + 1) * period;
                    }
                    traces.add(leads);
                }
                double[] da = d.getTrace(i).getVariable(1);
                if (da.length > max) {
                    max = da.length;
                }
                if (!isAllMissing(da,nV)) {
                    traces.add(da);
                }
            }

            double[][] newData = new double[traces.size()][max];
            for (int i = 0; i < newData.length; i++) {
                //Fill with null values
                Arrays.fill(newData[i],nV);
                double[] trace = traces.get(i);
                System.arraycopy(trace, 0, newData[i], 0, trace.length);
            }

            //Create and transpose the matrix
            DoubleMatrix2D returnMe = new DenseDoubleMatrix2D(newData);
            returnMe = returnMe.transpose();

            //Change the dates in the first column so that the years match the forecast
            //year (by default they correspond to the date of the historical observed data).
            //Then change the corrected date to milliseconds relative to UTC.
            int length = returnMe.getRowCount();

            //Difference in years between start year and actual recorded year
            int h1 = d.getStartDate().get(Calendar.YEAR);
            int h2 = HCalendar.computeCalendarFromJulianHour((int) returnMe.get(0, 0)).get(Calendar.YEAR);
            int diff = h1 - h2;

            for (int i = 0; i < length; i++) {
                //Next date
                Calendar next = HCalendar.computeCalendarFromJulianHour((int) returnMe.get(i, 0));  //Time in UTC
                next.set(next.YEAR, next.get(next.YEAR) + diff);
                long millis = next.getTimeInMillis();
                double hours = millis / (1000.0 * 60.0 * 60.0);
                
                if (!skipZoneCheck) {
                    //Throw an exception if the input offset does not match the offset specified in the file
                    int hourCheck = (int) (timeZone.getOffset(millis) / (1000.0 * 60.0 * 60.0));
                    //d._nlstz=-16;
                    if (hourCheck != d._nlstz) {
                        throw new IOException("The specified time zone " + timeZone.getID() + " does not match "
                                + "the time zone recorded in the file data source: [" + hourCheck + "," + d._nlstz + "].");
                    }
                }
                returnMe.set(i, 0, Mathematics.round(hours, 1));
            }
            //Create and transpose the matrix
            if (conditions != null) {
                if(d.isHistoricalSimulation()) {
                    returnMe = conditions.apply(returnMe, Condition.OBSERVED_DATA);
                } else {
                    returnMe = conditions.apply(returnMe, Condition.FORECAST_DATA);
                }
            }
            return returnMe;       
        }
    }
    
    /**
     * Reads an NWS card file containing forecasts and writes the output in ASCII.
     *
     * @param inFile the input file
     * @param outFile the output file
     * @param sep the separator string
     * @param conditions an array of conditions upon which to restrict reading (may be null)
     * @param nV the null value
     */
    
    public static void readCardForecastsWriteASCII(File inFile, File outFile, String sep, 
            ConditionArray conditions, double nV) throws IOException {
        DoubleMatrix2D data = readForecasts(new File[]{inFile},FileIO.NWSCARD,conditions,nV).get(0);
        System.out.println("Writing output file '"+outFile+"'...");
        ASCIIFileIO.write(data,outFile,sep,StringUtilities.DEFAULT_DATE_FORMAT);
        System.out.println("done.");
    }    
    
    /**
     * Reads an NWS CS binary forecast file and writes the output in ASCII.
     *
     * @param inFile the input file
     * @param outFile the output file
     * @param sep the separator string
     * @param conditions an array of conditions upon which to restrict reading (may be null)
     * @param nV the null value
     */
    
    public static void readBinaryForecastsWriteASCII(File inFile, File outFile, String sep, 
            ConditionArray conditions, double nV) throws IOException {
        //Document read progress, as this does not use one of the generic read methods
        System.out.println("Attempting to read file '"+inFile+"'...");
        DoubleMatrix2D data = readESPBinaryFile(inFile,TimeZone.getTimeZone("UTC"),conditions,true,nV); //Skip zone check
        System.out.println("done.");
        System.out.println("Writing output file '"+outFile+"'...");
        ASCIIFileIO.write(data,outFile,sep,StringUtilities.DEFAULT_DATE_FORMAT);
        System.out.println("done.");
    }    
    
    /**
     * Reads an NWS card file containing observations and writes the output in ASCII.
     *
     * @param inFile the input file
     * @param outFile the output file
     * @param sep the separator string\
     * @param conditions an array of conditions upon which to restrict reading (may be null)
     * @param nV the null value
     */
    
    public static void readCardObservationsWriteASCII(File inFile, File outFile, String sep, 
            ConditionArray conditions, double nV) throws IOException {
        DoubleMatrix2D data = readObservations(new File[]{inFile},FileIO.NWSCARD,conditions,nV).get(0);
        System.out.println("Writing output file '"+outFile+"'...");
        ASCIIFileIO.write(data,outFile,sep,StringUtilities.DEFAULT_DATE_FORMAT);
        System.out.println("done.");
    }     

    /********************************************************************************
     *                                                                              *
     *                                 TEST METHODS                                 *
     *                                                                              *
     *******************************************************************************/    

    /**
     * Main method to test the class.
     *
     * @param args the command line args
     */
    
    public static void main(String[] args) {

        try {
            File f = new File("D:/Data/HEFSv1/ABRFC/Precipitation/Forecasts/GEFS/p_gefs_base/BLKO2/19850101BLKO2.MAP06");
            DoubleMatrix2D v = readDatacardForecastFile(f,TimeZone.getTimeZone("GMT-12"),null,-999.0);
            StringUtilities.setDateString("yyyyMMddHH");
            StringUtilities.printWithDates(0,v);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
//
//        try {
//            File f = new File("G:/Data/HEPEX/CNRFC/NFDC1/NFDC1.NFDC1.QME.24.OBS");
//            DoubleMatrix2D v = readDatacardObservedFile(f,TimeZone.getTimeZone("GMT-12"));
//            StringUtilities.setDateString("yyyy.MM.dd'+'HH");
//            StringUtilities.printWithDates(0,v);
//        }
//        catch(Exception e) {
//            e.printStackTrace();
//        }

//        try {
//            File obsF = new File("G:/Data/HEPEX/CNRFC/NFDC1/NFDC1.NFDC1.QME.24.OBS");
//            DoubleMatrix2D obs = readDatacardObservedFile(obsF,TimeZone.getTimeZone("GMT-12"));
//            File forcF = new File("G:/Data/HEPEX/CNRFC/NFDC1/RCLIM/nfdc1_rclim/NFDC1.NFDC1.SQME.24.VS.19790101");
//            DoubleMatrix2D forc = readESPBinaryFile(forcF,TimeZone.getTimeZone("GMT-12"),0.0,1000.0);
//
//            Vector<DoubleMatrix2D> ff = new Vector<DoubleMatrix2D>();
//            ff.add(forc);
//            Vector<DoubleMatrix2D> oo = new Vector<DoubleMatrix2D>();
//            oo.add(obs);
//
//            evs.data.PairedData p = new evs.data.PairedData(ff,oo,true);
//
//            StringUtilities.printWithDates(0,p.getPairs());
//
//            PairedFileIO.write(new File("C:/Documents and Settings/James Brown/Desktop/test.xml"),p,true,5,new evs.data.IOState());
//
//        }
//        catch(Exception e) {
//            e.printStackTrace();
//        }


//        try {
//            File f = new File("C:/Documents and Settings/brownj/Desktop/AndrewP/20090915.farmville.MAP06");
//            DoubleMatrix2D v = readDatacardForecastFile(f,TimeZone.getTimeZone("GMT-6"),0.0,120.0);
//            StringUtilities.setDateString("yyyy.MM.dd'+'HH");
//            StringUtilities.printWithDates(0,v);
//        }
//        catch(Exception e) {
//            e.printStackTrace();
//        }


//        //File f = new File("C:/Documents and Settings/brownj/Desktop/EVS_NEW_08_07/TEST_DATA/CHTM7PQ.CHTM7.QINE.06.VS.20030306");
//        //File f2 = new File("C:/Documents and Settings/brownj/EVS_02/src/evs/resources/testdata/CHTM7PQ.CHTM7.QINE.06.OBS");
//        File f = new File("C:/Documents and Settings/brownj/Desktop/Satish/QUAO2PQ.QUAO2.QINE.06.VS.19990629.010200.CS");
//        
//        
//        try {
//            TimeZone tz = TimeZone.getTimeZone("UTC");
//            tz.setRawOffset(-12*60*60*1000);
//            System.out.println(readESPBinaryFile(f,tz,1000000.0));
//            //ESPData d = new ESPData(f.getAbsolutePath());
//            
//            
//            //Vector<DoubleMatrix2D> v = readForecasts(new File[]{f},TimeZone.getTimeZone("CST"));
//            //Vector<DoubleMatrix2D> v2 = readObservations(new File[]{f2},TimeZone.getTimeZone("CST"));
//            
//            //System.out.println(v.get(0));
//            //System.out.println(v2.get(0));
//            //System.out.println(getPairedData(v,v2));
//        }
//        catch(Exception e) {
//            e.printStackTrace();
//        }
    }
    
    
}
