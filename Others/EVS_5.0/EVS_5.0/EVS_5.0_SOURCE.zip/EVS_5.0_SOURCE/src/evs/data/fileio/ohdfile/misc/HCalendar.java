package evs.data.fileio.ohdfile.misc;

import evs.analysisunits.AnalysisUnit;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.Date;
import java.text.NumberFormat;

/**
 *
 *  A class that contains static functions for use with Calendar and Date objects.  Primarily,
 *  it is used to convert Calendar objects to and from Julian hours.  Also, it can be used to
 *  translate String objects of specific format to and from Calendar objects.  It is important
 *  to realize that all of these methods assume GMT by default, and that Julian hours, herein, is
 *  assumed to be computed relative to hour 0 or January 1, 1900.<br>
 * <br>
 *  Lastly, the computeCalendarRelativeToPresent method takes a String of the form,<br>
 * <br>
 *      <+ or -> [number units] [number units] ...<br>
 * <br>
 *  where the spaces are purely optional.  The number MUST be an integer and the
 *  units must be one of the Strings in the VALID_UNITS constant array below.  If
 *  the passed in adjustment factor String is valid, the returned Calendar will be
 *  set to the current time adjusted appropriately by the adjustment String.  If it
 *  is not valid, the null will be returned.<br>
 * <br>
 * <br>
 *
 * @author hank
 */

public abstract class HCalendar {
    public static final String CLASSNAME = "HCalendar";
    
    //Character codes for the date format string.  See the default strings, below, for examples.
    public static final String CENTURY  = "CC";
    public static final String YEAR     = "YY";
    public static final String MONTH    = "MM";
    public static final String DAY      = "DD";
    public static final String HOUR     = "hh";
    public static final String MINUTE   = "mm";
    public static final String SECOND   = "ss";
    public static final String TIMEZONE = "TZC";
    public static final String MONTH_AB = "MON";
    
    //The constant adjustment for intl time (i.e. what we add to GMT to get intl.)
    public static final int    INTL_TZ_ADJ = -12;
    
    //Default date formats.
    public static final String DEFAULT_DATE_FORMAT      = "CCYY-MM-DD hh:mm:ss";
    public static final String DEFAULT_DATETZ_FORMAT    = "CCYY-MM-DD hh:mm:ss TZC";
    public static final String DEFAULT_ESPADP_FORMAT    = "MMDDCCYY:hh";
    public static final String DEFAULT_SHORTTERM_FORMAT = "MMDDYYHH";
    public static final String DEFAULT_DATEONLY_FORMAT  = "CCYY-MM-DD";
    public static final String DEFAULT_DHMTZ_FORMAT     = "YYMMDDhh TZC";
    
    //Y2K year fix.
    public static final int    Y2K_UB_WINDOW = 10;  //The upperbound on the Y2K window -- i.e. if two digit year is
    //larger than this, we ASSUME its 1900.  Otherwise, use 2000.
    
    //Adjustment factor strings and indices.
    public static final String[] VALID_UNITS = {"weeks","week", "wk","days","day","dy","hours","hour","hr"};
    public static final int[] UNITS_TO_HOURS = {7*24,   7*24,   7*24,24,    24,    24,  1,      1,     1};
    public static final String[] BASIC_UNITS = {"weeks", "days", "hours"};  //Stripped down list above. Each
    //corresponds to a VALID_UNIT entry.
    
    public static final long MILLIS_IN_HR = 60*60*1000;
    public static final long MILLIS_IN_MIN = 60*1000;
    
    /**
     * Compute a Calendar object based on the Julian hours (since 1/1/1900 GMT, Midnight)
     * The calendar returned is in GMT, and it **assumes** the jhour was computed in GMT!
     *
     * @param jhour
     * @return the calendar
     */
    public static Calendar computeCalendarFromJulianHour(int jhour) {
        //Get a calendar instance, using the GMT time zone.
        TimeZone tz = TimeZone.getTimeZone("UTC");
        Calendar date = Calendar.getInstance();
        date.clear();
        date.setTimeZone(tz);
        //Set the calendar instance to Jan 1, 1900, 0 hours.
        date.set(1900, date.JANUARY, 1, 0, 0, 0);
        //Add the hours
        date.add(Calendar.HOUR, jhour);
        return date;
    }
    
    /**
     * Compute a Calendar from the passed in date object.  It assumes the date
     * is in GMT.
     *
     * @param d
     * @return the calendar
     */
    public static Calendar computeCalendarFromDate(Date d) {
        //Get a calendar instance, using the GMT time zone.
        TimeZone tz = TimeZone.getTimeZone("UTC");
        Calendar date = Calendar.getInstance(tz);
        date.setTime(d);
        return date;
    }
    
    /**
     * Compute a Calendar from the passed in number of milliseconds.  It assumes
     * the long was calculated from a date that was in GMT.
     *
     * @param millis
     * @return the calendar
     */
    public static Calendar computeCalendarFromMilliseconds(long millis) {
        return HCalendar.computeCalendarFromDate(new Date(millis));
    }
    
    /**
     * This routine can be used to convert a String of known format into a date,
     * based on the system date.  The passed in String is simply an adjustment
     * factor string, used to adjust relative to the current time:<br>
     * <br>
     *     <+ or -> quantity unit quantity unit ...<br>
     * <br>
     * where <+ or -> is either '+' or '-', and:<br>
     * <br>
     *     - quantity is a positive number,<br>
     *     - unit is either weeks, days, or hrs (not case sensitive)<br>
     * <br>
     * Every quantity and unit may be separated by spaces, tabs, or newlines.<br>
     * <br>
     * The returned Calendar is the current system time adjusted by the adjustment
     * factor given in the String.  A return of null implies and invalid factor
     * string.<br>
     *
     * @param factor
     * @param nV the null value
     * @return the calendar
     */
    public static Calendar computeCalendarRelativeToPresent(String factor, double nV) {
        //Grab the system time.
        TimeZone tz = TimeZone.getTimeZone("GMT");
        Calendar date = Calendar.getInstance(tz);
        
        //First, trim the factor to remove any leading spaces.  If the String
        //has 0-length, then just return the system date.
        factor = factor.trim();
        if (factor.length() == 0)
            return date;
        
        //Grab the first character, which must be a + or -.  If it is not, return
        //a null Calendar.  Remove the char from factor and trim it again to remove
        //any spaces from the beginning.
        char sign = factor.charAt(0);
        int mult = 0;
        if (sign == '+')
            mult = 1;
        else if (sign == '-')
            mult = -1;
        else
            return null;
        factor = factor.substring(1, factor.length()).trim();
        
        //Now, I need to do a while loop until the factor string has 0-length.
        int index, i;
        String num, unit;
        int number, unitinhrs = 1;
        while (factor.length() > 0) {
            //Find the first non-numeric character in the remaining portion of the
            //factor and pickup the number that precedes it.  If there is no number,
            //then return null (error).  Remove the number from the string.
            index = HString.findFirstNonNumericCharacter(factor,nV);
            if (index < 0)
                return null;
            num = factor.substring(0, index).trim();
            factor = factor.substring(index, factor.length()).trim();
            
            //Pickup the first numeric character in the remaining string and
            //do as above.  The string that is picked up is the <unit>.
            index = HString.findFirstNumericCharacter(factor,nV);
            if (index < 0)
                index = factor.length();
            unit = factor.substring(0, index).trim();
            factor = factor.substring(index, factor.length()).trim();
            
            //Add the number * units to the picked up date.
            if (HCalendar.computeAdjustFactor(num, unit, nV) == nV)
                return null; //an error!!!
            date.add(Calendar.HOUR, mult*HCalendar.computeAdjustFactor(num, unit,nV));
        }
        
        //Return the Calendar object.
        return date;
    }
    
    
    
    /**
     * Returns the time interval implied by the passed in string, after converting it
     * to hours.  It uses the computeAdjustFactor static method in this class.
     * @param str  String specifying the units.
     * @param nV the null value
     * @return The number of hours.
     */
    public static int computeIntervalValueInHours(String str, double nV) {
        //Call computeAdjustFactor, depending on if there is
        //any non-numeric character in the string.
        int temp;
        int pos = HString.findFirstNonNumericCharacter(str,nV);
        if ((pos < 0) || (pos >= str.length())) {
            temp = HCalendar.computeAdjustFactor(str, "",nV);
        } else {
            temp = HCalendar.computeAdjustFactor(
                    str.substring(0, pos), str.substring(pos, str.length()), nV);
        }
        
        return temp;
    }
    
    
    /**
     * This routine can be used to calculate a number of hours given by an adjustment
     * factor specified by the passed in num and unit.  The num and unit are:<br>
     * <br>
     *     num is a positive number,<br>
     *     unit>is a VALID_UNIT above.<br>
     * <br>
     * If unit is either null or "", then it is assumed to be "hours".
     * The returned Integer is the number of hours corresponding to the adjustment
     * factor.<br>
     *
     * <br>
     * @param num
     * @param unit
     * @param nV the null value
     * @return the number of hours
     */
    public static int computeAdjustFactor(String num, String unit, double nV) {
        int number, unitinhrs = 1;
        int i;
        
        //Convert the number to an integer.  If it fails, return null.
        try {
            number = Integer.parseInt(num.trim());
        } catch (NumberFormatException nfe) {
            return (int)nV;
        }
        
        //If the unit is null or empty, then return number.  Default
        //unit is hours.
        if ((unit == null) || (unit.length() == 0)) {
            return number;
        }
        
        //Check the <unit> for either "weeks", "days", or "hours".  If it is
        //none of those, return null.  Otherwise, record either 7*24, 24, or
        //1 as the base unit (these number are the number of hours to add for
        //that unit).
        for (i = 0; i < HCalendar.VALID_UNITS.length; i ++) {
            if (unit.trim().equalsIgnoreCase(HCalendar.VALID_UNITS[i])) {
                unitinhrs = HCalendar.UNITS_TO_HOURS[i];
                break;
            }
        }
        if (i == HCalendar.VALID_UNITS.length)
            return (int)nV;
        
        return number*unitinhrs;
    }
    
    /**
     * Given a Calendar, compute the Julian hour.  If gmt is true, then we are to ASSUME the calendar
     * is already in GMT, regardless of its true TimeZone.  This allows callers to play around with a
     * Calendar without actually paying any attention to its TimeZone, but just let it be GMT.
     *
     * @param date
     * @param gmt
     * @return Julian hour
     */
    public static int computeJulianHourFromCalendar(Calendar date, boolean gmt) {
        Calendar working = (Calendar)date.clone();
        
        //Get the offset from GMT in milliseconds, if necessary.
        //This is the number of milliseconds to add to date
        //to convert it **FROM** GMT to this time zone -- usually <0 in the USA.
        long gmtoffset;
        if (!gmt) {
            TimeZone tz = working.getTimeZone();
            gmtoffset = tz.getRawOffset();
            if (tz.inDaylightTime(working.getTime())) {
                //Is there a better way to do this?
                gmtoffset += 3600000;
            }
        } else {
            gmtoffset = 0;
        }
        
        //Add the gmtoffset to the date -- the -1 is there because the offset is to convert GMT to this
        //timezone, but we need to do it the other way around.
        working.add(Calendar.MILLISECOND, (int)(-1*gmtoffset) );
        
        //Get the month, day, year, and hour.
        int year = working.get(Calendar.YEAR);
        int dayofyear = working.get(Calendar.DAY_OF_YEAR);  //do I need +1 ?
        int hour = working.get(Calendar.HOUR_OF_DAY);
        
        //Compute the Julian hour -- from code written by David Street
        return HCalendar.computeJulianHour(year, dayofyear, hour);
    }
    
    /**
     * Compute the Julian hour based on the year (1900...), dayofyear (1..366), and hourofday (0..23)
     * This is all in GMT (Z-time).
     *
     * @param year
     * @param dayofyear
     * @param hourofday
     * @return Julian hour
     */
    public static int computeJulianHour(int year, int dayofyear, int hourofday) {
        int yearsfrom1900, daysfrom1900, yjj; //I don't know what yjj is doing
        int Julianhr;
        
        daysfrom1900 = 0;
        if ( year >= 1900 ) {
            yearsfrom1900 = year - 1900;
            if ( yearsfrom1900 > 0 ) {
                daysfrom1900 = 365*yearsfrom1900 + (yearsfrom1900-1)/4;
                if ( yearsfrom1900 > 200 ) {
                    yjj = yearsfrom1900 - 101;
                    daysfrom1900 = daysfrom1900 - yjj/100 + yjj/400;
                }
            }
            daysfrom1900 += dayofyear - 1;  //-1 because day of year starts at 1, not 0.
        }
        
        return 24*daysfrom1900 + hourofday;
    }
    
    /**
     * Compute the Julian hour based on the year, month (0..11), day (1..31), and hour of day (0..23).
     * <br>NOTE: MONTH STARTS AT 0!!!<br>
     *
     * @param year
     * @param month
     * @param dayofmonth
     * @param hourofday
     * @return Julian hour
     */
    public static int computeJulianHour(int year, int month, int dayofmonth, int hourofday) {
        int dayofyear;
        
        //I'm going to compute the day of the year, and pass that into the computeJulianHour
        //that uses the day of the year.

        //Month is stored as 0..11, so this should work.
        dayofyear = month*30;

        //Account for months that are not 30 days...
        if (month >= 1)  //if the month is Feb or later, add 1 for day 31 of Jan
            dayofyear ++;
        if (month >= 2)  //if the month is Mar or later...
        {
            //If its a leap year, then subtract 1 from dayofyear.
            if (isLeapYear(year))
                dayofyear --;

            //Otherwise, subtract 2
            else
                dayofyear -= 2;
        }
        if (month >= 3)  //if the month is Apr or later, add 1 for day 31 of Mar
            dayofyear ++;
        if (month >= 5)  //if the month is June or later, add 1 for day 31 of May
            dayofyear ++;
        if (month >= 7)  //if the month is Aug or later, add 1 for day 31 of July
            dayofyear ++;
        if (month >= 8)  //if the month is Sept or later, add 1 for day 31 of Aug
            dayofyear ++;
        if (month >= 10)  //if the month is Nov or later, add 1 for day 31 of Oct
            dayofyear ++;

        dayofyear += dayofmonth;

        return computeJulianHour(year, dayofyear, hourofday);

    }
    
    /**
     * Convert a calendar to a String based on the format string.  For valid strings within format,
     * see convertStringToCalendar below.
     *
     * @param date
     * @param format
     * @return string calendar
     */
    public static String convertCalendarToString(Calendar date, String format) {
        //Setup the number formatter for 2 digits, exactly.
        NumberFormat nf = NumberFormat.getInstance();
        nf.setMaximumFractionDigits(0);
        nf.setMinimumFractionDigits(0);
        nf.setMaximumIntegerDigits(2);
        nf.setMinimumIntegerDigits(2);
        
        //One piece at a time, construct the return string using format.
        String working = format;
        
        working = HString.replaceSubstring(working, CENTURY,  nf.format((int)(date.get(Calendar.YEAR)/100)) );
        working = HString.replaceSubstring(working, YEAR,     nf.format((int)(date.get(Calendar.YEAR)%100)) );
        working = HString.replaceSubstring(working, MONTH,    nf.format((date.get(Calendar.MONTH) + 1)) );
        working = HString.replaceSubstring(working, DAY,      nf.format(date.get(Calendar.DAY_OF_MONTH)) );
        working = HString.replaceSubstring(working, HOUR,     nf.format(date.get(Calendar.HOUR_OF_DAY)) );
        working = HString.replaceSubstring(working, MINUTE,   nf.format(date.get(Calendar.MINUTE)) );
        working = HString.replaceSubstring(working, SECOND,   nf.format(date.get(Calendar.SECOND)) );
        working = HString.replaceSubstring(working, TIMEZONE, date.getTimeZone().getID() );
        working = HString.replaceSubstring(working, MONTH_AB, computeThreeLetterMonth(date.get(Calendar.MONTH)));
        
        return working;
    }
    
    
    /**
     * Convert a string to a calendar based on a format.  The format is a sequence
     * of characters describing the format of the date string.  For example:
     * CCYY-MM-DD is a valid string, saying the first 4 digits is the year,
     * 6,7 is the month and 9,10 is the day.  Valid character codes:
     * CC, YY, MM, DD, hh, mm, ss, TZC.<br>
     * Default time zone is GMT!!!  Unless the string passed in overrides it.<br>
     * Returns null if one of the numbers in the date string is not valid.
     *
     * @param str
     * @param format
     * @return string calendar
     */
    public static Calendar convertStringToCalendar(String str, String format) {
        int index;
        int century = 0, year = 0, month = 0, day = 0, hour = 0, minute = 0, second = 0;
        TimeZone tz = TimeZone.getTimeZone("GMT");
        String temp;
        
        //Get the current system calendar date.
        Calendar date = Calendar.getInstance();
        
        //One big try based on string to int converting:
        try {
            //Look for each of the components.
            century = parseDateComponent(str, format, CENTURY, (int)(date.get(Calendar.YEAR)/100));
            year    = parseDateComponent(str, format, YEAR,    (int)(date.get(Calendar.YEAR)%100));
            month   = parseDateComponent(str, format, MONTH,   date.get(Calendar.MONTH) + 1);
            day     = parseDateComponent(str, format, DAY,     date.get(Calendar.DAY_OF_MONTH));
            hour    = parseDateComponent(str, format, HOUR,    date.get(Calendar.HOUR_OF_DAY));
            minute  = parseDateComponent(str, format, MINUTE,  date.get(Calendar.MINUTE));
            second  = parseDateComponent(str, format, SECOND,  date.get(Calendar.SECOND));
            
            //This handles the time zone ID -- the trim will remove any blanks from around the
            //time zone, so that a two character time zone ID can be accepted.
            tz      = TimeZone.getTimeZone(HString.getKeyFromString(str, format, TIMEZONE).trim());
        }
        //Catch an number format errors
        catch (NumberFormatException e) {
            return null;
        }
        
        //NOTE: Calendar has built in mechanisms to handle months, days, hours, etc being out of range.
        //  Namely, it loops the current date appropriately... i.e. month 1 day 33 becomes month 2 day 2.
        
        //Change the date to match the date specified by string and return it.
        date.setTimeZone(tz);
        date.set(Calendar.YEAR,         century*100 + year);
        date.set(Calendar.MONTH,        month - 1);
        date.set(Calendar.DAY_OF_MONTH, day);
        date.set(Calendar.HOUR_OF_DAY,  hour);
        date.set(Calendar.MINUTE,       minute);
        date.set(Calendar.SECOND,       second);
        date.set(Calendar.MILLISECOND,  0);
        
        //DEBUG PRINT:
        //System.out.println(">>>>DATE: " + date.get(Calendar.YEAR) + "-" + (date.get(Calendar.MONTH) + 1) + "-" +
        //date.get(Calendar.DAY_OF_MONTH) + " " + date.get(Calendar.HOUR_OF_DAY) + ":" + date.get(Calendar.MINUTE) +
        //":" + date.get(Calendar.SECOND));
        
        return date;
    }
    
    /**
     * A wrapper function on HString.getKeyFromString which uses it for extracting a date
     * component.  If the component specified in the key is not present in the format,
     * then this function will return defaultreturn.  Otherwise, it return the characters
     * from str in the same position as the key is in format, parsed into a integer.<br>
     * THIS FUNCTION MAY RESULT IN A NumberFormatException!!!<br>
     *
     * @param str
     * @param format
     * @param key
     * @param defaultreturn
     * @return date component
     * @throws NumberFormatException
     */
    public static int parseDateComponent(String str, String format, String key, int defaultreturn)
    throws NumberFormatException {
        String temp;
        
        temp = HString.getKeyFromString(str, format, key);
        
        if (temp.length() == 0) {
            return defaultreturn;
        }
        
        return Integer.parseInt(temp);
    }
    
    /**
     * Compute the number of days in a month, given the year and the month (0..11).
     *
     * @param year
     * @param month
     * @return days in month
     */
    public static int computeDaysInMonth(int year, int month) {
        int tmon = month + 1;
        if ( (tmon == 9) || (tmon == 4) || (tmon == 6) || (tmon == 11) )
            return 30;
        if (tmon == 2) {
            if (isLeapYear(year))
                return 29;
            else
                return 28;
        }
        return 31;
    }
    
    /**
     * Is the passed in year a leap year?
     *
     * @param year
     * @return true if a leap year
     */
    public static boolean isLeapYear(int year) {
        //If the year is divisible by 400, then it is a leap year
        if ((year % 400) == 0) {
            return true;
        }
        
        //If the year is divisble by 4, but NOT by 100, then it is a leap year
        if ( (((year - 1900)%4) == 0) && (((year - 1900)%100) != 0) ) {
            return true;
        }
        
        //Its not a leap year...
        return false;
    }
    
    /**
     * Return the four digit year corresponding to the data card 2 digit year.  This uses the windowing
     * technique employed by NWSRFS (a window around current year, specified by Y2K_UB_WINDOW)!
     *
     * @param year2d
     * @param todayyear
     * @return four digit year
     */
    public static int processTwoDigitYear(int year2d, int todayyear) {
        //Compare 2000 + year2d with _todayyear + Y2K_UB_WINDOW.  If it is larger than it, then
        //I assume 1900.  Otherwise, assume 2000.
        if ( (2000 + year2d) > (todayyear + Y2K_UB_WINDOW) )
            return 1900 + year2d;
        
        return 2000 + year2d;
    }
    
    
    /**
     * This returns a Calendar representing the first of the month for the passed
     * in calendar.
     *
     * @param cal
     * @return the calendar
     */
    public static Calendar computeFirstOfMonth(Calendar cal) {
        cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), 1, 0, 0, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal;
    }
    
    /**
     * This returns a Calendar representing the last of the month for the passed
     * in calendar.
     *
     * @param cal
     * @return the calendar
     */
    public static Calendar computeLastOfMonth(Calendar cal) {
        cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                HCalendar.computeDaysInMonth(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)),
                23, 59, 59);
        cal.set(Calendar.MILLISECOND, 999);
        return cal;
    }
    
    
    /**
     * Returns the three letter abbreviation corresponding to a month.  The passed in month is 0..11.
     */
    public static String computeThreeLetterMonth(int monthFromZero) {
        if (monthFromZero == 0)
            return "Jan";
        if (monthFromZero == 1)
            return "Feb";
        if (monthFromZero == 2)
            return "Mar";
        if (monthFromZero == 3)
            return "Apr";
        if (monthFromZero == 4)
            return "May";
        if (monthFromZero == 5)
            return "Jun";
        if (monthFromZero == 6)
            return "Jul";
        if (monthFromZero == 7)
            return "Aug";
        if (monthFromZero == 8)
            return "Sep";
        if (monthFromZero == 9)
            return "Oct";
        if (monthFromZero == 10)
            return "Nov";
        if (monthFromZero == 12)
            return "Dec";
        return null;
    }
    
    
    
    
    //The main...
    public static void main(String args[]) {
        
        //  ==== THIS IS FOR RETURNING THE DATE CORRESPONDING TO A JULIAN DAY/HOUR ====
        if (args.length != 2) {
            System.out.println("");
            System.out.println("Incorrect usage.  The usage is: ");
            System.out.println("    jrun HCalendar <h, d, r> <Julian number>");
            System.out.println("where h or d tells it to take the number as a Julian <h>our or <d>ay.");
            System.out.println("and r says that the String following specifies a date relative to today");
            System.out.println("that you wish to have translated.");
            System.out.println("");
            return;
        }
        double nV = -999.0;
        int jhr;
        Calendar date;
        if (args[0].equals("h")) {
            System.out.println("  <user specified a Julian hour>  ");
            jhr = Integer.parseInt(args[1]);
            date = HCalendar.computeCalendarFromJulianHour(jhr);
        } else if (args[0].equals("d")) {
            System.out.println("  <user specified a Julian day>  ");
            jhr = 24 * (Integer.parseInt(args[1]) - 1);
            date = HCalendar.computeCalendarFromJulianHour(jhr);
        } else {
            System.out.println("  <user specified a relative date using \"" + args[1] + "\">  ");
            date = HCalendar.computeCalendarRelativeToPresent(args[1],nV);
            if (date == null) {
                System.out.println("The relative string is invalid!!!");
                return;
            }
        }
        
        System.out.println("THE DATE IS:");
        System.out.println("" + HCalendar.convertCalendarToString(date,
                HCalendar.DEFAULT_DATETZ_FORMAT));
        System.out.println("");
    }
    
}
