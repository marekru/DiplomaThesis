package evs.data.fileio;

//Java util dependencies
import evs.analysisunits.scale.MeasurementUnitsChangeLibrary;
import evs.utilities.EVSConstants;
import evs.data.InvalidUnitException;
import java.util.Vector;
import java.util.TimeZone;
import java.util.SimpleTimeZone;

//java xml dependencies
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;

//EVS dependencies
import evs.utilities.StaticClassInitializer;

/**
 * Class comprising static methods for reading in global units, such as time
 * systems and measurement units. All units should be stored in US English (e.g.
 * METER not METRE). All methods should check that units have been read and
 * should read otherwise by calling the constructor.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */
public final class GlobalUnitsReader implements StaticClassInitializer {

    /**
     * *****************************************************************************
     *                                                                             *
     * INSTANCE VARIABLES * *
 *****************************************************************************
     */
    /**
     * Supported time units.
     */
    private static Vector<String> timeUnits = null;
    /**
     * Names of supported continuous measurement units.
     */
    private static Vector<String> continuousNumericalUnits = null;
    /**
     * Names of supported time systems.
     */
    private static Vector<TimeZone> timeSystems = null;
    /**
     * Default null value.
     */
    private static double defaultNull = -999.0;

    /**
     * *****************************************************************************
     *                                                                             *
     * CONSTRUCTOR * *
 *****************************************************************************
     */
    /**
     * Constructor that initializes the units.
     */
    public GlobalUnitsReader() {
        initialize();
    }

    /**
     * Initializes.
     */
    public static GlobalUnitsReader start() {
        return new GlobalUnitsReader();
    }

    /**
     * *****************************************************************************
     *                                                                             *
     * ACCESSOR METHODS * *
 *****************************************************************************
     */
    /**
     * Returns the supported time systems.
     *
     * @return the supported time systems
     */
    public static Vector<TimeZone> getTimeSystems() throws UnitInitializationException {
        start();
        if (timeSystems == null) {
            throw new UnitInitializationException("Cannot reference any time systems:"
                    + " the time systems have not been read from file.");
        }
        return timeSystems;
    }

    /**
     * Returns a TimeZone object for a named time system or throws an exception
     * if the system is not recognized.
     *
     * @param system the named time system
     * @return the named time system
     */
    public static TimeZone getTimeSystem(String system) throws IllegalArgumentException, UnitInitializationException {
        start();
        if (timeSystems == null) {
            throw new UnitInitializationException("Cannot reference any time systems:"
                    + " the time systems have not been read from file.");
        }
        isSupportedTimeSystem(system, true);
        return timeSystems.get(indexOfTimeSystem(system));
    }

    /**
     * Returns a deep copy of the supported attribute units for a continuous
     * numerical attribute.
     *
     * @return the supported attribute units
     */
    public static Vector getContinuousNumericalUnits() throws UnitInitializationException {
        start();
        if (continuousNumericalUnits == null) {
            throw new UnitInitializationException("Cannot reference any continuous numerical units:"
                    + " the units have not been read from file.");
        }
        Vector<String> v = new Vector<String>();
        for (String s : continuousNumericalUnits) {
            v.add(s);
        }
        return v;
    }

    /**
     * Returns a deep copy of the supported time units.
     *
     * @return the supported units
     */
    public static Vector getTimeUnits() throws UnitInitializationException {
        start();
        if (timeUnits == null) {
            throw new UnitInitializationException("Cannot reference any time units:"
                    + " the units have not been read from file.");
        }
        Vector<String> v = new Vector<String>();
        for (String s : timeUnits) {
            v.add(s);
        }
        return v;
    }

    /**
     * Returns true if the attribute unit is supported. Returns false or throws
     * an exception depending on the value of the throwEx flag.
     *
     * @param unit the attribute unit
     * @param throwEx is true to throw an exception
     * @return true if the unit is supported.
     */
    public static boolean isSupportedContinuousNumericalUnit(String unit, boolean throwEx) throws InvalidUnitException, UnitInitializationException {
        start();
        if (getContinuousNumericalUnits().contains(toUSEnglish(unit))) {
            return true;
        } else {
            if (throwEx) {
                throw new InvalidUnitException("Error: unsupported attribute unit '" + unit + "'. See the user manual for supported types.");
            }
            return false;
        }
    }

    /**
     * Returns the unit in US English from British English.
     *
     * @param unit the attribute unit
     * @return the unit in US English
     */
    public static String toUSEnglish(String unit) {
        if (unit == null) {
            throw new IllegalArgumentException("Cannot convert a null attribute unit from British English to US English.");
        }
        String up = unit.toUpperCase() + "";
        if (up.contains("METRE")) {
            up = up.replace("METRE", "METER");
        }
        return up;
    }

    /**
     * Checks if the time system is supported. Returns false or throws an
     * exception depending on the value of the throwEx flag.
     *
     * @param system the time system
     * @param throwEx is true to throw an exception
     * @return true if the time system is supported.
     */
    public static boolean isSupportedTimeSystem(String system, boolean throwEx) throws InvalidUnitException, UnitInitializationException {
        start();
        if (timeSystems == null) {
            throw new UnitInitializationException("Cannot reference any time systems:"
                    + " the time systems have not been read from file.");
        }
        if (indexOfTimeSystem(system) > -1) {
            return true;
        } else {
            if (throwEx) {
                throw new InvalidUnitException("Error: unsupported time system '" + system + "'. See the user manual for supported types.");
            }
            return false;
        }
    }

    /**
     * Checks if the temporal unit is supported. Returns false or throws an
     * exception depending on the value of the throwEx flag.
     *
     * @param unit the temporal unit of aggregation
     * @param throwEx is true to throw an exception
     * @return true if the temporal unit is supported.
     */
    public static boolean isSupportedTimeUnit(String unit, boolean throwEx) throws InvalidUnitException, UnitInitializationException {
        start();
        if (timeUnits == null) {
            throw new UnitInitializationException("Cannot reference any time units:"
                    + " the units have not been read from file.");
        }
        if (timeUnits.contains(unit.toUpperCase())) {
            return true;
        } else {
            if (throwEx) {
                throw new InvalidUnitException("Error: unsupported temporal unit '" + unit + "'. See the user manual for supported types.");
            }
            return false;
        }
    }

    /**
     * Returns the default null value.
     *
     * @return the default null value
     */
    public static double getDefaultNullValue() {
        return defaultNull;
    }

    /**
     * Returns the millisecond conversion factor for the specified input units.
     * Approximations are used for months (30 days), years (365 days), decades
     * (3650 days) and centuries (36500 days). The options for units are:
     * 
     * MILLISECOND
     * SECOND
     * MINUTE
     * HOUR
     * DAY
     * WEEK
     * MONTH
     * YEAR
     * DECADE
     * CENTURY
     *
     * @param units the time units
     * @return the millisecond conversion factor
     */
    public static double getMilliConversionFactor(String units) {
        double coefficient = 1.0;
        if (units.equalsIgnoreCase("MILLISECOND")) {
            coefficient = 1.0;
        } else if (units.equalsIgnoreCase("SECOND")) {
            coefficient = 1000.0;
        } else if (units.equalsIgnoreCase("MINUTE")) {
            coefficient = 1000.0 * 60.0;
        } else if (units.equalsIgnoreCase("HOUR")) {
            coefficient = 1000.0 * 60.0 * 60.0;
        } else if (units.equalsIgnoreCase("DAY")) {
            coefficient = 1000.0 * 60.0 * 60.0 * 24.0;
        } else if (units.equalsIgnoreCase("WEEK")) {
            coefficient = 1000.0 * 60.0 * 60.0 * 24.0 * 7.0;
        } else if (units.equalsIgnoreCase("MONTH")) {
            coefficient = 1000.0 * 60.0 * 60.0 * 24.0 * 30.0;  //Approximation
        } else if (units.equalsIgnoreCase("YEAR")) {
            coefficient = 1000.0 * 60.0 * 60.0 * 24.0 * 365.0;  //Approximation
        } else if (units.equalsIgnoreCase("DECADE")) {
            coefficient = 1000.0 * 60.0 * 60.0 * 24.0 * 365.0 * 10.0;  //Approximation
        } else if (units.equalsIgnoreCase("CENTURY")) {
            coefficient = 1000.0 * 60.0 * 60.0 * 24.0 * 365.0 * 100.0;  //Approximation
        }
        return coefficient;
    }

    /**
     * Attempts to read in all units from file if they have not been read.
     */
    public void initialize() {
        //Must read from file
        if (continuousNumericalUnits == null) {
            java.io.InputStream conn = null;
            try {
                //Set the supported time units
                timeUnits = new Vector<String>();
                timeUnits.add("YEAR");
                timeUnits.add("MONTH");
                timeUnits.add("WEEK");
                timeUnits.add("DAY");
                timeUnits.add("HOUR");
                timeUnits.add("MINUTE");
                timeUnits.add("SECOND");
                java.net.URL url = GlobalUnitsReader.class.getResource(EVSConstants.PARAMETER_FILE_DIR + "time_systems.xml");
                conn = url.openStream();
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = factory.newDocumentBuilder();
                Document d = builder.parse(conn);
                NodeList nlist = d.getElementsByTagName("system");

                //Read the supported time systems
                Vector<TimeZone> v3 = new Vector<TimeZone>();
                int len = nlist.getLength();
                for (int i = 0; i < len; i++) {
                    Node next = nlist.item(i);
                    NodeList children = next.getChildNodes();
                    int len2 = children.getLength();
                    String systemID = "";
                    int offset = 0;
                    for (int j = 0; j < len2; j++) {
                        Node current = children.item(j);
                        String name = current.getNodeName();
                        //Name of the verification unit
                        if (name.equals("name")) {
                            systemID = current.getFirstChild().getNodeValue();
                        } //Offset from GMT time in integer units 
                        else if (name.equals("gmt_offset")) {
                            offset = new Integer(current.getFirstChild().getNodeValue());
                        }
                    }
                    final String temp = systemID;
                    offset = offset * 3600000;  //Millis
                    SimpleTimeZone zone = new SimpleTimeZone(offset, temp) {

                        /**
                         * Overrides superclass method to return the zone name
                         *
                         * @return the zone name
                         */
                        public String toString() {
                            return temp;
                        }
                    };
                    v3.add(zone);
                }
                timeSystems = v3;

                //Read the continuous numerical units
                url = GlobalUnitsReader.class.getResource(EVSConstants.PARAMETER_FILE_DIR + "measurement_units.xml");
                conn = url.openStream();
                d = builder.parse(conn);
                nlist = d.getElementsByTagName("attribute");
                Vector<String> v = new Vector<String>();
                len = nlist.getLength();
                for (int p = 0; p < len; p++) {
                    NamedNodeMap map = ((Node) nlist.item(p)).getAttributes();
                    Node n = ((Node) map.item(0));
                    if (n.getNodeValue().equals("NAME")) {
                        String unit = ((Node) map.item(1)).getNodeValue().toUpperCase();
                        unit = toUSEnglish(unit);
                        v.add(unit);
                    }
                }
                continuousNumericalUnits = v;
            } catch (Throwable e) {
                e.printStackTrace();
            } finally {
                if (conn != null) {
                    try {
                        conn.close();
                    } catch (Throwable e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    /**
     * Returns the index of the named time system or -1 if the time system is
     * not found
     *
     * @param system the named time system
     * @return the system index
     */
    private static int indexOfTimeSystem(String system) {
        start();
        int length = timeSystems.size();
        for (int i = 0; i < length; i++) {
            if (timeSystems.get(i).toString().equalsIgnoreCase(system)) {
                return i;
            }
        }
        return -1;
    }
}