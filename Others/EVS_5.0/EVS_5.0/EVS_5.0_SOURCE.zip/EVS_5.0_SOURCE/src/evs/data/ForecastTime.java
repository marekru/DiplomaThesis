package evs.data;

/**
 * Base class for representing valid time or issue time and, optionally, lead time.
 *
 * @author evs@hydrosolved.com
 */

public class ForecastTime implements Comparable {

    /**
     * Forecast time.
     */

    private double forecastTime;

    /**
     * Forecast lead time.
     */

    private double leadTime;

    /**
     * Is true if the class was instantiated with a forecast time only, and not a
     * forecast lead time.
     */
    
    private boolean forecastOnly = false;

    /**
     * Construct with a forecast time only.
     *
     * @param forecastTime the forecast time
     */
    public ForecastTime(double forecastTime) {
        this.forecastTime = forecastTime;
        forecastOnly=true;
    }

    /**
     * Construct with a forecast time and lead time.
     *
     * @param forecastTime the forecast time
     * @param leadTime the forecast lead time
     */
    public ForecastTime(double forecastTime, double leadTime) {
        this.forecastTime = forecastTime;
        this.leadTime = leadTime;
    }

    /**
     * Throws an exception if the input object is not a ForecastTime. Otherwise,
     * returns an integer with respect to the input ForecastTime:
     *
     * If the lead time is available:
     *
     * The forecast time is equal, lead time is less: negative
     * The forecast time is equal, lead time is more: positive
     * The forecast time is less: negative
     * The forecast time is more: positive
     * The forecast time and lead time are equal: 0
     *
     * Otherwise:
     *
     * The forecast time is less: negative
     * The forecast time is more: positive
     * The forecast times are equal: 0
     *
     * @param input the input object to compare
     * @return an integer: less than if the input is less, 0 if equal, positive otherwise
     */

    public int compareTo(Object input) {
        ForecastTime in = (ForecastTime) input;
        if(forecastOnly) {
           if (in.forecastTime < forecastTime) {
                return 1;
            } else if (in.forecastTime > forecastTime) {
                return -1;
            } else {
               return 0;
            } 
        }
        else {
            if (in.forecastTime < forecastTime) {
                return 1;
            } else if (in.forecastTime > forecastTime) {
                return -1;
            } else {
                if (in.leadTime < leadTime) {
                    return 1;
                } else if (in.leadTime > leadTime) {
                    return -1;
                }
                return 0;
            }
        }
    }

    /**
     * For hashing.
     *
     * @return  hashcode
     */
    public int hashCode() {
        return toString().hashCode();
    }

    /**
     * String representation.
     *
     * @return a string representation.
     */

    public String toString() {
        if(forecastOnly) {
            return forecastTime+"";
        }
        return forecastTime + "_" + leadTime;
    }

    /**
     * Returns true if the input class is ForecastTime and has the same forecast time
     * and lead time as the current object
     *
     * @param o the object to test for equality
     * @return true if the objects are equal
     */

    public boolean equals(Object o) {
        if(o==null || o.getClass()!=getClass()) {
            return false;
        }
        ForecastTime v  = ((ForecastTime)o);
        return v.forecastTime==forecastTime && v.leadTime==leadTime;
    }

    /**
     * Test method.
     *
     * @param args command line arguments
     */

    public static void main(String[] args) {
        ForecastTime v = new ForecastTime(12345,678910);
        ForecastTime u = new ForecastTime(12344,678910);
        System.out.println(v.equals(u));
        System.out.println(v.compareTo(u));
        System.out.println(v.hashCode()+":"+u.hashCode());
    }


}
