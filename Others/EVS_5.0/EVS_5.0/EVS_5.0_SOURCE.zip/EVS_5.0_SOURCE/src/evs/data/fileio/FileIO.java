package evs.data.fileio;

//Java util dependencies
import java.util.StringTokenizer;
import java.util.Vector;

//Java io dependencies
import java.io.BufferedReader;
import java.io.IOException;
import java.io.File;

//Java xml dependencies
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;

//EVS dependencies
import evs.utilities.EVSConstants;
import evs.utilities.mathutil.FunctionLibrary;
import evs.utilities.mathutil.Mathematics;

/**
 * Base class for file reading and writing files.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public abstract class FileIO {
    
/********************************************************************************
 *                                                                              *
 *                              INSTANCE VARIABLES                              *
 *                                                                              *
 *******************************************************************************/

    /**
     * Identifier for ASCII file type.
     */

    public static final int ASCII = 501;

    /**
     * Identifier for PI-XML file type.
     */

    public static final int PIXML = 502;

    /**
     * Identifier for NWS BINARY file type.
     */

    public static final int NWSBIN = 503;

    /**
     * Identifier for NWS CARD file type.
     */

    public static final int NWSCARD = 504;
    
    /**
     * Identifier for NetCDF file type.
     */

    public static final int NETCDF = 505;    

    /**
     * Supported forecast files with description.
     */    
    
    private static String[] suppForcFiles = null;

    /**
     * Supported observed files with description.
     */    
    
    private static String[] suppObsFiles = null;          
    
    /**
     * Supported forecast file extentions.
     */    
    
    private static String[] suppForcExt = null;
       
    /**
     * Supported observed file extentions.
     */    
    
    private static String[] suppObsExt = null; 

    /**
     * Supported forecast file descriptions.
     */    
    
    private static String[] suppForcDesc = null;
       
    /**
     * Supported observed file descriptions.
     */    
    
    private static String[] suppObsDesc = null;     
    
/*******************************************************************************
 *                                                                             *
 *                               ACCESSOR METHODS                              *
 *                                                                             *
 ******************************************************************************/     

    /**
     * Returns the extensions of supported forecast file types as a String array.  
     * Optionally, a description is returned with the file extension.
     *
     * @param describe is true to return a description
     * @return an array of supported file extensions
     */
    
    public static String[] getSupportedForecastFileTypes(boolean describe) {
        initialize();
        if(describe) {
            String[] returnMe = new String[getSuppForcFiles().length];
            System.arraycopy(getSuppForcFiles(),0,returnMe,0,returnMe.length);
            return returnMe;                   
        }
        else {
            String[] returnMe = new String[getSuppForcExt().length];
            System.arraycopy(getSuppForcExt(),0,returnMe,0,returnMe.length);
            return returnMe;         
        }
    }    
    
    /**
     * Returns the extensions of supported observed file types as a String array.  
     * Optionally, a description is returned with the file extension.
     *
     * @param describe is true to return a description
     * @return an array of supported file extensions
     */
    
    public static String[] getSupportedObservedFileTypes(boolean describe) {
        initialize();
        if(describe) {
            String[] returnMe = new String[getSuppObsFiles().length];
            System.arraycopy(getSuppObsFiles(),0,returnMe,0,returnMe.length);
            return returnMe;                   
        }
        else {
            String[] returnMe = new String[getSuppObsExt().length];
            System.arraycopy(getSuppObsExt(),0,returnMe,0,returnMe.length);
            return returnMe;         
        }
    }
    
    /**
     * Returns true if all inputs in the 1D array correspond to the missing value, 
     * false otherwise.
     * 
     * TODO: replace calls to this method with {@link evs.utilities.mathutil.FunctionLibrary#isAll(evs.utilities.mathutil.DoubleProcedure)}
     *
     * @param nV the missing value
     * @return true if all inputs are missing
     */

    public static boolean isAllMissing(double[] data, double nV) {
        for(int i = 0; i < data.length; i++) {
            if(data[i]!=nV) {
                return false;
            }
        }
        return true;
    }

    /**
     * Returns an integer file type identifier for the input string. Supported
     * file type strings are:
     *
     * 1. ASCII
     * 2. PI-XML
     * 3. NetCDF
     * 4. NWS-CARD
     * 5. NWS-CS-BINARY
     * 
     * Throws an exception if the input string is not recognized.
     *
     * @param type the file type string
     * @return the identifier for the input string
     */
    
    public static int getFileTypeIDForString(String type) throws IllegalArgumentException {
        if(type==null) {
            throw new IllegalArgumentException("Specify a non-null input string to determine "
                    + "the file type identifier.");
        } else if (type.equals("ASCII")) {
            return ASCII;
        } else if (type.equals("PI-XML")) {
            return PIXML;
        } else if (type.equals("NetCDF")) {
            return NETCDF;
        } else if (type.equals("NWS-CARD")) {
            return NWSCARD;
        } else if (type.equals("NWS-BINARY")||type.equals("NWS-CS-BINARY")) {
            return NWSBIN;
        } else {
            throw new IllegalArgumentException("Encountered unrecognized file "
                    + "type string '" + type + "' when attempting to determine "
                    + "file type identifier.");
        }
    }
    
    /**
     * Returns a string file type for the input identifier. Supported identifiers
     * are:
     * 
     * 1. {#ASCII} 
     * 2. {#PIXML} 
     * 3. {#NETCDF} 
     * 4. {#NWSCARD} 
     * 5. {#NWSBIN} 
     * 
     * Throws an exception if the input identifier is not one of these.
     * 
     * @param id the file type identifier
     * @return the string representation of the identifier
     */
    
    public static String getFileTypeStringForID(int id) throws IllegalArgumentException {
        switch(id) {
            case ASCII: return "ASCII";
            case PIXML: return "PI-XML";
            case NETCDF: return "NetCDF";
            case NWSCARD: return "NWS-CARD";
            case NWSBIN: return "NWS-BINARY";
            default: throw new IllegalArgumentException("Unrecognized file type identifier "
                    + "encountered when attempting to determine file type string.");
        }
    }    
    
    /**
     * Returns the supported file type strings for observations.
     * 
     * @return the supported file type strings for observations
     */

    public static String[] getObservedFileTypeStrings() {
        return new String[] {"ASCII","PI-XML","NetCDF","NWS-CARD","NWS-BINARY"};
    }

    /**
     * Returns the supported file type strings for forecasts.
     *
     * @return the supported file type strings for forecasts
     */

    public static String[] getForecastFileTypeStrings() {
        return new String[] {"ASCII","PI-XML","NetCDF","NWS-CARD","NWS-BINARY"};
    }

    /**
     * Returns true if the input identifier is a supported file type for
     * observations, false otherwise.
     *
     * @param id the identifier
     * @return true if the input file type identifier is supported for observations
     */

    public static boolean isSupportedObservedFileType(int id) {
        switch(id) {
            case ASCII: return true;
            case PIXML: return true;
            case NETCDF: return true;
            case NWSCARD: return true;
            case NWSBIN: return true;
            default: return false;
        }
    }

    /**
     * Returns true if the input identifier is a supported file type for
     * forecasts, false otherwise.
     *
     * @param id the identifier
     * @return true if the input file type identifier is supported for forecasts
     */

    public static boolean isSupportedForecastFileType(int id) {
        switch(id) {
            case ASCII: return true;
            case PIXML: return true;
            case NWSCARD: return true;
            case NETCDF: return true;
            case NWSBIN: return true;
            default: return false;
        }
    }

/*******************************************************************************
 *                                                                             *
 *                              PROTECTED METHODS                              *
 *                                                                             *
 ******************************************************************************/

    /**
     * Attempts to return an array of double values from a string of double values
     * separated with one of ", \t\n\r\f".  
     *
     * @param doubles the double array string
     * @return a double array
     */
    
    protected static double[] getDoubleArray(String doubles) {
        StringTokenizer t = new StringTokenizer(doubles,", \t\n\r\f",false);
        Vector<Double> dou = new Vector<Double>();
        while(t.hasMoreTokens()) {
            dou.add(new Double(t.nextToken()));
        }
        int ln = dou.size();
        double[] thresholds = new double[ln];
        for (int m = 0; m < ln; m++) {
            thresholds[m] = dou.get(m);
        }
        return thresholds;
    }

    /**
     * Attempts to return an array of boolean values from a string of boolean values
     * separated with one of ", \t\n\r\f".
     *
     * @param booleans the boolean array string
     * @return a boolean array
     */

    protected static boolean[] getBooleanArray(String booleans) {
        StringTokenizer t = new StringTokenizer(booleans,", \t\n\r\f",false);
        Vector<Boolean> bou = new Vector<Boolean>();
        while(t.hasMoreTokens()) {
            bou.add(Boolean.valueOf(t.nextToken()));
        }
        int ln = bou.size();
        boolean[] returnMe = new boolean[ln];
        for (int m = 0; m < ln; m++) {
            returnMe[m] = bou.get(m);
        }
        return returnMe;
    }

    /**
     * Attempts to return an array of string values from a string of individual
     * string values separated by the specified separator.  Returns the null identifier
     * if the input string corresponds to the null string (case insensitive "null").
     *
     * @param strings the input string
     * @return a String array
     */

    protected static String[] getStringArray(String strings, String sep) {
        StringTokenizer t = new StringTokenizer(strings,sep,false);
        Vector<String> b = new Vector<String>();
        while(t.hasMoreTokens()) {
            String s = t.nextToken();
            if(s.equalsIgnoreCase("null")) {
                s = null;
            }
            b.add(s);
        }
        return b.toArray(new String[b.size()]);
    }
    
    /**
     * Returns a string of doubles separated by commas from the input array.  Writes
     * with a specified decimal precision.
     *
     * @param input the input array 
     * @param precision the number of decimal places to write
     */
    
    protected static String getDoubleArrayString(double[] input, int precision) {
        StringBuffer buf = new StringBuffer();
        for(int j = 0; j < input.length; j++) {
            if(Double.isInfinite(input[j])) {
                buf.append("All data, ");
            }
            else {
                buf.append(Mathematics.round(input[j],precision));
                if (j < (input.length - 1)) {
                    buf.append(", ");
                }
            }
        }
        return buf.toString();
    }

    /**
     * Returns a string of booleans separated by commas from the input array.
     *
     * @param input the input array
     */

    protected static String getBooleanArrayString(boolean[] input) {
        StringBuffer buf = new StringBuffer();
        for(int j = 0; j < input.length; j++) {
            buf.append(input[j]);
            if (j < (input.length - 1)) {
                buf.append(", ");
            }
        }
        return buf.toString();
    }
    
    /**
     * Returns a string of ints separated by commas from the input array.  
     *
     * @param input the input array 
     */
    
    protected static String getIntegerArrayString(int[] input) {
        StringBuffer buf = new StringBuffer();
        for(int j = 0; j < input.length; j++) {
            buf.append(input[j]);
            if (j < (input.length - 1)) {
                buf.append(", ");
            }
        }
        return buf.toString();
    }    
    
    /**
     * This function expects 2 tokens on a separate line. It checks if the first token equals
     * the string VariableName. In that case it returns the next token which is the value.
     *
     * Example: in file is the line <AttName Rainfall> Function call is: String a_string =
     * parseVarVal(buf_in, ", \t\n\r\f", "AttName"); a_string will now contain "Rainfall"
     *
     * @param type the data type to return
     * @param in a buffered reader
     * @param delimiters the file delimiters
     * @param variableName the name of the variable
     */
    
    protected static Object parseVarVal(String type, BufferedReader in, String delimiters, String variableName) throws IOException {
        try{
            String st1 = in.readLine();
            if(st1==null) {
                throw new IOException("Error in ParseVarVal: "+variableName);
            }
            StringTokenizer st = new StringTokenizer(st1, delimiters);
            if(st.countTokens() != 2 || !(st.nextToken().equalsIgnoreCase(variableName))){
                throw new IOException(st1+" Error in ParseVarVal: "+variableName);
            }
            if(type.equals("double")) {
                return Double.valueOf(Double.parseDouble(st.nextToken()));
            }
            else if(type.equals("int")) {
                return Integer.valueOf(Integer.parseInt(st.nextToken()));
            }
            else {
                return st.nextToken();
            }
        }
        catch(Exception e){
            throw new IOException("Unrecognised data format in file header.");
        }
    }
    
    /**
     * Initializes the default file extensions by reading a parameter file.
     */
    
    private static void initialize() {
        if(getSuppForcFiles() == null) {
            java.io.InputStream conn = null;
            try {
                //Set the supported time units
                java.net.URL url = GlobalUnitsReader.class.getResource(EVSConstants.PARAMETER_FILE_DIR + "file_types.xml");
                conn = url.openStream();
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = factory.newDocumentBuilder();
                Document d = builder.parse(conn);
                NodeList fList = d.getElementsByTagName("file");                
                //Read the supported file types
                Vector<String> forcExt = new Vector<String>();
                Vector<String> obsExt = new Vector<String>();
                Vector<String> forcDesc = new Vector<String>();
                Vector<String> obsDesc = new Vector<String>();
                int len = fList.getLength();
                for(int i = 0; i < len; i++) {
                    try {
                        Node next = fList.item(i);
                        NodeList children = next.getChildNodes();
                        int len2 = children.getLength();
                        String val = next.getParentNode().getNodeName();
                        for(int j = 0; j < len2; j++) {
                            String nextVal = children.item(j).getNodeName();
                            if(nextVal.equals("extension")) {
                                if(val.equals("forecast")) {
                                    forcExt.add(children.item(j).getFirstChild().getNodeValue());
                                } else if(val.equals("observed")) {
                                    obsExt.add(children.item(j).getFirstChild().getNodeValue());
                                }
                            }
                            else if(nextVal.equals("description")) {
                                if(val.equals("forecast")) {
                                    forcDesc.add(children.item(j).getFirstChild().getNodeValue());
                                } else if(val.equals("observed")) {
                                    obsDesc.add(children.item(j).getFirstChild().getNodeValue());
                                }
                            }
                        }
                    } catch(Exception e) {
                        e.printStackTrace();
                    }
                }
                //Set the parameters
                suppForcExt = forcExt.toArray(new String[forcExt.size()]);
                suppObsExt = obsExt.toArray(new String[obsExt.size()]);
                suppForcDesc = forcDesc.toArray(new String[forcDesc.size()]);
                suppObsDesc = obsDesc.toArray(new String[obsDesc.size()]);
                suppForcFiles = new String[getSuppForcExt().length];
                suppObsFiles = new String[getSuppObsExt().length];
                for(int i = 0; i < getSuppForcFiles().length; i++) {
                    suppForcFiles[i] = suppForcDesc[i]+" ("+suppForcExt[i]+")";
                }
                for(int i = 0; i < getSuppObsFiles().length; i++) {
                    suppObsFiles[i] = suppObsDesc[i]+" ("+suppObsExt[i]+")";
                }
            } 
            catch(Throwable e) {
                e.printStackTrace();
            } 
            finally {
                 if(conn != null) {
                    try {
                        conn.close();
                    } 
                    catch(Throwable e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }        
    
    /**
     * Get supported forecast file types with descriptions.
     * 
     * @return forecast file types with descriptions.
     */
    
    private static String[] getSuppForcDesc() {
        return suppForcDesc;
    }
    
    /**
     * Get supported forecast file types.
     * 
     * @return forecast file types.
     */
    
    private static String[] getSuppForcExt() {
        return suppForcExt;
    }
    
    /**
     * Get supported forecast files.
     * 
     * @return forecast files.
     */
    
    private static String[] getSuppForcFiles() {
        return suppForcFiles;
    }
    
    /**
     * Get supported observed file types with descriptions.
     * 
     * @return observed file types with descriptions.
     */
    
    private static String[] getSuppObsDesc() {
        return suppObsDesc;
    }
    
    /**
     * Get supported observed file types.
     * 
     * @return observed file types.
     */
    
    private static String[] getSuppObsExt() {
        return suppObsExt;
    }
    
    /**
     * Get supported observed file types.
     * 
     * @return observed file types.
     */
    
    private static String[] getSuppObsFiles() {
        return suppObsFiles;
    }    
    
}