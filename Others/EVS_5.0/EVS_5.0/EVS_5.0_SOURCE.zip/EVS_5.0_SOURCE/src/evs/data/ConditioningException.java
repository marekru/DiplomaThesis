package evs.data;

/**
 * Class for throwing exceptions that signifies a problem performing conditioning.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ConditioningException extends RuntimeException {
    
    /**
     * Constructs an ConditioningException with no message.
     */
    
    public ConditioningException() {
        super();
    }

    /**
     * Constructs an ConditioningException with the specified message. 
     * 
     * 
     * @param s the message.
     */
    
    public ConditioningException(String s) {
	super(s);
    }
}
