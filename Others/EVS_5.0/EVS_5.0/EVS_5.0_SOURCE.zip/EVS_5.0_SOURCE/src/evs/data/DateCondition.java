package evs.data;

//Java util dependencies
import evs.analysisunits.VerificationUnit;
import java.util.TreeMap;
import java.util.Vector;
import java.util.Iterator;
import java.util.Calendar;
import java.util.Arrays;
import java.util.TimeZone;

//EVS dependencies
import evs.utilities.matrix.BooleanMatrix1D;
import evs.utilities.matrix.DoubleMatrix2D;
import evs.utilities.matrix.DenseBooleanMatrix1D;

/**
 * A class for specifying date restrictions on a verification unit.  A date condition
 * can be set once the start and end dates of the verification unit have been defined.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DateCondition extends Condition {
    
    /********************************************************************************
     *                                                                              *
     *                             INSTANCE VARIABLES                               *
     *                                                                              *
     *******************************************************************************/    

    /**
     * The verification unit associated with this condition.
     */
    
    protected VerificationUnit vu = null;
    
    /**
     * Start date.
     */
    
    private Calendar start = null;

    /**
     * End date.
     */
    
    private Calendar end = null;

    /**
     * The date conditions comprise a map of objects representing date elements that
     * are NOT to be included in the verification.  The map keys comprise
     * identifiers for the date elements, which correspond to the identifiers used
     * in the java Calendar class.  The map values are vectors of elements that
     * should not be included in the verification.  The elements are represented as
     * integer row positions (zero based, relative to all possibilities) that should
     * NOT be included.  For example, a position of 4 associated with the Calendar.MONTH
     * identifier, would indicate that May should not be included.
     */
    
    private TreeMap<DateElement,Vector<Integer>> dateConditions = 
            new TreeMap<DateElement,Vector<Integer>>();

    /********************************************************************************
     *                                                                              *
     *                                 CONSTRUCTOR                                  *
     *                                                                              *
     *******************************************************************************/        
    
    /**
     * Constructs a date condition with a date element to exclude. Additional 
     * conditions may be added once the object has been constructed.
     *
     * @param vu the verification unit
     * @param dateElement the date element
     * @param exclude the vector of elements to exclude 
     */
     
    public DateCondition(final VerificationUnit vu, 
            DateElement dateElement, Vector<Integer> exclude) throws IllegalArgumentException {
        canApplyCondition(vu,true);
        start = vu.getStartDate();
        end = vu.getEndDate();
        setCondition(dateElement,exclude);
        this.vu = vu;        
    }    
    
    /**
     * Constructs a date condition with a map of elements to exclude.
     *
     * @param vu the verification unit
     * @param dateConditions the date conditions 
     */
    
    public DateCondition(final VerificationUnit vu, TreeMap<DateElement,Vector<Integer>> dateConditions) throws IllegalArgumentException {
        this(vu,dateConditions.firstKey(),dateConditions.get((DateElement)dateConditions.firstKey()));
        Iterator i = dateConditions.keySet().iterator();
        i.next(); //Skip 1
        while(i.hasNext()) {
            DateElement next = (DateElement)i.next();
            setCondition(next,dateConditions.get(next));
        }
    }  
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/        
    
    /**
     * Returns true if a condition can be applied to a specified verification 
     * unit, otherwise returns false or throws an exception if the condition is false 
     * and throwEx is true.
     *
     * @param vu the verification unit
     * @param throwEx the exception
     * @return true if the condition can be applied, false otherwise
     */
    @Override
    public final boolean canApplyCondition(VerificationUnit vu, boolean throwEx) throws IllegalArgumentException {
        if(vu == null) {
            throw new IllegalArgumentException("The input verification unit cannot be null.");
        }
        boolean returnMe = true;
        if(!vu.hasDates()) {
            returnMe = false;
            if(throwEx) {
                throw new IllegalArgumentException("Set the start and end dates of the parent unit '"+vu+"' before associating more specific date conditions with this unit.");
            }
        }        
        return returnMe;
    }        
    
    /**
     * Returns true if a specified date condition has been set.  
     * 
     * @param dateElement the date element
     * @return true if a specified conditions has been set
     */
    
    public boolean hasCondition(DateElement dateElement) {
        return getCondition(dateElement) != null;
    }
    
    /**
     * Returns true if a date element exists that is defined with valid time, 
     * false otherwise.
     * 
     * @return true if a date condition exists in valid time, false otherwise
     */
    
    public boolean hasConditionValidTime() {
        Iterator it = dateConditions.keySet().iterator();
        while(it.hasNext()) {
            if(((DateElement)it.next()).isValidTime()) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Returns true if a date element exists that is defined with basis time, 
     * false otherwise.
     * 
     * @return true if a date condition exists in basis time, false otherwise
     */
    
    public boolean hasConditionBasisTime() {
        Iterator it = dateConditions.keySet().iterator();
        while(it.hasNext()) {
            if(!((DateElement)it.next()).isValidTime()) {
                return true;
            }
        }
        return false;
    }    
    
    /**
     * Returns a vector of date positions to exclude with respect to the specified
     * date condition or null if the condition has not been defined.  The vector  
     * comprises zero-based indices of those elements that will NOT be included in the
     * verification.  For example, an index of 1 associated with Calendar.MONTH
     * would imply that February was not included in the verification.
     *
     * @param dateElement the date element
     * @return the specified condition or null
     */
    
    public Vector<Integer> getCondition(DateElement dateElement) {
        return dateConditions.get((DateElement)dateElement);
    }        
    
    /**
     * Returns the integer set of date elements to exclude.
     * 
     * @return the elements to exclude
     */
    
    public TreeMap<DateElement, Vector<Integer>> getConditions() {
        return dateConditions;
    }    
    
    /**
     * Returns the integer set of date elements to exclude in valid time. If no
     * conditions are defined in valid time, returns an empty map.
     * 
     * @return the elements to exclude
     */
    
    public TreeMap<DateElement, Vector<Integer>> getConditionsValidTime() {
        TreeMap<DateElement, Vector<Integer>> m = 
                new TreeMap<DateElement, Vector<Integer>>();
        Iterator i = dateConditions.keySet().iterator();
        while(i.hasNext()) {
            DateElement next = ((DateElement)i.next());
            if(next.isValidTime()) {
                m.put(next,dateConditions.get(next));
            }
        }
        return m; 
    }     
    
    /**
     * Returns the integer set of date elements to exclude in basis time. If no
     * conditions are defined in basis time, returns an empty map.
     * 
     * @return the elements to exclude
     */
    
    public TreeMap<DateElement, Vector<Integer>> getConditionsBasisTime() {
        TreeMap<DateElement, Vector<Integer>> m = 
                new TreeMap<DateElement, Vector<Integer>>();
        Iterator i = dateConditions.keySet().iterator();
        while(i.hasNext()) {
            DateElement next = ((DateElement)i.next());
            if(!next.isValidTime()) {
                m.put(next,dateConditions.get(next));
            }
        }
        return m; 
    }  
    
    /**
     * Returns the start date or null.
     *
     * @return the start date or null.
     */
    
    public Calendar getStartDate() {
        return start;
    }
    
    /**
     * Returns the end date or null.
     *
     * @return the end date or null.
     */
    
    public Calendar getEndDate() {
        return end;
    }    

    /**
     * Applies the condition, returning a 1D matrix of boolean values whose elements
     * indicate which rows should be used, where true indicates a row should be
     * used. The input data may contain either observed data (i.e. two columns,
     * with valid time and observations), forecasts (valid time, lead time, and members) 
     * or paired data (valid time, lead time, observations and members).  
     * 
     * @param data the data
     * @param dataType the data type
     * @return the rows that should be used given the condition
     */

    @Override
    public BooleanMatrix1D apply(DoubleMatrix2D data, int dataType) throws IllegalArgumentException {
        if(data == null) {
            throw new IllegalArgumentException("No data have been defined for conditioning purposes.");
        }
        //Iterate through the date elements and eliminate accordingly
        Iterator i = dateConditions.keySet().iterator();
        int rows = data.getRowCount();
        boolean[] include = new boolean[rows];
        Arrays.fill(include,true);
        while(i.hasNext()) {
            DateElement key = (DateElement)i.next();
            Vector<Integer> elements = dateConditions.get(key);
            for(int j = 0; j < rows; j++) {
                //Only check elements that are currently true
                if(include[j]) {
                    Calendar nxt = Calendar.getInstance();
                    //Pairs are always in UTC
                    nxt.setTimeZone(TimeZone.getTimeZone("UTC"));
                    double date = data.get(j,0);
                    //Adjust for basis time if needed
                    if(!key.isValidTime()) {
                        date = date - data.get(j,1);
                    }
                    //Convert time from hours relative to the epoch to milliseconds
                    nxt.setTimeInMillis((long)(date*1000.0*60.0*60.0));
                    int translated = translateCalToEVS(key.getDateElement(),
                            nxt.get(key.getDateElement()));
                    if(elements.contains(translated)) {
                        include[j] = false;
                    }
                }
            }
        }
        return new DenseBooleanMatrix1D(include);
    }

    /**
     * Returns true if the input object is a date condition and the date conditions
     * are equal to those in the current object, false otherwise
     *
     * @param obj the input object
     * @return true if the object has equivalent date conditions
     */
    
    public boolean equals(Object obj) {
        if(!(obj instanceof DateCondition)) {
            return false;
        }
        return ((DateCondition)obj).dateConditions.equals(dateConditions);
    }
    
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        assert false : "hashCode not implemented for DateCondition.";
        return 1;
    }
    
    /********************************************************************************
     *                                                                              *
     *                                MUTATOR METHODS                               *
     *                                                                              *
     *******************************************************************************/    
    
    /**
     * Sets a date condition.  Specify the verification unit to which the condition
     * applies.  In addition, specify the date element and the vector of 
     * identifiers to exclude. The identifiers for all date elements are zero-based. 
     * The following date elements are zero, and increment upwards:
     * 
     * Calendar.YEAR: the first year in {@link DateCondition#start}
     * Calendar.DAY_OF_WEEK: Monday
     * Calendar.WEEK_OF_YEAR: First week
     * Calendar.MONTH_OF_YEAR: January
     * Calendar.HOUR_OF_DAY: 0Z
     * 
     * @param dateElement the date element
     * @param exclude the vector of integer identifiers to exclude     
     */
    
    public final void setCondition(DateElement dateElement, Vector<Integer> exclude) throws IllegalArgumentException {
        //Check values to make sure they are in range
        int length = exclude.size();
        for (int j = 0; j < length; j++) {
            int n = (Integer) exclude.get(j);
            translateEVSToCal(dateElement.getDateElement(),n);
        }
        if(dateConditions == null) {
            dateConditions = new TreeMap<DateElement,Vector<Integer>>();
        }
        dateConditions.put(dateElement,exclude);        
    }    
    
    /**
     * Returns a deep copy of the verification condition.
     *
     * @return a deep copy
     */
    
    public Condition deepCopy() {   
        Iterator i = dateConditions.keySet().iterator();
        DateCondition d = null;
        while(i.hasNext()) {
            DateElement next = ((DateElement)i.next()).deepCopy();
            Vector v = dateConditions.get(next);
            Vector<Integer> v2 = new Vector<Integer>();
            int length = v.size();
            for(int j = 0; j < length; j++) {
                int nextDate = (Integer)v.get(j);
                v2.add(nextDate);
            }
            if(d == null) {
                d = new DateCondition(vu,next,v2);
            }
            else {
                d.setCondition(next,v2);
            }
        }
        return d;
    }
    
    /**
     * Returns a {@link java.util.Calendar} identifier that corresponds to the 
     * input integer. The identifiers for the EVS elements are zero-based. The 
     * following date elements are zero, and increment upwards:
     * 
     * {@link java.util.Calendar#DAY_OF_WEEK}: Monday
     * {@link java.util.Calendar#WEEK_OF_YEAR}: First week
     * {@link java.util.Calendar#MONTH}: January
     * {@link java.util.Calendar#HOUR_OF_DAY}: 0Z  
     * 
     * Thus, for example, an input of {@link java.util.Calendar#DAY_OF_WEEK} and
     * 0 will return the corresponding calendar identifier {@link java.util.Calendar#MONDAY}.
     * 
     * Throws an exception if the EVS identifier is inconsistent with the range
     * of the date class element (e.g. 27 for hour of day)
     * 
     * @param element the date class from {@link java.util.Calendar}
     * @param evsID the EVS identifier for the date element
     * @return the identifier from {@link java.util.Calendar}
     */
    
    public int translateEVSToCal(int element, int evsID) {
        //Check values to make sure they are in range
        switch (element) {
            case Calendar.YEAR: {
                int range = end.get(Calendar.YEAR) - start.get(Calendar.YEAR);
                if (evsID < 0 || evsID > range) {
                    throw new IllegalArgumentException("One or more excluded years are out of range.");
                }
                return start.get(Calendar.YEAR)+evsID;
            }
            case Calendar.MONTH: {
                if (evsID < 0 || evsID > 11) {
                    throw new IllegalArgumentException("One or more excluded months are out of range: "+evsID);
                }
                switch (evsID) {
                    case 0:
                        return Calendar.JANUARY;
                    case 1:
                        return Calendar.FEBRUARY;
                    case 2:
                        return Calendar.MARCH;
                    case 3:
                        return Calendar.APRIL;
                    case 4:
                        return Calendar.MAY;
                    case 5:
                        return Calendar.JUNE;
                    case 6:
                        return Calendar.JULY;
                    case 7:
                        return Calendar.AUGUST;
                    case 8:
                        return Calendar.SEPTEMBER;
                    case 9:
                        return Calendar.OCTOBER;
                    case 10:
                        return Calendar.NOVEMBER;
                    case 11:
                        return Calendar.DECEMBER;                      
                }
            }
            case Calendar.WEEK_OF_YEAR: {
                if (evsID < 0 || evsID > 52) {  //JB @ 21st November 2012. Some years have 53 weeks.
                    throw new IllegalArgumentException("One or more excluded weeks are out of range: "+evsID);
                }
                return evsID+1;  //JB Java Calendar first week of year is 1
            }
            case Calendar.DAY_OF_WEEK: {
                if (evsID < 0 || evsID > 6) {
                    throw new IllegalArgumentException("One or more excluded days of the week are out of range: "+evsID);
                }
                switch(evsID) {
                    case 0:
                        return Calendar.MONDAY;
                    case 1:
                        return Calendar.TUESDAY;
                    case 2:
                        return Calendar.WEDNESDAY;
                    case 3:
                        return Calendar.THURSDAY;
                    case 4:
                        return Calendar.FRIDAY;
                    case 5:
                        return Calendar.SATURDAY;
                    case 6:
                        return Calendar.SUNDAY; 
                }
            }
            case Calendar.HOUR_OF_DAY: {
                if (evsID < 0 || evsID > 23) {
                    throw new IllegalArgumentException("One or more excluded hours are out of range: "+evsID);
                }
                return evsID;
            }
            default: {
                throw new IllegalArgumentException("Unrecognized date identifier.");
            }
        }
    }
    
    /**
     * Returns an EVS date identifier that corresponds to the input {@link java.util.Calendar} 
     * integer. The identifiers for the EVS elements are zero-based. The following 
     * date elements are zero, and increment upwards:
     * 
     * {@link java.util.Calendar#DAY_OF_WEEK}: Monday
     * {@link java.util.Calendar#WEEK_OF_YEAR}: First week
     * {@link java.util.Calendar#MONTH}: January
     * {@link java.util.Calendar#HOUR_OF_DAY}: 0Z  
     * 
     * Thus, for example, an input of {@link java.util.Calendar#DAY_OF_WEEK} and
     * {@link java.util.Calendar#MONDAY} will return the EVS ID of 0.
     * 
     * Throws an exception if the input identifier is inconsistent with the range
     * of the input date class element (e.g. 27 for hour of day)
     * 
     * @param element the date class from {@link java.util.Calendar}
     * @param calID the {@link java.util.Calendar} identifier for the date element
     * @return the EVS identifier
     */
    
    public int translateCalToEVS(int element, int calID) {
        //Check values to make sure they are in range
        switch (element) {
            case Calendar.YEAR: {
                if (calID < start.get(Calendar.YEAR) || calID > end.get(Calendar.YEAR)) {
                    throw new IllegalArgumentException("One or more excluded years are out of range: "+calID);
                }
                return calID - start.get(Calendar.YEAR);
            }
            case Calendar.MONTH: {
                switch (calID) {
                    case Calendar.JANUARY:
                        return 0;
                    case Calendar.FEBRUARY:
                        return 1;
                    case Calendar.MARCH:
                        return 2;
                    case Calendar.APRIL:
                        return 3;
                    case Calendar.MAY:
                        return 4;
                    case Calendar.JUNE:
                        return 5;
                    case Calendar.JULY:
                        return 6;
                    case Calendar.AUGUST:
                        return 7;
                    case Calendar.SEPTEMBER:
                        return 8;
                    case Calendar.OCTOBER:
                        return 9;
                    case Calendar.NOVEMBER:
                        return 10;
                    case Calendar.DECEMBER:
                        return 11;       
                    default: throw new IllegalArgumentException("One or more excluded months are out of range: "+calID);
                }
            }
            case Calendar.WEEK_OF_YEAR: {
                if (calID < 1 || calID > 53) { //JB @ 21st November 2012  //Some years have 53 weeks
                    throw new IllegalArgumentException("One or more excluded weeks are out of range: "+calID);
                }
                return calID-1;    //JB @ 21st November 2012  //JB Java Calendar first week of year is 1
            }
            case Calendar.DAY_OF_WEEK: {
                switch(calID) {
                    case Calendar.MONDAY:
                        return 0;
                    case Calendar.TUESDAY:
                        return 1;
                    case Calendar.WEDNESDAY:
                        return 2;
                    case Calendar.THURSDAY:
                        return 3;
                    case Calendar.FRIDAY:
                        return 4;
                    case Calendar.SATURDAY:
                        return 5;
                    case Calendar.SUNDAY:
                        return 6; 
                    default: throw new IllegalArgumentException("One or more excluded days of the week are out of range: "+calID);
                }
            }
            case Calendar.HOUR_OF_DAY: {
                if (calID < 0 || calID > 23) {
                    throw new IllegalArgumentException("One or more excluded hours are out of range: "+calID);
                }
                return calID;
            }
            default: {
                throw new IllegalArgumentException("Unrecognized date identifier.");
            }
        }
    }    
    
}
