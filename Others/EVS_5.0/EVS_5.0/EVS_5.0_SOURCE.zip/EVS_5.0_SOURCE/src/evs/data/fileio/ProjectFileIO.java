package evs.data.fileio;

//Java io dependencies
import evs.data.DateElement;
import evs.data.DateCondition;
import evs.data.ValueCondition;
import java.io.*;

//Java util dependencies
import java.util.*;

//Java lang dependencies
import java.lang.reflect.InvocationTargetException;

//Java XMLW dependencies
import javax.xml.parsers.DocumentBuilder; 
import javax.xml.parsers.DocumentBuilderFactory;  

//Other XMLW dependencies
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

//Apache XMLW writing
import org.apache.ecs.xml.XMLDocument;

//EVS dependencies
import evs.analysisunits.*;
import evs.utilities.mathutil.*;
import evs.metric.metrics.*;
import evs.metric.parameters.*;
import evs.analysisunits.scale.*;
import evs.data.*;
import evs.utilities.*;
import evs.data.fileio.*;

/**
 * Class for reading and writing project files in XMLW format.  
 * 
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ProjectFileIO extends FileIO {

/*******************************************************************************
 *                                                                             *
 *                               ACCESSOR METHODS                              *
 *                                                                             *
 ******************************************************************************/    

    /**
     * Reads a project file and returns one or more evs.analysisunits.AnalysisUnit
     * objects.
     *
     * @param projectFile the XMLW file to read
     * @return one or more analysis units
     */
    
    public static AnalysisUnit[] read(File projectFile) throws IOException {
        FileInputStream conn = null;
        try {
            //The completed analysis units
            AnalysisUnit[] units = null;
            
            //Create the new document model
            conn = new FileInputStream(projectFile.getAbsolutePath());
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document d = builder.parse(conn);
            
            //Read in the objects
            NodeList verifList = d.getElementsByTagName("verification_unit");
            NodeList aggList = d.getElementsByTagName("aggregation_unit");
            int verifCount = verifList.getLength();
            int aggCount = aggList.getLength();
//            if(verifCount < 1) {
//                throw new IOException("No verification units to read in.");
//            }
            LinkedHashMap<String,VerificationUnit> nameStore = new LinkedHashMap();  //Store of verification units
            Vector<AggregationUnit> aggUnits = new Vector();
            
            //Set of variable value conditions associated with each unit
            //These cannot be set until all verification units have been read, as they 
            //may reference one or more other units.
            TreeMap<String,Vector> valExclusions = new TreeMap();
            //Import the verification units
            for(int i = 0; i < verifCount; i++) {
                VerificationUnit vu = readVerificationUnit(verifList.item(i));
                nameStore.put(vu.toString(),vu); //The next verification unit;
                Vector<Object[]> valCon = readValueConditionPars(verifList.item(i));
                if(valCon != null && valCon.size()>0) {
                    valExclusions.put(vu.toString(),valCon);
                }
            }
            //Import the aggregation units
            for(int i = 0; i < aggCount; i++) {
//                try {
                    Node next = aggList.item(i); //The next aggregation unit
                    NodeList children = next.getChildNodes();
                    int len = children.getLength();
                    String unitName = "";
                    String output = "";
                    String outputType = "";
                    ArrayList<VerificationUnit> components = new ArrayList<VerificationUnit>();
                    ArrayList<Double> weights = new ArrayList<Double>();
                    boolean poolPairs = false;
                    boolean statDependent = false;
                    boolean bootstrap = false;
                    for (int j = 0; j < len; j++) {
                        Node current = children.item(j);
                        String name = current.getNodeName();
                        //Name of aggregation unit
                        if (name.equals("name")) {
                            unitName = current.getFirstChild().getNodeValue();
                        } 
                        else if (name.equals("unit_id")) {
                            String uName = current.getFirstChild().getNodeValue();
                            if(nameStore.containsKey(uName)) {
                                components.add(nameStore.get(uName));
                            }
                            //Backwards compatibility: eliminate time-series ID
                            else {
                                String sub = uName.substring(0,uName.indexOf(VerificationUnit.getIDSepChar()));
                                String rem = uName.substring(sub.length()+1,uName.length());
                                String newName = sub+rem.substring(rem.indexOf(VerificationUnit.getIDSepChar()),rem.length());
                                components.add(nameStore.get(newName));
                            }
                        }
                        else if(name.equals("weights")) {
                            String w = current.getFirstChild().getNodeValue();
                            weights = EVSUtilities.toArrayList(getDoubleArray(w));
                        }
                        //Pool pairs
                        else if(name.equals("pool_pairs")) {
                            poolPairs=current.getFirstChild().getNodeValue().equalsIgnoreCase("true");
                        }
                        //Statistically dependent
                        else if(name.equals("statistically_dependent")) {
                            statDependent=current.getFirstChild().getNodeValue().equalsIgnoreCase("true");
                        }
                        //Bootstrap
                        else if(name.equals("bootstrap")) {
                            bootstrap=current.getFirstChild().getNodeValue().equalsIgnoreCase("true");
                        } 
                        //Output data source
                        else if (name.equals("output_data")) {
                            NodeList nodes = current.getChildNodes();
                            int len3 = nodes.getLength();
                            for (int k = 0; k < len3; k++) {
                                String nextName = nodes.item(k).getNodeName();
                                Node node = nodes.item(k).getFirstChild();
                                if (nextName.equals("output_data_location")) {
                                    String item = node.getNodeValue();
                                    if (item != null) {
                                        output = item;
                                    }
                                } 
                                else if (nextName.equals("output_graphics_type")) {
                                    if (node != null) {
                                        outputType=node.getNodeValue();
                                    }
                                }
                            }
                        }     
                        //Backwards compatibility for output location
                        else if (name.equals("output_data_location") && current.getFirstChild() != null) {
                            output = current.getFirstChild().getNodeValue();
                        }
                    }
                    AggregationUnit nextAgg = new AggregationUnit(unitName);
                    nextAgg.setPoolPairs(poolPairs);
                    nextAgg.setStatDependent(statDependent);
                    nextAgg.setBootstrap(bootstrap);
                    //One unit defined, which is used to identify associated verification unit
                    if (components.size() == 1) {
                        components.get(0).addAggregationUnit(nextAgg);
                    } //Multiple verification units
                    else if (components.size() > 1) {
                        //Backwards compatibility: set equal weights
                        if(weights.size()==0) {
                            int rows = components.size();
                            double dd = 1.0/rows;
                            for(int j = 0; j < rows; j++) {
                                weights.add(dd);
                            }
                        }
                        nextAgg.setVerificationUnits(components,weights);
                    }
                    //Set the output location
                    aggUnits.add(nextAgg);
                    nextAgg.setOutputData(new FileDataSource(new File(output)));
                    if(!outputType.isEmpty()) {
                        nextAgg.setWriteOptions(new WriteOption(outputType));
                    }
//                } catch (Exception e) {  JB @ August 2012
//                    e.printStackTrace();
//                }
            }
            
            //Set any value conditions now all verification units have been read
            Iterator it = valExclusions.keySet().iterator();
            while(it.hasNext()) {
                //Unit to which the conditions apply
                VerificationUnit parent = (VerificationUnit)nameStore.get(it.next());
                Vector<Object[]> conditionStore = valExclusions.get(parent.toString());  //Value conditions
                //Iterate through each condition
                for(int i = 0; i < conditionStore.size(); i++) {
                    Object[] p = conditionStore.get(i);
                    //Obtain the parameters for each condition
                    VerificationUnit un = (VerificationUnit)nameStore.get(p[0]);
                    int type = (Integer)p[1];
                    Function stat = (Function)p[2];
                    DoubleProcedure[] conditions = (DoubleProcedure[])p[3];
                    Double period = (Double)p[4];
                    String periodUnit = (String)p[5];
                    VectorFunction windowStat = (VectorFunction)p[6];
                    //Construct the condition and apply it to the parent
                    ValueCondition cond = new ValueCondition(un,type,stat,conditions,period,periodUnit,windowStat);
                    parent.setValueCondition(cond);
                }
            }
            
            //Copy the verification and aggregation units into one array
            units = new AnalysisUnit[verifCount+aggUnits.size()];
            Collection c = nameStore.values();
            Vector v = new Vector();
            v.addAll(c);
            v.addAll(aggUnits);
            System.arraycopy(v.toArray(),0,units,0,v.size());
            return units;
        } catch(Throwable e) {
            e.printStackTrace();
            String text = "Error reading the project file. ";
            if(e.getMessage()!=null) {
                text = text + e.getMessage();
            }
            throw new IOException(text);
        } finally {
            if(conn != null) {
                conn.close();
            }
        }
    }
    
/*******************************************************************************
 *                                                                             *
 *                                MUTATOR METHODS                              *
 *                                                                             *
 ******************************************************************************/

    /**
     * Writes a project to a specified file in XMLW format using a given set of 
     * analysis units.
     *
     * @param projectFile the project file
     * @param units the analysis units 
     */
    
    public static void write(File projectFile, AnalysisUnit[] units) throws IOException {    
        if(projectFile == null) {
            throw new IOException("Specify a writeable file for the project.");
        }
        if(!projectFile.canRead()) {
            try {
                boolean create = projectFile.createNewFile();
                if (!create) {
                    throw new IOException();
                }
            } catch (Exception e) {
                throw new IOException("Unable to create project file '"+projectFile.getCanonicalPath()+"' for writing.");
            }
        }
//        if(units.length < 1) {
//            throw new IOException("Specify some units to write.");
//        }
        //Separate the units by type
        Vector<VerificationUnit> ver = new Vector();
        Vector<AggregationUnit> agg = new Vector();
        for(int i = 0 ; i < units.length; i++) {
            if(units[i] instanceof VerificationUnit) {
                ver.add((VerificationUnit)units[i]);
            }
            else if(units[i] instanceof AggregationUnit){
                agg.add((AggregationUnit)units[i]);
            }
        }
        XMLDocument doc = new XMLDocument();
        XMLW top = new XMLW("verification");  //Root node
        doc.addElement(top);
        
        //Write the verification units first
        int vLength = ver.size();
        for(int i = 0; i < vLength; i++) {
            VerificationUnit v = ver.get(i);
            //Add a verification unit
            XMLW unit = new XMLW("verification_unit");
            top.addElement(unit);
            //Add the identification info
            XMLW ident = new XMLW("identifiers");
            unit.addElement(ident);
            ident.addElement(new XMLW("location_id").addElement(v.getLocationID()));
            ident.addElement(new XMLW("environmental_variable_id").addElement(v.getVariableID()));
            ident.addElement(new XMLW("additional_id").addElement(v.getAdditionalID()));
            
            //Add the input_data info
            XMLW input = new XMLW("input_data");
            unit.addElement(input);
            //Add the forecast files
            if(v.hasForecastData()) {
                XMLW forc = new XMLW("forecast_data_location");
                input.addElement(forc);
                DataSource d = v.getForecastData();
                if(d instanceof FileArrayDataSource) {
                    File[] files = (File[])d.getData();
                    for(int j = 0; j < files.length; j++) {
                        forc.addElement(new XMLW("file").addElement(files[j].getPath())); //JB @ August 2012 .getAbsolutePath()
                    }
                }
                else if(d instanceof FileDataSource){
                    File f = (File)d.getData();
                    forc.addElement(new XMLW("file").addElement(f.getPath())); //JB @ August 2012 .getAbsolutePath()
                }
            }
            //Add the observed file
            if(v.hasObservedData()) {
                File f = (File)v.getObservedData().getData();
                input.addElement(new XMLW("observed_data_location").addElement(f.getPath())); //JB @ August 2012 .getAbsolutePath()
            }
            //Add the climatology file
//            if(v.hasClimatologyData()) {
//                File f = (File)v.getClimatologyData().getData();
//                input.addElement(new XMLW("climatology_data_location").addElement(f.getPath())); //JB @ August 2012 .getAbsolutePath()
//            }

            //Set the file types
            input.addElement(new XMLW("forecast_file_type").addElement(FileIO.getFileTypeStringForID(
                    v.getForecastFileType())));
            input.addElement(new XMLW("observed_file_type").addElement(FileIO.getFileTypeStringForID(
                    v.getObservedFileType())));
            //Set the identifiers for file reading if available
            if(v.hasForecastFileLocationID()) {
                input.addElement(new XMLW("forecast_file_location_id").addElement(v.getForecastFileLocationID()));
            }
            if(v.hasObservedFileLocationID()) {
                input.addElement(new XMLW("observed_file_location_id").addElement(v.getObservedFileLocationID()));
            }
            if(v.hasForecastFileVariableID()) {
                input.addElement(new XMLW("forecast_file_variable_id").addElement(v.getForecastFileVariableID()));
            }
            if(v.hasObservedFileVariableID()) {
                input.addElement(new XMLW("observed_file_variable_id").addElement(v.getObservedFileVariableID()));
            }            

            //Add the time systems
            if(v.hasForecastTimeSystem()) {
                input.addElement(new XMLW("forecast_time_system").addElement(v.getForecastTimeSystem()+""));
            }
            if(v.hasObservedTimeSystem()) {
                input.addElement(new XMLW("observed_time_system").addElement(v.getObservedTimeSystem()+""));
            }

//            if(v.hasClimatologyTimeSystem()) {
//                input.addElement(new XMLW("climatology_time_system").addElement(v.getClimatologyTimeSystem()+""));
//            }
            //Add the support information
            //Forecast support
            if(v.hasSupport(Support.FORECAST_SUPPORT)) {
                TemporalSupport s = (TemporalSupport)v.getSupport(Support.FORECAST_SUPPORT);
                XMLW supp = new XMLW("forecast_support");
                input.addElement(supp);
                supp.addElement(new XMLW("statistic").addElement(s.getAggregationFunction()));
                if(!s.hasPointSupport()) {
                    supp.addElement(new XMLW("period").addElement(s.getAggregationPeriod()+""));
                    supp.addElement(new XMLW("period_units").addElement(s.getAggregationUnits()));
                }
                supp.addElement(new XMLW("existing_attribute_units").addElement(s.getMeasurementUnits()));
                if(s.hasTargetMeasurementUnits()) {
                    supp.addElement(new XMLW("target_attribute_units").addElement(s.getTargetMeasurementUnits()));
                    String f = s.getTargetMeasurementUnitsFunc().toString();
                    //Only add function if custom multiplier
                    if(!MeasurementUnitsChangeLibrary.
                            isInLibrary(s.getMeasurementUnits(),s.getTargetMeasurementUnits())) {
                        double d = ((DoubleOperation)s.getTargetMeasurementUnitsFunc()).getConstants()[0];
                        supp.addElement(new XMLW("attribute_units_function").addElement(d+""));
                    }
                }
                supp.addElement(new XMLW("notes").addElement(s.getNotes()));
            }
            //Observed support
            if(v.hasSupport(Support.OBSERVED_SUPPORT)) {
                TemporalSupport s = (TemporalSupport)v.getSupport(Support.OBSERVED_SUPPORT);
                XMLW supp = new XMLW("observed_support");
                input.addElement(supp);
                supp.addElement(new XMLW("statistic").addElement(s.getAggregationFunction()));
                if(!s.hasPointSupport()) {
                    supp.addElement(new XMLW("period").addElement(s.getAggregationPeriod()+""));
                    supp.addElement(new XMLW("period_units").addElement(s.getAggregationUnits()));
                }
                supp.addElement(new XMLW("existing_attribute_units").addElement(s.getMeasurementUnits()));
                if(s.hasTargetMeasurementUnits()) {
                    supp.addElement(new XMLW("target_attribute_units").addElement(s.getTargetMeasurementUnits()));
                    String f = s.getTargetMeasurementUnitsFunc().toString();
                    //Only add function if custom multiplier
                    if(!MeasurementUnitsChangeLibrary.
                            isInLibrary(s.getMeasurementUnits(),s.getTargetMeasurementUnits())) {
                        double d = ((DoubleOperation)s.getTargetMeasurementUnitsFunc()).getConstants()[0];
                        supp.addElement(new XMLW("attribute_units_function").addElement(d+""));
                    }
                }
                supp.addElement(new XMLW("notes").addElement(s.getNotes()));
            }
            input.addElement(new XMLW("use_all_observations_for_climatology").addElement(v.isUseFullClimatology()+""));
            input.addElement(new XMLW("apply_date_cond_to_climatology").addElement(v.isApplyDateCondToClim()+""));
            input.addElement(new XMLW("apply_value_cond_to_climatology").addElement(v.isApplyValueCondToClim()+""));
            
            //Add date formats for input data
            input.addElement(new XMLW("forecast_date_format").addElement(v.getForcDateFormat()));
            input.addElement(new XMLW("observed_date_format").addElement(v.getObsDateFormat()));
            //Add null value
            input.addElement(new XMLW("global_null_value").addElement(v.getNullValue()+""));
            
            //Add the parameters of the verification window
            XMLW window = new XMLW("verification_window");
            unit.addElement(window);
                        
            //Start date
            if(v.hasStartDate()) {
                Calendar c = v.getStartDate();
                XMLW start = new XMLW("start_date");
                window.addElement(start);
                start.addElement(new XMLW("year").addElement(c.get(c.YEAR)+""));
                start.addElement(new XMLW("month").addElement(c.get(c.MONTH)+""));
                start.addElement(new XMLW("day").addElement(c.get(c.DAY_OF_MONTH)+""));
            }
            //End date
            if(v.hasEndDate()) {
                Calendar c = v.getEndDate();
                XMLW end = new XMLW("end_date");
                window.addElement(end);
                end.addElement(new XMLW("year").addElement(c.get(c.YEAR)+""));
                end.addElement(new XMLW("month").addElement(c.get(c.MONTH)+""));
                end.addElement(new XMLW("day").addElement(c.get(c.DAY_OF_MONTH)+""));               
            }
            //Time system for the verification window
            window.addElement(new XMLW("window_in_valid_time").addElement(v.isVerifWindowInValidTime()+""));
            //Date condition
            if(v.hasDateCondition()) {
                DateCondition d = v.getDateCondition();
                XMLW condition = new XMLW("date_conditions");
                window.addElement(condition);
                if(d.hasConditionValidTime()) {
                    XMLW validTime = new XMLW("valid_time");
                    condition.addElement(validTime);
                    addDateConditions(validTime,d.getConditionsValidTime());
                }
                if(d.hasConditionBasisTime()) {
                    XMLW basisTime = new XMLW("basis_time");
                    condition.addElement(basisTime);
                    addDateConditions(basisTime,d.getConditionsBasisTime());
                }
            }
            //Value conditions
            if(v.hasValueConditions()) {
                XMLW condition = new XMLW("value_conditions");
                window.addElement(condition);
                Vector<ValueCondition> cons = v.getValueConditions();
                int count = cons.size();
                for(int j = 0; j < count; j++) {
                    ValueCondition c = cons.get(j);
                    XMLW next = new XMLW("condition");
                    condition.addElement(next);
                    next.addElement(new XMLW("unit_id").addElement(c.getVerificationUnitID()));
                    next.addElement(new XMLW("forecast_type").addElement((c.getConditionType()==c.FORECAST_CONDITION)+""));
                    Function cf = c.getDataStatistic();
                    next.addElement(new XMLW("statistic").addElement(cf.toString()));
                    if((cf instanceof VectorFunction) && ((VectorFunction)cf).getConstants()!=null) {
                        next.addElement(new XMLW("statistic_constant").addElement(((VectorFunction)cf).getConstants()[0]+""));
                    }
                    if(c.hasTimeWindow()) {
                        next.addElement(new XMLW("consecutive_period").addElement(c.getTimeWindow()+""));
                        next.addElement(new XMLW("consecutive_period_units").addElement(c.getTimeWindowUnits()));
                        next.addElement(new XMLW("consecutive_period_statistic").addElement(c.getWindowStatistic().toString()));
                    }
                    XMLW logical = new XMLW("logical_conditions");
                    next.addElement(logical);
                    DoubleProcedure[] log = c.getLogicalConditions();
                    for (int k = 0; k < log.length; k++) {
                        XMLW function = new XMLW("function");
                        logical.addElement(function);
                        function.addAttribute("name", log[k].toString());
                        function.addAttribute("value", log[k].getConstants()[0]);
                    }
                }
            }
            //Forecast lead time
            if(v.hasLeadTimes()) {
                window.addElement(new XMLW("first_lead_period").addElement(v.getFirstLeadTime()+""));
                window.addElement(new XMLW("last_lead_period").addElement(v.getLastLeadTime()+""));
                window.addElement(new XMLW("forecast_lead_units").addElement(v.getForecastLeadTimeUnits()));
            }
            //Aggregation of lead time
            if(v.hasResolution()) {
                window.addElement(new XMLW("aggregation_lead_period").addElement(v.getResolution()+""));
                window.addElement(new XMLW("aggregation_lead_units").addElement(v.getResolutionUnits()));
                window.addElement(new XMLW("aggregation_function").addElement(v.getTemporalAggFunc().toString().toUpperCase()));
            }
            //Aggregation start time
            if(v.hasAggregationStartHourUTC()) {
                window.addElement(new XMLW("aggregation_start_time_UTC").addElement(v.getAggregationStartHourUTC()+""));
            }
            
            //Aggregation start lead time
            if(v.hasAggregationStartLeadHour()) {
                window.addElement(new XMLW("aggregation_start_lead_hour").addElement(v.getAggregationStartLeadHour()+""));
            }
            
            //Add the sample size constraint, which is zero by default
            window.addElement(new XMLW("sample_size_constraint").addElement(v.getSampleSizeConstraint()+""));

            //Path to the output folder
            XMLW output = new XMLW("output_data");
            if(v.hasOutputData()) {
                File f = (File)v.getOutputData().getData();
                output.addElement(new XMLW("output_data_location").addElement(f.getPath())); //JB @ August 2012 .getAbsolutePath()
            }
            WriteOption write = v.getWriteOptions();
            output.addElement(new XMLW("output_graphics_type").addElement(write.getStringID())); //JB @ August 2012 .getAbsolutePath()
            unit.addElement(output);
            
            //Path to the paired data
            XMLW paired = new XMLW("paired_data");
            String path = "";
            if (v.hasPairedDataSource() && v.isWriteUnconditionalPairs()) {
                //File f = (File) v.getPairedDataSource().getData(); //@JB 5th October 2012
                //path = f.getAbsolutePath(); //@JB 5th October 2012
                path = v.getPairedDataSource().toString();
            }
            paired.addElement(new XMLW("paired_data_location").addElement(path));
            paired.addElement(new XMLW("eliminate_duplicates").addElement(v.isEliminateDuplicates() + ""));
            paired.addElement(new XMLW("write_conditional_pairs").addElement(v.isWriteConditionalPairs() + ""));
            paired.addElement(new XMLW("write_unconditional_pairs").addElement(v.isWriteUnconditionalPairs() + ""));
            paired.addElement(new XMLW("paired_write_precision").addElement(v.getPairPrecision() + ""));
            paired.addElement(new XMLW("strip_nulls_from_paired_file").addElement(v.isStripNullMembers() + ""));
            paired.addElement(new XMLW("raw_pairs_in_aggregated_res").addElement(v.isStoreRawPairsInAggregatedRes() + ""));
//            if(v.hasPairedStartLeadHour()) {
//                paired.addElement(new XMLW("paired_start_lead_hour").addElement(v.getPairedStartLeadHour() + ""));
//            }
            unit.addElement(paired);
            //Verification metrics
            if(v.hasMetrics()) {
                XMLW mets = new XMLW("metrics");
                unit.addElement(mets);
                Vector<Metric> m = v.getMetrics();
                int length = m.size();
                for(int j = 0; j < length; j++) {
                    XMLW next = new XMLW("metric");
                    mets.addElement(next);
                    writeMetric(next,m.get(j));
                }
            }
        }
        //Write the aggregation units next
        if(agg.size() > 0) {
            int length = agg.size();
            for(int i = 0; i < length; i++) {
                AggregationUnit next = agg.get(i);
                //Only write if verification units exist
                if (next.getVerificationUnitCount() > 0) {
                    XMLW aggUnit = new XMLW("aggregation_unit");
                    doc.addElement(aggUnit);
                    aggUnit.addElement(new XMLW("name").addElement(next.getAggregationID()));
                    ArrayList<VerificationUnit> vr = next.getVerificationUnits();
                    //Multiple verification units defined
                    for (VerificationUnit v : vr) {
                        aggUnit.addElement(new XMLW("unit_id").addElement(v.toString()));
                    }
                    //Write weights
                    if (next.hasWeights()) {
                        String s = getDoubleArrayString(EVSUtilities.toDoubleArray(next.getWeights()), 8);
                        aggUnit.addElement(new XMLW("weights").addElement(s));
                    }
                    
                    //Path to the output folder
                    XMLW output = new XMLW("output_data");
                    if (next.hasOutputData()) {
                        File f = (File) next.getOutputData().getData();
                        aggUnit.addElement(new XMLW("output_data_location").addElement(f.getPath()));  //JB @ August 2012 .getAbsolutePath()
                    }
                    WriteOption write = next.getWriteOptions();
                    output.addElement(new XMLW("output_graphics_type").addElement(write.getStringID())); //JB @ August 2012 .getAbsolutePath()
                    aggUnit.addElement(output);      
                    aggUnit.addElement(new XMLW("pool_pairs").addElement(next.isPoolPairs() + ""));
                    aggUnit.addElement(new XMLW("statistically_dependent").addElement(next.isStatDependent() + ""));
                    aggUnit.addElement(new XMLW("bootstrap").addElement(next.isBootstrap() + ""));
                }
            }
        }
        BufferedOutputStream b = null;
        try {
            b = new BufferedOutputStream(new FileOutputStream(projectFile));
            doc.output(b);
        }
        catch(Throwable e) {
            e.printStackTrace();
            throw new IOException(e.getMessage());
        }
        finally {
            if(b != null) {
                b.close();
            }
        }
    }
    
/*******************************************************************************
 *                                                                             *
 *                                PRIVATE METHODS                              *
 *                                                                             *
 ******************************************************************************/    
    
    /**
     * Reads a returns a single verification unit.  Any value conditions should
     * be read separately as they cannot be set until all required units have been 
     * defined (they may reference other units).  The specified node is a node
     * with the <verification_unit> tag.
     *  
     * @param unitNode the verification unit node
     * @return a verification unit
     */
    
    private static VerificationUnit readVerificationUnit(Node unitNode) throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        VerificationUnit vu = null;
        NodeList children = unitNode.getChildNodes();
        int len = children.getLength();
        for(int j = 0; j < len; j++) {
            Node current = children.item(j);
            String name = current.getNodeName();
            NodeList ids = current.getChildNodes();
            int len2 = ids.getLength();
            //Unit identifiers
            if(name.equals("identifiers")) {
                String[] idents = readIdentifiers(current);
                //Attempt construction
                vu = new VerificationUnit(idents[0],idents[1],idents[2]);
            }
            //Input data
            else if(name.equals("input_data")) {
                String observedLoc="", climLoc="", forecastTime="", observedTime="", 
                        climateTime="", allObs="", applyDateToClim="", applyValToClim="";
                Vector<String> forecastLoc = new Vector();
                for(int k = 0; k < len2; k++) {
                    boolean notNull = ids.item(k).getFirstChild() != null;
                    String nextName = ids.item(k).getNodeName();
                    if(nextName.equals("forecast_data_location") && notNull) {
                        NodeList fileList = ids.item(k).getChildNodes();
                        int len3 = fileList.getLength();
                        //Each node is a file path or a folder
                        for(int m = 0; m < len3; m++) {
                            if(fileList.item(m).getNodeName().equals("file")) {
                                forecastLoc.add(fileList.item(m).getFirstChild().getNodeValue());
                            }
                        }
                    } else if(nextName.equals("observed_data_location") && notNull) {
                        observedLoc = ids.item(k).getFirstChild().getNodeValue();
                    } else if(nextName.equals("climatology_data_location") && notNull) {
                        climLoc = ids.item(k).getFirstChild().getNodeValue();
                    } else if(nextName.equals("forecast_time_system") && notNull) {
                        forecastTime = ids.item(k).getFirstChild().getNodeValue();
                    } else if(nextName.equals("observed_time_system") && notNull) {
                        observedTime = ids.item(k).getFirstChild().getNodeValue();
                    } else if(nextName.equals("climate_time_system") && notNull) {
                        climateTime = ids.item(k).getFirstChild().getNodeValue();
                    } else if(nextName.equals("forecast_support")) {
                        vu.setSupport(Support.FORECAST_SUPPORT,readSupport(ids.item(k)));
                    } else if(nextName.equals("observed_support")) {
                        vu.setSupport(Support.OBSERVED_SUPPORT,readSupport(ids.item(k)));
                    } else if(nextName.equals("use_all_observations_for_climatology")) {
                        allObs=ids.item(k).getFirstChild().getNodeValue();
                    } else if(nextName.equals("apply_date_cond_to_climatology")) {
                        applyDateToClim=ids.item(k).getFirstChild().getNodeValue();
                    } else if(nextName.equals("apply_value_cond_to_climatology")) {
                        applyValToClim=ids.item(k).getFirstChild().getNodeValue();
                    } else if(nextName.equals("forecast_date_format") && notNull) {
                        vu.setForcDateFormat(ids.item(k).getFirstChild().getNodeValue());
                    } else if(nextName.equals("observed_date_format") && notNull) {
                        vu.setObsDateFormat(ids.item(k).getFirstChild().getNodeValue());
                    } else if(nextName.equals("forecast_file_type") && notNull) {
                        vu.setForecastFileType(FileIO.getFileTypeIDForString(ids.item(k).getFirstChild().getNodeValue()));
                    } else if(nextName.equals("observed_file_type") && notNull) {
                        vu.setObservedFileType(FileIO.getFileTypeIDForString(ids.item(k).getFirstChild().getNodeValue()));
                    } else if(nextName.equals("global_null_value")) {
                        vu.setNullValue(new Double(ids.item(k).getFirstChild().getNodeValue()));
                    } else if(nextName.equals("forecast_file_location_id") && notNull) {
                        vu.setForecastFileLocationID(ids.item(k).getFirstChild().getNodeValue());   
                    } else if(nextName.equals("observed_file_location_id") && notNull) {
                        vu.setObservedFileLocationID(ids.item(k).getFirstChild().getNodeValue());   
                    } else if(nextName.equals("forecast_file_variable_id") && notNull) {
                        vu.setForecastFileVariableID(ids.item(k).getFirstChild().getNodeValue());   
                    } else if(nextName.equals("observed_file_variable_id")&& notNull) {
                        vu.setObservedFileVariableID(ids.item(k).getFirstChild().getNodeValue());   
                    }     
                }
                try {
                    int length = forecastLoc.size();
                    if(length>0) {
                        if(length ==1) {
                            vu.setForecastData(new FileDataSource(new File(forecastLoc.get(0))));
                        } 
                        else {
                            File[] files = new File[length];
                            for(int k = 0; k < length; k++) {
                                files[k] = new File(forecastLoc.get(k));
                            }
                            vu.setForecastData(new FileArrayDataSource(files));
                        }
                    }
                    if(!observedLoc.equals("")) {
                        vu.setObservedData(new FileDataSource(new File(observedLoc)));
                    }
                    if(!allObs.equals("")) {
                        vu.setUseFullClimatology(allObs.equalsIgnoreCase("true"));
                    }
                    if(!applyDateToClim.equals("")) {
                        vu.setApplyDateCondToClim(applyDateToClim.equalsIgnoreCase("true"));
                    }
                    if(!applyValToClim.equals("")) {
                        vu.setApplyValueCondToClim(applyValToClim.equalsIgnoreCase("true"));
                    }
                    
//                    if(!climLoc.equals("")) {
//                        vu.setClimatologyData(new FileDataSource(new File(climLoc)));
//                    }
                } catch(Exception e) {
                    e.printStackTrace();
                    System.out.println("Errors reading one or more data files from the project file.");
                }
                if(!forecastTime.equals("")) {
                    vu.setForecastTimeSystem(GlobalUnitsReader.getTimeSystem(forecastTime));
                }
                if(!observedTime.equals("")) {
                    vu.setObservedTimeSystem(GlobalUnitsReader.getTimeSystem(observedTime));
                }
//                if(!climateTime.equals("")) {
//                    vu.setClimatologyTimeSystem(GlobalUnitsReader.getTimeSystem(climateTime));
//                }
            }
            //Parameters of the verification window
            else if(name.equals("verification_window")) {
                Calendar startDate = null, endDate = null;
                //Stores of date elements to exclude from the verification
                TreeMap<DateElement,Vector<Integer>> dateExclusions = 
                        new TreeMap<DateElement,Vector<Integer>>();
                
                for(int k = 0; k < len2; k++) {
                    String nextName = ids.item(k).getNodeName();
                    //Start date
                    if(nextName.equals("start_date")) {
                        startDate = readDate(ids.item(k));                        
                    }
                    //End date
                    else if(nextName.equals("end_date")) {
                        endDate = readDate(ids.item(k));  
                    }
                    //Date exclusions
                    else if(nextName.equals("date_conditions")) {
                        dateExclusions = readDateConditionPars(ids.item(k));
                    } 
                    //Time system for verification window
                    else if(nextName.equals("window_in_valid_time")) {
                        vu.setVerifWindowInValidTime(new Boolean(
                                ids.item(k).getFirstChild().getNodeValue()));
                    }
                }
                //Set the dates and date conditions
                if(startDate != null) {
                    vu.setStartDate(startDate);
                }
                if(endDate != null) {
                    vu.setEndDate(endDate);
                }
                //Set any date exclusions
                if(dateExclusions.size()>0) {
                    DateCondition dc = null;
                    Iterator it = dateExclusions.keySet().iterator();
                    while(it.hasNext()) {
                        DateElement key = (DateElement)it.next();
                        Vector<Integer> v = dateExclusions.get(key);
                        if (dc == null) {
                            dc = new DateCondition(vu,key,v);
                        }
                        dc.setCondition(key,v);
                    }
                    vu.setDateCondition(dc);
                }
                
                //Set the forecast lead times and aggregation (optional)
                int aggLeadP=0;
                Double leadFirst=null,leadLast=null;
                Integer aggStart = null;
                Double aggLeadStart = null;
                String leadPU ="", aggLeadPU="";
                for(int k = 0; k < len2; k++) {
                    String nextName = ids.item(k).getNodeName();
                    if(nextName.equals("first_lead_period")) {
                        leadFirst = new Double(ids.item(k).getFirstChild().getNodeValue());
                    } else if(nextName.equals("last_lead_period")) {
                        leadLast = new Double(ids.item(k).getFirstChild().getNodeValue());
                    } else if(nextName.equals("forecast_lead_period")) {  //Backwards compatibility
                        leadLast = new Double(ids.item(k).getFirstChild().getNodeValue());
                    } else if(nextName.equals("forecast_lead_units")) {
                        leadPU = ids.item(k).getFirstChild().getNodeValue();
                    } else if(nextName.equals("aggregation_lead_period")) {
                        String val = "";
                        try {
                            val = ids.item(k).getFirstChild().getNodeValue();
                        } catch(Exception e) {
                            System.out.println("No aggregation period specified.");
                        }
                        if(!val.equals("")) {
                            aggLeadP = new Integer(val);
                        }
                    } else if(nextName.equals("aggregation_lead_units")) {
                        //Set if aggregation period specified
                        if(aggLeadP > 0) {
                            aggLeadPU = ids.item(k).getFirstChild().getNodeValue();
                        }
                    } else if(nextName.equals("aggregation_function")) {
                        String func = ids.item(k).getFirstChild().getNodeValue()+"";
                        vu.setTemporalAggFunc(FunctionLibrary.getVectorFunction(func));
                    } else if(nextName.equals("sample_size_constraint")) {
                        String val = ids.item(k).getFirstChild().getNodeValue();
                        if(!val.equals("")) {
                            vu.setSampleSizeConstraint(new Double(val));
                        }
                    } else if(nextName.equals("aggregation_start_time_UTC")) {
                        String val = ids.item(k).getFirstChild().getNodeValue();
                        if(!val.equals("")) {
                            aggStart=new Integer(val);
                        }
                    } else if(nextName.equals("aggregation_start_lead_hour")) {
                        String val = ids.item(k).getFirstChild().getNodeValue();
                        if(!val.equals("")) {
                            aggLeadStart=new Double(val);
                        }
                    }
                }
                if(leadFirst!=null && leadLast!=null) {
                    vu.setLeadTimes(leadFirst,leadLast,leadPU);
                }
                if(aggLeadP>0) {
                    vu.setResolution(aggLeadP,aggLeadPU);
                    vu.setAggregationStartHourUTC(aggStart);
                }
                vu.setAggregationStartLeadHour(aggLeadStart);
            }
            //Output data source
            else if(name.equals("output_data")) {
                NodeList nodes = current.getChildNodes();
                int len3 = nodes.getLength();
                for (int k = 0; k < len3; k++) {
                    String nextName = nodes.item(k).getNodeName();
                    Node node = nodes.item(k).getFirstChild();
                    if (nextName.equals("output_data_location")) {
                        String item = node.getNodeValue();
                        if (item != null) {
                            vu.setOutputData(new FileDataSource(new File(item)));
                        }
                    } else if (nextName.equals("output_graphics_type")) {
                        if (node != null) {
                            vu.setWriteOptions(new WriteOption(node.getNodeValue()));
                        }
                    }      
                }
            }
            //Output data source backwards compatibility
            else if(name.equals("output_data_location") && current.getFirstChild().getNodeValue() != null) {
                 vu.setOutputData(new FileDataSource(new File(current.getFirstChild().getNodeValue())));
            }
            //Paired data source
            else if(name.equals("paired_data")) {
                NodeList nodes = current.getChildNodes();
                int len3 = nodes.getLength();
                if(len3==1) {
                    String item = nodes.item(0).getNodeValue();
                    if(item!=null) {
                        vu.setPairedDataSource(new PairedDataSource(new FileDataSource(new File(item))));            
                    }
                }
                else {
                    for (int k = 0; k < len3; k++) {
                        String nextName = nodes.item(k).getNodeName();
                        Node node = nodes.item(k).getFirstChild();
                        if (nextName.equals("paired_data_location")) {
                            if (node != null) {
                                String item = node.getNodeValue();
                                if (item != null && !item.equals("")) {
                                    vu.setPairedDataSource(new PairedDataSource(new FileDataSource(new File(item))));
                                }
                            }
                        } else if(nextName.equals("eliminate_duplicates")) {
                            String item = node.getNodeValue();
                            if (item != null) {
                                vu.setEliminateDuplicates(item.equalsIgnoreCase("true"));
                            }
                        } else if(nextName.equals("write_conditional_pairs")) {
                            String item = node.getNodeValue();
                            if (item != null) {
                                vu.setWriteConditionalPairs(item.equalsIgnoreCase("true"));
                            }
                        } else if(nextName.equals("write_unconditional_pairs")) {
                            String item = node.getNodeValue();
                            if (item != null) {
                                vu.setWriteUnconditionalPairs(item.equalsIgnoreCase("true"));
                            }
                        } else if(nextName.equals("paired_write_precision")) {
                            String item = node.getNodeValue();
                            if (item != null) {
                                try {
                                    vu.setPairPrecision(new Integer(item));
                                } catch(NumberFormatException e) {
                                    throw new IllegalArgumentException("Unexpected value for paired file write precision of unit '"+vu+"': enter an integer number of decimal places.");
                                }
                            }
                        } else if(nextName.equals("strip_nulls_from_paired_file")) {
                            String item = node.getNodeValue();
                            if (item != null) {
                                vu.setStripNullMembers(item.equalsIgnoreCase("true"));
                            }
                        } else if (nextName.equals("raw_pairs_in_aggregated_res")) {
                            String item = node.getNodeValue();
                            if (item != null) {
                                vu.setStoreRawPairsInAggregatedRes(item.equalsIgnoreCase("true"));
                            }
                        }                            
//                            else if (nextName.equals("paired_start_lead_hour")) {
//                            String val = ids.item(k).getFirstChild().getNodeValue();
//                            if (!val.equals("")) {
//                                vu.setPairedStartLeadHour(new Double(val));
//                            }
//                        }
                    }
                }
            }
            //Read the metrics from file
            else if(name.equals("metrics")) {
                for(int k = 0; k < len2; k++) {
                    String nextName = ids.item(k).getNodeName();
                    if(nextName.equals("metric")) {
                        Metric m = readMetric(ids.item(k));
                        if(m != null) {
                            vu.addMetric(m);
                        }
                    }
                }
            }
        }
        return vu;        
    }
    
    /**
     * Takes a node with verification unit identifiers as the children and 
     * returns the identifiers in the following order:
     *
     * Location identifier
     * Variable identifier
     * Additional identifier
     *
     * If the additional identifier is undefined a string of length 0 is returned
     * at index 2 in the returned array.
     *
     * @param parent the identifiers node
     * @return the identifiers
     */
    
    private static String[] readIdentifiers(Node parent) {
        NodeList ids = parent.getChildNodes();
        String[] idents = new String[3];
        int len2 = ids.getLength();
        for(int k = 0; k < len2; k++) {
            String nextName = ids.item(k).getNodeName();
            //First option is for backwards compatibility
            if(nextName.equals("river_segment")) {
                idents[0] = ids.item(k).getFirstChild().getNodeValue();
            }
            else if(nextName.equals("location_id")) {
                idents[0] = ids.item(k).getFirstChild().getNodeValue();
            } else if(nextName.startsWith("environmental_variable")) {  //startsWith for backwards compatibility
                idents[1] = ids.item(k).getFirstChild().getNodeValue();
            } else if(nextName.equals("additional_id")) {
                Node child = ids.item(k).getFirstChild();
                String additional = "";
                if(child != null) {
                    additional = child.getNodeValue();
                }
                idents[2] = additional;
            }
        }
        return idents;
    }
    
    /**
     * Takes a node representing some support information returns a support object.
     *
     * @param supportNode the support node
     */
    
    private static TemporalSupport readSupport(Node supportNode) {
        NodeList suppList = supportNode.getChildNodes();
        int len = suppList.getLength();
        String aggFunc = null;
        String aggPeriod = null;
        String aggPeriodUnits = null;
        String existingAttUnits = null;
        String targetAttUnits = null;
        String attChangeMult = null;  //Multiplier for units changes not currently in the library
        String notes = "";
        for(int k = 0; k < len; k++) {
            String nxt = suppList.item(k).getNodeName();
            if(nxt.equals("statistic")) {  
                if(suppList.item(k).getFirstChild() == null) {
                    throw new IllegalArgumentException("Missing statistic for the support information.");
                }
                aggFunc = suppList.item(k).getFirstChild().getNodeValue();      
            }
            //Optional
            else if(nxt.equals("period") && suppList.item(k).getFirstChild() != null) {
                aggPeriod = suppList.item(k).getFirstChild().getNodeValue();   
            } 
            //Optional
            else if(nxt.equals("period_units") && suppList.item(k).getFirstChild() != null) {
                aggPeriodUnits = suppList.item(k).getFirstChild().getNodeValue();
            } else if(nxt.equals("existing_attribute_units") || nxt.equals("attribute_units")) {  //Backwards compatible
                if(suppList.item(k).getFirstChild() == null) {
                    throw new IllegalArgumentException("Missing attribute units for the support information.");
                }
                existingAttUnits = suppList.item(k).getFirstChild().getNodeValue();
            } else if(nxt.equals("target_attribute_units")) {  //Backwards compatible
                if(suppList.item(k).getFirstChild() != null) {
                    targetAttUnits = suppList.item(k).getFirstChild().getNodeValue();
                }
            } else if(nxt.equals("attribute_units_function")) {
                if(suppList.item(k).getFirstChild() == null) {
                    throw new IllegalArgumentException("Missing attribute units function for the support information.");
                }
                attChangeMult = suppList.item(k).getFirstChild().getNodeValue();
            }
            //Optional
            else if(nxt.equals("notes") && suppList.item(k).getFirstChild() != null) {
                notes = suppList.item(k).getFirstChild().getNodeValue();   
            }
        }
        
        //Get the units change function if the target support is not null
        Function func = null;
        //Multiplier
        if(attChangeMult!=null && !attChangeMult.equals("")) {
            Double d = new Double(attChangeMult);
            //Backwards compatibility where a change multiplier exists but no target units are defined
            if(targetAttUnits==null) {
                //Support the few cases that might be encountered in old project files
                //These are only relevant to NWS users
                String s = d+"";
                if(d==25.4) {
                    existingAttUnits = "INCH";
                    targetAttUnits = "MILLIMETER";
                } else if(s.startsWith("0.0283")) {
                    existingAttUnits = "FEET CUBED/SECOND";
                    targetAttUnits = "METER CUBED/SECOND";
                } else if (d==1) {
                    targetAttUnits = existingAttUnits;
                } else {
                    targetAttUnits = "NONE"; 
                }
            }
            //No longer read the old default multiplier of 1.0, since the
            //multiplier is now an optional entry that is taken in precedent
            //to an explicit unit-to-unit conversion
            if(d!=1.0 && !MeasurementUnitsChangeLibrary.isInLibrary(existingAttUnits,targetAttUnits)) {
                func = FunctionLibrary.mult(d);
                System.out.println("Found custom multiplier for attribute units. " +
                        "This will be used to convert the existing attributes '"+existingAttUnits+"' to " +
                        "the new attribute units '"+targetAttUnits+"'.");
            }
        }
        TemporalSupport t = null;
        if(aggFunc==null) {
            throw new IllegalArgumentException("Specify a non-null aggregation function fot the temporal support object.");
        }
        if(aggFunc.equalsIgnoreCase("INSTANTANEOUS")) {
            t = new TemporalSupport(existingAttUnits);
        }
        else {
            t = new TemporalSupport(existingAttUnits,new Double(aggPeriod),aggPeriodUnits,aggFunc);
        }
        //Explicit target attribute units
        if(targetAttUnits!=null) {
            if(func==null) {
                func = MeasurementUnitsChangeLibrary.getMeasureUnitsChangeFunc(existingAttUnits,targetAttUnits);
            }
        }
        if(notes!=null) {
            t.setNotes(notes);
        }
        //Set the function and target attribute units
        if(func!=null || targetAttUnits != null) {
            t.setTargetMeasurementUnitsFunc(func,targetAttUnits);  //Throws an exception if one is null
        }
        return t;
    }
    
    /**
     * Takes a node representing a date element and reads the date.
     *
     * @param dateNode the date node (e.g. node <start_date>)
     * @return a date
     */
    
    private static Calendar readDate(Node dateNode) {
        NodeList dateList = dateNode.getChildNodes();
        int len3 = dateList.getLength();
        Calendar c = null;
        for(int m = 0; m < len3; m++) {
            String nxt = dateList.item(m).getNodeName();
            if(nxt.equals("year")) {  //Must have year
                c = Calendar.getInstance();
                c.setTimeZone(TimeZone.getTimeZone("UTC"));
                c.clear();
                int yr = new Integer(dateList.item(m).getFirstChild().getNodeValue());
                c.set(c.YEAR,yr);
            } else if(nxt.equals("month")) {
                int mo = new Integer(dateList.item(m).getFirstChild().getNodeValue());
                c.set(c.MONTH,mo);
            } else if(nxt.equals("day")) {
                int da = new Integer(dateList.item(m).getFirstChild().getNodeValue());
                c.set(c.DAY_OF_MONTH,da);
            }
        }
        return c;
    }
    
    /**
     * Reads any value conditions associated with the specified verification unit
     * node and returns the associated parameter values for each condition in a
     * vector of object arrays.  
     *
     * @param unitNode the verification unit node
     * @return the value condition parameters
     */
    
    private static Vector<Object[]> readValueConditionPars(Node unitNode) {
        NodeList children = unitNode.getChildNodes();
        int len = children.getLength();
        Vector<Object[]> valCon = null;
        //Iterate through the child nodes
        for(int j = 0; j < len; j++) {
            Node current = children.item(j);
            String name = current.getNodeName();
            NodeList ids = current.getChildNodes();
            int len2 = ids.getLength();
            //Parameters of the verification window
            if(name.equals("verification_window")) {
                for(int k = 0; k < len2; k++) {
                    String nextName = ids.item(k).getNodeName();
                    //Variable value exclusions
                    if(nextName.equals("value_conditions")) {
                        NodeList valList = ids.item(k).getChildNodes();
                        int len3 = valList.getLength();
                        valCon = new Vector();
                        //Iterate through each condition
                        for(int m = 0; m < len3; m++) {
                            String nxt = valList.item(m).getNodeName();
                            if(nxt.equals("condition")) {
                                //Parameters of condition
                                String id = null;
                                int type = 0;
                                String stName = null;
                                Double stCon = null;
                                DoubleProcedure[] conditions = null;
                                Double period = null;
                                String periodUnit = null;
                                VectorFunction periodStat = null;

                                //Obtain the parameters of the next condition
                                NodeList valList2 = valList.item(m).getChildNodes();
                                int len4 = valList2.getLength();
                                for(int n = 0; n < len4; n++) {
                                    String nxtPar = valList2.item(n).getNodeName();
                                    //Identifier
                                    if(nxtPar.equals("unit_id")) {
                                        id = valList2.item(n).getFirstChild().getNodeValue();
                                    }
                                    //Dataset to which the condition applies
                                    else if(nxtPar.equals("forecast_type")) {
                                        //True or false?
                                        String va = valList2.item(n).getFirstChild().getNodeValue();
                                        if(va.equalsIgnoreCase("true")) {
                                            type = ValueCondition.FORECAST_CONDITION;
                                        } else if(va.equalsIgnoreCase("false")) {
                                            type = ValueCondition.OBSERVED_CONDITION;
                                        }
                                    }
                                    //Statistic
                                    else if(nxtPar.equals("statistic")) {
                                        Node nVal = valList2.item(n).getFirstChild();
                                        if(nVal!= null) {
                                            stName = nVal.getNodeValue();
                                        }
                                    }
                                    //Constant for statistic
                                    else if(nxtPar.equals("statistic_constant")) {
                                        Node nVal = valList2.item(n).getFirstChild();
                                        if(nVal!= null) {
                                            stCon = new Double(nVal.getNodeValue());
                                        }
                                    }
                                    //Some of the remaining paramaters may be null
                                    //Period
                                    else if(nxtPar.equals("consecutive_period")) {
                                        Node nVal = valList2.item(n).getFirstChild();
                                        if(nVal != null) {
                                            period = new Double(nVal.getNodeValue());
                                        }
                                    }
                                    //Period units
                                    else if(nxtPar.equals("consecutive_period_units")) {
                                        Node nVal = valList2.item(n).getFirstChild();
                                        if(nVal!= null) {
                                            periodUnit = nVal.getNodeValue();
                                        }
                                    }
                                    //Period statistic
                                    else if(nxtPar.equals("consecutive_period_statistic")) {
                                        Node nVal = valList2.item(n).getFirstChild();
                                        if(nVal!= null) {
                                            periodStat = FunctionLibrary.getVectorFunction(nVal.getNodeValue());
                                        }
                                    }
                                    //Logical conditions and associated thresholds
                                    else if(nxtPar.equals("logical_conditions")) {
                                        NodeList log = valList2.item(n).getChildNodes();
                                        int logLength = log.getLength();
                                        if(logLength > 0) {
                                            Vector<DoubleProcedure> logAc = new Vector();  //Actual conditions constructed
                                            for(int p = 0; p < logLength; p++) {
                                                Node nextFunc = log.item(p);
                                                if(nextFunc.getNodeName().equals("function")) {
                                                    String funcName = nextFunc.getAttributes().item(0).getNodeValue();
                                                    String funcVal = nextFunc.getAttributes().item(1).getNodeValue();
                                                    //Attempt to construct the function
                                                    logAc.add(FunctionLibrary.getDoubleProcedure(funcName,new Double(funcVal)));
                                                }
                                            }
                                            conditions = logAc.toArray(new DoubleProcedure[logAc.size()]);
                                        }
                                    }
                                }
                                //Construct the statistic
                                Function stat = null;
                                try {
                                    stat = FunctionLibrary.getUnaryFunction(stName);
                                } catch (Exception e) {
                                    try {
                                        if(stCon==null) {
                                            stat = FunctionLibrary.getVectorFunction(stName);
                                        } else {
                                            stat = FunctionLibrary.getVectorFunction(stName,stCon);
                                        }
                                    } catch (Exception f) {
                                        f.printStackTrace();
                                        throw new IllegalArgumentException("Unrecognized statistic '" + stName + "'.");
                                    }
                                }

                                //Backwards compatibility for when a vector function for ValueCondition.OBSERVED_CONDITION
                                //implied a statistic over a period
                                if(type==ValueCondition.OBSERVED_CONDITION && (stat instanceof VectorFunction)) {
                                    valCon.add(new Object[]{id,type,FunctionLibrary.assign,conditions,period,periodUnit,stat});
                                }
                                //More recently a separate explicit function has been introduced for the window statistic
                                //i.e. the "stat" function is no longer used for two different things depending on whether the
                                //condition is an ValueCondition.OBSERVED_CONDITION or ValueCondition.FORECAST_CONDITION
                                else {
                                    //Store the value condition parameters without referencing the verification units
                                    //as these may not have been read in yet
                                    valCon.add(new Object[]{id,type,stat,conditions,period,periodUnit,periodStat});
                                }
                            }
                        }
                    }
                }
            }
        }
        return valCon;
    }
    
    /**
     * Reads and returns the parameters associated with a date condition from a
     * node representing a date condition (i.e. with the <date_conditions> tag)  
     *
     * @param dateNode the date conditions node
     * @return the date condition parameters
     */
    
    private static TreeMap<DateElement,Vector<Integer>> readDateConditionPars(Node dateNode) {
        NodeList dateList = dateNode.getChildNodes();
        int outer = dateList.getLength();
        TreeMap<DateElement,Vector<Integer>> returnMe = null;
        if (outer > 0) {
            for (int i = 0; i < outer; i++) {
                String nxtOuter = dateList.item(i).getNodeName();
                if (nxtOuter.equals("valid_time")) {
                    if(returnMe!=null) {
                        returnMe.putAll(readDateConditionParsElements(dateList.item(i), true));
                    } else {
                        returnMe = readDateConditionParsElements(dateList.item(i), true);
                    }
                } else if (nxtOuter.equals("basis_time")) {
                    if(returnMe!=null) {
                        returnMe.putAll(readDateConditionParsElements(dateList.item(i), false));
                    } else {
                        returnMe = readDateConditionParsElements(dateList.item(i), false);
                    }
                } 
                //Backwards compatibility
                else if(nxtOuter.startsWith("exclude")) {
                    returnMe = readDateConditionParsElements(dateNode, true); break;
                }
            }
        }
        return returnMe;
    }    
    
    /**
     * Reads and returns the parameters associated with a date condition from a
     * node representing a date condition (i.e. with the <date_conditions> tag)  
     *
     * @param dateNode the date conditions node
     * @return the date condition parameters
     */
    
    private static TreeMap<DateElement,Vector<Integer>> 
            readDateConditionParsElements(Node dateNode, boolean isValidTime) {
        NodeList dateList = dateNode.getChildNodes();
        int len3 = dateList.getLength();
        TreeMap<DateElement,Vector<Integer>> dateExclusions = 
                new TreeMap<DateElement,Vector<Integer>>();       
        for(int m = 0; m < len3; m++) {
            String nxt = dateList.item(m).getNodeName();
            if(nxt.equals("exclude_years")) {
                Vector excludeYears = new Vector();
                String value = dateList.item(m).getFirstChild().getNodeValue();
                StringTokenizer t = new StringTokenizer(value,", \t\n\r\f",false);
                while(t.hasMoreTokens()) {
                    excludeYears.add(new Integer(t.nextToken()));
                }
                dateExclusions.put(new DateElement(Calendar.YEAR,isValidTime),excludeYears);
            } else if(nxt.equals("exclude_months")) {
                Vector excludeMonths = new Vector();
                String value = dateList.item(m).getFirstChild().getNodeValue();
                StringTokenizer t = new StringTokenizer(value,", \t\n\r\f",false);
                while(t.hasMoreTokens()) {
                    excludeMonths.add(new Integer(t.nextToken()));
                }
                dateExclusions.put(new DateElement(Calendar.MONTH,isValidTime),excludeMonths);
            } else if(nxt.equals("exclude_weeks")) {
                Vector excludeWeeks = new Vector();
                String value = dateList.item(m).getFirstChild().getNodeValue();
                StringTokenizer t = new StringTokenizer(value,", \t\n\r\f",false);
                while(t.hasMoreTokens()) {
                    excludeWeeks.add(new Integer(t.nextToken()));
                }
                dateExclusions.put(new DateElement(Calendar.WEEK_OF_YEAR,isValidTime),excludeWeeks);
            } else if(nxt.equals("exclude_days_of_week")) {
                Vector excludeDays = new Vector();
                String value = dateList.item(m).getFirstChild().getNodeValue();
                StringTokenizer t = new StringTokenizer(value,", \t\n\r\f",false);
                while(t.hasMoreTokens()) {
                    excludeDays.add(new Integer(t.nextToken()));
                }
                dateExclusions.put(new DateElement(Calendar.DAY_OF_WEEK,isValidTime),excludeDays);
            }  else if(nxt.equals("exclude_hours_of_day_UTC")) {
                Vector excludeHours = new Vector();
                String value = dateList.item(m).getFirstChild().getNodeValue();
                StringTokenizer t = new StringTokenizer(value,", \t\n\r\f",false);
                while(t.hasMoreTokens()) {
                    excludeHours.add(new Integer(t.nextToken()));
                }
                dateExclusions.put(new DateElement(Calendar.HOUR_OF_DAY,isValidTime),excludeHours);
            }
        }
        return dateExclusions;
    }        
    
    /**
     * Reads and returns a verification metric from the specified metric node, 
     * represented by the <metric> tag.
     *
     * @param metricNode the metric node
     * @return the metric with associated parameter values
     */
    
    private static Metric readMetric(Node metricNode) throws ClassNotFoundException,
            NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        String metName = "";
        TreeMap<Integer,MetricParameter> pars = new TreeMap();  //Parameters indexed by type
        
        NodeList n = metricNode.getChildNodes();
        int len = n.getLength();
        for(int i = 0; i < len; i++) {
            String nextName = n.item(i).getNodeName();

            //Name of the metric
            if(nextName.equals("name")) {
                metName = n.item(i).getFirstChild().getNodeValue();
            }
            //Double thresholds
            else if(nextName.equals("double_array_parameter")) {
                String thresh = n.item(i).getFirstChild().getNodeValue();
                pars.put(MetricParameter.DOUBLE_ARRAY_PARAMETER,
                        new DoubleArrayParameter(getDoubleArray(thresh)));
            }
            //Probability thresholds
            else if(nextName.equals("probability_array_parameter")) {
                String thresh = n.item(i).getFirstChild().getNodeValue();
                pars.put(MetricParameter.PROBABILITY_ARRAY_PARAMETER,
                        new ProbabilityArrayParameter(getDoubleArray(thresh)));
            }
            //Forecast type
            else if(nextName.equals("forecast_type_parameter")) {
                Node refNode = n.item(i).getFirstChild();
                if(refNode != null) {
                    ForecastTypeParameter fType = new ForecastTypeParameter();
//                    StringTokenizer t = new StringTokenizer(refNode.getNodeValue(),", \t\n\r\f",false);
//                    //Add any additional forecast types
//                    while(t.hasMoreTokens()) {
//                        String nextToken = t.nextToken();
//                        if(nextToken.equals("reference")) {
//                            fType.addType(ForecastTypeParameter.REFERENCE_FORECAST);
//                        } else if(nextToken.equals("skill")) {
//                            fType.addType(ForecastTypeParameter.SKILL);
//                        }
//                    }
                    pars.put(MetricParameter.FORECAST_TYPE_PARAMETER,fType);
                }
            }
            //Reference forecasts in skill calculation
            else if(nextName.equals("reference_forecast_parameter")) {
                Node refNode = n.item(i).getFirstChild();
                ReferenceForecastParameter rType = new ReferenceForecastParameter();
                if(refNode != null) {
                    rType.setRefForecast(refNode.getNodeValue());
                }
                pars.put(MetricParameter.REFERENCE_FORECAST_PARAMETER,rType);
            }
            //Event threshold
            //Condition for the threshold
            else if(nextName.equals("threshold_condition")) {
                Node refNode = n.item(i).getFirstChild();
                if(refNode != null) {
                    String nodeValue = refNode.getNodeValue();
                    if(nodeValue.equals("isLess")) {
                        pars.put(MetricParameter.INTEGER_PARAMETER,
                                new IntegerParameter(DoubleProcedureParameter.LESS_THAN));
                    } else if(nodeValue.equals("isGreater")) {
                        pars.put(MetricParameter.INTEGER_PARAMETER,
                                new IntegerParameter(DoubleProcedureParameter.GREATER_THAN));
                    } else if(nodeValue.equals("isLessEqual")) {
                        pars.put(MetricParameter.INTEGER_PARAMETER,
                                new IntegerParameter(DoubleProcedureParameter.LESS_EQUAL));
                    } else if(nodeValue.equals("isGreaterEqual")) {
                        pars.put(MetricParameter.INTEGER_PARAMETER,
                                new IntegerParameter(DoubleProcedureParameter.GREATER_EQUAL));
                    } else if(nodeValue.equals("isBetween")) {
                        pars.put(MetricParameter.INTEGER_PARAMETER,
                                new IntegerParameter(DoubleProcedureParameter.BETWEEN));
                    }
                }
            }
            //Decomposition of score
            else if(nextName.equals("decompose_parameter")) {
                Node val = n.item(i).getFirstChild();
                if(val != null) {
                    String v = val.getNodeValue();
                    int type;
                    if(v.equalsIgnoreCase(DecomposableScore.CALIBRATION_REFINEMENT_STRING) ||
                            v.equalsIgnoreCase("true")) {  //Backwards compatibility
                        type = DecomposableScore.CALIBRATION_REFINEMENT;
                    } else if(v.equalsIgnoreCase(DecomposableScore.LIKELIHOOD_BASE_RATE_STRING)) {
                        type = DecomposableScore.LIKELIHOOD_BASE_RATE;
                    } else if(v.equalsIgnoreCase(DecomposableScore.CR_AND_LBR_STRING)) {
                        type = DecomposableScore.CR_AND_LBR;
                    } else {
                        type = DecomposableScore.NONE;
                    }      
                    pars.put(MetricParameter.DECOMPOSE_PARAMETER,new DecomposeParameter(type));
                }
            }
            //ROC points
            else if(nextName.equals("roc_points_parameter")) {
                Node val = n.item(i).getFirstChild();
                if(val != null) {
                    pars.put(MetricParameter.ROC_POINTS_PARAMETER,
                            new ROCPointsParameter(new Integer(val.getNodeValue())));
                }
            }
            //Fitted ROC
            else if(nextName.equals("fitted_roc_parameter")) {
                Node val = n.item(i).getFirstChild();
                if(val != null) {
                    pars.put(MetricParameter.FITTED_ROC_PARAMETER,
                            new FittedROCParameter(val.getNodeValue().equalsIgnoreCase("true")));
                }
            }
            //Fitted ROC
            else if(nextName.equals("fitted_auc_parameter")) {
                Node val = n.item(i).getFirstChild();
                if(val != null) {
                    pars.put(MetricParameter.FITTED_AUC_PARAMETER,
                            new FittedAUCParameter(val.getNodeValue().equalsIgnoreCase("true")));
                }
            }
            //ROC score points
            else if(nextName.equals("roc_score_points_parameter")) {
                Node val = n.item(i).getFirstChild();
                if(val != null) {
                    pars.put(MetricParameter.ROC_SCORE_POINTS_PARAMETER,
                            new ROCScorePointsParameter(new Integer(val.getNodeValue())));
                }
            }
            //ROC score method parameter
            else if(nextName.equals("roc_score_method_parameter")) {
                Node val = n.item(i).getFirstChild();
                if(val != null) {
                    //Method
                    String s = val.getNodeValue();
                    int method = 0;
                    if(s.equalsIgnoreCase("trapezoid")) {
                        method = ROCScoreMethodParameter.TRAPEZOID;
                    } else if(s.equalsIgnoreCase("mason_graham")) {
                        method = ROCScoreMethodParameter.MASON_GRAHAM;
                    } else {
                        throw new IllegalArgumentException("Unrecognized method for computing the ROC score: "+s+".");
                    }
                    pars.put(MetricParameter.ROC_SCORE_METHOD_PARAMETER,
                            new ROCScoreMethodParameter(method));
                }
            }
            //Reliability points
            else if(nextName.equals("reliability_points_parameter")) {
                Node val = n.item(i).getFirstChild();
                if(val != null) {
                    pars.put(MetricParameter.RELIABILITY_POINTS_PARAMETER,
                            new ReliabilityPointsParameter(new Integer(val.getNodeValue())));
                }
            }
            //Spread-bias points
            else if(nextName.equals("spread_bias_points_parameter")) {
                Node val = n.item(i).getFirstChild();
                if(val != null) {
                    pars.put(MetricParameter.SPREAD_BIAS_POINTS_PARAMETER,
                            new SpreadBiasPointsParameter(new Integer(val.getNodeValue())));
                }
            }
            //Centered spread-bias plot
            else if(nextName.equals("central_spread_bias_parameter")) {
                Node val = n.item(i).getFirstChild();
                if(val != null) {
                    pars.put(MetricParameter.CENTRAL_SPREAD_BIAS_PARAMETER,
                            new CentralSpreadBiasParameter(val.getNodeValue().equalsIgnoreCase("true")));
                }
            }
            //Rank histogram frequencies
            else if(nextName.equals("rank_hist_sample_parameter")) {
                Node val = n.item(i).getFirstChild();
                if(val != null) {
                    pars.put(MetricParameter.RANK_HIST_SAMPLE_PARAMETER,
                            new RankHistSampleParameter(new Boolean(val.getNodeValue())));
                }
            }
            //MCR points parameter
            else if(nextName.equals("mcr_points_parameter")) {
                Node val = n.item(i).getFirstChild();
                if(val != null) {
                    pars.put(MetricParameter.MCR_POINTS_PARAMETER,new MCRPointsParameter(
                            new Integer(val.getNodeValue())));
                }
            }
            //CE points parameter
            else if(nextName.equals("mep_points_parameter")) {
                Node val = n.item(i).getFirstChild();
                if(val != null) {
                    pars.put(MetricParameter.MEP_POINTS_PARAMETER,new MEPPointsParameter(
                            new Integer(val.getNodeValue())));
                }
            }
            //Box points parameter: pooled boxes
            else if(nextName.equals("box_pooled_lead_points_parameter")) {
                Node val = n.item(i).getFirstChild();
                if(val != null) {
                    pars.put(MetricParameter.BOX_POOLED_LEAD_POINTS_PARAMETER,
                            new BoxPooledLeadPointsParameter(new Integer(val.getNodeValue())));
                }
            }
            //Box points parameter: unpooled boxes
            else if(nextName.equals("box_unpooled_points_parameter")) {
                Node val = n.item(i).getFirstChild();
                if(val != null) {
                    pars.put(MetricParameter.BOX_UNPOOLED_POINTS_PARAMETER,
                            new BoxUnpooledPointsParameter(new Integer(val.getNodeValue())));
                }
            }
            //Box points parameter: unpooled boxes by size of obs
            else if(nextName.equals("box_unpooled_obs_points_parameter")) {
                Node val = n.item(i).getFirstChild();
                if(val != null) {
                    pars.put(MetricParameter.BOX_UNPOOLED_OBS_POINTS_PARAMETER,
                            new BoxUnpooledObsPointsParameter(new Integer(val.getNodeValue())));
                }
            }
            //Use of unconditional pairs
            else if(nextName.equals("unconditional_parameter")) {
                Node val = n.item(i).getFirstChild();
                if(val != null) {
                    pars.put(MetricParameter.UNCONDITIONAL_PARAMETER,new UnconditionalParameter(
                            val.getNodeValue().equalsIgnoreCase("true")));
                }
            }
            //Use of unconditional pairs
            else if(nextName.equals("equal_samples_parameter")) {
                Node val = n.item(i).getFirstChild();
                if(val != null) {
                    pars.put(MetricParameter.EQUAL_SAMPLES_PARAMETER,new EqualSamplesParameter(
                            val.getNodeValue().equalsIgnoreCase("true")));
                }
            }
            //Static option to set CRPS method
            else if(nextName.equals("crps_method")) {
                Node val = n.item(i).getFirstChild();
                if(val != null) {
                    if(val.getNodeValue().equals("hersbach")) {
                        MeanContRankProbScore.setMethod(MeanContRankProbScore.HERSBACH);
                    } else {
                        if (val.getNodeValue().equals("with_nulls")) {
                            System.err.println("Method 'with_nulls' used to compute CRPS has been "
                                    + "deprecated: use method 'hersbach', which has been altered to "
                                    + "handle missing members, including decomposition with missing members.");
                            System.out.println("Detected advanced option to set CRPS method to 'with_nulls'.");
                            MeanContRankProbScore.setMethod(MeanContRankProbScore.WITH_NULLS);
                        } else {
                            System.out.println("CRPS method was unchanged from default of 'hersbach', "
                                    + "as method request '" + val.getNodeValue() + "' was not recognized.");
                        }
                    }
                }
            }
            //Bootstrap parameters
            else if (nextName.equals("bootstrap_parameters")) {
                try {
                    pars.put(MetricParameter.BOOTSTRAP_PARAMETER, readBootstrapParNode(n.item(i).
                            getChildNodes()));
                } catch (Exception e) {
                    e.printStackTrace();
                    String nL = System.getProperty("line.separator");
                    throw new IllegalArgumentException("Unable to read bootstrap parameters "
                            + "for metric '" + metName + "'. Precise error follows: "+
                            nL+nL+e.getMessage());
                }
            }
            //Vector function for derivation of single-valued forecasts from an ensemble
            else if(nextName.equals("vector_function_parameter")) {
                Node refNode = n.item(i).getFirstChild();
                if(refNode != null) {
                    String nodeValue = refNode.getNodeValue();
                    pars.put(MetricParameter.VECTOR_FUNCTION_PARAMETER,new VectorFunctionParameter(
                            FunctionLibrary.getVectorFunction(nodeValue)));
                }
            }
            //Status of thresholds as "main" thresholds
            else if(nextName.equals("main_threshold")) {
                Node refNode = n.item(i).getFirstChild();
                if(refNode != null) {
                    String nodeValue = refNode.getNodeValue();
                    pars.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER,new BooleanArrayParameter(getBooleanArray(nodeValue)));
                }
            }
            //String identifiers
            else if(nextName.equals("threshold_identifier")) {
                Node refNode = n.item(i).getFirstChild();
                if(refNode != null) {
                    String nodeValue = refNode.getNodeValue();
                    pars.put(MetricParameter.STRING_ARRAY_PARAMETER,new StringArrayParameter(getStringArray(nodeValue,",")));
                }
            }
            //Minimum sample size
            else if(nextName.equals("minimum_sample_size_parameter")) {
                Node val = n.item(i).getFirstChild();
                if(val != null) {
                    pars.put(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER,
                            new MinimumSampleSizeParameter(new Integer(val.getNodeValue())));
                }
            }
        }
        //Support backwards compatibility before the unconditional parameter value
        if(!pars.containsKey(MetricParameter.UNCONDITIONAL_PARAMETER)) {
            pars.put(MetricParameter.UNCONDITIONAL_PARAMETER,new UnconditionalParameter(false));
        }
        //Support backwards compatibility before the equal samples parameter value
        if(metName.equals("ReliabilityDiagram")&&!pars.containsKey(MetricParameter.EQUAL_SAMPLES_PARAMETER)) {
            pars.put(MetricParameter.EQUAL_SAMPLES_PARAMETER,new EqualSamplesParameter(false));
        }
        //Support backwards compatibility before the smooth ROC parameter
        if(metName.equals("RelativeOperatingCharacteristic")&&!pars.containsKey(MetricParameter.FITTED_ROC_PARAMETER)) {
            pars.put(MetricParameter.FITTED_ROC_PARAMETER,new FittedROCParameter(false));
        }
        //Support backwards compatibility before the smooth AUC parameter
        if(metName.equals("ROCScore")&&!pars.containsKey(MetricParameter.FITTED_AUC_PARAMETER)) {
            pars.put(MetricParameter.FITTED_AUC_PARAMETER,new FittedAUCParameter(false));
        }
        //Support backwards compatibility before the ROC score method parameter
        if(metName.equals("ROCScore")&&!pars.containsKey(MetricParameter.ROC_SCORE_METHOD_PARAMETER)) {
            pars.put(MetricParameter.ROC_SCORE_METHOD_PARAMETER,ROCScore.getDefaultMethod());
        }
        //Support backwards compatibility for the reliability points parameter with a default value
        if(metName.equals("ReliabilityDiagram")&&!pars.containsKey(MetricParameter.RELIABILITY_POINTS_PARAMETER)) {
            pars.put(MetricParameter.RELIABILITY_POINTS_PARAMETER,(ReliabilityPointsParameter)ReliabilityDiagram.getDefaultPointCount());
        }
        //Support backwards compatibility for the centered Talagrand parameter
        if(metName.equals("TalagrandDiagram")&&!pars.containsKey(MetricParameter.CENTRAL_SPREAD_BIAS_PARAMETER)) {
            pars.put(MetricParameter.CENTRAL_SPREAD_BIAS_PARAMETER,new CentralSpreadBiasParameter(false));
        }
        //Support backwards compatibility for the rank histogram sample parameter
        if(metName.equals("RankHistogram")&&!pars.containsKey(MetricParameter.RANK_HIST_SAMPLE_PARAMETER)) {
            pars.put(MetricParameter.RANK_HIST_SAMPLE_PARAMETER,new RankHistSampleParameter(true));
        }
        //Support backwards compatibility for the MCR points parameter with a default value
        if(metName.equals("MeanCaptureRateDiagram")&&!pars.containsKey(MetricParameter.MCR_POINTS_PARAMETER)) {
            pars.put(MetricParameter.MCR_POINTS_PARAMETER,(MCRPointsParameter)MeanCaptureRateDiagram.getDefaultPointCount());
            //pars.remove(MetricParameter.PROBABILITY_ARRAY_PARAMETER);
        }
        //Support backwards compatibility for the Talagrand points parameter with a default value
        if(metName.equals("TalagrandDiagram")&&!pars.containsKey(MetricParameter.SPREAD_BIAS_POINTS_PARAMETER)) {
            pars.put(MetricParameter.SPREAD_BIAS_POINTS_PARAMETER,(SpreadBiasPointsParameter)SpreadBiasDiagram.getDefaultPointCount());
            //pars.remove(MetricParameter.PROBABILITY_ARRAY_PARAMETER);
        }
        //Support backwards compatibility for the pooled box plot points parameter with a default value
        if(metName.equals("ModifiedBoxPlotPooledByLead")&&!pars.containsKey(MetricParameter.BOX_POOLED_LEAD_POINTS_PARAMETER)) {
            pars.put(MetricParameter.BOX_POOLED_LEAD_POINTS_PARAMETER,(BoxPooledLeadPointsParameter)ModifiedBoxPlotPooledByLead.getDefaultPointCount());
            //pars.remove(MetricParameter.PROBABILITY_ARRAY_PARAMETER);
        }
        //Support backwards compatibility for the unpooled box plot points parameter with a default value
        if(metName.equals("ModifiedBoxPlotUnpooledByLead")&&!pars.containsKey(MetricParameter.BOX_UNPOOLED_POINTS_PARAMETER)) {
            pars.put(MetricParameter.BOX_UNPOOLED_POINTS_PARAMETER,(BoxUnpooledPointsParameter)ModifiedBoxPlotUnpooledByLead.getDefaultPointCount());
            //pars.remove(MetricParameter.PROBABILITY_ARRAY_PARAMETER);
        }
        //Support backwards compatibility for the unpooled box plot (by size of obs.) points parameter with a default value
        if(metName.equals("ModifiedBoxPlotUnpooledByLeadObs")&&!pars.containsKey(MetricParameter.BOX_UNPOOLED_OBS_POINTS_PARAMETER)) {
            pars.put(MetricParameter.BOX_UNPOOLED_OBS_POINTS_PARAMETER,(BoxUnpooledObsPointsParameter)ModifiedBoxPlotUnpooledByLeadObs.getDefaultPointCount());
            //pars.remove(MetricParameter.PROBABILITY_ARRAY_PARAMETER);
        }
        //Support backwards compatibility before the vector function for single-valued metrics
        boolean go = metName.equals("MeanError") || metName.equals("RootMeanSquaredError") ||
                metName.equals("Correlation") || metName.equals("MeanAbsoluteError");
        if(go&&!pars.containsKey(MetricParameter.VECTOR_FUNCTION_PARAMETER)) {
            pars.put(MetricParameter.VECTOR_FUNCTION_PARAMETER,new VectorFunctionParameter(FunctionLibrary.mean()));
        }
        //Support backwards compatibility for the ROC score reference
        if(metName.equals("ROCScore") && !pars.containsKey(MetricParameter.REFERENCE_FORECAST_PARAMETER)) {
            ReferenceForecastParameter rType = new ReferenceForecastParameter();
            rType.setRefForecast(ForecastTypeParameter.SAMPLE_CLIMATOLOGY_STRING);
            pars.put(MetricParameter.REFERENCE_FORECAST_PARAMETER, rType);
        }
        //Construct the double procedures from the thresholds and threshold type
        if(pars.containsKey(MetricParameter.DOUBLE_ARRAY_PARAMETER) || pars.containsKey(MetricParameter.PROBABILITY_ARRAY_PARAMETER)) {
            if(!pars.containsKey(MetricParameter.INTEGER_PARAMETER)) {
                throw new IllegalArgumentException("Logical condition missing for one or more threshold arrays.");
            }
            DoubleArrayParameter t = null;
            if(pars.containsKey(MetricParameter.DOUBLE_ARRAY_PARAMETER)) {
                t = (DoubleArrayParameter)pars.get(MetricParameter.DOUBLE_ARRAY_PARAMETER);
            }
            else {
                t = (DoubleArrayParameter)pars.get(MetricParameter.PROBABILITY_ARRAY_PARAMETER);
            }
            //Backwards compatibility for main thresholds
            if(!pars.containsKey(MetricParameter.BOOLEAN_ARRAY_PARAMETER)) {
                boolean[] b = new boolean[t.getLength()];
                Arrays.fill(b,true);
                pars.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER,new BooleanArrayParameter(b));
            }
            if(!pars.containsKey(MetricParameter.STRING_ARRAY_PARAMETER)) {
                String[] b = new String[t.getLength()];
                pars.put(MetricParameter.STRING_ARRAY_PARAMETER,new StringArrayParameter(b));
            }
            int pin = ((IntegerParameter)pars.get(MetricParameter.INTEGER_PARAMETER)).getParVal();
            try {
                DoubleProcedureArrayParameter pp = new DoubleProcedureArrayParameter(t, pin,
                        pars.containsKey(MetricParameter.PROBABILITY_ARRAY_PARAMETER), (BooleanArrayParameter) pars.get(MetricParameter.BOOLEAN_ARRAY_PARAMETER),
                        (StringArrayParameter) pars.get(MetricParameter.STRING_ARRAY_PARAMETER));
                pars.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, pp);
            } catch (IllegalArgumentException e) {
                System.err.println("Failed to set parameters of verification metric '"+metName+"'.");
                throw e;
            }            
            pars.remove(MetricParameter.INTEGER_PARAMETER);
            pars.remove(MetricParameter.DOUBLE_ARRAY_PARAMETER);
            pars.remove(MetricParameter.PROBABILITY_ARRAY_PARAMETER);
            pars.remove(MetricParameter.BOOLEAN_ARRAY_PARAMETER);
            pars.remove(MetricParameter.STRING_ARRAY_PARAMETER);
        }        
        
        //Parameters now available: create the metric
        //Create a default metric of the named type
        Metric m = null;
        if(!metName.equals("")) {
            //Backwards compatibility since name changed
            if(metName.equals("ModifiedBoxPlot")) {
                metName = "ModifiedBoxPlotPooledByLead";
            }
            //Backwards compatibility since name change
            else if(metName.equals("TalagrandDiagram")) {
                metName = "SpreadBiasDiagram";
                ThresholdMetricStore.setDefaultMetricClass(SpreadBiasDiagram.class);
            } else if (metName.equals("RootMeanSquaredError")) {
                metName = "RootMeanSquareError";
                ThresholdMetricStore.setDefaultMetricClass(RootMeanSquareError.class);
            }
            //Set threshold metric store
            m = Metric.getDefaultMetric(metName);  //Test construction
            if(m instanceof ThresholdMetric) {
                metName = "ThresholdMetricStore";
                ThresholdMetricStore.setDefaultMetricClass(m.getClass());
            }
            m = Metric.getDefaultMetric(metName);
            
            //Support backwards compatibility for metrics that now support thresholds
            if(m.hasThresholds() && !pars.containsKey(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER)) {
                ProbabilityIdentifierParameter p = new ProbabilityIdentifierParameter(true);
                DoubleParameter[] dubs = new DoubleParameter[]{new DoubleParameter(Double.NEGATIVE_INFINITY)};
                IntegerParameter p2 = new IntegerParameter(DoubleProcedureParameter.GREATER_THAN);
                DoubleProcedureParameter[] p3 = new DoubleProcedureParameter[]{new DoubleProcedureParameter(p2,dubs,p,
                        new BooleanParameter(true))};
                DoubleProcedureArrayParameter p4 = new DoubleProcedureArrayParameter(p3);
                pars.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER,p4);
            }
            
            //Support backwards compatibility for metrics that now support a minimum sample size
            //JB@30th October 2012
            if(m.hasParType(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER) && 
                    !pars.containsKey(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER)) {
                pars.put(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER,new MinimumSampleSizeParameter());  //Default is no bootstrap
            }
            
            //Support backwards compatibility for metrics that now support bootstrap resampling
            //boolean bs = false;
            boolean go2 = m instanceof BootstrapableMetric || m instanceof ThresholdMetricStore &&
                    ((ThresholdMetricStore)m).getFirstMetricInStore() instanceof BootstrapableMetric;
            if(go2 && !pars.containsKey(MetricParameter.BOOTSTRAP_PARAMETER)) {
                pars.put(MetricParameter.BOOTSTRAP_PARAMETER,new BootstrapParameter());  //Default is no bootstrap
            }
            try {
                //Set the parameters in the correct order
                int length = pars.size();
                MetricParameter[] finalPars = new MetricParameter[length];
                int[] types = m.getParTypes();
                for (int k = 0; k < length; k++) {
                    finalPars[k] = pars.get(types[k]);
                }
                m.setParameters(finalPars);
            } catch(Exception e) {
                String s = "Failed to set parameters of verification metric '"+metName+"': ";
                if(e instanceof ArrayIndexOutOfBoundsException) {
                    s = s+"one or more parameters were unrecognized.";
                } else {
                    s = s+e;
                }
                throw new IllegalArgumentException(s);
            }
        }
        return m;
    }

    /**
     * Reads a node containing bootstrap parameter values and attempts to return a
     * bootstrap parameter. Throws an exception if the construction fails.
     *
     * @param n the node list containing the bootstrap parameter values
     * @return the bootstrap parameter
     */

    private static BootstrapParameter readBootstrapParNode(NodeList n)  {
        int len2 = n.getLength();
        int technique = 0;
        int sampleCount = 0;
        int minSampleCount = 0;
        double blockSize = 0;
        String blockUnits = null;
        Vector<ProbabilityIntervalParameter> intervals = null;
        ProbabilityIntervalParameter main = null;
        for (int k = 0; k < len2; k++) {
            String nextName = n.item(k).getNodeName();
            Node child = n.item(k);
            if (child.getNodeType() == child.ELEMENT_NODE) {
                if(nextName.equals("technique")) {
                    String s = child.getFirstChild().getNodeValue();
                    technique = BootstrapParameter.getTechniqueForString(s);
                } else if(nextName.equals("sample_size")) {
                    String s = child.getFirstChild().getNodeValue();
                    sampleCount = new Double(s).intValue();
                } else if(nextName.equals("minimum_sample_size")) {
                    String s = child.getFirstChild().getNodeValue();
                    minSampleCount = new Double(s).intValue();
                } else if(nextName.equals("nominal_block_size")) {
                    String s = child.getFirstChild().getNodeValue();
                    blockSize = new Double(s);
                } else if (nextName.equals("nominal_block_size_units")) {
                    blockUnits = child.getFirstChild().getNodeValue();
                } else if(nextName.equals("intervals")) {
                    Object[] results = readBootstrapIntervalsNode(child.getChildNodes());
                    intervals = (Vector<ProbabilityIntervalParameter>)results[0];
                    if(results[1]!=null) {
                        main = (ProbabilityIntervalParameter)results[1];
                    }
                }
            }
        }
        BootstrapParameter bp = null;
        switch(technique) {
            case BootstrapableMetric.NO_BOOTSTRAP : {
                bp = new BootstrapParameter();
            }; break;
            case BootstrapableMetric.STATIONARY_BLOCK_BOOTSTRAP : {
                bp = new BootstrapParameter(blockSize,blockUnits,sampleCount,minSampleCount,
                        intervals.toArray(new ProbabilityIntervalParameter[intervals.size()]),main);
            }; break;
            default: BootstrapParameter.getStringForTechnique(technique);  //Throws an exception if invalid
        }
        return bp;
    }

    /**
     * Reads a node containing bootstrap intervals and returns a vector of intervals
     * in the first entry of the returned array, together with a main node in the second
     * entry or null if no main node was defined. Throws an exception if the
     * construction fails on any interval.
     *
     * @param n the node list containing the bootstrap intervals
     * @return the bootstrap intervals
     */

    private static Object[] readBootstrapIntervalsNode(NodeList n)  {
        int len2 = n.getLength();
        Vector<ProbabilityIntervalParameter> pInt = new Vector<ProbabilityIntervalParameter>();
        ProbabilityIntervalParameter main = null;
        for (int k = 0; k < len2; k++) {
            String nextName = n.item(k).getNodeName();
            Node child = n.item(k);
            if (child.getNodeType() == child.ELEMENT_NODE) {
                if(nextName.contains("interval")) {
                    String s = child.getFirstChild().getNodeValue();
                    pInt.add(new ProbabilityIntervalParameter(s));
                }
                if(nextName.equals("main_interval")) {
                    String s = child.getFirstChild().getNodeValue();
                    main = new ProbabilityIntervalParameter(s);
                }
            }
        }
        return new Object[]{pInt,main};
    }

    /**
     * Writes a metric to the specified XML node.
     *
     * @param mNode the XML node for the metric
     * @param metric the metric
     */

    private static void writeMetric(XMLW mNode, Metric m) {
        String name = m.getClass().getSimpleName();
        //Threshold metric stores a set of simpler metrics (e.g. reliability diagrams and ROC plots)
        if (m instanceof ThresholdMetricStore) {
            name = ((ThresholdMetricStore) m).getStoreInstanceClass().getSimpleName();
        }
        mNode.addElement(new XMLW("name").addElement(name));
        MetricParameter[] pars = m.getParameters();
        for (int k = 0; k < pars.length; k++) {
            if (m instanceof ThresholdMetricStore && pars[k].getID() == pars[k].DOUBLE_PROCEDURE_ARRAY_PARAMETER) {
                String log = ((ThresholdMetricStore) m).getThresholds()[0].getParVal() + "";
                MetricParameter pm = null;
                ProbabilityIdentifierParameter pm2 = ((DoubleProcedureArrayParameter) pars[k]).areProbs();
                if (pm2.getParVal()) {
                    pm = new ProbabilityArrayParameter((((DoubleProcedureArrayParameter) pars[k]).getThresholdValuesAsDoubleArray()));
                } else {
                    pm = new DoubleArrayParameter((((DoubleProcedureArrayParameter) pars[k]).getThresholdValuesAsDoubleArray()));
                }
                mNode.addElement(new XMLW(pm.getName()).addElement(pm.toString()));
                BooleanArrayParameter p = ((DoubleProcedureArrayParameter) pars[k]).getMainThresholds();
                StringArrayParameter q = ((DoubleProcedureArrayParameter) pars[k]).getThresholdIDs();
                mNode.addElement(new XMLW("main_threshold").addElement(p.toString()));  //Identifiers of main thresholds
                if(q.hasNonNullStrings()) {
                    mNode.addElement(new XMLW("threshold_identifier").addElement(q.toString()));  //Identifiers
                }
                mNode.addElement(new XMLW("threshold_condition").addElement(log));
            } else if (pars[k] instanceof BootstrapParameter) {
                BootstrapParameter bp = (BootstrapParameter)pars[k];
                XMLW bs = new XMLW("bootstrap_parameters");
                mNode.addElement(bs);
                bs.addElement(new XMLW("technique").addElement(bp.getTechniqueString()));
                //Add technique-specific parameters
                if (bp.getTechnique() != BootstrapableMetric.NO_BOOTSTRAP) {
                    bs.addElement(new XMLW("sample_size").addElement(bp.getSampleCount() + ""));
                    bs.addElement(new XMLW("minimum_sample_size").addElement(bp.getMinSampleCount() + ""));
                    XMLW bsi = new XMLW("intervals");
                    bs.addElement(bsi);
                    if (bp.hasMainInterval()) {
                        bsi.addElement(new XMLW("main_interval").addElement(bp.getMainInterval().toString()));
                    }
                    ProbabilityIntervalParameter[] intervals = bp.getIntervals();
                    for (ProbabilityIntervalParameter pp : intervals) {
                        bsi.addElement(new XMLW("interval").addElement(pp.toString()));
                    }
                    if (bp.getTechnique() == BootstrapableMetric.STATIONARY_BLOCK_BOOTSTRAP) {
                        bs.addElement(new XMLW("nominal_block_size").addElement(bp.getNominalBlockSize() + ""));
                        bs.addElement(new XMLW("nominal_block_size_units").addElement(bp.getNominalBlockSizeUnits() + ""));
                    }
                }
            } else {
                mNode.addElement(new XMLW(pars[k].getName()).addElement(pars[k].toString()));   //toString() returns correctly formatted par
            }
        }
        //Add special option for crps
        if (name.equalsIgnoreCase("meancontrankprobscore")) {
            String method = "hersbach";
            if (MeanContRankProbScore.getMethod() == MeanContRankProbScore.WITH_NULLS) {
                method = "with_nulls";
            }
            mNode.addElement(new XMLW("crps_method").addElement(method));
        }
    }
    
    /**
     * Adds a set of date conditions to a specified XML element.
     * 
     * @param element the XML element
     * @param dates the date conditions
     */
    
    private static void addDateConditions(XMLW element, TreeMap<DateElement,Vector<Integer>> dates) {
        Iterator it = dates.keySet().iterator();
        while(it.hasNext()) {
            DateElement d = (DateElement)it.next();
            Vector<Integer> exclude = dates.get(d);
            String add = exclude.toString();
            add = add.substring(1,add.length()-1);
            switch(d.getDateElement()) {
                case Calendar.YEAR: element.addElement(new XMLW("exclude_years").addElement(add)); break;
                case Calendar.MONTH: element.addElement(new XMLW("exclude_months").addElement(add)); break;
                case Calendar.WEEK_OF_YEAR: element.addElement(new XMLW("exclude_weeks").addElement(add)); break;
                case Calendar.DAY_OF_WEEK: element.addElement(new XMLW("exclude_days_of_week").addElement(add)); break;    
                case Calendar.HOUR_OF_DAY: element.addElement(new XMLW("exclude_hours_of_day_UTC").addElement(add)); break;    
            }
        }
    }
    
/*******************************************************************************
 *                                                                             *
 *                                  TEST METHOD                                *
 *                                                                             *
 ******************************************************************************/     
    
    /**
     * Test method.
     *
     * @param args the args
     */
    
    
    public static void main(String[] args) {
//        VerificationUnit vu = new VerificationUnit("river","time","variable");
//
//        File[] in = new File[4];
//        in[0] = new File("C:/Documents and Settings/brownj/Desktop/TEST_DATA/CHTM7PQ.CHTM7.QINE.06.VS.20030306");
//        in[1] = new File("C:/Documents and Settings/brownj/Desktop/TEST_DATA/CHTM7PQ.CHTM7.QINE.06.VS.20030307");
//        in[2] = new File("C:/Documents and Settings/brownj/Desktop/TEST_DATA/CHTM7PQ.CHTM7.QINE.06.VS.20030308");
//        in[3] = new File("C:/Documents and Settings/brownj/Desktop/TEST_DATA/CHTM7PQ.CHTM7.QINE.06.VS.20030309");
//        
//        vu.setForecastData(new FileArrayDataSource(in));
//        vu.setObservedData(new FileDataSource(new File("C:/Documents and Settings/brownj/Desktop/TEST_DATA/CHTM7PQ.CHTM7.QINE.06.OBS")));
//        
//        vu.setForecastTimeSystem(new java.util.SimpleTimeZone(0,"CST"));
//        vu.setObservedTimeSystem(new java.util.SimpleTimeZone(0,"CST"));
////        vu.setClimatologyTimeSystem(new java.util.SimpleTimeZone(0,"UTC"));
//        
//        vu.setSupport(Support.OBSERVED_SUPPORT,new TemporalSupport("BAR"));
//        vu.setSupport(Support.FORECAST_SUPPORT,new TemporalSupport("BAR",1.0,"DAY","MEAN"));
//        
//        Calendar c = Calendar.getInstance();
//        c.clear();
//        c.set(1992,11,23);
//        Calendar c2 = Calendar.getInstance();
//        c2.clear();
//        c2.set(1998,10,29);
//        vu.setDates(c,c2);
//        
//        DateCondition d = new DateCondition(vu,Calendar.YEAR,new Vector(Arrays.asList(1,2,3)));
//        d.setCondition(Calendar.MONTH,new Vector(Arrays.asList(11,10,7)));
//        d.setCondition(Calendar.DAY_OF_WEEK,new Vector(Arrays.asList(0,2,3)));
//        
//        vu.setDateCondition(d);
//        
//        vu.setLeadTimes(20,"DAY");
//        vu.setResolution(40,"DAY");
//        vu.setOutputData(new FileDataSource(new File("C:/Documents and Settings/brownj/Desktop/TEST_DATA/")));
//        
//        
//        File f = new File("C:/Documents and Settings/brownj/Desktop/test_out.xml");
//        try {
//            write(f,new AnalysisUnit[]{vu});
//        } catch(Exception e) {
//            e.printStackTrace();
//        }
    }    

    
}