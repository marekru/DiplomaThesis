package evs.data;

//Java util dependencies
import evs.analysisunits.VerificationUnit;
import java.util.Arrays;

//EVS dependencies
import evs.utilities.mathutil.DoubleProcedure;
import evs.utilities.mathutil.Function;
import evs.utilities.mathutil.VectorFunction;
import evs.data.fileio.GlobalUnitsReader;
import evs.utilities.matrix.*;

/**
 * A class for specifying restrictions on variable values to include in the
 * verification.  When a condition is applied to a specific verification unit,
 * it will be used to restrict the verification window for that unit alone.
 * 
 * NOTE: a value condition is associated with a verification unit on construction
 * by deep copying the input unit.  Thus, any changes in the parameters of the 
 * input unit will not be reflected in the current unit.  However, a convenience
 * method is provided for deep copying the current unit with a new verification
 * unit as the parameter.  
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ValueCondition extends Condition {
    
    /********************************************************************************
     *                                                                              *
     *                               CLASS VARIABLES                                *
     *                                                                              *
     *******************************************************************************/
    
    /**
     * Identifier for a variable value condition applied to the forecasts.
     */
    
    public static final int FORECAST_CONDITION = 101;
    
    /**
     * Identifier for a variable value condition applied to the observations.
     */
    
    public static final int OBSERVED_CONDITION = 102;   

    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLES                              *
     *                                                                              *
     *******************************************************************************/
    
    /**
     * Verification unit on which conditioning will be performed, which may be different 
     * than the verification unit to which the condition applies (i.e. conditioning
     * on another variable is possible). 
     */
    
    private VerificationUnit vu = null;
    
    /**
     * The type of condition {@link #FORECAST_CONDITION} or {@link #OBSERVED_CONDITION)}.
     */
    
    private int conditionType;
    
    /**
     * A statistic to apply to the specified dataset.
     */
    
    private Function dataStatistic = null;
    
    /**
     * An array of DoubleProcedure objects, which comprise the conditions (e.g. less than)
     */
    
    private DoubleProcedure[] conditions = null;
    
    /**
     * A time window to which the conditions should be applied.
     */
    
    private Double window = null;
    
    /**
     * Units of the time window to which the conditions should be applied.
     */
    
    private String windowTimeUnit = null;

    /**
     * Function to apply over a time window.
     */

    private VectorFunction windowStatistic = null;

    /********************************************************************************
     *                                                                              *
     *                                 CONSTRUCTOR                                  *
     *                                                                              *
     *******************************************************************************/
    
    /**
     * Constructs a value condition.  Specify a verification unit to which the 
     * condition will apply.  The input unit provides a link to the verification
     * unit to which the condition will apply, but the actual data used for conditioning
     * is supplied via the apply() methods of this class.  The value condition may
     * be associated with a different verification unit after construction. In that
     * case, the output from conditioning on one variable (the input here) may be 
     * used to sub-select pairs of another variable, for which sensibility checks
     * are made when associating this value condition with the other verification unit.
     * On construction, no guarantees can made as to whether the results from apply()
     * will succeed, since the data are supplied on calling apply().
     * 
     * In addition to the verification unit to which the conditions apply, specify the
     * type of condition and the data statistic, which should be
     * a {@link evs.utilities.mathutil.FunctionLibrary#assign} for an {@link #OBSERVED_CONDITION}
     * or a {@link evs.utilities.mathutil.VectorFunction} for {@link #FORECAST_CONDITION}, such as
     * {@link evs.utilities.mathutil.FunctionLibrary#mean}. The latter would apply the 
     * subsequent conditions to the ensemble mean forecast.  The conditions themselves 
     * are specified as an array of {@link evs.utilities.mathutil.DoubleProcedure} objects.
     *
     * Optionally, a time window may be specified, together with the associated time
     * units. In that case, also specify a function to determine over the time window,
     * such as the {@link evs.utilities.mathutil.FunctionLibrary#maximum}. This window must 
     * be smaller than, and exactly divisible by, the overall verification window. 
     *
     * Note that the input verification unit is deep copied when being associated
     * with the current unit, so that any changes will not be synchronous and must
     * be coordinated (see {@link #deepCopy(evs.analysisunits.VerificationUnit)}.
     * 
     * @param vu the verification unit to which the conditions should apply
     * @param conditionType the conditionType of condition 
     * @param dataStatistic a statistic to apply to the specified dataset
     * @param conditions an array of DoubleProcedure objects
     * @param window a time window to which the conditions should be applied (may be null)
     * @param windowTimeUnit units for the time window to which the conditions apply (may be null, not if a window is defined)
     * @param windowStatistic a statistic to apply over the window (may be null, not if a window is defined)
     */
    
    public ValueCondition(final VerificationUnit vu, int conditionType, Function dataStatistic, DoubleProcedure[] conditions, Double window, String  windowTimeUnit, VectorFunction windowStatistic) {
        if(vu == null) {
            throw new IllegalArgumentException("The input verification unit cannot be null.");
        }
        //Check the condition conditionType
        if(conditionType != FORECAST_CONDITION && conditionType != OBSERVED_CONDITION) {
            throw new IllegalArgumentException("Unrecognized type for the dataset to which '"+dataStatistic+"' should apply.");
        }
        if(dataStatistic == null) {
            throw new IllegalArgumentException("The input statistic cannot be null.");
        }
        if (conditions == null || conditions.length == 0) {
            throw new IllegalArgumentException("Logical condition required for sub-selecting data.");
        }
        //Forecast condition
        if(conditionType == FORECAST_CONDITION) {
            if(!(dataStatistic instanceof VectorFunction)) {
                throw new IllegalArgumentException("Incorrect function type for the specified dataset: expected a vector function for the ensemble data.");
            }
            int count = 0;
            if(conditions != null) {
                for(int i = 0; i < conditions.length; i++) {
                    if(conditions[i] != null) {
                        count++;
                    }
                }
            }
            if(count == 0) {
                throw new IllegalArgumentException("Specify at least one threshold condition for "+vu+" to select forecasts and observations.");
            }
        }
        //Observed condition
        else {         
            //Must be an assign function
            if (!dataStatistic.toString().equals("assign")) {
                throw new IllegalArgumentException("Incorrect function type for the specified dataset: expected an 'assign' function for the observed data.");
            }
        }

        //Check the window
        if(window != null) {
            if(window < 0) {
                throw new IllegalArgumentException("The period over which to apply the condition must be > 0.");
            }
            //Check the units
            GlobalUnitsReader.isSupportedTimeUnit(windowTimeUnit,true);
            //If the window is not null, the function must be a vector function
            if(windowStatistic==null) {
                throw new IllegalArgumentException("A temporal window of '"+window+"' "+windowTimeUnit+" was defined, but no window statistic was provided.  Specify a window statistic.");
            }
        }
        
        //Check that the conditions make sense
        if(conditions != null && conditions.length>0) {
            boolean lessThan = false;
            boolean lessThanEqual = false;
            boolean greaterThan = false;
            boolean greaterThanEqual = false;
            for(int i = 0; i < conditions.length; i++) {
                if(conditions[i] != null) {
                    lessThan = conditions[i].toString().equals("isLess");
                    lessThanEqual = conditions[i].toString().equals("isLessEqual");
                    greaterThan = conditions[i].toString().equals("isGreater");
                    greaterThanEqual = conditions[i].toString().equals("isGreaterEqual");
                } else {
                    throw new IllegalArgumentException("One or more logical conditions are null.");
                }
            }
            
            if(lessThan && lessThanEqual) {
                throw new IllegalArgumentException("Cannot specify a less than (<) condition together with a less than or equal to (<=) condition.");
            }
            if(greaterThan && greaterThanEqual) {
                throw new IllegalArgumentException("Cannot specify a greater than (>) condition together with a greater than or equal to (=>) condition.");
            }
        }
        //Deep copy the verification unit stored locally
        this.vu = vu.deepCopy(true);
        this.conditionType = conditionType;
        this.dataStatistic = dataStatistic;
        this.conditions = conditions;
        this.window = window;
        this.windowTimeUnit = windowTimeUnit;
        this.windowStatistic = windowStatistic;
    }

    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/
    
    /**
     * Returns the unique identifier of the verification unit associated with
     * this value condition.
     *
     * @return the verification unit identifier
     */
    
    public final String getVerificationUnitID() {
        return vu.toString();
    }
    
    /**
     * Returns the verification unit associated with this value condition.
     *
     * @return the verification unit
     */
    
    public final VerificationUnit getVerificationUnit() {
        return vu;
    }    
    
    /**
     * Returns the conditionType of dataset to which the conditions apply (one of
     * ValueCondition.FORECAST_CONDITION or ValueCondition.OBSERVED_CONDITION)
     *
     * @return the dataset conditionType
     */
    
    public final int getConditionType() {
        return conditionType;
    }
    
    /**
     * Returns the statistic applied to the time window (if defined).
     *
     * @return the statistic
     */
    
    public final VectorFunction getWindowStatistic() {
        return windowStatistic;
    }

    /**
     * Returns the statistic applied to the dataset.
     *
     * @return the statistic
     */

    public final Function getDataStatistic() {
        return dataStatistic;
    }
    
    /**
     * Returns the logical conditions applied to the dataset.
     *
     * @return the logical conditions or null
     */
    
    public final DoubleProcedure[] getLogicalConditions() {
        return conditions;
    }
    
    /**
     * Returns a logical condition with a specified name or null if the
     * condition does not exist.  The name corresponds to the method name of
     * the concrete DoubleProcedure from which the logical condition is
     * constructed (e.g. evs.utilities.mathutil.FunctionLibrary.isEqual()
     * is represented by isEqual).
     *
     * @param name the name of the logical procedure
     * @return the logical condition or null
     */
    
    public final DoubleProcedure getLogicalCondition(String name) {
        DoubleProcedure proc = null;
        if(conditions != null) {
            for(int i = 0; i < conditions.length; i++) {
                String n = conditions[i].getClass().getEnclosingMethod().getName();
                if(n.equals(name)) {
                    proc= conditions[i];
                    break;
                }
            }
        }
        return proc;
    }
    
    /**
     * Returns true if a logical condition with a specified name exists, false
     * otherwise.  The input name corresponds to the method name of the concrete
     * DoubleProcedure from which the logical condition is constructed
     * (e.g. evs.utilities.mathutil.FunctionLibrary.isEqual() is represented by
     * isEqual).
     *
     * @param name the name of the logical procedure
     * @return true if such a condition exists
     */
    
    public final boolean hasLogicalCondition(String name) {
        return getLogicalCondition(name) != null;
    }
    
    /**
     * Returns the moving window to which the conditions will be applied.
     *
     * @return the moving window
     */
    
    public final Double getTimeWindow() {
        return window;
    }
    
    /**
     * Returns the time units to which the moving window will be applied.
     *
     * @return the time units of the moving window
     */
    
    public final String getTimeWindowUnits() {
        return windowTimeUnit;
    }
    
    /**
     * Returns true if the moving window to which the conditions will be applied
     * has been set, false otherwise.
     *
     * @return true if the moving window has been set
     */
    
    public final boolean hasTimeWindow() {
        return window != null;
    }
    
    /**
     * Overrides the superclass method and returns the unique identifier of
     * the verification unit to which these conditions apply along with the
     * data conditionType as an appended string.
     *
     * @return the unique identifier of the verification unit
     */
    
    public final String toString() {
        String append = "";
        if(conditionType == FORECAST_CONDITION) {
            append=VerificationUnit.getIDSepChar()+"forecast";
        } else if(conditionType == OBSERVED_CONDITION) {
            append=VerificationUnit.getIDSepChar()+"observed";
        }
        return vu.toString()+append;
    }
    
    /**
     * Returns a deep copy of the verification condition where all attributes of
     * the returned condition are independent (i.e. separate objects in memory)
     * from those in the current unit.  The values of the attributes remain the
     * same.
     *
     * @return a deep copy
     */
    
    public final Condition deepCopy() {
        return new ValueCondition(vu,conditionType,dataStatistic,conditions,
                window,windowTimeUnit,windowStatistic);
    }
    
    /**
     * Returns a deep copy of the verification condition where all attributes of
     * the returned condition are independent (i.e. separate objects in memory)
     * from those in the current unit.  The values of the attributes remain the
     * same.  Specify another verification unit as the new parameter.  Throws an 
     * exception if the input unit is invalid.
     *
     * @return a deep copy with the new unit as parameter
     */
    
    public final Condition deepCopy(VerificationUnit vu) throws IllegalArgumentException {
        return new ValueCondition(vu,conditionType,dataStatistic,conditions,
                window,windowTimeUnit,windowStatistic);
    }    
    
    /**
     * Returns true if this condition can be applied to a specified unit.
     * A condition can be applied if the start and end dates have been set in both
     * units and those dates match.  In addition, any aggregation window and units
     * must be the same.
     *
     * @param vu the input verification unit
     * @param throwEx is true to throw an exception if the condition is not met
     * @return true if the condition is met, false if not and throwEx is false
     */
    
    public final boolean canApplyCondition(VerificationUnit vu, boolean throwEx) throws IllegalArgumentException {
        if(vu == null) {
            throw new IllegalArgumentException("The input verification unit cannot be null.");
        }
        //Check that the verification unit can be used
        //If no other conditions have been defined, only the dates and resolution must be set
        boolean go = true;
        if(!vu.hasDates()) {
            if(throwEx) {
                throw new IllegalArgumentException("Set the start and end dates of the verification unit before specifying more specific date conditions.");
            }
            go = false;
        }
        //Check the dates for equality if conditions have been set
        VerificationUnit comp = this.vu;
        go = compareDates(vu,comp);
        if(!go && throwEx) {
            throw new IllegalArgumentException("Cannot set a value condition for unit '"+vu+"' with respect to unit '"+toString()+"', as the verification dates are different.");
        }
        go = compareResolutions(vu,comp);
        if(!go && throwEx) {
            throw new IllegalArgumentException("Cannot set a value condition for unit '"+vu+"' with respect to unit '"+toString()+"', as the verification resolutions differ.");
        }
        return go;
    }
    
    /**
     * Returns true if a value condition can be applied to the specified unit
     * using the second unit as a parameter in that condition.  Otherwise, returns
     * false.
     *
     * @param unit the unit for which a condition is desired
     * @param par the unit intended as a parameter in the condition
     */
    
    public static boolean canApplyWithRespectTo(VerificationUnit unit, VerificationUnit par) {
        return compareDates(unit,par) && compareResolutions(unit,par);
    }

    /**
     * Applies the condition, returning a 1D matrix of boolean values whose elements
     * indicate which rows should be used, where true indicates a row should be
     * used. The input data may contain either observed data (i.e. two columns,
     * with valid time and observations), forecasts (valid time, lead time, and members) 
     * or paired data (valid time, lead time, observations and members).  
     *
     * The data type must be consistent with the type of condition, otherwise an 
     * exception is thrown. Specifically, a condition of {@link #FORECAST_CONDITION} 
     * must be accompanied by a data structure of {@link #FORECAST_DATA}
     * or {@link #PAIRED_DATA}. A condition of {@link #OBSERVED_CONDITION} 
     * must be accompanied by a data structure of {@link #OBSERVED_DATA}
     * or {@link #PAIRED_DATA}. 
     * 
     * @param d the data
     * @param dataType the data type
     * @return the rows that should be used given the condition
     */

    @Override
    public final BooleanMatrix1D apply(DoubleMatrix2D d, int dataType) throws IllegalArgumentException {
        if(d == null) {
            throw new IllegalArgumentException("No data have been defined for conditioning purposes.");
        }
        if(d.getColumnCount()<2) {
            throw new IllegalArgumentException("Input must have at least two columns of data.");
        }
        int rowCount = d.getRowCount();
        boolean[] bool = new boolean[rowCount];
        Arrays.fill(bool,true);
        BooleanMatrix1D returnMe = new DenseBooleanMatrix1D(bool);
        double nV = vu.getNullValue();

        //Establish the base data for the calculation first, namely the single-valued
        //observations or the single-valued statistic of the ensemble forecasts
        DoubleMatrix1D baseData = null;
        //Observations are in the second column if the input data are observations only
        //otherwise the third column
        if(getConditionType()==OBSERVED_CONDITION) {
            switch(dataType) {
                case OBSERVED_DATA: baseData = (DoubleMatrix1D)d.getColumnAt(1); break;
                case PAIRED_DATA: baseData = (DoubleMatrix1D)d.getColumnAt(2); break;
                default: throw new IllegalArgumentException("A value condition applied to observations requires either observed data or paired data as input.");       
            }
        }
        //Forecasts
        else if(getConditionType()==FORECAST_CONDITION) {
            double[] data = new double[rowCount];
            double[][] forecasts = null;
             switch(dataType) {
                case FORECAST_DATA: forecasts = ((DoubleMatrix2D)d.
                        getSubmatrixByColumn(2,d.getColumnCount()-1)).toArray(); break;
                case PAIRED_DATA: forecasts = ((DoubleMatrix2D)d.
                        getSubmatrixByColumn(3,d.getColumnCount()-1)).toArray(); break;
                default: throw new IllegalArgumentException("A value condition applied to forecasts requires either forecast data or paired data as input.");               
            }           
            
            //Apply the statistic to the forecast
            VectorFunction s = (VectorFunction)dataStatistic;
            for(int i = 0; i < data.length; i++) {
                data[i] = s.apply(new DenseDoubleMatrix1D(forecasts[i]),nV);
            }
            baseData = new DenseDoubleMatrix1D(data);
        }

        //Apply the statistic to a window if required
        if(hasTimeWindow()) {
            //Compute the number of aggregated hours
            double hourFactor = GlobalUnitsReader.getMilliConversionFactor(getTimeWindowUnits());
            //Convert to hours i.e. number of hours per unit
            hourFactor = hourFactor / (1000.0 * 60.0 * 60.0);
            //Multiply by the number of units to obtain the aggregated window in hours
            hourFactor = hourFactor * getTimeWindow();
            //Determine the corresponding number of rows from the verification resolution if defined
            int aggRows = 0;
            if(vu.hasResolution()) {
                double hourFactor2 = GlobalUnitsReader.getMilliConversionFactor(vu.getResolutionUnits());
                hourFactor2 = hourFactor2 / (1000.0 * 60.0 * 60.0);
                hourFactor2 = hourFactor2 * vu.getResolution();
                aggRows = (int)(hourFactor/hourFactor2);
            }
            //Otherwise, determine from the separation of the first data items
            else {
                double hourFactor2 = d.get(1,0)-d.get(0,0);
                aggRows = (int)(hourFactor/hourFactor2);
            }
            double div = aggRows%rowCount;
            if(div<=1) {
                throw new IllegalArgumentException("The input contained too few pairs to apply one or more value conditions" +
                        " to the specified time window of '"+getTimeWindow()+" "+getTimeWindowUnits()+"'.");
            }
            double skip = (div -((int)div)) * rowCount;
            if(skip!=0.0) {
                System.out.println("WARNING: the window specified for one or more value conditions does not divide exactly " +
                        "by the number of pairs ("+div+"). The last "+skip+" paired data are assumed to not meet the condition and will not " +
                        "be included in subsequent calculations.");
            }

            //Aggregate the data with the specified function
            VectorFunction s = (VectorFunction)windowStatistic;
            int total = rowCount/aggRows;
            for(int i = 0; i < total; i++) {
                int start = aggRows * i;
                int stop = (start + aggRows)-1;
                DoubleMatrix1D next = (DoubleMatrix1D)baseData.getSubmatrixByRow(start,stop);
                double result = s.apply(next,nV);
                //Check that all logical conditions apply
                boolean doNotUse = false;
                if(result==nV) {
                    doNotUse=true;
                } else {
                    //If one or more conditions do not apply, set all corresponding
                    //input rows to the aggregation period to "false".
                    for (int j = 0; j < conditions.length; j++) {
                        if (!conditions[j].apply(result)) {
                            doNotUse=true;
                            break;
                        }
                    }
                }
                //Set all pairs over the time window to false
                if(doNotUse) {
                    for(int j = 0; j < aggRows; j++) {
                        returnMe.set(start+j,false);
                    }
                }
            }
        }
        else {

            //Apply the threshold conditions
            for (int i = 0; i < rowCount; i++) {
                //Check each condition
                double test = baseData.get(i);
                if (test != nV) {
                    for (int j = 0; j < conditions.length; j++) {
                        if (!conditions[j].apply(test)) {
                            returnMe.set(i, false);
                            break;
                        }
                    }
                } else {
                    returnMe.set(i, false);
                }
            }
        }
        return returnMe;
    }

    /**
     * Returns true if the input object is a value condition and the value conditions
     * are equal to those in the current object, false otherwise.
     *
     * @param obj the input object
     * @return true if the object has equivalent value conditions
     */
    
    public final boolean equals(Object obj) {
        if(!(obj instanceof ValueCondition)) {
            return false;
        }
        ValueCondition test = (ValueCondition)obj;
        if(!test.vu.toString().equals(vu.toString())) {
            return false;
        }
        if(test.conditionType != conditionType) {
            return false;
        }
        if(test.hasTimeWindow()!=hasTimeWindow()) {
            return false;
        }
        if(hasTimeWindow()) {
            if(!window.equals(test.window)) {
                return false;
            }
            if(!windowTimeUnit.equals(test.windowTimeUnit)) {
                return false;
            }
            if(!windowStatistic.equals(test.windowStatistic)) {
                return false;
            }
        }
        if(!test.dataStatistic.equals(dataStatistic)) {
            return false;
        }
        if (test.getLogicalConditions().length != getLogicalConditions().length) {
            return false;
        }
        for (int i = 0; i < conditions.length; i++) {
            if (!conditions[i].equals(test.conditions[i])) {
                return false;
            }
        }
        return true;
    }    
    
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public final int hashCode() {
        assert false : "hashCode not implemented for ValueCondition.";
        return 1;
    }    
    
    /********************************************************************************
     *                                                                              *
     *                               PRIVATE METHODS                                *
     *                                                                              *
     *******************************************************************************/    
    
    /**
     * Returns true if the verification units both have start and end dates and
     * those dates are equivalent.
     *
     * @param first the first verification unit
     * @param second the second verification unit
     * @return true if the dates have been set and are equivalent
     */
    
    private static boolean compareDates(VerificationUnit first, VerificationUnit second) {
        boolean returnMe = false;
        returnMe = first.hasDates() && second.hasDates();
        if(returnMe) {
            returnMe = first.getStartDate().equals(second.getStartDate());
            returnMe = first.getEndDate().equals(second.getEndDate());
        }
        return returnMe;
    }
    
    /**
     * Returns true if the verification units have equivalent verification resolutions,
     * (including unspecified resolutions) false otherwise.
     *
     * @param first the first verification unit
     * @param second the second verification unit
     * @return true if the resolutions are equivalent
     */
    
    private static boolean compareResolutions(VerificationUnit first, VerificationUnit second) {
        boolean returnMe = first.getResolution()==second.getResolution();
        if(first.hasResolution()) {
            returnMe = first.getResolutionUnits().equals(second.getResolutionUnits());
        }
        return returnMe;
    }
    
    
}
