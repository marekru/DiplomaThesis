package evs.data.fileio.netcdf;

//Java dependencies
import java.util.Map;

/**
 * Interface for a callback object to store the parsed ensemble data.
 * 
 * @author Frederik van den Broek
 */

public interface EnsembleDataParserCallback {
	
	void setStationInfo(Map<String, String> stationIdNameMap);
	
	void setNumberOfStations(int number);
	
	void setEnsembleInfo(int[] ensembleIds);
	
	void setTimeInfo(long[] timeStamps);
	
	void handleTimeSeries(double[] timeSeries, int ensembleId, String stationId, String variableName);

}
