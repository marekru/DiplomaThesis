package evs.data.fileio.ohdfile.data;

import evs.data.fileio.ohdfile.misc.HCalendar;
import java.util.Calendar;
import evs.analysisunits.AnalysisUnit;

////////////////////////////////////////////////////////////////////////////////////////////////
//
//      Date            Person          Comment
//      ----------      ------------    ----------------------------------------------
//      2000-05-02      Hank Herr       First version complete.
//      2000-06-16      Hank Herr       Added the multiple regression using MatrixMath
//      2000-10-27      Hank Herr       Making it equivalent to the C++ DataSet I created.
//      2000-10-31      Hank Herr       Added the date related functions and scaleVariable.
//      2000-12-07      Hank Herr       Added count, extractSubset, intersection, and
//                                      union routines.
//      2001-01-29      Hank Herr       Added routines to make this a data source for JCChart.
//      2001-02-21      Hank Herr       Added the date based extractSubset routine.
//      2001-03-01      Hank Herr       Added extract subset by variables and a faulty version
//                                      of quicksort.
//      2001-03-02      Hank Herr       Added categorical "probability..." statistic functions.
//      2001-04-19      Hank Herr       Added temporalAverage and getCurrentSampleIndex.
//      2002-03-27      Hank Herr       Added K-S Statistic method (maximumError).
//
/////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * ================================== <br>
 * The DataSet Class. <br>
 * ================================== <br>
 * <br>
 * This class provides tools for accessing and manipulating a two-dimensional table of
 * double values (double[][]).  The constructor accepts as arguments either double
 * arrays, numbers of rows and columns, or other DataSets. <br>
 * <br>
 * -------------------------------------- <br>
 * RECOMMENDED USAGE<br>
 * -------------------------------------- <br>
 * <br>
 * When you create a new program, just create a subclass of this class which will provide
 * a means to fill the data set, either from a file or some other source.  Then, you can
 * use all the functionality provided here for the data from that data source -- and there
 * is a lot of functionality.  <br>
 * <br>
 * This class will not throw Exceptions.  Once the data is in place, it really shouldn't
 * be necessary.  Still, there are a lot of false/null/AnalysisUnit.getNullValue() return functions, so you
 * can use these for error checking.  Then, the subclass can do quality control and throw
 * exceptions as desired.  <br>
 * <br>
 * -------------------------------------- <br>
 * USING CONDITIONING <br>
 * -------------------------------------- <br>
 * <br>
 * The static variables LESS_THAN, GREATER_THAN, LESS_THAN_OR_EQUAL_TO, NOT_EQUAL_TO
 * GREATER_THAN_OR_EQUAL_TO, EQUAL_TO, NO_CONDITION, AND, and OR, are all used to
 * extract subsets, count samples, and calculate probabilities of detection, false
 * alarm, and so forth.  Methods which take them in as argument will have a parameter
 * list that includes: <br>
 * <br>
 *     int var, int cond1, double val1, boolean and, int cond2, double val2 <br>
 * <br>
 * where var is the variable being considered and cond1, val1, "and", cond2, and val2
 * define the conditioning using static variables.  For example, to find the subset
 * where variable 0 satisfies the condition "a <= var0 < c", pass in the arguments:  <br>
 * <br>
 *     0, GREATER_THAN_OR_EQUAL_TO, a, AND, LESS_THAN, b. <br>
 * <br>
 * @author Hank Herr
 */
public class DataSet {
    public static final String CLASSNAME = "DataSet";
    public static final int     NO_VARIABLE              = -999;
    public static final int     LESS_THAN                = -1;
    public static final int     GREATER_THAN             = 1;
    public static final int     LESS_THAN_OR_EQUAL_TO    = -2;
    public static final int     GREATER_THAN_OR_EQUAL_TO = 2;
    public static final int     EQUAL_TO                 = 0;
    public static final int     NOT_EQUAL_TO             = -3;
    public static final int     NO_CONDITION             = -999;
    public static final boolean AND                      = true;
    public static final boolean OR                       = false;
    public static final int     DEFAULT_DATA_SIZE        = 100;
    
    //General Attributes
    
    /**
     * Core attribute storing the data in a double array.
     */
    protected DataTable _dataTable;
    
    /**
     * The number of samples in the data set.
     */
    protected int _sampleSize;
    
    /**
     * A pointer to the "current" sample, facilitating looping via next(), resetPtr(), and goto
     * methods.
     */
    protected int _currentSample;
    
    /**
     * The number of variables in the table.
     */
    protected int _numberOfVariables;
    
    /**
     * The largest number of samples allowed.  This is used to provide a size for the double
     * array and can be increased if necessary.
     */
    protected int _maximumSize;
    
    //Distribution fitting variables
    protected int        _fitSample;
    protected int        _fitCDF;
    
    /**
     * If this flag is true, then the first index of the _data double array will be variables, and the
     * second will be samples.  This means that, to acquire the values for a variable, it can return the
     * array itself (_data[i]) instead of needing to make a copy ({_data[0...n][i]}).  However, for samples,
     * a copy must always be made.
     */
    protected boolean _makeRowsVariables;
    
    
//===============================================================================================
// CONSTRUCTORS
//===============================================================================================////
    
    /**
     * Empty Constructor.
     */
    public DataSet() {
        _dataTable = null;
    }
    
    /**
     * Constructor for known dimensions of DataSet.
     * @param samples The number of samples (rows) to allow for.
     * @param vars The number of variables (columns) to allow for.
     * @param nV the null value
     */
    public DataSet(int samples, int vars, double nV) {
        this(samples, vars, false, nV);
    }
    
    /**
     * Constructor for known dimensions, with option makeRowsVariables flag.
     * @param maxSamples The number of samples (rows) to allow for.
     * @param vars The number of variables (columns) to allow for.
     * @param makeRowsVariables True if you want the first dimension of _data to be variables.  False for samples.
     * @param nV the null value
     */
    public DataSet(int maxSamples, int vars, boolean makeRowsVariables, double nV) {
        if ((maxSamples <= 0) || (vars <= 0)) {
            _dataTable = null;
        }
        _makeRowsVariables = makeRowsVariables;
        _dataTable = DataSet.createDataAttribute(maxSamples, vars, _makeRowsVariables);        
        _numberOfVariables = vars;
        _sampleSize = 0;
        _currentSample = 0;
        _maximumSize = maxSamples;       
        clearAllData(nV);
    }
    
    /**
     * Copy constructor.  This is literally a copy!
     * @param base The base DataSet.
     */
    public DataSet(DataSet base) {
        _makeRowsVariables = base.getMakeRowsVariables();
        _sampleSize = base.getSampleSize();
        _currentSample = 0;
        _numberOfVariables = base.getNumberOfVariables();
        _maximumSize = base.getMaximumSampleSize();
        
        _dataTable = DataSet.createDataAttribute(_maximumSize, _numberOfVariables, _makeRowsVariables);
        
        int i, j;
        for (i = 0; i < _sampleSize; i ++) {
            for (j = 0; j < _numberOfVariables; j ++) {
                setValueBlindly(i, j, base.getValueBlindly(i, j));
            }
        }
        
    }
    
    /**
     * Routine to initialize the data table to have the specified dimensions adn be empty.
     * @param samples The number of samples (rows) to allow for.
     * @param vars The number of variables (columns) to allow for.
     * @param nV the null value
     */
    public void initialize(int samples, int vars, boolean makeRowsVariables, double nV) {
        if ((samples <= 0) || (vars <= 0)) {
            //PRINT ERROR MESSAGE HERE
            return;
        }
        _makeRowsVariables = makeRowsVariables;
        _dataTable = DataSet.createDataAttribute(samples, vars, _makeRowsVariables);
        
        _sampleSize = 0;
        _currentSample = 0;
        _numberOfVariables = vars;
        _maximumSize = samples;
        clearAllData(nV);        
        
    }
    
    
    /////////////////////////////////////////////////////////////////////////
    //Counts
    /////////////////////////////////////////////////////////////////////////\
    
    /**
     * Count the number of samples satisfying a single condition on one specific variable.
     * @param var The variable to use.
     * @param condition The condition (greater than, less than, etc.) to use.
     * @param value The boundary value being checked against.
     * @param nV the null value
     * @return The number of samples satisfying the condition.
     */
    public int countValues(int var, int condition, double value, double nV) {
        //I pass in OR so that countValues will work (see the NOTE below inside countValues).
        return countValues(var, condition, value, OR, NO_CONDITION,nV,nV);
    }
    
    /**
     * Count the number of samples satisfying a double condition, typically lower
     * and upper bounds.
     * @param var The variable checked.
     * @param cond1 The condition on the first bound.
     * @param val1 The first bound value.
     * @param and The and/or condition linking the two boundary conditions.
     * @param cond2 The condition on the second bound.
     * @param val2 The second bound value.
     * @param nV the null value
     * @return The number of samples satisfying the condition.
     */
    public int countValues(int var, int cond1, double val1, boolean and, int cond2, double val2, double nV) {
        if ((var >= _numberOfVariables) || (var < 0)) {
            //PRINT ERROR MESSAGE HERE
            return (int)nV;
        }
        
        int count = 0;
        int i;
        boolean result1, result2;
        
        //Count the values one by one
        for (i = 0; i < _sampleSize; i ++) {
            //Skip missing data.
            if (getValueBlindly(i, var) == nV)
                continue;
            
            //Do the comparison of val1 here
            //If less than...
            result1 = doesValueSatisfyConditions(getValueBlindly(i, var), val1, cond1);
            
            //Do the comparison of val2 here
            result2 = doesValueSatisfyConditions(getValueBlindly(i, var), val2, cond2);
            
            //NOTE: If either cond1 or cond2 is NO_CONDITION, then doesValueSatisfyConditions
            //will always return false.  SO, if the and variable is set to false (OR), then
            //the or line below will be used and the NO_CONDITION value will have no impact
            //i.e. if b is false, then if(a OR b) is the same as if(a).
            
            //Check the and condition
            if ( (and)  && ((result1) && (result2)) )
                count ++;
            if ( (!and) && ((result1) || (result2)) )
                count ++;
            
        }
        return count;
    }
    
    /**
     * Counts the number of samples in which a Julian hour variable has a calendar
     * field of a set value.  In other words, all sample for July or all samples for 1993.
     * @param jhourvar The Julian hour variable.
     * @param calendar_field The Calendar (class) field to check.
     * @param value The value it needs to be.
     * @param nV the null value
     * @return The number of samples satisfying condition.
     */
    public int countValues(int jhourvar, int calendar_field, int value, double nV) {
        if ((jhourvar >= _numberOfVariables) || (jhourvar < 0)) {
            //PRINT ERROR MESSAGE HERE
            return (int)nV;
        }
        
        int i;
        int count = 0;
        Calendar date;
        
        //Count the values one by one
        for (i = 0; i < _sampleSize; i ++) {
            //Skip missing data.
            if (getValueBlindly(i, jhourvar) == nV)
                continue;
            
            //Get the calendar corresponding to the julian hour
            date = HCalendar.computeCalendarFromJulianHour((int)getValueBlindly(i, jhourvar));
            
            //If the value of the field calendar_field of date is equal to value,
            //then count it.
            if (date.get(calendar_field) == value) {
                count ++;
            }
        }
        
        return count;
    }
    
    /**
     * Basic tool checking whether a passed in value satisfies a given condition (LESS_THAN,
     * GREATER_THAN, etc.) relative to a base value.
     * @param value The value to check.
     * @param compvalue The value checked against.
     * @param condition The condition checked (see DataSet static variables).
     * @return Either true or false.
     */
    public boolean doesValueSatisfyConditions(double value, double compvalue, int condition) {
        //If less than...
        if ( (condition == LESS_THAN) && (value < compvalue) )
            return true;
        else
            //if less than or equal to...
            if ( (condition == LESS_THAN_OR_EQUAL_TO) && (value <= compvalue) )
                return true;
            else
                //if greater than...
                if ( (condition == GREATER_THAN) && (value > compvalue) )
                    return true;
                else
                    //if greater than or equal to...
                    if ( (condition == GREATER_THAN_OR_EQUAL_TO) && (value >= compvalue) )
                        return true;
                    else
                        //if equal to...
                        if ( (condition == EQUAL_TO) && (value == compvalue) )
                            return true;
                        else
                            //if not equal to...
                            if ( (condition == NOT_EQUAL_TO) && (value != compvalue))
                                return true;
        
        return false;
    }
    
    /**
     * For some reason, this method is necessary, probably for backward compatibility.
     * It just reverses the second and third parameter.
     * @param value
     * @param condition
     * @param compvalue
     */
    public boolean doesValueSatisfyConditions(double value, int condition, double compvalue) {
        return doesValueSatisfyConditions(value, compvalue, condition);
    }
    
    /**
     * Check to see if a value satisfies a two part condition.
     * @param value The value to check.
     * @param cond1 The condition on the first bound.
     * @param val1 The bound value.
     * @param and The and/or connecting the two parts.
     * @param cond2 The condition on the second bound.
     * @param val2 The second bound value.
     * @return Either true or false.
     */
    public boolean doesValueSatisfyConditions(double value,
            int cond1, double val1, boolean and, int cond2, double val2) {
        if ((and) &&
                (doesValueSatisfyConditions(value, cond1, val1) &&
                doesValueSatisfyConditions(value, cond2, val2))) {
            return true;
        }
        if ((!and) &&
                (doesValueSatisfyConditions(value, cond1, val1) ||
                doesValueSatisfyConditions(value, cond2, val2))) {
            return true;
        }
        return false;
    }
    
    
    /////////////////////////////////////////////////////////////////////////
    //CDF Tools
    /////////////////////////////////////////////////////////////////////////
    
    /**
     * Sorts all samples by the passed in variable.  It uses a basic (slow)
     * bubble sort and puts them in ascending order.
     * @param var The variable to sort by.
     * @return Returns false only if the variable is invalid.
     */
    public boolean sortBy(int var) {
        int i, j=0;
        int changed = 1;
        double temp = 0;
        
        if ((var >= _numberOfVariables) || (var < 0)) {
            //PRINT ERROR MESSAGE HERE
            return false;
        }
        bubbleSortBy(var);
        
        return true;
    }
    
    
    /**
     * Performs a generally inefficient bubble sort by the passed in variable.
     * @param var The variable to sort by.
     */
    public void bubbleSortBy(int var) {
        boolean changed = true;
        int i, j = 0;
        double[] temp;
        
        //This does a BUBBLE sort.  It linearly passes through the data swapping any consecutive values
        //that are out of order, relative to each other.  It ends when no swaps are made in one pass.
        while (changed) {
            changed = false;
            i = 1;
            
            //Make a pass through the samples
            while (i < _sampleSize) {
                //If two consecutive values are out of order, swap them.
                if (getValueBlindly(i - 1, var) > getValueBlindly(i, var)) {
                    j = 0;
                    temp = getCopyOfSample(i);
                    setSample(i, getCopyOfSample(i - 1));
                    setSample(i - 1, temp);
                    
                    changed = true;
                }
                i ++;
            }
        }
    }
    
    /////////////////////////////////////////////////////////////////////////
    //Shifting, Scaling, Summing, and Multiplying Variables
    /////////////////////////////////////////////////////////////////////////
    
    /**
     * Shift the variable (column) value for all samples (rows) by the amount.
     * @param var The variable to shift.
     * @param amt The amount to shift the variable.
     * @return Returns false if the variable is invalid.
     */
    public boolean shiftVariable(int var, double amt) {
        if ((var >= _numberOfVariables) || (var < 0)) {
            return false;
        }
        
        int i;
        for (i = 0; i < _sampleSize; i ++)
            setValueBlindly(i, var, getValueBlindly(i, var) + amt);
        //_data[i][var] += amt;
        
        return true;
    }
    
//===============================================================================================
// BUILD AND NAVIGATE DATA SET
//===============================================================================================
    
    /////////////////////////////////////////////////////////////////////////
    //Add To The DataSet
    /////////////////////////////////////////////////////////////////////////
    
    /**
     * Add the sample provided in the array of doubles to the table.  If the sample
     * length does not equal the number of variables in the table, an error occurs.
     * If the number of sample already equals the maximum number of samples, an error
     * occurs.
     * @param sample The sample to add.
     * @return Returns false if an error occurs.
     */
    public boolean addSample(double[] sample) {
        if (sample.length != _numberOfVariables) {
            return false;
        }
        
        if (_sampleSize == _maximumSize) {
            return false;
        }
        
        this.setSampleBlindly(_sampleSize, sample);
        
        _sampleSize ++;
        return true;
    }
    
    /////////////////////////////////////////////////////////////////////////
    //Move Through The DataSet
    /////////////////////////////////////////////////////////////////////////
    
    /**
     * Basic tool that allows for moving from one sample to the next.  It increments
     * a current sample pointer.
     * @return Returns false if there are no more samples.
     */
    public boolean next() {
        if (_currentSample == _sampleSize - 1)
            return false;
        _currentSample ++;
        return true;
    }
    
    /**
     * Resets the current sample pointer to be 0 (for the first sample).
     */
    public void resetPtr() {
        _currentSample = 0;
    }
    
    /////////////////////////////////////////////////////////////////////////
    //Find Sample Index
    /////////////////////////////////////////////////////////////////////////
    
    /**
     * Returns the index of the next sample AFTER that sample corresponding to the
     * current sample pointer that has a the variable value specified.
     * @param var The variable to check.
     * @param value The value it must be.
     * @param nV the null value
     * @return Returns AnalysisUnit.getNullValue() if the variable is invalid or there are no more samples that qualify.
     */
    public int findSampleIndex(int var, double value, double nV) {
        if ((var >= _numberOfVariables) || (var < 0)) {
            return (int)nV;
        }
        
        int i;
        for (i = _currentSample; i < _sampleSize; i ++) {
            if (getValueBlindly(i, var) == value) {
                _currentSample = i;
                return i;
            }
        }
        
        return (int)nV;
    }
    
    /**
     * Returns the index of the next sample AFTER that sample corresponding to the
     * current sample pointer that equals the sample passed in.
     * @param sample The sample to find.
     * @param nV the null value
     * @return Returns AnalysisUnit.getNullValue() if the sample is invalid or if there are no more samples that equal.
     */
    public int findSampleIndex(double[] sample, double nV) {
        if (sample.length != _numberOfVariables) {
            return (int)nV;
        }
        
        int i, j;
        for (i = _currentSample; i < _sampleSize; i ++) {
            for (j = 0; j < _numberOfVariables; j ++) {
                if (getValueBlindly(i, j) != sample[j])
                    break;
            }
            
            if (j == _numberOfVariables) {
                _currentSample = i;
                return i;
            }
        }
        
        return (int)nV;
    }
    
    /**
     * Returns the index of the next sample AFTER that sample corresponding to the
     * current sample pointer that has a the Julian hour variable value specified.
     * The date is converted into GMT prior to calculating its Julian hour.
     * @param var The variable to check.
     * @param date The Calendar value it must be.
     * @param nV the null value
     * @return Returns AnalysisUnit.getNullValue() if the variable is invalid or there are no more samples that qualify.
     */
    public int findSampleIndex(int var, Calendar date, double nV) {
        return findSampleIndex(var, (double)HCalendar.computeJulianHourFromCalendar(date, false),nV);
    }
    
    /**
     * Goes to the next sample AFTER that sample corresponding to the current sample
     * pointer that is equal to the passed in sample.  The current sample pointer is
     * adjusted to point to the found sample.
     * @param sample The sample to search for.
     * @param nV the null value
     * @return Returns false if the sample is not found.
     */
    public boolean gotoNextSample(double[] sample, double nV) {
        //Make sure the sample is of the exact correct length.
        if (sample.length != _numberOfVariables) {
            return false;
        }
        
        boolean done = next();
        while (!done) {
            if (isSampleEqualTo(sample,nV))
                return true;
            
            //I'm using the NOT command (!) because I want to end when next returns FALSE.
            done = !(next());
        }
        
        //I never found it!
        return false;
    }
    
    
    
    /**
     * Goes to the next sample AFTER that sample corresponding to the current sample
     * pointer that satisfies a passed in one part condition.  The current sample pointer
     * is updated.
     * @param var The variable to check.
     * @param condition The condition on the bound.
     * @param value The bound value.
     * @param nV the null value
     * @return Returns false if a sample is not found.
     */
    public boolean gotoNextSample(int var, int condition, double value, double nV) {
        //I pass in OR so that countValues will work (see the NOTE below inside countValues).
        return gotoNextSample(var, condition, value, OR, NO_CONDITION,nV, nV);
    }
    
    /**
     * Goes to the next sample AFTER that sample corresponding to the current sample
     * pointer that satisfies a passed in two part condition.  The current sample pointer
     * is updated.
     * @param var The variable to check.
     * @param cond1 The condition on the first bound.
     * @param val1 The first bound value.
     * @param and The and/or connecting the two parts.
     * @param cond2 The condition on the second bound.
     * @param val2 The second bound value.
     * @param nV the null value
     * @return Returns false if a sample is not found.
     */
    public boolean gotoNextSample(int var, int cond1, double val1, boolean and, 
            int cond2, double val2, double nV) {
        if ((var >= _numberOfVariables) || (var < 0)) {
            return false;
        }
        
        int count = 0;
        boolean result1, result2, done;
        double currentvalue;
        
        //Count the values one by one -- starting with the next() one.
        done = !(next());
        while (!done) {
            //Set the current value
            currentvalue = getCurrentValue(var,nV);
            
            //Skip missing data.
            if (isMissingValue(currentvalue,nV))
                continue;
            
            //Do the comparison of val1 here
            //If less than...
            result1 = doesValueSatisfyConditions(currentvalue, val1, cond1);
            
            //Do the comparison of val2 here
            result2 = doesValueSatisfyConditions(currentvalue, val2, cond2);
            
            //NOTE: If either cond1 or cond2 is NO_CONDITION, then doesValueSatisfyConditions
            //will always return false.  SO, if the and variable is set to false (OR), then
            //the or line below will be used and the NO_CONDITION value will have no impact
            //i.e. if b is false, then if(a OR b) is the same as if(a).
            
            //Check the and condition.  If either of these ifs are satisfied, then return true.
            if ( (and)  && ((result1) && (result2)) )
                return true;
            if ( (!and) && ((result1) || (result2)) )
                return true;
            
            //I want done to be TRUE when I can go no further -- hence I use the NOT operator.
            done = !(next());
        }
        return false;
    }
    
//===============================================================================================
// EDIT ALREADY BUILT DATA SET
//===============================================================================================
    
    /////////////////////////////////////////////////////////////////////////
    //Setting Attributes
    /////////////////////////////////////////////////////////////////////////
    
    /**
     * Sets a specified sample (row) of the data table.  The specified sample index must
     * be one that already exists (i.e. less than the sample size).  The sample array must
     * have the correct number of elements (use getNumberOfVariables). <br>
     * <br>
     * If _makeRowsVariables is true, then the sample in the core DataTable will be a
     * physical copy.  Otherwise, it will be the actual array you passed in (pointer copy).
     * @param numsample The sample index.
     * @param sample The sample.
     * @return Returns false if the sample index or array is invalid.
     */
    public boolean setSample(int numsample, double[] sample) {
        if ((numsample >= _sampleSize) || (numsample < 0)) {
            return false;
        }
        if (sample.length != _numberOfVariables) {
            return false;
        }
        
        if (_makeRowsVariables) {
            _dataTable.setColumnAsCopy(numsample, sample);
        } else {
            _dataTable.setRow(numsample, sample);
        }
        return true;
    }
    
    /**
     * Sets a sample without doing any error checking.  Provides for direct editing of
     * the data table.  <br>
     * <br>
     * If _makeRowsVariables is true, then the sample in the core DataTable will be a
     * physical copy.  Otherwise, it will be the actual array you passed in (pointer copy).
     * @param numsample The sample index.
     * @param sample The sample.
     */
    public void setSampleBlindly(int numsample, double[] sample) {
        if (_makeRowsVariables) {
            _dataTable.setColumnAsCopy(numsample, sample);
        } else {
            _dataTable.setRow(numsample, sample);
        }
    }
    
    /**
     * Sets a specified variable (column) of the data table.  The specified variable must
     * be valid.  The var array must have the correct number of elements equal to the
     * current sample size (NOT the maximum sample size!).  <br>
     * <br>
     * If _makeRowsVariables is false, then the sample in the core DataTable will be a
     * physical copy.  Otherwise, it will be the actual array you passed in (pointer copy).
     * @param numvar The variable number.
     * @param var The data array.
     * @param nV the null value
     * @return Returns false if the variable number or data array is invalid.
     */
    public boolean setVariable(int numvar, double[] var, double nV) {
        
        if ((numvar >= _numberOfVariables) || (numvar < 0)) {
            return false;
        }
        
        if (var == null) {
            makeVariableValuesEqualTo(numvar,nV);
            return true;
        }
        
        if (var.length != _sampleSize) {
            return false;
        }
        
        if (_makeRowsVariables) {
            _dataTable.setRow(numvar, var);
        } else {
            _dataTable.setColumnAsCopy(numvar, var);
        }
        return true;
    }
    
    /**
     * Sets a variable without doing any error checking.  Provides for direct editing of
     * the data table.  <br>
     * <br>
     * If _makeRowsVariables is false, then the sample in the core DataTable will be a
     * physical copy.  Otherwise, it will be the actual array you passed in (pointer copy).
     * @param numvar The sample index.
     * @param var The sample.
     */
    public void setVariableBlindly(int numvar, double[] var) {
        if (_makeRowsVariables) {
            _dataTable.setRow(numvar, var);
        } else {
            _dataTable.setColumnAsCopy(numvar, var);
        }
    }
    
    /**
     * Set a variable value for the sample corresponding to the current sample pointer.
     * @param var The variable to set.
     * @param value The value to set it to.
     * @return Return false if the variable is invalid.
     */
    public boolean setCurrentValue(int var, double value) {
        if ((var >= _numberOfVariables) || (var < 0)) {
            return false;
        }
        
        setValueBlindly(_currentSample, var, value);
        return true;
    }
    
    /**
     * Sets a specific value with the data table.  The sample number must be for
     * an already existing sample (less that the sample size).
     * @param numsample The sample (row) index.
     * @param var The variable (column) index.
     * @param value The value to set it to.
     * @return Returns false if the sample index or variable index are invalid.
     */
    public boolean setValue(int numsample, int var, double value) {
        if ((numsample >= _sampleSize) || (numsample < 0)) {
            return false;
        }
        if ((var > _numberOfVariables) || (var < 0)) {
            return false;
        }
        
        setValueBlindly(numsample, var, value);
        return true;
    }
    
    
    /**
     * Sets a specific value with the data table, but does no problem checking.
     * @param numsample The sample (row) index.
     * @param var The variable (column) index.
     * @param value The value to set it to.
     */
    public void setValueBlindly(int numsample, int var, double value) {
        if (_makeRowsVariables) {
            _dataTable.setValue(var, numsample, value);
        } else {
            _dataTable.setValue(numsample, var, value);
        }
    }
    
    
    
    /**
     * Set a variable value for the sample corresponding to the current sample pointer,
     * assuming that the variable is a Julian hour variable.  The passed in Calendar is
     * converted into GMT prior to computing the Julian hour.
     * @param var The variable.
     * @param date The Calendar object to use.
     * @return Returns false if the variable is invalid.
     */
    public boolean setCurrentValue(int var, Calendar date) {
        if ((var >= _numberOfVariables) || (var < 0)) {
            return false;
        }
        
        setValueBlindly(_currentSample, var,
                (double)HCalendar.computeJulianHourFromCalendar(date, false));
        return true;
    }
    
    /**
     * Sets a specific value with the data table, assuming it a Julian hour variable.
     * The sample number must be for an already existing sample (less that the sample size).
     * The passed in Calendar is converted to GMT prior to calculating the Julian hour.
     * @param numsample The sample (row) index.
     * @param var The variable (column) index.
     * @param date The Calendar object used to compute the Julian hour.
     * @return Returns false if the sample index or variable index is invalid.
     */
    public boolean setValue(int numsample, int var, Calendar date) {
        if ((numsample >= _sampleSize) || (numsample < 0)) {
            return false;
        }
        if ((var > _numberOfVariables) || (var < 0)) {
            return false;
        }
        
        setValueBlindly(numsample, var,
                (double)HCalendar.computeJulianHourFromCalendar(date, false));
        return true;
    }
    
    /**
     * Allows the sample size to be manually set by the user.
     * @param size The sample size.
     * @return Returns false if the size is invalid (i.e. larger than the maximum size).
     */
    public boolean setSampleSize(int size) {
        if ((size > _maximumSize) || (size < 0))
            return false;
        
        _sampleSize = size;
        return true;
    }
    
    /////////////////////////////////////////////////////////////////////////
    //Copying Variables and Samples
    /////////////////////////////////////////////////////////////////////////
    
    /**
     * Copy the contents of one variable (column) to another variable.
     * @param fromvar The index of the variable copied from.
     * @param tovar The index of the variable copied to.
     * @return Returns false if either variable is invalid.
     */
    public boolean copyVarToVar(int fromvar, int tovar) {
        if  ( ((fromvar >= _numberOfVariables) || (fromvar < 0)) ||
                ((tovar   >= _numberOfVariables) || (tovar   < 0)) ) {
            return false;
        }
        
        int i;
        for (i = 0; i < _sampleSize; i ++) {
            setValueBlindly(i, tovar, getValueBlindly(i, fromvar));
        }
        
        return true;
    }
    
    /**
     * Copy the contents of one sample (row) to another sample.
     * @param fromsample The index of the sample copied from.
     * @param tosample The index of the sample copied to.
     * @return Returns false if either index points to a non-existent sample.
     */
    public boolean copySampleToSample(int fromsample, int tosample) {
        if  ( ((fromsample >= _sampleSize) || (fromsample < 0)) ||
                ((tosample   >= _sampleSize) || (tosample   < 0)) ) {
            return false;
        }
        
        int i;
        for (i = 0; i < _numberOfVariables; i ++) {
            setValueBlindly(tosample, i, getValueBlindly(fromsample, i));
        }
        
        return true;
    }
    
    /////////////////////////////////////////////////////////////////////////
    //Merge With Another DataSet
    /////////////////////////////////////////////////////////////////////////
    
    /**
     * Merges the specified DataSet object to this data set.  Both DataSets must
     * have an identical sample size.  It will just add the given table of data to
     * to the end of this table of data.  The data from the data will be COPIED to
     * the new core DataTable.
     * @param thedata The DataSet instance containing the table of data to merge.
     * @param nV the null value
     * @return Returns false if the given DataSet does not have an identical sample size.
     */
    public boolean mergeDataSetsAsVariables(DataSet thedata, double nV) {
        //Check the sample size of thedata with this.  If they don't match, the call is invalid.
        if (thedata.getSampleSize() != _sampleSize ) {
            //PRINT ERROR HERE
            return false;
        }
        
        //Compute the new number of variables.  Create a new DataTable to hold all the variables.
        //Copy the contents from this DataTable to the new one.  And then set this DataTable to be the new one.
        int newnumvars = thedata.getNumberOfVariables() + _numberOfVariables;
        DataTable newTable = DataSet.createDataAttribute(_maximumSize, newnumvars, _makeRowsVariables);
        newTable.copyContentsFromDataTable(_dataTable,nV);
        _dataTable = newTable;
        
        //Loop through each variable within thedata and add each variable to the new DataTable.
        int i, j;
        for (i = 0; i < _sampleSize; i ++) {
            for (j = 0; j < thedata.getNumberOfVariables(); j ++) {
                setValueBlindly(i, _numberOfVariables + j, thedata.getValueBlindly(i, j));
            }
        }
        
        _numberOfVariables = newnumvars;
        return true;
    }
    
    
    
    /**
     * Adds the samples from the passed in DataSet table of data to this table.
     * The passed in DataSet must have the same number of variables for this to work.
     * The new sample will be copied from the data to the core DataTable.
     * @param thedata The data to merge.
     * @param nV the null value
     * @return Returns false if the number of variables do not match.
     */
    public boolean mergeDataSetsAsSamples(DataSet thedata, double nV) {
        if (thedata.getNumberOfVariables() != _numberOfVariables ) {
            //PRINT ERROR HERE
            return false;
        }
        
        //Compute the new number of samples.  Create a new DataTable to hold all the variables.
        //Copy the contents from this DataTable to the new one.  And then set this DataTable to be the new one.
        int newnumsamples = thedata.getSampleSize() + _sampleSize;
        if (newnumsamples > _maximumSize) {
            _maximumSize = newnumsamples;
            DataTable newTable = DataSet.createDataAttribute(_maximumSize, _numberOfVariables, _makeRowsVariables);
            newTable.copyContentsFromDataTable(_dataTable,nV);
            _dataTable = newTable;
        }
        
        //Loop through each sample getting the data for both sets and putting it into the
        //new data set.
        int i, j;
        for (i = 0; i < thedata.getSampleSize(); i ++) {
            addSample(thedata.getCopyOfSample(i));
        }
        
        return true;
    }
    
    /////////////////////////////////////////////////////////////////////////
    //Changing Data Table Size
    /////////////////////////////////////////////////////////////////////////
    
    /**
     * Removes the specified variable from the table.  This will create a new
     * table of data, copy the values over cell by cell and then discard the
     * old table.  This is not the most efficient way to do it.
     * @param var The variable to discard.
     * @return Returns false if the variable is invalid.
     */
    public boolean removeVariable(int var) {
        if ((var >= _numberOfVariables) || (var < 0)) {
            return false;
        }
        
        if (_makeRowsVariables) {
            _dataTable.removeRow(var);
        } else {
            _dataTable.removeColumn(var);
        }
        
        _numberOfVariables --;
        return true;
    }
    
    /**
     * Adds a new variable to the table of data.  This creates a new table of data
     * to store the old data with the new empty variable.  The values will initially
     * be the null value
     * @param nV the null value
     * @return Always returns true.
     */
    public boolean addNewVariable(double nV) {
        if (_makeRowsVariables) {
            _dataTable.addRow(nV);
        } else {
            _dataTable.addColumn(nV);
        }
        
        _numberOfVariables ++;
        return true;
    }
    
    /**
     * Adds a new variable (see addNewVariable above) and then initializes all
     * new variable values to the given value.
     * @param value The value to initialize the variable to.
     * @param nV the null value
     * @return Returns false only if addNewVariable() returns false (i.e. never).
     */
    public boolean addNewVariable(double value, double nV) {
        if (!addNewVariable(nV)) {
            return false;
        }
        return makeVariableValuesEqualTo(_numberOfVariables - 1, value);
    }
    
    /**
     * Removes the specified sample.  It moves all samples below it on the table
     * up one row and then subtracts 1 from the sample size.
     * @param sample The sample to remove.
     * @return Returns false if the sample to remove does not exist.
     */
    public boolean removeSample(int sample) {
        if ((sample < 0) || (sample >= _sampleSize)) {
            //PRINT ERROR: Illegal sample number
            return false;
        }
        
        if (_makeRowsVariables) {
            _dataTable.removeColumn(sample);
        } else {
            _dataTable.removeRow(sample);
        }
        
        _sampleSize --;
        
        return true;
    }
    
    /**
     * Removes the sample corresponding to the current sample pointer.  It
     * repoints the pointer to the preceding sample in the table.
     * @return Returns false only if the current sample point is screwed up (probably never).
     */
    public boolean removeCurrentSample() {
        //The current sample index has to be increased so its no longer pointing at the
        //removed sample.
        _currentSample --;
        return removeSample(_currentSample + 1);
    }
    
    /**
     * Changes the maximum number of samples the table can have.  If the new size is smaller
     * than the current sample size, then this function will not work.  It works by creating
     * a new data table and then using setData to transfer over the sample values.  It
     * then discards the old data table.
     * @param newmax The new maximum sample size.
     * @param nV the null value
     * @return Returns false if the new size is smaller than the current sample size.
     */
    public boolean changeMaximumNumberOfSamples(int newmax, double nV) {
        if (newmax < _sampleSize) {
            return false;
        }
        
        DataTable newTable = DataSet.createDataAttribute(newmax, _numberOfVariables, _makeRowsVariables);
        newTable.setAllValues(nV);
        int i;
        for (i = 0; i < _sampleSize; i ++) {
            if (!_makeRowsVariables) {
                newTable.setRow(i, getCopyOfSample(i));
            } else {
                newTable.setColumnAsCopy(i, getCopyOfSample(i));
            }
        }
        
        _dataTable = newTable;
        _maximumSize = newmax;
        
        return true;
        
    }
    
    /////////////////////////////////////////////////////////////////////////
    //Setting Entire Sample And Variable Values
    /////////////////////////////////////////////////////////////////////////
    
    /**
     * Make all of the variable values for a sample equal to the value specified.
     * @param sample The index of the sample to change.
     * @param value The value to set the variables equal to.
     * @return Returns false if the sample is invalid.
     */
    public boolean makeSampleValuesEqualTo(int sample, double value) {
        if ((sample < 0) || (sample >= _sampleSize)) {
            System.out.println("Error clearing data.");
            return false;
        }
        
        int j;
        for (j = 0; j < _numberOfVariables; j ++) {
            setValueBlindly(sample, j, value);
        }
        
        return true;
    }
    
    /**
     * Make all of the variable values across all samples equal to a specified value.
     * @param var The variable to change.
     * @param value The value to set the variable equal to.
     * @return Returns false if the variable is invalid.
     */
    public boolean makeVariableValuesEqualTo(int var, double value) {
        if ((var >= _numberOfVariables) || (var < 0)) {
            System.out.println("Error clearing data.");
            return false;
        }
        
        int i;
        for (i = 0; i < _sampleSize; i ++) {
            setValueBlindly(i, var, value);
        }
        
        return true;
    }
    
    /**
     * Sets all sample values for a sample to be AnalysisUnit.getNullValue().
     * @param sample The sample to change.
     * @param nV the null value
     * @return Returns false if makeSampleValuesEqualTo returns false.
     */
    public boolean clearSample(int sample, double nV) {
        return makeSampleValuesEqualTo(sample,nV);
    }
    
    /**
     * Sets all variable values for a sample to be AnalysisUnit.getNullValue().
     * @param var The variable to change.
     * @param nV the null value
     * @return Returns false if makeVariableValuesEqualTo returns false.
     */
    public boolean clearVariable(int var, double nV) {
        return makeVariableValuesEqualTo(var,nV);
    }
    
    /**
     * Clears all variables, setting all data values to null.
     * 
     * @param nV the null value
     * @return Should always return true (if not, then an internal error has occurred).
     */
    public boolean clearAllData(double nV) {
        
        //Set sample size so that ENTIRE data set is cleared.
        _sampleSize = _maximumSize;
        
        //Clear it variable by variable.
        int i;
        for (i = 0; i < _numberOfVariables; i ++) {
            if (!clearVariable(i,nV)) {
                return false;
            }
        }
        
        //Sample size is now 0.
        _sampleSize = 0;
        return true;
    }
    
    /**
     * Sets the specified sample's variable values to zero.
     * @param sample The sample to change.
     * @return Returns false if makeSampleValuesEqualTo returns false.
     */
    public boolean makeSampleZero(int sample) {
        return makeSampleValuesEqualTo(sample, 0.0);
    }
    
    /**
     * Sets the specified variable's values to zero.
     * @param var The variable to change.
     * @return Returns false if makeVariableValuesEqualTo returns false.
     */
    public boolean makeVariableZero(int var) {
        return makeVariableValuesEqualTo(var, 0.0);
    }
    
//===============================================================================================
// READ DATA SET
//===============================================================================================
    
    
    /**
     * Should be overridden by any subclass that cares.  If the passed in value is considered
     * a null value or HOLE value, return true.  Else, false.  By default, this returns true
     * for the null value, only.
     * 
     * @param nV the null value
     */
    public boolean isMissingValue(double value, double nV) {
        if (value == nV) {
            return true;
        }
        return false;
    }
    
    
    /**
     * Return the smallest value from var 1 in which the var2 value
     * is greater than the keyvalue specified.  A keyvalue of AnalysisUnit.getNullValue()
     * results in ignoring the var2 condition.  Note that var1 must be
     * valid, but var2 can either be valid or DataSet.NO_VARIABLE.
     * @param var1 The variable being searched.
     * @param var2 The variable used for comparison.
     * @param keyvalue The value var2 must be greater than.
     * @param nV the null value
     * @return The smallest var1 value such that var2 >= keyvalue, or AnalysisUnit.getNullValue() if none found or invalid parameter.
     */
    public double getSmallest(int var1, int var2, double keyvalue, double nV) {
        double current = 0,
                currentother = 0,
                smallest;
        boolean notatend;
        
        if (_sampleSize == 0)
            return nV;
        
        //Check to see that var1 is acceptable, and that var2 is acceptable if it
        //does not equal NO_VARIABLE
        if  ( ((var1 > _numberOfVariables) || (var1 < 0)) ||
                (((var2 > _numberOfVariables) || (var2 < 0)) && (var2 != NO_VARIABLE)) ) {
            return nV;
        }
        
        //Setup for no variable usage if necessary.
        if (var2 == NO_VARIABLE) {
            var2 = var1;
            keyvalue = nV;
        }
        
        resetPtr();
        
        //If the keyvalue was set to missing in the NO_VARIABLE check above, then just get the
        //first value that isn't missing.
        notatend = true;
        if (keyvalue == nV) {
            current = nV;
            while ((isMissingValue(current,nV)) && (notatend)) {
                current = getCurrentValue(var1,nV);
                notatend = next();
            }
        } else {
            //Otherwise Acquire the first var1 value whose other is greater than keyvalue.
            while ((currentother <= keyvalue) && (notatend)) {
                current = getCurrentValue(var1,nV);
                currentother = getCurrentValue(var2,nV);
                notatend = next();
            }
        }
        
        //Check to see if we reached the end of the data set
        if (!notatend) {
            //If the last value did not match the keyvalue condition or the last value
            //was AnalysisUnit.getNullValue(), then return AnalysisUnit.getNullValue()
            if ((currentother <= keyvalue) || (isMissingValue(current,nV)))
                return nV;
            
            //Otherwise, return current
            return current;
        }
        
        //At this point, current will always be some value
        smallest = current;
        
        //Look at the variable value for each sample to find the smallest.
        notatend = true;
        while (notatend) {
            current      = getCurrentValue(var1,nV);
            currentother = getCurrentValue(var2,nV);
            
            //If keyvalue is AnalysisUnit.getNullValue(), 0 will force the keyvalue condition in the next if to always be true
            if (keyvalue == nV)
                currentother = 0;
            
            //If the new value is smaller, and it satisfies the keyvalue requirement, and it isn't AnalysisUnit.getNullValue(),
            //then update smallest
            if ( (current < smallest) && (currentother > keyvalue) && (!isMissingValue(current,nV)) )
                smallest = current;
            
            notatend = next();
        }
        
        resetPtr();
        return smallest;
    }
    
    /**
     * Return the largest value from var 1 in which the var2 value
     * is no greater than the keyvalue specified.  A keyvalue of AnalysisUnit.getNullValue()
     * results in ignoring the var2 condition.  Note that var1 must be
     * valid, but var2 can either be valid or DataSet.NO_VARIABLE.
     * @param var1 The variable being searched.
     * @param var2 The variable used for comparison.
     * @param keyvalue The value var2 must be smaller than.
     * @param nV the null value
     * @return The largest var1 value such that var2 <= keyvalue, or AnalysisUnit.getNullValue() if none found or invalid parameter.
     */
    public double getLargest(int var1, int var2, double keyvalue, double nV) {
        double current = 0,
                currentother = 0,
                largest;
        boolean notatend;
        
        
        if (_sampleSize == 0)
            return nV;
        
        //Check to see that var1 is acceptable, and that var2 is acceptable if it
        //does not equal NO_VARIABLE
        if  ( ((var1 > _numberOfVariables) || (var1 < 0)) ||
                (((var2 > _numberOfVariables) || (var2 < 0)) && (var2 != NO_VARIABLE)) ) {
            //PRINT ERROR MESSAGE HERE
            return nV;
        }
        
        //Setup for no variable usage if necessary.
        if (var2 == NO_VARIABLE) {
            var2 = var1;
            keyvalue = nV;
        }
        
        resetPtr();
        
        //If the keyvalue was set to missing in the NO_VARIABLE check above, then just get the
        //first value.
        notatend = true;
        if (keyvalue == nV) {
            current = nV;
            while (isMissingValue(current,nV) && (notatend)) {
                current = getCurrentValue(var1,nV);
                notatend = next();
            }
        } else {
            //Otherwise Acquire the first var1 value whose other is larger than keyvalue.
            while ((currentother >= keyvalue) && (notatend)) {
                current = getCurrentValue(var1,nV);
                currentother = getCurrentValue(var2,nV);
                notatend = next();
            }
        }
        
        //Check to see if we reached the end of the data set
        if (!notatend) {
            //If the last value did not match the keyvalue condition, then return AnalysisUnit.getNullValue()
            if ((currentother <= keyvalue) || isMissingValue(current,nV))
                return nV;
            
            //Otherwise, return current
            return current;
        }
        
        //At this point, current will always be some value
        largest = current;
        
        //Look at the variable value for each sample to find the smallest.
        notatend = true;
        while (notatend) {
            current      = getCurrentValue(var1,nV);
            currentother = getCurrentValue(var2,nV);
            
            //If keyvalue is AnalysisUnit.getNullValue(), keyvalue + 1 will force the keyvalue condition in the next if to always be true
            if (keyvalue == nV)
                currentother = keyvalue - 1;
            
            //If the new value is larger, and satisfies the keyvalue requirement, and is not AnalysisUnit.getNullValue(),
            //then update largest
            if ( (current > largest) && (currentother < keyvalue) && !isMissingValue(current,nV) )
                largest = current;
            
            notatend = next();
        }
        
        resetPtr();
        return largest;
    }
    
    /**
     * Returns the smallest value for a variable.
     * @param var The variable to search.
     * @param nV the null value
     * @return The smallest value, or AnalysisUnit.getNullValue() if var is invalid.
     */
    public double getSmallest(int var, double nV) {
        return getSmallest(var, NO_VARIABLE, nV, nV);
    }
    
    /**
     * Returns the largest value for a variable.
     * @param var The variable to search.
     * @param nV the null value
     * @return The largest value, or AnalysisUnit.getNullValue() if var is invalid.
     */
    public double getLargest(int var, double nV) {
        return getLargest(var, NO_VARIABLE, nV,nV);
    }
    
    /**
     * Gets the smallest value over a group of variables including only samples
     * for which a specified variable is no less than a keyvalue.  It calls
     * the univariate version of getSmallest multiple times, and then chooses
     * the smallest of these values.
     * @param var An array of variable indices.
     * @param var2 The variable used for comparison.
     * @param keyvalue The value compared against.
     * @param nV the null value
     * @return The smallest value, or AnalysisUnit.getNullValue() if a variable is invalid.
     */
    public double getSmallest(int[] var, int var2, double keyvalue, double nV) {
        int i;
        double currentsmallest, temp;
        
        //Find the smallest one...
        currentsmallest = nV;
        for (i = 0; i < var.length; i ++) {
            temp = getSmallest(var[i], var2, keyvalue,nV);
            
            //If temp IS NOT missing and either currentsmallest IS missing or temp is smaller
            //than currentsmallest, then we've found a smaller smallest.
            if ( !isMissingValue(temp,nV) &&
                    (isMissingValue(currentsmallest,nV) || (temp < currentsmallest)) ) {
                currentsmallest = temp;
            }
        }
        
        return currentsmallest;
    }
    
    /**
     * Gets the largest value over a group of variables including only samples
     * for which a specified variable is no greater than a keyvalue.  It calls
     * the univariate version of getLargest multiple times, and then chooses
     * the largest of these values.
     * @param var An array of variable indices.
     * @param var2 The variable used for comparison.
     * @param keyvalue The value compared against.
     * @param nV the null value
     * @return The largest value, or AnalysisUnit.getNullValue() if a variable is invalid.
     */
    public double getLargest(int[] var, int var2, double keyvalue, double nV) {
        int i;
        double currentlargest, temp;
        
        //Find the smallest one...
        currentlargest = nV;
        for (i = 0; i < var.length; i ++) {
            temp = getLargest(var[i], var2, keyvalue,nV);
            
            //If temp IS NOT missing and either currentsmallest IS missing or temp is smaller
            //than currentsmallest, then we've found a smaller smallest.
            if ( !isMissingValue(temp,nV) &&
                    (isMissingValue(currentlargest,nV) || (temp > currentlargest)) ) {
                currentlargest = temp;
            }
        }
        
        return currentlargest;
    }
    
    
    /**
     * @return Returns the sample size (rows).
     */
    public int getSampleSize() {
        return _sampleSize;
    }
    
    /**
     * @return Returns the maximum allowed sample size (rows).
     */
    public int getMaximumSampleSize() {
        return _maximumSize;
    }
    
    /**
     * @return Returns the number of variables (columns).
     */
    public int getNumberOfVariables() {
        return _numberOfVariables;
    }
    
    /**
     * @return Returns a COPY of the table of data, not the data itself.  The returned double array will ALWAYS
     * have the first index be samples and the second index be variables, so that MatrixMath.printMatrix(...) will
     * print it out as a table.  Use getDataTable to get a non-copy of the original table as seen in memory.
     */
    public double[][] getData() {
        double[][] returnvalue = new double[_sampleSize][_numberOfVariables];
        
        int i;
        for (i = 0; i < _sampleSize; i ++) {
            returnvalue[i] = getCopyOfSample(i);
        }
        
        return returnvalue;
    }
    
    
    /**
     * Get the core DataTable object.
     */
    public DataTable getDataTable() {
        return _dataTable;
    }
    
    
    /**
     * @return Returns a COPY of the sample corresponding the current sample pointer.
     */
    public double[] getCurrentSample() {
        if (_sampleSize == 0)
            return null;
        return getSample(_currentSample);
    }
    
    /**
     * @param index the index
     * @return Returns the specified sample, or null if the index is invalid.  Will attempt to return by
     * pointer, if possible. 
     */
    public double[] getSample(int index) {
        if (_sampleSize == 0)
            return null;
        
        if (_makeRowsVariables) {
            return _dataTable.getCopyOfColumn(index);
        }
        return _dataTable.getRow(index);
    }
    
    
    /**
     * @return Returns a COPY of the sample corresponding the current sample pointer.
     */
    public double[] getCopyOfCurrentSample() {
        if (_sampleSize == 0)
            return null;
        return getCopyOfSample(_currentSample);
    }
    
    /**
     * @param index the index
     * @return Returns a COPY of the specified sample, or null if the index is invalid.
     */
    public double[] getCopyOfSample(int index) {
        if (_sampleSize == 0)
            return null;
        
        if (_makeRowsVariables) {
            return _dataTable.getCopyOfColumn(index);
        }
        return _dataTable.getCopyOfRow(index);
    }
    
    /**
     * @param var The variable index to acquire.
     * @return Returns a COPY of the specified variable, or null if the variable is invalid.
     */
    public double[] getCopyOfVariable(int var) {
        if (_sampleSize == 0)
            return null;
        
        if (_makeRowsVariables) {
            return _dataTable.getCopyOfRow(var);
        }
        return _dataTable.getCopyOfColumn(var);
    }
    
    /**
     * @param var The variable index to acquire.
     * @return Returns the variable double array.  If _makeRowsVariables is false, this will
     * be a physical copy.  Otherwise, it will be a pointer copy.
     */
    public double[] getVariable(int var) {
        if (_sampleSize == 0)
            return null;
        
        if (_makeRowsVariables) {
            return _dataTable.getRow(var);
        }
        return _dataTable.getCopyOfColumn(var);
    }
    
    /**
     * @return Returns the value of the current sample pointer.
     */
    public int getCurrentSampleIndex() {
        return _currentSample;
    }
    
    /**
     * Returns the value of a specified variable for the sample corresponding to
     * the current sample pointer.
     * @param var The variable to acquire.
     * @param nV the null value
     * @return The value, which may be AnalysisUnit.getNullValue(), or AnalysisUnit.getNullValue() if the variable is invalid.
     */
    public double getCurrentValue(int var, double nV) {
        if (_sampleSize == 0)
            return nV;
        if ((var > _numberOfVariables) || (var < 0)) {
            return nV;
        }
        
        return getValueBlindly(_currentSample, var);
    }
    
    /**
     * Gets a value from the data table.
     * @param numsample The index of the sample.
     * @param var The index of the variable.
     * @param nV the null value
     * @return Returns a specific value from the table, or AnalysisUnit.getNullValue() if the sample or variable is invalid.
     */
    public double getValue(int numsample, int var, double nV) {
        if ((numsample >= _sampleSize) || (numsample < 0)) {
            return nV;
        }
        if ((var > _numberOfVariables) || (var < 0)) {
            return nV;
        }
        
        return getValueBlindly(numsample, var);
    }
    
    /**
     * Gets a value blindly, without checking for proper parameters.
     * @param numsample The index of the sample.
     * @param var The index of the variable.
     * @return Returns a specific value from the table, or crashes if a parameter is invalid.
     */
    public double getValueBlindly(int numsample, int var) {
        if (_makeRowsVariables) {
            return _dataTable.getValue(var, numsample);
        }
        return _dataTable.getValue(numsample, var);
    }
    
    /**
     * Gets a value from the data table, assuming that the value is a Julian hour
     * variable, and it returns it as a Calendar (in GMT).
     * @param numsample The index of the sample.
     * @param var The index of the variable.
     * @return Calendar or null if varible or sample is invalid.
     */
    public Calendar getValueAsDate(int numsample, int var) {
        if ((numsample >= _sampleSize) || (numsample < 0)) {
            return null;
        }
        if ((var > _numberOfVariables) || (var < 0)) {
            return null;
        }
        
        return HCalendar.computeCalendarFromJulianHour((int)getValueBlindly(numsample, var));
    }
    
    /**
     * Returns the value of a specified variable for the sample corresponding to
     * the current sample pointer.  It assumes the variable is a Julian hour variable
     * and returns a Calendar (in GMT).
     * @param var The index of the variable.
     * @return Calendar or null if variable is invalid.
     */
    public Calendar getCurrentValueAsDate(int var) {
        if (_sampleSize == 0)
            return null;
        
        if ((var > _numberOfVariables) || (var < 0)) {
            return null;
        }
        
        return HCalendar.computeCalendarFromJulianHour((int)getValueBlindly(_currentSample, var));
    }
    
    /**
     * Gets the _makeRowsVariables flag.
     * @return _makeRowsVariables
     */
    public boolean getMakeRowsVariables() {
        return _makeRowsVariables;
    }
    
    
    
    
//===============================================================================================
// DataSet Creation Tools
//===============================================================================================
    
    /////////////////////////////////////////////////////////////////////////
    //Set Theory:
    /////////////////////////////////////////////////////////////////////////
    
    /**
     * Returns the subset of the current DataSet for which the samples satisfy
     * the passed in condition.  The relative order of samples is maintained in
     * the returned DataSet.
     * @param var The variable to subset based upon.
     * @param condition The condition.
     * @param value The value the condition is applied to.
     * @param nV the null value
     * @return A new DataSet, or null if the variable is invalid or if no samples satisfy the condition.
     */
    public DataSet extractSubset(int var, int condition, double value, double nV) {
        return extractSubset(var, condition, value, OR, NO_CONDITION,nV,nV);
    }
    
    /**
     * Returns a subset using a two-sided condition on a single variable in the
     * DataSet.
     * @param var The variable conditioned upon.
     * @param cond1 The first condition.
     * @param val1 The value the first condition is applied to.
     * @param and The and/or connecting the two conditions.
     * @param cond2 The second condition.
     * @param val2 The value the second condition is applied to.
     * @param nV the null value
     * @return A new DataSet, or null if the variable is invalid or if no samples satisfy condition.
     */
    public DataSet extractSubset(int var, int cond1, double val1, boolean and, int cond2, double val2, double nV) {
        //Make sure the number of values satisfying the conditions is positive.
        //The countValues routine will do a check on jhourvar and return the null value if it is bad.
        //Thus, I don't need to check it, here.
        int numvalues = countValues(var, cond1, val1, and, cond2, val2,nV);
        if (numvalues <= 0) {
            return null;
        }
        
        DataSet newdata = new DataSet(numvalues, _numberOfVariables, nV);
        int i;
        boolean result1, result2;
        
        //Count the values one by one
        for (i = 0; i < _sampleSize; i ++) {
            //Do the comparison of val1 here
            //If less than...
            result1 = doesValueSatisfyConditions(getValueBlindly(i, var), val1, cond1);
            
            //Do the comparison of val2 here
            result2 = doesValueSatisfyConditions(getValueBlindly(i, var), val2, cond2);
            
            //NOTE: If either cond1 or cond2 is NO_CONDITION, then doesValueSatisfyConditions
            //will always return false.  SO, if the and variable is set to false (OR), then
            //the or line below will be used and the NO_CONDITION value will have no impact
            //i.e. if b is false, then if(a OR b) is the same as if(a).
            
            //Check the and condition
            if ( (and)  && ((result1) && (result2)) )
                newdata.addSample(getCopyOfSample(i));
            if ( (!and) && ((result1) || (result2)) )
                newdata.addSample(getCopyOfSample(i));
            
        }
        return newdata;
    }
    
    /**
     * Returns a subset of the DataSet containing samples that satisfy all of the conditions
     * specified.  All passed in arrays must be of equal length, and a single two-sided
     * condition is specified from all arrays for a given index (i.e. the first condition is
     * given by var[0], cond1[0], val1[0], etc.).
     * @param var Array of indices of variables being conditioned on.
     * @param cond1  Array of first conditions in the two sided conditions.
     * @param val1 Array of values the first conditions are applied to.
     * @param and Array of and/or's connecting the two-sided conditions.
     * @param cond2 Array of second conditions in the two sided conditions.
     * @param val2 Array of values the second conditions are applied to.
     * @param nV the null value
     * @return A new DataSet, or null if a passed in parameter is invalid or no samples satisfy all conditions.
     */
    public DataSet extractSubset(int[] var, int[] cond1, double[] val1, boolean[] and, 
            int[] cond2, double[] val2, double nV) {
        //Make sure none of the arrays are null.
        if ((var == null) || (cond1 == null) || (val1 == null) || (and == null) ||
                (cond2 == null) || (val2 == null)) {
            return null;
        }
        
        //Make sure they all have the same non-zero length.
        if ((cond1.length != var.length) || (val1.length != var.length) || (and.length != var.length) ||
                (cond2.length != var.length) || (val2.length != var.length) || (var.length == 0)) {
            return null;
        }
        
        //Grab the subset by calling extractSubset for one variable conditions repeatedly.
        //This is inefficient in terms of speed (it makes many passes through a shrinking DataSet),
        //but not memory (because of garbage collection).
        int i;
        DataSet sub = this;
        for (i = 0; i < var.length; i ++) {
            sub = sub.extractSubset(var[i], cond1[i], val1[i], and[i], cond2[i], val2[i],nV);
            if (sub == null)
                return null;
        }
        
        return sub;
    }
    
    /**
     * Return a subset of the DataSet for which the passed in Julian hour variable contains
     * dates with a calendar-field as specified.
     * @param jhourvar The Julian hour variable conditioned on.
     * @param calendar_field The field, such as Calendar.MONTH or Calendar.DAY_OF_YEAR.
     * @param value The value the field must equal, such as 1 for January (if MONTH).
     * @param nV the null value
     * @return The new DataSet, or null if no samples satisfy the condition.
     */
    public DataSet extractSubset(int jhourvar, int calendar_field, int value, double nV) {
        //Make sure the number of values satisfying the conditions is positive.
        //The countValues routine will do a check on jhourvar and return AnalysisUnit.getNullValue() if it is bad.
        //Thus, I don't need to check it, here.
        int numvalues = countValues(jhourvar, calendar_field, value,nV);
        
        if (numvalues <= 0) {
            return null;
        }
        
        DataSet newdata = new DataSet(numvalues, _numberOfVariables, nV);
        int i;
        Calendar date;
        
        //Count the values one by one
        for (i = 0; i < _sampleSize; i ++) {
            //Skip missing data.
            if (getValueBlindly(i, jhourvar) == nV)
                continue;
            
            //Get the calendar corresponding to the julian hour
            date = HCalendar.computeCalendarFromJulianHour((int)getValueBlindly(i, jhourvar));
            
            //If the value of the field calendar_field of date is equal to value,
            //then count it.
            if (date.get(calendar_field) == value)
                newdata.addSample(getCopyOfSample(i));
        }
        
        return newdata;
    }
    
    /**
     * Return a subset of this DataSet that contains all of the samples, but only the
     * specified variables.
     * @param variables An array of variable indices.
     * @param nV the null value
     * @return The new DataSet, or null if any variable is invalid.
     */
    public DataSet extractSubset(int[] variables, double nV) {
        //Make sure variables has something inside it.
        if (variables == null)
            return null;
        if (variables.length == 0)
            return null;
        
        //Check the variables to make sure they are all valid
        int i;
        for (i = 0; i < variables.length; i ++) {
            if ((variables[i] > _numberOfVariables) || (variables[i] < 0)) {
                return null;
            }
        }
        
        //All the variables are acceptable, so create a data set to contain everything.
        DataSet newdata = new DataSet(_maximumSize, variables.length, nV);
        newdata.setSampleSize(_sampleSize);
        
        for (i = 0; i < variables.length; i ++) {
            newdata.setVariable(i, getCopyOfVariable(variables[i]),nV);
        }
        
        return newdata;
    }
    
    
//===============================================================================================
// QUALITY CONTROL FUNCTIONS
//===============================================================================================
    
    /**
     * @param nV the null value
     * @return Returns true if any samples have any AnalysisUnit.getNullValue() values.
     */
    public boolean isAnyDataMissing(double nV) {
        int i;
        
        for (i = 0; i < _sampleSize; i ++) {
            if (isAnySampleDataMissing(i,nV))
                return true;
        }
        
        return false;
    }
    
    /**
     * @param sample The index of sample to check.
     * @param nV the null value
     * @return Return true if any variable value for the sample is AnalysisUnit.getNullValue().
     */
    public boolean isAnySampleDataMissing(int sample, double nV) {
        if ((sample >= _sampleSize) || (sample < 0)) {
            //PRINT ERROR HERE
            return true;
        }
        
        int j;
        for (j = 0; j < _numberOfVariables; j ++) {
            if (getValueBlindly(sample, j) == nV)
                return true;
        }
        return false;
    }
    
    /**
     * @param var The index of variable to check.
     * @param nV the null value
     * @return Returns true if variable is invalid or if any sample values are AnalysisUnit.getNullValue() for the variable.
     */
    public boolean isAnyVariableDataMissing(int var, double nV) {
        if ((var > _numberOfVariables) || (var < 0)) {
            return true;
        }
        
        int i;
        for (i = 0; i < _sampleSize; i ++) {
            if (getValueBlindly(i, var) == nV)
                return true;
        }
        return false;
    }
    
    /**
     * @param sample Sample to check against.
     * @param nV the null value
     * @return Returns true if the sample corresponding to current sample pointer equals passed in sample.
     */
    public boolean  isSampleEqualTo(double[] sample, double nV) {
        //The sample must be of the exact correct length.
        if (sample.length != _numberOfVariables)
            return false;
        
        //Check the sample one by one.
        int i;
        for (i = 0; i < sample.length; i ++) {
            if (sample[i] != getCurrentValue(i,nV))
                return false;
        }
        return true;
    }
    
    
    /**
     * This method will create a DataTable object for the two passed in dimensions.  The passed in
     * boolean tells it if the first element of the DataTable should be samples (false) or variables
     * (true).  In most cases, true is best so that entire variables can be efficient acquired to pass
     * into graphical packages, such as ChartDirector.
     * @param maximumSamples
     * @param maximumVariables
     * @param makeRowsVariables
     * @return DataTable to be used as _data in a DataSet object.
     */
    protected static DataTable createDataAttribute(int maximumSamples, int maximumVariables,
            boolean makeRowsVariables) {
        if (makeRowsVariables) {
            return new DataTable(maximumVariables,maximumSamples);
        }
        return new DataTable(maximumSamples, maximumVariables);
    }
    
    
    
    //A test main.
    public static void main(String args[]) {
        
        double nV = -999.0;
        
        
        DataSet thedata = new DataSet(5, 3, nV);
        
        thedata.setSampleSize(5);
        thedata.setValue(0, 0, 3);
        thedata.setValue(1, 0, 2);
        thedata.setValue(2, 0, 4);
        thedata.setValue(3, 0, 5);
        thedata.setValue(4, 0, 6);
        thedata.setValue(0, 1, 4);
        thedata.setValue(1, 1, 1);
        thedata.setValue(2, 1, 3);
        thedata.setValue(3, 1, 6);
        thedata.setValue(4, 1, 9);
        thedata.setValue(0, 2, 1);
        thedata.setValue(1, 2, 7);
        thedata.setValue(2, 2, 3);
        thedata.setValue(3, 2, 5);
        thedata.setValue(4, 2, 2);
        
        //Test Subset Stuff
        System.out.println("");
        System.out.println("The Count for var 2 between 2 and 7 is " +
                thedata.countValues(1, DataSet.GREATER_THAN, 2.0, DataSet.AND, DataSet.LESS_THAN, 7.0,nV));
        
        //DataSet newdata = thedata.extractSubset(1, DataSet.GREATER_THAN, 2.0, DataSet.AND, DataSet.LESS_THAN, 7.0);
        System.out.println("The number of samples is... " + thedata.getSampleSize());
        
        Calendar today = Calendar.getInstance();
        today.add(Calendar.YEAR, -100);
        int jh = HCalendar.computeJulianHourFromCalendar(today, false);
        System.out.println("JULIAN HOUR... " + jh);
        HCalendar.computeCalendarFromJulianHour(jh);
        
        ////////////////////// TESTING INTERSECTION AND UNION ///////////////////
        System.out.println("\n>>>>>>>>>> TESTING INTERSECTION AND UNION AND MERGE <<<<<<<<<<\n");
        DataSet thedata2 = new DataSet(5, 3, nV);
        
        thedata2.setSampleSize(5);
        thedata2.setValue(0, 0, 3);
        thedata2.setValue(1, 0, 2);
        thedata2.setValue(2, 0, 10);
        thedata2.setValue(3, 0, 5);
        thedata2.setValue(4, 0, 6);
        thedata2.setValue(0, 1, 4);
        thedata2.setValue(1, 1, 1);
        thedata2.setValue(2, 1, 3);
        thedata2.setValue(3, 1, 6);
        thedata2.setValue(4, 1, 25);
        thedata2.setValue(0, 2, 1);
        thedata2.setValue(1, 2, 7);
        thedata2.setValue(2, 2, 3);
        thedata2.setValue(3, 2, 5);
        thedata2.setValue(4, 2, 2);
        
        
        System.out.println("********************  ORIGINAL 1: *******************");
        System.out.println("********************  ORIGINAL 2: *******************");
        
        DataSet thedata3 = new DataSet(thedata);
        if (thedata3.mergeDataSetsAsVariables(thedata2,nV)) {
            System.out.println("********************  MERGE AS VARIABLE: *******************");
        } else {
            System.out.println("####>> FAILED TO MERGE AS SAMPLE");
        }
        
        thedata3 = new DataSet(thedata);
        if (thedata3.mergeDataSetsAsSamples(thedata2,nV)) {
            System.out.println("********************  MERGE AS SAMPLE: *******************");
        } else {
            System.out.println("####>> FAILED TO MERGE AS SAMPLE");
        }
        
        thedata3.removeVariable(2);
        System.out.println("********************  LAST VARIABLE REMOVED FROM MERGE AS SAMPLE:   (RAW DATA BELOW) *******************");
        
        thedata3.removeSample(1);
        System.out.println("********************  SECOND SAMPLE REMOVED FROM MERGE AS SAMPLE:   (RAW DATA BELOW) *******************");
        
        thedata3.changeMaximumNumberOfSamples(12,nV);
        System.out.println("********************  Increased MAXIMUM number of samples to 12:  (RAW DATA BELOW) *******************");
        
        
        System.out.println("********************  INTERSECTION: *******************  (RAW DATA BELOW) ");
        
        
        System.out.println("******************** UNION: ***************************  (RAW DATA BELOW) ");
        
        thedata2.changeMaximumNumberOfSamples(10,nV);
        thedata2.setSampleSize(6);
        thedata2.makeSampleValuesEqualTo(5, nV);
        System.out.println("\nThe new sample size is ... " + thedata2.getSampleSize());
        System.out.println("The max size is ... " + thedata2.getMaximumSampleSize());
        
        ///////////////////////// TESTING SORTING /////////////////////////////
        
        System.out.println("******************** Data To Sort: ***************************  (RAW DATA BELOW) ");
        
        thedata2.sortBy(2);
        System.out.println("******************** Sorted by 2: ***************************  (RAW DATA BELOW) ");
        
    }
    
}
