package evs.data.fileio;

//EVS dependencies
import evs.metric.results.*;
import evs.metric.parameters.*;

//Java io dependencies
import java.io.*;

//Java util dependencies
import java.util.*;
        
//Apache XML writing
import org.apache.ecs.xml.*;


/**
 * Writes metric results to file in XML format.
 * 
 * @author evs@hydrosolved.com
 */

public class ResultFileIO extends FileIO {

    /********************************************************************************
     *                                                                              *
     *                               MUTATOR METHODS                                *
     *                                                                              *
     *******************************************************************************/
    
    /**
     * Writes the specified results to a specified file.
     *
     * @param resultFile the results file
     * @param result the result
     */
    
    public static void write(File resultFile, MetricResultByLeadTime result) throws IOException {
        if(resultFile == null) {
            throw new IllegalArgumentException("Specify a writeable file for the results data.");
        }
        if(result == null) {
            throw new IllegalArgumentException("Specify a non-null result to write.");
        }
        if(!resultFile.exists()) {
            boolean create = resultFile.createNewFile();
            if(!create) {
                throw new IOException("Unable to create result file for writing.");
            }
        }
        String nL = System.getProperty("line.separator");
        XMLDocument doc = new XMLDocument();
        XMLW top = new XMLW("results") {
            public boolean getNeedLineBreak() {
                return true;
            };
        };  //Root node
        doc.addElement(top);              
        //Explain
        top.addElement("<!--"+nL+"\tResult file containing the results for a single metric by lead period." +nL+
                "\tSome metrics, such as reliability diagrams, have results for specific thresholds " +nL+
                "\t(e.g. probability thresholds).  In that case, the results are stored by lead period " +nL+
                "\tand then by threshold value.  The actual data associated with a result always appears " +nL+
                "\twithin a 'values' tag.  A metric result that comprises a single value will appear as a " +nL+
                "\tsingle value in this tag.  A metric result that comprises a 1D matrix will appear as a " +nL+
                "\trow of values separated by commas in the input order.  A metric result that comprises a " +nL+
                "\t2D matrix will appear as a sequence of rows, each with a 'values' tag, which are written " +nL+
                "\tin the input order.  For example, a diagram metric with an x and y axis will comprise " +nL+
                "\ttwo rows of data (i.e. two rows within two separate 'values' tags).  The default input " +nL+
                "\torder would be data for the x axis followed by data for the y axis.  Data that refer to " +nL+
                "\tcumulative probabilities are, by default, always defined in increasing size of probability."+nL+"-->");
        //Determine the result type for the stored date
        int type = result.getIDForStoredResults();
        //Write some meta-data
        XMLW meta = new XMLW("meta_data") {
            public boolean getNeedLineBreak() {
                return true;
            };
        };   
        top.addElement(meta);
        //Threshold type?
        meta.addElement(new XMLW("thresholds_type").addElement((type==result.METRIC_RESULT_BY_THRESHOLD)+""));
        meta.addElement(new XMLW("original_file_id").addElement(resultFile.getName()+""));
        
        //Add the results
        TreeMap<Double,MetricResult> results = result.getResults();
        Iterator i = results.keySet().iterator();
        //Add the results for a normal node with lead time only
        if(type != result.METRIC_RESULT_BY_THRESHOLD) {
            while(i.hasNext()) {
                double leadHours = (Double)i.next();
                addResultNode(top,leadHours,results.get(leadHours));
            }
        }
        else {
            while(i.hasNext()) {
                double leadHours = (Double)i.next();
                addThresholdResultNode(top,leadHours,(MetricResultByThreshold)results.get(leadHours));
            }
        }
        BufferedOutputStream b = new BufferedOutputStream(new FileOutputStream(resultFile));

        try {
            doc.output(b);
        }
        catch(Throwable e) {
            e.printStackTrace();
            throw new IOException(e.getMessage());
        }
        finally {
            b.close();
        }        
    }       
    
    /********************************************************************************
     *                                                                              *
     *                               PRIVATE METHODS                                *
     *                                                                              *
     *******************************************************************************/    
    
    /**
     * Adds a standard result node to the specified top-level node, comprising a lead
     * period and a result.
     *
     * @param top the top-level node
     * @param leadHours the lead time in hours
     * @param result the metric result
     */
    
    private static XMLW addResultNode(XMLW top, double leadHours, MetricResult result) {
        //Add the lead hours
        XMLW r = new XMLW("result") {
            public boolean getNeedLineBreak() {
                return true;
            };
        }; 
        top.addElement(r);
        r.addElement(new XMLW("lead_hour").addElement(leadHours+""));
        //Add the data node
        addDataNode(r,result);
        return r;
    }
    
    /**
     * Adds a threshold result node to the specified top-level node, comprising a lead
     * period and a set of results recorded by threshold.
     *
     * @param top the top-level node
     * @param leadHours the lead time in hours
     * @param result the metric result
     */
    
    private static XMLW addThresholdResultNode(XMLW top, double leadHours, MetricResultByThreshold result) {
        //Add the lead hours
        XMLW r = new XMLW("result") {
            public boolean getNeedLineBreak() {
                return true;
            };
        }; 
        top.addElement(r);
        r.addElement(new XMLW("lead_hour").addElement(leadHours+""));
        TreeMap<DoubleProcedureParameter,MetricResult> tr = result.getResults();
        Iterator i = tr.keySet().iterator();
        XMLW tNode = new XMLW("threshold_data");
        r.addElement(tNode);
        while(i.hasNext()) {
            DoubleProcedureParameter t = (DoubleProcedureParameter)i.next();
            XMLW thresh = new XMLW("threshold");
            tNode.addElement(thresh);
            thresh.addElement(new XMLW("threshold_value").addElement(t.toXMLString()));
            addDataNode(thresh,tr.get(t));     
        }
        return r;
    }    
    
    /**
     * Adds a data node containing the metric results to a parent node.  
     *
     * @param parent the parent node
     * @param result the result
     */
    
    private static XMLW addDataNode(XMLW parent, MetricResult result) {
        int precision = 5;  //5 d.p precision: might abstract in future
        XMLW data = new XMLW("data");
        parent.addElement(data);
        String[] valueNodes = result.toXMLString(precision);
        for(String n : valueNodes) {
            data.addElement(new XMLW("values").addElement(n));
        }
        //Add sampling interval
        if (result.hasSamplingIntervals()) {
            addSamplingIntervalsNode(data, result, precision);
        }
        return data;
    }

    /**
     * Adds a sampling uncertainty interval node to a specified parent node.
     *
     * @param parent the parent node
     * @param result the metric result
     * @param precision the write precision
     */

    private static void addSamplingIntervalsNode(XMLW parent, MetricResult result, int precision) {
        if (result.hasSamplingIntervals()) {
            XMLW intervals = new XMLW("sampling_intervals");
            parent.addElement(intervals);
            MetricResult sampleSize = null;
            if(result.hasMainInterval()) {
                MetricResult[] r = result.getMainIntervalResults();
                addOneSamplingIntervalNode(intervals,result.getMainInterval(),
                        r,precision,true);
                sampleSize=r[2];
            }
            if(result.hasAncillaryIntervals()) {
                //Add the sampling intervals
                TreeMap<ProbabilityIntervalParameter,MetricResult[]> ints =
                    result.getAncillaryIntervalResults();
                Iterator it = ints.keySet().iterator();
                while(it.hasNext()) {
                    ProbabilityIntervalParameter p = (ProbabilityIntervalParameter) it.next();
                    MetricResult[] rp = ints.get(p);
                    if(sampleSize==null) {
                        sampleSize=rp[2];
                    }
                    addOneSamplingIntervalNode(intervals,p,
                            rp, precision, false);
                }
            }
            //Add sample sizes if required
            if(sampleSize!=null) {
                addSampleSizeNodeForIntervals(intervals,sampleSize);
            }
        }
    }
    
    /**
     * Adds a single sampling uncertainty interval node to a specified parent node.
     *
     * @param parent the parent node
     * @param interval the interval
     * @param bounds the lower and upper bounds of the interval
     * @param precision the write precision
     * @param main is true if the interval is a main interval
     */

    private static void addOneSamplingIntervalNode(XMLW parent, ProbabilityIntervalParameter interval, MetricResult[] bounds, int precision, boolean main) {
        XMLW node = null;
        if(main) {
            node = new XMLW("main_interval");
        } else {
            node = new XMLW("interval");
        }
        parent.addElement(node);
        node.addElement(new XMLW("bounds").addElement(interval.toString()));
        XMLW lower = new XMLW("lower_bound");
        XMLW upper = new XMLW("upper_bound");
        node.addElement(lower);
        node.addElement(upper);
        String[] lowValueNodes = bounds[0].toXMLString(precision);
        String[] upValueNodes = bounds[1].toXMLString(precision);
        for (String n : lowValueNodes) {
            lower.addElement(new XMLW("values").addElement(n));
        }
        for (String n : upValueNodes) {
            upper.addElement(new XMLW("values").addElement(n));
        }
    }

    /**
     * Adds a sample size node for a set of sampling intervals to a specified parent node.
     *
     * @param parent the parent node
     * @param sampleSize the sample size result
     */

    private static void addSampleSizeNodeForIntervals(XMLW parent, MetricResult sampleSize) {
        XMLW samples = new XMLW("sample_size");
        parent.addElement(samples);
        String[] sampleNodes = sampleSize.toXMLString(1);
        //First result is enough: others refer to e.g. specific axes diagram metrics
        samples.addElement(new XMLW("values").addElement(sampleNodes[0]));
    }

/*******************************************************************************
 *                                                                             *
 *                                  TEST METHOD                                *
 *                                                                             *
 ******************************************************************************/     
    
    /**
     * Test method.
     *
     * @param args the args
     */
    
    public static void main(String[] args) {
        
//        ResultFileIO io = new ResultFileIO();
//        File f3 = new File("D:/HEP_projects/Ensemble_verification/Test_data/NFDC1_precip/nfdc1hlf.nfdc1hlf.Precipitation.Mean_capture_rate_diagram.xml");
//        try {
//            System.out.println(io.isOfType(f3));
//        }
//        catch(Exception e) {
//            e.printStackTrace();
//        }
//        
//        try {
//            File f = new File("C:/Documents and Settings/brownj/Desktop/CHTM7.CHTM7PQ.streamflow.Talagrand.xml");
//            MetricResultByLeadTime res = new MetricResultByLeadTime(MetricResult.DOUBLE_MATRIX_2D_RESULT);
//            for(int i = 0; i < 100; i++) {
//                double[][] data = new double[2][12];
//                data[0] = new double[]{0.0,0.1,0.2,0.3,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0};
//                for(int j = 0; j < data[0].length; j++) {
//                    data[1][j] = Math.random();
//                }
//                Arrays.sort(data[1]);
//                res.addResult(i,new DoubleMatrix2DResult(new DenseDoubleMatrix2D(data)));
//            }
//            write(f,res);
//            File f2 = new File("C:/Documents and Settings/brownj/Desktop/CHTM7.CHTM7PQ.streamflow.Reliability.xml");
//            MetricResultByLeadTime res2 = new MetricResultByLeadTime(MetricResult.METRIC_RESULT_BY_THRESHOLD);
//            for(int i = 0; i < 100; i++) {
//                MetricResultByThreshold t = new MetricResultByThreshold(MetricResult.DOUBLE_MATRIX_2D_RESULT);
//                double start = 0.1;
//                for(int k = 0; k < 10; k++) {
//                    double[][] data = new double[2][12];
//                    ProbabilityIdentifierParameter prob = new ProbabilityIdentifierParameter(true);
//                    data[0] = new double[]{0.0,0.1,0.2,0.3,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0};
//                    for(int j = 0; j < data[0].length; j++) {
//                        data[1][j] = Math.random();
//                    }
//                    Arrays.sort(data[1]);
//                    t.addResult(new DoubleProcedureParameter(new IntegerParameter(DoubleProcedureParameter.LESS_THAN),
//                            new DoubleParameter[]{new ProbabilityParameter(start)},prob,new BooleanParameter(true)),
//                            new DoubleMatrix2DResult(new DenseDoubleMatrix2D(data)));
//                    start +=0.1;
//                    start = Mathematics.round(start,5);
//                }
//                res2.addResult(i,t);
//            }
//            write(f2,res2);
//        } catch(Exception e) {
//            e.printStackTrace();
//        }
    }   
}

