
package evs.data.fileio.ohdfile.misc;


import java.util.*;

/////////////////////////////////////////////////////////////////////////////////////////////////
//
//	  Date            Person          Comment
//	  ----------      ------------    ----------------------------------------------
//	  2001-01-09      Hank Herr       First version complete
//
/////////////////////////////////////////////////////////////////////////////////////////////////


/**
 * ================================== <br>
 * The SegmentedLine Class. <br>
 * ================================== <br>
 * <br>
 * This class takes a line of text that contains words separated by known characters and extracts
 * all of the words.  The characters that are treated as separators are passed into the
 * constructor.  It also allows the user to specify if he or she would like for two consecutive
 * separators to be treated as one separator, or to mark an empty word. <br>
 * <br>
 * Within the constructors, the mode specifies whether or not to treat two consecutive separators
 * as defining an "empty" token (MODE_ALLOW_EMPTY_SEGS), or treat two consecutive separators as
 * one separator (MODE_NO_EMPTY_SEGS).  The default in the constructors that do not contain a
 * passed in mode parameter is the first: MODE_ALLOW_EMPTY_SEGS.<br>
 * <br>
 * The method that segments a line is segmentTheLine(String).<br>
 * <br>
 * It is also possible to segment the line based on set indices within the line.  The constructor
 * that accomplishes this is the SegmentedLine(String, int[]) constructor.  The method that
 * is used to segment the line segmentTheLineByFixedWidth(String).<br>
 * <br>
 * The method reconstructLine(...) can be used to build a String corresponding to the segments of
 * the current SegmentLine object, with separators being specified by the first parameter.  The
 * second parameter specifies if the individual elements of the output are to be quoted (useful
 * for building database queries).<br>
 * <br>
 * To navigate the segments found, use the methods getNumberOfSegments() within a for loop and
 * getASegment(int) to acquire each segment.  Or you can use the getNextSegment() method in a
 * while loop, quitting when null is returned.  In this case, call resetPtr() to reset to the
 * first segment.<br>
 */

public class SegmentedLine {
    final static String CLASSNAME="SegmentedLine";
    
    
    public final String DEFAULT_SEPARATORS = " ,;?!:'\"";
    public final static boolean MODE_ALLOW_EMPTY_SEGS = true;
    public final static boolean MODE_NO_EMPTY_SEGS = false;
    
    private Vector   _segments;
    private int      _numsegments;
    private String   _separators;
    private int      _currentptr;
    private boolean  _mode;
    
    //These variables provide linked list capabilities
    private SegmentedLine _prev;
    private SegmentedLine _next;
    
    //The positions array.
    private int[]    _positions;
    
    ////////////////////////////////////////////////////
    //Constructors
    ////////////////////////////////////////////////////
    
    /**
     * Constructor to build an empty instance.
     */
    public SegmentedLine() {
        initialize(null, DEFAULT_SEPARATORS, MODE_ALLOW_EMPTY_SEGS, null);
    }
    
    /**
     * Constructor that initializes the separators to use and the mode.
     * @param separators Collection of characters each of which is a separator.
     * @param mode Either MODE_ALLOW_EMPTY_SEGS or MODE_NO_EMPTY_SEGS.
     */
    public SegmentedLine(String separators, boolean mode) {
        initialize(null, separators, mode, null);
    }
    
    /**
     * Segment the passed in line assuming DEFAULT_SEPARATORS and MODE_ALLOW_EMPTY_SEGS.
     * @param line
     */
    public SegmentedLine(String line) {
        initialize(line, DEFAULT_SEPARATORS, MODE_ALLOW_EMPTY_SEGS, null);
    }
    
    /**
     * Segment the passed in line using the specified separators and MODE_ALLOW_EMPTY_SEGS.
     * @param line
     * @param separators Collection of characters each of which is a separator.
     */
    public SegmentedLine(String line, String separators) {
        initialize(line, separators, MODE_ALLOW_EMPTY_SEGS, null);
    }
    
    /**
     * Segment the passed in line using the specified separators and mode.
     * @param line
     * @param separators Collection of characters each of which is a separator.
     * @param mode Either MODE_ALLOW_EMPTY_SEGS or MODE_NO_EMPTY_SEGS.
     */
    public SegmentedLine(String line, String separators, boolean mode) {
        initialize(line, separators, mode, null);
    }
    
    
    /**
     * Segment the line based on indices of characters with the line.  The positions array
     * specifies the indices as the first index of each new segment.  For each position which
     * is beyond the length of the String, a segment of "" is assumed.  Otherwise it is just
     * the substring from the indexed character to the character immediately before the next
     * indexed character.  The positions must be non-negative and in increasing order!
     * @param line
     * @param positions The positions; all non-negative and in increasing order.
     */
    public SegmentedLine(String line, int[] positions) {
        initialize(line, DEFAULT_SEPARATORS, MODE_ALLOW_EMPTY_SEGS, positions);
    }
    
    /**
     * This does basic initialization for SegmentedLine.  If positions is NOT null, then
     * the line will be segmented based on positions (see the constructor above).  Otherwise it
     * will be segmented based on the separators.
     * @param line
     * @param separators Collection of characters each of which is a separator.
     * @param mode Either MODE_ALLOW_EMPTY_SEGS or MODE_NO_EMPTY_SEGS.
     * @param positions The positions; all non-negative and in increasing order.
     */
    public void initialize(String line, String separators, boolean mode, int[] positions) {
        //I cannot allow a null separators string!
        if (separators == null)
            separators = DEFAULT_SEPARATORS;
        _separators  = separators;
        
        //Initialize other attributes based on what is passed in.
        _prev = null;
        _next = null;
        _mode = mode;
        _numsegments = 0;
        if(positions!=null&&positions.length>0) {
            _positions = new int[positions.length];
            System.arraycopy(positions,0,_positions,0,positions.length);
        }
        //Go no further if line is null.
        if (line == null)
            return;
        
        //Segment the line based on whether or not positions is null.
        if (positions == null)
            segmentTheLine(line);
        else
            segmentTheLineByFixedWidth(line);
    }
    
    
    ////////////////////////////////////////////////////
    //TOOLS
    ////////////////////////////////////////////////////
    
    
    /**
     * Segment the passed in line using the attributes of the class, as defined in the
     * constructors.
     * @param line
     * @return Returns the number of segments found.
     */
    public int segmentTheLine(String line) {
        int i;
        int previous = 0;   //The index of the first character to copy into the next segment
        
        //If line is null, then make it an empty string, so I don't get null ptr problems.
        if (line == null)
            line = "";
        
        //Initialize variables
        _segments = new Vector();
        _currentptr = 0;
        _numsegments = 0;
        
        //Go through each character of line.
        for (i = 0; i < line.length(); i ++) {
            //if the character is a separator or we are at the last character of the line, then...
            if ( (_separators.indexOf(line.charAt(i)) >= 0) || (i == line.length() - 1) ) {
                //if there is nothing between the previous separator and this separator,
                //or if this is the last character in the line.
                if (i == previous) {
                    //If I don't have a seperator and I'm at the end of the line, then add
                    //the one character string.
                    if ( (i == line.length() - 1) && (_separators.indexOf(line.charAt(i)) < 0) ) {
                        _segments.addElement(line.substring(previous, i + 1));
                        _numsegments ++;
                    }
                    
                    //else, If I have a separator and I'm allowing empty segments, then...
                    else if (_mode) {
                        //Add a segment between the two separators
                        _numsegments ++;
                        _segments.addElement("");
                        
                        //If this is also the end of the line, then add a segment between the last
                        //separator and the end of the line.
                        if (i == line.length() - 1) {
                            _numsegments ++;
                        }
                    }
                    
                    //Increment previous without copying anything
                    previous ++;
                }
                //otherwise, we have something to copy...
                else {
                    //If this is the end of the line and its not a separator, then include last char
                    if ( (i == line.length() - 1) && (_separators.indexOf(line.charAt(i)) < 0) ) {
                        _segments.addElement(line.substring(previous, i + 1));
                        _numsegments ++;
                    }
                    
                    //Otherwise
                    else {
                        _segments.addElement(line.substring(previous, i));
                        previous = i + 1;
                        _numsegments ++;
                        
                        //If its the end of the line and I'm allowing empty segments, then I have to
                        //add an empty segment
                        if ((_mode) && (i == line.length() - 1)) {
                            _numsegments ++;
                            _segments.addElement("");
                        }
                    }
                }
            }
        }
        
        return _numsegments;
        
        //_segments now contains all of the segments of the line
    }
    
    
    /**
     * Segment the line based on indices of characters in the given string specified by
     * the _positions attribute.
     * @param line
     * @return Returns the number of segments found.
     */
    public int segmentTheLineByFixedWidth(String line) {
        _numsegments = 0;
        _segments = new Vector();
        int i;
        
        //Check for null.
        if ( (line == null) || (_positions == null) )
            return _numsegments;
        
        //Make sure the positions are valid by seeing if they are consecutive and within the
        //size of the string.
        for (i = 0; i < _positions.length; i ++) {
            //The positions must be positive or zero.
            if (_positions[i] < 0)
                return _numsegments;
            
            //if i > 0, the position must be larger than the previous position.
            if (i > 0) {
                if (_positions[i] <= _positions[i - 1])
                    return _numsegments;
            }
        }
        
        //The positions are valid.
        
        //Initialize some variables.
        int prevpos = 0;
        int currentpos;
        
        //Startpt tells me to start at 0, if the first element in the pos array is NOT 0, otherwise
        //start at 1.
        int startpt = 0;
        if (_positions[0] == 0)
            startpt = 1;
        for (i = startpt; i < _positions.length; i ++) {
            currentpos = _positions[i];
            
            //If I am off the end of the string completely, just add "".
            if (prevpos >= line.length())
                _segments.addElement("");
            //Otherwise add the substring.
            else
                _segments.addElement( line.substring( prevpos, Math.min(currentpos, line.length()) ) );
            
            prevpos = currentpos;
        }
        
        //Set and return the number of segments.
        _numsegments = _segments.size();
        return _numsegments;
    }
    
    /**
     * Reconstruct the segmented line with one specific separator between segments.
     * If quoteelements is true, then each element should be in separate quotes after
     * reconstruction.
     * @param separator The separator(s) used in the reconstructed line.
     * @param quoteelements If true, the line will have each segment in double quotes.
     * @return segmented line
     */
    public String reconstructLine(String separator, boolean quoteelements) {
        return reconstructLine(separator, quoteelements, false);
    }
    
    /**
     * Reconstruct the segmented line with one specific separator between segments.
     * If quoteelements is true, then each element should be in separate quotes after
     * reconstruction.
     * @param separator The separator(s) used in the reconstructed line.
     * @param quoteelements If true, the line will have each segment in quotes.
     * @param singlequotes If true, the line will use single quotes.  Otherwise
     * it will use double quotes.
     * @return segmented line
     */
    public String reconstructLine(String separator, boolean quoteelements, boolean singlequotes) {
        StringBuffer masterstr = new StringBuffer();
        int i;
        
        //Set the quotation mark.
        char quote = '"';
        if (singlequotes) {
            quote = '\'';
        }
        
        //Build the string from the segments.
        for (i = 0; i < _numsegments; i ++) {
            //If I am to quote the elements, then do so here...
            if (quoteelements)
                masterstr.append(quote);
            
            masterstr.append((_segments.elementAt(i)));
            
            //...and do so here
            if (quoteelements)
                masterstr.append(quote);
            
            //Don't add the separator if this is the last segment to add.
            if (i < _numsegments - 1)
                masterstr.append(separator);
        }
        
        //Return the master string.
        return masterstr.toString();
    }
    
    /**
     * Removes any repeat segments.  This will result in a group of segments each of which
     * is unique.
     * @param ignorecase If true, case will be ignored in comparing segments.
     */
    public void removeRepeats(boolean ignorecase) {
        //I need two loops going.
        int i, j;
        
        //The first loop starts at the end and works its way forward up to
        //segment number 1.
        for (i = _numsegments - 1; i > 0 ; i --) {
            //The second loops from the beginning and goes up to the value
            //of i minus 1.
            for (j = 0; j < i; j ++) {
                //If the two segments are equal, remove the one pointed to by i
                //And quit from this internal loop.
                if ( ((ignorecase)  && (getASegment(i).equalsIgnoreCase(getASegment(j)))) ||
                        ((!ignorecase) && (getASegment(i).equals(          getASegment(j)))) ) {
                    removeSegment(i);
                    break;
                }
            }
        }
    }
    
    
    /**
     * Removes the segment at the specified index.  If the index is invalid, nothing happens.
     * @param index
     */
    public void removeSegment(int index) {
        if ( (index < 0) || (index >= _numsegments) )
            return;
        
        _numsegments --;
        _segments.remove(index);
    }
    
    ////////////////////////////////////////////////////
    //Sets and Gets
    ////////////////////////////////////////////////////
    public void setSeparators(String separators) {
        if (separators == null)
            _separators = "";
        else
            _separators = separators;
    }
    
    public void setPositions(int[] positions) {
        if (positions == null) {
            return;
        }
        if (positions.length == 0) {
            return;
        }
        _positions = new int[positions.length];
        System.arraycopy(positions, 0, _positions, 0, positions.length);
    }
    
    public int getNumberOfSegments() {
        return _numsegments;
    }
    
    public String getSeparators() {
        return _separators;
    }
    
    /**
     * The tool normally used to acquire a segment.
     * @param num The index of the segment to acquire.
     * @return The segment returned as a String.
     */
    public String getASegment(int num) {
        if ((num < 0) || (num >= _numsegments))
            return null;
        
        return (String)_segments.elementAt(num);
    }
    
    public String getNextSegment() {
        if (_currentptr == _segments.size()) {
            return null;
        }
        
        _currentptr ++;
        return (String)_segments.elementAt(_currentptr - 1);
    }
    
    public Vector getSegments() {
        return _segments;
    }
    
    public void setSegments(Vector segments) {
        if (segments == null)
            return;
        _segments = segments;
        _numsegments = _segments.size();
    }
    
    public void resetPtr() {
        _currentptr = 0;
    }
    
    
    ////////////////////////////////////////////////////
    //Linked List Methods
    ////////////////////////////////////////////////////
    
    //Set the next item in linked list
    public void setNextItem(SegmentedLine aline) {
        _next = aline;
    }
    
    //Get the next item
    public SegmentedLine getNextItem() {
        return _next;
    }
    
    //Set the previous item
    public void setPrevItem(SegmentedLine aline) {
        _prev = aline;
    }
    
    //Get the previous item
    public SegmentedLine getPrevItem() {
        return _prev;
    }
    
    
    ////////////////////////////////////////////////////
    //TEST MAIN
    ////////////////////////////////////////////////////
    public static void main(String args[]) {
        //SegmentedLine segline = new SegmentedLine(args[0], "|", false);
        int[] pos = {20, 27, 34};
        SegmentedLine segline = new SegmentedLine(args[0], pos);
        
        System.out.println("Number of segments... " + segline._numsegments);
        System.out.println("Second segment... " + segline.getASegment(1));
        boolean done = false;
        String item;
        while (!done) {
            item = segline.getNextSegment();
            if (item == null)
                done = true;
            else
                System.out.println("####>> " + segline._currentptr + " = " + item);
        }
    }
}




