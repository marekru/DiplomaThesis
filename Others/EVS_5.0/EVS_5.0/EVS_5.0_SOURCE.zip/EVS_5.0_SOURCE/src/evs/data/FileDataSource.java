package evs.data;

//Java io dependencies
import java.io.File;

/**
 * Constructs a file data source with a single file.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class FileDataSource extends DataSource {
    
    /**
     * Creates a file data source with a single file, which cannot be null.
     * 
     * @param data the file data source
     */
    
    public FileDataSource(final File data) {
        if(data == null) {
            throw new IllegalArgumentException("Specify non-null input for the file data source.");
        }
        this.data = data;
    }
    
    /**
     * Returns true if the data source is readable, false otherwise.
     *
     * @return true if the data are readable.
     */
    
    public boolean canRead() {
        return ((File)data).canRead();
    }    
    
	/**
	 * Returns true if the data source can be written, false otherwise.
	 * 
	 * @return true if the data source can be written
	 */

	public boolean canWrite() {
        return ((File)data).canWrite();
    }    
    
    /**
     * Returns a string representation of the receiver. 
     *
     * @return a string representation
     */
    
    public String toString() {
        return ((File)data).getPath();  //JB @ August 2012 .getAbsolutePath()
    }
    
    /**
     * Returns true if the objects are the same (tests the underlying data
     * objects).
     *
     * @return true if the objects are the same
     */
    
    public boolean equals(Object obj) {
        if(! (obj instanceof FileDataSource)) {
            return false;
        }
        return data.equals(((FileDataSource)obj).getData());
    }   
    
    /**
     * Override hashcode.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        return toString().hashCode();
    }    
    
}
