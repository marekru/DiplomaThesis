package evs.data;

/**
 * A class used to identify the I/O state of an object being read or written.
 * 
 * @author evs@hydrosolved.com
 */

public class IOState {

    /**
     * Is true to continue I/O, false to stop.
     */
    
    private boolean ioState = true;
    
    /**
     * Returns the I/O state.
     * 
     * @return true if the I/O state is true, false otherwise
     */
    
    public boolean getIOState() {
        return ioState;
    }
    
    /**
     * Sets the IO state.
     * 
     * @param ioState the I/O state.
     */
 
    public void setIOState(boolean ioState) {
        this.ioState = ioState;
    }
}
