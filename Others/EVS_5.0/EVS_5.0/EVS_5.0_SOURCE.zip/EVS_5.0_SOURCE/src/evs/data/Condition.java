package evs.data;

//EVS dependencies
import evs.analysisunits.VerificationUnit;
import evs.utilities.matrix.BooleanMatrix1D;
import evs.utilities.matrix.DoubleMatrix2D;

/**
 * An abstract base class for specifying conditions to restrict a verification 
 * study.  Examples of such restrictions might include a restricted set of dates
 * or variable values.  A verification condition always belongs to a specific
 * verification unit.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public abstract class Condition {
    
    /********************************************************************************
     *                                                                              *
     *                               CLASS VARIABLES                                *
     *                                                                              *
     *******************************************************************************/
    
    /**
     * Identifier for a forecast data structure with dates, lead times and the 
     * first forecast in the first, second and third columns, respectively.
     */
    
    public static final int FORECAST_DATA = 201;
    
    /**
     * Identifier for on observed data structure with dates and observations in
     * the first and second columns, respectively.
     */
    
    public static final int OBSERVED_DATA = 202;   
    
    /**
     * Identifier for a paired data structure with dates, lead times, observations 
     * and the first forecast in the first, second, third and fourth columns, 
     * respectively.
     */
    
    public static final int PAIRED_DATA = 203;       
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/        

    /**
     * Applies the condition, returning a 1D matrix of boolean values whose elements
     * indicate which rows should be used, where true indicates a row should be
     * used. The input data may contain either observed data (i.e. two columns,
     * with valid time and observations), forecasts (valid time, lead time, and members) 
     * or paired data (valid time, lead time, observations and members).  
     *
     * The data type is one of {@link #FORECAST_DATA}, {@link #PAIRED_DATA} or 
     * {@link #OBSERVED_DATA}.
     * 
     * @param d the data
     * @param dataType the data type
     * @return the rows that should be used given the condition
     */    
    
    public abstract BooleanMatrix1D apply(DoubleMatrix2D d, int dataType) throws IllegalArgumentException;    
    
    /**
     * Returns a deep copy of the verification condition where all attributes of
     * the returned condition are independent (i.e. separate objects in memory)
     * from those in the current unit.  The values of the attributes remain the
     * same.
     *
     * @return a deep copy
     */
    
    public abstract Condition deepCopy();        
    
    /**
     * Returns true if a condition can be applied to a specified verification 
     * unit, otherwise returns false or throws an exception if the condition is false 
     * and throwEx is true.
     *
     * @param vu the verification unit
     * @param throwEx the exception
     * @return true if the condition can be applied, false otherwise
     */
    
    public abstract boolean canApplyCondition(VerificationUnit vu, boolean throwEx) throws IllegalArgumentException;
        
}
