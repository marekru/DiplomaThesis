package evs.data.fileio.netcdf;

//Java dependencies
import java.io.IOException;
import java.util.Date;
import java.util.List;

//UCAR dependencies
import ucar.nc2.Attribute;
import ucar.nc2.Dimension;
import ucar.nc2.NetcdfFile;
import ucar.nc2.Variable;
import ucar.nc2.units.DateUnit;

/**
 * This class contains utility methods for reading/writing data from/to netcdf
 * files. Based on org.openda.exchange.dataobjects.NetcdfUtils
 *
 * @author Frederik van den Broek
 */
public class NetcdfUtils {

    private static final String AXIS_ATTRIBUTE_NAME = "axis";
    private static final String COORDINATES_ATTRIBUTE_NAME = "coordinates";
    public static final int VARIABLE_IDENTIFICATION_METHOD_VARIABLE_NAME = 0;
    public static final int VARIABLE_IDENTIFICATION_METHOD_STANDARD_NAME_ATTRIBUTE = 1;
    public static final int VARIABLE_IDENTIFICATION_METHOD_LONG_NAME_ATTRIBUTE = 2;
    //attribute names.
    private static final String STANDARD_NAME_ATTRIBUTE = "standard_name";
    private static final String LONG_NAME_ATTRIBUTE = "long_name";
    public static final String STATIONS_VARIABLE_NAME = "stations";
    public static final String REALIZATION_VARIABLE_NAME = "realization";
    public static final String STATION_ID_VARIABLE = "station_id";
    public static final String STATION_NAME_VARIABLE = "station_names";

    /**
     * Reads the times from the given timeVariable and converts them to long
     * values (from {@link java.util.Date#getTime()} in the returned array.
     *
     * @param timeVariable
     * @return times array.
     * @throws IOException
     */
    public static long[] readTimes(Variable timeVariable) throws IOException {
        long[] convertedTimes = new long[0];

        if ((timeVariable != null) && timeVariable.isCoordinateVariable()) {
            //read times.
            ucar.ma2.Array timesArray = timeVariable.read();
            double[] times = (double[]) timesArray.get1DJavaArray(double.class);

            //convert times.
            convertedTimes = new long[times.length];
            DateUnit dateUnit = getDateUnitFromDimension(timeVariable);
            for (int n = 0; n < times.length; n++) {
                Date date = dateUnit.makeDate(times[n]);
                if (date == null) {
                    convertedTimes[n] = 0;
                    continue;
                }

                long time = date.getTime();
                convertedTimes[n] = time;
            }
        }

        return convertedTimes;
    }

    /**
     * Searches all the variables that the given variable depends on, and
     * returns the first variable that is a valid time variable. If cannot find
     * a valid time variable, then returns null.
     *
     * @param variable
     * @param netcdfFile
     * @return timeVariable or null.
     */
    public static Variable findTimeVariableForVariable(Variable variable, NetcdfFile netcdfFile) {
        List<Dimension> dimensions = variable.getDimensions();
        for (Dimension dimension : dimensions) {
            Variable dimensionVariable = netcdfFile.findVariable(dimension.getName());
            if (dimensionVariable == null || !dimensionVariable.isCoordinateVariable()) {
                continue;
            }

            if (isTimeVariable(dimensionVariable)) {
                return dimensionVariable;
            }
        }

        //search auxiliary coordinate variables.
        //according to the CF-convention (see http://cf-pcmdi.llnl.gov/documents/cf-conventions/1.5/cf-conventions.html#coordinate-system):
        //"An application that is trying to find the latitude coordinate of a variable should always look first to see
        //if any of the variable's dimensions correspond to a latitude coordinate variable. If the latitude coordinate
        //is not found this way, then the auxiliary coordinate variables listed by the coordinates attribute should
        //be checked. Note that it is permissible, but optional, to list coordinate variables as well as auxiliary
        //coordinate variables in the coordinates attribute. The axis attribute is not allowed for auxiliary coordinate
        //variables. Auxiliary coordinate variables which lie on the horizontal surface can be identified as such by their
        //dimensions being horizontal. Horizontal dimensions are those whose coordinate variables have an axis attribute
        //of X or Y, or a units attribute indicating latitude and longitude (see Chapter 4, Coordinate Types ).
        String coordinates = getAttributeStringValue(variable, COORDINATES_ATTRIBUTE_NAME);
        if (coordinates != null) {
            String[] strings = coordinates.split("\\s+");
            for (String auxiliaryCoordinateVariableName : strings) {
                Variable auxiliaryCoordinateVariable = netcdfFile.findVariable(auxiliaryCoordinateVariableName);
                if (auxiliaryCoordinateVariable == null) {
                    continue;
                }

                if (isTimeVariable(auxiliaryCoordinateVariable)) {
                    return auxiliaryCoordinateVariable;
                }
            }
        }

        return null;
    }

    /**
     * Returns the trimmed String value of the attribute with the given
     * attributeName for the given variable.
     *
     * @param variable
     * @param attributeName
     * @return String or null.
     */
    private static String getAttributeStringValue(Variable variable, String attributeName) {
        Attribute attribute = variable.findAttribute(attributeName);
        if (attribute == null) {
            return null;
        }

        String value = attribute.getStringValue();
        if (value == null) {
            return null;
        }

        return value.trim();
    }

    /**
     * Returns true if the given variable is a valid time variable.
     *
     * @param variable
     * @return whether the given variable is a valid time variable.
     */
    private static boolean isTimeVariable(Variable variable) {
        //check if axis is "T".
        if ("T".equalsIgnoreCase(getAttributeStringValue(variable, AXIS_ATTRIBUTE_NAME))) {
            return true;
        }

        //check if unit of time.
        //according to the CF-convention (see http://cf-pcmdi.llnl.gov/documents/cf-conventions/1.5/cf-conventions.html#time-coordinate):
        //"A time coordinate is identifiable from its units string alone.
        //The Udunits routines utScan() and utIsTime() can be used to make this determination."
        //TODO use Udunits routines utScan() and utIsTime() instead of ucar.nc2.units.DateUnit. AK
        if (variable.getUnitsString() != null && !variable.getUnitsString().isEmpty()
                && getDateUnitFromDimension(variable) != null) {
            //if variable has a valid unit of time.
            return true;
        }

        return false;
    }

    /**
     * @param var
     * @return DateUnit converted unit for this
     * <code>var</code> null if conversion to DateUnit throws an exception
     */
    private static DateUnit getDateUnitFromDimension(Variable var) {
        try {
            String unitString = var.getUnitsString();
            DateUnit unit = new DateUnit(unitString);
            return unit;
        } catch (Exception e) {
            //if the given variable does not have a valid unit of time.
            return null;
        }
    }

    /**
     * Returns the externalParameterId for the given variable depending on the
     * given variableIdentificationMethod.
     *
     * @param variable
     * @param variableIdentificationMethod
     * @return externalParameterId can be null if standard name or long name is
     * not defined for the given variable.
     */
    public static String getExternalParameterId(Variable variable, int variableIdentificationMethod) {
        switch (variableIdentificationMethod) {
            case VARIABLE_IDENTIFICATION_METHOD_VARIABLE_NAME:
                return variable.getFullName();

            case VARIABLE_IDENTIFICATION_METHOD_STANDARD_NAME_ATTRIBUTE:
                Attribute attribute = variable.findAttributeIgnoreCase(STANDARD_NAME_ATTRIBUTE);
                if (attribute == null) {//if no standard name present.
                    return null;
                }
                return attribute.getStringValue();

            case VARIABLE_IDENTIFICATION_METHOD_LONG_NAME_ATTRIBUTE:
                attribute = variable.findAttributeIgnoreCase(LONG_NAME_ATTRIBUTE);
                if (attribute == null) {//if no long name present.
                    return null;
                }
                return attribute.getStringValue();

            default:
                throw new IllegalArgumentException("Unknown variable identification method " + variableIdentificationMethod);
        }
    }
}
