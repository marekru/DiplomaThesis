package evs.data.fileio.ohdfile.data;

//EVS dependencies
import evs.analysisunits.AnalysisUnit;

/**
 * This class wraps around a table of data.  It provides raw methods to access rows, columns, etc.
 * It does no checking of parameters, however, so the calling methods must know the size of the table
 * and pass in valid rows and columns, or an array exception may occur.
 * @author hank herr
 */

public class DataTable {
    public static final String CLASSNAME = "DataTable";
    
    private double[][] _data;
    
    
    /**
     * Basic constructor creates the data using the row and column dimensions passed in.
     * The row dimension is the FIRST dimension, column is second... i.e. _data[row][column].
     * @param numberOfRows The number of rows.
     * @param numberOfColumns The number of columns.
     */
    public DataTable(int numberOfRows, int numberOfColumns) {
        _data = new double[numberOfRows][numberOfColumns];
    }
    
    
    public double[][] getData() {
        return _data;
    }
    
    public int getNumberOfRows() {
        return _data.length;
    }
    
    public int getNumberOfColumns() {
        return _data[0].length;
    }
    
    /**
     * Sets a value within the data table at the specified row and column, without doing any checks.
     * @param row Index of row
     * @param column Index of column
     * @param value The value to set it to.
     */
    public void setValue(int row, int column, double value) {
        _data[row][column] = value;
    }
    
    
    /**
     * Gets the value within the passed in cell.
     * @param row Index of row
     * @param column Index of column
     *
     */
    public double getValue(int row, int column) {
        return _data[row][column];
    }
    
    
    /**
     * Sets the passed in row to be the given row array.  IMPORTANT: The setting is a literal '=' operation,
     * so the passed in row is not a physical copy of the given row array, but is the actual row array.
     * This does no checking to make sure the passed in rowArray is of the right size!  It should be the same size
     * as all other rows.
     * @param row Index of rows.
     * @param rowArray array of doubles comprising the row.
     */
    public void setRow(int row, double[] rowArray) {
        _data[row] = rowArray;
    }
    
    
    /**
     * Get the row, itself, not a copy.
     */
    public double[] getRow(int row) {
        return _data[row];
    }
    
    
    /**
     * Sets the passed in row as a copy of the given rowArray.
     * @param row Index of rows.
     * @param rowArray array of doubles comprising the row.
     *
     */
    public void setRowAsCopy(int row, double[] rowArray) {
        double[] rowValues = DataTable.copyArray(rowArray);
        setRow(row, rowValues);
    }
    
    
    /**
     * Get a copy of the row.
     */
    public double[] getCopyOfRow(int row) {
        return DataTable.copyArray(_data[row]);
    }
    
    
    /**
     * Copies the passed in columnArray into the column pointed to by column.
     */
    public void setColumnAsCopy(int column, double[] columnArray) {
        int i;
        for (i = 0; i < columnArray.length; i ++) {
            _data[i][column] = columnArray[i];
        }
    }
    
    /**
     * Gets a copy of the column.
     */
    public double[] getCopyOfColumn(int column) {
        double[] columnValues = new double[_data.length];
        int i;
        for (i = 0; i < columnValues.length; i ++) {
            columnValues[i] = _data[i][column];
        }
        return columnValues;
    }
    
    /**
     * Sets all the values of the double array to the passed in number.
     */
    public void setAllValues(double value) {
        int i;
        int j;
        for (i = 0; i < _data.length; i ++) {
            for (j = 0; j < _data[i].length; j ++) {
                _data[i][j] = value;
            }
        }
    }
    
    
    /**
     * Adds a row to the _data table.  The row is made new, and is not initialized,
     * meaning it picks up the default Java initialization of DataSet.MISSING.
     * 
     * @param nV the null value
     */
    public void addRow(double nV) {
        double[][] oldData = _data;
        _data = new double[oldData.length + 1][oldData[0].length];
        int i;
        for (i = 0; i < oldData.length; i ++) {
            setRow(i, oldData[i]);
        }
        setRow(oldData.length, DataTable.createAllMissingArray(oldData[0].length,nV));
    }
    
    
    /**
     * Adds a column to the _data table by increasing the size of each row by 1.  The new
     * value will be set to the null value.
     * 
     * @param nV the null value
     */
    public void addColumn(double nV) {
        int i;
        double[] newRow;
        int j;
        for (i = 0; i < _data.length; i ++) {
            newRow = new double[_data[i].length + 1];
            for (j = 0; j < newRow.length - 1; j ++) {
                newRow[j] = _data[i][j];
            }
            newRow[j] = nV;
            setRow(i, newRow);
        }
    }
    
    
    /**
     * Removes the row pointed to by index.
     */
    public void removeRow(int index) {
        double[][] newData = new double[getNumberOfRows() - 1][getNumberOfColumns()];
        int i;
        
        for (i = 0; i < getNumberOfRows(); i ++) {
            if (i < index) {
                newData[i] = getRow(i);
            }
            if (i > index) {
                newData[i - 1] = getRow(i);
            }
        }
        
        _data = newData;
    }
    
    
    /**
     * Removes the column pointed to by index.  This is less memory efficient that removeRow.
     */
    public void removeColumn(int index) {
        double[][] newData = new double[getNumberOfRows()][getNumberOfColumns() - 1];
        
        int i;
        int j;
        for (i = 0; i < getNumberOfRows(); i ++) {
            for (j = 0; j < getNumberOfColumns(); j ++) {
                if (j < index) {
                    newData[i][j] = getValue(i, j);
                }
                if (j > index) {
                    newData[i][j - 1] = getValue(i, j);
                }
            }
        }
        
        _data = newData;
    }
    
    
    /**
     * Copy the contents of the passed in DataTable to this DataTable.  This is a copy!!!
     * It will attempt to do a cell by cell copy.  If a cell in this table is found to be invalid in
     * the other table, then that cell will be set to MISSING.
     * DataTable otherTable The table to copy from.
     * 
     * @param nV the null value
     */
    public void copyContentsFromDataTable(DataTable otherTable, double nV) {
        int i, j;
        for (i = 0; i < _data.length; i ++) {
            for (j = 0; j < _data[0].length; j ++) {
                if ( (i < otherTable.getNumberOfRows()) && (j < otherTable.getNumberOfColumns())) {
                    _data[i][j] = otherTable.getValue(i, j);
                } else {
                    _data[i][j] = nV;
                }
            }
        }
    }
    
    
    /**
     * Return an array of all MISSING values of the length passed in.
     * 
     * @param nV the null value
     */
    public static double[] createAllMissingArray(int quantity, double nV) {
        double[] returnArray = new double[quantity];
        int i;
        for (i = 0; i < quantity; i ++) {
            returnArray[i] = nV;
        }
        return returnArray;
    }
    
    
    /**
     * Creates a physical copy of the passed in array and returns it.
     * @param array an array
     * @return a double array
     */
    public static double[] copyArray(double[] array) {
        double[] returnArray = new double[array.length];
        int i;
        for (i = 0; i < array.length; i ++) {
            returnArray[i] = array[i];
        }
        return returnArray;
    }
    
    
    /**
     * MAIN unit test.
     * @param args
     */
    public static void main(String[] args) {
        DataTable testTable = new DataTable(3, 3);
        double[] testArray = {-1.0, -2.0, -3.0};
        int i, j;
        for (i = 0 ; i < testTable.getNumberOfRows(); i ++) {
            for (j = 0; j < testTable.getNumberOfColumns(); j ++) {
                testTable.setValue(i,j, i + j);
                System.out.println("####>> getValue (each should be row + column)... " + i + ", " + j + " = " + testTable.getValue(i,j));
            }
        }
        System.out.println("####>> setValue test...." );
        
        double nV = -999;
        
        //Add two row.
        testTable.addRow(nV);
        testTable.addRow(nV);
        System.out.println("####>> ADDED TWO ROWS..." );
        
        
        //Set a row as pointer and copy.
        testTable.setRow(3, testArray);
        testTable.setRowAsCopy(4, testArray);
        System.out.println("####>> SET TWO ROWS..." );
        testArray[0] = 100.0;
        System.out.println("####>> MANUALLY CHANGED ORIGINAL ARRAY VALUE TO 100..." );

        //Create a second data set that is expanded.
        DataTable testTable2 = new DataTable(10, 4);
        testTable2.copyContentsFromDataTable(testTable,nV);
        System.out.println("####>> Created bigger test table and copied contents...." );
        
    }
}
