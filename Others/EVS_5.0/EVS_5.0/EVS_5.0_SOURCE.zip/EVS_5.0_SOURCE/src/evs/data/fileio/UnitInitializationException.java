package evs.data.fileio;

import evs.data.*;

/**
 * Class for throwing exceptions that signify that default units have not been
 * initialized (e.g. read from file).
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class UnitInitializationException extends RuntimeException {
    
    /**
     * Constructs an InvalidUnitException with no message.
     */
    
    public UnitInitializationException() {
        super();
    }

    /**
     * Constructs an InvalidUnitException with the specified message. 
     * 
     * 
     * @param s the message.
     */
    
    public UnitInitializationException(String s) {
	super(s);
    }
}
