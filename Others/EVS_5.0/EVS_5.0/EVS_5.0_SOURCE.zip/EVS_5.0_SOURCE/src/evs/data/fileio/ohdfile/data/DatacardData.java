package evs.data.fileio.ohdfile.data;

import evs.data.fileio.ohdfile.misc.HCalendar;
import evs.data.fileio.ohdfile.misc.HString;
import evs.data.fileio.ohdfile.misc.Messenger;  
import evs.data.fileio.ohdfile.misc.SegmentedLine; 
import evs.analysisunits.AnalysisUnit;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.Vector;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.NumberFormat;

/***********************************************************************************************
 *  DatacardData class
 *
 *
 *  The DatacardData class reads in and stores Datacard format data files.  It ASSUMES the file is
 *  written in GMT, although it provides a constructor which can be used if it is NOT in GMT by
 *  simply passing in the correct time zone string (e.g. "EST" or "CST", but not "CDT" -- to
 *  for day-light savings time, find the standard timezone with the same offset from GMT; for
 *  example instead of "CDT" use "EST").
 *
 *  For average/accumulated data, the Julian hour column lists the Julian hour associated with the
 *  END of each time period of data.  So, the average flow over the period January 10, 1975 at 6
 *  GMT to 1-10-75 at 12 GMT will be stored with the Julian hour corresponding to 1-10-75 at 12
 *  GMT.
 *
 *  In the datacard world, a day ends at 24Z, so that 1-10-1975 at 24Z is still 1-10-1975.  Hence,
 *  the first period for 1-10-1975 is from 1-9-1975 24Z through 1-10-1975 6Z.  Thus, using the end
 *  of the period makes sense.  In the real world, 1-10-1975 24Z is actually 1-11-1975 00Z.  Hence
 *  it does not make sense.
 *
 *       Date            Person          Comment
 *       ----------      ------------    ----------------------------------------------
 *       2001-04-30      Hank Herr       First version complete... it reads in the data.
 *       2001-05-01      Hank Herr       Reads in and writes out data.
 *       2001-06-25      Hank Herr       Got it working with a user specified time zone.
 *       2001-08-28      Hank Herr       Added constructor from ESPData object.
 *
 *
 *
 *   STATIC VARS:
 *
 *     public final String CLASSNAME = "DatacardData";
 *     final static int    JULIAN_HOUR = 0;
 *     final static int    VALUE = 1;
 *     final static double ACCUMULATED_VALUE = -998.0;
 *     final static int    VALUES_POSITION_IN_RECORD = 20;
 *     final static int[]  DATE_POSITION_IN_RECORD = {12, 14, 16, 20};
 *     final static int    BASE_SAMPLE_SIZE = 500;
 *     final static String DEFAULT_TIMEZONE = "GMT";
 *     final static int    DEFAULT_VALUESPERLINE = 6;
 *     final static String DEFAULT_VALUESFORMAT  = "F12.3";
 *
 *   ATTRIBUTES:
 *
 *     public String _filename;
 *     public String _datatype;
 *     public String _datadim;
 *     public String _dataunits;
 *     public int    _tsdt;
 *     public String _timeseriesid;
 *     public String _tsdesc;
 *     public int    _im;
 *     public int    _iy;
 *     public int    _lm;
 *     public int    _ly;
 *     public int    _valuesperline;
 *     public String _valuesformat;
 *     public Calendar _firstdate;
 *     public Calendar _lastdate;
 *     public int      _firstjhr;
 *     public int      _lastjhr;
 *     public int      _totalvaluewidth;
 *     public int      _decimaldigits;
 *     public int[]    _positions;
 *     public int      _todayyear;
 *     public TimeZone _timezone;
 *
 *   FUNCTIONS (in order of appearance):
 *
 *   Constructors:
 *   =============================================================================================
 *     DatacardData(String filename) throws DatacardDataException
 *     DatacardData(DatacardData base)
 *     DatacardData(String filename, String timezone) throws DatacardDataException
 *     DatacardData(ESPData base)
 *     DatacardData(DataSet base, String filename, String datatype, String datadim,
 *         String dataunits, int tsdt, String timeseriesid, String tsdesc,
 *         int im, int iy, int lm, int ly, int valuesperline, String valuesformat)
 *         throws DatacardDataException
 *
 *   Input:
 *   =============================================================================================
 *     boolean readInHeader(BufferedReader localfile) throws IOException
 *     boolean processHeader()
 *     boolean readInData(BufferedReader localfile) throws IOException
 *     String retrieveNextDataLine(BufferedReader localfile)
 *     Vector processDataLineValues(String aline)
 *     int processDataLineJulianHour(String aline)
 *     int processDataLineEndOfMonthJulianHour(String aline)
 *     void doTimeZoneShift()
 *
 *   Output:
 *   =============================================================================================
 *     void writeDatacardOutputHeader(BufferedWriter localfile) throws IOException
 *     void writeDatacardOutputData(BufferedWriter localfile) throws IOException
 *     boolean writeDatacardOutputFile(String filename)
 *     boolean writeDatacardOutputFile()
 *     void dumpHeader()
 *     void dumpProcessedHeader()
 *     void dumpData()
 *     void dumpDataUsingDates()
 *
 *   Sets and Gets:
 *   =============================================================================================
 *     boolean setTimeZone(String timezone)
 *
 **/

public class DatacardData extends DataSet {
    private static final long serialVersionUID = 1L;
    public final String CLASSNAME = "DatacardData";
    
    //Some static variables.
    final public static int    JULIAN_HOUR = 0;
    final public static int    VALUE = 1;
    
    final static double ACCUMULATED_VALUE = -998.0;  //Another possible missing value within Datacard data.
    final static int    VALUES_POSITION_IN_RECORD = 20;  //The spot in a record line where the values start.
    final static int[]  DATE_POSITION_IN_RECORD = {12, 14, 16, 20};  //Positions in record line of pre value stuff.
    final static int    BASE_SAMPLE_SIZE = 500;  //the starting max sample size for the dataset.
    final static String DEFAULT_TIMEZONE = "GMT";
    final static int    DEFAULT_VALUESPERLINE = 6;
    final static String DEFAULT_VALUESFORMAT  = "F12.3";
    
    /////////////////////////////////////////////////////////////////////////
    //Attributes
    /////////////////////////////////////////////////////////////////////////
    
    //All attributes are currently PUBLIC because I do not, yet, want to create the set methods
    //for them.
    
    //Header information -- se section VII.2 of the NWSRFS documentation.
    //Line 1
    public String _filename;     //
    public String _datatype;     //data type
    public String _datadim;      //dimension type
    public String _dataunits;    //units of the data
    public int    _tsdt;         //Time interval
    public String _timeseriesid; //the time series id associated with the data.
    public String _tsdesc;       //a descriptor
    
    //Line 2
    public int    _im;           //The month associated with first block of data.
    public int    _iy;           //The year ...
    public int    _lm;           //The month associated with the last block of data.
    public int    _ly;           //The year ...
    public int    _valuesperline;//The number of values per line.
    public String _valuesformat; //The format of those values.
    
    //Processed data.
    public Calendar _firstdate;  //The calendar associated with what should be the first day with any data (even MISSING).
    public Calendar _lastdate;   //The last date calendar with data.
    public int      _firstjhr;   //The Julian hour of _firstdate.
    public int      _lastjhr;    //The Julian hour of lastdate.
    public int      _totalvaluewidth;  //The total field width of the values, extracted from valuesformat.
    public int      _decimaldigits;    //the number of decimal places within the field.
    public int[]    _positions;  //The positions within the record line demarkating different values.
    public int      _todayyear;  //The year associated with today, in order to run processTwoDigitYear.
    
    //Time Zone
    public TimeZone _timezone;
    
    //Null value identifier
    private double nV = -999;

    /////////////////////////////////////////////////////////////////////////
    //Constructors
    /////////////////////////////////////////////////////////////////////////
    
    private DatacardData() {}
    
    //MAKE THIS THROW AN EXCEPTION!!!!
    public DatacardData(String filename, double nV) throws DatacardDataException, IOException {
        FileReader filereader = null;
        BufferedReader localfile = null;
        try {
            this.nV = nV;
            //First, set the time zone.
            setTimeZone(TimeZone.getTimeZone("UTC"));

            //Look at the file info.
            File thefile = new File(filename);

            //Check for existence and readability.
            if (!thefile.exists() || !thefile.canRead()) {
                //Messenger.writeMsg(Messenger.EVT_SOURCE_IO + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,"File \"" + filename + "\" either does not exist or is not readable.\n");
                throw new DatacardDataException();
            }

            //Try to open the data file for reading.
            try {
                filereader = new FileReader(thefile);
                localfile = new BufferedReader(filereader);
            } catch (FileNotFoundException e1) {
                //JOptionPane.showMessageDialog(null, "Unable to open sac_sma file: " + binfilename,
                //    CLASSNAME + ": ERROR", JOptionPane.ERROR_MESSAGE);
                //Messenger.writeMsg(Messenger.EVT_SOURCE_IO + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,"Failed to open requested file " + filename + "\n");
                throw new DatacardDataException();
            }

            //Try to read in the header of the file.
            int status = 0;
            try {
                //Read in the header data.
                if (!readInHeader(localfile)) {
                    //Messenger.writeMsg(Messenger.EVT_DATA + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,"Failed to read in header data.\n");
                    throw new DatacardDataException();
                }
                status = 1;

                //Process the header.
                if (!processHeader()) {
                    //Messenger.writeMsg(Messenger.EVT_PARAMETERS + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,"Failed to process header data.\n");
                    throw new DatacardDataException();
                }

                //Initialize the _data array to the right size.
                initialize(BASE_SAMPLE_SIZE, 2, false, nV);

                //Read in the data.
                if (!readInData(localfile)) {
                    //Messenger.writeMsg(Messenger.EVT_DATA + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT, "Failed to process data section.\n");
                    throw new DatacardDataException();
                }

                localfile.close();
                filereader.close();
            } catch (IOException e) {
                //Messenger.writeMsg(Messenger.EVT_SOURCE_IO + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,"Failed to read in Datacard time series file for this reason:\n");
                //if (status == 0)
                //Messenger.writeMsg(Messenger.EVT_SOURCE_IO + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,"  Unable to read in the header.\n");
                //else
                //   Messenger.writeMsg(Messenger.EVT_SOURCE_IO + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,
                //          "  Unable to read in the data or it does not match what the header states.\n");
            }

            //Do the time zone shift.
            doTimeZoneShift();
        } finally {
            if(localfile!=null) {
                localfile.close();
            }
            if(filereader!=null) {
                filereader.close();
            }
        }
    }
    
    public DatacardData(String filename, TimeZone timeZone, double nV) throws DatacardDataException, IOException {
        FileReader thefile = null;
        BufferedReader localfile = null;
        try {
            this.nV = nV;

            //First, set the time zone.
            setTimeZone(timeZone);

            //Try to open the data file for reading.
            try {
                thefile = new FileReader(filename);
                localfile = new BufferedReader(thefile);
            } catch (FileNotFoundException e1) {
                //JOptionPane.showMessageDialog(null, "Unable to open sac_sma file: " + binfilename,
                //    CLASSNAME + ": ERROR", JOptionPane.ERROR_MESSAGE);
                //System.out.println("DatacardData ERROR: Failed to open requested file " + filename);
                throw new DatacardDataException("DatacardData ERROR: Failed to open requested file " + filename);
            }

            //Try to read in the header of the file.
            int status = 0;
            try {
                //Read in the header data.
                if (!readInHeader(localfile)) {
                    //Messenger.writeMsg(Messenger.EVT_DATA + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,"Failed to read in header data.\n");
                    throw new DatacardDataException();
                }
                status = 1;

                //Process the header.
                if (!processHeader()) {
                    //Messenger.writeMsg(Messenger.EVT_PARAMETERS + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,"Failed to process header data.\n");
                    throw new DatacardDataException();
                }

                //Initialize the _data array to the right size.
                initialize(BASE_SAMPLE_SIZE, 2, false, nV);

                //Read in the data.
                if (!readInData(localfile)) {
                    //Messenger.writeMsg(Messenger.EVT_DATA + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,"Failed to process data section.\n");
                    throw new DatacardDataException();
                }

                localfile.close();
                thefile.close();
            } catch (IOException e) {
                //Messenger.writeMsg(Messenger.EVT_SOURCE_IO + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,"Failed to read in Datacard time series file for this reason:\n");
                //if (status == 0)
                //Messenger.writeMsg(Messenger.EVT_SOURCE_IO + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,"  Unable to read in the header.\n");
                //else
                //Messenger.writeMsg(Messenger.EVT_SOURCE_IO + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,"  Unable to read in the data or it does not match what the header states.\n");
            }

            //Do the time zone shift.
            //EDITED OUT: evs@hydrosolved.com

            doTimeZoneShift();
        } finally {
            if (thefile != null) {
                thefile.close();
            }
            if (localfile != null) {
                localfile.close();
            }
        }
    }
    
    /**
     * Returns the start date of the data.
     * 
     * @return the start date.
     */

    public Calendar getStartDate() {
        return _firstdate;
    }
    
    /**
     * Returns the end date.
     *
     * @return the end date
     */
    
    public Calendar getEndDate() {
        return _lastdate;
    }       
    
    /**
     * Returns true if the data can be read.
     * 
     * @param file
     * @return true if the data can be read
     * @deprecated
     */
    
    public static boolean isOfType(File  file) throws IOException {
        if(file == null) {
            return false;
        }
        if(!file.canRead()) {
            throw new IOException("Cannot check the file: "+file);
        }
        BufferedReader read = null;
        try {
            DatacardData d = new DatacardData();
            read = new BufferedReader(new FileReader(file));
            return d.readInHeader(read) && d.processHeader();
        }
        catch(Throwable e) {
            return false;
        } finally {
            if(read!= null) {
                read.close();
            }
        }
    }
    
    /////////////////////////////////////////////////////////////////////////
    //Input
    /////////////////////////////////////////////////////////////////////////
    
    //read in the header portion of the file -- which should be the first two valid data lines.
    private boolean readInHeader(BufferedReader localfile) throws IOException {
        String aline;
        
        /////////////////////////////////////////////////////////////////////////////////
        //Get Line 1, and make sure I have the minimum requisite number of characters, enough
        //to get me to the last element of the line.
        aline = retrieveNextDataLine(localfile);
        if(aline==null) {
            throw new IOException("Error reading Datacard file header: no data found.");
        }
        if (aline.length() < 31)
            return false;
        
        //Process the line
        _filename = aline.substring(0, 11 + 1);
        //Skip 12, 13
        _datatype = aline.substring(14, 17 + 1);
        //Skip 18
        _datadim = aline.substring(19, 22 + 1);
        //Skip 23
        _dataunits = aline.substring(24, 27 + 1);
        //Skip 28
        try {
            _tsdt = Integer.parseInt(aline.substring(29, 30 + 1).trim());
        } catch (NumberFormatException e) {
            _tsdt = (int)nV;
            return false;
        }
        //Skip 31, 32, 33
        if (aline.length() > 35)
            _timeseriesid = aline.substring(34, Math.min(aline.length(), 45 + 1));
        //Skip 46, 47, 48
        if (aline.length() > 50)
            _tsdesc = aline.substring(49, Math.min(aline.length(), 68 + 1));
        
        /////////////////////////////////////////////////////////////////////////////////
        //Get Line 2 and make sure it has the requisite number of characters -- enough to get
        //me to the last element of the line.
        aline = retrieveNextDataLine(localfile);
        if (aline.length() < 25)
            return false;
        try {
            _im = Integer.parseInt(aline.substring(0, 1 + 1).trim());
            //Skip 2,3
            _iy = Integer.parseInt(aline.substring(4, 7 + 1).trim());
            //Skip 8
            _lm = Integer.parseInt(aline.substring(9, 10 + 1).trim());
            //Skip 11, 12, 13
            _ly = Integer.parseInt(aline.substring(14, 17 + 1).trim());
            //Skip 18
            _valuesperline = Integer.parseInt(aline.substring(19, 20 + 1).trim());
        } catch (NumberFormatException e) {
            return false;
        }
        //Skip 21, 22, 23
        _valuesformat = aline.substring(24, Math.min(aline.length(), 31 + 1));
        _valuesformat = _valuesformat.trim();  //-> Its length does not matter, and a trimmed string is easier to deal with.
        
        return true;
    }
    
    //Compute class variables using header data.
    private boolean processHeader() {
        //Compute the dates -- initialize using computeCalendarFromJulianHour
        //NOTE: If the time ever changes from 1..24 to 0..23, then I will need to change how I define both of these so that
        //  _firstjhr is from hour 0 and _lastjhr is its current value minus _tsdt!

        _firstjhr  = HCalendar.computeJulianHour(_iy, _im - 1, 1, _tsdt);      
        _firstdate = HCalendar.computeCalendarFromJulianHour(_firstjhr);
        _lastjhr   = HCalendar.computeJulianHour(_ly + (int)(_lm/12), (_lm%12), 1, 0); //This will always set it as the NEXT month at 0 GMT.
        _lastdate  = HCalendar.computeCalendarFromJulianHour(_lastjhr);
        
        //NOTE: I add (int)(_lm/12) to the year, because if the last month is December (12), the I actually
        //      set the last Julian hour to be 1/1 at 00 GMT for the NEXT year (i.e. 12/_ly at 24 GMT).
        
        //NEED TO PROCESS DATA VALUE FORMAT HERE (_valuesformat).
        //Will assume float here for now...
        //Get the total values width
        try {
            _totalvaluewidth = Integer.parseInt( _valuesformat.substring(1, _valuesformat.indexOf('.')) );
            _decimaldigits   = Integer.parseInt( _valuesformat.substring(_valuesformat.indexOf('.') + 1, _valuesformat.length()) );
        } catch (NumberFormatException e) {
            return false;
        }
        
        //Construct the positions array for use with SegmentedLine.
        _positions = new int[_valuesperline + 1];
        int i = 0;
        for (i = 0; i <= _valuesperline; i ++) {
            _positions[i] = VALUES_POSITION_IN_RECORD + (i) * _totalvaluewidth;
        }
        
        //Compute todayyear as the year of the present.  This is used in the windowing technique used in
        //processYear below.
        TimeZone tz = TimeZone.getTimeZone("GMT");
        Calendar today = Calendar.getInstance(tz);
        _todayyear = today.get(Calendar.YEAR);
        
        return true;
    }
    
    //Read in the data, line by line.  This uses processDataLineValues and processDataLineDate to read
    //in all the values.  Its only requirements are that the dates are in increasing order and that
    //the first data is for the first jhr and the last data is for the last jhr.
    private boolean readInData(BufferedReader localfile) throws IOException {
        //Some variables
        Vector values = null;
        Double d;
        double[] aSample = new double[2];
        int i;
        
        //Initialize variables for the looping.
        String aline = retrieveNextDataLine(localfile);
        
        int currentmonthjhr = (int)nV;
        int firstofmonthjhr = 0;
        int endofmonthjhr = 0;
        int workingjhr = _firstjhr;
        
        //I want to loop from the _firstjhr to the _lastjhr, only inserting non-MISSING values.
        boolean done = false;
        while ( (!done) && (workingjhr <= _lastjhr) ) {

            //Is the line null?  If it is quit out -- this should be the EOF.
            if (aline == null) {
                done = true; continue;
            }
            
            //Get the values and the first day of the working month from the line.
            values          = processDataLineValues(aline);

            firstofmonthjhr = processDataLineJulianHour(aline);
            
            //Look at the current month... does it need processing?  If so, update the current month
            //and set the working Julian hour to be the first of the month, because I now have a new
            //month of data to process.
            if ( (currentmonthjhr < 0) || (currentmonthjhr != firstofmonthjhr) ) {
                //If this is true, then I'm reading in my first data line.  Make sure it corresponds
                //to _firstjhr.
                //if ( (currentmonthjhr < 0) && (firstofmonthjhr != _firstjhr) ) {
                //    Messenger.writeMsg(Messenger.EVT_DATA + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,
                //            "Error processing line \"" + aline + "\".\n");
                //    Messenger.writeMsg(Messenger.EVT_DATA + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,
                //            "The first month jhr of data, " + firstofmonthjhr
                //            + ", does not correspond to that specified in the header, " + _firstjhr + ".\n");
                //    return false;
                //}
                
                //Make sure the upcoming month is greater than this past data month.
                //if (firstofmonthjhr <= currentmonthjhr) {
                //    Messenger.writeMsg(Messenger.EVT_DATA + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,
                //            "Error processing line \"" + aline + "\".\n");
                //    Messenger.writeMsg(Messenger.EVT_DATA + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,
                //            "This month of data is before the preceding month, which is not allowed.\n");
                //    return false;
                //}
                
                //Was the previous month complete -- if (workingjhr - _tsdt) < endofmonthjhr, then it was not.
                //workingjhr - _tsdt was the last data value actually processed from the records.
                //if ( (workingjhr - _tsdt) < endofmonthjhr ) {
                //    Messenger.writeMsg(Messenger.EVT_DATA + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,
                //            "Error processing line \"" + aline + "\".\n");
                //    Messenger.writeMsg(Messenger.EVT_DATA + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,
                //            "The PRECEDING month of data was incomplete.\n");
                //    return false;
                //}
                
                currentmonthjhr = firstofmonthjhr;
                workingjhr = currentmonthjhr;
                endofmonthjhr = processDataLineEndOfMonthJulianHour(aline);
            }
            
            //If I've got values to process...
            if ( (values != null) && (currentmonthjhr > 0) ) {
                
                //Loop through the values, adding them one at a time if not MISSING.
                for (i = 0; i < values.size(); i ++) {
                    //I've still got a value to process within this month, but I just went off the end.
                    if (workingjhr > endofmonthjhr) {
                        //Messenger.writeMsg(Messenger.EVT_DATA + Messenger.SEV_WARNING + Messenger.ALWAYS_PRINT,
                        //        "In the line \"" + aline + "\".\n");
                        //Messenger.writeMsg(Messenger.EVT_DATA + Messenger.SEV_WARNING + Messenger.ALWAYS_PRINT,
                        //        "Data goes beyond end of the month.  Extra values are discarded.\n");
                        break;
                    }
                    
                    //Get the current working value.
                    d = (Double)values.elementAt(i);
                    
                    //Create and add the sample, if its not missing or -998 (ACCUMULATED_VALUE).
                    if ((d.doubleValue() != nV) && (d.doubleValue() != ACCUMULATED_VALUE)) {
                        aSample = new double[2];
                        
                        aSample[JULIAN_HOUR] = (double)workingjhr;
                        
                        aSample[VALUE] = d.doubleValue();
                        addSample(aSample);
                        //Check the sample size now... if I'm approaching maximum size, then increase it.
                        if (getSampleSize() == (getMaximumSampleSize() - 1))
                            changeMaximumNumberOfSamples(getMaximumSampleSize() + BASE_SAMPLE_SIZE,nV);
                    }
                    
                    //Goto the text time step and if I've gone too far, break out of the for loop.
                    workingjhr += _tsdt;
                }
            }
            //Get the next readable line...
            aline = retrieveNextDataLine(localfile);            
            
        }
        
        //Make sure the last value I processed was the end of the last month of data.
        if ( (workingjhr - _tsdt) != _lastjhr ) {
            //Messenger.writeMsg(Messenger.EVT_DATA + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,
            //        "Error processing line \"" + aline + "\".\n");
            //Messenger.writeMsg(Messenger.EVT_DATA + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,
            //        "The last month of data does not correspond to that specified in the header.\n");
            return false;
        }
        
        return true;
    }
    
    //Get the next meaningful line.  A return of null marks the end of the file.  A return of "" marks
    private String retrieveNextDataLine(BufferedReader localfile) {
        boolean done = false;
        String aline = "";
        while (!done) {
            //Try to read a line from the input stream
            try {
                aline = localfile.readLine();
                //If aline is null, then I must be at the end of the file, though why I didn't
                //receive an IOException, I don't know.
                if (aline == null)
                    return null;
                
                //If the first character is not a '$', then I need to process it.
                if (aline.charAt(0) != '$')
                    return aline;
            }
            //I've reached the end of the file...
            catch(Exception e) {   //evs@hydrosolved.com replaced with generic exception
                done = true;
                
                //If aline was null, then just return null, marking the end of the file.
                if (aline == null)
                    return null;
                
                //If aline had no length, then just return null, marking the end of the file.
                if (aline.length() == 0)
                    return null;
                
                //If the first character is not a '$', then I need to process it.
                if (aline.charAt(0) != '$')
                    return aline;
            }
        }
        return null;
    }
    
    //Return a vector of Double objects containing the numbers within this line.
    private Vector processDataLineValues(String aline) {
        if (aline == null)
            return null;
        
        //FOR NOW I AM SKIPPING TO CHARACTER 20 (starting at 0) TO REACH THE DATA IMMEDIATELY.
        //If I can ever think of a reason to checkthe first 20 characters, I'll insert the check here.
        
        //build the returned array one element at a line by breaking up the string consecutive.
        String valuestr;
        Vector values = new Vector();
        
        //Segment the line by fixed width block computed in processHeader.
        SegmentedLine segline = new SegmentedLine(aline, _positions);
        
        //Go through the segments, starting with the second one, one by one.
        //Count starts at 1 because the first segment is the bs before the values.
        int count;
        for (count = 1; count < segline.getNumberOfSegments(); count ++) {
            //Get the value string
            valuestr = segline.getASegment(count);
            
            //Turn it into a Double and add it to the vector
            try {
                values.addElement(new Double(valuestr.trim()));
            } catch (NumberFormatException e) {
                //I've failed to process this double, so I am going to assume the end of line is reached.
                return values;
            }
        }
        
        return values;
    }
    
    //Return the Calendar which specifies, for the line passed in, what the first data hour of the first day
    //of the month for that line will be.  This is used inside readInData to know when it switches months
    //and what month it switches to.
    private int processDataLineJulianHour(String aline) {
        //Segment the passed in line based on the static array DATE_POSITION_IN_RECORD.
        SegmentedLine segline = new SegmentedLine(aline, DATE_POSITION_IN_RECORD);
        
        int month;
        int year;

        //Try to get the month and year of the record from the line

        try {
            month = Integer.parseInt( segline.getASegment(1).trim() );
            year  = Integer.parseInt( segline.getASegment(2).trim() );
        } catch (NumberFormatException e) {
            //I've failed to process this double, so I am going to assume the end of line is reached.
            return (int)nV;
        }

        //Compute the Julian hour...
        int datejhr = HCalendar.computeJulianHour(HCalendar.processTwoDigitYear(year, _todayyear), month - 1, 1, _tsdt);

        //Return the calendar corresponding to datejhr
        return datejhr;
    }
    
    //Get the Julian hour marking the last value within that month.
    private int processDataLineEndOfMonthJulianHour(String aline) {
        //Segment the passed in line based on the static array DATE_POSITION_IN_RECORD.
        SegmentedLine segline = new SegmentedLine(aline, DATE_POSITION_IN_RECORD);
        
        int month;
        int year;
        
        //Try to get the month and year of the record from the line.
        try {
            month = Integer.parseInt( segline.getASegment(1).trim() );
            year  = Integer.parseInt( segline.getASegment(2).trim() );
        } catch (NumberFormatException e) {
            //I've failed to process this double, so I am going to assume the end of line is reached.
            return (int)nV;
        }
        
        //Compute the Julian hour...
        int datejhr;
        if (month == 12)
            datejhr = HCalendar.computeJulianHour(HCalendar.processTwoDigitYear(year, _todayyear) + 1, 0, 1, 0);
        else
            datejhr = HCalendar.computeJulianHour(HCalendar.processTwoDigitYear(year, _todayyear), month, 1, 0);
        
        //Return the calendar corresponding to datejhr
        return datejhr;
    }
    
    //Perform a shift on the Julian hour for the Time Zone of the data read in.
    //All the data was read in ASSUMING it was in Julian hours.  However, the data was most
    //likely not in Julian hours.  To account for this I need to shift the JULIAN_HOUR variable
    //accordingly.
    //
    //Example: If the data is in EST.  The first value I read in had a Julian hour for 1/1/1999 6h GMT.
    //  However, it was supposed to be the Julian hour for 1/1/1999 6h EST, which is 1/1/1999 11h GMT.  So,
    //  my Julian hour was 5 hours too few.  So, I add 5 hours to all of the samples.
    private void doTimeZoneShift() {
        //I need the offset in milliseconds.
        int rawoffset = _timezone.getRawOffset();
       
        //Divide it by 3600*1000 to remove the millisecond and get the hours.
        int hourshift = (int)(rawoffset/(3600 * 1000));
        
        //Hour shift is now the number of hours shifted to get FROM GMT TO _timezone.  However, I am
        //actually trying to go FROM _timezone TO GMT, meaning I SUBTRACT this shift value.
        
        //Do a shift on the data.  I multiply by -1, because I am trying to shift a Julian hour thats actually in
        //the _timezone time to one that is in GMT.
        if (!shiftVariable(JULIAN_HOUR, -1 * hourshift)) {
            //Messenger.writeMsg(Messenger.EVT_DATA + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,
            //        "INTERNAL ERROR: For some reason, I failed on my shiftVariable call in DatacardData.\n");
            return;
        }
        
        //Now, shift the attributes _firstjhr and _lastjhr, because they were computed assuming GMT data.
        _firstjhr -= hourshift;
        _firstdate = HCalendar.computeCalendarFromJulianHour(_firstjhr);
        _lastjhr  -= hourshift;
        _lastdate  = HCalendar.computeCalendarFromJulianHour(_lastjhr);
        return ;
    }
    
    /////////////////////////////////////////////////////////////////////////
    //Output
    /////////////////////////////////////////////////////////////////////////
    
    //Write out the header information to a datacard file.
    private void writeDatacardOutputHeader(BufferedWriter localfile) throws IOException {
        if (localfile == null)
            throw new IOException();
        
        String tempstr;
        NumberFormat nf = NumberFormat.getInstance();
        nf.setMaximumFractionDigits(0);
        nf.setMinimumFractionDigits(0);
        nf.setMaximumIntegerDigits(2);
        nf.setMinimumIntegerDigits(2);
        
        /////////////////////////////////////////////////////////////////////////////////
        //Write Line 1
        String aline = "";
        aline += HString.formatStringToFieldWidth(12, _filename,  true);
        aline += "  ";
        aline += HString.formatStringToFieldWidth(4,  _datatype,  true);
        aline += " ";
        aline += HString.formatStringToFieldWidth(4,  _datadim,   true);
        aline += " ";
        aline += HString.formatStringToFieldWidth(4,  _dataunits, true);
        aline += " ";
        aline += HString.formatStringToFieldWidth(2,  "" + _tsdt, true);
        aline += "   ";
        aline += HString.formatStringToFieldWidth(12, _timeseriesid, true);
        aline += "   ";
        aline += HString.formatStringToFieldWidth(20, _tsdesc, true);
        localfile.write(aline, 0, aline.length());
        localfile.newLine();
        
        /////////////////////////////////////////////////////////////////////////////////
        //Write line 2
        aline = "";
        aline += HString.formatStringToFieldWidth(2, "" + _im, true);
        aline += "  ";
        aline += _iy;
        aline += " ";
        aline += HString.formatStringToFieldWidth(2, "" + _lm, true);
        aline += "   ";
        aline += _ly;
        aline += " ";
        aline += HString.formatStringToFieldWidth(2, "" + _valuesperline, true);
        aline += "   ";
        aline += _valuesformat;
        localfile.write(aline, 0, aline.length());
        localfile.newLine();
        localfile.flush();
    }
    
    //Write the data portion of the datacard file.
    private void writeDatacardOutputData(BufferedWriter localfile) throws IOException {
        //Sort the data by the Julian hour and reset the ptr.
        sortBy(JULIAN_HOUR);
        resetPtr();
        
        //Floating point number formatter
        NumberFormat fnf = NumberFormat.getInstance();
        fnf.setMaximumFractionDigits(_decimaldigits);
        fnf.setMinimumFractionDigits(_decimaldigits);
        fnf.setMaximumIntegerDigits(_totalvaluewidth - _decimaldigits - 1);
        fnf.setGroupingUsed(false);
        
        //Integer number formatter.
        NumberFormat znf = NumberFormat.getInstance();
        znf.setMaximumFractionDigits(0);
        znf.setMinimumFractionDigits(0);
        znf.setMaximumIntegerDigits(2);
        znf.setMinimumIntegerDigits(2);
        
        //Some variables.
        String aline = "";
        boolean donewithdata, donewritingfile, newmonth;
        int currentline      = 1;
        int currentlineentry = 0;
        
        //HERE's what the jhr and dates store:
        //datadate        -- stores the date associated with the next sample in the DataSet.
        //datadatejhr     -- its Julian hour.
        //currentdate     -- stores the date associated with the next printed value.
        //currentdatejhr  -- its Julian hour.
        //currentfomjhr   -- the Julian hour of the first of the month corresponding to the next printed value.
        //workingblockjhr -- the date of the first of the month for the current working block.
        Calendar datadate;
        int      datadatejhr;
        Calendar currentdate;
        int      currentdatejhr;
        int      currentfomjhr = 0;
        int      workingblockjhr = (int)nV;
        
        //I need the offset in hours.  This will be the number of hours to shift to get FROM GMT TO
        //_timezone.  Hence, this is an additive factor.
        int rawoffset = _timezone.getRawOffset();
        int hourshift = (int)rawoffset/(3600 * 1000);
        
        //NOTE ON HOUR SHIFTING:
        //The data in the data set is in GMT, but the output must follow a pattern prescribed by the
        //TimeZone _timezone.  So, I'm going to compute Julian hour dates in LST (i.e. from 1/1/1900 0h LST)
        //and then adjust the Julian hours that come out of the DataSet by ADDING hourshift to shift it
        //from GMT to LST.
        
        //Get the first samples date and first of month jhr.
        datadatejhr    = (int)getCurrentValue(JULIAN_HOUR,nV) + hourshift; //Shift the GMT value to LST!
        datadate       = HCalendar.computeCalendarFromJulianHour(datadatejhr);
        currentfomjhr  = HCalendar.computeJulianHour(datadate.get(Calendar.YEAR),
                datadate.get(Calendar.MONTH), 1, _tsdt);  //Viewed as LST!
        currentdate    = HCalendar.computeCalendarFromJulianHour(currentfomjhr);
        currentdatejhr = currentfomjhr;
        
        //This is to force hour 0 to be treated as hour 24...
        currentdate.add(Calendar.SECOND, -1);
        
        donewithdata = false;
        donewritingfile = false;
        newmonth = false;
        while (!donewritingfile) {
            //If the preceding month is not the same as the currentdate's month, then
            //this is a new month.
            //(i.e. if I reach the end of the month, then...)
            if (workingblockjhr != currentfomjhr) {
                newmonth = true;
                
                //Force the next if to printout this line.
                currentlineentry = _valuesperline;
            }
            
            //If I've just maxed out the line entries, then print the line...
            if (currentlineentry == _valuesperline) {
                //print out aline if I have one and clear it.
                if (aline.length() != 0) {
                    localfile.write(aline, 0, aline.length());
                    localfile.newLine();
                    localfile.flush();
                    currentline ++;
                }
                aline = "";
                currentlineentry = 0;
            }
            
            //If this is a new month, then...
            if (newmonth) {
//System.out.println("####>> Inside here!!! >> " + workingblockjhr + " != " + currentfomjhr);
//System.out.println("####>>     datadate is " + HCalendar.convertCalendarToString(datadate, HCalendar.DEFAULT_DATETZ_FORMAT));
//System.out.println("####>>     donewithdata = " + donewithdata);
                //Reset newmonth.
                newmonth = false;
                
                //If I just wrote the last month with any data from the data set, then quit the loop.
                if (donewithdata) {
                    donewritingfile = true;
                    continue;
                }
                
                //Reset precedingmonth to be the next data values's first-of-month.
                workingblockjhr = HCalendar.computeJulianHour(datadate.get(Calendar.YEAR),
                        datadate.get(Calendar.MONTH), 1, _tsdt);    //Viewed as LST!  Being Initial value, I mod it!
                
                //Move current date stuff to workingblockjhr and I'll start from there.
                currentdate = HCalendar.computeCalendarFromJulianHour(workingblockjhr);
                currentfomjhr = HCalendar.computeJulianHour(currentdate.get(Calendar.YEAR),
                        currentdate.get(Calendar.MONTH), 1, _tsdt); //Viewed as LST!  Being Initial value, I mod it!
                currentdatejhr = HCalendar.computeJulianHourFromCalendar(currentdate, true);
//System.out.println("####>>     currentdate set to " + HCalendar.convertCalendarToString(datadate, HCalendar.DEFAULT_DATETZ_FORMAT));
//System.out.println("####>>     currentfomjhr = " + currentfomjhr + "; currentdatejhr = " + currentdatejhr);
                
                //This is to force hour 0 to be treated as hour 24...
                currentdate.add(Calendar.SECOND, -1);
            }
            
            //If aline is empty, then setup aline for the next line.
            if (aline.length() == 0) {
                aline += HString.formatStringToFieldWidth(12, _timeseriesid, true);
                aline += HString.formatStringToFieldWidth(2, "" + (currentdate.get(Calendar.MONTH) + 1), false);
                aline += znf.format(currentdate.get(Calendar.YEAR)%100);
                aline += HString.formatStringToFieldWidth(4, "" + currentline, false);
            }
            
            //If the value to print out now is the current value in the data set...
//System.out.println("####>> Checking equality of " + currentdatejhr + " and " + datadatejhr);
            if (currentdatejhr == datadatejhr) {
                aline += HString.formatStringToFieldWidth(_totalvaluewidth,
                        fnf.format(getCurrentValue(VALUE,nV)), false);
                donewithdata = !next();  //If there is no more data, this next will not move the pointer, so the if above will fail until done.
                datadatejhr = (int)getCurrentValue(JULIAN_HOUR,nV) + hourshift; //Shift from GMT to LST!
                datadate = HCalendar.computeCalendarFromJulianHour(datadatejhr);
//System.out.println("####>> Just incremented datadate to " + datadatejhr);
            }
            //Otherwise, put in a missing value...
            else {
                aline += HString.formatStringToFieldWidth(_totalvaluewidth,
                        fnf.format(nV), false);
            }
            
            //Increment the current date.
            currentdatejhr += _tsdt;
//System.out.println("####>> " + currentdatejhr);
            currentdate.add(Calendar.HOUR, _tsdt);
            currentfomjhr = HCalendar.computeJulianHour(currentdate.get(Calendar.YEAR),
                    currentdate.get(Calendar.MONTH), 1, _tsdt);   //Viewed as LST!  Being Initial value, I mod it!
            currentlineentry ++;
        }
    }
    
    //Call the previous two routines to write a datacard file.
    public boolean writeDatacardOutputFile(String filename) {
        FileWriter     thefile;
        BufferedWriter localfile;
        
        //Try to open the data file for reading.
        try {
            thefile   = new FileWriter(filename);
            localfile = new BufferedWriter(thefile);
        } catch (IOException e1) {
            Messenger.writeMsg(Messenger.EVT_SOURCE_IO + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,
                    "Failed to open requested file " + filename);
            return false;
        }
        
        //Try to writeout the file contents.
        try {
            writeDatacardOutputHeader(localfile);
            writeDatacardOutputData(localfile);
            localfile.close();
            thefile.close();
        } catch (IOException e) {
            Messenger.writeMsg(Messenger.EVT_SOURCE_IO + Messenger.SEV_ERROR + Messenger.ALWAYS_PRINT,
                    "Failed to write out file information.");
            return false;
        }
        
        return true;
    }
    
    //Call the previous two routines to write a datacard file.
    public boolean writeDatacardOutputFile() {
        return writeDatacardOutputFile(_filename);
    }
    
    //Dump the header to standard out.
    public void dumpHeader() {
        int i;
        
        System.out.println("========== DATACARD HEADER =========================");
        System.out.println("_filename      = \"" + _filename + "\"");
        System.out.println("_datatype      = \"" + _datatype + "\"");
        System.out.println("_datadim       = \"" + _datadim + "\"");
        System.out.println("_dataunits     = \"" + _dataunits + "\"");
        System.out.println("_tsdt          = "   + _tsdt );      //Time interval
        System.out.println("_timeseriesid  = \"" + _timeseriesid + "\"");
        System.out.println("_tsdesc        = \"" + _tsdesc + "\"");
        System.out.println("_im            = "   + _im);
        System.out.println("_iy            = "   + _iy);
        System.out.println("_lm            = "   + _lm);
        System.out.println("_ly            = "   + _ly);
        System.out.println("_valuesperline = "   + _valuesperline);
        System.out.println("_valuesformat  = \"" + _valuesformat + "\"");
        System.out.println("====================================================");
    }
    
    //Dump the processed header variables.
    public void dumpProcessedHeader() {
        //Dump the calendar objects.
        System.out.println("========== DATACARD PROCESSED HEADER ===============");
        System.out.println("_firstjhr        = "   + _firstjhr);
        System.out.println("_firstdate       = "   +
                HCalendar.convertCalendarToString(_firstdate, HCalendar.DEFAULT_DATETZ_FORMAT) );
        System.out.println("_lastjhr         = "   + _lastjhr);
        System.out.println("_lastdate        = "   +
                HCalendar.convertCalendarToString(_lastdate, HCalendar.DEFAULT_DATETZ_FORMAT) );
        System.out.println("_totalvaluewidth = "   + _totalvaluewidth);
        System.out.println("_decimaldigtis   = "   + _decimaldigits);
        System.out.println("_todayyear       = "   + _todayyear);
        System.out.println("TIMEZONE         = "   + _timezone.getID());
        System.out.println("====================================================");
    }  
    
    /////////////////////////////////////////////////////////////////////////
    //TOOLS
    /////////////////////////////////////////////////////////////////////////
    
    /////////////////////////////////////////////////////////////////////////
    //Sets and Gets
    /////////////////////////////////////////////////////////////////////////
    
    public boolean setTimeZone(TimeZone timezone) {
        _timezone = timezone;
        return true;
    }
    
    /**
     * Returns the time zone.
     * 
     * @return the time zone
     */
    
    public TimeZone getTimeZone() {
        return _timezone;
    }
    
    //A test main.
    public static void main(String args[]) {
        int[] testlevels = { Messenger.ALWAYS_PRINT, Messenger.ALWAYS_PRINT,
        Messenger.ALWAYS_PRINT, Messenger.ALWAYS_PRINT, Messenger.ALWAYS_PRINT,
        Messenger.ALWAYS_PRINT, Messenger.ALWAYS_PRINT, Messenger.ALWAYS_PRINT,
        Messenger.ALWAYS_PRINT, Messenger.ALWAYS_PRINT, Messenger.ALWAYS_PRINT};
        Messenger.initMsg(-1, null, "stdout", testlevels);
        
        if ((args.length != 2) && (args.length != 3)) {
            System.out.println("DatacardData version ob8.2 10/04/06");
            System.out.println("");
            System.out.println("Bad command line format.  Correct format:");
            System.out.println("    <program> <h,dd,dj,a,yt> <file> [<time zone string>]");
            System.out.println("where file is the file to be read and 'h' means only print");
            System.out.println("out the header, 'dd' means print out the header and data as");
            System.out.println("dates, 'dj' means print out the header and data as Julian hours,");
            System.out.println("and 'a' means print out the header, data, and do 24-hour, 'yt'");
            System.out.println("means total the values for each of the years and provide the");
            System.out.println("sums.");
            System.out.println("The optional time zone string specifies what time zone to assume");
            System.out.println("the data is in.");
            System.out.println("");
            return;
        }
        
        //Process the second arg, if there is one.
        int outputlevel = 1;
        boolean dateprint = false;
        if (args[0].equals("h"))
            outputlevel = 0;
        else if (args[0].equals("dj"))
            outputlevel = 1;
        else if (args[0].equals("a"))
            outputlevel = 2;
        else if (args[0].equals("yt"))
            outputlevel = 3;
        else if (args[0].equals("special"))
            outputlevel = 99;
        else if (args[0].equals("dd")) {
            outputlevel = 1;
            dateprint = true;
        }
        
        DatacardData data;
        double nV = -999.0;
        try {
            //For the "special" argument (outputlevel == 99), we are going to assume that
            //argument 3 is the name of the file we want to file in with data from the file
            //in argument 2.  Hence, we read in assuming GMT.
            if ( (args.length == 2) || ((args.length == 3) && (outputlevel == 99)) ) {
                System.out.println("Reading in file assuming GMT is the time zone.");
                data = new DatacardData(args[1],nV);
            } else {
                data = new DatacardData(args[1], TimeZone.getTimeZone(args[2]),nV);
            }
            
            //NOTE: This piece is hardcoded if the data 24-h.  Basically, I'm going to force it to associate
            //with each sample, the START of the day, not the END!!!
            if (data._tsdt == 24)
                data.shiftVariable(DatacardData.JULIAN_HOUR, -24);
            
            //If no averaging...
            if (outputlevel < 2) {
                System.out.println("##################### File Contents Read In: ####################");
                System.out.println("  If the data is 24-hour data, then the Julian hour represents");
                System.out.println("  the beginning of each day.  Otherwise, it is the end of each");
                System.out.println("  time period.");
                System.out.println("#################################################################");
                if (outputlevel >= 0) {
                    data.dumpHeader();
                    data.dumpProcessedHeader();
                }
                System.out.println("#################################################################");
                System.out.println("");
                System.out.println("");
                return;
            }
            
            //If we are in the yearly averaging mode to get year sums, then...
            if (outputlevel == 3) {
                System.out.println("#################################################################");
                System.out.println("  Totals for each year.");
                System.out.println("#################################################################");
                
                //This is a subset DataSet that will be used to store data.
                DataSet subset;
                
                //Loop through each year.
                int year;
                for (year = data._firstdate.get(Calendar.YEAR);
                year <= data._lastdate.get(Calendar.YEAR);
                year ++) {
                    subset = data.extractSubset(0, Calendar.YEAR, year,nV);
                }
                System.out.println("#################################################################");
                System.out.println("");
                System.out.println("");
                return;
            }
            
            //If we are running the special function, then...
            if (outputlevel == 99) {
                //Read in the second file.
                System.out.println("Reading in second file assuming GMT is the time zone.");
                DatacardData data2 = new DatacardData(args[2],nV);
                int month;
                
                //Now, we start replacing the data in data2 with that in data.
                //If we run out of samples in data, then we loop back around.
                System.out.println("Using the first file to replace values in the second file.");
                data.resetPtr();
                data2.resetPtr();
                data2.setCurrentValue(1, data.getCurrentValue(1,nV));
                while (data2.next()) {
                    if (!data.next()) {
                        System.out.println("First file ran out of values at jhr " + data.getCurrentValue(0,nV));
                        System.out.println("  Looping to beginning.");
                        data.resetPtr();
                    }
                    
                    month = data.getCurrentValueAsDate(0).get(Calendar.MONTH);
                    if ((month != 6) && (month != 7) && (month != 8))
                        data2.setCurrentValue(1, data.getCurrentValue(1,nV));
                }
                
                //Output the datacard file.
                System.out.println("Writing new datacard file \"" + args[2] + ".new\".");
                data2.writeDatacardOutputFile(args[2] + ".new");
                return;
            }
            
            //I am doing averaging.
            
            //startjhr is the Julian hours in GMT!  Now, I want to get the first hour of THAT day
            //in the timezone of the DatacardData!  First, get the offset in milliseconds.
            int rawoffset = data._timezone.getRawOffset();
            
            //Divide it by 3600*1000 to remove the millisecond and get the hours.
            int hourshift = (int)rawoffset/(3600 * 1000);
            
            //Get the smallest Julian hour.
            double startjhr = data.getSmallest(0,nV);
            
            //hourshift is the number of hours to shift to go FROM GMT TO the file time zone.  Hence,
            //it is ADDED to the startjhr, since it is already in GMT.
            startjhr += hourshift;
            
            //If I convert the Julian hour to a calendar, now, it will have the date components
            //in local time.
            Calendar startdate = HCalendar.computeCalendarFromJulianHour((int)startjhr);
            
            //Set the hour to be 0 to get hour 0 of that day to be the start hour.
            startdate.add(Calendar.HOUR, -1 * startdate.get(Calendar.HOUR_OF_DAY));
            
            //Now, when I convert back, I'll get the Julian hour in the ESPData time zone that
            //corresponds to hour 0 of the first day.
            startjhr = HCalendar.computeJulianHourFromCalendar(startdate, true);
            
            //But, I need the Julian hour in GMT for it to be the same timezone as the data I have.
            startjhr -= hourshift;
            
            //THESE LINES DEAL WITH DAILY AVERAGING...
            System.out.println("");
            System.out.println("Doing the daily average assuming the start jhr and date in GMT is:");
            System.out.println("    " + startjhr + " -- " +
                    HCalendar.convertCalendarToString(HCalendar.computeCalendarFromJulianHour((int)startjhr),
                    HCalendar.DEFAULT_DATETZ_FORMAT) );
            System.out.println("If you add the offset of the time zone given in the header, you will");
            System.out.println("see the date in the time zone of the ESPData file.  Check that this is");
            System.out.println("correct to be certain my hours are right.");
            System.out.println("");
            
        } catch (Exception e) {
            System.out.println("FAILURE!!!!!!");
        }
        
    }
    
}
