package evs.data;

//Java dependencies
import evs.analysisunits.VerificationUnit;
import evs.data.fileio.GlobalUnitsReader;
import java.util.*;

//EVS dependencies
import evs.utilities.matrix.*;
import evs.utilities.mathutil.*;

/**
 * A class for specifying lead time restrictions on a verification unit.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class LeadTimeCondition extends Condition {
    
    /********************************************************************************
     *                                                                              *
     *                             INSTANCE VARIABLES                               *
     *                                                                              *
     *******************************************************************************/    

    /**
     * The verification unit associated with this condition.
     */
    
    protected VerificationUnit vu = null;
    
    /**
     * Earliest lead time in hours.
     */
    
    private Double earliest = null;

    /**
     * Latest lead time in hours.
     */
    
    private Double latest = null;
    
    /********************************************************************************
     *                                                                              *
     *                                 CONSTRUCTOR                                  *
     *                                                                              *
     *******************************************************************************/        
    
    /**
     * Constructs a condition on lead times using the first and last lead times
     * of the input verification unit. These lead times must be defined. 
     * 
     * @param vu the verification unit
     */
     
    public LeadTimeCondition(final VerificationUnit vu) throws IllegalArgumentException {
        if(!vu.hasLeadTimes()) {
            throw new IllegalArgumentException("Forecast lead times cannot be null.");
        }
        this.vu = vu;
        //Convert to hours if required
        //Compute the number of milliseconds equivalent of the units
        double maxLead = GlobalUnitsReader.getMilliConversionFactor(vu.getForecastLeadTimeUnits());
        //Convert to hours i.e. number of hours per unit
        maxLead = maxLead / (1000.0 * 60.0 * 60.0);       
        double minLead = maxLead;
        earliest = minLead * vu.getFirstLeadTime();
//        //Multiply by the number of units
//        if(vu.hasPairedStartLeadHour()) {
//            earliest = vu.getPairedStartLeadHour();
//        } else {
//            double minLead = maxLead;
//            earliest = minLead * vu.getFirstLeadTime();
//        }
        latest = maxLead * vu.getLastLeadTime();       
    }    

    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/        
    
    /**
     * Returns true if a condition can be applied to a specified verification 
     * unit, otherwise returns false or throws an exception if the condition is false 
     * and throwEx is true.
     *
     * @param vu the verification unit
     * @param throwEx the exception
     * @return true if the condition can be applied, false otherwise
     */
    @Override
    public final boolean canApplyCondition(VerificationUnit vu, boolean throwEx) throws IllegalArgumentException {
        if(vu == null) {
            throw new IllegalArgumentException("The input verification unit cannot be null.");
        }
        boolean returnMe = true;
        if(!vu.hasLeadTimes()) {
            returnMe = false;
            if(throwEx) {
                throw new IllegalArgumentException("Set the lead times of the parent unit '"+vu+"' before associating more specific conditions with this unit.");
            }
        }        
        return returnMe;
    }                
    
    /**
     * Returns the earliest lead time.
     *
     * @return the earliest lead time
     */
    
    public Double getEarliest() {
        return earliest;
    }
    
    /**
     * Returns the latest lead time.
     *
     * @return the latest lead time.
     */
    
    public Double getLatest() {
        return latest;
    }    

    /**
     * Applies the condition, returning a 1D matrix of boolean values whose elements
     * indicate which rows should be used, where true indicates a row should be
     * used. The input data may contain either observed data (i.e. two columns,
     * with valid time and observations), forecasts (valid time, lead time, and members) 
     * or paired data (valid time, lead time, observations and members).  
     *
     * The data type must be either {@link #FORECAST_DATA} or {@link #PAIRED_DATA}. 
     * 
     * @param data the data
     * @param dataType the data type
     * @return the rows that should be used given the condition
     */

    @Override
    public BooleanMatrix1D apply(DoubleMatrix2D data, int dataType) throws IllegalArgumentException {
        if(data == null) {
            throw new IllegalArgumentException("No data have been defined for conditioning purposes.");
        }
        if(dataType!=FORECAST_DATA && dataType!=PAIRED_DATA) {
            throw new IllegalArgumentException("Conditions on lead times require either forecast data or paired data "
                    + "as input.");
        }
        int rows = data.getRowCount();
        boolean[] include = new boolean[rows];
        DoubleProcedure test = FunctionLibrary.isBetween(earliest,latest);
        //Check whether conditions met
        for(int i = 0; i < rows; i++) {
            include[i] = test.apply(data.get(i,1));
        }
        DenseBooleanMatrix1D returnMe = new DenseBooleanMatrix1D(include);
        return returnMe;
    }

    /**
     * Returns true if the input object is a lead time condition and the conditions
     * are equal to those in the current object, false otherwise
     *
     * @param obj the input object
     * @return true if the object has equivalent lead time conditions
     */
    
    @Override
    public boolean equals(Object obj) {
        if(!(obj instanceof LeadTimeCondition)) {
            return false;
        }
        boolean returnMe = false;
        //All null or all equal or null pointer exception
        try {
            returnMe = (earliest==null && latest == null && 
                    ((LeadTimeCondition)obj).earliest == null
                    && ((LeadTimeCondition)obj).latest == null) || 
                    (((LeadTimeCondition)obj).earliest.equals(earliest) && 
                    ((LeadTimeCondition)obj).latest.equals(latest));
                    
        } catch(NullPointerException e) {
            returnMe = false;
        }
        return returnMe;
    }
    
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        assert false : "hashCode not implemented for DateCondition.";
        return 1;
    }
    
    /**
     * Returns a deep copy of the verification condition.
     *
     * @return a deep copy
     */
    
    public Condition deepCopy() {   
        return new LeadTimeCondition(vu);
    }
    
}
