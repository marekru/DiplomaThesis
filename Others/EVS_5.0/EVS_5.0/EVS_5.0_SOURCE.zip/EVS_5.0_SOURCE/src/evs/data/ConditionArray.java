package evs.data;

//EVS dependencies
import evs.utilities.matrix.*;

//Java dependencies
import java.util.*;

/**
 * Convenience class for collating an array of {@link evs.data.Condition}
 * objects and allowing them to be applied sequentially to the input data.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ConditionArray {   
    
    /********************************************************************************
     *                                                                              *
     *                             INSTANCE VARIABLES                               *
     *                                                                              *
     *******************************************************************************/    
    
    /**
     * An array of conditions on which to select data. 
     */
    
    private ArrayList<Condition> conditions = null;
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/        

    /**
     * Construct with an array of non-null {@link evs.data.Condition}.
     * 
     * @param conditions the conditions
     */
    
    public ConditionArray(ArrayList<Condition> conditions) {
        if(conditions == null) {
            throw new IllegalArgumentException("Specify a non-null array of conditions.");
        }
        this.conditions = conditions;
    }
    
    /**
     * Apply each of the conditions sequentially to the input data of specified
     * type.
     * 
     * @param d the data
     * @param dataType the data type 
     * @return the conditional dataset
     * @throws IllegalArgumentException if the input data is null or the data type 
     * inconsistent with the conditions 
     */
    
    public DoubleMatrix2D apply(DoubleMatrix2D d, int dataType) throws IllegalArgumentException {
        if(conditions.isEmpty()) {
            return d;
        }
        int count = conditions.size();
        BooleanMatrix1D conflated = conditions.get(0).apply(d, dataType);
        for(int i = 1; i < count; i++) {
            conflated.conflate(conditions.get(i).apply(d,dataType),false);
        }
        //Construct the result matrix
        ArrayList<double[]> rowsToUse = new ArrayList<double[]>();
        int rows = conflated.getRowCount();
        for(int i = 0; i < rows; i++) {
            if(conflated.get(i)) {
                rowsToUse.add((double[])d.getRowAt(i).getMatrixValues());
            }
        }    

        //Construct the result matrix
        int size = rowsToUse.size();
        if (size < 1) {
            throw new ConditioningException("The conditions failed to select any data.");
        }
        double[][] complete = new double[rowsToUse.size()][d.getColumnCount()];
        for (int i = 0; i < size; i++) {
            complete[i] = rowsToUse.get(i);
        }
        return new DenseDoubleMatrix2D(complete);
    }  
    
    /**
     * Print a string representation.
     * 
     * @return a string representation
     */
    
    @Override
    public String toString() {
        String st = null;
        String nL = System.getProperty("line.separator");
        StringBuffer b = new StringBuffer();
        for(Condition c : conditions) {
            b.append(nL+c+"");
        }
        return b.toString();
    }
    
}
