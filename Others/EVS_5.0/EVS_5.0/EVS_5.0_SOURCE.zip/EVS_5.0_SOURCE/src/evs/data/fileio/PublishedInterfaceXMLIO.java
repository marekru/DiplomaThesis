package evs.data.fileio;

//EVS dependencies
import evs.data.Condition;
import evs.data.ConditionArray;
import evs.data.ConditioningException;
import evs.utilities.matrix.DoubleMatrix2D;
import evs.data.VUIdentifier;
import evs.utilities.StringUtilities;

//Java util dependencies
import java.util.*;

//Java io dependencies
import java.io.*;

//Other XML dependencies
import org.apache.xerces.parsers.SAXParser;
import org.xml.sax.*;

/**
 * Reads one or more time-series files in the Published Interface (PI) XML format,
 * for which a schema is available from:
 * 
 * http://fews.wldelft.nl/schemas/version1.0/pi-schemas/pi_timeseries.xsd 
 * 
 * Reads both files containing ensemble forecasts and files containing observations.
 *
 * This class coordinates the reading of several files and stores the resulting
 * data centrally. The reading of individual PI-XML files is conducted by
 * the PISAXHandler.
 * 
 * @author evs@hydrosolved.com
 */

public class PublishedInterfaceXMLIO extends FileIO implements InputDataIO {

    /*******************************************************************************
     *                                                                             *
     *                                 VARIABLES                                   *
     *                                                                             *
     ******************************************************************************/ 
    
    /**
     * Store of data (either forecasts or observations) by unique identifier in
     * a map.
     */
    
    private HashMap<VUIdentifier, Vector<DoubleMatrix2D>> store = null;

    /**
     * The data to read.
     */

    private Vector<VUIdentifier> readMe = null;

    /**
     * Store of forecast support by unique location identifier in a map.
     * 
     * Format for storage TBD
     */
    
    private HashMap<String, Object[]> support = null;    
    
    /********************************************************************************
     *                                                                              *
     *                                 CONSTRUCTOR                                  *
     *                                                                              *
     *******************************************************************************/

    /**
     * Default constructor.
     */
    
    public PublishedInterfaceXMLIO() throws IOException {
        store = new HashMap();
        support = new HashMap();
    }
    
    /**
     * Reads an array of file containing ensemble forecasts or observations.  The 
     * data are then accessible via the instance methods. Throws an exception if 
     * the expected time zone does not match the time zone on file.
     *
     * @param files the files containing the ensemble forecasts
     * @param readMe the data to read
     * @param zone the time zone to check against the time zone on file
     * @param forecastData is true if the data to be passed are forecasts, false for observations
     * @param conditions an array of conditions upon which to restrict reading (may be null)
     */
    
    public PublishedInterfaceXMLIO(File[] files,Vector<VUIdentifier> readMe,
    		TimeZone zone, boolean forecastData, ConditionArray conditions) throws IOException, ConditioningException {
        this();
        if(files==null || files.length==0) {
            throw new IOException("Specify at least one PI-XML file for reading.");
        }
        this.readMe = readMe;
        Throwable ex = null;
        //Iterate through the files
        for (int i = 0; i < files.length; i++) {
            read(files[i],readMe, zone, forecastData, conditions);   
        }                
    }
    
    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/
    
    /**
     * Returns the data for a specified identifier or throws an exception if not
     * available.
     *
     * @param id the identifier
     * @return the data
     */

    public Vector<DoubleMatrix2D> getData(VUIdentifier id) throws IOException {
        if(!store.containsKey(id)) {
            throw new IOException("No data were read for identifier '"+id+"': " +
                    "check that the identifier is valid and that the corresponding data are on file.");
        }
        return store.get(id);
    }
    
    /**
     * Returns all data in the PI-XML store indexed by unique identifier. 
     * 
     * @return all data
     */

    public HashMap<VUIdentifier, Vector<DoubleMatrix2D>> getAllData() {
        HashMap<VUIdentifier,Vector<DoubleMatrix2D>> returnMe = 
                new HashMap<VUIdentifier,Vector<DoubleMatrix2D>>();
        Iterator it = store.keySet().iterator();
        while(it.hasNext()) {
            VUIdentifier next = (VUIdentifier)it.next();
            Vector<DoubleMatrix2D> v  = new Vector<DoubleMatrix2D>();
            v.addAll(store.get(next));
            returnMe.put(next.deepCopy(),v);
        }        
        return returnMe;
    }
    
    /**
     * Returns true if the store contains data.
     *
     * @return true if the store contains data, false otherwise
     */

    public boolean containsData() {
        return store.size()>0;
    }

    /********************************************************************************
     *                                                                              *
     *                                MUTATOR METHODS                               *
     *                                                                              *
     *******************************************************************************/    
    
    /**
     * Reads a file in the PI-XML format and stores the results for the specified
     * identifiers. Throws an exception if the expected time zone does not match
     * the time zone on file.
     * 
     * @param file the file containing the data
     * @param readMe the data to read
     * @param zone the time zone to check against the time zone on file
     * @param forecastData is true if the data to be passed are forecasts, false for observations
     * @param conditions an array of conditions upon which to restrict reading (may be null)
     */
    
    public final void read(File file, Vector<VUIdentifier> readMe, TimeZone zone,
            boolean forecastData, ConditionArray conditions) throws IOException, ConditioningException {
        System.out.println("Attempting to read file '" + file + "'...");
        PISAXHandler handler = new PISAXHandler(readMe, forecastData);
        SAXParser p = new SAXParser();
        p.setContentHandler(handler);
        BufferedReader r = new BufferedReader(new FileReader(file));
        InputSource input = new InputSource(r);
        try {
            p.parse(input);
        } catch(SAXException e) {
            throw new IOException("Exception in SAX parser: "+e.getMessage());
        }
        int conditionType = Condition.OBSERVED_DATA;
        //Type of condition
        if (forecastData) {
            conditionType = Condition.FORECAST_DATA;
        }

        //Check the time zone for consistency with the expected time zone
        TimeZone checkMe = handler.getTimeZone();
        if (checkMe == null || zone.getRawOffset() != checkMe.getRawOffset()) {
            String checkId = null;
            double checkHours = -999;
            if (checkMe != null) {
                checkId = checkMe.getID();
                checkHours = ((double) checkMe.getRawOffset()) / 3600000.0;
            }
            double zoneHours = ((double) zone.getRawOffset()) / 3600000.0;

            throw new IOException("The expected time zone (" + zone.getID() + ") with offset in "
                    + "hours from UTC '" + zoneHours + "' does not correspond to the time zone "
                    + "read from the PI-XML file ("
                    + checkId + ") with offset in hours from UTC '" + checkHours + "'.");
        }
        int tot = readMe.size();
        int handledCount = 0;
        for (int i = 0; i < tot; i++) {
            VUIdentifier id = readMe.get(i);
            if (store.containsKey(id)) {
                Vector current = store.get(id);
                //JB@10th December 2012
                DoubleMatrix2D handled = handler.getData(id);
                if (conditions != null) {
                    try {
                        handled = conditions.apply(handled, conditionType);
                        handledCount++;
                    } catch (Exception e) {
                        System.err.println("The conditions failed to select data for '" + id + "' in file '" + file + "'.");
                    }
                } else {
                    handledCount++;
                }
                current.add(handled);
            } else {
                Vector<DoubleMatrix2D> v = new Vector();
                //JB@10th December 2012
                DoubleMatrix2D handled = handler.getData(id);
                if (conditions != null) {
                    try {
                        handled = conditions.apply(handled, conditionType);
                        handledCount++;
                    } catch (Exception e) {
                        System.err.println("The conditions failed to select data for '" + id + "' in file '" + file + "'.");
                    }
                } else {
                    handledCount++;
                }
                v.add(handled);
                store.put(id, v);
            }
        }
        if (handledCount == 0) {
            throw new ConditioningException("The conditions failed to select data for any of the locations and variables requested in file '" + file + "'.");
        }
        System.out.println("File read successfully '" + file + "'.");
    }

    /**
     * Reads a file in the PI-XML format and stores the results for all
     * identifiers on file.
     *
     * @param file the file containing the data
     * @param forecastData is true if the data to be passed are forecasts, false
     * for observations
     * @param conditions an array of conditions upon which to restrict reading
     * (may be null)
     */
    public void read(File file, boolean forecastData, ConditionArray conditions) throws IOException, ConditioningException {
        PISAXHandler f = new PISAXHandler(forecastData);
        SAXParser p = new SAXParser();
        p.setContentHandler(f);
        BufferedReader r = new BufferedReader(new FileReader(file));
        InputSource input = new InputSource(r);
        try {
            p.parse(input);
        } catch(SAXException e) {
            throw new IOException("Exception in SAX parser: "+e.getMessage());
        }
        HashMap<VUIdentifier, DoubleMatrix2D> d = f.getAllData();
        int conditionType = Condition.OBSERVED_DATA;
        //Type of condition
        if (forecastData) {
            conditionType = Condition.FORECAST_DATA;
        }
        Iterator it = d.keySet().iterator();
        int handledCount = 0;
        while (it.hasNext()) {
            VUIdentifier id = (VUIdentifier) it.next();
            if (store.containsKey(id)) {
                Vector current = store.get(id);
                //JB@10th December 2012
                DoubleMatrix2D handled = d.get(id);
                if (conditions != null) {
                    try {
                        handled = conditions.apply(handled, conditionType);
                        handledCount++;
                    } catch (Exception e) {
                        System.err.println("The conditions failed to select data for '" + id + "' in file '" + file + "'.");
                    }
                } else {
                    handledCount++;
                }
                current.add(handled);
            } else {
                Vector<DoubleMatrix2D> v = new Vector();
                //JB@10th December 2012
                DoubleMatrix2D handled = d.get(id);
                if (conditions != null) {
                    try {
                        handled = conditions.apply(handled, conditionType);
                        handledCount++;
                    } catch (Exception e) {
                        System.err.println("The conditions failed to select data for '" + id + "' in file '" + file + "'.");
                    }
                } else {
                    handledCount++;
                }
                v.add(handled);
                store.put(id, v);
            }
        }
        if (handledCount == 0) {
            throw new ConditioningException("The conditions failed to select data for any of the locations and variables requested in file '" + file + "'.");
        }
        System.out.println("File read successfully '" + file + "'.");
    }

    /**
     * Clears the data store of any data read from file.
     */
    
    public void clearDataStore() {
        if(readMe!=null) {
            readMe.clear();
        }
        store.clear();
        support.clear();
    } 
    
/*******************************************************************************
 *                                                                             *
 *                                  TEST METHOD                                *
 *                                                                             *
 ******************************************************************************/     
    
    /**
     * Test method.
     *
     * @param args the args
     */
    
    public static void main(String[] args) {
        
        try {
        	
            //File f = new File("D:/NOAA_work/HEP_projects/Ensemble_verification/Test_data/Deltares_FEWS_data/200807180900_MOGREPS_TCM_MODIFIED.XML");
            //File f2 = new File("D:/NOAA_work/HEP_projects/Ensemble_verification/Test_data/Deltares_FEWS_data/200807180900_DischargeTelemetry_Measured_MODIFIED.XML");
        	//File f = new File("C:/Documents and Settings/james.d.brown/Desktop/195001011200_SQME_flathead.xml");
            File f2 = new File("D:/Data/HEFSv1/MARFC/Streamflow/Observations/CNNN6TINQME_1979-1999.xml");
            
        	Vector v1 = new Vector();
            v1.add(new VUIdentifier("CNNN6TIN","QINE"));
            
            //PublishedInterfaceXMLIO pi = new PublishedInterfaceXMLIO(new File[]{f},v1,
                //TimeZone.getTimeZone("UTC"),true,null); 
            PublishedInterfaceXMLIO pi2 = new PublishedInterfaceXMLIO(new File[]{f2},v1,
                    TimeZone.getTimeZone("GMT-6"),false,null);        

            StringUtilities.setDateString("yyyyMMddHH");
            //StringUtilities.printWithDates(0,pi.getData((VUIdentifier)v1.get(0)).get(0));
            StringUtilities.printWithDates(0,pi2.getData((VUIdentifier)v1.get(0)).get(0));
            
        } catch(Exception e) {
            e.printStackTrace();
        }        
        
//        try {
//            //File f = new File("C:/Documents and Settings/brownj/Desktop/200807312100_Discharge_Measured.XML");
//            File f2 = new File("C:/Documents and Settings/brownj/Desktop/197901011200_NFDC1_ESP.XML");
//            //PublishedInterfaceXMLIO pi = new PublishedInterfaceXMLIO(new File[]{f},OBSERVED,"Edgware Hospital"); 
//            //PublishedInterfaceXMLIO pi2 = new PublishedInterfaceXMLIO(new File[]{f2},ENSEMBLE_FORECAST,"Edgware Hospital");        
//            
//            PublishedInterfaceXMLIO check = new PublishedInterfaceXMLIO();
//            System.out.println(check.isOfType(f2));
//            VUIdentifier v = new VUIdentifier("NFDC1","Flow");
//            System.out.println(check.getData(v).get(0));
//            
//            //System.out.println(pi.getData("Edgware Hospital").get(0));
//            //System.out.println(pi2.getData("Edgware Hospital").get(0));
//            
//        } catch(Exception e) {
//            e.printStackTrace();
//        }
    }   
    
}
