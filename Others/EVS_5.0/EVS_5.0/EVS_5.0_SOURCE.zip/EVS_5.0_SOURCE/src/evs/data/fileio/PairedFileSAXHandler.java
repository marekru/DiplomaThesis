package evs.data.fileio;
        
//SAX dependencies
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;

//Java util dependencies 
import java.util.Vector;
import java.util.Arrays;

//EVS dependencies
import evs.analysisunits.AnalysisUnit;
import evs.utilities.matrix.DoubleMatrix2D;
import evs.utilities.matrix.DenseDoubleMatrix2D;

/**
 * Handler for reading paired files in XML format using the SAX model.
 * 
 * @author evs@hydrosolved.com
 */

public class PairedFileSAXHandler extends DefaultHandler {

/********************************************************************************
 *                                                                              *
 *                              INSTANCE VARIABLES                              *
 *                                                                              *
 *******************************************************************************/    
    
    /**
     * The completed data rows.
     */
    
    private Vector<double[]> rows = new Vector();
    
    /**
     * Forecasts for the last pair.
     */
    
    private double[] forecasts = null;
    
    /**
     * Internal hours for the last pair.
     */
    
    private double internHours = -999;  
    
    /**
     * Observation for the last pair.
     */
    
    private double obs = -999; 
    
    /**
     * Lead hours for the last pair.
     */
    
    private double lead = -999; 
    
    /**
     * The last character set read.
     */
    
    private StringBuffer last;
    
    /**
     * The maximum number of ensemble members.
     */
    
    private int maxCols = 0;    
    
    /**
     * Number of pairs in the file.
     */
    
    private double pairCount = 0;
    
    /**
     * Number of pairs read.
     */
    
    private double pairsRead = 0;

    /**
     * Paired data, constructed on completion.
     */

    private DoubleMatrix2D pairs = null;
    
    /**
     * The null value
     */
    
    private double nV;
    
/********************************************************************************
 *                                                                              *
 *                                 CONSTRUCTOR                                  *
 *                                                                              *
 *******************************************************************************/   
    
    /**
     * Constructs the handler with a null data value.
     * 
     * @param nV the null data value
     */
    
    public PairedFileSAXHandler(double nV) {
        super();
        this.nV=nV;
    }
    
/********************************************************************************
 *                                                                              *
 *                                ACCESSOR METHODS                              *
 *                                                                              *
 *******************************************************************************/   
    
    /**
     * Returns a paired dataset from the available data.
     * 
     * @return a paired dataset
     */
    
    public final DoubleMatrix2D getPairs() throws IllegalArgumentException {
        if(pairs==null) {
            throw new IllegalArgumentException("No paired data read.");
        }
        return pairs;
    }
    
/********************************************************************************
 *                                                                              *
 *                                MUTATOR METHODS                               *
 *                                                                              *
 *******************************************************************************/     
    
    /**
     * Starts the document.
     */
    
    public final void startDocument() {
        last = new StringBuffer();
    }

    /**
     * Ends the document.
     */

    public final void endDocument() {
        int size = rows.size();
        if (size > 0) {
            //Construct the paired dataset
            double[][] data = new double[size][maxCols];
            for (int i = 0; i < data.length; i++) {
                //Must explicitly initialize for the full space required: allocation
                //of a 1D array in a 2D array is NOT sufficient
                double[] nextD = new double[maxCols];
                Arrays.fill(nextD,nV);
                double[] row = rows.get(i);
                System.arraycopy(row, 0, nextD, 0, row.length);
                data[i] = nextD;
            }
            pairs = new DenseDoubleMatrix2D(data);
            rows.clear();
        }
    }

    /**
     * Starts an element.
     *
     * @param namespaceURL the URL
     * @param localName the local name
     * @param qname the raw XML name
     * @param attributes the attributes
     */
    
    public final void startElement(String namespaceURL, String localName,String qname, Attributes attributes) {
        last.setLength(0);
    }
    
    /**
     * Increments the paired dataset.
     *
     * @param uri the URI
     * @param localName the tag name
     * @param qName the raw XML name
     */
    
    public final void endElement(String uri, String localName, String qName) throws SAXException {
        if(localName.equals("in_h")) {
            internHours = new Double(last+"");
        } else if(localName.equals("ld_h")) {
            lead = new Double(last+"");
        } else if(localName.equals("ob")) {
            obs = new Double(last+"");
        } else if(localName.equals("fc")) {
            forecasts = FileIO.getDoubleArray(last+"");
        } 
        //Create and store the new row
        else if(localName.equals("pr")) {
            //Construct the new row
            double[] result = new double[forecasts.length+3];
            if(result.length > maxCols) {
                maxCols = result.length;
            }
            result[0] = internHours;
            result[1] = lead;
            result[2] = obs;
            System.arraycopy(forecasts,0,result,3,forecasts.length);
            rows.add(result);
            pairsRead+=1;
        } else if(localName.equals("pair_count")) {
            pairCount = new Integer(last+"");
        }
    }
   
    /**
     * Reads un-tagged characters (i.e. data values).
     *
     * @param ch the characters
     * @param start the start index
     * @param length the length
     */
    
    public final void characters (char[] ch, int start, int length) {
        last.append(ch, start, length);        
    }

    /**
     * Returns the number of pairs in the file.
     * 
     * @return the number of pairs on file
     */
    
    public final double getPairCount() {
        return pairCount;
    }
    
    /**
     * Returns the number of pairs read from the file.
     * 
     * @return the number of pairs read from file
     */
    
    public final double getPairsReadCount() {
        return pairsRead;
    }   
    
}
