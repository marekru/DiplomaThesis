package evs.data.fileio.ohdfile.data;
import java.io.IOException;

/*************************************************
* ESPDataException
*
*
* This class is the exception thrown by ESPData if it fails to read in the data.
*
*
*
*      Date            Person          Comment
*      ----------      ------------    ----------------------------------------------
*      2004-01-12      Hank Herr       Completed a long time ago!!!
*
*
*
*  FUNCTIONS (in order of appearance):
*
*    public ESPDataException()
*    public ESPDataException(String s)
*
*************************************************/
public class ESPDataException extends IOException {
    private static final long serialVersionUID = 1L;
    public ESPDataException() {
        super();
    }
    
    public ESPDataException(String s) {
        super(s);
    }
    
}
