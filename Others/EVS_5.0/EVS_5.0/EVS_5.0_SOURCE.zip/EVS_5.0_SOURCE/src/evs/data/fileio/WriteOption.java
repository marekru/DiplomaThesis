package evs.data.fileio;

//Java util dependencies
import java.util.ArrayList;

/**
 * Class of options for writing graphical and numerical results.
 *
 * TODO: decompose this class into meaningful elements and methods, rather than
 * lumped storage. Also, separate the graphical and numerical writing options. 
 *
 * @author evs@hydrosolved.com
 * @version 5.0 
 */

public class WriteOption {

/*******************************************************************************
 *                                                                             *
 *                               CLASS VARIABLES                               *
 *                                                                             *
 ******************************************************************************/     
    
    /**
     * Identifier for JPEG graphics writing options
     */
    
    public static final int JPEG_GRAPHICS = 202;
    
    /**
     * Identifier for PNG graphics writing options
     */
    
    public static final int PNG_GRAPHICS = 203;    
    
    /**
     * Identifier for SVG graphics writing options
     */
    
    public static final int SVG_GRAPHICS = 204;      
    
    /**
     * Identifier for XML writing options
     */
    
    public static final int XML_NUMERICS = 205;           
    
/*******************************************************************************
 *                                                                             *
 *                              INSTANCE VARIABLES                             *
 *                                                                             *
 ******************************************************************************/     
    
    /**
     * Option identifier (see the parent class for supported types).
     */
    
    private int id;
    
    /**
     * Options name.
     */
    
    private String name = null;
    
    /**
     * Short string identifier.
     */
    
    private String shortString = null;
    
    /**
     * Parameter values associated with the writing option.
     */
    
    private ArrayList<String> pars = null;
    
/*******************************************************************************
 *                                                                             *
 *                                CONSTRUCTORS                                 *
 *                                                                             *
 ******************************************************************************/        
    
    /**
     * Constructs the writing option from an integer ID, which must be one of:
     * 
     * {@link #JPEG_GRAPHICS}
     * {@link #PNG_GRAPHICS}
     * {@link #SVG_GRAPHICS}
     * {@link #XML_NUMERICS}
     *
     * @param id the identifier of the writing option
     */
    
    public WriteOption(int id) {
        switch(id) {
            case JPEG_GRAPHICS: {
                name = "JPEG file (*.jpg)";
                shortString = "JPEG";
                pars = new ArrayList<String>();
                pars.add("800");  //Width in pixels
                pars.add("600");  //Height in pixels
                pars.add("1.0");  //Quality            
            }; break;
            case PNG_GRAPHICS: {
                name = "PNG file (*.png)";
                shortString = "PNG";
                pars = new ArrayList<String>();
                pars.add("800");  //Width in pixels
                pars.add("600");  //Height in pixels
                pars.add("5");  //Compression              
            }; break;
            case SVG_GRAPHICS: {
                name = "SVG file (*.svg)";
                shortString = "SVG";
                pars = new ArrayList<String>();
                pars.add("800");  //Width in pixels
                pars.add("600");  //Height in pixels                
            }; break;
            case XML_NUMERICS: {
                name = "XML file (*.xml)"; 
                shortString = "XML";
            }; break;
            default: {
                throw new IllegalArgumentException("Unrecognized format for writing.");
            }   
        }
        this.id = id;
    }   
    
    /**
     * Convenience method for constructing a graphics option with a short string
     * ID, which must be one of:
     * 
     * JPEG
     * PNG
     * SVG
     * XML
     *
     * @param shortString the identifier of the writing option
     */
    
    public WriteOption(String shortString) {
        this(getIDForString(shortString));
    }      
    
/*******************************************************************************
 *                                                                             *
 *                              ACCESSOR METHODS                               *
 *                                                                             *
 ******************************************************************************/ 
    
    /**
     * Returns the unique identifier of the graphics option.
     *
     * @return the option identifier.
     */
    
    public int getID() {
        return id;
    }

    /**
     * Returns the short string identifier of the graphics option.
     *
     * @return the short string identifier.
     */
    
    public String getStringID() {
        return shortString;
    }    
    
    /**
     * Returns a list of parameter associated with the writing option.
     *
     * @return the pars
     */
    
    public ArrayList<String> getPars() {
        ArrayList<String> returnMe = new ArrayList<String>();
        returnMe.addAll(pars);
        return returnMe;
    }

    /**
     * Returns a string representation of the writing option.
     *
     * @return a string representation of the writing option
     */
    
    public String toString() {
        return name;
    }
    
    /**
     * Returns the integer ID corresponding to a given string or throws an exception
     * if the input string is unrecognized. The following pairings apply:
     * 
     * JPEG {@link #JPEG_GRAPHICS}
     * PNG {@link #PNG_GRAPHICS}
     * SVG {@link #SVG_GRAPHICS}
     * XML {@link #XML_NUMERICS}
     * 
     * @param shortString the string ID of the writing option 
     * @return the integer ID corresponding to the input string
     */
    
    public static final int getIDForString(String shortString) {
        IllegalArgumentException e = new IllegalArgumentException("Unrecognized writing option '" + shortString + "'");
        if (shortString == null) {
            throw e;
        }
        if (shortString.equals("JPEG")) {
            return JPEG_GRAPHICS;
        } else if (shortString.equals("PNG")) {
            return PNG_GRAPHICS;
        } else if (shortString.equals("SVG")) {
            return SVG_GRAPHICS;
        } else if (shortString.equals("XML")) {
            return XML_NUMERICS;
        } else {
            throw e;
        }
    }
    
/*******************************************************************************
 *                                                                             *
 *                              MUTATOR METHODS                                *
 *                                                                             *
 ******************************************************************************/     

    /**
     * Sets a list of parameter values for the writing option. The input identifier
     * must be consistent with the identifier stored for the object.
     *
     * @param id the identifier
     * @param pars the parameter values
     */
    
    public void setPars(int id, ArrayList<String> pars) throws IllegalArgumentException {
        if(this.id!=id) {
            throw new IllegalArgumentException("Input ID, '"+id+"', is inconsistent with the stored "
                    + "ID, '"+this.id+"'.");
        }
        if(pars==null) {
            throw new IllegalArgumentException("The input parameters cannot be null.");
        }
        if(pars.size()!=this.pars.size()) {
            throw new IllegalArgumentException("Expected '"+this.pars.size()+"' input parameters, but received '"+pars.size()+"'.");
        }
        this.pars.clear();
        this.pars.addAll(pars);    
    }
    
}
