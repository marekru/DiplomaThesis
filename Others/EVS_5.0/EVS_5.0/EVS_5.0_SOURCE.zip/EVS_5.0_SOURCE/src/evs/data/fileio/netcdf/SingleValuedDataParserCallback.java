package evs.data.fileio.netcdf;
import java.util.Map;

/**
 * Interface for a callback object to store the parsed single-valued data. 
 * 
 * @author evs@hydrosolved.com
 */

public interface SingleValuedDataParserCallback {
	
	void setStationInfo(Map<String, String> stationIdNameMap);
	
	void setNumberOfStations(int number);
	
	void setTimeInfo(long[] timeStamps);
	
	void handleTimeSeries(double[] timeSeries, String stationId, String variableName);
    
}
