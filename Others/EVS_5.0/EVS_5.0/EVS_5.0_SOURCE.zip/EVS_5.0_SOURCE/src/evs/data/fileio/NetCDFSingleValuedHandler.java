package evs.data.fileio;

//Java dependencies 
import java.util.*;
import java.io.IOException;

//EVS dependencies
import evs.utilities.matrix.*;
import evs.data.*;
import evs.data.fileio.netcdf.*;

/**
 * Handler for time-series files in the NetCDF format. Reads files containing 
 * single-valued time-series.
 * 
 * @author evs@hydrosolved.com
 */

public class NetCDFSingleValuedHandler implements SingleValuedDataParserCallback {

/********************************************************************************
 *                                                                              *
 *                                CONSTRUCTORS                                  *
 *                                                                              *
 *******************************************************************************/     
    
   /**
    * Constructor to read in data for a specific set of locations and variables.
    *
    * @param readMe the data to read
    */ 
    
    public NetCDFSingleValuedHandler(Vector<VUIdentifier> readMe){
        this.readMe = readMe;
    }    
    
/********************************************************************************
 *                                                                              *
 *                              INSTANCE VARIABLES                              *
 *                                                                              *
 *******************************************************************************/    
    /**
     * The data to read.
     */
    private Vector<VUIdentifier> readMe = null;
    /**
     * Store of data (either forecasts or observations) by unique VUIdentifier
     * in a map. The first two rows comprise the valid times and lead times.
     */
    private HashMap<VUIdentifier,Vector<double[]>> store = new HashMap();
    
    /**
     * Store of forecast support by unique location identifier in a map.
     * 
     * Format for storage TBD
     */
    private HashMap<String, Object[]> support = new HashMap();
    /**
     * Timezone
     */
    private TimeZone zone;    
    
    /**
     * Valid times for all data.
     */
    
    private double[] valid = null;    
    
/********************************************************************************
 *                                                                              *
 *                                ACCESSOR METHODS                              *
 *                                                                              *
 *******************************************************************************/   
    
    /**
     * Returns the data for a specified identifier or throws an exception if not
     * available.
     * 
     * @param id the identifier
     * @return the data
     */
    
    public DoubleMatrix2D getData(VUIdentifier id) throws IOException {
        if(!store.containsKey(id)) {
            throw new IOException("No data were read for identifier '"+id+"': " +
                    "check that the identifier is valid and that the corresponding data are on file.");
        }
        return retrieve(id);
    }
    
    /**
     * Returns the data for the first identifier in the store.
     * 
     * @return the data for the first identifier in store
     */
    
    public DoubleMatrix2D getData() throws IOException {
        if(store.isEmpty()) {
            throw new IOException("No data were found in the PI-XML store.");
        }
        return retrieve(store.keySet().iterator().next());
    }
    
    /**
     * Returns the time zone read from file or null if the time
     * zone has not been read.
     * 
     * @return the time zone
     */
    
    public TimeZone getTimeZone() {
    	if(zone!=null) {
    		return TimeZone.getTimeZone(zone.getID());
    	}
    	return null;
    }
    
    /**
     * Returns the data for all locations indexed by unique ID.
     * 
     * 
     * @return data for all stored locations indexed by unique ID
     */
    
    public HashMap<VUIdentifier,DoubleMatrix2D> getAllData() throws IOException {
        if(store.isEmpty()) {
            throw new IOException("No data were found in the PI-XML store.");
        }
        HashMap<VUIdentifier,DoubleMatrix2D> returnMe = 
                new HashMap<VUIdentifier,DoubleMatrix2D>();
        Iterator it = store.keySet().iterator();
        while(it.hasNext()) {
            VUIdentifier next = (VUIdentifier)it.next();
            returnMe.put(next.deepCopy(),retrieve(next));
        }
        return returnMe;
    }
    
    /**
     * Returns the data for a specified ID.
     * 
     * @param id the identifier
     * @return the corresponding data
     */
    private DoubleMatrix2D retrieve(VUIdentifier id) {
        Vector<double[]> d = store.get(id);
        double[][] data = new double[d.size() + 1][];
        data[0] = valid;
        for (int i = 1; i < data.length; i++) {
            data[i] = d.get(i-1);
        }
        DoubleMatrix2D dt = new DenseDoubleMatrix2D(data);
        return dt.transpose();
    }

    
/********************************************************************************
 *                                                                              *
 *                                MUTATOR METHODS                               *
 *                                                                              *
 *******************************************************************************/     
    
    @Override
    public void setStationInfo(Map<String, String> stationIdNameMap) {
        for (Map.Entry<String, String> entry : stationIdNameMap.entrySet()) {
            //Do nothing
        }
    }

    @Override
    public void setNumberOfStations(int number) {
        //Do nothing
    }

    @Override
    public void setTimeInfo(long[] timeStamps) {
        //Set valid times and lead times
        valid = new double[timeStamps.length];
        int length = timeStamps.length;
        double div = 1000.0*60.0*60.0;
        for(int i = 0; i < length; i++) {
            valid[i]=timeStamps[i]/div;
        }
    }

    @Override
    public void handleTimeSeries(double[] timeSeries, String stationID, String variableID) {
        VUIdentifier check = new VUIdentifier(stationID,variableID);
        if(readMe!=null) {
            if(!readMe.contains(check)) {
                return;
            }
        }
        if(store.containsKey(check)) {
            Vector<double[]> v = store.get(check);
            v.add(timeSeries);
        } else{
            Vector<double[]> v = new Vector<double[]>();
            v.add(timeSeries);
            store.put(check,v);
        }
    }
    
    
    

}
