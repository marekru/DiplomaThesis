package evs.data;

/**
 * Class for throwing exceptions that signify an invalid unit.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class PairedDataException extends RuntimeException {
    
    /**
     * Constructs an PairedDataException with no message.
     */
    
    public PairedDataException() {
        super();
    }

    /**
     * Constructs an PairedDataException with the specified message. 
     * 
     * 
     * 
     * @param s the message.
     */
    
    public PairedDataException(String s) {
	super(s);
    }
}
