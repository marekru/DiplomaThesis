package evs.data;

import java.awt.Font;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.XYPlot;

import org.jfree.data.xy.DefaultXYDataset;
import org.jfree.chart.renderer.xy.XYDotRenderer;

import java.awt.Graphics2D;
import java.awt.Graphics;
import java.awt.geom.Line2D;
import java.awt.Color;

import javax.swing.JFrame;

/**
 * Convenience class for rapidly viewing synthetically generated pairs. 
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class CheckSyntheticScatter extends JFrame{
    
    /**
     * Creates a new plot with a specified dataset, plot title and titles for 
     * each axis.
     *
     * @param data the data
     * @param plotTitle the plot title
     * @param xTitle the x axis title
     * @param yTitle the y axis title
     */
    
    public CheckSyntheticScatter(final double[][] data, String plotTitle, String xTitle, String yTitle) {
        DefaultXYDataset dataset = new DefaultXYDataset();
        dataset.addSeries("",data);
        setTitle(plotTitle);       
        final NumberAxis xAxis = new NumberAxis(xTitle);
        final NumberAxis yAxis = new NumberAxis(yTitle);       
        
        //xAxis.setTickLabelsVisible(false);
        xAxis.setTickLabelFont(new Font("Verdana", Font.PLAIN, 8));
        yAxis.setTickLabelFont(new Font("Verdana", Font.PLAIN, 8));
        yAxis.setAutoRangeIncludesZero(false);
        final XYDotRenderer renderer = new XYDotRenderer();
        renderer.setDotHeight(3);
        renderer.setDotWidth(3);
        renderer.setPaint(Color.black);
        
        final XYPlot plot = new XYPlot(dataset, xAxis, yAxis, renderer);
        final JFreeChart chart = new JFreeChart(
            plotTitle,
            new Font("Verdana", Font.BOLD, 12),
            plot,
            true
        );
        
        final ChartPanel chartPanel = new ChartPanel(chart) {
            public void paint(Graphics g) {
                super.paint(g);
                
                //Draw horizontal line at y = 0
                double yPosition = yAxis.valueToJava2D(0.0,getScreenDataArea(),plot.getRangeAxisEdge());
                double xLower = getScreenDataArea().getMinX();
                double xUpper = getScreenDataArea().getMaxX();
                ((Graphics2D)g).draw(new Line2D.Double(xLower,yPosition,xUpper,yPosition));
                //Draw vertical line at x = 0
                double xPosition = xAxis.valueToJava2D(0.0,getScreenDataArea(),plot.getDomainAxisEdge());
                double yLower = getScreenDataArea().getMinY();
                double yUpper = getScreenDataArea().getMaxY();
                ((Graphics2D)g).draw(new Line2D.Double(xPosition,yLower,xPosition,yUpper));
                
                /*//Plot the mean of the error statistic
                
                java.awt.Stroke original = ((Graphics2D)g).getStroke();
                float lineDim = 2;
                double xLower = getScreenDataArea().getMinX();
                double xUpper = getScreenDataArea().getMaxX();
                
                //Compute regression and correlation as required
                /*double[] xData = data[0];
                double[] yData = data[1];
                double[] sortedX = new double[xData.length];
                System.arraycopy(xData,0,sortedX,0,xData.length);
                java.util.Arrays.sort(sortedX);
                double xRange = sortedX[sortedX.length-1]-sortedX[0];
                double[] regression = null;
                Number[] x = new Number[xData.length];
                Number[] y = new Number[yData.length];
                for(int i = 0; i < x.length; i++) {
                    x[i] = xData[i];
                    y[i] = yData[i];
                }
                regression = org.jfree.data.statistics.Statistics.getLinearFit(x,y);
                double rho = org.jfree.data.statistics.Statistics.getCorrelation(x,y);
                double yFirst = sortedX[0] * regression[1] + regression[0];
                yFirst = yAxis.valueToJava2D(yFirst,getScreenDataArea(),plot.getRangeAxisEdge());
                double yLast = sortedX[sortedX.length-1] * regression[1] + regression[0];
                yLast = yAxis.valueToJava2D(yLast,getScreenDataArea(),plot.getRangeAxisEdge());
                g.setColor(Color.blue);
                ((Graphics2D)g).draw(new Line2D.Double(xLower,yFirst,xUpper,yLast));
                g.setColor(Color.black);
                
                //Draw a legend for the new items in the upper left corner of the chart
                g.setColor(Color.black);
                double xLeft = getScreenDataArea().getMinX(); 
                double yTop = getScreenDataArea().getMinY(); 
                double chartHeight = getScreenDataArea().getMaxY() - getScreenDataArea().getMinY(); 
                double chartWidth = getScreenDataArea().getMaxX() - getScreenDataArea().getMinX();
                ((Graphics2D)g).draw(new Rectangle2D.Double(xLeft+10,yTop+10,chartWidth/4,chartHeight/10));
                Rectangle2D rect = new Rectangle2D.Double(xLeft+11,yTop+11,chartWidth/4-1,chartHeight/10-1);
                g.setColor(Color.white);
                ((Graphics2D)g).fill(rect);
                g.setColor(Color.black);
                
                double height4th = (chartHeight/10)/4;
                double width3rd = (chartWidth/7)/3;
                //Draw the legend lines
                //Mean
                ((Graphics2D)g).setStroke(new java.awt.BasicStroke(lineDim));
                ((Graphics2D)g).draw(new Line2D.Double(xLeft+15,yTop+10+height4th,xLeft+15+width3rd,yTop+10+height4th));
                ((Graphics2D)g).setStroke(original);
                //Mean absolute error
                g.setColor(Color.blue);
                ((Graphics2D)g).draw(new Line2D.Double(xLeft+15,yTop+10+height4th*2,xLeft+15+width3rd,yTop+10+height4th*2));
                g.setColor(Color.black);
                //Draw the legend labels
                ((Graphics2D)g).setFont(new java.awt.Font("Verdana",java.awt.Font.PLAIN,10));
                ((Graphics2D)g).drawString("Y = "+Math.rint(regression[1]*100)/100.0+"X + "+Math.rint(regression[0]*100)/100.0,(float)xLeft+15,(float)(yTop+10+height4th*3+1));*/
            }            
        };
        chart.removeLegend();
        chartPanel.setPreferredSize(new java.awt.Dimension(800, 600));
        setContentPane(chartPanel);   
    }
   
}
