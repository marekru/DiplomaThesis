package evs.data.fileio.netcdf;

//Java dependencies
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

//Apache dependencies
import org.apache.commons.httpclient.Credentials;
import org.apache.commons.httpclient.UsernamePasswordCredentials;
import org.apache.commons.httpclient.auth.AuthScheme;
import org.apache.commons.httpclient.auth.CredentialsNotAvailableException;
import org.apache.commons.httpclient.auth.CredentialsProvider;

//Thredds dependencies
import thredds.catalog.InvAccess;
import thredds.catalog.InvCatalogFactory;
import thredds.catalog.InvCatalogImpl;
import thredds.catalog.InvDataset;
import thredds.catalog.ServiceType;

//UCAR dependencies
import ucar.nc2.NetcdfFile;
import ucar.nc2.Variable;
import ucar.nc2.dataset.NetcdfDataset;
import ucar.nc2.util.net.HTTPSession;

/**
 * Example class to demonstrate reading NetCDF data, either from file or from an
 * OPenDAP server using the NetCDF libraries from Unidata, see
 * http://www.unidata.ucar.edu/downloads/netcdf/netcdf-java-4/index.jsp This
 * example only reads the data, for reading the associated metadata, please
 * refer to org.openda.exchange.dataobjects.NetcdfDataObject.readNetcdfFile()
 *
 * @author Frederik van den Broek
 *
 */
public class SimpleNetcdfDataReader {

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }

    /**
     * This method reads the data from a NetCDF File
     *
     * @param file
     * @return the data
     * @throws IOException
     */
    public ArrayList<VariableDataSet> parse(File file) throws IOException {
        ArrayList<VariableDataSet> data = null;
        NetcdfFile netcdfFile = null;
        try {
            netcdfFile = NetcdfDataset.openFile(file.getAbsolutePath(), null);
            data = parseNetcdfFile(netcdfFile);
        } finally {
            if (netcdfFile != null) {
                netcdfFile.close();
            }
        }
        return data;
    }

    /**
     * This method downloads one or more NetCDF files from a given URL and then
     * parses them
     *
     * @param url
     * @return the data
     * @throws IOException
     */
    public ArrayList<VariableDataSet> parse(URL url) throws IOException {
        return parse(url, "", "");
    }

    /**
     * This method downloads one or more NetCDF files from a given URL with an
     * optional username and password and then parses them
     *
     * @param url
     * @param username username for the server, supply an empty string when not
     * used
     * @param password password for the server, supply an empty string when not
     * used
     * @return the data
     * @throws IOException
     */
    public ArrayList<VariableDataSet> parse(URL url, String username, String password) throws IOException {
        if (url == null) {
            throw new IllegalArgumentException("url is null.");
        }

        ArrayList<VariableDataSet> data = new ArrayList<VariableDataSet>();
        ArrayList<String> dataSetUrlStrings = new ArrayList<String>();

        String configuredUrlString = url.toString().trim();
        // The configured URL is a catalog.
        if (configuredUrlString.toLowerCase().endsWith(".xml")) {
            String catalogUrlString = configuredUrlString;
            System.out.println("Configured url " + configuredUrlString + " identified as a catalog."
                        + " Reading dataSet urls from catalog " + catalogUrlString);
            
            // Create catalog object.
            InvCatalogFactory catalogFactory = new InvCatalogFactory("catalogFactory", true);
            InvCatalogImpl catalog = catalogFactory.readXML(catalogUrlString);
            // Check format of catalog.
            StringBuilder stringBuilder = new StringBuilder();
            if (!catalog.check(stringBuilder)) {
                // The catalog is not valid.
                throw new IOException("Configured catalog '" + catalogUrlString + "' is not valid: " + stringBuilder.toString());
            }

            // Recursively get the URLs of all the dataSets in the catalog and store these in dataSetUrlStrings list.
            dataSetUrlStrings.addAll(getDataSetUrlStrings(catalog.getDatasets()));
            // Trim all urlStrings.
            for (int n = 0; n < dataSetUrlStrings.size(); n++) {
                dataSetUrlStrings.set(n, dataSetUrlStrings.get(n).trim());
            }

            //remove URLs of files that are not readable dataSets.
            Iterator<String> iterator = dataSetUrlStrings.iterator();
            while (iterator.hasNext()) {
                String urlString = iterator.next();
                if (urlString.toLowerCase().endsWith("catalog.nc")) {
                    //remove catalog.nc files. These are only present on the opendap.deltares.nl server as an experiment,
                    //but are not an international standard.
                    iterator.remove();
                }
            }

            if (dataSetUrlStrings.isEmpty()) {
                System.out.println("Catalog '" + catalogUrlString + "' contains no valid dataSets to import.");
            }

        } else {//if the configured URL is a single dataSet.
            System.out.println("Configured url " + configuredUrlString + " identified as a single dataSet.");
            dataSetUrlStrings.add(configuredUrlString);
        }

        //the netcdf opendap library cannot handle URLs that start with "https", therefore replace
        //"https" with "http". Then when the http connection is made, it will be redirected to
        //the https variant of the URL. This only works if the server is configured to do this redirection.
        for (int n = 0; n < dataSetUrlStrings.size(); n++) {
            if (dataSetUrlStrings.get(n).toLowerCase().startsWith("https")) {
                dataSetUrlStrings.set(n, "http" + dataSetUrlStrings.get(n).substring(5));
            }
        }

        //parse all dataSets in dataSetUrlString list.
        for (String dataSetUrlString : dataSetUrlStrings) {
            URL dataSetUrl;
            try {
                dataSetUrl = new URL(dataSetUrlString);
            } catch (MalformedURLException e) {
                System.err.println("Data set url " + dataSetUrlString + " is not a valid url."
                        + " This url will be skipped. Message was: " + e.getMessage());
                continue;
            }
            data.addAll(parseSingleDataSet(dataSetUrl, username, password));
        }
        return data;
    }

    private ArrayList<VariableDataSet> parseSingleDataSet(URL dataSetUrl, String username, String password) throws IOException {
        String urlString = dataSetUrl.toString();
        ArrayList<VariableDataSet> data = new ArrayList<VariableDataSet>();

        System.out.println("Parsing data from dataSet url: " + urlString);

        //set credentials.
        if (username != null && password != null) {
            setGlobalCredentialsProvider(username, password);
        }

        //open NetcdfFile.
        NetcdfFile netcdfFile = null;
        try {
            netcdfFile = NetcdfDataset.openFile(urlString, null);
            System.out.println("File opened for netcdf import from url: " + urlString);
            data.addAll(parseNetcdfFile(netcdfFile));

        } finally {
            resetGlobalCredentialsProvider();
            if (netcdfFile != null) {
                netcdfFile.close();
            }
        }
        return data;
    }

    private ArrayList<VariableDataSet> parseNetcdfFile(NetcdfFile netcdfFile) throws IOException {
        ArrayList<VariableDataSet> data = new ArrayList<VariableDataSet>();
        for (Variable variable : netcdfFile.getVariables()) {
            if (variable.isCoordinateVariable()) {
                continue;
            }

            if (!variable.getDataType().isNumeric()) {
                System.out.println("Only reading of numeric data is supported. Data in variable "
                        + variable.getFullName() + " in netcdf file " + netcdfFile.getLocation()
                        + " is not numeric. This variable will be skipped.");
                continue;
            }

            VariableDataSet dataSet = readData(variable);
            data.add(dataSet);
        }

        return data;
    }

    private VariableDataSet readData(Variable variable) throws IOException {
        VariableDataSet dataset = null;

        if (variable.getDimensions().isEmpty()) {//if scalar.
            double[] values = new double[]{variable.readScalarDouble()};
            dataset = new VariableDataSet(variable.getFullName(), values);
        } else {//if array.
            double[] values = (double[]) variable.read().get1DJavaArray(double.class);
            dataset = new VariableDataSet(variable.getFullName(), values);
        }
        return dataset;
    }

    /**
     * Recursively get the URLs of all the dataSets in the given list with
     * InvDataSet objects and store these in the returned dataSetUrlStrings
     * list.
     *
     * @param invDataSets
     * @return list with dataSetUrlStrings.
     */
    private ArrayList<String> getDataSetUrlStrings(List<InvDataset> invDataSets) {
        ArrayList<String> dataSetUrlStrings = new ArrayList<String>();

        for (InvDataset invDataset : invDataSets) {
            if (invDataset.hasNestedDatasets()) {//if has nested dataSets.
                //recursion.
                dataSetUrlStrings.addAll(getDataSetUrlStrings(invDataset.getDatasets()));

            } else {//if no nested dataSets.
                //add URL of this dataSet.
                InvAccess invAccess = invDataset.getAccess(ServiceType.OPENDAP);
                if (invAccess == null) {
                    String message = "catalog.xml file ";
                    if (invDataset.getParentCatalog() != null) {
                        message += "'" + invDataset.getParentCatalog().getUriString() + "' ";
                    }
                    message += "contains no opendap service for dataset " + invDataset.getFullName() + ". This dataset will be skipped.";
                    System.err.println(message);
                    continue;
                }

                String standardUrlName = invAccess.getStandardUrlName();
                if (standardUrlName == null) {
                    System.err.println("Standard url name is null for dataset '"
                            + invDataset.getFullName() + "'. This dataset will be skipped.");
                    continue;
                }

                System.out.println("Adding dataSet url from catalog to list with dataSets to parse: " + standardUrlName);
                dataSetUrlStrings.add(standardUrlName);
            }
        }

        return dataSetUrlStrings;
    }

    /**
     * Sets the HTTPSession.setGlobalCredentialsProvider to a provider that
     * provides the given username and password.
     *
     * @param username
     * @param password
     */
    public static void setGlobalCredentialsProvider(final String username, final String password) {
        HTTPSession.setGlobalCredentialsProvider(new CredentialsProvider() {

            @Override
            public Credentials getCredentials(AuthScheme scheme, String host, int port,
                    boolean proxy) throws CredentialsNotAvailableException {
                return new UsernamePasswordCredentials(username, password);
            }
        });
    }

    /**
     * Resets the HTTPSession.setGlobalCredentialsProvider.
     */
    public static void resetGlobalCredentialsProvider() {
        HTTPSession.setGlobalCredentialsProvider(null);
    }

}
