package evs.data;

//Java dependencies
import evs.analysisunits.*;
import java.util.*;

//EVS dependencies
import evs.utilities.*;
import evs.analysisunits.scale.*;
import evs.data.fileio.*;
import evs.utilities.mathutil.*;
import evs.utilities.matrix.*;
import evs.metric.parameters.*;
import evs.metric.metrics.*;

/**
 * Records a set of paired forecasts and observations.  Also allows for a set of
 * climatological observations to be associated with the data.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class PairedData {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLES                              *
     *                                                                              *
     *******************************************************************************/        
    
    /**
     * The raw paired data.
     */
    
    private DoubleMatrix2D pairs = null;
    
    /**
     * The unique observations associated with the pairs.
     */

    private DoubleMatrix2D observations = null;
    
    /**
     * The climatological observations (may be null).
     */

    private DoubleMatrix2D climatology = null;

    /**
     * The unconditional climatological observations (may be null).
     */

    private DoubleMatrix2D uncClimatology = null;
    
    /**
     * Matrix of unique lead times.
     */
    
    private DoubleMatrix1D leadTimes = null;

    /**
     * The null value.
     */
    
    private double nV = -999;
    
    /********************************************************************************
     *                                                                              *
     *                                  CONSTRUCTOR                                 *
     *                                                                              *
     *******************************************************************************/        

    /**
     * Constructs a paired dataset from matrices of observations and forecasts where the
     * first column of each matrix is the time in UTC hours relative to the epoch.  The 
     * second column of each matrix of observations contains the observed values. The 
     * second column of each matrix of forecasts contains the forecast lead time in hours 
     * and the remaining columns contain the ensemble members or the single-valued forecast.  
     * 
     * Uses a sorted map to arrange the rows of the input matrices and then conduct pairing. 
     * A sorted map guarantees log(n) time on the set and get methods.  The paired data 
     * are then stored in a 2D matrix in the following format:
     * 
     * Column 0: the times in hours relative to the epoch
     * Column 1: the forecast lead times in hours relative to the first forecast
     * Column 2: the observation
     * Column 3...n the forecast ensemble members, where each column is a unique series
     * 
     * Specify whether duplicate data, namely those data that maintain the same forecast
     * valid time and lead time, should be removed. For example, when constructing paired data 
     * across several locations, this should be set to false. However, any operation that 
     * requires the data in time series order, such as temporal aggregation, also requires the
     * elimination of duplicate data. Thus, any temporal aggregation should be performed
     * prior to constructing data across several locations.
     *
     * @param forecasts the forecasts
     * @param observations the observations
     * @param eliminateDuplicates is true to eliminate data with the same forecast valid time and lead time
     * @param nV the null value
     */
    
    public PairedData(Vector<DoubleMatrix2D> forecasts,Vector<DoubleMatrix2D> observations, 
            boolean eliminateDuplicates, double nV) throws PairedDataException {
        long start = System.currentTimeMillis();
        this.nV=nV;
        //Construct the full map of observations
        TreeMap<Double,Double> obs = new TreeMap<Double,Double>();
        int obsSize = observations.size();
        //One matrix of observations
        if(obsSize==1) {
            obs = getObservedDataMap(observations.get(0));
        }
        //Two or more matrices
        else {
            for(int i = 0; i < obsSize; i++) {
                obs.putAll(getObservedDataMap(observations.get(i)));
            }
        }

        System.out.println(obs.size()+" observations available for pairing.");
        
        //Iterate through the forecast vector
        int forcSize = forecasts.size();
        Vector<double[]> pairedRows = new Vector<double[]>();  //All of the data
        int totalF = 0;
        int noObs = 0;
        int noFcsts = 0;
        int nullObs = 0;
        int pairPot = 0;
        Vector<Double> missingTimes = new Vector<Double>();
        for(int i = 0; i < forcSize; i++) {
            //Obtain a map of the forecasts
            TreeMap<Double,Vector<double[]>> fMap = getForecastDataMap(forecasts.get(i));
            Iterator it = fMap.keySet().iterator();
            while(it.hasNext()) {
                Object next = it.next();
                Double test = obs.get(next);
                Vector<double[]> append = fMap.get(next);
                int size = append.size();
                totalF+=size;
                //Valid observation available at the forecast time
                if(test != null && test != nV && ! Double.isNaN(test)) {
                    for (int j = 0; j < size; j++) {
                        double[] nxt = append.get(j);
                        //Check that some members are non-null and proceed in that case
                        double[] tst = new double[nxt.length-2];
                        System.arraycopy(nxt, 2, tst, 0, nxt.length - 2);  //Members
                        DoubleMatrix1D tst2 = new DenseDoubleMatrix1D(tst);
                        //Some members are non-null and none are not finite
                        VectorDoubleProcedure p = FunctionLibrary.isAll(FunctionLibrary.isEqual(nV));
                        VectorDoubleProcedure q = FunctionLibrary.isOneOrMore(FunctionLibrary.isNotFinite());
                        if (!p.apply(tst2) && !q.apply(tst2)) { 
                            //Append the rows, observed first
                            double[] result = new double[nxt.length + 1];
                            result[0] = nxt[0];  //Valid time
                            result[1] = nxt[1];  //Lead time
                            result[2] = test;  //Observation
                            System.arraycopy(nxt, 2, result, 3, nxt.length - 2);  //Members
                            //Add to sorted map
                            pairedRows.add(result);
                        }
                        else {
                            noFcsts++;
                        }
                        pairPot+=1;
                    }
                }
                //No valid observation available at the forecast time
                else {
                    missingTimes.add((Double)next);
                    noObs+=size;
                    if(test!=null) {
                        if(test==nV) {
                            nullObs+=1;
                        }
                        pairPot+=1;
                    }
                }
            }
        }
        System.out.println(totalF+" forecasts available for pairing.");
        System.out.println(noObs+" of "+totalF+" forecasts for which contemporary, valid, observations were not available.");
        System.out.println(nullObs+" of the "+pairPot+" observations with contemporary forecasts "
                + "matched the missing value of "+nV+".");
        System.out.println(noFcsts+" forecasts whose members all matched the missing value '"+nV+"' or contained one or more members that were not valid numbers.");
        if(pairedRows.isEmpty()) {
            throw new PairedDataException("No valid observations and forecasts were found at the same times. "
                    + "Check that pairs actually exist and that the time zones are correct.");
        } 
        System.out.println(pairedRows.size()+" pairs created.");
        int stopT = missingTimes.size(); 
        if (stopT > 0) {
            if (stopT > 10) {
                stopT = 10;
            }
            System.out.println("The first " + stopT + " missing observations follow (date/time in UTC):");
            Calendar c = Calendar.getInstance();
            c.setTimeZone(TimeZone.getTimeZone("UTC"));
            StringUtilities.setDateString("yyyyMMddHH");
            for (int i = 0; i < stopT; i++) {
                c.clear();
                long millis = (long) (missingTimes.get(i) * 60 * 60 * 1000);
                c.setTimeInMillis(millis);
                String date = StringUtilities.parseDate(c);
                System.out.println(date);
            }
        }
        //Construct the paired matrix
        double[][] data = new double[pairedRows.size()][];
        for(int i = 0; i < data.length; i++) {            
            data[i] = pairedRows.get(i);
        }

        //Set the unique lead times
        setLeadTimes(data);
        
        if(eliminateDuplicates) {
            System.out.println("Attempting to sort pairs by valid time then lead time.");
            pairs = sortByTraceNew(new DenseDoubleMatrix2D(data),nV);
        } else{
            pairs = new DenseDoubleMatrix2D(data);
        }
        //Must pad with nulls because individual forecast matrices may contain differing column counts
        padWithNulls(pairs,nV);
        //Set the observations associated with the pairs and the default climatology, i.e. paired observations
        this.observations = PairedData.getObservationsWithTimes(pairs);
        climatology = this.observations;
        
        long stop = System.currentTimeMillis();
        double diff = (stop-start)/1000.0;        
        System.out.println("Time taken to pair forecasts and observations: "+diff+" seconds.");
    }

    /**
     * Constructs a paired dataset from matrices of observations and forecasts where the
     * first column of each matrix is the time in UTC hours relative to the epoch.  The 
     * second column of each matrix of observations contains the observed values. The 
     * second column of each matrix of forecasts contains the forecast lead time in hours 
     * and the remaining columns contain the ensemble members or the single-valued forecast.  
     * 
     * Uses a sorted map to arrange the rows of the input matrices and then conduct pairing. 
     * A sorted map guarantees log(n) time on the set and get methods.  The paired data 
     * are then stored in a 2D matrix in the following format:
     * 
     * Column 0: the times in hours relative to the epoch
     * Column 1: the forecast lead times in hours relative to the first forecast
     * Column 2: the observation
     * Column 3...n the forecast ensemble members, where each column is a unique ts
     * 
     * Eliminates any duplicate data (same forecast valid time and lead time).
     *
     * @param forecasts the forecasts
     * @param observations the observations
     * @param nV the null value
     */
    
    public PairedData(Vector<DoubleMatrix2D> forecasts,Vector<DoubleMatrix2D> observations, double nV) throws PairedDataException {
        this(forecasts,observations,true,nV);
    }    
    
    /**
     * Constructs a paired dataset with a 2D matrix where the first column is the time 
     * in UTC hours relative to the epoch, the second column contains the forecast lead time 
     * in hours, the third column contains the observations and the remaining columns contain 
     * the ensemble members or the single-valued forecast.
     *
     * Specify whether duplicate data, namely those data that maintain the same forecast
     * valid time and lead time, should be removed. For example, when constructing paired data 
     * that originate from several locations, this should be set to false. However, any operation that
     * requires the data in time order, such as temporal aggregation, also requires the
     * elimination of duplicate data. Thus, any temporal aggregation should be performed
     * prior to constructing paired data that originate from several locations.
     * 
     * @param pairs the paired dataset
     * @param eliminateDuplicates is true to eliminate data with the same forecast valid time and lead time
     */
    
    public PairedData(DoubleMatrix2D pairs, boolean eliminateDuplicates, double nV) {
        if(eliminateDuplicates) {
            this.pairs = sortByTraceNew(pairs,nV);
        } else {
            this.pairs = (DoubleMatrix2D)pairs; 
        }       
        this.nV = nV;
        setLeadTimes(this.pairs.toArray());
        padWithNulls(pairs,nV);
        this.observations = PairedData.getObservationsWithTimes(pairs);
        climatology = this.observations;        
    }   
    
     /**
     * Constructs a paired dataset with a 2D matrix where the first column is the time 
     * in UTC hours relative to the epoch, the second column contains the forecast lead time 
     * in hours, the third column contains the observations and the remaining columns contain 
     * the ensemble members or the single-valued forecast.
     *
     * Eliminates duplicate data (same forecast valid time and lead time).
     * 
     * @param pairs the paired dataset
     * @param nV the null value
     */
    
    public PairedData(DoubleMatrix2D pairs, double nV) {
        this(pairs,true,nV);        
    }    
    
    /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/        

    /**
     * Returns true if a separate set of unconditional climatological observations
     * is associated with the data, false otherwise.
     *
     * @return true if the unconditional climatological observations have been set
     */

    public boolean hasUncClimObs() {
        return uncClimatology!=null;
    } 

    /**
     * Returns true if the paired data contains the input lead time, false
     * otherwise.
     *
     * @param time the lead time to check
     * @return true if the pairs contains the input lead time, false otherwise
     */

    public boolean hasLeadTime(double time) {
        int rows = leadTimes.getRowCount();
        for(int i = 0; i < rows; i++) {
            if (leadTimes.get(i)==time) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns the raw paired dataset. The first column is the time in UTC hours 
     * relative to the epoch, the second column contains the observations and 
     * the remaining columns contain the ensemble members or the single-valued 
     * forecast.  
     *
     * @return the paired data
     */
    
    public DoubleMatrix2D getPairs() {
        return pairs;
    }

    /**
     * Returns the observations associated with the paired forecasts.  Note that
     * there may be fewer observations than data, since observations may be
     * duplicated across data at different forecast times.
     *
     * @return the observations.
     */

    public DoubleMatrix1D getObservations() {
        return (DoubleMatrix1D)observations.getColumnAt(1);  //JB @5th November  Observations now stored locally
    }
    
    /**
     * Returns the observations associated with the paired forecasts together with
     * the associated times.  Note that there may be fewer observations than data, 
     * since observations may be duplicated across data at different forecast times.
     *
     * @return the observations.
     */

    public DoubleMatrix2D getObservationsWithTimes() {
        return observations;
    }    

    /**
     * Returns any climatological observations associated with the paired forecasts
     * together with their valid times. If separate climatological observations have
     * been registered with the paired data, they are returned, otherwise the paired
     * observations are returned.
     *
     * @return the climatology.
     */

    public DoubleMatrix2D getClimObsWithTimes() {
        return climatology;
    }

    /**
     * Returns any climatological observations associated with the paired forecasts.
     * If separate climatological observations have been registered with the paired
     * data, they are returned, otherwise the paired observations are returned.
     *
     * @return the climatology.
     */

    public DoubleMatrix1D getClimObs() {
        return (DoubleMatrix1D)climatology.getColumnAt(1);
    }

    /**
     * Returns any unconditional climatological observations associated with the
     * paired forecasts together with their valid times or null of no unconditional
     * climatological observations have been defined.  The unconditional 
     * climatological observations are always exactly as read from the observed
     * data input source.
     *
     * @return the unconditional climatology with times.
     */

    public DoubleMatrix2D getUncClimObsWithTimes() {
        return uncClimatology;
    }

    /**
     * Returns any unconditional climatological observations associated with the
     * paired forecasts or null if no unconditional climatological observations
     * have been defined.  The unconditional climatological observations are always 
     * exactly as read from the observed data input source.
     *
     * @return the unconditional climatology.
     */

    public DoubleMatrix1D getUncClimObs() {
        if(uncClimatology!=null) {
            return (DoubleMatrix1D)uncClimatology.getColumnAt(1);
        }
        return null;
    }

    /**
     * Returns a set of forecast/observation data for a specified lead time
     * in hours.  Throws an exception if no data are available.
     *
     * @return a subset of data
     */
    
    public DoubleMatrix2D getPairsByLeadTime(double time) throws IllegalArgumentException {
        return getPairsByLeadTime(pairs,time);
    }
    
    /**
     * Returns the set of lead times for which forecast/observation data are
     * available.  The lead times are in hours relative to the epoch. 
     *
     * @return the available times 
     */
    
    public DoubleMatrix1D getLeadTimes() {
        return (DoubleMatrix1D)leadTimes.deepCopy();
    }
    
    /**
     * Return the first lead time available. 
     * 
     * @return the first lead time available
     */
    
    public double getFirstLeadTime() {
        return leadTimes.get(0);
    }

    /**
     * Returns the number of data at a given lead time.  Access the data themselves
     * and use the instance methods on the returned matrix for other count 
     * information.
     * 
     * @param leadTime the lead time
     * @return the number of data at the specified lead time
     */
    
    public int getPairCount(double leadTime) {
        int rows = pairs.getRowCount();
        int cnt = 0;
        for(int i = 0; i < rows; i++) {
            if(pairs.get(i,1) == leadTime) {
                cnt++;
            }
        }       
        return cnt;
    }
    
    /**
     * Returns the total number of pairs available.
     * 
     * @return the number of pairs
     */

    public int getPairCount() {
        return pairs.getRowCount();
    }
    
    /**
     * Returns a string representation of the receiver.
     *
     * @return a string representation
     */

    public String toString() {
        return pairs.toString();
    }
    
    /**
     * Returns the no data value.
     */
 
    public double getNullValue() {
        return nV;
    }
    
    /**
     * Merges the input data and returns a new pooled dataset. In order to pool
     * data across several locations, set eliminateDuplicates true. This will avoid
     * sorting the data in time order and eliminating data with the same
     * forecast valid time and lead time.
     *
     * @param pairs the input data
     * @param eliminateDuplicates is false to skip time-ordering (e.g. when pooling over locations)
     * @return the merged input
     */
    
    public static PairedData getPooledPairs(PairedData[] pairs, boolean eliminateDuplicates) throws PairedDataException {
        if(pairs == null || pairs.length == 0) {
            throw new IllegalArgumentException("Specify non-null pairs to merge.");
        }
        DenseDoubleMatrix2D result = null;
        DenseDoubleMatrix2D totClimate = null;
        DenseDoubleMatrix2D totUncClimate = null;
        
        double nV = pairs[0].getNullValue();
        for(int i = 0; i < pairs.length; i++) {
            if(pairs[i]==null) {
                throw new PairedDataException("Pooling of pairs failed due to one or more null inputs: "
                        + "ensure that all inputs are non null. Index of first null input: "+i+".'");
            }
            if(result == null) {
                result = (DenseDoubleMatrix2D)pairs[i].getPairs();
            }
            else { 
                    //result = (DenseDoubleMatrix2D)result.appendRowsShallow(data[i].getPairs());
                    result = (DenseDoubleMatrix2D)result.concatenate(pairs[i].getPairs(),DenseDoubleMatrix2D.S);
            }
            //Replace existing null with common null
            DoubleFunction f = FunctionLibrary.chain(FunctionLibrary.assign(nV),
                    FunctionLibrary.isEqual(pairs[i].getNullValue()));
            
            result.assign(f,true);
            //Climate observations
            if (totClimate == null) {
                totClimate = (DenseDoubleMatrix2D) pairs[i].getClimObsWithTimes();
            } else {
                totClimate = (DenseDoubleMatrix2D) totClimate.concatenate(
                        pairs[i].getClimObsWithTimes(), DenseDoubleMatrix2D.S);
            }
            //JB @ 17th December 2012
            //Unconditional climate observations
            if(pairs[i].hasUncClimObs()) {
                if (totUncClimate == null) {
                    totUncClimate = (DenseDoubleMatrix2D) pairs[i].getUncClimObsWithTimes();
                } else {
                    totUncClimate = (DenseDoubleMatrix2D) totUncClimate.concatenate(
                            pairs[i].getUncClimObsWithTimes(), DenseDoubleMatrix2D.S);
                }               
            }
        }
        PairedData pd = new PairedData(result,eliminateDuplicates,nV);
        if(totClimate!=null) {
            pd.setClimObsWithTimes(totClimate);
        }
        if(totUncClimate!=null) {
            pd.setUncClimObsWithTimes(totUncClimate);
        }        
        return pd;
    }

    /**
     * Returns the observations associated with the paired forecasts.  Note that
     * there may be fewer observations than data, since observations may be
     * duplicated across data at different forecast times.
     *
     * @param pairs the input data
     * @return the observations.
     */

    public static DoubleMatrix1D getObservations(DoubleMatrix2D pairs) {
        TreeMap<Double,Double> map = new TreeMap<Double,Double>();
        int tot = pairs.getRowCount();
        for(int i = 0; i < tot; i++) {
            map.put(pairs.get(i,0),pairs.get(i,2));  //Removes duplicate observations
        }
        double[] result = new double[map.size()];
        int nxt = 0;
        for(Iterator i = map.keySet().iterator(); i.hasNext();) {
            result[nxt] = (Double)map.get((Double)i.next());
            nxt++;
        }
        return new DenseDoubleMatrix1D(result);
    }

    /**
     * Returns the observations associated with the paired forecasts together with
     * the valid times.  Note that there may be fewer observations than data, since
     * observations may be duplicated across data at different forecast times.
     *
     * @param pairs the input data
     * @return the observations.
     */

    public static DoubleMatrix2D getObservationsWithTimes(DoubleMatrix2D pairs) {
        TreeMap<Double,double[]> map = new TreeMap<Double,double[]>();
        int tot = pairs.getRowCount();
        for(int i = 0; i < tot; i++) {
            map.put(pairs.get(i,0),new double[]{pairs.get(i,0),pairs.get(i,2)});  //Removes duplicate observations
        }
        double[][] result = new double[map.size()][2];
        int nxt = 0;
        for(Iterator i = map.keySet().iterator(); i.hasNext();) {
            result[nxt] = (double[])map.get((Double)i.next());
            nxt++;
        }
        return new DenseDoubleMatrix2D(result);
    }

    /**
     * Returns a set of forecast/observation data for a specified lead time
     * in hours.  Throws an exception if no data are available.
     *
     * @param pairs the data
     * @param time the lead time
     * @return a subset of data
     */
    
    public static DoubleMatrix2D getPairsByLeadTime(DoubleMatrix2D pairs, double time) throws IllegalArgumentException {
        Vector<double[]> matches = new Vector<double[]>();
        double[][] data = pairs.toArray();
        int count = pairs.getRowCount();
        for(int i = 0; i < count; i++) {
            if(data[i][1] == time) {
                matches.add(data[i]);
            }
        }
        int tot = matches.size();
        if(matches.size()==0) {
            throw new IllegalArgumentException("No pairs available at lead time "+time);
        }
        double[][] returnMe = new double[tot][];        
        for(int i = 0; i < tot; i++) {
            returnMe[i] = matches.get(i);
        }       
        return new DenseDoubleMatrix2D(returnMe);
    }    
    
    /**
     * Returns the individual traces from the input data (the first column must
     * be forecast valid time and the second column forecast lead time).
     * 
     * This method requires sorting the data by time. If the input data contains
     * duplicate data (the same forecast valid time and lead time), they will be
     * eliminated.
     * 
     * @param data the input data
     * @param nV the null value
     * @return the traces
     */
    
    public static DoubleMatrix2D[] getTraces(DoubleMatrix2D data, double nV) {
        DoubleMatrix2D d = sortByTraceNew(data,nV);
        Vector<DoubleMatrix2D> v = new Vector<DoubleMatrix2D>();
        int start = 0;
        int length = d.getRowCount();
        //Break when lead time decreases in consecutive rows
        for(int i = 1; i < length; i++) {
            if(d.get(i,1)<d.get(i-1,1)) {
                v.add((DoubleMatrix2D)d.getSubmatrixByRow(start,i-1));
                start = i;
            }
        }
        //Add the last subsection, which is not included in the loop
        v.add((DoubleMatrix2D)d.getSubmatrixByRow(start,d.getRowCount()-1));
        DoubleMatrix2D[] returnMe = new DoubleMatrix2D[v.size()];
        v.copyInto(returnMe);
        return returnMe;
    }
    
    /**
     * Applies a specified aggregation period and function to an input data set,
     * which must contain forecast valid time in the first column and forecast
     * lead time in the second column (unless areObs is true). For forecasts or
     * paired data, the data are organized by valid time before aggregation.  The required
     * support must be an integer multiple of the data frequency and the required
     * support is checked against the original support to establish eligibility for
     * aggregation. The support may be aggregated with any function if the original
     * support is instantaneous, but only with a total if not instantaneous.  If
     * the data comprise both forecasts and observations, the original support is
     * assumed to apply to bot, i.e. this function should NOT be used for data
     * with variable support; change to a common support first.
     * 
     * By default, the output lead time (for data or forecasts) corresponds to
     * the maximum of the input lead times in an aggregation data block and the
     * valid time also corresponds to the maximum of the input times, but both may
     * be defined.
     * 
     * For data or forecasts, temporal aggregation is performed by time, and
     * hence the paired input will be ordered by time. This process leads to the
     * elimination of any duplicate data (same forecast valid time and lead time).
     * Thus, when performing temporal aggregation across several forecast locations,
     * aggregation must be performed for each location in turn before pooling any
     * paired data.
     * 
     * @param data the input data
     * @param areObs is true if the data only comprise observations
     * @param origS the original support
     * @param reqS the required support
     * @param agg the data aggregation function
     * @param nV the null value
     * @param startRow a zero-based start row integer for each time-series (may be null)
     * @param startTime a start time in hours UTC [0,23] from which to start aggregating each time series (may be null)
     * @param startLeadTime a first lead time in hours from which to start aggregating each time series (may be null)
     * @param validTime a function for aggregating the forecast valid time (if null, maximum is used)
     * @param leadTime a function for aggregating the forecast lead time (if null, maximum is used)
     * @param strictAgg is true to return a missing value if any of the inputs are missing, otherwise aggregate the non-missing data
     * @return the temporally aggregated data
     */
    
    public static DoubleMatrix2D getTimeAggData(DoubleMatrix2D data, boolean areObs,
            TemporalSupport origS, TemporalSupport reqS, VectorFunction agg,
            double nV, Integer startRow, Integer startTime, Double startLeadTime, 
            VectorFunction validTime,VectorFunction leadTime, boolean strictAgg) throws IllegalArgumentException {
        //Check that aggregation is possible
        if(origS == null || reqS == null) {
            throw new IllegalArgumentException("Specify non-null support for both the required and aggregated support.");
        }

        //Equivalent support
        if(origS.equalsOnUnitChange(reqS)) {
            return data;
        }
        if(!Support.canChangeSupport(origS,reqS)) {
            throw new IllegalArgumentException("Cannot aggregate the data support: aggregation requires " +
                    "values of a common attribute in common measurement units. The values may be instantaneous " +
                    "or totals. The aggregated period must be an integer multiple of the non-aggregated periods.");
        }
        //Check the aggregation function
        if(!origS.hasPointSupport()) {
            //Check that the aggregation function is a total
            if(!agg.equals(FunctionLibrary.total())) {
                throw new IllegalArgumentException("When aggregating data that are not instantaneous, the aggregation " +
                        "function, existing support and required support must all be a 'total': other functions are " +
                        "not currently allowed.");
            }
        }
        
        //Get the required support increments
        int resolution = (int)reqS.getAggregationPeriod();
        String resUnits = reqS.getAggregationUnits();
        return getTimeAggData(data,areObs,resolution,resUnits,agg,nV,startRow,
                startTime,startLeadTime,validTime,leadTime,null,strictAgg);
    }   
    
    /**
     * Applies a specified aggregation period and function to an input data set,
     * which must contain forecast valid time in the first column and forecast
     * lead time in the second column (unless areObs is true). For forecasts or
     * paired data, the data are organized by time before aggregation.  If the 
     * input data comprise BOTH forecasts and observations, they are assumed to
     * be in a common support.  If the support is defined, this is checked.  The
     * aggregation function can be anything if the support is instantaneous, but 
     * only a total if not instantaneous.  If the data comprise both forecasts 
     * and observations, the support is assumed to apply to both, i.e. this function 
     * should NOT be used for data with variable support; change to a common 
     * support first.
     *
     * By default, the output lead time (for data or forecasts) corresponds to
     * the maximum of the input lead times in an aggregation data block and the
     * valid time also corresponds to the maximum of the input times, but both
     * may be defined.
     *
     * For data or forecasts, temporal aggregation is performed by time, and
     * hence the paired input will be ordered by time. This process leads to the
     * elimination of any duplicate data (same forecast valid time and lead time).
     * Thus, when performing temporal aggregation across several forecast locations,
     * aggregation must be performed for each location in turn before pooling any
     * paired data.
     *
     * @param data the input data
     * @param areObs is true if the data only comprise observations
     * @param resolution the resolution
     * @param resUnits the resolution units
     * @param agg the data aggregation function
     * @param nV the null value
     * @param startRow a zero-based start row integer for each time-series (may be null)
     * @param startTime a start time in hours UTC [0,23] from which to start aggregating each time series (may be null)
     * @param startLeadTime a first lead time in hours from which to start aggregating each time series (may be null)
     * @param validTime a function for aggregating the forecast valid time (if null, maximum is used)
     * @param leadTime a function for aggregating the forecast lead time (if null, maximum is used)
     * @param support the data support
     * @param strictAgg is true to return a missing value if any of the inputs are missing, otherwise aggregate the non-missing data
     * @return the temporally aggregated data
     */
    
    public static DoubleMatrix2D getTimeAggData(DoubleMatrix2D data, boolean areObs,
            int resolution, String resUnits, VectorFunction agg, double nV, Integer startRow,
            Integer startTime, Double startLeadTime, VectorFunction validTime, VectorFunction leadTime,
            TemporalSupport support, boolean strictAgg) throws IllegalArgumentException {
        if(agg==null) {
            throw new IllegalArgumentException("Specify a non-null aggregation function for temporal aggregation.");
        }
        
        //Check the aggregation function
        if(support != null && !support.hasPointSupport()) {
            System.err.println("WARNING: using aggregation function '"+agg+"' on data that are NOT at the point support. "
                    + "Check that the requested aggregation is meaningful.");
            //Check that the aggregation function is a mean or a total
//            if(!(agg.equals(FunctionLibrary.total())||agg.equals(FunctionLibrary.mean()))) {
//                throw new IllegalArgumentException("When aggregating data that are not instantaneous, the aggregation " +
//                        "function should be a 'total' or a 'mean': other functions are not currently allowed.");
//            }
        }
        if(data == null) {
            throw new IllegalArgumentException("Cannot aggregate null input.");
        }
        if(data.getRowCount()<=1) {
            throw new IllegalArgumentException("Temporal aggregation requires at least two data points.");
        }

        //Determine the number of hours in the aggregated period
        double hourFactor = GlobalUnitsReader.getMilliConversionFactor(resUnits);
        hourFactor = hourFactor / (1000.0 * 60.0 * 60.0);
        hourFactor = hourFactor * resolution;

        Vector<double[]> aggData = new Vector<double[]>();

        //Forecasts or observed data
        if (!areObs) {         
            
            //Store the aggregated data in order of processing
            DoubleMatrix2D[] traces = getTraces(data,nV);
            
            //JB @ 12th December 2012. The hour factor can only be determined from
            //a trace with at least two rows.
            
            //Determine the number of hours between data
            double hourFactor2 = nV;
            for(DoubleMatrix2D t : traces) {
                if(t.getRowCount()>1) {
                    hourFactor2 = t.get(1, 0) - t.get(0, 0);
                    break;
                }
            }
            //Throw exception if hour factor could not be determined
            if(hourFactor2==nV) {
                throw new IllegalArgumentException("Could not determine the frequency of the data for aggregation from the available traces. No traces had more than one row.");
            }
            
            //Same frequency as input
            if(hourFactor2==hourFactor) {
                System.err.println("Requested temporal aggregation of data that are already at the required frequency: [" + hourFactor2 + ", " + hourFactor + "]: skipping aggregation.");
                return data;
            }
            //Throw exception if indivisible 
            else if (hourFactor2 > hourFactor) {
                throw new IllegalArgumentException("Temporal frequency of data is insufficient to aggregate to the required period: [" + hourFactor2 + ", " + hourFactor + "] hours.");
            }
            double div = hourFactor / hourFactor2;
            if (Math.abs(Math.rint(div) - div) > .00000001) {
                throw new IllegalArgumentException("Aggregation of data requires an aggregation period that divides exactly by the frequency of the forecasts ("+hourFactor2+" hours)");
            }
            //Determine the aggregation period in rows
            int aggRows = (int) (hourFactor / hourFactor2);                
            
            Calendar c = Calendar.getInstance();
            c.setTimeZone(TimeZone.getTimeZone("UTC"));
            //Process each trace
            for (int i = 0; i < traces.length; i++) {
                String time = "";
                try {
                    long tm = (long) (traces[i].get(0, 0) * 1000 * 60 * 60);
                    c.setTimeInMillis(tm);
                    time = " with start time " + StringUtilities.parseDate(c,"yyyyMMddHH");
                    aggData.addAll(aggregateSingleTimeSeries(traces[i], areObs, aggRows, 
                            agg, nV, startRow, startTime, startLeadTime, validTime, leadTime,strictAgg));
                } catch (Exception e) {
                    System.out.println("Could not aggregate trace " + (i + 1) + " of " + traces.length
                            + time + ": " + e.getMessage());
                }
            }
        }
        //Observations: single time-series
        else {
            //JB @ 12th December 2012. Use separate determination of hour factor for observations
            //and perform associated checks
            double hourFactor2 = data.get(1, 0) - data.get(0, 0);

            //Same frequency as input
            if(hourFactor2==hourFactor) {
                System.err.println("Requested temporal aggregation of data that are already at the required frequency: [" + hourFactor2 + ", " + hourFactor + "] hours. Skipping aggregation.");
                return data;
            }
            //Throw exception if indivisible 
            else if (hourFactor2 > hourFactor) {
                throw new IllegalArgumentException("Temporal frequency of data is insufficient to aggregate to the required period: [" + hourFactor2 + ", " + hourFactor + "] hours.");
            }
            double div = hourFactor / hourFactor2;
            if (Math.abs(Math.rint(div) - div) > .00000001) {
                throw new IllegalArgumentException("Aggregation of data requires an aggregation period that divides exactly by the frequency of the observations.");
            }
            //Determine the aggregation period in rows
            int aggRows = (int) (hourFactor / hourFactor2);                   
            
            if(startLeadTime!=null) {
                throw new IllegalArgumentException("Cannot specify a first forecast lead time "
                        + "for aggregation when aggregating observed data.");
            }
            aggData = aggregateSingleTimeSeries(data, areObs, aggRows, agg, nV, 
                   startRow, startTime, startLeadTime, validTime, null, strictAgg);
        }
        //Construct the final matrix
        int tot = aggData.size();
        if (tot == 0) {
            throw new IllegalArgumentException("Failed to temporally aggregate input data.");
        }
        double[][] r = new double[tot][];
        for (int i = 0; i < tot; i++) {
            r[i] = aggData.get(i);
        }
        return new DenseDoubleMatrix2D(r);
    }
    
    /**
     * Sorts the input so the output contains data in order of time (i.e. forecast
     * valid time then lead time), and removes duplicates if they exist.  Assumes that
     * the first two columns contain the forecast valid time and lead time, respectively.
     * 
     * This method will eliminate any duplicate rows (same forecast valid time and
     * lead time) from the input.
     *
     * The input may be forecasts or pairs.
     * 
     * @param data the input data
     * @param nV the null value
     * @return the sorted data
     * @deprecated
     */
    
    public static DoubleMatrix2D sortByTraceOld(DoubleMatrix2D data, double nV) {
        long start = System.currentTimeMillis();
        int rows = data.getRowCount();

        //DenseDoubleMatrix2D copy = new DenseDoubleMatrix2D(rows,cols);
        //copy.assign(FunctionLibrary.assign(nV),true);

        //Order by forecast issue time (based on valid time) then lead time
        //Sort data in ts order
        TreeMap<Double, TreeMap<Double, double[]>> pMap = 
                new TreeMap<Double, TreeMap<Double, double[]>>();
        Vector<double[]> duplicates = new Vector<double[]>();  //Store first 10 duplicates
        int dCount = 0;
        int nullCount = 0;
        int newRowCount = 0;
        for (int i = 0; i < rows; i++) {
            double[] row = ((DoubleMatrix1D) data.getRowAt(i)).toArray();
            //Check that the row contains some non-null entries: it may not, since the input may
            //be forecasts rather than paired data
            double[] tst = new double[row.length-2];
            System.arraycopy(row,2,tst,0,tst.length);  //Members
            //Some entries are non-null
            if (!evs.data.fileio.FileIO.isAllMissing(tst, nV)) {  //Re-use code from FileIO
                double validTime = row[0];
                double leadTime = row[1];
                double issueTime = validTime - leadTime;
                if (pMap.containsKey(issueTime)) {
                    TreeMap<Double, double[]> tm = pMap.get(issueTime);
                    if (tm.containsKey(leadTime)) {
                        dCount++;
                        if (duplicates.size() < 10) {
                            duplicates.add(row);
                        }
                    } else {
                        tm.put(leadTime, row);
                        newRowCount++;
                    }

                } else {
                    TreeMap<Double, double[]> t = new TreeMap<Double, double[]>();
                    t.put(leadTime, row);
                    pMap.put(issueTime, t);
                    newRowCount++;
                }
            } else {
                nullCount++;
            }
        }

        //Repopulate matrix
        int nxt = 0;
        double[][] d = new double[newRowCount][];
        for (Iterator i = pMap.keySet().iterator(); i.hasNext();) {
            double nextIssueTime = (Double) i.next();
            TreeMap<Double,double[]> byLead = (TreeMap<Double,double[]>)pMap.get(nextIssueTime);
            for (Iterator k = byLead.keySet().iterator(); k.hasNext();) {
                double lead = (Double)k.next();
                double[] row = (double[])byLead.get(lead);
                d[nxt]=row;
                nxt++;
            }
        }
        //Note that errors can sometimes be printed here in the case of leap-year problems
        //This occurs for some ESP, for example. In that case, the dates read are nonsense.
        if(data.getRowCount()!=nxt) {
            double elim = data.getRowCount()-nxt;
            System.out.println(elim + " of " + data.getRowCount() + " forecasts were eliminated when ordering by trace.");
            System.out.println(nullCount + " of these forecasts comprised ensemble members that all matched the null value: "+nV);
            System.out.println(dCount + " of these forecasts were duplicates (same forecast valid time and lead time)");
            double perc = 100.0 * (elim/data.getRowCount());
            if (dCount > 0) {
                int stopT = dCount;
                if (stopT > 10) {
                    stopT = 10;
                }
                System.out.println("The first " + stopT + " duplicates follow (date/time (UTC), lead time, first data item):");
                Calendar c = Calendar.getInstance();
                c.setTimeZone(TimeZone.getTimeZone("UTC"));
                StringUtilities.setDateString("yyyyMMddHH");
                for (int i = 0; i < stopT; i++) {
                    c.clear();
                    long millis = (long) (duplicates.get(i)[0] * 60 * 60 * 1000);
                    c.setTimeInMillis(millis);
                    String date = StringUtilities.parseDate(c);
                    System.out.println(date + ", " + duplicates.get(i)[1] + ", " + duplicates.get(i)[2]);
                }
            }
            if(perc>5.0) {
                System.out.println("*****************************************************************");
                System.out.println("WARNING: "+perc+"% of data were eliminated when ordering by trace. If the data are pooled " +
                        "across several locations, set the flag to remove duplicates (data with the same valid time and lead time) " +
                        "to FALSE. Proceeding with the reduced dataset.");
                System.out.println("*****************************************************************");
            }
            //throw new IllegalArgumentException("More than one pair contained the same forecast time and lead time, which is not allowed");
        }
        long stop = System.currentTimeMillis();
        double diff = (stop-start)/1000.0;        
        System.out.println("Time taken to sort pairs in trace order: "+diff+" seconds.");        
        return new DenseDoubleMatrix2D(d);
    }        
        
    /**
     * Sorts the input pairs or forecasts so that the output contains data in order 
     * of time (i.e. forecast valid time then lead time), and removes duplicates 
     * if they exist.  Assumes that the first two columns contain the forecast 
     * valid time and lead time, respectively.
     * 
     * This method will eliminate any duplicate rows (same forecast valid time and
     * lead time) from the input.
     *
     * The input may be forecasts or pairs.
     * 
     * @param data the input data
     * @param nV the null value
     * @return the sorted data
     */
    
    public static DoubleMatrix2D sortByTraceNew(DoubleMatrix2D data, double nV) {
        long start = System.currentTimeMillis();
        int rows = data.getRowCount();

        //DenseDoubleMatrix2D copy = new DenseDoubleMatrix2D(rows,cols);
        //copy.assign(FunctionLibrary.assign(nV),true);

        //Order by forecast issue time (based on valid time) then lead time
        //Sort data in ts order
        TreeMap<ForecastTime,double[]> pMap = 
                new TreeMap<ForecastTime, double[]>();
        Vector<double[]> duplicates = new Vector<double[]>();  //Store first 10 duplicates
        int dCount = 0;
        int nullCount = 0;
        for (int i = 0; i < rows; i++) {
            double[] row = ((DoubleMatrix1D) data.getRowAt(i)).toArray();
            //Check that the row contains some non-null entries: it may not, since the input may
            //be forecasts rather than paired data
            double[] tst = new double[row.length-2];
            System.arraycopy(row,2,tst,0,tst.length);  //Members
            DoubleMatrix1D tst2 = new DenseDoubleMatrix1D(tst);
            //Some members are non-null and none are not finite
            VectorDoubleProcedure p = FunctionLibrary.isAll(FunctionLibrary.isEqual(nV));
            VectorDoubleProcedure q = FunctionLibrary.isOneOrMore(FunctionLibrary.isNotFinite());            
            if (!p.apply(tst2) && !q.apply(tst2)) {        
                double validTime = row[0];
                double leadTime = row[1];
                double issueTime = validTime - leadTime;
                ForecastTime f = new ForecastTime(issueTime,leadTime);
                if (pMap.containsKey(f)) {
                        dCount++;
                        if (duplicates.size() < 10) {
                            duplicates.add(row);
                        }
                } else {
                    pMap.put(f,row);
                }
            } else {
                nullCount++;
            }
        }

        //Repopulate matrix
        int nxt = 0;
        double[][] d = new double[pMap.size()][];
        for (Iterator i = pMap.keySet().iterator(); i.hasNext();) {
            ForecastTime nextTime = (ForecastTime) i.next();
            double[] row = (double[])pMap.get(nextTime);
            d[nxt]=row;
            nxt++;
        }
        //Note that errors can sometimes be printed here in the case of leap-year problems
        //This occurs for some ESP, for example. In that case, the dates read are nonsense.
        if(data.getRowCount()!=nxt) {
            double elim = data.getRowCount()-nxt;
            System.out.println(elim + " of " + data.getRowCount() + " forecasts were eliminated when ordering by trace.");
            System.out.println(nullCount + " of these forecasts comprised ensemble members that all matched the missing value '"+nV+"' or contained one or more members that were not valid numbers.");       
            System.out.println(dCount + " of these forecasts were duplicates (same forecast valid time and lead time)");
            double perc = 100.0 * (elim/data.getRowCount());
            if (dCount > 0) {
                int stopT = dCount;
                if (stopT > 10) {
                    stopT = 10;
                }
                System.out.println("The first " + stopT + " duplicates follow (date/time (UTC), lead time, first data item):");
                Calendar c = Calendar.getInstance();
                c.setTimeZone(TimeZone.getTimeZone("UTC"));
                StringUtilities.setDateString("yyyyMMddHH");
                for (int i = 0; i < stopT; i++) {
                    c.clear();
                    long millis = (long) (duplicates.get(i)[0] * 60 * 60 * 1000);
                    c.setTimeInMillis(millis);
                    String date = StringUtilities.parseDate(c);
                    System.out.println(date + ", " + duplicates.get(i)[1] + ", " + duplicates.get(i)[2]);
                }
            }
            if(perc>5.0) {
                System.out.println("*****************************************************************");
                System.out.println("WARNING: "+perc+"% of data were eliminated when ordering by trace. If the data are pooled " +
                        "across several locations, set the flag to remove duplicates (data with the same valid time and lead time) " +
                        "to FALSE. Proceeding with the reduced dataset.");
                System.out.println("*****************************************************************");
            }
            //throw new IllegalArgumentException("More than one pair contained the same forecast time and lead time, which is not allowed");
        }
        long stop = System.currentTimeMillis();
        double diff = (stop-start)/1000.0;        
        System.out.println("Time taken to sort data in trace order: "+diff+" seconds.");  //JB @ 7th May 2013: changed "pairs" to "data"      
        return new DenseDoubleMatrix2D(d);
    }            
    
    /**
     * Returns a reduced set of data comprising only those forecasts whose
     * ensemble members do not include the avoid value (e.g. a null value) or only
     * the observations do not include the avoid value.  Also removes all forecasts
     * for which one or more members return true when tested with Double.isNaN() 
     * and Double.isInfinite(). Specify obs is true to test the observed value only
     * and false to test the forecast member values.
     * 
     * Throws an exception if no data remain.
     * 
     * @param pairs the paired data
     * @param obs is true if the observation should be tested, false to test the forecast members
     * @param avoid a number to avoid
     * @param obsInd the column index that contains the observed value (remaining columns contain forecast members)
     * @return a reduced set of data whose forecast members don't contain the input value
     */
    
    public static DoubleMatrix2D getStrippedPairs(DoubleMatrix2D pairs, boolean obs, final double avoid,int obsInd) throws IllegalArgumentException {
        Vector<double[]> remain = new Vector<double[]>();
        double[][] d = pairs.toArray();
        int rows = d.length;
        int cols = d[0].length;
        //Test observed value
        if (obs) {
            for (int i = 0; i < rows; i++) {
                boolean include = true;
                if (d[i][obsInd] == avoid || 
                        Double.isNaN(d[i][obsInd]) || 
                        Double.isInfinite(d[i][obsInd])) {
                    include = false;
                    break;
                }
                if (include) {
                    remain.add(d[i]);
                }
            }
        } 
        //Test forecast members
        else {
            int ind = (obsInd+1);
            for (int i = 0; i < rows; i++) {
                boolean include = true;
                for (int j = ind; j < cols; j++) {
                    if (d[i][j] == avoid  || 
                        Double.isNaN(d[i][obsInd]) || 
                        Double.isInfinite(d[i][obsInd])) {
                        include = false;
                        break;
                    }
                }
                if (include) {
                    remain.add(d[i]);
                }
            }
        }
        if(remain.isEmpty()) {
            if(obs) {
                throw new IllegalArgumentException("No pairs remain whose observed value was not '"+avoid+"'.");
            } else {
                throw new IllegalArgumentException("No pairs remain for which none of the ensemble members had value '"+avoid+"'.");
            }
        }
        double[][] ret = new double[remain.size()][cols];
        for(int i = 0 ; i < ret.length; i++) {
            ret[i]=remain.get(i);
        }
        return new DenseDoubleMatrix2D(ret);        
    }

    /**
     * Linearly interpolates a set of observations to the specified forecast
     * times using the nearest two observations that contain the forecast valid
     * time (weighted by separation time, i.e. inverse distance weight). If one
     * observation is null or not available, the nearest observation in time is
     * the estimated value at the forecast valid time. The forecasts and
     * observations must be given in hours relative to the epoch in one column.
     * Assumes that no change of support is required (e.g. interpolating 6-hourly
     * accumulated precipitation to 3-hourly time-steps would not make sense
     * without down-scaling to 3-hourly accumulations).
     *
     * Throws an exception if the inputs are null or in an unexpected format.
     *
     * @param forecasts the forecasts
     * @param observations the observations
     * @param nV the null value identifier
     * @return the interpolated observations with times relative to the epoch
     */

    public static DoubleMatrix2D linInterpObsToFcsts(DoubleMatrix2D forecasts,
            DoubleMatrix2D observations, double nV) throws IllegalArgumentException {
        //Get forecast times for which observed estimates are required
        //in ascending order
        TreeMap<Double, Vector<double[]>> fcst = getForecastDataMap(forecasts);
        //Order the observations by valid time
        TreeMap<Double,Double> obs = getObservedDataMap(observations);
        int tot = obs.size();
        double[][] orderedObs = new double[tot][2];
        Iterator it = obs.keySet().iterator();
        for(int i = 0; i < tot; i++) {
            Double key = (Double)it.next();
            orderedObs[i][0]=key;
            orderedObs[i][1]=obs.get(key);
        }
        Double[] times = fcst.keySet().toArray(new Double[fcst.size()]); //Unique, ordered, valid times
        //Iterate through the required times
        int size = times.length;
        double[][] returnMe = new double[times.length][2];
        for(int i = 0 ; i < size; i++) {
            //Find the two nearest observations and associated times
            double[][] next = getNearestObsPair(orderedObs, times[i]);
            returnMe[i][0] = times[i];
            if (next[0][0] == nV) {
                returnMe[i][1] = nV;
            } else {
                //Find the distance in time to each
                double dist1 = Math.abs(next[0][0] - times[i]);
                double dist2 = Math.abs(next[1][0] - times[i]);
                double total = dist1 + dist2;
                double coeff_1 = 1.0 - (dist1 / total);
                double coeff_2 = 1.0 - (dist2 / total);
                double estimate = (coeff_1 * next[0][1]) + (coeff_2 * next[1][1]);
                returnMe[i][1] = estimate;
            }
        }
        return new DenseDoubleMatrix2D(returnMe);
    }

    /**
     * Applies a specified condition to each cell in a specified column and returns
     * only those rows that meet the condition. Throws an exception if no rows
     * meet the condition.  More complex forms of conditioning should be performed
     * with the following classes:
     *
     * evs.analysisunits.DateCondition
     * evs.analysisunits.ValueCondition
     *
     * @param input the input to subset
     * @param condition the condition to test
     * @param col the column in the input matrix to test
     * @param nV a null value to ignore
     * @return only those rows that meet the condition
     */

    public static DoubleMatrix2D subsetPairs(DoubleMatrix2D input,DoubleProcedure condition,int col,double nV) {
        return input.subRowsbyColCond(condition,col,nV);
    }

    /**
     * Applies a specified condition to a specified component of the date and returns
     * only those rows that meet the condition. Throws an exception if no rows
     * meet the condition.  More complex forms of conditioning should be performed
     * with the following classes:
     *
     * evs.analysisunits.DateCondition
     *
     * Care should be taken when requesting periods for which the lower bound of
     * a "between" condition has a numeric value from the Calendar class that is
     * greater than the upper bound (e.g. requesting data that fall between September
     * of one year and March of the next year).  For such cases, apply
     * {@link evs.utilities.mathutil.FunctionLibrary#isNotBetween(double from, double to)}
     * to the inverse of the condition, which is a valid condition.
     *
     * @param input the input to subset
     * @param condition the condition to test
     * @param cal the calendar to use
     * @param field the calendar field (see {@link java.util.Calendar})
     * @return only those rows that meet the condition
     */

    public static DoubleMatrix2D subsetPairsByDate(DoubleMatrix2D input,DoubleProcedure condition,Calendar cal,int field) {
        DoubleMatrix2D copy = (DoubleMatrix2D)input.deepCopy();
        //Append a date column to the copy
        int rows = copy.getRowCount();
        DenseDoubleMatrix2D st = new DenseDoubleMatrix2D(rows,1);
        st=(DenseDoubleMatrix2D)st.concatenate(copy,DenseDoubleMatrix2D.E);
        Calendar calCopy = Calendar.getInstance();
        calCopy.clear();
        calCopy.setTimeZone(cal.getTimeZone());
        
        //Populate new date column with date element
        for(int i = 0; i < rows; i++) {
            long m = (long)(input.get(i,0) * 1000 * 60 * 60);
            calCopy.setTimeInMillis(m);
            st.set(i,0,calCopy.get(field));
            calCopy.clear();
        }
        return (DoubleMatrix2D)st.subRowsbyColCond(condition,0,null)
                .getSubmatrixByColumn(1,st.getColumnCount()-1);
    }

    /**
     * Subsets a paired dataset by the start and end dates of the verification
     * window, as well as the time system of the verification window, specified
     * in the input VU. Returns all pairs between the start and end dates. Does 
     * not assume the input pairs are sorted.
     *
     * @param input the paired data to subset
     * @param vu the verification unit with start and end dates defined
     * @return only those rows that meet the condition
     */

    public static DoubleMatrix2D subsetPairsByDate(DoubleMatrix2D input,
            VerificationUnit vu) {
        if(input==null) {
            throw new IllegalArgumentException("Cannot subset null input data.");
        }
        if(!vu.hasDates()) {
            throw new IllegalArgumentException("Specify non-null dates for subsetting.");
        }
        Calendar start = vu.getStartDate();
        Calendar end = vu.getEndDate();
        SimpleDateCondition simple = new SimpleDateCondition(vu);
        BooleanMatrix1D useMe = simple.apply(input,Condition.PAIRED_DATA);
        Vector<double[]> rowsToUse = new Vector<double[]>();
        int rows = input.getRowCount();
        for(int i = 0; i < rows; i++) {
            if(useMe.get(i)) {
                rowsToUse.add((double[])input.getRowAt(i).getMatrixValues());
            }
        }
        if(rowsToUse.isEmpty()) {
            throw new IllegalArgumentException("No data were found between the "
                    + "specified start and end dates ["+StringUtilities.parseDate(start,"yyyyMMddHH")
                    +","+StringUtilities.parseDate(end,"yyyyMMddHH")+"].");
        }        
        double[][] complete = new double[rowsToUse.size()][];
            for(int i = 0; i < complete.length; i++) {
                complete[i] = rowsToUse.get(i);
            }
        return new DenseDoubleMatrix2D(complete);        
        //Find the hours in UTC
//        double st = start.getTimeInMillis();
//        double en = end.getTimeInMillis();
//        int off = start.getTimeZone().getOffset((long)st);
//        int off2 = end.getTimeZone().getOffset((long)en);
//        st = st + off;
//        en = en + off2;
//        st = st/(1000.0*60.0*60.0);
//        en = en/(1000.0*60.0*60.0);
//        DoubleProcedure bet = FunctionLibrary.isBetween(st,en);
//        int rows = input.getRowCount();
//        for(int i = 0; i < rows; i++) {
//            if(bet.apply(input.get(i,0))) {
//                rowsToUse.add((double[])input.getRowAt(i).getMatrixValues());
//            }
//        }
//        if(rowsToUse.size()==0) {
//            throw new IllegalArgumentException("No data were found between the "
//                    + "specified start and end dates ["+StringUtilities.parseDate(start,"yyyyMMddHH")
//                    +","+StringUtilities.parseDate(end,"yyyyMMddHH")+"].");
//        }        
//        double[][] complete = new double[rowsToUse.size()][];
//            for(int i = 0; i < complete.length; i++) {
//                complete[i] = rowsToUse.get(i);
//            }
//        return new DenseDoubleMatrix2D(complete);
    }    
    
    /**
     * Merges data in an array by calling getMergedData in the sequence of the
     * input. The input sequence is important, as the results from sub-setting
     * by valid time (and possibly lead time) are conducted with respect to the
     * first of two consecutive inputs.
     *
     * @param data the array of data to merge by valid time and possibly lead time
     * @param areObs is true to merge by valid time, false to merge by lead time also
     * @param remObsFromLast is true to remove the third column from all (paired) inputs after the first input, which contains observed data
     * @param order is true to return in order of insertion in the last input, false to use natural ordering
     * @return the merged, contemporary, data
     */

    public static DoubleMatrix2D getMergedData(DoubleMatrix2D[] data, boolean areObs, boolean remObsFromLast,
            boolean order) throws IllegalArgumentException {
        if(data == null) {
            throw new IllegalArgumentException("Expected non-null data as input.");
        }
        DoubleMatrix2D returnMe = data[0];
        for(int i = 1; i < data.length; i++) {
            returnMe = getMergedData(returnMe,data[i],areObs,remObsFromLast,order);
        }
        return returnMe;
    }
    
    /**
     * Merges the first set of data with the second set of data (forecasts, observations
     * or data). Forecast and paired data are merged according to valid time (first column)
     * and lead time (second column).  Observed data are merged according to valid time only.
     * Returns a matrix of data from the first set that contain contemporary data in the
     * second set. The result contains columns of data values, beginning with the
     * first set.  Assumes that any units and missing value identifiers associated
     * with the two sets of data are the same.
     *
     * @param first the first set of data
     * @param second the second set of data
     * @param areObs is true to merge by valid time only, false to merge by lead time also
     * @param remObsFromSec is true to removed the third column from the second (paired) input, which contains observed data
     * @param order is true to return in order of insertion in the second input, false to use natural ordering
     * @return the merged, contemporary, data
     */

    public static DoubleMatrix2D getMergedData(DoubleMatrix2D first,
            DoubleMatrix2D second, boolean areObs, boolean remObsFromSec, boolean order) throws IllegalArgumentException {
        if(first == null || second == null) {
            throw new IllegalArgumentException("Expected non-null data as input.");
        }
        TreeMap<ForecastTime,double[]> data = new TreeMap<ForecastTime,double[]>();
        int rows = first.getRowCount();
        if (areObs) {
            for (int i = 0; i < rows; i++) {
                data.put(new ForecastTime(first.get(i, 0)),
                        (double[]) first.getRowAt(i).getMatrixValues());
            }
        }
        else {
            for (int i = 0; i < rows; i++) {
                data.put(new ForecastTime(first.get(i, 0), first.get(i, 1)),
                        (double[]) first.getRowAt(i).getMatrixValues());
            }
        }
        System.out.println("Found "+data.size()+" rows in the first input dataset" +
                " to pair with corresponding rows in the second input.");
        int rows2 = second.getRowCount();
        Map<ForecastTime,double[]> ret = null;
        if(order) {
            ret = new TreeMap<ForecastTime,double[]>();
        } else {
            ret = new LinkedHashMap<ForecastTime,double[]>();
        }
        for(int i = 0; i < rows2; i++) {
            ForecastTime f = null;
            if(areObs) {
                f = new ForecastTime(second.get(i,0));
            }
            else {
                f = new ForecastTime(second.get(i,0),second.get(i,1));
            }
            if(data.containsKey(f)) {
                double[] start = data.get(f);
                double[] end = (double[])second.getRowAt(i).getMatrixValues();
                int sub = 2;
                if(areObs) {
                    sub = 1;
                }
                if(!areObs && remObsFromSec) {
                    sub = sub+1;
                }
                double[] merge = new double[start.length+end.length-sub];  //Don't repeat valid time and lead
                System.arraycopy(start,0,merge,0,start.length);
                System.arraycopy(end,sub,merge,start.length,end.length-sub);
                ret.put(f,merge);
            }
        }
        System.out.println("Found "+ret.size()+" rows in the second input with " +
                "corresponding rows in the first input.");
        double[][] returnMe = new double[ret.size()][];
        Iterator it = ret.keySet().iterator();
        for(int i = 0; i < returnMe.length; i++) {
            returnMe[i]=ret.get(it.next());
        }
        return new DenseDoubleMatrix2D(returnMe);
    }

    /**
     * Returns a bootstrap sample of the input pairs using the specified bootstrap
     * parameter and paired input. The paired input is stored in a map, with arrays
     * of pairs indexed by forecast type. Each entry of the array comprises a
     * separate forecast location. If multiple locations are present, the pairs
     * may be treated as statistically dependent in space or not. If they are
     * treated as statistically dependent in space, the locations are sampled
     * under a rule of perfect dependence whereby the same forecast date/lead time
     * combinations are sampled from all locations. Otherwise, they are sampled
     * under a rule of perfect independence. Partial statistical dependence is
     * not supported.
     *
     * Currently, each forecast lead time is sampled separately (i.e. assuming
     * independence by lead time). This is reasonable for metrics that are computed
     * by lead time.  All metrics are currently computed by lead time (or for
     * aggregated lead times).  The paired inputs must comprise a constant number
     * of forecast lead times, otherwise an exception is thrown.
     *
     * The input map must comprise a set of main pairs, indexed by identifier
     * {@link ForecastTypeParameter#REGULAR_FORECAST}, otherwise an exception is
     * thrown. Optionally, the input may comprise a reference forecast for each
     * location (i.e. each set of main pairs), indexed by identifier
     * {@link ForecastTypeParameter#REFERENCE_FORECAST}. If the input map comprises
     * an array of reference pairs, there must be as many reference datasets
     * as forecast locations (i.e. as main pair datasets), otherwise an exception
     * will be thrown.  Reference pairs are always bootstrapped under an assumption
     * of perfect dependence with the main pairs.
     *
     * If the input arrays contain only one element (location), the flag for
     * spatial dependence is ignored.
     *
     * When conducting a block bootstrap for dependent pairs (i.e. for locations
     * that are dependent or for pairs from reference forecasts), the returned
     * paired datasets may differ in size from the input datasets. Specifically,
     * only as many blocks will be sampled as implied by the shortest of the
     * input datasets. A warning is printed if the smallest dataset is more than
     * 10% shorter than the longest dataset and skipCheck is false.
     *
     * @param bsInput the bootstrap input pairs indexed by forecast type
     * @param bs the bootstrap parameter object
     * @param spatialDep is true for perfect spatial dependence, false for independence
     * @param skipCheck is true to skip all checks of inputs (e.g. after first sample)
     */

    public static TreeMap<Integer, PairedData[]> getBootstrapSample(TreeMap<Integer, PairedData[]> bsInput,
            BootstrapParameter bs, boolean spatialDep, boolean skipCheck) throws BootstrapException {
        //Check the input
        if (!skipCheck) {
            if (bsInput == null) {
                throw new IllegalArgumentException("Error in bootstrap sampling: "
                        + "the input pairs were null.");
            }
            if (bs == null) {
                throw new IllegalArgumentException("Error in bootstrap sampling: the "
                        + "bootstrap parameter was null.");
            }
            if (!bs.isBootstrap()) {
                throw new IllegalArgumentException("Error in bootstrap sampling: the "
                        + "bootstrap method is set to '" + BootstrapableMetric.NO_BOOTSTRAP_STRING + ".");
            }
            //Check the input pairs.
            if (!bsInput.containsKey(ForecastTypeParameter.REGULAR_FORECAST)) {
                throw new IllegalArgumentException("Error in bootstrap sampling: the "
                        + "input map is missing some of the required pairs.");
            }
        }
        PairedData[] main = bsInput.get(ForecastTypeParameter.REGULAR_FORECAST);
        PairedData[] ref = null;
        PairedData[] mainReturn  = new PairedData[main.length];
        PairedData[] refReturn = null;
        TreeMap<Integer,PairedData[]> tempReturnMe = new TreeMap<Integer,PairedData[]>();
        tempReturnMe.put(ForecastTypeParameter.REGULAR_FORECAST,mainReturn);
        DoubleMatrix1D leadTimes = null;
        //Check the main pairs
        if(skipCheck) {
            leadTimes = main[0].getLeadTimes();
        } else {
            if (main == null || main.length == 0) {
                throw new IllegalArgumentException("Error in bootstrap sampling: the "
                        + "input map is missing some of the required pairs.");
            }
            for (PairedData p : main) {
                if (p == null) {
                    throw new IllegalArgumentException("Error in bootstrap sampling: "
                            + "one or more of the paired inputs are null.");
                }
                DoubleMatrix1D leadCheck = p.getLeadTimes();
                if(leadTimes != null) {
                    if (!leadCheck.hasEquivalentDimensions(leadTimes)
                            || !Arrays.equals(leadCheck.toArray(),leadTimes.toArray())) {
                        throw new IllegalArgumentException("Error in bootstrap sampling: "
                                + "the paired inputs comprise inconsistent lead times.");
                    }
                }
                leadTimes = leadCheck;
            }
        }
        //Check the reference pairs if defined
        if (bsInput.containsKey(ForecastTypeParameter.REFERENCE_FORECAST)) {
            ref = bsInput.get(ForecastTypeParameter.REFERENCE_FORECAST);
            if (!skipCheck) {
                if (ref == null || ref.length == 0) {
                    throw new IllegalArgumentException("Error in bootstrap sampling: the "
                            + "input map is missing some of the required reference pairs.");
                }
                if (ref.length != main.length) {
                    throw new IllegalArgumentException("Error in bootstrap sampling: one set of "
                            + "reference pairs is required for each set of main pairs "
                            + "[" + ref.length + ", " + main.length + "].");
                }
                for (PairedData p : ref) {
                    if (p == null) {
                        throw new IllegalArgumentException("Error in bootstrap sampling: one or more of the "
                                + "reference paired inputs are null.");
                    }
                    DoubleMatrix1D leadCheck = p.getLeadTimes();
                    if (!Arrays.equals(leadCheck.toArray(),leadTimes.toArray())) {
                        throw new IllegalArgumentException("Error in bootstrap sampling: one or more "
                                + "sets of reference pairs comprise lead times that are inconsistent with "
                                + "the main pairs.");
                    }
                }
            }
            refReturn = new PairedData[ref.length];
            tempReturnMe.put(ForecastTypeParameter.REFERENCE_FORECAST,refReturn);
        }
        //Conduct the block bootstrap
        //Note that some preparation is required here, which is repeated for each 
        //new sample, but this is small compared to the time required to derive the
        //bootstrap samples, which is in turn small compared to the time required to
        //compute the metrics.

        //Iterate through the lead times, which are independent, i.e. verified separately
        int times = leadTimes.getRowCount();
        int index = 0; //The index of the next sample
        double bSize = 0;  //Block size in hours
        for (int i = 0; i < times; i++) {
            double nextTime = leadTimes.get(i);
            //Need to do dependent block resampling
            if (spatialDep && main.length > 1) {
                //Check the number of rows available for the current lead time
                //across each location, in case there are large differences
                double minRows = main[0].getPairCount(nextTime);
                double maxRows = minRows;
                for (int j = 1; j < main.length; j++) {
                    double nextM = main[j].getPairCount(nextTime);
                    if (nextM < minRows) {
                        minRows = nextM;
                    }
                    else if(nextM > maxRows) {
                        maxRows = nextM;
                    }
                    if (ref != null) {
                        double nextR = ref[j].getPairCount(nextTime);
                        if (nextR < minRows) {
                            minRows = nextR;
                        }
                        else if(nextR > maxRows) {
                            maxRows = nextR;
                        }
                    }
                }
                if (!skipCheck && minRows < (0.9 * maxRows)) {
                    System.out.println("Warning: when bootstrapping pairs at lead time '" + nextTime + "', "
                            + "the smallest input paired dataset was at least 10% smaller ["+Mathematics.
                            round(100.0-((minRows/maxRows)*100.0),1)+"] than the largest dataset. The block "
                            + "bootstrap sample size will reflect the smaller dataset.");
                }
                //Do the sampling
                int rowsMain = 0;
                DoubleMatrix2D[] leadByLocMain = new DoubleMatrix2D[main.length];
                DoubleMatrix1D[] leadByLocMainTimes = new DoubleMatrix1D[main.length];
                DoubleMatrix1D[] leadByLocRefTimes = null;
                DoubleMatrix2D[] leadByLocRef = null;
                if(ref !=null) {
                    leadByLocRefTimes = new DoubleMatrix1D[ref.length];
                    leadByLocRef = new DoubleMatrix2D[ref.length];
                }
                for (int j = 0; j < main.length; j++) {
                    leadByLocMain[j]=main[j].getPairsByLeadTime(nextTime);
                    leadByLocMainTimes[j]=(DoubleMatrix1D)leadByLocMain[j].getColumnAt(0);
                    if(ref!=null) {
                        leadByLocRef[j]=ref[j].getPairsByLeadTime(nextTime);
                        leadByLocRefTimes[j]=(DoubleMatrix1D)leadByLocRef[j].getColumnAt(0);
                    }
                }
                //Sample rows until the number of rows is at least the data dim, then crop later
                while (rowsMain < minRows) {
                    //New index and block size, retained for all locations
                    index = (int) Math.floor(Math.random() * (minRows - 1));
                    bSize = bs.getRandomBlockSizeInHours();
                    //Find the time at the first location corresponding to the index
                    double time = leadByLocMain[0].get(index,0);
                    //Iterate through the locations and find the index nearest to the time
                    boolean done = false;
                    for (int j = 0; j < main.length; j++) {
                        int ind = getNearestIndexToTime(leadByLocMainTimes[j].toArray(),time,index);  //Specify the starting position
                        double[][] b = getNextBlock(leadByLocMain[j],ind,bSize);
                        //Crop as required
                        if(rowsMain+b.length>minRows) {
                            int allowed = (int)(minRows - rowsMain);
                            double[][] brep = new double[allowed][];
                            for(int k = 0; k < allowed; k++) {
                                brep[k]=b[k];
                            }
                            b=brep;
                        }
                        //Set or append
                        if (b != null && b.length>0) {
                            DoubleMatrix2D mn = new DenseDoubleMatrix2D(b);
                            if (mainReturn[j] == null) {
                                mainReturn[j] = new PairedData(mn,false,main[j].getNullValue());
                            } else {
                                DoubleMatrix2D r = mainReturn[j].getPairs().appendRowsShallow(mn);
                                DoubleFunction f = FunctionLibrary.chain(FunctionLibrary.assign(main[0].getNullValue()),
                                        FunctionLibrary.isEqual(mainReturn[j].getNullValue()));
                                r.assign(f,true);
                                mainReturn[j] = new PairedData(r,false,main[0].getNullValue());
                            }
                            //Increment rows (for first valid block)
                            if(!done) {
                                rowsMain += b.length;
                                done = true;
                            }
                        }
                    }
                    //Sample the reference forecasts: could be a different number of locations
                    if (ref != null) {
                        for (int j = 0; j < ref.length; j++) {
                            int ind = getNearestIndexToTime(leadByLocRefTimes[j].toArray(), time, index);  //Specify the starting position
                            double[][] b = getNextBlock(leadByLocRef[j], ind, bSize);
                            //Set or append
                            if (b != null && b.length > 0) {
                                //Crop as required
                                if (rowsMain + b.length > minRows) {
                                    int allowed = (int) (minRows - rowsMain);
                                    double[][] brep = new double[allowed][];
                                    for (int k = 0; k < allowed; k++) {
                                        brep[k] = b[k];
                                    }
                                    b = brep;
                                }
                                //Set or append
                                DoubleMatrix2D mn = new DenseDoubleMatrix2D(b);
                                if (refReturn[j] == null) {
                                    refReturn[j] = new PairedData(mn,false,ref[j].getNullValue());
                                } else {
                                    DoubleMatrix2D r = refReturn[j].getPairs().appendRowsShallow(mn);
                                    DoubleFunction f = FunctionLibrary.chain(FunctionLibrary.assign(refReturn[0].getNullValue()),
                                        FunctionLibrary.isEqual(refReturn[j].getNullValue()));
                                    r.assign(f, true);
                                    refReturn[j] = new PairedData(r, false, ref[0].getNullValue());
                                }
                            }
                        }
                    }
                }
            }
            //Sample one location or sample multiple locations independently
            else {
                //Iterate through the locations
                for (int j = 0; j < main.length; j++) {
                    //The base pairs for resampling
                    DoubleMatrix2D nextLeadMain = main[j].getPairsByLeadTime(nextTime);
                    DoubleMatrix2D nextLeadRef = null;
                    if(ref!=null) {
                        nextLeadRef = ref[j].getPairsByLeadTime(nextTime);
                    }
                    //Determine the number of rows to sample
                    int rows = nextLeadMain.getRowCount();
                    int rowsMain = 0;

                    //Sample rows until the number of rows is within one random block size
                    Vector<double[][]> blocks = new Vector<double[][]>();
                    Vector<double[][]> refBlocks = new Vector<double[][]>();
                    //Sample rows until the number of rows is at least the data dim, then crop later
                    while(rowsMain<rows) {
                        //New index and block size for each block
                        index = (int) Math.floor(Math.random() * (rows - 1));
                        bSize = bs.getRandomBlockSizeInHours();
                        double[][] b = getNextBlock(nextLeadMain,index,bSize);
                        
                        //Acquire a sample from the main forecast and the corresponding reference 
                        //forecast if available
                        //Note that the block index and size remain the same for the dependent sample
                        //Do not add the main sample until both the main and reference are available
                        if(b!=null) {
                            //Reference forecast requested
                            if(ref!=null) {
                                double[][] br = getNextBlock(nextLeadRef, index, bSize);
                                //Reference forecast successfully sampled, otherwise continue
                                if (br != null) {
                                    blocks.add(b);
                                    refBlocks.add(br);
                                    //Update rows pars
                                    rowsMain+=Math.min(b.length,br.length);
                                }
                            }
                            //No reference forecast requested
                            else {
                                blocks.add(b);
                                //Update rows pars
                                rowsMain+=b.length;
                            }
                        } 
                    }
                    //Construct full matrix for main pairs
                    double[][] mainCon = new double[rows][];
                    int tot = blocks.size();
                    int next = 0;
                    for(int k = 0; k < tot; k++) {
                        double[][] nx = blocks.get(k);
                        for (int m = 0; m < nx.length; m++) {
                            if (next < rows) {
                                mainCon[next] = nx[m];
                                next++;
                            } else {
                                break;
                            }
                        }
                    }
                    //Set or append
                    DoubleMatrix2D mn = new DenseDoubleMatrix2D(mainCon);
                    if(mainReturn[j]==null) {
                        mainReturn[j] = new PairedData(mn,false,main[j].getNullValue());
                    } else {
                        DoubleMatrix2D r = mainReturn[j].getPairs().appendRowsShallow(mn);
                        DoubleFunction f = FunctionLibrary.chain(FunctionLibrary.assign(main[0].getNullValue()),
                                        FunctionLibrary.isEqual(mainReturn[j].getNullValue()));
                        r.assign(f, true);
                        mainReturn[j] = new PairedData(r, false, main[0].getNullValue());
                    }
                    //Construct full matrix for reference pairs
                    if (ref != null) {
                        double[][] refCon = new double[rows][];
                        int totR = refBlocks.size();
                        int nextR = 0;
                        for (int k = 0; k < totR; k++) {
                            double[][] nx = refBlocks.get(k);
                            for (int m = 0; m < nx.length; m++) {
                                if (nextR < rows) {
                                    refCon[nextR] = nx[m];
                                    nextR++;
                                } else {
                                    break;
                                }
                            }
                        }
                        //Set or append
                        DoubleMatrix2D mr = new DenseDoubleMatrix2D(refCon);
                        if (refReturn[j] == null) {
                            refReturn[j] = new PairedData(mr,false,ref[j].getNullValue());
                        } else {
                            DoubleMatrix2D r = refReturn[j].getPairs().appendRowsShallow(mr);
                            DoubleFunction f = FunctionLibrary.chain(FunctionLibrary.assign(refReturn[0].getNullValue()),
                                        FunctionLibrary.isEqual(refReturn[j].getNullValue()));
                            r.assign(f, true);
                            refReturn[j] = new PairedData(r, false, ref[0].getNullValue());
                        }
                    }
                }
            }
        }
        //Construct the final map
        TreeMap<Integer,PairedData[]> returnMe = new TreeMap<Integer,PairedData[]>();
        PairedData[] p = tempReturnMe.get(ForecastTypeParameter.REGULAR_FORECAST);
        returnMe.put(ForecastTypeParameter.REGULAR_FORECAST,p);
        if(tempReturnMe.containsKey(ForecastTypeParameter.REFERENCE_FORECAST)) {
            PairedData[] pr = tempReturnMe.get(ForecastTypeParameter.REFERENCE_FORECAST);
            returnMe.put(ForecastTypeParameter.REFERENCE_FORECAST,pr);
        }
        return returnMe;
    }

    /**
     * Returns the union of lead times in the input.
     *
     * @param pairs the input array of pairs
     * @return the union of lead times
     */

    public static DoubleMatrix1D getUnionOfLeadTimes(PairedData[] pairs) throws IllegalArgumentException {
        if(pairs==null) {
            throw new IllegalArgumentException("Specify a non-null array of input "
                    + "pairs from which to determine the union of lead times.");
        }
        TreeSet<Double> times = new TreeSet<Double>();
        for(PairedData p : pairs) {
            if(p==null) {
                throw new IllegalArgumentException("Specify non-null pairs from which "
                        + "to determine the union of lead times.");
            }
            double[] t = p.getLeadTimes().toArray();
            for(int i = 0; i < t.length; i++) {
                times.add(t[i]);
            }
        }
        double[] rM = new double[times.size()];
        Iterator it = times.iterator();
        int nx = 0;
        while(it.hasNext()) {
            rM[nx]=(Double)it.next();
            nx++;
        }
        return new DenseDoubleMatrix1D(rM);
    }

    /**
     * Splits the input into as many separate matrices as differing number of
     * non-null ensemble members in the input. Specify to return a deep copy.
     * Only ensemble members can have null values, so the input may be forecasts
     * or paired data.
     *
     * @param input the input matrix of forecasts or pairs
     * @param nV the null value identifier
     * @param deepCopy is true to deep copy the result
     */

    public static DoubleMatrix2D[] splitInputByMemberCount(DoubleMatrix2D input,
            double nV, boolean deepCopy) throws IllegalArgumentException {
        if(input==null) {
            throw new IllegalArgumentException("Expected non-null input to be split by member count.");
        }
        TreeMap<Integer, ArrayList<double[]>> byCount = new TreeMap<Integer, ArrayList<double[]>>();
        DoubleMatrix2D d = input;
        if(deepCopy) {
            d = (DoubleMatrix2D)input.deepCopy();
        }
        int rows = input.getRowCount();
        VectorFunction f = FunctionLibrary.countNulls();
        for(int i = 0; i < rows; i++) {
            DoubleMatrix1D dd = (DoubleMatrix1D)d.getRowAt(i);
            int n = (int)f.apply(dd,nV);
            if(byCount.containsKey(n)) {
                byCount.get(n).add(dd.toArray());
            } else{
                ArrayList<double[]> list = new ArrayList<double[]>();
                list.add(dd.toArray());
                byCount.put(n,list);
            }
        }
        //Reconstruct and return the separate datasets
        DoubleMatrix2D[] returnMe = new DoubleMatrix2D[byCount.size()];
        Iterator it = byCount.keySet().iterator();
        int c = 0;
        while(it.hasNext()) {
            ArrayList<double[]> nx = byCount.get(it.next());
            double[][] add = new double[nx.size()][];
            for(int j = 0; j < add.length; j++) {
                add[j]=nx.get(j);
            }
            returnMe[c] = new DenseDoubleMatrix2D(add);
            c++;
        }
        return returnMe;
    }
    
    /**
     * Convenience method that computes a statistic from forecast values when 
     * the paired input comprise more than one forecast per pair.  If not, the
     * input is simply returned.
     *
     * @param forecastStat the forecast statistic
     * @param pairs the paired input
     * @param nV the ignore value
     * @return the processed input
     */
    
    public static DoubleMatrix2D getForecastStatFromPaired(VectorFunction forecastStat,DoubleMatrix2D pairs,
            double nV) {
        if(forecastStat==null) {
            throw new IllegalArgumentException("Specify a valid function for application to the paired data.");
        }
        if(pairs==null) {
            throw new IllegalArgumentException("Specify non-null paired data from which to compute the forecast "
                    + "statistic.");
        }
        if(pairs.getColumnCount()>3) {
            DoubleMatrix1D r = pairs.assignByRow(forecastStat,nV,3,
                    pairs.getColumnCount()-1);
            DoubleMatrix2D returnMe = (DoubleMatrix2D)pairs.getSubmatrixByColumn(0,3);
            int length = pairs.getRowCount();
            for(int i = 0; i < length; i++) {
                returnMe.set(i,3,r.get(i));
            }
            return returnMe;
        }
        else {
            return pairs;
        }
    }    

    /********************************************************************************
     *                                                                              *
     *                               MUTATOR METHODS                                *
     *                                                                              *
     *******************************************************************************/

    /**
     * Allows for a set of climatological observations to be associated with the
     * data. It is assumed that the observations are in the same support as the
     * paired observations.
     *
     * @param climatology the climatology
     */

    public void setClimObsWithTimes(DoubleMatrix2D climatology) {
        this.climatology=climatology;
    }

    /**
     * Allows a set of unconditional climatological observations to be associated
     * with the data in case the main climatological observations were reduced
     * by conditioning or underwent a change of support. It is assumed that the 
     * observations are in the same support as the paired observations.
     *
     * @param uncClimatology the unconditional climatology
     */

    public void setUncClimObsWithTimes(DoubleMatrix2D uncClimatology) {
        this.uncClimatology=uncClimatology;
    }

    /**
     * Pads a matrix with a specified null value to ensure that the matrix is
     * square.
     *
     * @param input the input matrix
     * @param nV the null value
     */

    public static void padWithNulls(DoubleMatrix2D input, double nV) {
        int maxCols = input.getColumnCount();
        double[][] d = input.toArray();
        for(int i = 0; i < d.length; i++) {
            if(d[i].length!=maxCols) {
                double[] c = new double[maxCols];
                Arrays.fill(c,nV);
                System.arraycopy(d[i],0,c,0,d[i].length);
                d[i]=c;
            }
        }
    }

    /**
     * Converts the forecast valid times in the first column of the input matrix
     * to issue times using the forecast lead times in hours from the second column.
     *
     * @param input
     * @param overwrite is true to overwrite the existing times
     * @return a copy of the input with issue times in the first column or a pointer to the overwritten matrix
     */

    public static DoubleMatrix2D validTimesToIssueTimes(DoubleMatrix2D input, boolean overwrite)
            throws IllegalArgumentException {
        if(input== null) {
            throw new IllegalArgumentException("Enter a non-null matrix with which "
                    + "to convert forecast valid times to issue times.");
        }
        if(input.getColumnCount()<3) {  //Must have at least one member
            throw new IllegalArgumentException("Unexpected input for determining forecast "
                    + "issue times from valid times: enter a matrix with at least three columns: "
                    +input.getColumnCount());
        }
        int rows = input.getRowCount();
        DoubleMatrix2D returnMe = input;
        if(!overwrite) {
            returnMe = (DoubleMatrix2D)returnMe.deepCopy();
        }
        for(int i = 0; i < rows; i++) {
            returnMe.set(i,0,returnMe.get(i,0)-returnMe.get(i,1));
        }
        return returnMe;
    }

    /********************************************************************************
     *                                                                              *
     *                               PRIVATE METHODS                                *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Returns a sorted map of 1D double arrays with their corresponding times in hours 
     * UTC relative to the epoch. 
     *
     * @param input the input matrix
     * @return a sorted map of data
     */
    
    private static TreeMap<Double,Vector<double[]>> getForecastDataMap(DoubleMatrix2D input) {
        //Use a map that imposes ordering on hours
        TreeMap<Double, Vector<double[]>> pMap = new TreeMap<Double, Vector<double[]>>();
        int rows = input.getRowCount();
        for (int i = 0; i < rows; i++) {
            DoubleMatrix1D row = (DoubleMatrix1D) input.getRowAt(i);
            double time = row.get(0);
            if (pMap.containsKey(time)) {
                pMap.get(time).add(row.toArray());
            } else {
                Vector<double[]> v = new Vector<double[]>();
                v.add(row.toArray());
                pMap.put(time, v);
            }
        }
        return pMap;
    }
    
    /**
     * Returns a sorted map of 1D double values with their corresponding times in hours 
     * UTC relative to the epoch. 
     *
     * @param input the input matrix
     * @return a sorted map of data
     */
    
    private static TreeMap<Double,Double> getObservedDataMap(DoubleMatrix2D input) {
        //Use a map that imposes ordering on integer hours
        TreeMap<Double,Double> rows = new TreeMap<Double,Double>();
        double[][] next = input.toArray();
        //Determine the column space required
        for(int j = 0; j < next.length; j++) {
            rows.put(next[j][0],next[j][1]);
        }
        return rows;
    }    
    
    /**
     * Sets the unique lead times from an array of paired data.
     *
     * @param data the paired data
     */
    
    private void setLeadTimes(double[][] pairs) {
        int length = pairs.length;
        Vector<Double> uniqueLeads = new Vector<Double>();  //Unique lead times
        for(int i = 0; i < length; i++) {
            double d = pairs[i][1];
            if(!uniqueLeads.contains(d)) {  //Forecast lead time in column 1
                uniqueLeads.add(d);
            }
        }
        Collections.sort(uniqueLeads);
        //Set the unique lead times
        int tot = uniqueLeads.size();
        leadTimes = new DenseDoubleMatrix1D(tot);
        for(int j = 0; j < tot; j++) {
            leadTimes.set(j,uniqueLeads.get(j));
        }
    }

    /**
     * Returns the nearest pair of observations that contain the specified forecast
     * time. If one observation is null or the forecast time falls outside the observed
     * time range, the pair comprises two copies of the nearest observation and
     * associated time.  
     *
     * @param observations the time-ordered observations (earliest to latest)
     * @param time the forecast time
     * @return the nearest pair of observations with times in the first column
     */

    private static double[][] getNearestObsPair(double[][] observations, double time) {
        double[][] returnMe = new double[2][2];
        for(int i = 0; i < observations.length; i++) {
            if(observations[i][0]>time) {
                if(i > 0) {
                    returnMe[0][0]=observations[i-1][0];
                    returnMe[1][0]=observations[i][0];
                    returnMe[0][1]=observations[i-1][1];
                    returnMe[1][1]=observations[i][1];
                }
                //Earlier than first time
                else {
                    returnMe[0][0]=observations[i][0];
                    returnMe[1][0]=observations[i][0];
                    returnMe[0][1]=observations[i][1];
                    returnMe[1][1]=observations[i][1];
                }
                break;
            }
            //Later than last time
            if (i == observations.length - 1) {
                returnMe[0][0] = observations[i][0];
                returnMe[1][0] = observations[i][0];
                returnMe[0][1] = observations[i][1];
                returnMe[1][1] = observations[i][1];
            }
        }
        return returnMe;
    }

    /**
     * Aggregates the input time-series into data blocks with the specified number
     * of rows. Skips all data blocks with missing lead times and throws an 
     * exception if no data blocks could be aggregated or if the input is unexpected.
     * 
     * @param ts the time series (e.g. ensemble trace)
     * @param areObs is true if the data comprise observations only
     * @param aggRows the number of rows to aggregate
     * @param aggFunc the aggregation function
     * @param nV the null value
     * @param startRow a zero-based start row integer in each time-series (may be null)
     * @param startTime a start time in hours UTC [0,23] from which to start aggregating each time series (may be null)
     * @param startLeadTime a first lead time in hours from which to start aggregating each time series (may be null)
     * @param validTime a function for aggregating the forecast valid time (if null, maximum is used)
     * @param leadTime a function for aggregating the forecast lead time (if null, maximum is used)
     * @param strictAgg is true to return a missing value if any of the inputs are missing, otherwise aggregate the non-missing data
     * @return the aggregated time-series
     */
    
    private static Vector<double[]> aggregateSingleTimeSeries(DoubleMatrix2D ts, boolean areObs, 
            int aggRows, VectorFunction aggFunc, double nV, Integer startRow, Integer startTime,
            Double startLeadTime, VectorFunction validTime, VectorFunction leadTime, boolean strictAgg) throws IllegalArgumentException {
        //Transpose of ts (aggregate row-wise)
        int traceRows = ts.getRowCount();
        if(traceRows < aggRows) {
            throw new IllegalArgumentException("Insufficient data to aggregate into blocks of "+aggRows+".");
        }
        int startPos = 0;
        if(startRow != null) {
            if(startRow > (traceRows-aggRows)) {
                throw new IllegalArgumentException("Insufficient data to aggregate into blocks of "+aggRows+" with a start row index of "+startRow+".");
            }
            startPos = startRow;
        }
        if(startTime!=null) {
            if(startTime > 23 || startTime < 0) {
                throw new IllegalArgumentException("Start time for temporal aggregation must fall within [0,23] UTC: "+startTime+".");
            }
            //Find the first time index that meets the condition
            int rows = ts.getRowCount();
            int firstIndex = -1;
            Calendar c = Calendar.getInstance();
            c.setTimeZone(TimeZone.getTimeZone("UTC"));
            for(int i = startPos; i < rows; i++) {
                c.clear();
                c.setTimeInMillis((long)(ts.get(i,0)*3600000));
                int hour  = c.get(Calendar.HOUR_OF_DAY);
                if(hour == startTime) {
                    firstIndex = i; break;
                }
            }
            if(firstIndex==-1) {
                throw new IllegalArgumentException("Could not find any data with start time of "+startTime+" UTC "
                        + "from which to begin temporal aggregation.");
            }
            startPos = firstIndex;
        }
        if(startLeadTime!=null) {
            if(areObs) {
                throw new IllegalArgumentException("Cannot specify a first forecast lead time for aggregation when aggregating observed data.");
            }
            //Find the first time index that meets the condition
            int rows = ts.getRowCount();
            int firstIndex = -1;
            for(int i = startPos; i < rows; i++) {
                double time = ts.get(i,1);
                if(time == startLeadTime) {
                    firstIndex = i; break;
                }
            }
            if(firstIndex==-1) {
                throw new IllegalArgumentException("Could not find any data with a lead time of "+startLeadTime+" hours "
                        + "from which to begin temporal aggregation.");
            }
            startPos = firstIndex;
        }
        
        double[][] d = ts.transpose().toArray();

        String time = "";
        Calendar c = Calendar.getInstance();
        c.clear();
        c.setTimeZone(TimeZone.getTimeZone("UTC"));
        long tm = (long)(ts.get(0,0) * 1000 * 60 * 60);
        c.setTimeInMillis(tm);
        time = StringUtilities.parseDate(c,"yyyyMMddHH");
                
        //Iterate while more blocks are left and aggregate if all lead times are increasing
        //with constant frequency
        int blocks = (int)(((double)ts.getRowCount())/aggRows);
        Vector<double[]> returnMe = new Vector<double[]>();
        VectorFunction vT = validTime;
        VectorFunction lT = leadTime;
        if(vT==null) {
            vT = FunctionLibrary.maximum();
        }
        if(lT==null) {
            lT = FunctionLibrary.maximum();
        }
        //Iterate through the aggregation blocks
        for(int i = 0; i < blocks; i++) {
            //Iterate through the data to aggregate
            int start = i*aggRows+startPos;
            int stop = start+aggRows;
            boolean go = checkBlock(d,start,stop,areObs);
            if(go) {
                double[] agg = new double[d.length];
                VectorFunction aggF = aggFunc;
                //Iterate through the columns (time-series) in the original (now transposed) matrix
                for (int j = 0; j < d.length; j++) {
                    //Valid time for data, forecasts or observations
                    if (j == 0) {
                        aggF = vT;
                    } 
                    //Lead time for data or forecasts (otherwise observations)
                    else if (j == 1) {
                        if(!areObs) {
                            aggF = lT;
                        }
                        else {
                            aggF = aggFunc;
                        }
                    }
                    //Data columns: apply specified function
                    else {
                        aggF = aggFunc;
                    }
                    double val = nV;
                    double[] nx = new double[aggRows];
                    for (int k = 0; k < aggRows; k++) {
                        nx[k] = d[j][start + k];
                        if (strictAgg) {
                            if (nx[k] == nV) {
                                break;
                            } else if (k == (aggRows - 1)) {
                                val = aggF.apply(new DenseDoubleMatrix1D(nx));
                            }
                        }
                        else {
                            val = aggF.apply(new DenseDoubleMatrix1D(nx),nV);
                        }
                    }
//                    //Test
//                    if(j==0) {
//                        System.out.println("Next aggregation block:");
//                        StringUtilities.setDateString("yyyyMMddHH");
//                        double[][] dat = new double[][] {
//                            nx,
//                        };
//                        StringUtilities.printWithDates(0,new DenseDoubleMatrix2D(dat).transpose());
//                    }
                    agg[j] = val;
                }
                returnMe.add(agg);
            } else {
                System.out.println("Skipped data block "+(i+1)+" of "+blocks+" when aggregating time-series with " +
                        "start time "+time+".");
            }
        }
        int skipped = ts.getRowCount()-(blocks * aggRows);
        if(skipped > 0) {
            System.out.println("Skipped last "+skipped+" rows when aggregating time-series with start time "+time+".");
        }
        return returnMe;
    }
    
    /**
     * Checks an aggregation data block for available data between the start and 
     * stop indices and, if the input contains forecasts (areObs=false), checks
     * for valid forecast lead times.  Returns true if the start and stop indices
     * are within range and, where applicable, the lead times are valid. The lead times
     * are valid if strictly increasing by a constant amount between the start index
     * and the stop index minus 1, i.e. in the interval [start,stop).
     * 
     * @param data the input data in column-order (i.e. transpose of the paired data)
     * @param start the start index
     * @param stop the stop index
     * @param areObs is true if the data are observations
     * @return true if the lead times are valid for a specified data block
     */
    
    private static boolean checkBlock(double[][] data, int start, int stop, boolean areObs) {
        //Cannot aggregate
        if(stop>data[0].length) {  //EDIT (Feb. 2011): Changed >= to > as the stop index is defined as [start,stop)
            return false;
        }
        if(stop<=start) {
            return false;
        }
        if (!areObs) {
            if (!areSimulations(data)) {
                //Two lead times: next lead time must be greater
                if (stop == (start + 1)) {
                    return data[1][start + 1] > data[1][start];
                }
                //More than two lead times
                //Lead times must increment in constant positive amount
                double inc = data[1][start + 1] - data[1][start];  //Increment for first two times
                if (inc == 0) {
                    return false;
                }
                int st = start + 2;
                if (st < stop) {
                    for (int i = st; i < stop; i++) {
                        if (Math.abs(data[1][i] - data[1][i - 1] - inc) > .0000000001) {
                            return false;
                        }
                    }
                }
            }
        }
        return true;
    }

    /**
     * Returns true if all values in the second ROW of the input forecasts
     * (i.e. the forecast lead times) are zero, false otherwise.
     *
     * @param transposedForecasts the transposed forecasts
     * @return true if the second column contains only zeros, false otherwise
     */

    private static boolean areSimulations(double[][] transposedForecasts) {
        for(int i = 0; i < transposedForecasts[0].length; i++) {
            if(transposedForecasts[1][i]!=0) {
                return false;
            }
        }
        return true;
    }

    /**
     * Returns an array of pairs surrounding an index in the input matrix whose
     * valid times are within the block centered on the specified index
     * with specified length or null if no such pairs exist.
     *
     * @param input the input matrix to search
     * @return a block of pairs or null if no pairs exist
     */
    
    private static double[][] getNextBlock(DoubleMatrix2D input, int index, double blockSize) {
        double[][] returnMe = null;
        try {
            double halfBlock = 0.5 * blockSize;
            double center = input.get(index, 0);
            double min = center - halfBlock;
            double max = center + halfBlock;
            //Search up
            int rows = input.getRowCount();
            Vector<double[]> st = new Vector<double[]>();
            st.add(((DoubleMatrix1D) input.getRowAt(index)).toArray());
            int start = index + 1;
            for (int i = start; i < rows; i++) {
                if (input.get(i, 0) <= max) {
                    st.add(((DoubleMatrix1D) input.getRowAt(i)).toArray());
                } else {
                    break;
                }
            }
            //Search down
            int start2 = index - 1;
            for (int i = start2; i > -1; i--) {
                if (input.get(i, 0) >= min) {
                    st.add(((DoubleMatrix1D) input.getRowAt(i)).toArray());
                } else {
                    break;
                }
            }
            int size = st.size();
            if (size == 0) {
                return null;
            }
            returnMe = new double[size][];
            for (int i = 0; i < size; i++) {
                returnMe[i] = st.get(i);
            }
        } catch (Exception e) {
            //Do nothing
        }
        return returnMe;
    }

    /**
     * Finds the nearest index in the input array to the specified valid time.
     *
     * @param in the input
     * @param time the time
     * @param start the start index
     */

    private static int getNearestIndexToTime(double[] in, double time, int start) {
        if(in[start]==time) {
            return start;
        }
        return Math.abs(Arrays.binarySearch(in,time));
    }

    /**
     * Test method.
     *
     * @param args command line args
     */ 
     
    public static void main(String[] args) {
  
//        double[][] d = new double[][]{{-999,53,20}};
//        DoubleMatrix2D test = new DenseDoubleMatrix2D(d);
//        DoubleFunction f = FunctionLibrary.chain(FunctionLibrary.assign(-888.0),FunctionLibrary.isEqual(-999.0));
//        System.out.println(test.assign(f,true));
        
        /*java.io.File fc = new java.io.File("D:/HEP_projects/Postprocessing/Data/SREF/Forecasts/MARFC/SREF_FCST_HUNP1_APCP.fcst");
        java.io.File ob = new java.io.File("D:/HEP_projects/Postprocessing/Data/SREF/Observations/MARFC/HUNP1JUN.MAP06.OBS");

        double nV = -999; 

        //Read forecasts and observations
        try {
            DoubleMatrix2D f = evs.data.fileio.ASCIIFileIO.readForecasts(fc,TimeZone.getTimeZone("UTC"),null, null, null);
            DoubleMatrix2D o = evs.data.fileio.OHDFileIO.readObservations(new java.io.File[]{ob},TimeZone.getTimeZone("EST")).get(0);
            PairedData.linInterpObsToFcsts(f,o,nV);
        }
        catch(Exception e) {
            e.printStackTrace();
        }

        
        java.io.File f = new java.io.File("D:/HEP_projects/Ensemble_verification/Test_data/Juniata_precip/huntingdon_06_Precipitation_60th_3optBW_pairs.xml");
        if(!f.exists()) {
            throw new IllegalArgumentException("The specified path '"+f.getAbsolutePath()+"' does not exist.");
        }
        
        evs.data.PairedData pd = null;
        try {
            pd = evs.data.fileio.PairedFileIO.read(f,new IOState());
        }
        catch(Exception e) {
            e.printStackTrace();
        }*/
        
    }    

    /*
     * Replaced with sortByTraceOld() and bug fix and simplification made.
     * 
     * Sorts the input so the output contains data in order of forecast valid
     * time then lead time, and removes duplicates if they exist.  Assumes the
     * first two columns contain the forecast valid time and lead time, respectively.
     * 
     * @param data the input data
     * @return the sorted data
     */
    
    /*public static DoubleMatrix2D sortByValidTimeThenLead(DoubleMatrix2D data) {
        //Must copy and explicitly set values, in case underlying array was 
        //constructed by rows without explicitly allocating array positions
        int rows = data.getRowCount();
        int cols = data.getColumnCount();

        DenseDoubleMatrix2D copy = new DenseDoubleMatrix2D(rows,cols);
        double nV = AnalysisUnit.getNullValue();
        copy.assign(FunctionLibrary.assign(nV),true);

        DoubleMatrix1D leads = (DoubleMatrix1D)data.getColumnAt(1).deepCopy();
        double leadMin = FunctionLibrary.minimum().apply(leads,nV);
        double leadMax = FunctionLibrary.maximum().apply(leads,nV);   
        double[] sortedLeads = leads.toArray();
        Arrays.sort(sortedLeads);
        Double first = null;
        Double second = null;
        for(int i = 0; i < sortedLeads.length; i++) {
            if(sortedLeads[i]!=nV) {
                if(first==null) {
                    first = sortedLeads[i];
                }
                else if(second == null && first!=sortedLeads[i]) {
                    second = sortedLeads[i];
                }
                if(first!=null && second != null) {
                    break;
                }
            }
        }
        double inc = first.doubleValue();
        if(second != null) {
            inc = second - first; 
        }

        //Order by time then lead time
        int nxt = 0;
        //Sort data in ts order
        TreeMap<Double, TreeMap<Double, DoubleMatrix1D>> pMap = new TreeMap();
        for (int i = 0; i < rows; i++) {
            DoubleMatrix1D row = (DoubleMatrix1D) data.getRowAt(i);
            double time = row.get(0);
            double lead = row.get(1);

            if (pMap.containsKey(time)) {
                pMap.get(time).put(lead, row);
            } else {
                TreeMap<Double, DoubleMatrix1D> t = new TreeMap();
                t.put(lead, row);
                pMap.put(time, t);
            }
            //Update bound
            if (lead > leadMax) {
                leadMax = lead;
            }
            if (lead < leadMin) {
                leadMin = lead;
            }
        }
        double totInc = ((leadMax-leadMin)/inc)+1;

        //System.out.println("Minimum lead time found: " + leadMin);
        //System.out.println("Maximum lead time found: " + leadMax);
        //System.out.println("Lead time increment found: " + inc);
        //System.out.println("Number of lead times per ts: " + totInc);

        StringBuffer b = new StringBuffer();
        String nL = System.getProperty("line.separator");
        int stop = 50;
        int curr = 0;

        for (Iterator i = pMap.keySet().iterator(); i.hasNext();) {
            double start = (Double) i.next();
            //Check for all possible ts values up to the max lead time
            for (int j = 0; j < totInc; j++) {
                double nextLead = leadMin + (j * inc);
                double nextTime = start + (j * inc);
                if (pMap.containsKey(nextTime)) {
                    TreeMap<Double, DoubleMatrix1D> nextT = pMap.get(nextTime);
                    if (nextT.containsKey(nextLead)) {
                        double[] row = nextT.remove(nextLead).toArray();
                        for (int k = 0; k < row.length; k++) {
                            try {
                                copy.set(nxt, k, row[k]);
                            } catch (ArrayIndexOutOfBoundsException e) {
                                //Do nothing because copy will have null in place
                                }
                        }
                        nxt++;
                    }
                }
            }
        }
            
        copy = (DenseDoubleMatrix2D) copy.getSubmatrixByRow(0, nxt-1);
        if(data.getRowCount()!=nxt) {
            int elim = data.getRowCount()-nxt;
            System.out.println(elim+" of "+data.getRowCount()+" data were eliminated when ordering the data by ts.");
            //throw new IllegalArgumentException("More than one pair contained the same forecast time and lead time, which is not allowed");
        }        
        return copy;
    }*/

    
}



