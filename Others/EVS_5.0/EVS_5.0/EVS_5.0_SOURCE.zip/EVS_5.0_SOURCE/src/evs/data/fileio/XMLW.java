package evs.data.fileio;

//Apache XMLW writing
import org.apache.ecs.xml.XML;

/**
 * Extends ECS XML element for pretty printing by default.
 * 
 * @author evs@hydrosolved.com
 */

public class XMLW extends XML {
    
/*******************************************************************************
 *                                                                             *
 *                                 CONSTRUCTOR                                 *
 *                                                                             *
 ******************************************************************************/      
    /**
     * Construct element with a string element type.
     * 
     * @param element the element type
     */
    
    public XMLW(String element) {
        super(element);  
    }
      
/*******************************************************************************
 *                                                                             *
 *                               ACCESSOR METHODS                              *
 *                                                                             *
 ******************************************************************************/      
    
    /**
     * Returns true for pretty printing.
     *
     * @return true for pretty printing
     */
    
    public boolean getPrettyPrint() {
        return true;
    }
    
}
