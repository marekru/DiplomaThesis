package evs.data;

//Java dependencies
import java.io.*;
import java.util.*;

//EVS dependencies
import evs.analysisunits.*;
import evs.utilities.StringUtilities;
import evs.utilities.matrix.*;
import evs.data.fileio.*;
import evs.analysisunits.scale.*;
import evs.utilities.mathutil.*;

/**
 * Constructs a file data source for paired data.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public final class PairedDataSource extends FileDataSource {
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLES                              *
     *                                                                              *
     *******************************************************************************/      
    
    /**
     * Percentage progress of the paired data reading.
     */
    
    private static double progress = 0;
    
    /**
     * The I/O state of the paired data source.  This may be used to cancel I/O.
     * 
     * NOTE: Once I/O is canceled, the I/O state must be reset to allow continued
     * I/O, since this is a static variable.
     */
    
    private static final IOState IOSTATE = new IOState();
    
    /********************************************************************************
     *                                                                              *
     *                                  CONSTRUCTOR                                 *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Creates a paired data source with a single file, which cannot be null.
     * 
     * @param data the file data source
     */
    
    public PairedDataSource(final FileDataSource data) {
        super((File)data.getData());
    }
 
    /********************************************************************************
     *                                                                              *
     *                              ACCESSOR METHODS                                *
     *                                                                              *
     *******************************************************************************/    
    
    /**
     * Returns the state of progress for computing and setting pairs, but not for 
     * reading a paired data source.
     *
     * @return the progress
     */
    
    public static int getProgress() {
        return (int)progress;
    }
    
    /**
     * Returns the I/O state, which may be modified.
     * 
     * @return the I/O state
     */
    
    public static IOState getIOState() {
        return IOSTATE;
    }
    
    /**
     * Returns a paired dataset from the source or throws an exception if the source
     * could not be processed.
     * 
     * @param eliminateDuplicates is true to eliminate duplicate pairs
     * @param nV the null value
     */
    
    public PairedData getPairedData(boolean eliminateDuplicates, double nV) throws PairedDataException {
        //Process a file-based data source
        PairedData pairs = null;
        if(data instanceof File) {
            Timer t = new Timer();
            try {
                //Monitor progress
                TimerTask task = new TimerTask() {
                    public void run() {
                        progress = PairedFileIO.getProgress();
                        if(progress>=100) {
                            cancel();
                        }
                    }
                };
                t.scheduleAtFixedRate(task, 0, 100);
                pairs = PairedFileIO.read((File)data,IOSTATE,eliminateDuplicates,nV);
            }
            catch(Exception e) {
                throw new PairedDataException(" "+e.getMessage());
            }
            finally {
                t.cancel();
            }
        }
        if(pairs == null) {
            throw new PairedDataException("Unable to process the paired data source.");
        }
        progress = 100.0;
        return pairs;
    }

    /********************************************************************************
     *                                                                              *
     *                               MUTATOR METHODS                                *
     *                                                                              *
     *******************************************************************************/     
    
    /**
     * Removes the underlying data source, and returns true if successful.
     *
     * @return true if successful, false otherwise
     */
    
    public boolean delete() {
        return ((File)data).delete();
    }
    
    /**
     * Convenience method for setting pairs for a set of verification units.
     * Reads the predefined forecasts and observations from a set of verification
     * units or a predefined paired data source if it exists and sets the paired dataset.  
     * In addition, if a paired data source does not exist, a new paired data
     * source is written to file and registered with the unit.  Throws an exception 
     * if no sources have been defined, if the sources cannot not be read properly, 
     * if the pairing fails or if the writing of the paired file fails.
     * 
     * @param units the units for which pairs should be computed
     * @return the pairs that have been set, for convenience (some may be null)
     */
    
    public static PairedData[] computeAndSetPairs(VerificationUnit[] units) throws IllegalArgumentException, IOException {
        if(units == null || units.length == 0) {
            throw new IllegalArgumentException("Specify non-null input to compute the pairs.");
        }
        //Iterate through the units and set the paired data 
        progress = 0;
        PairedData[] paired = new PairedData[units.length];
        //Continue while I/O is required
        if (IOSTATE.getIOState()) {
            StringUtilities.setDateString("yyyyMMddHH");
            for (int i = 0; i < units.length; i++) {
                VerificationUnit vu = units[i];

                //Check that a change of support is possible
                TemporalSupport fS = (TemporalSupport) vu.getSupport(Support.FORECAST_SUPPORT);
                TemporalSupport oS = (TemporalSupport) vu.getSupport(Support.OBSERVED_SUPPORT);
                if ((fS != null && oS != null) && !fS.equals(oS)) {
                    if (!(TemporalSupport.canChangeSupport(fS, oS) || TemporalSupport.canChangeSupport(oS, fS))) {
                        throw new IllegalArgumentException("The forecasts and observations are on different support "
                                + "and the requested change of support is not allowed.");
                    }
                }

                //If aggregation required, check that support is set
                //JB @ 27th May 2013  
                //Check that aggregation is possible
                if (vu.hasResolution() && !vu.hasSupport(Support.ALL_SUPPORT)) {
                    throw new ConditioningException("Cannot compute aggregated pairs for unit '" + vu + "': cannot apply an aggregation period without knowing the scale of the "
                            + "forecasts and observations. Set the scale of the forecasts and observations or remove the aggregation period.");
                }

                //Check output directory
                if (!vu.hasOutputData() || !(((File) vu.getOutputData().getData()).canRead())) {
                    throw new IllegalArgumentException("Specify a valid output data location for unit '" + vu + "': " + vu.getOutputData());
                }

                //Read data
                if (!vu.hasPairedDataSource() || !vu.getPairedDataSource().canRead()) {
                    System.out.println("No valid paired data source found for unit '" + units[i] + "'.  Will attempt to compute pairs and write data source....");
                    if (!vu.hasForecastData() && vu.getForecastData() instanceof FileArrayDataSource) {
                        throw new IllegalArgumentException("Error reading files for '" + vu + "': specify one or more source files for the forecasts.");
                    }
                    if (!vu.hasObservedData() && vu.getForecastData() instanceof FileDataSource) {
                        throw new IllegalArgumentException("Error reading files for '" + vu + "': specify a source file for the observations.");
                    }
                    Double min = null;
                    Double max = null;
                    if (vu.hasLeadTimes()) {
                        //Compute the number of milliseconds equivalent of the units
                        double hourFactor = GlobalUnitsReader.getMilliConversionFactor(vu.getForecastLeadTimeUnits());
                        //Convert to hours i.e. number of hours per unit
                        hourFactor = hourFactor / (1000.0 * 60.0 * 60.0);
                        //Multiply by number of units
                        min = new Double(hourFactor * vu.getFirstLeadTime());
                        max = new Double(hourFactor * vu.getLastLeadTime());
                    }

                    DataSource d = vu.getForecastData();
                    File[] forc = null;
                    if (d instanceof FileDataSource) {
                        //Directory
                        if (((File) d.getData()).isDirectory()) {
                            forc = ((File) d.getData()).listFiles();
                        } //Single file
                        else {
                            forc = new File[]{(File) d.getData()};
                        }
                    } else if (d instanceof FileArrayDataSource) {
                        forc = (File[]) d.getData();
                    }

                    //Assign progress evenly between units and 90% to reading the forecasts
                    int fTotal = forc.length;
                    double subProg = 100.0 / units.length;
                    double prop = 1.0 / fTotal;
                    double inc = subProg * prop * 0.9;

                    //Reads data for a single VU: could also collect together all VUs first and read at once
                    
                    //For some file types (e.g. PI-XML), the location and variable IDs may be separate from
                    //the VU location and variable IDs
                    String fLocID = vu.getLocationID();
                    String oLocID = vu.getLocationID();
                    String fVarID = vu.getVariableID();
                    String oVarID = vu.getVariableID();
                    //Set forecast and observed IDs if defined explicitly
                    if(vu.hasForecastFileLocationID()) {
                        fLocID = vu.getForecastFileLocationID();
                    }
                    if(vu.hasForecastFileVariableID()) {
                        fVarID = vu.getForecastFileVariableID();
                    }
                    if(vu.hasObservedFileLocationID()) {
                        oLocID = vu.getObservedFileLocationID();
                    }
                    if(vu.hasObservedFileVariableID()) {
                        oVarID = vu.getObservedFileVariableID();
                    }
                    VUIdentifier fVID = new VUIdentifier(fLocID,fVarID);
                    Vector<VUIdentifier> fvv = new Vector<VUIdentifier>();
                    fvv.add(fVID);
                    VUIdentifier oVID = new VUIdentifier(oLocID,oVarID);
                    Vector<VUIdentifier> ovv = new Vector<VUIdentifier>();
                    ovv.add(oVID);                    
                    
                    Vector<DoubleMatrix2D> v1 = new Vector<DoubleMatrix2D>();
                    Vector<DoubleMatrix2D> v2 = null;
                    
                    //Change of support occurred?
                    boolean supportChanged = false;
                    //Raw pairs are aggregated pairs?
                    boolean rawAggregated = false;

                    //Build constraints on reading paired data
                    //The dates here may be updated in future to be specific to the paired data and not
                    //to the verification time window
                    LeadTimeCondition lead =  new LeadTimeCondition(vu);
                    SimpleDateCondition date = new SimpleDateCondition(vu);
                    ArrayList<Condition> oList = new ArrayList<Condition>();
                    ArrayList<Condition> fList = new ArrayList<Condition>();
                    oList.add(date);
                    fList.add(date);
                    fList.add(lead);
                    ConditionArray obsConditions = new ConditionArray(oList);
                    ConditionArray forcConditions = new ConditionArray(fList);
                    
                    //Read observations                  
                    File obs = (File) vu.getObservedData().getData();
                    switch(vu.getObservedFileType()) {
                        case FileIO.PIXML: v2 = new PublishedInterfaceXMLIO(new File[]{obs},
                        		ovv,vu.getObservedTimeSystem(),false,obsConditions).getData(oVID); break;
                        case FileIO.NETCDF: v2 = new NetCDFFileIO(new File[]{obs},
                        		ovv,vu.getObservedTimeSystem(),false,obsConditions).getData(oVID); break;    
                        case FileIO.NWSCARD: v2 = OHDFileIO.readObservations(new File[]{obs}, 
                        		vu.getObservedTimeSystem(),
                                FileIO.NWSCARD,obsConditions,vu.getNullValue()); break;
                        case FileIO.NWSBIN: v2 = OHDFileIO.readObservations(new File[]{obs}, 
                        		vu.getObservedTimeSystem(),
                                FileIO.NWSBIN,obsConditions,vu.getNullValue()); break;
                        case FileIO.ASCII: {
                            v2 = ASCIIFileIO.readObservations(new File[]{obs},vu.getObservedTimeSystem(),
                                vu.getObsDateFormat(),", \t\n\r\f",obsConditions);
                        };
                        break;
                        default:
                            System.out.println("File '" + obs + "' is not a recognized file type and was not read.");
                    }
                    
                    //Aggregate observations for storage if storing raw pairs in aggregated resolution    
                    //JB @ 14th November 2012  
                    if (vu.willAggregatePairs() && vu.isStoreRawPairsInAggregatedRes()) {
                        System.out.println("WARNING: storing pairs in aggregated resolution. Performing "
                                + "aggregation of observations and forecasts for pairing.");
                        DoubleMatrix2D obsD = v2.get(0);
                        obsD = PairedData.getTimeAggData(obsD, true, vu.getResolution(),
                            vu.getResolutionUnits(), vu.getTemporalAggFunc(), vu.getNullValue(), null,
                            vu.getAggregationStartHourUTC(), vu.getAggregationStartLeadHour(), null, null, 
                            (TemporalSupport) vu.getSupport(Support.OBSERVED_SUPPORT),vu.isStrictAgg());
                        v2.clear();
                        v2.add(obsD);
                        rawAggregated = true;  //No need to set again for forecasts, as applies to both
                        supportChanged = true;
                    }
                    
                    //Read forecasts
                    PublishedInterfaceXMLIO fXMLIO = new PublishedInterfaceXMLIO();
                    NetCDFFileIO fNETIO = new NetCDFFileIO();
                    for (int g = 0; g < fTotal; g++) {
                        if(!IOSTATE.getIOState()) {
                            throw new IOException("Cancelled pairing process.");
                        }
                        try {
                            Vector<DoubleMatrix2D> addMe = null;
                            switch (vu.getForecastFileType()) {
                                case FileIO.PIXML: {
                                    fXMLIO.clearDataStore();  //Empty store JB@14th November 2012
                                    fXMLIO.read(forc[g], fvv, vu.getForecastTimeSystem(), true, forcConditions);
                                    addMe = fXMLIO.getData(fVID);
                                } 
                                break;
                                case FileIO.NETCDF: {
                                    fNETIO.clearDataStore();  //Empty store JB@14th November 2012
                                    fNETIO.read(forc[g], fvv, vu.getForecastTimeSystem(), true, forcConditions);
                                    addMe = fNETIO.getData(fVID);
                                }
                                break;
                                case FileIO.NWSBIN:
                                    addMe = OHDFileIO.readForecasts(new File[]{forc[g]},
                                            vu.getForecastTimeSystem(), forcConditions, FileIO.NWSBIN, vu.getNullValue());
                                    break;
                                case FileIO.NWSCARD:
                                    addMe = OHDFileIO.readForecasts(new File[]{forc[g]},
                                            vu.getForecastTimeSystem(), forcConditions, FileIO.NWSCARD, vu.getNullValue());
                                    break;
                                case FileIO.ASCII: {
                                    String valDelims = ", \t\n\r\f";
                                    addMe = ASCIIFileIO.readForecasts(new File[]{forc[g]}, vu.getForecastTimeSystem(),
                                            vu.getForcDateFormat(), valDelims, forcConditions, vu.getNullValue());                                 
                                }
                                break;
                                default:
                                    System.out.println("File '" + forc[g] + "' is not a recognized file type and was not read.");
                                    break;
                            }
                            //Aggregate forecasts for storage if storing raw pairs in aggregated resolution    
                            //JB@14th November 2012  
                            if (vu.willAggregatePairs() && vu.isStoreRawPairsInAggregatedRes()) {
                                int tot = addMe.size();
                                for (int k = 0; k < tot; k++) {
                                    DoubleMatrix2D nx = addMe.get(k);
                                    nx = PairedData.getTimeAggData(nx, false, vu.getResolution(),
                                            vu.getResolutionUnits(), vu.getTemporalAggFunc(), vu.getNullValue(), null,
                                            vu.getAggregationStartHourUTC(), vu.getAggregationStartLeadHour(), null, null,
                                            (TemporalSupport) vu.getSupport(Support.FORECAST_SUPPORT),
                                            vu.isStrictAgg());
                                    addMe.set(k, nx);
                                }
                            }
                            //Add data just read
                            v1.addAll(addMe);
                        } 
                        //Catch any exception based purely on the file data not meeting constraints and print a message
                        catch (ConditioningException e) {
                            System.err.println("Skipping file '" + forc[g] + "', as none of the data met the conditions imposed: " + e.getMessage());
                        }
                        progress += inc;
                    }
                    
                    progress += (subProg * 0.1);

                    if (v1.isEmpty()) {
                        throw new IOException("No forecast data were read from file.");
                    }
                    if (v2==null || v2.isEmpty()) {
                        throw new IOException("No observed data were read from file.");
                    }

                    //Conduct any change-of-support on forecasts or observations so that pairing is possible
                    //Only perform if aggregation was not already performed above. Aggregation is performed above, when
                    //reading individual files, if aggregation is required and the raw pairs are not stored in their native
                    //resolution
                    //Currently the change of support options are very limited.
                    if (fS != null && oS != null && !fS.equalsAggregation(oS) && !rawAggregated) {
                        //Aggregate observations
                        if(Support.canChangeSupport(oS,fS)) {
                            supportChanged = true;
                            //Attempt to aggregate the observations
                            System.out.println();
                            System.out.println("*****AGGREGATING OBSERVATIONS TO FORECAST SUPPORT*****");
                            System.out.println();
                            System.out.println("Observed support:");
                            System.out.println(oS);
                            System.out.println("Forecast support:");
                            System.out.println(fS);
                            System.out.println("******************************************************");
                            System.out.println();
                            int tot = v2.size();
                            Vector<DoubleMatrix2D> v3 = new Vector<DoubleMatrix2D>();
                            //Currently only one observed file can be selected, but retain loop for future update
                            for (int j = 0; j < tot; j++) {
                                System.out.println("Aggregating observations from file: "+obs);
                                try {
                                    VectorFunction f = FunctionLibrary.mean();
                                    if (fS.getAggregationFunction().equalsIgnoreCase("total")) {
                                        f = FunctionLibrary.total();
                                    }
                                    v3.add(PairedData.getTimeAggData(v2.get(j), true, oS, fS, f,
                                            units[i].getNullValue(),null,
                                            vu.getAggregationStartHourUTC(),null,null,null,vu.isStrictAgg()));
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    System.out.println("Could not aggregate observations from file: " + obs);
                                }
                            }
                            v2 = v3;
                        }
                        else if (Support.canChangeSupport(fS,oS)) {
                            supportChanged = true;
                            System.out.println();
                            System.out.println("*****AGGREGATING FORECASTS TO OBSERVED SUPPORT*****");
                            System.out.println();
                            System.out.println("Forecast support:");
                            System.out.println(fS);
                            System.out.println("Observed support:");
                            System.out.println(oS);
                            System.out.println("***************************************************");
                            System.out.println();
                            //Attempt to aggregate the forecasts
                            //Note that additional options may have been set for aggregation in the VU.
                            //These should be used when calling PairedData.getTimeAggData below
                            int tot = v1.size();
                            Vector<DoubleMatrix2D> v3 = new Vector<DoubleMatrix2D>();
                            for (int j = 0; j < tot; j++) {
                                System.out.println("Aggregating forecasts from file: "+forc[j]);
                                try {
                                    VectorFunction f = null;
                                    if (oS.getAggregationFunction().equalsIgnoreCase("total")) {
                                        f = FunctionLibrary.total();
                                    } else if(oS.getAggregationFunction().equalsIgnoreCase("mean")) {
                                        f = FunctionLibrary.mean();
                                    } else {
                                        throw new IllegalArgumentException("Expected function 'TOTAL' or 'MEAN' to aggregate "
                                                + "forecasts. Actual function: '"+oS.getAggregationFunction()+"'.");
                                    }
                                    v3.add(PairedData.getTimeAggData(v1.get(j), false, fS, oS, f, 
                                            units[i].getNullValue(), null,
                                            vu.getAggregationStartHourUTC(),vu.getAggregationStartLeadHour(),
                                            null,null,vu.isStrictAgg()));
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    System.out.println("Could not aggregate forecasts from file: " + forc[j]);
                                }
                            }
                            v1 = v3;
                        } else {
                            throw new IllegalArgumentException("Support of observations and forecast differs and " +
                                    "the difference cannot be accomodated by an existing change of support function: " +
                                    "see the user's manual for change of support options.");
                        }
                    }
                    
                    PairedData pairs = null;
                    try {
                        pairs = new PairedData(v1, v2, vu.isEliminateDuplicates(),vu.getNullValue());
                    } catch(PairedDataException e) {
                        if(supportChanged) {
                            System.out.println("The pairs could not be constructed following a change of support.  "
                                    + "This can occur for several reasons, including a forecast cycle (e.g. daily cycle) "
                                    + "that is not synchronized with the observed cycle.  When aggregating data, the forecasts "
                                    + "and observations are processed separately from the start of record of each "
                                    + "dataset before conducting any pairing.  Thus, skipping some forecasts at the "
                                    + "start of the record may bring the observed and forecast times into synchronicity if "
                                    + "this is the source of the problem.");
                            if (v1.size() > 0 && v2.size() > 0) {
                                try {
                                    int v1Size = v1.get(0).getRowCount() - 1;
                                    int v2Size = v2.get(0).getRowCount() - 1;
                                    if (v1Size > 9) {
                                        v1Size = 9;
                                    }
                                    if (v2Size > 9) {
                                        v2Size = 9;
                                    }
                                    System.out.println("The first " + (v1Size + 1) + " aggregated forecasts and " + (v2Size + 1) + " "
                                            + "aggregated observations follow (in UTC).");
                                    System.out.println();
                                    System.out.println("Forecasts:");
                                    StringUtilities.printWithDates(0, (DoubleMatrix2D) v1.get(0).getSubmatrixByRow(0, v1Size));
                                    System.out.println();
                                    System.out.println("Observations:");
                                    StringUtilities.printWithDates(0, (DoubleMatrix2D) v2.get(0).getSubmatrixByRow(0, v2Size));
                                } catch (Exception f) {
                                    f.printStackTrace();
                                }
                            }
                        }
                        throw e;
                    }
                    paired[i]=pairs;
                    String root = "";
                    if (vu.getOutputData() instanceof FileDataSource) {
                        root = vu.getOutputData().toString();
                    }
                    String pre = StringUtilities.processFileName(vu.toString());
                    String name = pre + "_pairs_raw.xml";
                    name = StringUtilities.removeWhiteSpace(name, "_");
                    File out = new File(root, name);
                    //Write the new pairs to file and set the link in the verification unit
                    //for current use
                    if(vu.isWriteUnconditionalPairs()) {
                        PairedFileIO.write(out, pairs, vu.isStripNullMembers(), vu.getPairPrecision(),
                            PairedDataSource.getIOState(),vu.getNullValue());
                        System.out.println("Paired data written to file '" + out + "'.");
                    }
                    vu.setPairedDataSource(new PairedDataSource(new FileDataSource(out)));
                    
                    if(vu.isUseFullClimatology()) {
                        DoubleMatrix2D fullClimate = getAppendObservations(v2);
                        //No further aggregation needed if rawAggregated=true, since this is done above.
                        //Set unconditional climatology in same support if raw pairs are stored as aggregated data
                        pairs.setClimObsWithTimes(fullClimate);
                        pairs.setUncClimObsWithTimes(fullClimate);
                    }
                }
            }
        }
        return paired;
    }

    /**
     * Sets the climatological observations for an existing paired dataset if
     * they have been requested and do not exist. Currently this method sets 
     * both the climatological observations and the unconditional climatological
     * observations using the same input data source, i.e. by supplying the same
     * data to:
     * 
     * {@link evs.data.PairedData#setClimObsWithTimes(evs.utilities.matrix.DoubleMatrix2D)}
     * {@link evs.data.PairedData#setUncClimObsWithTimes(evs.utilities.matrix.DoubleMatrix2D)}
     * 
     * In future, these may be set differently to allow combinations of:
     * 
     * - An extended set of climatological observations from file
     * - An unconditional set of climatological observations
     * 
     * Currently, there is no distinction, and the unconditional climatological 
     * observations come from the extended period on file. Similarly, the only way
     * to use conditional observations is to not determine the climatological 
     * observations separately, i.e. there will be no unconditional climate observations
     * or separate climate observations under the paired data. However, also see
     * {@link evs.analysisunits.VerificationUnit#getConditionedPairs(boolean)}
     * for the exact approach to using conditional climatology. 
     * 
     * In keeping with {@link PairedDataSource#computeAndSetPairs(evs.analysisunits.VerificationUnit[])},
     * a change of support is applied to the observations only insofar as required for pairing. For example,
     * no change of measurement units is applied.
     * 
     * @param vu the verification unit
     * @param pairs the pairs
     * @param climatology the climatological data source
     */

    public static void readAndSetClimatology(VerificationUnit vu, PairedData pairs, DataSource climatology) throws IllegalArgumentException, IOException {
        if(pairs == null || climatology == null) {
            throw new IllegalArgumentException("Specify non-null input for setting the climatology.");
        }

        //Read data
        Object dt = climatology.getData();
        if (dt != null && (dt instanceof File) && ((File) dt).canRead()) {
            System.out.println("Reading full set of climatological observations for Verification Unit '"+vu+"'....");
            File obs = (File)dt;
            //Reads data for a single VU: could also collect together all VUs first and read at once

            //For some file types (e.g. PI-XML), the location and variable IDs may be separate from
            //the VU location and variable IDs
            String oLocID = vu.getLocationID();
            String oVarID = vu.getVariableID();
            //Set the observed IDs if defined explicitly
            if (vu.hasObservedFileLocationID()) {
                oLocID = vu.getObservedFileLocationID();
            }
            if (vu.hasObservedFileVariableID()) {
                oVarID = vu.getObservedFileVariableID();
            }
            VUIdentifier v = new VUIdentifier(oLocID, oVarID);
            Vector<VUIdentifier> vv = new Vector<VUIdentifier>();
            vv.add(v);
            Vector<DoubleMatrix2D> v2 = null;

            //Read observations
            switch(vu.getObservedFileType()) {
                case FileIO.PIXML: v2 = new PublishedInterfaceXMLIO(new File[]{obs}, vv,
                		vu.getObservedTimeSystem(),false,null).getData(v); break;
                //JB@10th December 2012
                case FileIO.NETCDF: v2 = new NetCDFFileIO(new File[]{obs},
                        		vv,vu.getObservedTimeSystem(),false,null).getData(v); break;                     
                case FileIO.NWSCARD: v2 = OHDFileIO.readObservations(new File[]{obs}, 
                        vu.getObservedTimeSystem(),FileIO.NWSCARD,null,vu.getNullValue()); break;
                case FileIO.NWSBIN: v2 = OHDFileIO.readObservations(new File[]{obs}, 
                        vu.getObservedTimeSystem(),FileIO.NWSBIN,null,vu.getNullValue()); break;
                case FileIO.ASCII: {
                    v2 = ASCIIFileIO.readObservations(new File[]{obs}, vu.getObservedTimeSystem(),
                        vu.getObsDateFormat(),", \t\n\r\f",null);
                }; break;
            }
            if (v2 == null || v2.isEmpty()) {
                throw new IOException("No observed data were read from file.");
            }
            
            //JB@14th November 2012            
            //Pairs are stored in aggregated format?
            boolean rawAggregated = false;
            
            //Aggregate observations for storage if storing raw pairs in aggregated resolution    
            if (vu.willAggregatePairs() && vu.isStoreRawPairsInAggregatedRes()) {
                System.out.println("WARNING: storing pairs in aggregated resolution. Performing "
                        + "aggregation of observations and forecasts for pairing.");
                DoubleMatrix2D obsD = v2.get(0);
                obsD = PairedData.getTimeAggData(obsD, true, vu.getResolution(),
                        vu.getResolutionUnits(), vu.getTemporalAggFunc(), vu.getNullValue(), null,
                        vu.getAggregationStartHourUTC(), vu.getAggregationStartLeadHour(), null, null,
                        (TemporalSupport) vu.getSupport(Support.OBSERVED_SUPPORT),vu.isStrictAgg());
                v2.clear();
                v2.add(obsD);
                rawAggregated = true; 
            }           
                       
            //Conduct any change-of-support/aggregation of the observations to the forecast support of 
            //the paired forecasts if required
            TemporalSupport fS = (TemporalSupport) vu.getSupport(Support.FORECAST_SUPPORT);
            TemporalSupport oS = (TemporalSupport) vu.getSupport(Support.OBSERVED_SUPPORT);
            if (fS != null && oS != null && !fS.equalsAggregation(oS) && !rawAggregated ) {
                //Aggregate observations to forecast support if required
                if (TemporalSupport.canChangeSupport(oS, fS)) {
                    //Attempt to aggregate the observations
                    System.out.println("Aggregating observations to form unconditional climatology.");
                    int tot = v2.size();
                    Vector<DoubleMatrix2D> v3 = new Vector<DoubleMatrix2D>();
                    //Currently only one observed file can be selected, but retain loop for future update
                    for (int j = 0; j < tot; j++) {
                        System.out.println("Aggregating observations from file: " + obs);
                        try {
                            VectorFunction f = FunctionLibrary.mean();
                            if (fS.getAggregationFunction().equalsIgnoreCase("total")) {
                                f = FunctionLibrary.total();
                            }
                            v3.add(PairedData.getTimeAggData(v2.get(j), true, oS, fS, f,
                                    vu.getNullValue(), null,
                                    vu.getAggregationStartHourUTC(), null, null, null,vu.isStrictAgg()));
                        } catch (Exception e) {
                            e.printStackTrace();
                            System.out.println("Could not aggregate observations from file: " + obs);
                        }
                    }
                    v2 = v3;
                } else {
                    System.out.println("No change of support applied to the unconditional "
                            + "climatology for the purposes of pairing. A change of "
                            + "support may be applied to the pairs (both forecasts and observations) "
                            + "if requested separately.");
                }
            }
            
            DoubleMatrix2D obsClim = getAppendObservations(v2);
            pairs.setClimObsWithTimes(obsClim);
            //@JB 23/10/12 Fixed a bug whereby the unconditional climate observations were not being set
            //This bug was manifest only when re-reading pairs, as they are also set by 
            //PairedDataSource#computeAndSetPairs 
            pairs.setUncClimObsWithTimes(obsClim);  //@JB 23/10/12 
            System.out.println("Finished reading full set of climatological observations for Verification Unit '"+vu+"'.");
        }
        else {
            throw new IllegalArgumentException("Could not read the climatological observations for Verification Unit '"+vu+"'.");
        }
    }

    /********************************************************************************
     *                                                                              *
     *                               PRIVATE METHODS                                *
     *                                                                              *
     *******************************************************************************/

    /**
     * Returns a 1D matrix of appended observations from the input vector.
     *
     * @return a 1D matrix of appended observations
     */

    private static DoubleMatrix2D getAppendObservations(Vector<DoubleMatrix2D> input) {
        int size = input.size();
        DoubleMatrix2D first = (DoubleMatrix2D)input.get(0);
        for(int i = 1; i < size; i++) {
            first = first.appendRowsShallow((DoubleMatrix2D)input.get(i));
        }
        return first;
    }


}
