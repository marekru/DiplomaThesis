package evs.data.fileio;

//Java dependencies
import java.io.*;
import java.util.*;

//EVS dependencies
import evs.utilities.matrix.*;
import evs.utilities.mathutil.Mathematics;

/**
 * Utility class for file writing
 * 
 * @author evs@hydrosolved.com
 */
public class FileIOUtilities {

    /**
     * Writes a 1D matrix of double values to file with a specified precision and
     * separator string.
     *
     * @param data the data
     * @param file the file to write
     * @param precision the integer precision to write
     */

    public static void writeDoubleMatrix1D(DoubleMatrix1D data, File file, int precision) throws IOException, IllegalArgumentException  {
        if(data == null) {
            throw new IllegalArgumentException("Specify non-null data matrix.");
        }
        if(file == null) {
            throw new IllegalArgumentException("Specify a file that can be written.");
        }
        if(precision <=0) {
            throw new IllegalArgumentException("Specify a valid integer precision.");
        }
        //Write average coefficients to file
        String nL = System.getProperty("line.separator");
        BufferedWriter dc = null;
        double[] d = data.toArray();
        try {
            dc = new BufferedWriter(new FileWriter(file));
            for (int p = 0; p < d.length; p++) {
                dc.write(Mathematics.round(d[p],precision)+"");
                dc.write(nL);
            }
        } catch (IOException e) {
            throw e;
        } finally {
            if (dc != null) {
                try {
                    dc.close();
                } catch (Exception e) {
                    //Do nothing
                }
            }
        }
    }

    /**
     * Writes a 2D matrix of double values to file with a specified precision and
     * separator string.
     * 
     * @param data the data
     * @param file the file to write
     * @param precision the integer precision to write
     * @param sep the separator string
     */
    
    public static void writeDoubleMatrix2D(DoubleMatrix2D data, File file, int precision, String sep) throws IOException, IllegalArgumentException  {
        if(data == null) {
            throw new IllegalArgumentException("Specify non-null data matrix.");
        }
        if(file == null) {
            throw new IllegalArgumentException("Specify a file that can be written.");
        }
        if(precision <=0) {
            throw new IllegalArgumentException("Specify a valid integer precision.");
        }
        //Write average coefficients to file
        String nL = System.getProperty("line.separator");
        BufferedWriter dc = null;
        double[][] d = data.toArray();
        try {
            dc = new BufferedWriter(new FileWriter(file));
            for (int p = 0; p < d.length; p++) {
                for (int q = 0; q < (d[p].length-1); q++) {
                    dc.write(Mathematics.round(d[p][q],precision) + sep);
                }
                dc.write(Mathematics.round(d[p][d[p].length-1],precision)+"");
                dc.write(nL);
            }
        } catch (IOException e) {
            throw e;
        } finally {
            if (dc != null) {
                try {
                    dc.close();
                } catch (Exception e) {
                    //Do nothing
                }
            }
        }
    }

    /**
     * Reads a tabular data structure and returns an array of strings.
     *
     * @param file the tabular data
     * @param sep a string of separator characters to ignore
     * @return a 2D array of strings
     */

    public static String[][] readTable(File file,String sep) throws IOException {
        BufferedReader in = null;
        try {
            BufferedInputStream bIN = new BufferedInputStream(new FileInputStream(file));
            in = new BufferedReader(new InputStreamReader(bIN));
            String line = null;
            Vector<String[]> tempData = new Vector<String[]>();
            while ((line = in.readLine()) != null) {
                StringTokenizer stb = new StringTokenizer(line,sep,false);
                String[] next = new String[stb.countTokens()];
                for(int i = 0; i < next.length; i++) {
                    next[i]=stb.nextToken();
                }
                tempData.add(next);
            }
            //Construct the array
            int tot = tempData.size();
            String[][] returnMe = new String[tot][];
            for(int i = 0; i < tot; i++) {
                returnMe[i]=tempData.get(i);
            }
            return returnMe;

        } catch(Exception e) {
            e.printStackTrace();
            throw new IllegalArgumentException(e.getMessage());
        } finally {
            if(in != null) {
                try {
                    in.close();
                }
                catch(Exception e) {
                    //Do nothing
                }
            }
        }
    }

    /**
     * Reads a 2D double matrix from file.
     *
     * @param file the tabular data
     * @param sep a string of separator characters to ignore
     * @return a 2D array of strings
     */

    public static DoubleMatrix2D readDoubleMatrix2D(File file,String sep) throws IOException, NumberFormatException {
        BufferedReader in = null;
        try {
            BufferedInputStream bIN = new BufferedInputStream(new FileInputStream(file));
            in = new BufferedReader(new InputStreamReader(bIN));
            String line = null;
            Vector<String[]> tempData = new Vector<String[]>();
            int colMax = 0;
            while ((line = in.readLine()) != null) {
                StringTokenizer stb = new StringTokenizer(line,sep,false);
                String[] next = new String[stb.countTokens()];
                for(int i = 0; i < next.length; i++) {
                    next[i]=stb.nextToken();
                }
                if(next.length>colMax) {
                    colMax=next.length;
                }
                tempData.add(next);
            }
            //Construct the array
            int tot = tempData.size();
            double[][] returnMe = new double[tot][colMax];
            for(int i = 0; i < tot; i++) {
                String[] nx = tempData.get(i);
                for(int j = 0; j < nx.length; j++) {
                    returnMe[i][j]=new Double(nx[j]);
                }
            }
            return new DenseDoubleMatrix2D(returnMe);

        } catch(Exception e) {
            e.printStackTrace();
            throw new IllegalArgumentException(e.getMessage());
        } finally {
            if(in != null) {
                try {
                    in.close();
                }
                catch(Exception e) {
                    //Do nothing
                }
            }
        }
    }
    
}
