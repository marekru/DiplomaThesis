package evs.data.fileio.netcdf;

/**
 * Utility class to encapsulate a Variable with its data from a NetCdf file
 *
 * @author Frederik van den Broek
 */

public class VariableDataSet {

    private final String variableName;
    private final double[] values;

    public VariableDataSet(String variableName, double[] values) {
        this.variableName = variableName;
        this.values = values;
    }

    public String getVariableName() {
        return variableName;
    }

    public double[] getValues() {
        return values;
    }
}
