package evs.data.fileio.ohdfile.misc;
import java.io.*;

/**
 *  This subclass of DataInputStream supplies five extra functions.  Each is the same as the
 *  the routine in DataInputStream that reads in a primitive numerical data types (short, int,
 *  long, float, or double), except that it will reverse the bytes if the environment variable
 *  HOSTOS says that this is a Linux machine. This is required because Java ALWAYS assumes
 *  big-endian!  For examples of how this is used, see ESPData. <br>
 *  <br>
 *  UPDATING A ROUTINE TO SWITCH FROM A DataInputStream TO A HBinaryInputStream:<br>
 *  <br>
 *  First, you need to change all references to "DataInputStream" into "HBinaryInputStream".  Next,
 *  all read commands for float, double, short, int, or long are changed to the corresponding *Swap
 *  routine in here.  So readFloat becomes readFloatSwap, readInt becomes readIntSwap, etc. <br>
 *  <br>
 *
 * @author hank
 */

public class HBinaryInputStream extends DataInputStream {
    private static final long serialVersionUID = 1L;
    final public static String CLASSNAME = "HBinaryInputStream";

    //Static vars
    final public static int FLOAT_SIZE  = 4;
    final public static int DOUBLE_SIZE = 8;
    final public static int SHORT_SIZE  = 2;
    final public static int INT_SIZE    = 4;
    final public static int LONG_SIZE   = 8;

    //Flags to pass in to the setEndianFlag routine.
    final public static boolean LITTLE_ENDIAN_DATA_FLAG    = true;
    final public static boolean BIG_ENDIAN_DATA_FLAG = false;

    ///////////////////////////////////////////////////////////////////////////
    //Attributes
    ///////////////////////////////////////////////////////////////////////////
    boolean _reversebytesflag;  //If this is true, then reverse the bytes before processing.


    ///////////////////////////////////////////////////////////////////////////
    //Constructors
    ///////////////////////////////////////////////////////////////////////////

    /**
     * This is the default constructor and will just call super followed by something to set the
     * reversebytesflag if necessary.
     * @param in InputStream to serve as base for this object.
     */
    public HBinaryInputStream(InputStream in) {
        //Call the constructor for the super class.
        super(in);

        //Set the flag to determine if endians are to be swapped.
        //Here, I should read an environment variable or an apps-defaults token in order
        //to determine if I am on a linux system.  The default value is...
        _reversebytesflag = false;  //True is for linux runs

        //Get the system property sun.cpu.endian.
        String endian = System.getProperty("sun.cpu.endian");
        if ((endian == null) || (endian.length() == 0)) {
            Messenger.writeMsg(Messenger.EVT_PARAMETERS + Messenger.SEV_WARNING + Messenger.ALWAYS_PRINT,
                    "System getProperty failed to find sun.cpu.endian Java property.  Assuming big endian.\n");
            return;
        }

        //Check for "little" (LINUX_SETTING).  If so, turn on the reversal flag.
        //Messenger.writeMsg(Messenger.EVT_PARAMETERS + Messenger.SEV_INFO + Messenger.ALWAYS_PRINT,
        //        "The system property sun.cpu.endian was found to be \"" + endian + "\".\n");
        if (endian.equalsIgnoreCase("little")) {
            //Messenger.writeMsg(Messenger.EVT_PARAMETERS + Messenger.SEV_INFO + Messenger.ALWAYS_PRINT,
            //        "Bytes will be reversed for little-endian.\n");
            _reversebytesflag = true;
        } else {
            //Messenger.writeMsg(Messenger.EVT_PARAMETERS + Messenger.SEV_INFO + Messenger.ALWAYS_PRINT,
            //        "Bytes will NOT be reversed... assuming big-endian.\n");
        }
    }

    /**
     * This is the default constructor and will just call super and set the _reversebytesflag
     * to the passed in flag.  Note that the flag should be one of the static flag variables
     * above, for sanity sake.
     *
     * @param in
     * @param flag
     */
    public HBinaryInputStream(InputStream in, boolean flag) {
        //Call the constructor for the super class.
        super(in);

        //Set the flag to determine if endians are to be swapped.
        _reversebytesflag = flag;
    }


    ///////////////////////////////////////////////////////////////////////////
    //Tools
    ///////////////////////////////////////////////////////////////////////////

    /**
     * Reads in a float; uses readByteArraySwap to read bytes for swapping.
     */
    public float readFloatSwap() throws IOException {
        //Now, read in the bytes of the number and reverse them if necessary.
        byte[] bytearray = readByteArraySwap(FLOAT_SIZE);

        //Now I need to get my four bytes into a float.  So, I put the byte array into a
        //ByteArrayInputStream...
        ByteArrayInputStream bytestream = new ByteArrayInputStream(bytearray, 0, FLOAT_SIZE);

        //cast it into a DataInputStream...
        DataInputStream binfile = new DataInputStream(bytestream);

        //and read the float.
        float value = binfile.readFloat();

        return value;
    }

    /**
     * Reads in a double; uses readByteArraySwap to read bytes for swapping.
     */
    public double readDoubleSwap() throws IOException {
        //Now, read in the bytes of the number and reverse them if necessary.
        byte[] bytearray = readByteArraySwap(DOUBLE_SIZE);

        //Now I need to get my four bytes into a float.  So, I put the byte array into a
        //ByteArrayInputStream...
        ByteArrayInputStream bytestream = new ByteArrayInputStream(bytearray, 0, DOUBLE_SIZE);

        //cast it into a DataInputStream...
        DataInputStream binfile = new DataInputStream(bytestream);

        //and read the float.
        double value = binfile.readDouble();

        return value;
    }

    /**
     *
     * Reads in an int; uses readByteArraySwap to read bytes for swapping.
     */
    public int readIntSwap() throws IOException {
        //Now, read in the bytes of the number and reverse them if necessary.
        byte[] bytearray = readByteArraySwap(INT_SIZE);

        //Now I need to get my four bytes into a float.  So, I put the byte array into a
        //ByteArrayInputStream...
        ByteArrayInputStream bytestream = new ByteArrayInputStream(bytearray, 0, INT_SIZE);

        //cast it into a DataInputStream...
        DataInputStream binfile = new DataInputStream(bytestream);

        //and read the float.
        int value = binfile.readInt();

        return value;
    }


    /**
     *
     * Reads in a long; uses readByteArraySwap to read bytes for swapping.
     */
    public long readLongSwap() throws IOException {
        //Now, read in the bytes of the number and reverse them if necessary.
        byte[] bytearray = readByteArraySwap(LONG_SIZE);

        //Now I need to get my four bytes into a float.  So, I put the byte array into a
        //ByteArrayInputStream...
        ByteArrayInputStream bytestream = new ByteArrayInputStream(bytearray, 0, LONG_SIZE);

        //cast it into a DataInputStream...
        DataInputStream binfile = new DataInputStream(bytestream);

        //and read the float.
        long value = binfile.readLong();

        return value;
    }


    /**
     *
     * Reads in a short; uses readByteArraySwap to read bytes for swapping.
     */
    public short readShortSwap() throws IOException {
        //Now, read in the bytes of the number and reverse them if necessary.
        byte[] bytearray = readByteArraySwap(SHORT_SIZE);

        //Now I need to get my four bytes into a float.  So, I put the byte array into a
        //ByteArrayInputStream...
        ByteArrayInputStream bytestream = new ByteArrayInputStream(bytearray, 0, SHORT_SIZE);

        //cast it into a DataInputStream...
        DataInputStream binfile = new DataInputStream(bytestream);

        //and read the float.
        short value = binfile.readShort();

        return value;
    }

    /**
     * Reverse the bytes in the passed in array; do the swap!
     * @param bytearray Array of bytes.
     * @return Reversed array of bytes.
     */
    public byte[] reverseBytes(byte[] bytearray) {
        int i = 0;
        int j = bytearray.length - 1;
        byte tmpbyte;

        //Loop through until i is no longer less than j.
        for (i = 0; i < j; i ++) {
            //swap the bytes in the i and j position.
            tmpbyte = bytearray[i];
            bytearray[i] = bytearray[j];
            bytearray[j] = tmpbyte;

            //decrement j.
            j --;
        }

        return bytearray;
    }

    /**
     * Read in the appropriate byte array, swapping endians if necessary.
     *
     * @param size Number of bytes to read
     * @return The byte array, swapped if needed.
     * @throws IOException if DataInputStream read throws an exception using
     * this in constructor.
     */
    public byte[] readByteArraySwap(int size) throws IOException {
        try {
            //Now, read in the four bytes making up the byte array.
            byte[] bytearray = new byte[size];
            int read = read(bytearray, 0, size);  //JB: this read is required even though the return value isn't used
//            if (read != size) {
//                throw new IOException("Read fewer bytes than expected: [" + size + "," + read + "].");
//            }
            //And call the reverse bytes routine if necessary.
            if (_reversebytesflag) {
                //Add some stuff here to swap the endians.
                bytearray = reverseBytes(bytearray);
            }
            return bytearray;
        } catch (Exception e) {
            throw new IOException(e.getMessage());
        }
    }

    ///////////////////////////////////////////////////////////////////////////
    //Sets and Gets
    ///////////////////////////////////////////////////////////////////////////

    /**
     * Endian flag should be true if the file to read in requires swapping (i.e. is in
     * little endian) or false otherwise.  Static vars LITTLE_ENDIAN_DATA_FLAG and
     * BIG_ENDIAN_DATA_FLAG can be used.  Wrapper on setReverseBytesFlag.
     * @param flag The new flag value.
     */
    public void setEndianFlag(boolean flag) {
        setReverseBytesFlag(flag);
    }

    /**
     * Sets the reverse bytes flag.
     * @param flag The new flag value.
     */
    public void setReverseBytesFlag(boolean flag) {
        _reversebytesflag = flag;
    }

    public boolean getEndianFlag() {
        return getReverseBytesFlag();
    }

    public boolean getReverseBytesFlag() {
        return _reversebytesflag;
    }

}




