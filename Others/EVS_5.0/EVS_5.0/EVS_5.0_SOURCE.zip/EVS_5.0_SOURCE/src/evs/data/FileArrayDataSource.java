package evs.data;

//Java io dependencies
import java.io.File;

//Java util dependencies
import java.util.Arrays;

/**
 * Constructs a file array data source with an array of files.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public final class FileArrayDataSource extends DataSource {

    /**
     * Creates a FileDataSource with an array of files, none of which may be null.
     * 
     * @param data the file array data source
     */
    
    public FileArrayDataSource(final File[] data) {
        if(data == null || data.length == 0) {
            throw new IllegalArgumentException("Specify non-null input for the file array data source.");
        }
        for(int i = 0; i < data.length; i++) {
            if(data[i]==null) {
                throw new IllegalArgumentException("Specify non-null input for the file array data source.");
            }
        }
        this.data = data;
    }

    /**
     * Returns a string representation of the receiver. 
     *
     * @return a string representation
     */
    
    public String toString() {
        String s = "";
        try { 
            s = "[FILE ARRAY]: "+((File[])data)[0].getParentFile().getPath();  //JB @ August 2012 .getAbsolutePath()
        } catch(Exception e) {}//Do nothing
        return s;
    }
    
	/**
	 * Returns true if the data source can be read, false otherwise.
	 * 
	 * @return true if the data source can be read
	 */

	public boolean canRead() {
		File[] f = (File[])data;
        for(int i = 0; i < f.length; i++) {
            if(!((File)f[i]).canRead()) {
                return false;
            }
        }
        return true;
	}    
	
	/**
	 * Returns true if the data source can be written, false otherwise.
	 * 
	 * @return true if the data source can be written
	 */

	public boolean canWrite() {
		File[] f = (File[])data;
        for(int i = 0; i < f.length; i++) {
            if(!((File)f[i]).canWrite()) {
                return false;
            }
        }
        return true;
	}  	
    
    /**
     * Returns true if the objects are the same (tests the underlying data
     * objects).
     *
     * @param obj the object to test for equality
     * @return true if the objects are the same
     */
    
    public boolean equals(Object obj) {
        if(! (obj instanceof FileArrayDataSource)) {
            return false;
        }
        return Arrays.equals((File[])data,(File[])((FileArrayDataSource)obj).getData());                
    }  
    
    /**
     * Override hashcode: not implemented.
     * 
     * @return a hashcode
     */
    
    public int hashCode() {
        assert false : "hashCode not implemented for FileArrayDataSource.";
        return 1;
    }    
    
}
