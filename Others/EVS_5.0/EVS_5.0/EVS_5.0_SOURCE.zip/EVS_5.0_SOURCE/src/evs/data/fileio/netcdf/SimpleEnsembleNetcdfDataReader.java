package evs.data.fileio.netcdf;

//Java dependencies
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

//UCAR dependencies
import ucar.ma2.Array;
import ucar.nc2.Dimension;
import ucar.nc2.NetcdfFile;
import ucar.nc2.Variable;
import ucar.nc2.dataset.NetcdfDataset;

/**
 * Example class to reading Ensemble NetCDF data files produced by Delft FEWS,
 * using the NetCDF libraries from Unidata, see
 * http://www.unidata.ucar.edu/downloads/netcdf/netcdf-java-4/index.jsp This
 * example only reads the essential data, for extensive reading of the
 * associated metadata, please refer to
 * org.openda.exchange.dataobjects.NetcdfDataObject.readNetcdfFile()
 *
 * 5th June 2012: Modified by JB to read information for a specified station
 * only.
 *
 * @author Frederik van den Broek
 */
public class SimpleEnsembleNetcdfDataReader {

    private String variableName;
    private String locationID;   //JB@5th June 2012
    private NetcdfFile netcdfFile;
    private EnsembleDataParserCallback contentHandler;

    public SimpleEnsembleNetcdfDataReader(EnsembleDataParserCallback contentHandler) {
        this.contentHandler = contentHandler;
    }

    public void parse(File file, String variableLongName) throws IOException {

        this.variableName = variableLongName;

        try {
            netcdfFile = NetcdfDataset.openFile(file.getAbsolutePath(), null);
            parseNetcdfFile(netcdfFile);
        } finally {
            if (netcdfFile != null) {
                netcdfFile.close();
            }
        }
    }

    //JB@5th June 2012
    public void parse(File file, String locationID, String variableLongName) throws IOException {

        this.variableName = variableLongName;
        this.locationID = locationID;

        try {
            netcdfFile = NetcdfDataset.openFile(file.getAbsolutePath(), null);
            parseNetcdfFile(netcdfFile);
        } finally {
            if (netcdfFile != null) {
                netcdfFile.close();
            }
        }
    }

    private void parseNetcdfFile(NetcdfFile netcdfFile) throws IOException {
        // Find the wanted variable
        Variable dataVariable = netcdfFile.findVariable(variableName);
        if (dataVariable == null) {
            throw new IOException("Did not find requested variable " + variableName + " in NetcdfFile " + netcdfFile.getLocation());
        }

        // Find the time variable
        Variable timeVariable = NetcdfUtils.findTimeVariableForVariable(dataVariable, netcdfFile);
        if (timeVariable == null) {
            throw new IOException("Did not find time variable for variable " + variableName + " in NetcdfFile " + netcdfFile.getLocation());
        }

        // Find the stations dimension
        Dimension stationsDim = netcdfFile.findDimension(NetcdfUtils.STATIONS_VARIABLE_NAME);
        if (stationsDim == null) {
            throw new IOException("Did not find stations dimension in NetcdfFile " + netcdfFile.getLocation());
        }

        // Find the realizations variable
        Variable realizations = netcdfFile.findVariable(NetcdfUtils.REALIZATION_VARIABLE_NAME);
        if (realizations == null) {
            throw new IOException("Did not find realizations variable in NetcdfFile " + netcdfFile.getLocation());
        }

        // Store the station information
        HashMap<String, String> stationInfo = new HashMap<String, String>();

        String[] stationIdArray = null;
        String[] stationNameArray = null;
        Variable stationIdVariable = netcdfFile.findVariable(NetcdfUtils.STATION_ID_VARIABLE);
        if (stationIdVariable == null) {
            System.out.println("Did not find variable " + NetcdfUtils.STATION_ID_VARIABLE + " in NetcdfFile " + netcdfFile.getLocation());
        } else {
            stationIdArray = readVariableWithStrings(stationIdVariable);
        }
        Variable stationNameVariable = netcdfFile.findVariable(NetcdfUtils.STATION_NAME_VARIABLE);
        if (stationNameVariable == null) {
            System.out.println("Did not find variable " + NetcdfUtils.STATION_NAME_VARIABLE + " in NetcdfFile " + netcdfFile.getLocation());
        } else {
            stationNameArray = readVariableWithStrings(stationNameVariable);
        }

        for (int i = 0; i < stationsDim.getLength(); i++) {
            String id = "";
            String name = "";
            if (stationIdArray != null) {
                id = stationIdArray[i];
            }
            if (stationNameArray != null) {
                name = stationNameArray[i];
            }
            //JB@5th June 2012
            if (locationID != null) {
                if (id.equals(locationID)) {
                    stationInfo.put(id, name);
                    break;  //One station
                }
            } else {
                stationInfo.put(id, name);  //All stations
            }
        }
        //One station required, but not found
        if (locationID != null && stationInfo.size() == 0) {
            throw new IOException("Could not find location with ID " + locationID + " in NetcdfFile " + netcdfFile.getLocation());
        }

        // And write it to the callback
        contentHandler.setStationInfo(stationInfo);
        contentHandler.setNumberOfStations(stationInfo.size()); //JB@5th June 2012

        // Store the realization information
        int[] realizationsArray = (int[]) realizations.read().get1DJavaArray(int.class);
        contentHandler.setEnsembleInfo(realizationsArray);

        // Store timeInformation
        long[] timeArray = NetcdfUtils.readTimes(timeVariable);
        contentHandler.setTimeInfo(timeArray);

        //read data.
        Array array3D = dataVariable.read();
        if (array3D == null) {
            return;
        }
        // Loop over stations and realizations to extract the timeseries
        for (int i = 0; i < stationsDim.getLength(); i++) {

            //JB@5th June 2012  If one station requested, check it is the current station
            if (locationID == null || (locationID != null && stationIdArray[i].equals(locationID))) {

                //get values for one station.
                int stationsDimensionIndex = 2;
                Array array2D = array3D.slice(stationsDimensionIndex, i);

                for (int j = 0; j < realizationsArray.length; j++) {
                    //get values for one ensemble.
                    int realizationDimensionIndex = dataVariable.findDimensionIndex(realizations.getFullName());
                    Array array1D = array2D.slice(realizationDimensionIndex, j);

                    //convert from Array object to double[] array.
                    double[] timeSeries = (double[]) array1D.get1DJavaArray(Double.class);

                    //store data.
                    contentHandler.handleTimeSeries(timeSeries, realizationsArray[j], stationIdArray[i], variableName);
                }
            }
        }

    }

    /**
     * Assumption: if stationIdsVar has two dimensions, then the first dimension
     * is the location axis and the second dimension is a char array that
     * contains the characters of the String that is the external locationId.
     *
     * @param variableWithStrings
     * @throws IOException
     */
    private String[] readVariableWithStrings(Variable variableWithStrings) throws IOException {
        char[] chars = (char[]) variableWithStrings.read().copyTo1DJavaArray();
        int stationCount = variableWithStrings.getDimension(0).getLength();
        int charCount = variableWithStrings.getDimension(1).getLength();

        String[] strings = new String[stationCount];
        for (int i = 0; i < stationCount; i++) {
            StringBuilder sb = new StringBuilder();
            for (int j = 0; j < charCount; j++) {
                sb.append(chars[j + i * charCount]);
            }
            strings[i] = sb.toString().trim();
        }

        return strings;
    }
}
