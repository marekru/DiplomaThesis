package evs.data.fileio;
        
//SAX dependencies
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;

//Java dependencies 
import java.util.*;
import java.io.IOException;

//EVS dependencies
import evs.utilities.StringUtilities;
import evs.utilities.matrix.*;
import evs.data.*;

/**
 * Handler for time-series files in the Published Interface (PI) XML format, for which 
 * a schema is available from:
 * 
 * http://fews.wldelft.nl/schemas/version1.0/pi-schemas/pi_timeseries.xsd 
 * 
 * Reads files containing ensemble forecasts and files containing observations.
 * 
 * @author evs@hydrosolved.com
 */

public class PISAXHandler extends DefaultHandler {

    
/********************************************************************************
 *                                                                              *
 *                                CONSTRUCTORS                                  *
 *                                                                              *
 *******************************************************************************/     
    
   /**
    * Constructor to read in data for all locations and variables on file.
    * 
    * @param forecastData is true if the data to be passed are forecasts, false for observations
    */ 
    
    public PISAXHandler(boolean forecastData){
    	this.forecastData=forecastData;
    }
    
   /**
    * Constructor to read in data for a specific set of locations and variables.
    *
    * @param readMe the data to read
    * @param forecastData is true if the data to be passed are forecasts, false for observations
    */ 
    
    public PISAXHandler(Vector<VUIdentifier> readMe, boolean forecastData){
        this.readMe = readMe;
        this.forecastData=forecastData;
    }    
    
/********************************************************************************
 *                                                                              *
 *                              INSTANCE VARIABLES                              *
 *                                                                              *
 *******************************************************************************/    
    /**
     * The data to read.
     */
    private Vector<VUIdentifier> readMe = null;
    /**
     * Store of data (either forecasts or observations) by unique VUIdentifier
     * in a map. The stored map contains the data by forecast valid time (and possibly
     * lead time).
     */
    private HashMap<VUIdentifier,LinkedHashMap<ForecastTime,double[]>> store = new HashMap();
    /**
     * Store of forecast support by unique location identifier in a map.
     * 
     * Format for storage TBD
     */
    private HashMap<String, Object[]> support = new HashMap();
    /**
     * Timezone
     */
    private TimeZone zone;    
    /**
     * Last value for field <type>.
     */
    private String type;
    /**
     * Last value for field <locationId>.
     */
    private String locationId;
    /**
     * Last value for field <parameterId>.
     */
    private String parameterId;
    /**
     * Last value for <ensembleMemberIndex> 
     */
    private int ensembleMemberIndex;
    /**
     * Last value for <ensembleId> 
     */
    private String ensembleId;    
    /**
     * Last value for <timeStep unit>.
     */
    private String timeStepUnit;
    /**
     * Last value for <timeStep multiplier>.
     */
    private double timeStepMultiplier;
    /**
     * Last value for <startDate date>.
     */
    private String startDateDate;
    /**
     * Last value for <startDate time>.
     */
    private String startDateTime;
    /**
     * Last value for <endDate date>.
     */
    private String endDateDate;
    /**
     * Last value for <endDate time>.
     */
    private String endDateTime;
    /**
     * Last value for <forecastDate date>.
     */
    private String forecastDateDate;
    /**
     * Last value for <forecastDate time>.
     */
    private String forecastDateTime;
    /**
     * Last forecast time in hours.
     */
    private double lastForcTime;
    /**
     * Last value for <missVal>.
     */
    private double missVal;
    /**
     * Last value for <stationName>.
     */
    private String stationName; 
    /**
     * Last value for <units>.
     */
    private String units;
    /**
     * Last value for <event date>.
     */
    private String date;
    /**
     * Last value for <event time>.
     */
    private String time;
    /**
     * Last value for <event value>.
     */
    private double value;
    /**
     * Last value for <event flag>.
     */
    private String flag;
    /**
     * The last character set read.
     */
    private StringBuffer last;
    /**
     * Is true if the last read data were ensemble data.
     */
    private boolean ensembleData = false;
    
    /**
     * Is true if the data comprise forecast data, false if they comprise observations.
     */
    
    private boolean forecastData = false;
    
/********************************************************************************
 *                                                                              *
 *                                ACCESSOR METHODS                              *
 *                                                                              *
 *******************************************************************************/   
    
    /**
     * Returns the data for a specified identifier or throws an exception if not
     * available.
     * 
     * @param id the identifier
     * @return the data
     */
    
    public DoubleMatrix2D getData(VUIdentifier id) throws IOException {
        if(!store.containsKey(id)) {
            throw new IOException("No data were read for identifier '"+id+"': " +
                    "check that the identifier is valid and that the corresponding data are on file.");
        }
        return retrieve(id);
    }
    
    /**
     * Returns the data for the first identifier in the store.
     * 
     * @return the data for the first identifier in store
     */
    
    public DoubleMatrix2D getData() throws IOException {
        if(store.isEmpty()) {
            throw new IOException("No data were found in the PI-XML store.");
        }
        return retrieve(store.keySet().iterator().next());
    }
    
    /**
     * Returns the time zone read from file or null if the time
     * zone has not been read.
     * 
     * @return the time zone
     */
    
    public TimeZone getTimeZone() {
    	if(zone!=null) {
    		return TimeZone.getTimeZone(zone.getID());
    	}
    	return null;
    }
    
    /**
     * Returns the data for all locations indexed by unique ID.
     * 
     * 
     * @return data for all stored locations indexed by unique ID
     */
    
    public HashMap<VUIdentifier,DoubleMatrix2D> getAllData() throws IOException {
        if(store.isEmpty()) {
            throw new IOException("No data were found in the PI-XML store.");
        }
        HashMap<VUIdentifier,DoubleMatrix2D> returnMe = 
                new HashMap<VUIdentifier,DoubleMatrix2D>();
        Iterator it = store.keySet().iterator();
        while(it.hasNext()) {
            VUIdentifier next = (VUIdentifier)it.next();
            returnMe.put(next.deepCopy(),retrieve(next));
        }
        return returnMe;
    }
    
    /**
     * Returns the data for a specified ID.
     * 
     * @param id the identifier
     * @return the corresponding data
     */
    
    private DoubleMatrix2D retrieve(VUIdentifier id) {
        HashMap<ForecastTime, double[]> d = store.get(id);
        double[][] dt = new double[d.size()][];
        Iterator it = d.keySet().iterator();
        int tot = 0;
        while (it.hasNext()) {
            dt[tot] = d.get(it.next());
            tot++;
        }
        return new DenseDoubleMatrix2D(dt);     
    }
    
    
/********************************************************************************
 *                                                                              *
 *                                MUTATOR METHODS                               *
 *                                                                              *
 *******************************************************************************/     
    
    /**
     * Starts the document.
     */
    
    public void startDocument() {
        last = new StringBuffer();
    }

    /**
     * Starts an element.
     *
     * @param namespaceURL the URL
     * @param localName the local name
     * @param qname the raw XML name
     * @param attributes the attributes
     */
    
    public void startElement(String namespaceURL, String localName,String qname, Attributes attributes) {
        last.setLength(0);
        if(localName.equals("timeStep")) {
            timeStepUnit = attributes.getValue("unit");
            String mult = attributes.getValue("multiplier");
            if(mult!=null) {
            	timeStepMultiplier = new Double(mult);
            }
        } else if(localName.equals("startDate")) {
            startDateDate = attributes.getValue("date");
            startDateTime = attributes.getValue("time");
        } else if(localName.equals("endDate")) {
            endDateDate = attributes.getValue("date");
            endDateTime = attributes.getValue("time");
        } else if(localName.equals("forecastDate")) {
            forecastDateDate = attributes.getValue("date");
            forecastDateTime = attributes.getValue("time");
        } else if(localName.equals("event")) {
            date = attributes.getValue("date");
            time = attributes.getValue("time");
            value = new Double(attributes.getValue("value"));
            flag = attributes.getValue("flag");            
        }
    }
    
    /**
     * Ends an element.
     *
     * @param uri the URI
     * @param localName the tag name
     * @param qName the raw XML name
     */
    
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if(localName.equals("type")) {
            //At this point, store the support and other information for the 
            //last unit if store.size() > 0
            type = last+"";
        } else if(localName.equals("stationName")) {
            stationName = last+"";
        } else if(localName.equals("parameterId")) {
            parameterId = last+"";
        } else if(localName.equals("ensembleId")) {
            ensembleId = last+"";
        } else if(localName.equals("ensembleMemberIndex")) {
            int next = new Integer(last+"");
            ensembleData = true;
            ensembleMemberIndex = next;
        } else if(localName.equals("missVal")) {
            missVal = new Double(last+"");
        } else if(localName.equals("locationId")) {
            //Change unit, so add results for current unit to the store
            locationId = last+"";            
        } else if(localName.equals("units")) {
            units = last+"";
            //Update forecast time if forecasts (units is the last record)
            if(forecastDateDate !=null) {
                lastForcTime=getTime(forecastDateDate,forecastDateTime,zone);                
            }
        } 
        //Store results for current event, creating a new store if the location
        //has changed
        else if(localName.equals("event")) {
            VUIdentifier v = new VUIdentifier(locationId, parameterId);
            if (readMe==null || readMe.contains(v)) {  //Read all or test
                LinkedHashMap<ForecastTime, double[]> d = null;
                if (store.containsKey(v)) {
                    d = store.get(v);
                } else {
                    d = new LinkedHashMap();
                    store.put(v, d);
                }
                double validTime = getTime(date, time, zone);
                double leadTime = -999;
                if(forecastData) {
                    leadTime = validTime - lastForcTime;
                }
                double[] addMe = null;
                ForecastTime t = null;
                if (forecastData) {
                    t = new ForecastTime(validTime, leadTime);
                    //Add data to store
                    if (d.containsKey(t)) {
                        double[] appenda = d.get(t);
                        addMe = new double[appenda.length + 1];
                        System.arraycopy(appenda, 0, addMe, 0, appenda.length);  //Copy existing data
                        addMe[appenda.length] = value;
                    }
                    else {
                        addMe = new double[]{validTime, leadTime, value};
                    }
                } else {
                    t = new ForecastTime(validTime);
                    if (d.containsKey(t)) {
                        double[] appenda = d.get(t);
                        addMe = new double[appenda.length + 1];
                        System.arraycopy(appenda, 0, addMe, 0, appenda.length);  //Copy existing data
                        addMe[appenda.length] = value;
                    }
                    else {
                        addMe = new double[]{validTime, value};
                    }
                }
                d.put(t,addMe);
                
            } 
//            else {
//                //System.out.println("Skipping data for: " + v);
//            }
        } 
        else if(localName.equals("timeZone")) {
            String append = "";
            Integer offset = new Double(last+"").intValue();
            if(offset>=0) {
                append = "+"+offset;
            } else {
                append = offset+"";
            }
            try {
            	if(offset==0) {
                    zone = TimeZone.getTimeZone("GMT");
            	} else {
                    zone = TimeZone.getTimeZone("GMT"+append);
            	}
            }
            catch(Exception e) {
                throw new SAXException("Unrecognized time zone offset '"+last+"'.");
            }
        }
    }

    public void endDocument() throws SAXException {        
        super.endDocument();
    }
    
    /**
     * Reads untagged characters (i.e. data values).
     *
     * @param ch the characters
     * @param start the start index
     * @param length the length
     */
    
    public void characters (char[] ch, int start, int length) {
        last.append(ch, start, length);        
    }
            
    /********************************************************************************
     *                                                                              *
     *                                PRIVATE METHODS                               *
     *                                                                              *
     *******************************************************************************/  
    
    /**
     * Returns a time in hours relative to the epoch.
     * 
     * @param date the date
     * @param time the time
     * @param zone the time zone
     * @return hours relative to the epoch
     */
    
    private double getTime(String date, String time, TimeZone zone) throws SAXException {
        if(date == null || time == null) {
            throw new SAXException("Cannot process the date and time in the PI-XML file as some "
                    + "information was missing. The date string is '"+date+"' and the time string is "
                    + "'"+time+"'");
        }
        try {
            Calendar c = Calendar.getInstance(zone);
            c.clear();
            StringTokenizer s = new StringTokenizer(date, "-");
            StringTokenizer t = new StringTokenizer(time, ":");
            //Set year, month, day of month: note zero-based month index
            int year = new Integer(s.nextToken());
            int month = (new Integer(s.nextToken()))-1;
            int day = new Integer(s.nextToken());
            int hour = new Integer(t.nextToken());
            int minute = new Integer(t.nextToken());
            int second = new Integer(t.nextToken());
            c.set(year,month,day,hour,minute,second);
            double millis = c.getTimeInMillis() / (1000.0 * 60.0 * 60.0);
            return millis;
        } catch (Exception e) {
            e.printStackTrace();
            throw new SAXException("Failed to process date string "+date+" with time "+time+".");
        }
    }

}
