package evs.data.fileio;

//EVS dependencies
import evs.data.ConditioningException;
import evs.data.ConditionArray;
import evs.data.Condition;
import evs.analysisunits.*;
import evs.utilities.matrix.*;
import evs.utilities.*;

//Java io dependencies
import java.io.*;

//Java util dependencies
import java.util.*;

/**
 * Reads ASCII files containing forecasts or observations.
 * 
 * @author evs@hydrosolved.com
 */

public class ASCIIFileIO extends FileIO implements InputDataIO {

    /********************************************************************************
     *                                                                              *
     *                               ACCESSOR METHODS                               *
     *                                                                              *
     *******************************************************************************/    

    /**
     * Reads in an array of files containing forecasts and returns a vector of 
     * matrices, which may be input to the pairing process.  Each matrix contains 
     * the data from one file.  The first column contains the time in hours from 
     * the epoch and the remaining columns contain the data.  
     *
     * @param input the input data
     * @param zone the time zone
     * @param dateFormat the date format
     * @param valDelims the data value delimiter(s)
     * @param conditions an array of conditions upon which to restrict reading (may be null) 
     * @param nV the null value
     * @return vector of matrices containing the data
     */
    
    public static Vector<DoubleMatrix2D> readForecasts(File[] input, TimeZone zone, 
            String dateFormat, String valDelims, ConditionArray conditions, double nV) throws IOException {
        //Check for files to read  
        if(input == null || input.length == 0) {
            throw new IOException("No files specified.");
        }
        //Check for the file types by reading the header, which removes dependence on naming
        Vector<DoubleMatrix2D> rawData = new Vector<DoubleMatrix2D>();
        //Attempt to read the files and construct the vector of matrices
        for (int i = 0; i < input.length; i++) {
            System.out.println("Attempting to read file '" + input[i] + "'...");
            rawData.add(readForecasts(input[i], zone, dateFormat, valDelims, conditions, nV));
            System.out.println("done.");
        }
        return rawData;
    }
    
    /**
     * Reads in an array of files containing forecasts and returns a vector of 
     * matrices, which may be input to the pairing process.  Each matrix contains 
     * the data from one file.  The first column contains the time in hours from 
     * the epoch and the remaining columns contain the data.  
     *
     * @param input the input data
     * @param zone the time zone
     * @param dateFormat the date format
     * @param valDelims the data value delimiter(s)
     * @param conditions an array of conditions upon which to restrict reading (may be null)
     * @return vector of matrices containing the data
     */
    
    public static Vector<DoubleMatrix2D> readObservations(File[] input, TimeZone zone, 
            String dateFormat, String valDelims, ConditionArray conditions) throws IOException {
        //Check for files to read
        if(input == null || input.length == 0) {
            throw new IOException("No files specified.");
        }
        //Check for the file types by reading the header, which removes dependence on naming
        Vector<DoubleMatrix2D> rawData = new Vector<DoubleMatrix2D>();
        //Attempt to read the files and construct the vector of matrices
        for (int i = 0; i < input.length; i++) {
            System.out.println("Attempting to read file '" + input[i] + "'...");
            rawData.add(readObservations(input[i], zone, dateFormat, valDelims, conditions));
            System.out.println("done.");
        }
        return rawData;
    }

    /**
     * Generic read method for which a date format and number of rows to skip in
     * the header can be specified.  The file may contain forecasts, observations
     * or paired data.  The first column must contain dates in the specified format.
     *
     * @param input the files to read
     * @param dateFormat the date format string
     * @param valDelims the data value delimiter(s)
     * @param timeZone the time zone
     * @param skipRows the number of header rows to skip
     * @param nV the null value
     * @return the paired data set
     */

    public static DoubleMatrix2D[] read(File[] input, String dateFormat, String valDelims, 
            TimeZone timeZone, int skipRows, double nV) throws IOException {
        String originalFormat = PairedFileIO.getDateFormat();
        PairedFileIO.setASCIIDateFormat(dateFormat);
        Vector<DoubleMatrix2D> rr = new Vector<DoubleMatrix2D>();
        for (int i = 0; i < input.length; i++) {
            System.out.println("Attempting to read file '" + input[i] + "'...");
            rr.add(PairedFileIO.readText(input[i], valDelims, timeZone, false, skipRows, nV).getPairs());
            System.out.println("done.");
        }
        PairedFileIO.setASCIIDateFormat(originalFormat);
        return rr.toArray(new DoubleMatrix2D[rr.size()]);
    }

    /**
     * Reads a file containing observations and returns a vector of matrices, which 
     * may be input to the pairing process.  Each matrix contains the data from 
     * one file.  The first column contains the time in hours from the epoch and the 
     * remaining columns contain the data.  
     *
     * @param file the input file
     * @param timeZone the time zone
     * @param dateFormat the date format string
     * @param valDelims the data value delimiter(s)
     * @param conditions an array of conditions upon which to restrict reading (may be null)
     * @return a matrix containing the data
     */
    
    public static DoubleMatrix2D readObservations(File file, TimeZone timeZone, String dateFormat, String valDelims, ConditionArray conditions) throws IOException {
        if(!StringUtilities.isCheckDateFormat(dateFormat)) {
            System.err.println("WARNING: date format '"+dateFormat+"' for file "+file+" was not a common type. Double-check that "
                    + "the specified format is the intended format, as format strings are case sensitive (e.g. m=minute, M=month).");
        }
        BufferedReader in = null;
        try {
            BufferedInputStream bIN = new BufferedInputStream(new FileInputStream(file));
            in = new BufferedReader(new InputStreamReader(bIN));
            String line = null;
            Vector<double[]> tempData = new Vector<double[]>();
            
            //Number of date tokens, and date token separators
            int dateTokens = -999;
            Vector<String> sep = new Vector<String>();            
            
            while ((line = in.readLine()) != null) {
//                StringTokenizer stb = new StringTokenizer(line, "-/, \t\n\r\f", false);
//                String valDelims = ", \t\n\r\f";  //Delimiters for reading values
//                int m = Integer.parseInt(stb.nextToken());
//                int d = Integer.parseInt(stb.nextToken());
//                int y = Integer.parseInt(stb.nextToken());
//                int h = Integer.parseInt(stb.nextToken());
//                Calendar cal = Calendar.getInstance();
//                cal.clear();
//                //Set as if UTC calendar, then update for the hour offset later
//                //This is critical because, otherwise, the individual date elements
//                //need to be changed to the correct values for their time zones
//
//                cal.setTimeZone(TimeZone.getTimeZone("UTC"));
//                cal.set(cal.YEAR, y);
//                cal.set(cal.MONTH,PairedFileIO.getCalMonthFromAct(m));
//                cal.set(cal.DAY_OF_MONTH, d);
//                cal.set(cal.HOUR_OF_DAY,h);

                //Determine the number of tokens in the date format for the first time
                StringTokenizer stb = new StringTokenizer(line, valDelims, false);
                if (dateTokens == -999) {
                    StringTokenizer std = new StringTokenizer(dateFormat, valDelims, false);
                    dateTokens = std.countTokens();
                    if (dateTokens == 0) {
                        dateTokens = 1;
                    }
                    std = new StringTokenizer(dateFormat, valDelims, true);
                    while(std.hasMoreTokens()) {
                        String nx = std.nextToken();
                        if(valDelims.contains(nx)) {
                            sep.add(nx);
                        }
                    }
                }
                //Read the date token 
                StringBuilder buf = new StringBuilder();
                for (int i = 0; i < dateTokens; ++i) {
                    if(i==0) {
                        buf.append(stb.nextToken());
                    } else {
                        buf.append(sep.get(i-1));
                        buf.append(stb.nextToken());
                    }
                }

                Calendar cal = StringUtilities.parseDate(buf.toString(),dateFormat,timeZone,false);

                if(cal==null) {
                    throw new IOException("Could not parse dates in file "
                            + ""+file+" using date format "+dateFormat+".");
                }

                long millis = cal.getTimeInMillis();   //UTC!!!
//                //Update for time zone offset                
//                millis = millis - timeZone.getRawOffset();
                double hours = millis/(1000.0*60.0*60.0);  //Hours relative to the epoch
                String obsString = stb.nextToken(valDelims);
                double obs = new Double(obsString);
                
                double[] nextLine = new double[2];
                nextLine[0]=hours;
                nextLine[1]=obs;
                tempData.add(nextLine);
            }
            //Construct the matrix
            double[][] data = new double[tempData.size()][2];
            for (int i = 0; i < data.length; i++) {
                data[i] = tempData.get(i);
            }
            DoubleMatrix2D returnMe = new DenseDoubleMatrix2D(data);
            if(conditions!=null) {
                returnMe = conditions.apply(returnMe,Condition.OBSERVED_DATA);
            }
            return returnMe;
        } finally {
            if(in != null) {
                try {
                    in.close();
                }
                catch(Exception e) {
                    //Do nothing
                }
            }
        }                 
    } 
    
    /**
     * Reads a file containing ensemble forecasts and returns a matrix containing
     * the data.  The first column contains the time in hours from the epoch and the 
     * remaining columns contain the data. The maximum lead time, start and end
     * dates may be null. 
     *
     * @param file the input file
     * @param timeZone the time zone
     * @param dateFormat the date format string
     * @param valDelims the data value delimiter(s)
     * @param conditions an array of conditions upon which to restrict reading
     * @param nV the null value
     * @return a matrix containing the data
     */
    
    public static DoubleMatrix2D readForecasts(File file,TimeZone timeZone, String dateFormat, 
            String valDelims,ConditionArray conditions,double nV) throws IOException {
        BufferedReader in = null;
        if(!StringUtilities.isCheckDateFormat(dateFormat)) {
            System.err.println("WARNING: date format '"+dateFormat+"' for file "+file+" was not a common type. Double-check that "
                    + "the specified format is the intended format, as format strings are case sensitive (e.g. m=minute, M=month).");
        }
        try {
            BufferedInputStream bIN = new BufferedInputStream(new FileInputStream(file));
            in = new BufferedReader(new InputStreamReader(bIN));
            String line = null;
            int maxCols = 0;
            Vector<double[]> tempData = new Vector<double[]>();
             
            //Number of date tokens, and date token separators
            int dateTokens = -999;
            Vector<String> sep = new Vector<String>();
            
            while ((line = in.readLine()) != null) {
//                StringTokenizer stb = new StringTokenizer(line, "-/, \t\n\r\f", false); //Reading dates
//                String valDelims = ", \t\n\r\f";  //Delimiters for reading values
//                int m = Integer.parseInt(stb.nextToken());
//                int d = Integer.parseInt(stb.nextToken());
//                int y = Integer.parseInt(stb.nextToken());
//                int h = Integer.parseInt(stb.nextToken());
//                Calendar cal = Calendar.getInstance();
//                cal.clear();
//                //Set as if UTC calendar, then update for the hour offset later
//                //This is critical because, otherwise, the individual date elements
//                //need to be changed to the correct values for their time zones
//
//                cal.setTimeZone(TimeZone.getTimeZone("UTC"));
//                cal.set(cal.YEAR, y);
//                cal.set(cal.MONTH,PairedFileIO.getCalMonthFromAct(m));
//                cal.set(cal.DAY_OF_MONTH, d);
//                cal.set(cal.HOUR_OF_DAY,h);

                //Determine the number of tokens in the date format for the first time
                StringTokenizer stb = new StringTokenizer(line, valDelims, false);
                if (dateTokens == -999) {
                    StringTokenizer std = new StringTokenizer(dateFormat, valDelims, false);
                    dateTokens = std.countTokens();
                    if (dateTokens == 0) {
                        dateTokens = 1;
                    }
                    std = new StringTokenizer(dateFormat, valDelims, true);
                    while(std.hasMoreTokens()) {
                        String nx = std.nextToken();
                        if(valDelims.contains(nx)) {
                            sep.add(nx);
                        }
                    }
                }
                //Read the date token 
                StringBuilder buf = new StringBuilder();
                for (int i = 0; i < dateTokens; ++i) {
                    if(i==0) {
                        buf.append(stb.nextToken());
                    } else {
                        buf.append(sep.get(i-1));
                        buf.append(stb.nextToken());
                    }
                }
                                
                Calendar cal = StringUtilities.parseDate(buf.toString(),dateFormat,timeZone,false);

                if(cal==null) {
                    throw new IOException("Could not parse dates in file "
                            + ""+file+" using date format "+dateFormat+". "
                            + "Date string attempting to parse: '"+buf+"'");
                }

                long millis = cal.getTimeInMillis();  //UTC!!!
                //Update for time zone offset
//                millis = millis - timeZone.getRawOffset();
                double hours = millis/(1000.0*60.0*60.0);  //Hours relative to the epoch
                double lead = new Double(stb.nextToken());

                //Read data
                Vector<Double> vec = new Vector<Double>();
                while (stb.hasMoreTokens()) {
                    vec.add(new Double(stb.nextToken(valDelims)));
                }
                int tot = vec.size();
                if (tot < 1) {
                    throw new IOException("Forecast files must contain at least 3 columns, "
                            + "comprising [Valid time, Lead time, Forecast 1,...]. Only found "
                            + "" + (tot + 2) + " columns.");
                }
                double[] nextLine = new double[tot + 2];
                nextLine[0] = hours;
                nextLine[1] = lead;
                for (int i = 0; i < tot; i++) {
                    nextLine[i + 2] = vec.get(i);
                }
                tempData.add(nextLine);
                if (nextLine.length > maxCols) {
                    maxCols = nextLine.length;
                }
            }
            //Check that data were read
            if(tempData.isEmpty()) {
                String message = "No appropriate data were found in file '"+file+"'.";
                throw new IOException(message);
            }

            //Construct the paired matrix
            double[][] data = new double[tempData.size()][maxCols];
            for (int i = 0; i < data.length; i++) {
                //Must explicitly initialize for the full space required: allocation 
                //of a 1D array in a 2D array is NOT sufficient
                double[] nextD = new double[maxCols];
                Arrays.fill(nextD,nV);
                System.arraycopy(tempData.get(i), 0, nextD, 0, tempData.get(i).length);
                data[i] = nextD;
            }
            DoubleMatrix2D returnMe = new DenseDoubleMatrix2D(data);
            if(conditions!=null) {
                returnMe = conditions.apply(returnMe,Condition.FORECAST_DATA);
            }
            return returnMe;            
        } finally {
            if(in != null) {
                try {
                    in.close();
                }
                catch(Exception e) {
                    //Do nothing
                }
            }
        }                 
    }

    /**
     * Writes a flat text format file from an input dataset with dates in the
     * first column.   Throws an exception if the date format is not supported.
     * See {@link evs.utilities.StringUtilities} for supported types.
     *
     * @param d the data with dates in the first column
     * @param output the output file
     * @param sep the separator string
     * @param dateFormat the date format for writing
     */

    public static void write(DoubleMatrix2D d, File output, String sep, String dateFormat) throws IOException {
        if(dateFormat!=null) {
            PairedFileIO.setASCIIDateFormat(dateFormat);
        }
        PairedFileIO.writeASCIIPairs(d, output, sep);
    }

/*******************************************************************************
 *                                                                             *
 *                                  TEST METHOD                                *
 *                                                                             *
 ******************************************************************************/     
    
    /**
     * Test method.
     *
     * @param args the args
     */
    
    public static void main(String[] args) {
    
//        try {
//            File f = new File("F:/Data/Processed_data/Observations/NWRFC/NCEP_QPE/NWRFC.OBS");
//            ASCIIFileIO check = new ASCIIFileIO();
//            Vector<DoubleMatrix2D> ch2 = check.readObservations(new File[]{f},
//                    TimeZone.getTimeZone("UTC"),null,null);
//            DoubleMatrix2D m = ch2.get(0);
//            //Compute average positive precip.
////            m = m.subRowsbyColCond(evs.utilities.mathutil.FunctionLibrary.isGreater(0.0),1,-999.0);
////            System.out.println(evs.utilities.mathutil.FunctionLibrary.mean().apply(m.getColumnAt(1),-999));
//            double[] obs = (double[])m.getColumnAt(1).getMatrixValues();
//            for(int i = 0; i < obs.length; i++) {
//                if(obs[i]!=-999.0) {
//                    obs[i]=obs[i]*25.4;
//                }
//            }
//
//
//            double[] incs = new double[201];
//            for(int i = 0; i < incs.length; i++) {
//                incs[i]=evs.utilities.mathutil.Mathematics.round(i*0.005,4);
//            }
//            double[][] cdf = evs.utilities.mathutil.EmpiricalCDFCalculator.getEmpiricalCDF(obs,incs,-999.0,true,true,false);
//            System.out.println(new DenseDoubleMatrix2D(cdf).transpose());
//
////            while(p<=1.0) {
////                p = p+0.01;
////                double v = evs.utilities.mathutil.EmpiricalCDFCalculator.getVal(obs,p,-999,false);
////                System.out.println(p+"  "+v);
////            }
//        } catch(Exception e) {
//            e.printStackTrace();
//        }



//        try {
//            //File f1 = new File("C:/Documents and Settings/brownj/Desktop/Test_observations.obsvd");
//            //File f2 = new File("D:/HEP_projects/Ensemble_verification/Test_data/NCEP_GFS_data/GFS_ensembles_12_hourly_04_08_agg_paired.txt");
//            File f3 = new File("C:/Documents and Settings/James Brown/Desktop/EVS_TEST/GLOO2_Ens_Formatted_EVS_CC.txt");
//            File f4 = new File("C:/Documents and Settings/James Brown/Desktop/EVS_TEST/testobs.txt");
//            
//            Calendar st = null;
//            Calendar en = null;
//            
//            ASCIIFileIO check = new ASCIIFileIO();
//            //System.out.println(check.isOfType(f1));
//            //System.out.println(check.isOfType(f2));
//            //Vector<DoubleMatrix2D> ch = check.readObservations(new File[]{f1},TimeZone.getTimeZone("UTC"),st,en);
//            //Vector<DoubleMatrix2D> ch2 = check.readForecasts(new File[]{f2},TimeZone.getTimeZone("UTC"),120.0,st,en);
//            
//            //System.out.println(ch.get(0));      
//            //System.out.println(ch2.get(0));
//            
//            Vector<DoubleMatrix2D> ch2 = check.readForecasts(new File[]{f3},TimeZone.getTimeZone("UTC"),null,st,en);
//            //Vector<DoubleMatrix2D> ch3 = check.readObservations(new File[]{f4},TimeZone.getTimeZone("UTC"),st,en);
//            System.out.println(ch2.get(0)); 
//            
//        } catch(Exception e) {
//            e.printStackTrace();
//        }
    }   
    
}
