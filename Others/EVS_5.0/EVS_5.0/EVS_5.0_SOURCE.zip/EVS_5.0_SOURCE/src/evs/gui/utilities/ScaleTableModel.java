package evs.gui.utilities;

//Java swing dependencies
import javax.swing.table.DefaultTableModel;
import javax.swing.DefaultCellEditor;
import javax.swing.table.TableCellEditor;

//Java util dependencies
import java.util.Vector;

//EVS dependencies
import evs.analysisunits.scale.Support;
import evs.analysisunits.scale.TemporalSupport;
import evs.analysisunits.scale.InvalidSupportException;
import evs.analysisunits.scale.MeasurementUnitsChangeLibrary;
import evs.data.fileio.GlobalUnitsReader;
import evs.utilities.mathutil.FunctionLibrary;   
import evs.utilities.mathutil.Function;
import evs.utilities.mathutil.DoubleOperation;

/**
 * Table for storing support information.  
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ScaleTableModel extends DefaultTableModel {

/*******************************************************************************
*                                                                              *
*                              INSTANCE VARIABLES                              *
*                                                                              *
*******************************************************************************/     

    /**
     * Table cell editors.
     */
    
    private Object[][] eds;
    
    /**
     * Editing status of the table rows and columns
     */
    
    private boolean[][] canEdit;   
    
    /**
     * Copy of editing status for enabling/disabling the table for editing.
     */
    
    private boolean[][] canEditCopy;

/*******************************************************************************
 *                                                                             *
 *                               CONSTRUCTOR                                   *
 *                                                                             *
 ******************************************************************************/     
        
    /**
     * Constructs an empty support table model.
     */
    
    public ScaleTableModel() {
        constructTable();
    }
    
    /**
     * Constructs a support table model with a specified support object.
     *
     * @param support the support
     */
    
    public ScaleTableModel(Support support) throws IllegalArgumentException {
        constructTable();
        setSupport(support);
    }

/*******************************************************************************
 *                                                                             *
 *                              ACCESSOR METHODS                               *
 *                                                                             *
 ******************************************************************************/  
    
    /**
     * Returns true if the table cell is editable.
     *
     * @param rowIndex the row index
     * @param columnIndex the columnIndex
     * @return true if the table cell is editable
     */
    
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return canEdit[rowIndex][columnIndex];
    }
    
    /**
     * Returns the table cell editors for the support values.
     *
     * @return the table cell editors
     */

    public Object[][] getCellEditors() {
        return eds;
    }
    
    /**
     * Returns true if the scale is valid, false otherwise.
     *
     * @return true if the scale is valid
     */
    
    public boolean hasValidSupport() {
        try {
            getSupport();
            return true;
        }
        catch(Exception e) {
            return false;
        }
    }
    
    /**
     * Returns true if some scale information has been input, false otherwise
     *
     * @return true if some scale information exists
     */
    
    public boolean hasSupportInput() {
        for(int i = 0; i < getRowCount(); i++) {
            if(!(getValueAt(i,1)+"").equals("")) {
                return true;
            }
        }
        return false;
    }    
    
    /**
     * Attempts to parse a support object from the information in the table.
     *
     * @return a support object
     */
    
    public TemporalSupport getSupport() throws InvalidSupportException {
        try {
            TemporalSupport t = null;

            //Accept partial selections
            acceptInputs();
            
            //Construct the support for this object
            Object aggFunc = getValueAt(0,1);
            Object aggPeriod = getValueAt(1,1);
            Object aggPeriodUnits = getValueAt(2,1);
            Object existingAttUnits = getValueAt(3,1);
            Object targetAttUnits = getValueAt(4,1);
            Object attChangeMult = getValueAt(5,1);
            Object notes = getValueAt(6,1)+"";

            //Check inputs
            //The existingAttUnits and aggPeriodUnits are automatically set if instantaneous support is selected
            //And are otherwise required
            if(aggFunc==null || existingAttUnits==null || aggPeriodUnits==null) {
                throw new InvalidSupportException("Some scale information is missing: enter values for each required category.");
            }

            Function func = null;
            //Multiplier
            if (attChangeMult != null && !attChangeMult.equals("")) {
                double d = new Double(attChangeMult+"");
                //No longer read the old default multiplier of 1.0, since the
                //multiplier is now an optional entry that is taken in precedent
                //to an explicit unit-to-unit conversion
                if (d != 1.0) {
                    func = FunctionLibrary.mult(d);
                    System.out.println("Found custom multiplier for attribute units. "
                            + "This will be used to convert the existing attributes '" + existingAttUnits + "' to "
                            + "the new attribute units '" + targetAttUnits + "'.");
                }
            }
            //Explicit target attribute units
            if (targetAttUnits != null && !targetAttUnits.equals("")) {
                if (func == null) {  //Use custom multiplier by default
                    func = MeasurementUnitsChangeLibrary.getMeasureUnitsChangeFunc(existingAttUnits+"",targetAttUnits+"");
                } 
            }
            if (aggFunc.toString().equalsIgnoreCase("INSTANTANEOUS")) {
                t = new TemporalSupport(existingAttUnits+"");
            } else {
                t = new TemporalSupport(existingAttUnits+"", new Double(aggPeriod+""),aggPeriodUnits+"",aggFunc+"");
            }
            if (notes != null) {
                t.setNotes(notes+"");
            }
            if (func != null || (targetAttUnits != null && !targetAttUnits.equals(""))) {
                t.setTargetMeasurementUnitsFunc(func,targetAttUnits+"");  //Throws an exception if one is null
            }
            return t;
        }      
        catch (NumberFormatException f) {
            f.printStackTrace();
            throw new InvalidSupportException("Some scale information is missing: enter correct values for each required category.");
        }
    }
    
/*******************************************************************************
 *                                                                             *
 *                               MUTATOR METHODS                               *
 *                                                                             *
 ******************************************************************************/    
    
    /**
     * Sets the support object for the current table.
     *
     * @param support the support
     */
    
    public void setSupport(Support support) {
        if(support instanceof TemporalSupport) {
            TemporalSupport s = (TemporalSupport)support;
            String function = s.getAggregationFunction();
            super.setValueAt(function,0,1);
            if(function.equals("INSTANTANEOUS")) {
                super.setValueAt(ScaleTableRenderer.NULL_TYPE,1,1);
                super.setValueAt(ScaleTableRenderer.NULL_TYPE,2,1);
            } else {
                super.setValueAt(new Double(s.getAggregationPeriod()),1,1);
                super.setValueAt(s.getAggregationUnits(),2,1);
            }
            super.setValueAt(s.getMeasurementUnits(),3,1);
            if(s.hasTargetMeasurementUnits()) {
                super.setValueAt(s.getTargetMeasurementUnits(),4,1);
                String f = s.getTargetMeasurementUnitsFunc().toString();
                //Set any custom multiplier only
                if (f.equalsIgnoreCase("mult")) {
                    double d = ((DoubleOperation) s.getTargetMeasurementUnitsFunc()).getConstants()[0];
                    super.setValueAt(d, 5, 1);
                }
            }
            super.setValueAt(s.getNotes(),6,1);
        }
    }
    
    /**
     * Accepts all partial or complete inputs.
     */
    
    public void acceptInputs() {
        if(eds!=null) {
            for(int i = 0; i < eds.length; i++) {
                for(int j = 0; j < eds[0].length; j++) {
                    if(isCellEditable(i,j) && eds[i][j]!=null) {
                        ((TableCellEditor)eds[i][j]).stopCellEditing();
                    }
                }
            }
        }
    }
    
    /**
     * Returns the model to its default status.
     */
    
    public void clearSupport() {
        int length = getRowCount();
        for(int i = 0; i < length; i++) {
            super.setValueAt("",i,1);
        }
    }
    
    /**
     * Overrides the superclass method to conditionally set the support values.
     * The method is only called by the cell editors.
     *
     * @param obj the cell value
     * @param row the row index
     * @param column the column index
     */
    
    public void setValueAt(Object obj, int row, int column) {
        super.setValueAt(obj,row,column);
        if(row == 0 && column == 1) {
            if(getValueAt(0,1) != null && getValueAt(0,1).equals("INSTANTANEOUS")) {
                canEdit[1][1] = false;
                canEdit[2][1] = false;
                super.setValueAt(ScaleTableRenderer.NULL_TYPE,1,1);  //Clear existing selections
                super.setValueAt(ScaleTableRenderer.NULL_TYPE,2,1);  //Units also not required               
            } else {
                canEdit[1][1] = true;
                canEdit[2][1] = true;
                super.setValueAt(null,1,1);  //Clear existing selections
                super.setValueAt(null,2,1);  //Clear existing selections
            }
        }
    }
    
    /**
     * Sets the editing status for the table.
     *
     * @param enable is true to enable editing
     */
    
    public void setEditingEnabled(boolean enable) {
        //Set the copy
        if(canEditCopy == null) {
            canEditCopy = new boolean[canEdit.length][canEdit[0].length];
            for(int i = 0; i < canEdit.length; i++) {
                for(int j = 0; j < canEdit[0].length; j++) {
                    canEditCopy[i][j] = canEdit[i][j];
                }
            }        
        }
        if(enable) {
            for(int i = 0; i < canEdit.length; i++) {
                for(int j = 0; j < canEdit[0].length; j++) {
                    canEdit[i][j] = canEditCopy[i][j];
                }
            }
        }
        else {
            canEdit = new boolean[canEdit.length][canEdit[0].length];
        }
    }

/*******************************************************************************
 *                                                                             *
 *                              PRIVATE METHODS                                *
 *                                                                             *
 ******************************************************************************/       
    
    /**
     * Returns a combo-box with the given string categories for display in a table.
     *
     * @param categories the initial categories to display
     * @return a searchable combo box
     */
    private SearchableComboBox getComboBox(Vector categories) {
        return getComboBox(categories.toArray());            
    }    
    
    /**
     * Returns a combo-box with the given string categories for display in a table.
     *
     * @param categories the initial categories to display
     * @return a searchable combo box
     */
    private SearchableComboBox getComboBox(Object[] categories) {
        SearchableComboBox box = new SearchableComboBox(categories);
        box.setPreferredSize(new java.awt.Dimension(140, 22));
        box.setFont(new java.awt.Font("Tahoma", 0, 12));
        return box;            
    }    
    
    /**
     * Constructs an empty support table model with a specified type.
     */    
    
    private void constructTable() {
        setDataVector(new Object [][] {
            {"Temporal statistic", null},
            {"Period of aggregation",null},
            {"Temporal units",null},           
            {"Attribute units", null},
            {"Target attribute units (optional unit conversion)", null},
            {"Multiplier for target units (for conversions not in library)", null},
            {"Notes", null},
        },
        new String [] {
            "Variable", "Value"
        });
        eds = new Object[7][2];
        String[] funcs = FunctionLibrary.getSupportedAggregationFunctions();
        String[] funcs2 = new String[funcs.length+1];
        //Add the point support
        funcs2[0] = "INSTANTANEOUS";
        //Display functions as upper case
        for(int i = 1; i < funcs2.length; i++) {
            funcs2[i] = funcs[i-1].toUpperCase();
        }
        eds[0][1] = new DefaultCellEditor(getComboBox(funcs2));
        eds[2][1] = new DefaultCellEditor(getComboBox(GlobalUnitsReader.getTimeUnits()));
        eds[3][1] = new DefaultCellEditor(getComboBox(GlobalUnitsReader.getContinuousNumericalUnits()));
        eds[4][1] = new DefaultCellEditor(getComboBox(GlobalUnitsReader.getContinuousNumericalUnits()));
        eds[5][1] = new DefaultCellEditor(new javax.swing.JTextField());
        eds[6][1] = new DefaultCellEditor(new javax.swing.JTextField());
        
        //Cell editing
        canEdit = new boolean [][] {
            {false, true},
            {false, true},
            {false, true},
            {false, true},
            {false, true},
            {false, true},
            {false, true}
        };
    }
    
}
