package evs.gui.windows;

//SwingWorker: use local version when backporting to Java 1.5
import evs.data.fileio.WriteOption;
import javax.swing.SwingWorker;
//import evs.gui.utilities.SwingWorker;

//Java swing dependencies
import javax.swing.*;

//Java awt dependencies
import java.awt.event.*;
import java.awt.*;

//Java io dependencies
import java.io.*;

//Java util dependencies
import java.util.*;

//JFreeChart dependencies
import org.jfree.chart.plot.*;
import org.jfree.data.*;
import org.jfree.chart.JFreeChart;

//EVS dependencies
import evs.metric.results.*;
import evs.metric.metrics.*;
import evs.metric.parameters.*;
import evs.analysisunits.*;
import evs.analysisunits.scale.*;
import evs.data.fileio.*;
import evs.gui.utilities.*;
import evs.utilities.*;
import evs.products.plots.defaults.*;
import evs.utilities.mathutil.*;

/**
 * Dialog for generating products from metric results.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ProductGeneratorDialog extends JDialog implements GUICommunicator {
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Construct the dialog with a parent frame.
     * 
     * @param showNavigation is true to show navigation buttons
     * @param showTitles is true to show window titles
     */
    
    protected ProductGeneratorDialog(boolean showNavigation, boolean showTitles) {
        super();
        initComponents();
        setTitle("Product generation options");

        //Hide navigation
        if(!showNavigation) {
            jPanel13.setVisible(false);
            jPanel43.setVisible(false);            
        }
        //Hide window titles
        if(!showTitles) {
            jPanel5.setBorder(javax.swing.BorderFactory.createEmptyBorder(3, 3, 3, 3));
            jPanel17.setBorder(javax.swing.BorderFactory.createEmptyBorder(3, 3, 3, 3));
        }
        //Set defaults
        setWriteOptions();
        wGraphicsCheckBox.setSelected(true);
        wNumericsCheckBox.setSelected(true);
        dialog = this;
    };
    
    /********************************************************************************
     *                                                                              *
     *                                   METHODS                                    *
     *                                                                              *
     *******************************************************************************/
    
    /**
     * Returns true if the graphics will be displayed, false otherwise.
     *
     * @return true if the graphics will be displayed
     */
    
    protected boolean getDisplayGraphics() {
        return dGraphicsCheckBox.isSelected();
    }
    
    /**
     * Returns true if the numerics will be displayed, false otherwise.
     *
     * @return true if the numerics will be displayed
     */
    
    protected boolean getDisplayNumerics() {
        return dNumericsCheckBox.isSelected();
    }    
    
    /**
     * Returns true if the graphics will be written, false otherwise.
     *
     * @return true if the graphics will be written
     */
    
    protected boolean getWriteGraphics() {
        return wGraphicsCheckBox.isSelected();
    }    
    
    /**
     * Returns true if the numerics will be written, false otherwise.
     *
     * @return true if the numerics will be written
     */
    
    protected boolean getWriteNumerics() {
        return wNumericsCheckBox.isSelected();
    }       
    
    /**
     * Returns the write options.
     *
     * @return the write options
     */
    
    protected WriteOption getWriteOptions() {
        return (WriteOption)wGraphicsBox.getSelectedItem();
    }
    
    /**
     * Returns the option pane.
     * 
     * @return the option pane
     */
    
    protected Component getOptionPane() {
        return mainTabbedPane;
    }
    
    /**
     * Clears all options.
     */
    
    protected void returnToDefaults() {
        wGraphicsCheckBox.setSelected(true);
        wNumericsCheckBox.setSelected(true);
        dGraphicsCheckBox.setSelected(false);
        dNumericsCheckBox.setSelected(false);
        wGraphicsBox.setSelectedIndex(0);
        wNumericsBox.setSelectedIndex(0);
    }
    
    /**
     * Generates and displays the specified products.
     *
     * @param res the results from which to generate products
     * @param dG is true to display graphics
     * @param wG is true to write graphics
     * @param dN is true to display numerics
     * @param wN is true to write numerics
     * @param write the additional charting options for the specified type
     * @param guiCall is true if calling this method from the GUI, false otherwise
     */
    
    protected static void generateProducts(final Vector<DisplayMetricResult> res, final boolean dG, final boolean wG, final boolean dN, final boolean wN, final WriteOption write, boolean guiCall) throws IllegalArgumentException {
        if(res == null || res.size() < 1) {
            throw new IllegalArgumentException("No products and/or lead times have been selected for generation.");
        }
        if(wG && write == null) {
            throw new IllegalArgumentException("Specify the format for writing graphics.");
        }
        
        if(!(dG || wG || dN || wN)) {
            throw new IllegalArgumentException("Select graphical or numerical output to write or display.");
        }
        
        boolean tempWrite = wN;
        
        //Must write numerics to display them
        if(dN && !wN) {
            int n = JOptionPane.showOptionDialog(EVSMainWindow.main,"Cannot display numerics without writing them also. Proceed?","Warning: data will be written", JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
            if(n == JOptionPane.NO_OPTION) {
                return;
            }
            tempWrite = true;
        }
                
        final boolean wNum = tempWrite;
        
        
        //Determine the number of plotable results
        int rCount = 0;
        int size = res.size();
        for(int i = 0; i < size; i++) {
            int tot = 1;
            if(!res.get(i).getSingleProduct()) {
                tot = res.get(i).getIncludeLeadCount();
            }
            rCount+=tot;
        }
        
        //Warn if more than 5 graphics to display
        if(dG && rCount > 5) {
            int n = JOptionPane.showOptionDialog(EVSMainWindow.main,"More than five graphics will be displayed.  Proceed?","Warning: display volume", JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
            if(n == JOptionPane.NO_OPTION) {
                return;
            }
        }
        //Warn if more than 5 sets of numerics to display
        if(dN && getMetricCount(res)>5) {
            int n = JOptionPane.showOptionDialog(EVSMainWindow.main,"More than five sets of numerical results will be displayed.  Proceed?","Warning: display volume", JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
            if(n == JOptionPane.NO_OPTION) {
                return;
            }
        }
        //Check the output folders for all results before continuing if writing is required
        if(wG || wNum) {
            int size2 = res.size();
            for(int k = 0; k < size2; k++) {
                AnalysisUnit an = res.get(k).getParentUnit();
                if(!an.hasOutputData()) {
                    throw new IllegalArgumentException("Could not write results for "+an+": no output folder defined.");
                }
            }
        }
        //Perform generation in a separate thread
        //Close this dialog first if visible
        if(dialog != null) {             
            dialog.setVisible(false);
        }
        final int totResults = rCount;
        if(guiCall) {
            final ProgressMonitor pro = new ProgressMonitor(EVSMainWindow.main);
            SwingWorker worker = new SwingWorker() {
                public Object doInBackground() {
                    pro.setThread(this);
                    pro.setProgress(0);  //Initialize
                    long start = System.currentTimeMillis();
                    generateProducts(res, dG, wG, dN, wNum, write,totResults,pro);
                    long stop = System.currentTimeMillis();
                    System.out.println("Time taken for output: " + Mathematics.round((stop - start) / 1000.0,1) + " seconds.");
                    return null;
                }
            };
            worker.execute();
            pro.setVisible(true);
        }
        else {
            generateProducts(res,dG,wG,dN,wNum,write,totResults,null);
        }
    }
    
    /**
     * Generates and displays the specified products.
     *
     * @param res the results from which to generate products
     * @param dG is true to display graphics
     * @param wG is true to write graphics
     * @param dN is true to display numerics
     * @param wN is true to write numerics
     * @param write the additional charting options for the specified type
     * @param totResults the total number of results to write
     * @param progress monitor, can be null
     */
    
    private static void generateProducts(final Vector<DisplayMetricResult> res, final boolean dG, final boolean wG, final boolean dN, final boolean wN, final WriteOption write, int totResults, ProgressMonitor pro) throws IllegalArgumentException {

        Vector<ChartDialog> dialogs = new Vector();
        
        try {

            //Approximate percent complete by assigning equal time to each write or display event 
            double totalEvents = 0.0;
            if (wN) {
                totalEvents += res.size() * 2;  //Two numerical results for each metric
            }
            if (dN) {
                totalEvents += res.size() * 2;  //One numerical result for each metric
            }
            if (dG) {
                totalEvents += totResults;  //One graphic for each lead time
            }
            if (wG) {
                totalEvents += totResults;  //One graphic for each lead time
            }

            double prog = 0;
            double inc = 100.0 / totalEvents;

            //Graphics to write or display
            if (wG || dG) {
                //Display and/or write
                int total = res.size();
                for (int j = 0; j < total; j++) {
                    DisplayMetricResult dis = res.get(j);
                    MetricResultByLeadTime m2 = dis.getResult();

                    //Max absolute lead number for determining padding of lead time
                    double maxLead = Math.max(Math.abs(m2.getFirstLeadTime()),Math.abs(m2.getLastLeadTime()));
                    int maxLeadC = (((int)Math.abs(maxLead))+"").length();
                                
                    //Single result to display?
                    TreeMap<Double, MetricResult> displayMe = new TreeMap();
                    //Results include multiple plots for score decompositions

                    boolean incDecomp = false;
                    if (dis.getSingleProduct()) {
                        //Add score decompositions
                        if (dis.getResult().getLowestLevelResultID() == MetricResult.ENSEMBLE_SCORE_DECOMPOSITION_RESULT) {
                            DecomposableScore s = (DecomposableScore) ((ThresholdMetricStore) dis.getParentMetric()).getFirstMetricInStore();
                            //Determine if this is a climatological skill score, 
                            //in which case certain components will not be available
                            boolean climSkill = false;
                            if (s instanceof BrierSkillScore || s instanceof MeanContRankProbSkillScore) {
                                ReferenceForecastParameter p = ((SkillScore) s).getRefFcst();
                                if (p.isSampleClimatology()) {
                                    climSkill = true;
                                }
                            }
                            if (s.willDecompose()) {
                                int type = s.getScoreDecType();
                                switch(type) {
                                    case DecomposableScore.CALIBRATION_REFINEMENT : {
                                        //Use dummy times to store score decompositions
                                        displayMe.put(-999.0, m2.getResultsForScoreComp(DecomposableScore.OVERALL_SCORE));
                                        if(s instanceof MeanContRankProbScore || s instanceof MeanContRankProbSkillScore) {
                                            displayMe.put(-998.0, m2.getResultsForScoreComp(DecomposableScore.POTENTIAL));
                                        }
                                        displayMe.put(-997.0, m2.getResultsForScoreComp(DecomposableScore.RELIABILITY));
                                        displayMe.put(-996.0, m2.getResultsForScoreComp(DecomposableScore.RESOLUTION));
                                        if(!climSkill) {
                                            displayMe.put(-995.0, m2.getResultsForScoreComp(DecomposableScore.UNCERTAINTY));
                                        }
                                    }; break;
                                    case DecomposableScore.LIKELIHOOD_BASE_RATE : {
                                        //Use dummy times to store score decompositions
                                        displayMe.put(-999.0, m2.getResultsForScoreComp(DecomposableScore.OVERALL_SCORE));
                                        displayMe.put(-994.0, m2.getResultsForScoreComp(DecomposableScore.TYPE_II_BIAS));
                                        displayMe.put(-993.0, m2.getResultsForScoreComp(DecomposableScore.DISCRIMINATION));
                                        displayMe.put(-992.0, m2.getResultsForScoreComp(DecomposableScore.SHARPNESS));
                                    }; break;
                                    case DecomposableScore.CR_AND_LBR : {
                                        //Use dummy times to store score decompositions
                                        displayMe.put(-999.0, m2.getResultsForScoreComp(DecomposableScore.OVERALL_SCORE));
                                        displayMe.put(-997.0, m2.getResultsForScoreComp(DecomposableScore.RELIABILITY));
                                        displayMe.put(-996.0, m2.getResultsForScoreComp(DecomposableScore.RESOLUTION));
                                        if(!climSkill) {
                                            displayMe.put(-995.0, m2.getResultsForScoreComp(DecomposableScore.UNCERTAINTY));
                                        }
                                        displayMe.put(-994.0, m2.getResultsForScoreComp(DecomposableScore.TYPE_II_BIAS));
                                        displayMe.put(-993.0, m2.getResultsForScoreComp(DecomposableScore.DISCRIMINATION));
                                        displayMe.put(-992.0, m2.getResultsForScoreComp(DecomposableScore.SHARPNESS));
//                                        if(!climSkill) {
//                                            displayMe.put(-991.0, m2.getResultsForScoreComp(DecomposableScore.SCORE_GIVEN_OBS_TRUE));
//                                            displayMe.put(-990.0, m2.getResultsForScoreComp(DecomposableScore.SCORE_GIVEN_OBS_FALSE));
//                                            displayMe.put(-989.0, m2.getResultsForScoreComp(DecomposableScore.TYPE_II_BIAS_GIVEN_OBS_TRUE));
//                                            displayMe.put(-988.0, m2.getResultsForScoreComp(DecomposableScore.TYPE_II_BIAS_GIVEN_OBS_FALSE));
//                                            displayMe.put(-987.0, m2.getResultsForScoreComp(DecomposableScore.DISCRIMINATION_GIVEN_OBS_TRUE));
//                                            displayMe.put(-986.0, m2.getResultsForScoreComp(DecomposableScore.DISCRIMINATION_GIVEN_OBS_FALSE));
//                                        }
                                    }; break;
                                }
                                incDecomp = true;
                            } else {
                                displayMe.put(-999.0, m2.getResultsForScoreComp(DecomposableScore.OVERALL_SCORE));  //Dummy time
                            }
                        } else {
                            displayMe.put(-999.0, m2);  //Dummy time
                        }
                    } else {
                        displayMe = m2.getResults();
                    }

                    //Iterate through the results to display
                    Iterator k = displayMe.keySet().iterator();

                    ChartDialog chD = null;

                    Vector<XYPlot> reRange = new Vector();
                    Vector<Object[]> reRangedGraphics = new Vector();
                    
                    while (k.hasNext()) {
                        
                        double nxt = (Double) k.next();
                        String decompName = "";
                        MetricResult m = displayMe.get(nxt);

                        //Only include non-null results
                        if (m != null) {

                            String key = "";

                            Metric parent = dis.getParentMetric();
                            int ident = parent.getID();
                            Integer additional = null;

                            //Change identity if score decomposition
                            if (incDecomp) {
                                switch ((int) nxt) {
                                    case -999:
                                        additional = DecomposableScore.OVERALL_SCORE;
                                        decompName=DecomposableScore.OVERALL_SCORE_STRING;
                                        break;
                                    case -998:
                                        additional = DecomposableScore.POTENTIAL;
                                        decompName=DecomposableScore.POTENTIAL_STRING;
                                        break;
                                    case -997:
                                        additional = DecomposableScore.RELIABILITY;
                                        decompName=DecomposableScore.RELIABILITY_STRING;
                                        break;
                                    case -996:
                                        additional = DecomposableScore.RESOLUTION;
                                        decompName=DecomposableScore.RESOLUTION_STRING;
                                        break;
                                    case -995:
                                        additional = DecomposableScore.UNCERTAINTY;
                                        decompName=DecomposableScore.UNCERTAINTY_STRING;
                                        break;
                                    case -994:
                                        additional = DecomposableScore.TYPE_II_BIAS;
                                        decompName=DecomposableScore.TYPE_II_BIAS_STRING;
                                        break;
                                    case -993:
                                        additional = DecomposableScore.DISCRIMINATION;
                                        decompName=DecomposableScore.DISCRIMINATION_STRING;
                                        break;
                                    case -992:
                                        additional = DecomposableScore.SHARPNESS;
                                        decompName=DecomposableScore.SHARPNESS_STRING;
                                        break;
//                                    case -991:
//                                        additional = DecomposableScore.SCORE_GIVEN_OBS_TRUE;
//                                        decompName=DecomposableScore.SCORE_GIVEN_OBS_TRUE_STRING;
//                                        break;
//                                    case -990:
//                                        additional = DecomposableScore.SCORE_GIVEN_OBS_FALSE;
//                                        decompName=DecomposableScore.SCORE_GIVEN_OBS_FALSE_STRING;
//                                        break;
//                                    case -989:
//                                        additional = DecomposableScore.TYPE_II_BIAS_GIVEN_OBS_TRUE;
//                                        decompName=DecomposableScore.TYPE_II_BIAS_GIVEN_OBS_TRUE_STRING;
//                                        break;
//                                    case -988:
//                                        additional = DecomposableScore.TYPE_II_BIAS_GIVEN_OBS_FALSE;
//                                        decompName=DecomposableScore.TYPE_II_BIAS_GIVEN_OBS_FALSE_STRING;
//                                        break;
//                                    case -987:
//                                        additional = DecomposableScore.DISCRIMINATION_GIVEN_OBS_TRUE;
//                                        decompName=DecomposableScore.DISCRIMINATION_GIVEN_OBS_TRUE_STRING;
//                                        break;
//                                    case -986:
//                                        additional = DecomposableScore.DISCRIMINATION_GIVEN_OBS_FALSE;
//                                        decompName=DecomposableScore.DISCRIMINATION_GIVEN_OBS_FALSE_STRING;
//                                        break;
                                }
                            }
                            //Set frequency type for rank histogram
                            if (parent instanceof ThresholdMetricStore) {
                                Metric b = ((ThresholdMetricStore) parent).getFirstMetricInStore();
                                if (b instanceof RankHistogram) {
                                    if(((RankHistogram)b).isRelativeFreq()) {
                                        additional = RankHistogramPlot.RELATIVE;
                                    } else {
                                        additional = RankHistogramPlot.ABSOLUTE;
                                    }
                                }
                            }
                            
                            //Proceed if one of the types allowed for plotting
                            if (!incDecomp || (incDecomp && additional != null)) {
                                JFreeChart ch = ChartFactory.getDefaultChart(ident, additional);

                                AnalysisUnit an = dis.getParentUnit();
                                String app = an.toString();
                                if (nxt != -999 && !incDecomp) {  //Multiple results, implies results per lead time unless score decomp.

                                    //Pad key to max lead with zeros
                                    int nxtC = (((int) Math.abs(nxt)) + "").length();
                                    if (maxLeadC > nxtC) {
                                        key = StringUtilities.getPaddedNumber(nxt, maxLeadC - nxtC);
                                    } else {
                                        key = nxt + "";
                                    }

                                    app = app + " at lead hour " + nxt;
                                }
                                //Add text on conditions
                                if (an.hasValueConditions() && !dis.getParentMetric().willIgnoreConditions()) {
                                    if (an.hasDateCondition()) {
                                        app = app + " with conditions on dates and variable value.";
                                    } else {
                                        app = app + " with conditions on variable value.";
                                    }
                                } else {
                                    if (an.hasDateCondition()) {
                                        app = app + " with conditions on dates.";
                                    }
                                }
                                //Add the dataset to the plot
                                EVSPlot plot = (EVSPlot) ch.getPlot();
                                reRange.add(ch.getXYPlot());

                                String nL = System.getProperty("line.separator");

                                //Reference forecast
                                if (parent instanceof ThresholdMetricStore) {
                                    Metric b = ((ThresholdMetricStore) parent).getFirstMetricInStore();
                                    if (b instanceof SkillScore) {
                                        app = app + " (reference forecast: " + ((SkillScore) b).getRefFcst().getParVal() + ")";
                                    }
                                }
                                ch.setTitle(ch.getTitle().getText() + nL + app);

                                plot.addDataset(dis.toString(), m);

                                //Add information on error units for those plots in real units
                                if (parent.hasRealUnits() && plot instanceof RealValuedPlot) {
                                    int s = Support.OBSERVED_SUPPORT;
                                    Support su = null;
                                    if (an instanceof VerificationUnit && ((VerificationUnit) an).hasSupport(s)) {
                                        su = ((VerificationUnit) an).getSupport(s);
                                    } else if (an instanceof AggregationUnit && ((AggregationUnit) an).hasVerificationUnits()) {
                                        if (((AggregationUnit) an).getVerificationUnits().get(0).hasSupport(s)) {
                                            su = ((AggregationUnit) an).getVerificationUnits().get(0).getSupport(s);
                                        }
                                    }
                                    if (su != null) {
                                        if (su.hasTargetMeasurementUnits()) {
                                            ((RealValuedPlot) plot).setRealUnits(su.getTargetMeasurementUnits());
                                        } else {
                                            ((RealValuedPlot) plot).setRealUnits(su.getMeasurementUnits());
                                        }
                                    }
                                }

                                //Display graphics
                                if (dG) {
                                    if (chD == null) {
                                        if (displayMe.size() == 1) {
                                            chD = new ChartDialog("Chart window", ch);
                                            dialogs.add(chD);
                                        } //Construct an empty dialog and add a tab
                                        else {
                                            if (incDecomp) {
                                                chD = new ChartDialog("Chart collection by score decomposition for '" + dis.getParentMetric().getName() + "'");
                                                dialogs.add(chD);
                                                chD.addChart("SCORE", ch);  //First case

                                            } else {
                                                chD = new ChartDialog("Chart collection by lead time for '" + dis.getParentMetric().getName() + "'");
                                                dialogs.add(chD);
                                                chD.addChart(nxt + "", ch);
                                            }

                                        }
                                    } else {
                                        //Decomposition results (first case is the overall score, added above)
                                        if (incDecomp) {
                                            chD.addChart(decompName, ch);
                                        } else {
                                            chD.addChart(nxt + "", ch);
                                        }
                                    }
                                    if (incDecomp) {
                                        if (nxt == -999) {  //Update first event only, not additional decomposition events
                                            prog += inc;
                                        }
                                    } else {
                                        prog += inc;
                                    }
                                    if (pro != null) {
                                        pro.setProgress((int) prog);
                                    }
                                }

                                //Write graphics
                                if (wG) {
                                	
                                	//Check that the output path is available
                                	if(!an.hasWriteableOutputPath()) {
                                    	throw new IOException("Could not find a valid output path for one or more products associated with " +
                                    			"unit '"+an+"': "+an.getOutputData());
                                    }
                                	
                                    //Name the file
                                    char c = AnalysisUnit.getIDSepChar();
                                    String append = "";
                                    if (!dis.getSingleProduct()) {
                                        append = c + "" + key;
                                    }
                                    String name = "" + an + c + dis.getParentMetric() + append;
                                    if (incDecomp && !decompName.equals("")) { //Add decomposition key for everything except the first result (total score)
                                        name = name + "_" + decompName;
                                    }
                                    name = StringUtilities.removeWhiteSpace(name, "_");
                                    name = name.replaceAll("\\|", "GIVEN");
                                    name = name.replaceAll("!", "NOT_");
                                    File f = null;
                                    try {
                                        final ArrayList<String> optP = write.getPars();
                                        int gWriteOption = write.getID();
                                        switch (gWriteOption) {
                                            //JPEG output
                                            case WriteOption.JPEG_GRAPHICS: {
                                                //File, quality, chart, width, height
                                                f = new File(((File) an.getOutputData().getData()).getAbsolutePath(), name + ".jpg");
                                                reRangedGraphics.add(new Object[]{WriteOption.JPEG_GRAPHICS, f, new Float(optP.get(2) + ""), ch, new Integer(optP.get(0) + ""), new Integer(optP.get(1) + "")});
                                            }
                                            ;
                                            break;
                                            //PNG output
                                            case WriteOption.PNG_GRAPHICS: {
                                                //File, chart, width, height, null, false, compression
                                                f = new File(((File) an.getOutputData().getData()).getAbsolutePath(), name + ".png");
                                                reRangedGraphics.add(new Object[]{WriteOption.PNG_GRAPHICS, f, ch, new Integer(optP.get(0) + ""), new Integer(optP.get(1) + ""), null, false, new Integer(optP.get(2) + "")});
                                            }
                                            ;
                                            break;
                                            //SVG output
                                            case WriteOption.SVG_GRAPHICS: {
                                                //File, chart, width, height
                                                f = new File(((File) an.getOutputData().getData()).getAbsolutePath(), name + ".svg");
                                                reRangedGraphics.add(new Object[]{WriteOption.SVG_GRAPHICS, f, ch, new Integer(optP.get(0) + ""), new Integer(optP.get(1) + "")});
                                            }
                                            ;
                                            break;

                                        }
                                    } catch (NumberFormatException n) {
                                        throw new IllegalArgumentException("Incorrect input for one or more graphics options.");
                                    }
                                }
                            }
                        }
                    }

                    //Coordinate the axis ranges for comparisons between times
                    int totR = reRange.size();
                    if (totR > 1) {
                        Range newXRange = reRange.get(0).getDomainAxis().getRange();
                        Range newYRange = reRange.get(0).getRangeAxis().getRange();
                        for (int i = 1; i < totR; i++) {
                            newXRange = newXRange.combine(newXRange, reRange.get(i).getDomainAxis().getRange());
                            newYRange = newYRange.combine(newYRange, reRange.get(i).getRangeAxis().getRange());
                        }
                        //Set the new ranges
                        for (int i = 0; i < totR; i++) {
                            reRange.get(i).getDomainAxis().setRange(newXRange);
                            reRange.get(i).getRangeAxis().setRange(newYRange);
                        }
                    }

                    //Write the re-ranged graphics
                    int tot = reRangedGraphics.size();
                    if (tot > 0) {
                        for (int i = 0; i < tot; i++) {
                            Object[] data = (Object[]) reRangedGraphics.get(i);
                            Integer type = (Integer) data[0];
                            switch (type) {
                                //JPEG output
                                case WriteOption.JPEG_GRAPHICS: {
                                    EVSChartUtilities.saveChartAsJPEG((File) data[1], (Float) data[2], (JFreeChart) data[3], (Integer) data[4], (Integer) data[5]);
                                }; break;
                                //PNG output
                                case WriteOption.PNG_GRAPHICS: {
                                    EVSChartUtilities.saveChartAsPNG((File) data[1], (JFreeChart) data[2], (Integer) data[3], (Integer) data[4], (org.jfree.chart.ChartRenderingInfo) data[5], (Boolean) data[6], (Integer) data[7]);
                                }; break;
                                //SVG output
                                case WriteOption.SVG_GRAPHICS: {
                                    Rectangle bounds = new Rectangle((Integer) data[3], (Integer) data[4]);
                                    EVSChartUtilities.saveChartAsSVG((JFreeChart) data[2],bounds, (File) data[1]);
                                }; break;
                            }
                            if (incDecomp) {
                                if (i == 0) {  //Update first event only, not additional decomposition events
                                    prog += inc;
                                }
                            } else {
                                prog += inc;
                            }
                            if (pro != null) {
                                pro.setProgress((int) prog);
                            }
                        }
                    }

                    //if (chD != null) {
                        //chD.setVisible(true);
                    //}
                }
            }
            //Numerics to write and possibly display
            if (wN) {
                //Writeable numerics
                TreeMap<String, MetricResultByLeadTime> writeMe = getWriteableNumerics(res);
                //Write the numerics
                Iterator i = writeMe.keySet().iterator();
                File[] written = new File[writeMe.size()];

                //Only increment progress for numerics that are not sample counts
                //as the sample counts were not included in the standard increment above.

                int tot = 0;
                while (i.hasNext()) {
                    String next = i.next() + "";
                    written[tot] = new File(next);
                    ResultFileIO.write(written[tot], writeMe.get(next));
                    //if(!written[tot].getName().contains("sample_counts")) {
                    prog += inc;
                    //}
                    tot++;
                    if (pro != null) {
                        pro.setProgress((int) prog);
                    }
                }

                //Display in default browser
                if (dN) {
                    for (int j = 0; j < written.length; j++) {
                        BrowserControl.displayURL(written[j].toURI().toURL().toString());
                        //if(written[j] != null && !written[j].getName().contains("sample_counts")) {
                        prog += inc;
                        //}
                        if (pro != null) {
                            pro.setProgress((int) prog);
                        }
                    }
                }
            }
            if (pro != null) {
                pro.setVisible(false); //Finish quietly
            }
            final ProductGeneratorDialog di = dialog;
            if (di != null) {
                di.exit(); //Exit dialog if displayed
            }
            if (pro != null) {
                pro.stop(" complete.", true); //Clean up the thread
            }
            //Now display created charts
            if(dialogs.size()>0) {
                int tot = dialogs.size();
                for(int i = 0; i < tot; i++) {
                    dialogs.get(i).setVisible(true);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            if (pro != null) {
                CONSOLE.addMessage(StringUtilities.stackTraceToString(e));
                pro.stop(" stopped.", false);
            }
        } //Occurs when even a single (set of) attribute(s) cannot be written
        catch (OutOfMemoryError f) {
            f.printStackTrace();
            if (pro != null) {
                CONSOLE.addMessage(StringUtilities.stackTraceToString(f));
                pro.stop(" stopped.", false);
            }
        } 
    }
    
    /**
     * Returns a map of numerics to write, where each map key contains the absolute
     * path of a file to write and each map value contains a metric result by lead
     * period. Throws an exception if a valid output path is not available for 
     * any metrics.
     *
     * @param res the results
     * @return a map of writable numerics
     */
    
    private static TreeMap<String,MetricResultByLeadTime> getWriteableNumerics(Vector<DisplayMetricResult> res) 
    		throws IOException {
        TreeMap<String,MetricResultByLeadTime> returnMe = new TreeMap();
        int length = res.size();
        double nV = GlobalUnitsReader.getDefaultNullValue();
        for(int i = 0; i < length; i++) {
            DisplayMetricResult dis = res.get(i);
            AnalysisUnit an = dis.getParentUnit();
            if(!an.hasWriteableOutputPath()) {
            	throw new IOException("Could not find a valid output path for one or more products associated with " +
            			"unit '"+an+"': "+an.getOutputData());
            }
            Metric parentM = dis.getParentMetric();
            char c = AnalysisUnit.getIDSepChar();
            String name = ""+an+c+parentM;
            name = StringUtilities.removeWhiteSpace(name,"_");
            File f = new File(((File)an.getOutputData().getData()).getAbsolutePath(),name+".xml");
            String path = f.getAbsolutePath();
            MetricResultByLeadTime result = dis.getResult();

            //Strip any null columns from MEP diagram: this is handled separately for the graphics
            //This is not essential, but improves readability for cases when the MEP diagram contains
            //a large number of duplicate points, which are returned as null.
            
            //Add metadata on sample counts etc. for stores of threshold metrics
            if(parentM instanceof ThresholdMetricStore) {
                //Only write score decompositions when decomposition was requested (i.e. 
                //when the components are not null values).  Otherwise, store as a double result.
                if(dis.getResult().getLowestLevelResultID()==MetricResult.ENSEMBLE_SCORE_DECOMPOSITION_RESULT) {
                    Metric s = ((ThresholdMetricStore)parentM).getFirstMetricInStore();
                    if(s instanceof ScoreMetric) {
                        if(!((ScoreMetric)s).getDecompose()) {
                            result = result.getResultsForScoreComp(DecomposableScore.OVERALL_SCORE);
                        }
                    }
                } else if(((ThresholdMetricStore) parentM).getFirstMetricInStore()
                        instanceof MeanErrorOfProbabilityDiagram) {
                    result = stripNullsFromMEPResult(result,nV);
                }
                try {
                    File f2 = new File(((File)an.getOutputData().getData()).getAbsolutePath(),name+"_metadata.xml");
                    String path2 = f2.getAbsolutePath();
                    returnMe.put(path2,((ThresholdMetricStore)parentM).getThresholdMetadata(dis.getForecastType()));
                } catch(Exception e) {
                    System.out.println("Could not write metadata for metric "+parentM+" of "+an+" due to the following errors: ");
                    System.out.println(evs.utilities.StringUtilities.stackTraceToString(e));
                }
            }
            returnMe.put(path,result);

            //Add sample counts for other metrics
            //else if(parentM.hasSampleCounts(dis.getForecastType())) {
            //    try {
            //        File f2 = new File(((File)an.getOutputData().getData()).getAbsolutePath(),name+"_sample_counts.xml");
            //        String path2 = f2.getAbsolutePath();
            //        returnMe.put(path2,(parentM.getSampleCounts(dis.getForecastType())));
            //    } catch(Exception e) {
            //        System.out.println("Could not write sample counts for metric "+parentM+" of "+an+" due to the following errors: ");
            //        System.out.println(evs.utilities.StringUtilities.stackTraceToString(e));
            //    }
            //}
        }
        return returnMe;
    }

    /**
     * Strips null columns from the MEP result, which can happen with a discontinuity
     * in probability.  Returns the result with null columns stripped for writing.
     *
     * @param result the result, potentially containing null columns
     * @param nV the null data value
     * @return the result with null columns stripped
     */

    private static MetricResultByLeadTime stripNullsFromMEPResult(MetricResultByLeadTime result, double nV) {
        TreeMap<Double,MetricResult> r = result.getResults();
        MetricResultByLeadTime newResult = new MetricResultByLeadTime(result.METRIC_RESULT_BY_THRESHOLD);
        Iterator timeIt = r.keySet().iterator();
        while(timeIt.hasNext()) {
            Double time = (Double)timeIt.next();
            MetricResultByThreshold nextThresh = (MetricResultByThreshold)r.get(time);
            MetricResultByThreshold newThreshResult = new MetricResultByThreshold(result.DOUBLE_MATRIX_2D_RESULT);
            TreeMap<DoubleProcedureParameter,MetricResult> tr = nextThresh.getResults();
            Iterator threshIt = tr.keySet().iterator();
            while(threshIt.hasNext()) {
                DoubleProcedureParameter pt = (DoubleProcedureParameter)threshIt.next();
                DoubleMatrix2DResult nextD = (DoubleMatrix2DResult)tr.get(pt);
                newThreshResult.addResult(pt,nextD.stripNullSamples(nV,0));
            }
            newResult.addResult(time,newThreshResult);
        }
        return newResult;
    }

    /**
     * Returns the number of unique metrics in the stored results
     *
     * @param res the results
     * @return the number of metrics
     */
    
    private static int getMetricCount(Vector<DisplayMetricResult> res) {
        TreeMap filter = new TreeMap();
        int length = res.size();
        for(int i = 0; i < length; i++) {
            filter.put(res.get(i).getParentMetric().getName(),"");
        }
        return filter.size();
    }
    
    /**
     * Sets the default writing options.
     */
    
    private void setWriteOptions() {
        wGraphicsBox.addItem(new WriteOption(WriteOption.PNG_GRAPHICS));
        wGraphicsBox.addItem(new WriteOption(WriteOption.JPEG_GRAPHICS));
        wGraphicsBox.addItem(new WriteOption(WriteOption.SVG_GRAPHICS));
        wNumericsBox.addItem(new WriteOption(WriteOption.XML_NUMERICS));
    } 

    /**
     * Sets the options for a specified graphic type.  See this class for supported 
     * types.
     *
     * @param id the graphics option identifier
     */
    
    private void setGraphicsOptions(int id) throws IllegalArgumentException {        
        Object item = wGraphicsBox.getSelectedItem();
        if(item == null) {
            throw new IllegalArgumentException("No item selected in graphics writing box.");
        }
        final ArrayList<String> pars = ((WriteOption) item).getPars();  //Default parameters
        switch (id) {
            //Remove all graphics options
            case NO_GRAPHICS: {
                wGraphicsOptionsLabel.setEnabled(false);
                wGraphicsOptionsPanel.removeAll();
            }
            ;
            break;
            //Display JPEG graphics options
            case WriteOption.JPEG_GRAPHICS: {
                setJPEGOptions(pars);
            }
            ;
            break;
            //Display PNG graphics options
            case WriteOption.PNG_GRAPHICS: {
                setPNGOptions(pars);
            }
            ;
            break;
            //Display SVG graphics options
            case WriteOption.SVG_GRAPHICS: {
                setSVGOptions(pars);
            }
            ;
            break;
            //Unrecognized option
            default: {
                throw new IllegalArgumentException("Unrecognised graphics option.");
            }
        }
    }

    /**
     * Sets the options for jpeg file creation.
     *
     * @param pars the option parameters
     */
    
    private void setJPEGOptions(final ArrayList<String> pars) {
        
        //Clear any existing components
        wGraphicsOptionsPanel.removeAll();
        //Generate the components
        JPanel widthPanel = new JPanel();
        JLabel widthLabel = new JLabel();
        final JTextField widthField = new JTextField();
        JPanel heightPanel = new JPanel();
        JLabel heightLabel = new JLabel();
        final JTextField heightField = new JTextField();
        JPanel qualityPanel = new JPanel();
        JLabel qualityLabel = new JLabel();
        final JTextField qualityField = new JTextField();
        
        wGraphicsOptionsPanel.setLayout(new BoxLayout(wGraphicsOptionsPanel, BoxLayout.Y_AXIS));
        
        widthPanel.setLayout(new BoxLayout(widthPanel, BoxLayout.X_AXIS));

        widthPanel.setMaximumSize(new Dimension(32000, 36));
        widthPanel.setMinimumSize(new Dimension(10, 36));
        widthPanel.setPreferredSize(new Dimension(10, 36));
        widthLabel.setText("Image width (pixels):");
        widthLabel.setMaximumSize(new Dimension(32000, 30));
        widthLabel.setMinimumSize(new Dimension(101, 30));
        widthLabel.setPreferredSize(new Dimension(200, 30));
        widthPanel.add(widthLabel);

        widthField.setMaximumSize(new Dimension(2147483647, 30));
        widthField.setMinimumSize(new Dimension(80, 30));
        widthField.setPreferredSize(new Dimension(80, 30));
        //Set the existing par value
        widthField.setText(pars.get(0)+"");
        //Add a listener to update the parameter
        widthField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent evt) {
                pars.set(0,widthField.getText());
            }
        });

        widthPanel.add(widthField);

        wGraphicsOptionsPanel.add(widthPanel);

        heightPanel.setLayout(new BoxLayout(heightPanel, BoxLayout.X_AXIS));

        heightPanel.setMaximumSize(new Dimension(32000, 36));
        heightPanel.setMinimumSize(new Dimension(10, 36));
        heightPanel.setPreferredSize(new Dimension(10, 36));
        heightLabel.setText("Image height (pixels):");
        heightLabel.setMaximumSize(new Dimension(32000, 30));
        heightLabel.setMinimumSize(new Dimension(101, 30));
        heightLabel.setPreferredSize(new Dimension(200, 30));
        heightPanel.add(heightLabel);

        heightField.setMaximumSize(new Dimension(2147483647, 30));
        heightField.setMinimumSize(new Dimension(80, 30));
        heightField.setPreferredSize(new Dimension(80, 30));
        //Set the existing par value
        heightField.setText(pars.get(1)+"");
        //Add a listener to update the parameter
        heightField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent evt) {
                pars.set(1,heightField.getText());
            }
        });

        heightPanel.add(heightField);

        wGraphicsOptionsPanel.add(heightPanel);

        qualityPanel.setLayout(new BoxLayout(qualityPanel, BoxLayout.X_AXIS));

        qualityPanel.setMaximumSize(new Dimension(32767, 36));
        qualityPanel.setMinimumSize(new Dimension(10, 36));
        qualityPanel.setPreferredSize(new Dimension(10, 36));
        qualityLabel.setText("Image quality (0.0-1.0):");
        qualityLabel.setMaximumSize(new Dimension(32000, 30));
        qualityLabel.setMinimumSize(new Dimension(101, 30));
        qualityLabel.setPreferredSize(new Dimension(200, 30));
        qualityPanel.add(qualityLabel);

        qualityField.setMaximumSize(new Dimension(2147483647, 30));
        qualityField.setMinimumSize(new Dimension(80, 30));
        qualityField.setPreferredSize(new Dimension(80, 30));
        //Set the existing par value
        qualityField.setText(pars.get(2)+"");
        //Add a listener to update the parameter
        qualityField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent evt) {
                pars.set(2,qualityField.getText());
            }
        });

        qualityPanel.add(qualityField);
        wGraphicsOptionsPanel.add(qualityPanel);        
        pack();
        wGraphicsOptionsPanel.updateUI();
    }
    
    /**
     * Sets the options for png file creation.
     *
     * @param pars the option parameters
     */
    
    private void setPNGOptions(final ArrayList<String> pars) {
        //Clear any existing components
        wGraphicsOptionsPanel.removeAll();
        //Generate the components
        JPanel widthPanel = new JPanel();
        JLabel widthLabel = new JLabel();
        final JTextField widthField = new JTextField();
        JPanel heightPanel = new JPanel();
        JLabel heightLabel = new JLabel();
        final JTextField heightField = new JTextField();
        JPanel compressionPanel = new JPanel();
        JLabel compressionLabel = new JLabel();
        final JTextField compressionField = new JTextField();
        
        wGraphicsOptionsPanel.setLayout(new BoxLayout(wGraphicsOptionsPanel, BoxLayout.Y_AXIS));
        
        widthPanel.setLayout(new BoxLayout(widthPanel, BoxLayout.X_AXIS));

        widthPanel.setMaximumSize(new Dimension(32000, 36));
        widthPanel.setMinimumSize(new Dimension(10, 36));
        widthPanel.setPreferredSize(new Dimension(10, 36));
        widthLabel.setText("Image width (pixels):");
        widthLabel.setMaximumSize(new Dimension(32000, 30));
        widthLabel.setMinimumSize(new Dimension(101, 30));
        widthLabel.setPreferredSize(new Dimension(200, 30));
        widthPanel.add(widthLabel);

        widthField.setMaximumSize(new Dimension(2147483647, 30));
        widthField.setMinimumSize(new Dimension(11, 30));
        widthField.setPreferredSize(new Dimension(11, 30));
        //Set the existing par value
        widthField.setText(pars.get(0)+"");
        //Add a listener to update the parameter
        widthField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent evt) {
                pars.set(0,widthField.getText());
            }
        });

        widthPanel.add(widthField);

        wGraphicsOptionsPanel.add(widthPanel);

        heightPanel.setLayout(new BoxLayout(heightPanel, BoxLayout.X_AXIS));

        heightPanel.setMaximumSize(new Dimension(32000, 36));
        heightPanel.setMinimumSize(new Dimension(10, 36));
        heightPanel.setPreferredSize(new Dimension(10, 36));
        heightLabel.setText("Image height (pixels):");
        heightLabel.setMaximumSize(new Dimension(32000, 30));
        heightLabel.setMinimumSize(new Dimension(101, 30));
        heightLabel.setPreferredSize(new Dimension(200, 30));
        heightPanel.add(heightLabel);

        heightField.setMaximumSize(new Dimension(2147483647, 30));
        heightField.setMinimumSize(new Dimension(11, 30));
        heightField.setPreferredSize(new Dimension(11, 30));
        //Set the existing par value
        heightField.setText(pars.get(1)+"");
        //Add a listener to update the parameter
        heightField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent evt) {
                pars.set(1,heightField.getText());
            }
        });

        heightPanel.add(heightField);

        wGraphicsOptionsPanel.add(heightPanel);

        compressionPanel.setLayout(new BoxLayout(compressionPanel, BoxLayout.X_AXIS));

        compressionPanel.setMaximumSize(new Dimension(32767, 36));
        compressionPanel.setMinimumSize(new Dimension(10, 36));
        compressionPanel.setPreferredSize(new Dimension(10, 36));
        compressionLabel.setText("Image compression (0-9):");
        compressionLabel.setMaximumSize(new Dimension(32000, 30));
        compressionLabel.setMinimumSize(new Dimension(101, 30));
        compressionLabel.setPreferredSize(new Dimension(200, 30));
        compressionPanel.add(compressionLabel);

        compressionField.setMaximumSize(new Dimension(2147483647, 30));
        compressionField.setMinimumSize(new Dimension(11, 30));
        compressionField.setPreferredSize(new Dimension(11, 30));
        //Set the existing par value
        compressionField.setText(pars.get(2)+"");
        //Add a listener to update the parameter
        compressionField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent evt) {
                pars.set(2,compressionField.getText());
            }
        });

        compressionPanel.add(compressionField);
        wGraphicsOptionsPanel.add(compressionPanel);     
        pack();
        wGraphicsOptionsPanel.updateUI();
    }    
    
    /**
     * Sets the options for svg file creation.
     *
     * @param pars the option parameters
     */
    
    private void setSVGOptions(final ArrayList<String> pars) {

        //Clear any existing components
        wGraphicsOptionsPanel.removeAll();
        //Generate the components
        JPanel widthPanel = new JPanel();
        JLabel widthLabel = new JLabel();
        final JTextField widthField = new JTextField();
        JPanel heightPanel = new JPanel();
        JLabel heightLabel = new JLabel();
        final JTextField heightField = new JTextField();
        
        wGraphicsOptionsPanel.setLayout(new BoxLayout(wGraphicsOptionsPanel, BoxLayout.Y_AXIS));
        
        widthPanel.setLayout(new BoxLayout(widthPanel, BoxLayout.X_AXIS));

        widthPanel.setMaximumSize(new Dimension(32000, 36));
        widthPanel.setMinimumSize(new Dimension(10, 36));
        widthPanel.setPreferredSize(new Dimension(10, 36));
        widthLabel.setText("Image width:");
        widthLabel.setMaximumSize(new Dimension(32000, 30));
        widthLabel.setMinimumSize(new Dimension(101, 30));
        widthLabel.setPreferredSize(new Dimension(200, 30));
        widthPanel.add(widthLabel);

        widthField.setMaximumSize(new Dimension(2147483647, 30));
        widthField.setMinimumSize(new Dimension(11, 30));
        widthField.setPreferredSize(new Dimension(11, 30));
        //Set the existing par value
        widthField.setText(pars.get(0)+"");
        //Add a listener to update the parameter
        widthField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent evt) {
                pars.set(0,widthField.getText());
            }
        });

        widthPanel.add(widthField);

        wGraphicsOptionsPanel.add(widthPanel);

        heightPanel.setLayout(new BoxLayout(heightPanel, BoxLayout.X_AXIS));

        heightPanel.setMaximumSize(new Dimension(32000, 36));
        heightPanel.setMinimumSize(new Dimension(10, 36));
        heightPanel.setPreferredSize(new Dimension(10, 36));
        heightLabel.setText("Image height:");
        heightLabel.setMaximumSize(new Dimension(32000, 30));
        heightLabel.setMinimumSize(new Dimension(101, 30));
        heightLabel.setPreferredSize(new Dimension(200, 30));
        heightPanel.add(heightLabel);

        heightField.setMaximumSize(new Dimension(2147483647, 30));
        heightField.setMinimumSize(new Dimension(11, 30));
        heightField.setPreferredSize(new Dimension(11, 30));
        //Set the existing par value
        heightField.setText(pars.get(1)+"");
        //Add a listener to update the parameter
        heightField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent evt) {
                pars.set(1,heightField.getText());
            }
        });

        heightPanel.add(heightField);

        wGraphicsOptionsPanel.add(heightPanel);
        wGraphicsOptionsPanel.repaint();
        pack();
        wGraphicsOptionsPanel.updateUI();
    }    
        
    /**
     * Initializes the window components.
     */
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainTabbedPane = new javax.swing.JTabbedPane();
        writePanel = new javax.swing.JPanel();
        jPanel511 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        wGraphicsCheckBox = new javax.swing.JCheckBox();
        wGraphicsFormatLabel = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        wGraphicsBox = new javax.swing.JComboBox();
        wGraphicsOptionsLabel = new javax.swing.JLabel();
        wGraphicsOptionsPanel = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        wNumericsCheckBox = new javax.swing.JCheckBox();
        wNumericsFormatLabel = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        wNumericsBox = new javax.swing.JComboBox();
        jLabel4 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        cancelButton1 = new javax.swing.JButton();
        jPanel14121 = new javax.swing.JPanel();
        nextButton = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        displayPanel = new javax.swing.JPanel();
        jPanel512 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        dGraphicsCheckBox = new javax.swing.JCheckBox();
        jPanel28 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        dNumericsCheckBox = new javax.swing.JCheckBox();
        jPanel24 = new javax.swing.JPanel();
        jPanel43 = new javax.swing.JPanel();
        jPanel53 = new javax.swing.JPanel();
        jPanel45 = new javax.swing.JPanel();
        jPanel202 = new javax.swing.JPanel();
        cancelButton2 = new javax.swing.JButton();
        jPanel14124 = new javax.swing.JPanel();
        backButton = new javax.swing.JButton();
        jPanel141211 = new javax.swing.JPanel();
        saveButton = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();

        setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                closeDialog(evt);
            }
        });
        getContentPane().setLayout(new java.awt.GridLayout(1, 0));

        mainTabbedPane.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        mainTabbedPane.setMaximumSize(new java.awt.Dimension(32000, 32000));
        mainTabbedPane.setMinimumSize(new java.awt.Dimension(500, 350));
        mainTabbedPane.setPreferredSize(new java.awt.Dimension(500, 350));

        writePanel.setMaximumSize(new java.awt.Dimension(2147483647, 2147483647));
        writePanel.setMinimumSize(new java.awt.Dimension(500, 60));
        writePanel.setPreferredSize(new java.awt.Dimension(500, 65));
        writePanel.setLayout(new javax.swing.BoxLayout(writePanel, javax.swing.BoxLayout.Y_AXIS));

        jPanel511.setMaximumSize(new java.awt.Dimension(32000, 5));
        jPanel511.setMinimumSize(new java.awt.Dimension(500, 5));
        jPanel511.setPreferredSize(new java.awt.Dimension(500, 5));
        writePanel.add(jPanel511);

        jPanel17.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Options for writing output", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11), new java.awt.Color(0, 0, 0))); // NOI18N
        jPanel17.setMinimumSize(new java.awt.Dimension(120, 47));
        jPanel17.setPreferredSize(new java.awt.Dimension(32000, 2000));
        jPanel17.setLayout(new java.awt.GridLayout(1, 0));

        jPanel4.setLayout(new java.awt.GridLayout(1, 2, 5, 0));

        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Graphical output", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 11), new java.awt.Color(0, 0, 0))); // NOI18N
        jPanel8.setLayout(new javax.swing.BoxLayout(jPanel8, javax.swing.BoxLayout.Y_AXIS));

        wGraphicsCheckBox.setText("Write graphical output"); // NOI18N
        wGraphicsCheckBox.setAlignmentX(0.5F);
        wGraphicsCheckBox.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        wGraphicsCheckBox.setMargin(new java.awt.Insets(0, 0, 0, 0));
        wGraphicsCheckBox.setMaximumSize(new java.awt.Dimension(32000, 30));
        wGraphicsCheckBox.setMinimumSize(new java.awt.Dimension(73, 30));
        wGraphicsCheckBox.setPreferredSize(new java.awt.Dimension(73, 30));
        jPanel8.add(wGraphicsCheckBox);

        wGraphicsFormatLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        wGraphicsFormatLabel.setText("Output format:"); // NOI18N
        wGraphicsFormatLabel.setAlignmentX(0.5F);
        wGraphicsFormatLabel.setMaximumSize(new java.awt.Dimension(32000, 30));
        wGraphicsFormatLabel.setMinimumSize(new java.awt.Dimension(34, 30));
        wGraphicsFormatLabel.setPreferredSize(new java.awt.Dimension(34, 30));
        jPanel8.add(wGraphicsFormatLabel);

        jPanel9.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel9.setMinimumSize(new java.awt.Dimension(33, 30));
        jPanel9.setPreferredSize(new java.awt.Dimension(37, 30));
        jPanel9.setLayout(new javax.swing.BoxLayout(jPanel9, javax.swing.BoxLayout.LINE_AXIS));

        wGraphicsBox.setBackground(java.awt.Color.WHITE);
        wGraphicsBox.setMaximumSize(new java.awt.Dimension(200, 30));
        wGraphicsBox.setMinimumSize(new java.awt.Dimension(23, 30));
        wGraphicsBox.setPreferredSize(new java.awt.Dimension(27, 30));
        wGraphicsBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                wGraphicsBoxItemStateChanged(evt);
            }
        });
        jPanel9.add(wGraphicsBox);

        jPanel8.add(jPanel9);

        wGraphicsOptionsLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        wGraphicsOptionsLabel.setText("Options for selected output format:"); // NOI18N
        wGraphicsOptionsLabel.setAlignmentX(0.5F);
        wGraphicsOptionsLabel.setMaximumSize(new java.awt.Dimension(32000, 30));
        wGraphicsOptionsLabel.setMinimumSize(new java.awt.Dimension(34, 30));
        wGraphicsOptionsLabel.setPreferredSize(new java.awt.Dimension(34, 30));
        jPanel8.add(wGraphicsOptionsLabel);

        wGraphicsOptionsPanel.setMaximumSize(new java.awt.Dimension(32000, 32000));
        wGraphicsOptionsPanel.setLayout(new java.awt.GridLayout(1, 0));
        jPanel8.add(wGraphicsOptionsPanel);

        jPanel4.add(jPanel8);

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Numerical output", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 11), new java.awt.Color(0, 0, 0))); // NOI18N
        jPanel6.setLayout(new javax.swing.BoxLayout(jPanel6, javax.swing.BoxLayout.Y_AXIS));

        wNumericsCheckBox.setText("Write numerical output"); // NOI18N
        wNumericsCheckBox.setAlignmentX(0.5F);
        wNumericsCheckBox.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        wNumericsCheckBox.setMargin(new java.awt.Insets(0, 0, 0, 0));
        wNumericsCheckBox.setMaximumSize(new java.awt.Dimension(32000, 30));
        wNumericsCheckBox.setMinimumSize(new java.awt.Dimension(73, 30));
        wNumericsCheckBox.setPreferredSize(new java.awt.Dimension(73, 30));
        jPanel6.add(wNumericsCheckBox);

        wNumericsFormatLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        wNumericsFormatLabel.setText("Output format:"); // NOI18N
        wNumericsFormatLabel.setAlignmentX(0.5F);
        wNumericsFormatLabel.setMaximumSize(new java.awt.Dimension(32000, 30));
        wNumericsFormatLabel.setMinimumSize(new java.awt.Dimension(34, 30));
        wNumericsFormatLabel.setPreferredSize(new java.awt.Dimension(34, 30));
        jPanel6.add(wNumericsFormatLabel);

        jPanel11.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel11.setMinimumSize(new java.awt.Dimension(33, 30));
        jPanel11.setPreferredSize(new java.awt.Dimension(37, 30));
        jPanel11.setLayout(new javax.swing.BoxLayout(jPanel11, javax.swing.BoxLayout.LINE_AXIS));

        wNumericsBox.setBackground(java.awt.Color.WHITE);
        wNumericsBox.setMaximumSize(new java.awt.Dimension(200, 30));
        wNumericsBox.setMinimumSize(new java.awt.Dimension(23, 30));
        wNumericsBox.setPreferredSize(new java.awt.Dimension(27, 30));
        jPanel11.add(wNumericsBox);

        jPanel6.add(jPanel11);

        jLabel4.setAlignmentX(0.5F);
        jLabel4.setMaximumSize(new java.awt.Dimension(32000, 30));
        jLabel4.setMinimumSize(new java.awt.Dimension(34, 30));
        jLabel4.setPreferredSize(new java.awt.Dimension(34, 30));
        jPanel6.add(jLabel4);
        jPanel6.add(jPanel10);

        jPanel4.add(jPanel6);

        jPanel17.add(jPanel4);

        writePanel.add(jPanel17);

        jPanel13.setMaximumSize(new java.awt.Dimension(65676, 35));
        jPanel13.setMinimumSize(new java.awt.Dimension(150, 30));
        jPanel13.setPreferredSize(new java.awt.Dimension(300, 35));
        jPanel13.setLayout(new javax.swing.BoxLayout(jPanel13, javax.swing.BoxLayout.Y_AXIS));

        jPanel1.setMaximumSize(new java.awt.Dimension(32000, 2));
        jPanel1.setMinimumSize(new java.awt.Dimension(500, 2));
        jPanel1.setPreferredSize(new java.awt.Dimension(500, 2));
        jPanel13.add(jPanel1);

        jPanel15.setMaximumSize(new java.awt.Dimension(32899, 35));
        jPanel15.setMinimumSize(new java.awt.Dimension(142, 30));
        jPanel15.setPreferredSize(new java.awt.Dimension(144, 35));
        jPanel15.setLayout(new javax.swing.BoxLayout(jPanel15, javax.swing.BoxLayout.LINE_AXIS));

        jPanel20.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel15.add(jPanel20);

        cancelButton1.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        cancelButton1.setText("Cancel"); // NOI18N
        cancelButton1.setMargin(new java.awt.Insets(2, 10, 2, 10));
        cancelButton1.setMaximumSize(new java.awt.Dimension(65, 29));
        cancelButton1.setMinimumSize(new java.awt.Dimension(65, 29));
        cancelButton1.setPreferredSize(new java.awt.Dimension(65, 29));
        cancelButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButton1ActionPerformed(evt);
            }
        });
        jPanel15.add(cancelButton1);

        jPanel14121.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel14121.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel14121.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel15.add(jPanel14121);

        nextButton.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        nextButton.setText("Next"); // NOI18N
        nextButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        nextButton.setMaximumSize(new java.awt.Dimension(65, 29));
        nextButton.setMinimumSize(new java.awt.Dimension(65, 29));
        nextButton.setPreferredSize(new java.awt.Dimension(65, 29));
        nextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextButtonActionPerformed(evt);
            }
        });
        jPanel15.add(nextButton);

        jPanel2.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel2.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel2.setPreferredSize(new java.awt.Dimension(2, 10));
        jPanel15.add(jPanel2);

        jPanel13.add(jPanel15);

        writePanel.add(jPanel13);

        mainTabbedPane.addTab("Write      ", writePanel);

        displayPanel.setMinimumSize(new java.awt.Dimension(500, 65));
        displayPanel.setPreferredSize(new java.awt.Dimension(500, 60));
        displayPanel.setLayout(new javax.swing.BoxLayout(displayPanel, javax.swing.BoxLayout.Y_AXIS));

        jPanel512.setMaximumSize(new java.awt.Dimension(32000, 5));
        jPanel512.setMinimumSize(new java.awt.Dimension(500, 5));
        jPanel512.setPreferredSize(new java.awt.Dimension(500, 5));
        displayPanel.add(jPanel512);

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Options for displaying output", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11), new java.awt.Color(0, 0, 0))); // NOI18N
        jPanel5.setMinimumSize(new java.awt.Dimension(120, 47));
        jPanel5.setPreferredSize(new java.awt.Dimension(32000, 2000));
        jPanel5.setLayout(new java.awt.GridLayout(1, 0));

        jPanel12.setLayout(new java.awt.GridLayout(1, 2, 5, 0));

        jPanel21.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Graphical output", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 11), new java.awt.Color(0, 0, 0))); // NOI18N
        jPanel21.setLayout(new javax.swing.BoxLayout(jPanel21, javax.swing.BoxLayout.Y_AXIS));

        dGraphicsCheckBox.setText("Display graphical output"); // NOI18N
        dGraphicsCheckBox.setAlignmentX(0.5F);
        dGraphicsCheckBox.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        dGraphicsCheckBox.setMargin(new java.awt.Insets(0, 0, 0, 0));
        dGraphicsCheckBox.setMaximumSize(new java.awt.Dimension(32000, 30));
        dGraphicsCheckBox.setMinimumSize(new java.awt.Dimension(73, 30));
        dGraphicsCheckBox.setPreferredSize(new java.awt.Dimension(73, 30));
        jPanel21.add(dGraphicsCheckBox);
        jPanel21.add(jPanel28);

        jPanel12.add(jPanel21);

        jPanel22.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Numerical output", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 11), new java.awt.Color(0, 0, 0))); // NOI18N
        jPanel22.setLayout(new javax.swing.BoxLayout(jPanel22, javax.swing.BoxLayout.Y_AXIS));

        dNumericsCheckBox.setText("Display numerical output"); // NOI18N
        dNumericsCheckBox.setAlignmentX(0.5F);
        dNumericsCheckBox.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        dNumericsCheckBox.setMargin(new java.awt.Insets(0, 0, 0, 0));
        dNumericsCheckBox.setMaximumSize(new java.awt.Dimension(32000, 30));
        dNumericsCheckBox.setMinimumSize(new java.awt.Dimension(73, 30));
        dNumericsCheckBox.setPreferredSize(new java.awt.Dimension(73, 30));
        jPanel22.add(dNumericsCheckBox);
        jPanel22.add(jPanel24);

        jPanel12.add(jPanel22);

        jPanel5.add(jPanel12);

        displayPanel.add(jPanel5);

        jPanel43.setMaximumSize(new java.awt.Dimension(65676, 35));
        jPanel43.setMinimumSize(new java.awt.Dimension(150, 30));
        jPanel43.setPreferredSize(new java.awt.Dimension(300, 35));
        jPanel43.setLayout(new javax.swing.BoxLayout(jPanel43, javax.swing.BoxLayout.Y_AXIS));

        jPanel53.setMaximumSize(new java.awt.Dimension(32000, 2));
        jPanel53.setMinimumSize(new java.awt.Dimension(500, 2));
        jPanel53.setOpaque(false);
        jPanel53.setPreferredSize(new java.awt.Dimension(500, 2));
        jPanel53.setLayout(new javax.swing.BoxLayout(jPanel53, javax.swing.BoxLayout.LINE_AXIS));
        jPanel43.add(jPanel53);

        jPanel45.setMaximumSize(new java.awt.Dimension(32909, 35));
        jPanel45.setMinimumSize(new java.awt.Dimension(152, 30));
        jPanel45.setPreferredSize(new java.awt.Dimension(150, 35));
        jPanel45.setLayout(new javax.swing.BoxLayout(jPanel45, javax.swing.BoxLayout.LINE_AXIS));

        jPanel202.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel45.add(jPanel202);

        cancelButton2.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        cancelButton2.setText("Cancel"); // NOI18N
        cancelButton2.setMargin(new java.awt.Insets(2, 10, 2, 10));
        cancelButton2.setMaximumSize(new java.awt.Dimension(65, 29));
        cancelButton2.setMinimumSize(new java.awt.Dimension(65, 29));
        cancelButton2.setPreferredSize(new java.awt.Dimension(65, 29));
        cancelButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButton2ActionPerformed(evt);
            }
        });
        jPanel45.add(cancelButton2);

        jPanel14124.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel14124.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel14124.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel45.add(jPanel14124);

        backButton.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        backButton.setText("Back"); // NOI18N
        backButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        backButton.setMaximumSize(new java.awt.Dimension(65, 29));
        backButton.setMinimumSize(new java.awt.Dimension(65, 29));
        backButton.setPreferredSize(new java.awt.Dimension(65, 29));
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });
        jPanel45.add(backButton);

        jPanel141211.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel141211.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel141211.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel45.add(jPanel141211);

        saveButton.setFont(new java.awt.Font("Dialog", 1, 11)); // NOI18N
        saveButton.setText("Save"); // NOI18N
        saveButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        saveButton.setMaximumSize(new java.awt.Dimension(65, 29));
        saveButton.setMinimumSize(new java.awt.Dimension(65, 29));
        saveButton.setPreferredSize(new java.awt.Dimension(65, 29));
        saveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveButtonActionPerformed(evt);
            }
        });
        jPanel45.add(saveButton);

        jPanel3.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel3.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel3.setPreferredSize(new java.awt.Dimension(2, 10));
        jPanel45.add(jPanel3);

        jPanel43.add(jPanel45);

        displayPanel.add(jPanel43);

        mainTabbedPane.addTab("Display     ", displayPanel);

        getContentPane().add(mainTabbedPane);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * State change in the graphics writing box.
     *
     * @param evt a state change event
     */
    
    private void wGraphicsBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_wGraphicsBoxItemStateChanged
        if(wGraphicsBox.isEnabled()) {
            if(evt.getStateChange()==evt.SELECTED) {
                Object sel = wGraphicsBox.getSelectedItem();
                //Set display
                if (sel != null) {
                    setGraphicsOptions(((WriteOption) sel).getID());
                } //Clear display
                else {
                    setGraphicsOptions(NO_GRAPHICS);
                }
            }
        }
    }//GEN-LAST:event_wGraphicsBoxItemStateChanged
    
    /**
     * Cancels the dialog.
     *
     * @param evt an action event
     */
    
    private void cancelButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButton1ActionPerformed
        cancel();
    }//GEN-LAST:event_cancelButton1ActionPerformed
    
    /**
     * Moves to the next window.
     *
     * @param evt an action event
     */
    
    private void nextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextButtonActionPerformed
        mainTabbedPane.setSelectedIndex((mainTabbedPane.getSelectedIndex())+1);
    }//GEN-LAST:event_nextButtonActionPerformed
    
    /**
     * Cancels the dialog.
     *
     * @param evt an action event
     */
    
    private void cancelButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButton2ActionPerformed
        cancel();
    }//GEN-LAST:event_cancelButton2ActionPerformed
    
    /**
     * Moves to the previous window.
     *
     * @param evt an action event
     */
    
    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        mainTabbedPane.setSelectedIndex((mainTabbedPane.getSelectedIndex())-1);
    }//GEN-LAST:event_backButtonActionPerformed
    
    /**
     * Runs the product generation.
     *
     * @param evt an action event
     */
    
    private void saveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveButtonActionPerformed
        exit();
    }//GEN-LAST:event_saveButtonActionPerformed
    
    /**
     * Cancels the dialog, asking if any input conditions should be deleted.
     */
    
    private void cancel() {
        exit();
    }
    
    /**
     * Exits the dialog.
     *
     * @param evt a window event.
     */
    
    private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
        cancel();
    }//GEN-LAST:event_closeDialog
    
    /**
     * Exits.
     */
    
    private void exit() {
        setVisible(false);
        dispose();
    }
    
    /********************************************************************************
     *                                                                              *
     *                               CLASS VARIABLES                                *
     *                                                                              *
     *******************************************************************************/    
    
    /**
     * Identifier for no graphics writing options
     */
    
    public final int NO_GRAPHICS = 201;
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLES                              *
     *                                                                              *
     *******************************************************************************/
    
    /**
     * Instance of the product generator dialog.
     */
      
    private static ProductGeneratorDialog dialog = null;
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.JButton cancelButton1;
    private javax.swing.JButton cancelButton2;
    private javax.swing.JCheckBox dGraphicsCheckBox;
    private javax.swing.JCheckBox dNumericsCheckBox;
    private javax.swing.JPanel displayPanel;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14121;
    private javax.swing.JPanel jPanel141211;
    private javax.swing.JPanel jPanel14124;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel202;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel511;
    private javax.swing.JPanel jPanel512;
    private javax.swing.JPanel jPanel53;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JTabbedPane mainTabbedPane;
    private javax.swing.JButton nextButton;
    private javax.swing.JButton saveButton;
    private javax.swing.JComboBox wGraphicsBox;
    private javax.swing.JCheckBox wGraphicsCheckBox;
    private javax.swing.JLabel wGraphicsFormatLabel;
    private javax.swing.JLabel wGraphicsOptionsLabel;
    private javax.swing.JPanel wGraphicsOptionsPanel;
    private javax.swing.JComboBox wNumericsBox;
    private javax.swing.JCheckBox wNumericsCheckBox;
    private javax.swing.JLabel wNumericsFormatLabel;
    private javax.swing.JPanel writePanel;
    // End of variables declaration//GEN-END:variables
    
}
