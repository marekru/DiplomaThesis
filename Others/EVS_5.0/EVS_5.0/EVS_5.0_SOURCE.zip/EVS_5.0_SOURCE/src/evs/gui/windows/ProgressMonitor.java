package evs.gui.windows;

//SwingWorker: use local version when backporting to Java 1.5
import javax.swing.SwingWorker;
//import evs.gui.utilities.SwingWorker;

//Java swing dependencies
import javax.swing.*;

/**
 * Processing dialog which returns a boolean false on close.
 * 
 * @author evs@hydrosolved.com
 * @version 4.0
 */  

public class ProgressMonitor extends JDialog implements GUICommunicator{
    
/*******************************************************************************
 *                                                                             *
 *                               CONSTRUCTORS                                  *
 *                                                                             *
 ******************************************************************************/  
    
    /** 
     * Construct a progress monitor with a parent frame.
     *
     * @param parent the parent frame
     */
    
    protected ProgressMonitor(JFrame parent) {
        super(parent, true);
        initComponents();
        progressBar.setIndeterminate(false);
        progressBar.setMinimum(0);
        progressBar.setMaximum(100);
        EVSMainWindow.setWindowLocation(this);
    }
    
    /** 
     * Construct a progress monitor with a parent dialog.
     *
     * @param parent the parent dialog
     */
    
    protected ProgressMonitor(JDialog parent) {
        super(parent, true);
        initComponents();
        progressBar.setIndeterminate(false);
        progressBar.setMinimum(0);
        progressBar.setMaximum(100);
        EVSMainWindow.setWindowLocation(this);              
    }    
    
    /** 
     * Construct a progress monitor with a parent frame and an initial message.
     *
     * @param message the message
     * @param parent the parent frame
     */
    
    protected ProgressMonitor(JFrame parent, String message) {
        this(parent);
        setMessage(message);
    }
    
    /** 
     * Construct a progress monitor with a parent dialog and an initial message.
     *
     * @param message the message
     * @param parent the parent dialog
     */
    
    protected ProgressMonitor(JDialog parent, String message) {
        this(parent);           
        setMessage(message);
    }     
    
/*******************************************************************************
 *                                                                             *
 *                              PROTECTED METHODS                              *
 *                                                                             *
 ******************************************************************************/         
    
    /**
     * Returns true if the operation has terminated.
     *
     * @return true if the operation has terminated
     */
    
    protected boolean isStopped() {
        return stopped;
    }
    
    /**
     * Returns true if the operation terminated successfully.
     *
     * @return true if the operation terminated successfully
     */
    
    protected boolean wasSuccessful() {
        return success;
    }    
    
    /**
     * Allows (true) or disallows (false) cancellation of the process.
     *
     * @param allowed is true if cancellation is allowed
     */
    
    protected void setCancelEnabled(boolean allowed) {
        cancelButton.setVisible(allowed);
    }
    
    /**
     * Sets the percentage complete, removing an indeterminate status from the 
     * menu bar.  
     *
     * @param perc the percent complete
     */
    
    protected void setProgress(int perc) {
        if(! stopped) {
            if (perc > last) {
                progressBar.setValue(perc);
                progressBar.setString(perc + "%");
                progressBar.setStringPainted(true);
                last = perc;
            }
        }
    }
    
    /**
     * Returns the percentage complete.  
     *
     * @return the percent complete
     */
    
    protected int getProgress() {
        return (int)progressBar.getPercentComplete()*100;
    }    
    
    /**
     * Returns true if the operation was canceled.
     *
     * @return true if the operation was canceled
     */
    
    protected boolean wasCanceled() {
        return cancelled;
    }     
    
    /**
     * Cancels the dialog with a given message.
     * 
     * @param message the stop message
     * @param success is true if no error message was thrown
     */
    
    protected void stop(String message, boolean success) {
        this.success = success;
        progressBar.setIndeterminate(false);
        progressBar.setValue(progressBar.getMinimum()); //Set min, because max display is custom below
        progressBar.setStringPainted(false);
        jLabel1.setText(jLabel1.getText() + message);
        exitButton.setEnabled(true);
        cancelButton.setEnabled(false);
        detailsButton.setEnabled(!success);
        progressBar.setBackground(new java.awt.Color(153, 153, 204));
        last = 0;
        if (thread != null) {
            if (!thread.isCancelled()) {
                thread.cancel(true);
            }
        }
        stopped = true;
    }
    
    /**
     * Performs clean-up on cancel, preventing further actions before the 
     * clean-up is complete.  
     */
    
    protected void cleanUpOnCancel() {
        setVisible(false);
        stop(" cancelled.",true);
    }
    
    /**
     * Registers a worker thread, allowing the thread to be interrupted.
     * 
     * @param thread a thread
     */
    
    protected void setThread(SwingWorker thread) {
        this.thread = thread;
    }
    
    /**
     * Sets the processing message.
     *
     * @param message the message
     */
    
    protected void setMessage(String message) {
        jLabel1.setText(message);
    }

/*******************************************************************************
 *                                                                             *
 *                               PRIVATE METHODS                               *
 *                                                                             *
 ******************************************************************************/        
    
   /**
     * Closes the dialog, terminating any active processes.
     */    
    
    private void close() {
        if(thread != null) {
            stop("", false);
        }
        setVisible(false);
        dispose();
    }    
        
    /**
     * Initializes the window components.
     */
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel81 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel91 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        progressBar = new javax.swing.JProgressBar();
        jPanel9 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        buttonPanel = new javax.swing.JPanel();
        exitButton = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();
        detailsButton = new javax.swing.JButton();
        minimizeButton = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Processing");
        setMinimumSize(new java.awt.Dimension(275, 100));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                closeDialog(evt);
            }
        });
        getContentPane().setLayout(new javax.swing.BoxLayout(getContentPane(), javax.swing.BoxLayout.Y_AXIS));

        jPanel4.setMaximumSize(new java.awt.Dimension(32000, 32000));
        jPanel4.setMinimumSize(new java.awt.Dimension(250, 76));
        jPanel4.setPreferredSize(new java.awt.Dimension(350, 110));
        jPanel4.setLayout(new javax.swing.BoxLayout(jPanel4, javax.swing.BoxLayout.Y_AXIS));

        jPanel3.setPreferredSize(new java.awt.Dimension(32000, 32000));
        jPanel3.setLayout(new javax.swing.BoxLayout(jPanel3, javax.swing.BoxLayout.Y_AXIS));

        jPanel5.setPreferredSize(new java.awt.Dimension(10, 100));
        jPanel5.setLayout(new javax.swing.BoxLayout(jPanel5, javax.swing.BoxLayout.LINE_AXIS));

        jPanel81.setMaximumSize(new java.awt.Dimension(10000, 32767));
        jPanel5.add(jPanel81);

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel1.setText("Processing  . . . . . .");
        jLabel1.setMaximumSize(new java.awt.Dimension(32767, 23));
        jLabel1.setPreferredSize(new java.awt.Dimension(200, 23));
        jPanel5.add(jLabel1);

        jPanel91.setMaximumSize(new java.awt.Dimension(10000, 32767));
        jPanel5.add(jPanel91);

        jPanel3.add(jPanel5);

        jPanel6.setLayout(new javax.swing.BoxLayout(jPanel6, javax.swing.BoxLayout.LINE_AXIS));

        jPanel8.setMaximumSize(new java.awt.Dimension(10000, 32767));
        jPanel6.add(jPanel8);

        progressBar.setMaximumSize(new java.awt.Dimension(32767, 20));
        progressBar.setPreferredSize(new java.awt.Dimension(200, 20));
        jPanel6.add(progressBar);

        jPanel9.setMaximumSize(new java.awt.Dimension(10000, 32767));
        jPanel6.add(jPanel9);

        jPanel3.add(jPanel6);

        jPanel7.setPreferredSize(new java.awt.Dimension(10, 20));
        jPanel3.add(jPanel7);

        jPanel4.add(jPanel3);

        jPanel1.setLayout(new javax.swing.BoxLayout(jPanel1, javax.swing.BoxLayout.LINE_AXIS));
        jPanel1.add(jPanel21);

        exitButton.setText("Close");
        exitButton.setEnabled(false);
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(exitButton);

        cancelButton.setText("Cancel");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(cancelButton);

        detailsButton.setText("Details");
        detailsButton.setEnabled(false);
        detailsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                detailsButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(detailsButton);

        minimizeButton.setText("Iconify");
        minimizeButton.setActionCommand("Hide");
        minimizeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minimizeButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(minimizeButton);

        jPanel1.add(buttonPanel);
        jPanel1.add(jPanel2);

        jPanel4.add(jPanel1);

        getContentPane().add(jPanel4);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Shows available messages.
     *
     * @param evt an action event
     */    
    
    private void detailsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_detailsButtonActionPerformed
        Console c = new Console(this,false);
        c.addMessage(CONSOLE.getMessages());
        EVSMainWindow.setWindowLocation(c);
        c.setVisible(true);
    }//GEN-LAST:event_detailsButtonActionPerformed

    /**
     * Exits the dialog.
     *
     * @param evt an action event
     */        
    
    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        close();
    }//GEN-LAST:event_exitButtonActionPerformed
        
    /**
     * Cancels the operation in progress.
     *
     * @param evt an action event
     */            
    
    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonActionPerformed
        cancelButton.setEnabled(false);
        cancelled = true;
        cleanUpOnCancel();
    }//GEN-LAST:event_cancelButtonActionPerformed

    /**
     * Exits the dialog.
     *
     * @param evt an action event
     */            
    
    private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
        //Only allow closure if cancelled or complete
        if(stopped) {
            close();
        }        
    }//GEN-LAST:event_closeDialog

    /**
     * Minimize the parent container.
     *
     * @param evt
     */

    private void minimizeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minimizeButtonActionPerformed
        try {
            int state = EVSMainWindow.main.getExtendedState();
            state |= JFrame.ICONIFIED;
            EVSMainWindow.main.setExtendedState(state);
        } catch (Exception e) {
            //Do nothing
        }
    }//GEN-LAST:event_minimizeButtonActionPerformed
            
//    /**
//     * Temporary method to kill the active thread.  Must be replaced with a safer
//     * method.
//     *
//     * @deprecated
//     */
//    
//    private void killThread() {
//        if(thread != null) {
//            thread.stop();  //Calls a deprecated API temporarily
//        }
//    }
    
/*******************************************************************************
 *                                                                             *
 *                              INSTANCE VARIABLES                             *
 *                                                                             *
 ******************************************************************************/       

    /**
     * Is true if the thread has terminated.
     */
    
    private boolean stopped = false;
    
    /**
     * The operation.
     */
    
    private SwingWorker thread = null;
    
    /**
     * Is true if the thread terminated successfully.
     */
    
    private boolean success;
    
    /**
     * Is true if the thread was canceled.
     */
    
    private boolean cancelled;    
    
    /**
     * Last percentage complete value.
     */
    
    private double last = 0;
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel buttonPanel;
    private javax.swing.JButton cancelButton;
    private javax.swing.JButton detailsButton;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel81;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPanel jPanel91;
    private javax.swing.JButton minimizeButton;
    private javax.swing.JProgressBar progressBar;
    // End of variables declaration//GEN-END:variables

}
