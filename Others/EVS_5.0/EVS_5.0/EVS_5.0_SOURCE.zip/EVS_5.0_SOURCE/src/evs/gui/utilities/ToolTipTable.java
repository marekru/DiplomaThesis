package evs.gui.utilities;

//Java swing dependencies
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;
import javax.swing.JComponent;

//Java awt dependencies
import java.awt.Component;

/**
 * Table that displays a tool tip text based on the string representation
 * of the cell value.
 */

public class ToolTipTable extends JTable {
        
/*******************************************************************************
 *                                                                             *
 *                                  METHODS                                    *
 *                                                                             *
 ******************************************************************************/      

    /**
     * Prepares the renderer by querying the data model for the value and selection 
     * state of the cell at row, column.  Returns the component (may be a Component 
     * or a JComponent) under the event location. Note: Throughout the table package, 
     * the internal implementations always use this method to prepare renderers so
     * that this default behavior can be safely overridden by a subclass. 
     * 
     * @param renderer the TableCellRenderer to prepare
     * @param rowIndex the row of the cell to render, where 0 is the first row
     * @param colIndex the column of the cell to render, where 0 is the first column 
     * @return the Component under the event location
     */
    
    public Component prepareRenderer(TableCellRenderer renderer, int rowIndex, int colIndex) {
        Component c = super.prepareRenderer(renderer, rowIndex, colIndex);
        if (c instanceof JComponent) {
            JComponent jc = (JComponent)c;
            jc.setToolTipText(getValueAt(rowIndex, colIndex)+"");
        }
        return c;
    }

}
