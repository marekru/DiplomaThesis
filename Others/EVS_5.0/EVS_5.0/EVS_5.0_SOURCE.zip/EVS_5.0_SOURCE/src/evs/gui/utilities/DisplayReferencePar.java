package evs.gui.utilities;

//Java dependencies
import java.util.Arrays;
import java.util.TreeSet;

/**
 * Class for storing and displaying a reference forecast in a combo box.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DisplayReferencePar {

    /**
     * The reference forecasts.
     */
    
    private String[] refs;

    /**
     * Selected forecast index.
     */
    
    private int sel = -1; 
    
    /**
     * Default constructor.
     */
    
    public DisplayReferencePar() {
        this.refs = new String[]{"None available: add VU"};
    }

    /**
     * Constructor with pre-defined reference forecasts.
     *
     * @param ref the reference forecasts
     */

    public DisplayReferencePar(String[] ref) {
        setRefFcsts(ref);
    }

    /**
     * Returns the selected reference forecast index or -1
     *
     * @return the selected index
     */
    
    public int getSelectedIndex() {
        return sel;
    }
    
    /**
     * Returns the reference forecasts available.
     * 
     * @return the available reference forecasts.
     */
    
    public String[] getRefFcsts() {
        String[] s = new String[refs.length];
        System.arraycopy(refs,0,s,0,s.length);
        return s;
    } 
    
    /**
     * Sets the selected index.
     * 
     * @param sel the selected index
     */
    
    public void setSelectedIndex(int sel) {
        if(sel < 0 || sel > (refs.length-1)) {
            this.sel = -1;
        }
        else {
            this.sel = sel;
        }
    }
    
    /**
     * Sets the selected item, if found.
     * 
     * @param select the reference forecast to select
     */
    
    public void setSelectedItem(String select) {
        for(int i = 0; i < refs.length; i++) {
            if(refs[i].equals(select)) {
                sel = i; break;
            }
        }
    }
    
    /**
     * Sets the reference forecasts, removing the default status of none available
     * and removing the current index selection.
     * 
     * Throws an exception if two or more reference identifiers are the same.
     * 
     * @param refs the reference forecasts
     */
    
    public void setRefFcsts(String[] refs) throws IllegalArgumentException {
        if(refs == null || refs.length==0) {
            throw new IllegalArgumentException("Specify valid reference forecasts.");
        }
        TreeSet<String> set = new TreeSet<String>();
        set.addAll(Arrays.asList(refs));
        if(set.size()!=refs.length) {
            throw new IllegalArgumentException("Two or more reference forecasts comprise the same "
                    + "identifiers, which is not allowed");
        }
        String[] s = new String[refs.length];
        System.arraycopy(refs,0,s,0,s.length);
        sel = -1;
        this.refs = s;
    }

    /**
     * Display name.
     *
     * @return the display name
     */
    
    public String toString() {
        if(sel ==-1) {
            return "";
        }
        else {
            return refs[sel];
        }
    }
} 
        
   
