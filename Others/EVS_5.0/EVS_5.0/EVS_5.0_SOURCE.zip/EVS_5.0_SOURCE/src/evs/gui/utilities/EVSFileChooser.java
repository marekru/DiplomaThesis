package evs.gui.utilities;

//Java IO dependencies
import java.io.File;

//Java swing dependencies
import javax.swing.JFileChooser;
import javax.swing.JList;
import javax.swing.JToggleButton;
import javax.swing.SwingUtilities;
import javax.swing.JTable;
import javax.swing.table.TableColumn;
import javax.swing.Icon;
import javax.swing.UIManager;

//Java awt dependencies
import java.awt.Component;
import java.awt.Container;
import java.awt.event.MouseListener;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * Extends the default file chooser. 
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class EVSFileChooser extends JFileChooser {

    /**
     * The current working directory.
     */

    private static File defaultDirectory = null;

/*******************************************************************************
 *                                                                             *
 *                               CONSTRUCTORS                                  *
 *                                                                             *
 ******************************************************************************/      
    
    /**
     * Construct the chooser.
     */
    
    public EVSFileChooser() {
        super();
        //UI dependent, so take care
        try {

            // Disable editing (file renaming) in JList
            JList list = (JList)findByClass(this, JList.class);
            MouseListener[] listeners = list.getMouseListeners();
            for (int i = 0; i < listeners.length; i++) {
                String className = listeners[i].getClass().getName();
                if (className.endsWith("FileChooserUI$SingleClickListener")) {
                    list.removeMouseListener(listeners[i]);
                    break;
                }
            }
            
            // Disable editing (file renaming) in JTable
            JToggleButton detailsViewButton = findDetailsViewButton(this);
            detailsViewButton.addActionListener(new ActionListener() {
                boolean done = false;
                
                public void actionPerformed(ActionEvent ev) {
                    if (!done && ((JToggleButton)ev.getSource()).isSelected()) {
                        SwingUtilities.invokeLater(new Runnable() {
                            public void run() {
                                JTable table = (JTable)findByClass(EVSFileChooser.this,JTable.class);
                                if (table != null) {
                                    TableColumn column = table.getColumnModel().getColumn(0);
                                    column.setCellEditor(null);
                                }
                            }
                        });
                        done = true;
                    }
                }
            });

            if(defaultDirectory!=null && defaultDirectory.exists()) {
                setCurrentDirectory(defaultDirectory);
            }

        } catch(Exception e) {
            //Do nothing
        }
    }
    
/*******************************************************************************
 *                                                                             *
 *                              ACCESSOR METHODS                               *
 *                                                                             *
 ******************************************************************************/     
    
    /**
     * Finds a component by class.
     *
     * @param comp the component to search
     * @param cls the class
     * @return the component
     */
    
    private static Component findByClass(Component comp, Class cls) {
        if (cls.isInstance(comp)) {
	    return comp;
	} else if (comp instanceof Container) {
	    Component[] comps = ((Container)comp).getComponents();
	    for (int i = 0; i < comps.length; i++) {
		Component c = findByClass(comps[i], cls);
		if (c != null) {
		    return c;
		}
	    }
	}
	return null;
    }
 
    /**
     * Finds the details view button.
     *
     * @param comp the component to search
     */    
    
    private static JToggleButton findDetailsViewButton(Component comp) {
	Icon detailsViewIcon = UIManager.getIcon("FileChooser.detailsViewIcon");
 
	if (comp instanceof JToggleButton &&
	    ((JToggleButton)comp).getIcon() == detailsViewIcon) {
 
	    return (JToggleButton)comp;
	} else if (comp instanceof Container) {
	    Component[] comps = ((Container)comp).getComponents();
	    for (int i = 0; i < comps.length; i++) {
		JToggleButton button = findDetailsViewButton(comps[i]);
		if (button != null) {
		    return button;
		}
	    }
	}
	return null;
    }

/*******************************************************************************
 *                                                                             *
 *                              MUTATOR METHODS                                *
 *                                                                             *
 ******************************************************************************/

    /**
     * Sets the default working directory.
     *
     * @param file the working directory
     */

    public static void setDefaultDirectory(File file) {
        defaultDirectory = file;
    }
    
}
