package evs.gui.utilities;

//EVS dependencies
import evs.analysisunits.AnalysisUnit;

/**
 * An interface for updating an existing verification unit with transitional 
 * data.
 * 
 * @author evs@hydrosolved.com
 */

public interface TransitionalUnit {
 
    /**
     * Updates a specified transitional parameter in the local store with the 
     * specified object. Throws an exception if the identifier is not recognized
     * or the class of the input object is inconsistent with the class of the 
     * stored temporary data
     * 
     * @param id the parameter identifier
     * @param value the parameter value
     */
    
    void update(int id, Object value) throws IllegalArgumentException;
    
    /**
     * Implements the transition between the local data and the existing unit.
     * 
     * It is critical that a transition is not finalized until all parameters
     * have been deemed valid. See {@link evs.gui.utilities.TransitionalUnit#testTransition()}
     * 
     * Throws an exception if any of the transitional data are invalid.
     */
    
    void transition() throws IllegalArgumentException;
    
    /**
     * Tests the transition between the local data and the existing unit, returning
     * the transitioned unit, without updating the stored unit.
     * 
     * Throws an exception if any of the transitional data are invalid. Returns
     * the updated unit for convenience. 
     */
    
    AnalysisUnit testTransition() throws IllegalArgumentException;    
    
    /**
     * Returns the stored verification unit. Specific implementations may decide whether
     * to return a deep copy of the stored unit, but care should be taken to avoid
     * inconsistency between the stored unit and the temporary parameter values.
     * 
     * @return the stored unit
     */
    
    AnalysisUnit getStoredUnit();
    
}
