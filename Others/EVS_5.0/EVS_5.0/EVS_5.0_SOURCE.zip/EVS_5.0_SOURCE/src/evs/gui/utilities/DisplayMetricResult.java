package evs.gui.utilities;

//EVS dependencies
import evs.metric.results.MetricResultByLeadTime;
import evs.metric.metrics.Metric;
import evs.analysisunits.AnalysisUnit;
import evs.metric.parameters.DoubleParameter;

//Java util dependencies
import java.util.Vector;

/**
 * Class for storing a metric result for display in a table.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DisplayMetricResult {
    
    /*******************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLES                              *
     *                                                                              *
     *******************************************************************************/
    
    /**
     * The result.
     */
    
    private MetricResultByLeadTime result = null;
    
    /**
     * The name.
     */
    
    private String name = null;
    
    /**
     * The parent metric.
     */
    
    private Metric parentMetric;
    
    /**
     * Is true to include, false otherwise.
     */
    
    private boolean include = false;
    
    /**
     * The parent analysis unit.
     */
    
    private AnalysisUnit parentUnit = null;   
    
    /**
     * The forecast type.  See evs.metrics.parameters.ForecastTypeParameter for
     * supported types.
     */
    
    private int forecastType;
    
    /**
     * Threshold.
     */
    
    private DoubleParameter threshold = null;
    
    /**
     * Is true to include this result with all other results from the same metric
     * and analysis unit in the same product.
     */
    
    private boolean singleProduct = false;
    
    /**
     * Boolean vector indicating whether a lead period will be included.
     */
    
    private Vector<Boolean> includeLead = new Vector();
    
    /**
     * Vector of lead times in hours.
     */
    
    private Vector<Double> leadTimes = new Vector();
    
    /********************************************************************************
     *                                                                              *
     *                               CONSTRUCTOR                                    *
     *                                                                              *
     *******************************************************************************/
    
    /**
     * Constructs a result for display.  See evs.metric.Metric for the supported
     * metric types.
     *
     * @param name the name to display
     * @param result the result
     * @param parentMetric the parent metric
     * @param parentUnit the parent analysis unit
     * @param forecastType the forecast type
     */
    
    public DisplayMetricResult(String name, MetricResultByLeadTime result, 
            Metric parentMetric, AnalysisUnit parentUnit, int forecastType) {
        this.result = result;
        this.name = name;
        this.parentMetric = parentMetric;
        this.parentUnit = parentUnit;
        this.forecastType = forecastType;
        int count = result.getResultCount();
        for(int i = 0; i < count; i++) {
            includeLead.add(false);
        }   
        leadTimes.addAll(result.getResults().keySet());
        
        //Set as a single product by default?
        final int stored = result.getLowestLevelResultID();
        int ID = parentMetric.getID();
        if (stored == result.DOUBLE_RESULT
                || stored == result.ENSEMBLE_SCORE_DECOMPOSITION_RESULT
                || stored == result.INTEGER_RESULT
                || ID == parentMetric.BOX_DIAGRAM_POOLED_BY_LEAD
                || ID == parentMetric.ROCS) {
            singleProduct = true;
        }        
        
    }
    
    /**
     * Constructs a result for display, including a threshold for the result.  
     *
     * @param name the name to display
     * @param result the result
     * @param parentMetric the parent metric
     * @param parentUnit the parent analysis unit
     * @param forecastType the forecast type
     * @param threshold the threshold
     */
    
    public DisplayMetricResult(String name, MetricResultByLeadTime result, 
            Metric parentMetric, AnalysisUnit parentUnit, int forecastType, 
            DoubleParameter threshold) {
        this(name,result,parentMetric,parentUnit,forecastType);
        this.threshold = threshold;
    }    
    
    /*******************************************************************************
     *                                                                             *
     *                              ACCESSOR METHODS                               *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Returns true if a threshold exists.
     *
     * @return true if a threshold exists
     */
    
    public boolean hasThreshold() {
        return threshold !=  null;
    }      
    
    /**
     * Returns true if some times will be included.
     *
     * @return true if some times will be included.
     */
    
    public boolean hasIncludeTimes() {
        return includeLead.indexOf(true) > -1;
    }
    
    /**
     * Returns the result.
     *
     * @return the result
     */
    
    public MetricResultByLeadTime getResult() {
        return result;
    }
    
    /**
     * Returns the parent metric from which the result originated.
     *
     * @return the metric
     */
    
    public Metric getParentMetric() {
        return parentMetric;
    }
    
    /**
     * Returns true if the result will be computed, false otherwise.
     *
     * @return true if the result will be computed
     */
    
    public boolean getInclude() {
        return include;
    }
    
    /**
     * Returns true if the forecast lead time (in hours) will be included.
     *
     * @param leadHours the lead time in hours
     * @return true if the lead time will be included.
     */
    
    public boolean getIncludeLead(double leadHours) throws IllegalArgumentException {
        int ind = leadTimes.indexOf(leadHours);
        if(ind < 0) {
            throw new IllegalArgumentException("Unrecognized lead time.");
        }
        return includeLead.get(ind);
    }
    
    /**
     * Returns a vector of booleans indicating which, if any, lead times will
     * be included.
     *
     * @return the lead times for inclusion
     */
    
    public Vector<Boolean> getIncludeLeads() {
        return includeLead;
    }
    
    /**
     * Returns the number of lead times that will be included.
     *
     * @return the lead time count to include
     */
    
    public int getIncludeLeadCount() {
        int tot = 0;
        int size = includeLead.size();
        for(int i = 0; i < size; i++) {
            if(includeLead.get(i)) {
                tot++;
            }
        }
        return tot;
    }    
    
    /**
     * Returns the lead times available for the metric result.
     *
     * @return the lead times available.
     */
    
    public Vector<Double> getLeadTimes() {
        return leadTimes;
    }    
    
    /**
     * Returns the forecast type.  See evs.metrics.parameters.ForecastTypeParameter 
     * for supported types. 
     */
    
    public int getForecastType() {
        return forecastType;
    }
    
    /**
     * Returns the threshold or null.
     *
     * @return the threshold.
     */
    
    public DoubleParameter getThreshold() {
        return threshold;
    }    
    
    /**
     * Returns true if this result will be included with all other results from 
     * the same metric and analysis units in the same product.
     *
     * @return true if this will be included in a single product, false otherwise
     */
    
    public boolean getSingleProduct() {
        return singleProduct;
    }    
         
    /**
     * Returns the parent analysis unit associated with this unit.
     *
     * @return the parent analysis unit
     */
    
    public AnalysisUnit getParentUnit() {
        return parentUnit;
    }
    
    /**
     * Returns a string representation of the result.
     *
     * @return a string representation of the result
     */
    
    public String toString() {
        return name;
    }
    
    /*******************************************************************************
     *                                                                             *
     *                               MUTATOR METHODS                               *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Sets the include flag
     *
     * @param include is true to include
     */
    
    public void setInclude(boolean include) {
        this.include=include;
    }
    
    /**
     * Is true to include this result with all other results from the same metric 
     * and analysis unit in the same product.
     *
     * @param singleProduct is true to include in a single product
     */
    
    public void setSingleProduct(boolean singleProduct) {
        this.singleProduct = singleProduct;
    }    
    
    /**
     * Sets a specific lead time to include or not include.
     *
     * @param leadHours the lead time
     * @param include is true to include
     */
    
    public void setIncludeLead(double leadHours, boolean include) throws IllegalArgumentException {
        int ind = leadTimes.indexOf(leadHours);
        if(ind < 0) {
            throw new IllegalArgumentException("Unrecognized lead time.");
        }
        includeLead.set(ind,include);
    }
    
    /**
     * Sets all lead times to include or not.
     *
     * @param include is true to include all times
     */
    
    public void setIncludeAllLeads(boolean include) {
        int count = leadTimes.size();
        for(int i = 0; i < count; i++) {
            includeLead.set(i,include);
        }          
    }    
    
    /**
     * Sets the threshold.
     *
     * @param threshold the threshold.
     */
    
    public void setThreshold(DoubleParameter threshold) {
        this.threshold = threshold;
    }     
    
}