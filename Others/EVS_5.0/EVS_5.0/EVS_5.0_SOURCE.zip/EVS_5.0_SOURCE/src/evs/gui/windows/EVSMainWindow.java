package evs.gui.windows;

// Java swing dependencies
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.LookAndFeel;
import javax.swing.SwingUtilities;
import javax.swing.ToolTipManager;
import javax.swing.UIManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.plaf.OptionPaneUI;
import com.incors.plaf.alloy.AlloyLookAndFeel;
import com.incors.plaf.alloy.themes.custom.CustomThemeFactory;

import evs.analysisunits.AggregationUnit;
import evs.analysisunits.AnalysisUnit;
import evs.analysisunits.VerificationUnit;
import evs.analysisunits.scale.MeasurementUnitsChangeLibrary;
import evs.data.IOState;
import evs.data.fileio.GlobalUnitsReader;
import evs.data.fileio.InputFileFilter;
import evs.data.fileio.OHDFileIO;
import evs.data.fileio.PairedFileIO;
import evs.data.fileio.ProjectFileIO;
import evs.data.fileio.XSLTControl;
import evs.gui.utilities.AdaptableComboBox;
import evs.gui.utilities.DisplayMetricResult;
import evs.gui.utilities.EVSFileChooser;
import evs.gui.utilities.EventThreadExceptionHandler;
import evs.gui.utilities.OptionPaneMultiLineUI;
import evs.metric.metrics.Metric;
import evs.metric.parameters.ForecastTypeParameter;
import evs.metric.results.MetricResultByLeadTime;
import evs.utilities.EVSConstants;
import evs.utilities.StringUtilities;

import ohd.hseb.util.fews.ResourceTools;
import ohd.hseb.util.fews.OHDUtilities;

/**
 * The main window frame for the Ensemble Verification System. The window
 * contains a tabbed pane into which further windows are embedded.
 * 
 * TODO: create a local store of verification and aggregation units that is accessible
 * from all GUI windows, so that local saves are always updating the same store without
 * any need to coordinate between windows, i.e. removing the dependence on save 
 * order.
 * 
 * @author evs@hydrosolved.com
 * @version 4.0
 */
public class EVSMainWindow extends JFrame implements GUICommunicator {

    /***************************************************************************
     * 
     *                                 CONSTRUCTOR 
     *
     ***************************************************************************/
    
    /**
     * Construct the main window.
     */
    
    protected EVSMainWindow() {
        initComponents();
        regNavListeners();
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setTitle("Ensemble Verification System");
        setFileChoosers();        
    }

    /****************************************************************************
     * 
     *                               PUBLIC METHODS 
     *
     ***************************************************************************/
    /**
     * Main method. Invokes the GUI.
     * 
     * @param args
     *            the command line arguments
     */
    public static void main(final String[] args) {
        // Catch any unhandled exceptions cleanly
        Thread.setDefaultUncaughtExceptionHandler(new EventThreadExceptionHandler());
        SwingUtilities.invokeLater(new Runnable() {

            public void run() {
                if (args.length == 0) {
                    createAndShowGUI();
                } // Command line options to change file formats?
                else if (args.length == 3) {
                    final double nV = GlobalUnitsReader.getDefaultNullValue();
                    if (args[0].equals("-p")) {
                        convertPairedFile(args[1], args[2], nV);
                    } else if (args[0].equals("-fcard2asc")) {
                        convertCardForecastFile(args[1], args[2], nV);
                    } else if (args[0].equals("-ocard2asc")) {
                        convertCardObservedFile(args[1], args[2], nV);
                    } else if (args[0].equals("-bin2asc")) {
                        convertBinFile(args[1], args[2], nV);
                    } else if(args[0].equals("-xslt")) {
                        transformXML(args[1],args[2],null);  //Standard out
                    } else {
                        // Could be a silent project run with three arguments
                        // (e.g. -aggOnly and -g)
                        runProjectsSilently(args);
                    }
                } // Command line option to run projects
                else if(args.length==4) {
                    if(args[0].equals("-xslt")) {
                        transformXML(args[1],args[2],args[3]);
                    }
                    else {
                        // Could be a silent project (or two) run with four arguments                     
                        runProjectsSilently(args);
                    }
                }
                else {
                    runProjectsSilently(args);
                }
            }
        });
    }

    /**
     * Utility method that dynamically sets the width of a popup menu to the
     * width required by the widest element in the menu.
     * 
     * @param evt a popup menu event
     */
    public static void setPopupWidth(final PopupMenuEvent evt) {
        final JComboBox box = (JComboBox) evt.getSource();
        if (box instanceof AdaptableComboBox) {
            ((AdaptableComboBox) box).setWide(true);
        }
    }

    /**
     * Runs an array of projects silently, writing the graphical and numerical
     * output for all of the verification and aggregation units within each
     * project.
     * 
     * @param args the command line array of paths to the EVS project files
     * @return the status (one of {@link EVSMainWindow#SUCCESS} or
     *         {@link EVSMainWindow#FAILURE})
     */
    public static int runProjectsSilently(final String[] args) {
        try {
//            // Initialize all required static classes prior to
//            // running the EVS
//            new GlobalUnitsReader();
//            new MeasurementUnitsChangeLibrary();

            // Run aggregation units only?
            boolean aggOnly = false;
            final boolean dG = false;
            boolean wG = true; // Write graphics
            final boolean dN = false;
            boolean wN = true; // Write numerics
            final Vector<String> process = new Vector<String>();
            for (final String s : args) {
                if (s != null && s.equalsIgnoreCase("-aggOnly")) {
                    aggOnly = true;
                } else if (s != null && s.equalsIgnoreCase("-g")) {
                    wG = false;
                } else if (s != null && s.equalsIgnoreCase("-n")) {
                    wN = false;
                } else {
                    process.add(s);
                }
            }
            if (!wG && !wN) {
                throw new IllegalArgumentException(
                        "Cannot suppress the writing of both numerical "
                        + "and graphical outputs (-g -n).");
            } else if (!wG) {
                System.out.println("Detected -g option to suppress graphical output.");
            } else if (!wN) {
                System.out.println("Detected -n option to suppress numerical output.");
            }
            // Compute all projects
            for (String s : process) {
                try {
                    s = StringUtilities.cleanPath(s);
                } catch (final Exception e) {
                    System.out.println("Error cleaning file path '" + s + "'.");
                }
                System.out.println("Processing project '" + s + "'...");
                final File proj = new File(s);
                final AnalysisUnit[] units = ProjectFileIO.read(proj);
                final Vector<VerificationUnit> v = new Vector();
                final Vector<AggregationUnit> a = new Vector();
                
                for (int j = 0; j < units.length; j++) {
                    if (units[j] instanceof VerificationUnit) {
                        v.add((VerificationUnit) units[j]);
                    } else if (units[j] instanceof AggregationUnit) {
                        a.add((AggregationUnit) units[j]);
                    }
                }

                //Obtain the results in a format used by the GUI (maximizes
                //code re-use)
                for (int j = 0; j < units.length; j++) {
                    if ((units[j] instanceof AggregationUnit)
                            && ((AggregationUnit) units[j]).getVerificationUnitCount() == 0) {
                        continue;
                    }
                    if (aggOnly && !(units[j] instanceof AggregationUnit)) {
                        continue;
                    }
                    // Compute metrics, pairing and writing conditional pairs as
                    // necessary
                    System.out.println("Processing unit '" + units[j] + "'...");
                    final AnalysisUnit next = units[j];

                    final boolean ok = next.computeMetrics(v);
                    if (next.hasMetrics()) {
                        final TreeMap<String, Metric> nxtMet = next.getMetricsWithResults();
                        final Iterator k = nxtMet.keySet().iterator();

                        // Iterate through the metrics
                        final Vector<DisplayMetricResult> results = new Vector();
                        while (k.hasNext()) {
                            final Object metName = k.next();
                            final Metric m = nxtMet.get(metName);

                            // Determine result type
                            int type = ForecastTypeParameter.REGULAR_FORECAST;
                            if (m.isSkillMetric()) {
                                type = ForecastTypeParameter.SKILL;
                            }
                            // Results exist
                            if (m.hasResult(type)) {
                                final MetricResultByLeadTime res = m.getResult(type);
                                // Add the new results
                                final DisplayMetricResult nextDisp = new DisplayMetricResult(
                                        metName + "", res, m, next, type);
                                results.add(nextDisp);
                            }
                        }

                        // Generate the products with default writing options
                        if (results.size() > 0) {
                            ProductGeneratorDialog.generateProducts(results,
                                    dG, wG, dN, wN, next.getWriteOptions(), false);
                            
                            //Once generated, remove all products from current
                            //metric to conserve memory
                            //Only remove if they will not be used later in an 
                            //Aggregation Unit
                            if(next instanceof VerificationUnit) {
                                boolean eliminate = true;
                                for(AggregationUnit ag : a) {
                                    if(ag.containsUnit((VerificationUnit)next)) {
                                        eliminate = false;
                                    }
                                }
                                if(eliminate) {
                                    System.out.println("Cleaning up: clearing generated results for unit '"+next+"'");
                                    next.clearAllMetricResults();
                                }
                            } 
                            //Clear aggregation unit from list of units to check
                            else if (next instanceof AggregationUnit){
                                next.clearAllMetricResults();
                                a.remove((AggregationUnit)next);
                            }
                        }
                    }
                    if (!ok) {
                        System.out.println("Completed unit '" + next
                                + "', but with the following errors: ");
                        System.out.println(next.getComputeErrors());
                        System.out.println();
                    } else {
                        System.out.println("Completed unit '" + next + "'.");
                        System.out.println();
                    }
                    // Update project file after EACH unit has been read, in
                    // case of paired file updates
                    ProjectFileIO.write(proj, units);
                }
                System.out.println("Completed project '" + s + "'.");
            }
        } catch (final Throwable t) {
            System.out.println("Project failed to complete with the following errors: ");

            System.out.println(StringUtilities.stackTraceToString(t));

            return FAILURE;
        }
        return SUCCESS;
    }

    /*******************************************************************************
     * 
     *                               PROTECTED METHODS 
     * 
     *******************************************************************************/
    /**
     * Shows a save project dialog. Does not actually write the project data to
     * file, since the operation may be canceled. Specifying saveAs to be true
     * allows an existing project to be saved with a new name.
     * 
     * @param saveAs is true to save an existing project with a new name
     * @return true if the operation was NOT canceled
     */
    protected final boolean showSaveProjectDialog(final boolean saveAs) {
        boolean notCancelled = true;
        if (projectFile == null || saveAs) {
            final int status = saveChooser.showSaveDialog(this);
            if (status == EVSFileChooser.APPROVE_OPTION) {
                projectFile = saveChooser.getSelectedFile();
                String name = projectFile.getName();
                String path = null;
                try {
                    path = projectFile.getCanonicalPath();
                    if (!path.toLowerCase().endsWith(".evs")) {
                        projectFile = new File(path + ".evs");
                        name = name + ".evs";
                    }
                    setTitle("Ensemble Verification System (EVS)  [Project '"
                            + name.substring(0, name.length() - 4) + "']");
                } catch (final Exception e) {
                    e.printStackTrace();
                    System.out.println("Failed to append '.evs' extension to EVS project file '"
                            + path + "'.");
                }
            } else {
                notCancelled = false;
            }
        }
        return notCancelled;
    }

    /**
     * Clears an existing project file.
     */
    protected final void clearProjectFile() {
        projectFile = null;
    }

    /**
     * Returns true if the project file exists, false otherwise.
     * 
     * @return true if the project file exists.
     */
    protected final boolean hasProjectFile() {
        return projectFile != null;
    }

    /**
     * Saves the project data by sequentially calling local saves on each input
     * window and, finally, writing the output to file if write is true. Writing
     * of the project file is done in a separate thread.
     * 
     * @param write is true to write the data
     * @return true if the save was successful, false otherwise
     */
    protected final boolean saveProject(final boolean write) {
        boolean returnMe = true;
        // If writing is not required, proceed directly without showing a
        // save dialog, otherwise call the method that shows a save dialog and
        // returns true if the save dialog was not cancelled.
        if (!write || EVSMainWindow.main.showSaveProjectDialog(false)) {
            try {
                // Only update if verification units are defined
                if (VERIFICATION_A.hasVerificationUnits()) {
                    // Save changes
                    returnMe = returnMe && VERIFICATION_A.saveData();
                    if (!returnMe) {
                        return false;
                    }
                    returnMe = returnMe && VERIFICATION_B.saveData();
                    if (!returnMe) {
                        return false;
                    }
                    returnMe = returnMe && AGGREGATION_A.saveData();
                    if (!returnMe) {
                        return false;
                    }
                    returnMe = returnMe && OUTPUT_A.saveData();
                    if (!returnMe) {
                        return false;
                    }
                    // Propagate changes
                    VERIFICATION_A.updateLocalData(VERIFICATION_A.getSelectedUnit());
                    VERIFICATION_A.showLocalData();
                    VERIFICATION_B.updateLocalData(VERIFICATION_A.getSelectedUnit());
                    VERIFICATION_B.showLocalData();
                    AGGREGATION_A.updateLocalData(VERIFICATION_A.getSelectedUnit());
                    AGGREGATION_A.showLocalData();
                    OUTPUT_A.updateLocalData(VERIFICATION_A.getSelectedUnit());
                    OUTPUT_A.showLocalData();
                }
                // Write the data
                if (projectFile != null && write) {
                    returnMe = returnMe && writeObjects(projectFile);
                }
            } catch (final Throwable e) {
                returnMe = false;
                e.printStackTrace();
                CONSOLE.addMessage(StringUtilities.stackTraceToString(e));
                ExceptionHandler.displayException(e);
            }
        }
        return returnMe;
    }

    /**
     * Centers the input component relative to the main window.
     * 
     * @param component the Component
     */
    protected static void setWindowLocation(final Component component) {
        if (main != null) {
            final Point p = main.getLocation();
            component.setLocation(p.x
                    + (main.getWidth() - component.getWidth()) / 2,
                    p.y + (main.getHeight() - component.getHeight()) / 2);
        } else {
            System.out.println("Cannot set location of component before main window has been constructed.");
        }
    }

    /**
     * Displays updated data following a change in the selected verification
     * unit. If local data are currently being edited, this will remove all local data.
     * 
     * Deprecated, as the same functionality must be handled in VERIFICATION_A
     * 
     *@deprecated
     */
    protected final void updateAndShowLocalData() {
        if (VERIFICATION_A.unitIsSelected()) {
            final VerificationUnit selected = VERIFICATION_A.getSelectedUnit();
            VERIFICATION_A.updateLocalData(selected);  //JB @ 10th June 2012
            VERIFICATION_A.showLocalData();
            VERIFICATION_B.updateLocalData(selected);
            VERIFICATION_B.showLocalData();
            AGGREGATION_A.updateLocalData(selected);
            AGGREGATION_A.showLocalData();
            OUTPUT_A.updateLocalData(selected);
            OUTPUT_A.showLocalData();
        } else {
            VERIFICATION_A.showLocalData();
            VERIFICATION_B.clearAllLocalData();
            AGGREGATION_A.clearAllLocalData();
            OUTPUT_A.clearAllLocalData();
        }
    }
    
    /**
     * Protected access to writing objects. This may be required following an
     * update in a verification unit that does not require iterative saving of
     * data first (e.g. following allocation of a paired dataset).
     * 
     * @return true if the objects were written
     */
    protected final boolean updateProjectFile() throws IOException {
        return writeObjects(projectFile);
    }

    /*******************************************************************************
     * 
     *                               PRIVATE METHODS 
     * 
     *******************************************************************************/
    /**
     * Writes all objects in the current project to file. Writing is conducted
     * in a separate thread. This method returns false if the objects were not
     * written
     * 
     * @param f the file to write
     * @return true if the objects were written, false otherwise
     */
    private boolean writeObjects(final File f) {
        try {
            final Vector<AnalysisUnit> v = new Vector();
            v.addAll(VERIFICATION_A.getVerificationUnits());
            v.addAll(AGGREGATION_A.getAggregationUnits());
            final AnalysisUnit[] units = v.toArray(new AnalysisUnit[v.size()]);
            ProjectFileIO.write(f, units);
            return true;
        } catch (final Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Reads all objects in the specified file.
     * 
     * @param f the file to read
     */
    private AnalysisUnit[] readObjects(final File f) throws IOException {
        try {
            return ProjectFileIO.read(f);
        } catch (final Exception e) {
            e.printStackTrace();
            throw new IOException(e.getMessage());
        }
    }

    /**
     * Adds a new set of analysis units read from an EVS project file and displays
     * them.
     * 
     * @param units the analysis units
     */
    private void addUnits(final AnalysisUnit[] units) {
        VERIFICATION_A.clearAllLocalData();
        for (int i = 0; i < units.length; i++) {
            if (units[i] instanceof VerificationUnit) {
                VERIFICATION_A.updateLocalData(units[i]);
            }
        }
        VERIFICATION_A.setDefaultSelection();
        
//        updateAndShowLocalData();
        
//        VERIFICATION_A.showLocalData();
//        // Need to update windows if an existing project was reloaded, otherwise
//        // update is handled by the table selection listener (which listens for
//        // a change in selection).
//        final Vector<VerificationUnit> a = VERIFICATION_A.getVerificationUnits();
//        final int rows = a.size();
//        if (rows == units.length) {
//            for (int i = 0; i < rows; i++) {
//                if (!a.get(i).toString().equals(units[i].toString())) {
//                    break;
//                }
//                if (i == (rows - 1)) {
//                    updateAndShowLocalData();
//                }
//            }
//        }
    }

    /**
     * Sets the file choosers.
     */
    private void setFileChoosers() {
        final InputFileFilter filter = new InputFileFilter(
                new String[]{"evs"});
        saveChooser = new EVSFileChooser() {

            @Override
            public void approveSelection() {
                File f = this.getSelectedFile();
                final String filename = f.getName();
                f = new File(f.getParent(), filename);
                final File f1 = new File(f.getParent(), filename + ".evs");
                if (!f.equals(projectFile) && f.exists() || f1.exists()) {
                    final int result = JOptionPane.showConfirmDialog(
                            this,
                            "The file "
                            + filename
                            + " already exists, would you like to overwrite it?",
                            "Overwrite?", JOptionPane.YES_NO_OPTION,
                            JOptionPane.WARNING_MESSAGE);
                    if (result == JOptionPane.OK_OPTION) {
                        super.approveSelection();
                        saveChooser.setDefaultDirectory(f);
                    }
                } else {
                    super.approveSelection();
                    saveChooser.setDefaultDirectory(f);
                }
            }
        };
        saveChooser.addChoosableFileFilter(filter);
        saveChooser.setPreferredSize(new Dimension(500, 330));
        openChooser = new EVSFileChooser();
        openChooser.addChoosableFileFilter(filter);
        openChooser.setPreferredSize(new Dimension(500, 330));
        newProjChooser = new EVSFileChooser() {

            @Override
            public void approveSelection() {
                File f = this.getSelectedFile();
                final String filename = f.getName();
                f = new File(f.getParent(), filename);
                final File f1 = new File(f.getParent(), filename + ".evs");
                if (f.exists() || f1.exists()) {
                    final int result = JOptionPane.showConfirmDialog(
                            this,
                            "The file "
                            + filename
                            + " already exists, would you like to overwrite it?",
                            "Overwrite?", JOptionPane.YES_NO_OPTION,
                            JOptionPane.WARNING_MESSAGE);
                    if (result == JOptionPane.OK_OPTION) {
                        super.approveSelection();
                        newProjChooser.setDefaultDirectory(f);
                    }
                } else {
                    super.approveSelection();
                    newProjChooser.setDefaultDirectory(f);
                }
            }
        };
        newProjChooser.setDialogTitle("New project");
        newProjChooser.addChoosableFileFilter(filter);
        newProjChooser.setPreferredSize(new Dimension(500, 330));
    }

    /**
     * Opens a project by first displaying a file dialog.
     */
    private void openProject() {
//        boolean updateDisplay = false;  //JB @ August 2012
        // Save an existing project?
        if (projectFile != null) {
            final int n = JOptionPane.showOptionDialog(main,
                    "Save changes to current project?", "Save project",
                    JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE,
                    null, null, null);
            if (n == JOptionPane.YES_OPTION) {
                if (EVSMainWindow.main.showSaveProjectDialog(false)) {
                    saveProject(true); // Save existing project
                }
            }
            //updateDisplay = true; //JB @ August 2012
            openChooser.setCurrentDirectory(projectFile);
        } else if (projectFile == null
                && VERIFICATION_A.getVerificationUnits().size() > 0) {
            final int n = JOptionPane.showOptionDialog(main,
                    "Save existing objects to new project?", "Save project",
                    JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE,
                    null, null, null);
            if (n == JOptionPane.YES_OPTION) {
                if (EVSMainWindow.main.showSaveProjectDialog(true)) {
                    saveProject(true); // Save with given name
                }
            }
//            updateDisplay = true; //JB @ August 2012
        }
        final int status = openChooser.showOpenDialog(this);
        if (status == EVSFileChooser.APPROVE_OPTION) {
            try {
                final File selectedFile = openChooser.getSelectedFile();
                final AnalysisUnit[] units = readObjects(selectedFile);
                addUnits(units);
                projectFile = selectedFile;
                if (projectFile != null) {
                    setTitle("Ensemble Verification System (EVS)  [Project '"
                            + projectFile.getName().substring(0,
                            projectFile.getName().length() - 4) + "']");
                }
                // Return to first window
                mainTabbedPane.setSelectedIndex(0);
                final JPanel model = (JPanel) VERIFICATION_A.getParent();
                ((CardLayout) model.getLayout()).first(model);
                //Update display
//                if(updateDisplay) { 
//                    updateAndShowLocalData(); //JB @ August 2012
//                }
            } catch (final Throwable e) {
                e.printStackTrace();
                CONSOLE.addMessage(StringUtilities.stackTraceToString(e));
                ExceptionHandler.displayException(e);
            }
        }
    }

    /**
     * Closes an existing project.
     */
    private void closeProject() {
        // Save an existing project?
        if (projectFile != null) {
            final int n = JOptionPane.showOptionDialog(main,
                    "Save changes to current project?", "Save project",
                    JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE,
                    null, null, null);
            if (n == JOptionPane.YES_OPTION) {
                if (EVSMainWindow.main.showSaveProjectDialog(false)) {
                    saveProject(true); // Save to existing project
                }
            }
        } else if (projectFile == null
                && VERIFICATION_A.getVerificationUnits().size() > 0) {
            final int n = JOptionPane.showOptionDialog(main,
                    "Save existing objects to new project?", "Save project",
                    JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE,
                    null, null, null);
            if (n == JOptionPane.YES_OPTION) {
                if (EVSMainWindow.main.showSaveProjectDialog(true)) {
                    saveProject(true); // Save with a new name
                }
            }
        }
        if (VERIFICATION_A.getVerificationUnits().size() > 0) {
            VERIFICATION_A.clearAllLocalData();
        }
        setTitle("Ensemble Verification System (EVS)");
        projectFile = null;
    }

    /**
     * Creates a new project.
     */
    private void newProject() {
        // Save an existing project?
        if (projectFile != null) {
            final int n = JOptionPane.showOptionDialog(main,
                    "Save changes to current project?", "Save project",
                    JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE,
                    null, null, null);
            if (n == JOptionPane.YES_OPTION) {
                if (EVSMainWindow.main.showSaveProjectDialog(false)) {
                    saveProject(true); // Save to existing project
                }
            }
        } else if (projectFile == null
                && VERIFICATION_A.getVerificationUnits().size() > 0) {
            final int n = JOptionPane.showOptionDialog(main,
                    "Save existing objects to new project?", "Save project",
                    JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE,
                    null, null, null);
            if (n == JOptionPane.YES_OPTION) {
                if (EVSMainWindow.main.showSaveProjectDialog(true)) {
                    saveProject(true); // Save with a new name
                }
            }
        }
        // Create new project
        if (projectFile != null) {
            newProjChooser.setCurrentDirectory(projectFile);
        }
        final int status = newProjChooser.showSaveDialog(this);
        if (status == EVSFileChooser.APPROVE_OPTION) {
            projectFile = newProjChooser.getSelectedFile();
            String name = projectFile.getName();
            final String path = projectFile.getPath();
            if (!name.endsWith(".evs")) {
                projectFile = new File(path.substring(0, path.indexOf(name)),
                        name + ".evs");
                name = name + ".evs";
            }
            setTitle("Ensemble Verification System (EVS)  [Project '"
                    + name.substring(0, name.length() - 4) + "']");
            if (VERIFICATION_A.getVerificationUnits().size() > 0) {
                VERIFICATION_A.clearAllLocalData();
            }
            // Create an empty project file
            if (projectFile != null) {
                try {
                    final boolean write = writeObjects(projectFile);
                    // Return to defaults
                    AnalysisUnit.returnToDefaults();
                } catch (final Exception e) {
                    ExceptionHandler.displayException(e);
                }
            }
        }
    }

    /**
     * Converts an existing paired file to a flat text format.
     * 
     * @param paired
     *            the path to the paired file
     * @param output
     *            the path to the output file
     * @param nV
     *            the null value
     */
    private static void convertPairedFile(final String paired,
            final String output, final double nV) {
        if (paired == null || output == null) {
            throw new IllegalArgumentException(
                    "Specify valid names for the input and output files.");
        }
        try {
            PairedFileIO.readPairedFileWriteASCII(new File(paired), new File(
                    output), new IOState(), " ", nV);
        } catch (final Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Reads an observed file in the NWS card format an writes to a file
     * containing ascii.
     * 
     * @param in
     *            the path to the input file
     * @param out
     *            the path to the output file
     */
    private static void convertCardObservedFile(final String in,
            final String out, final double nV) {
        if (in == null || out == null) {
            throw new IllegalArgumentException(
                    "Specify valid names for the input and output files.");
        }
        try {
            OHDFileIO.readCardObservationsWriteASCII(new File(in),
                    new File(out), " ", null, nV);
        } catch (final Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Reads a forecast file in the NWS card format an writes to a file
     * containing ascii.
     * 
     * @param in
     *            the path to the input file
     * @param out
     *            the path to the output file
     * @param nV
     *            the null value
     */
    private static void convertCardForecastFile(final String in,
            final String out, final double nV) {
        if (in == null || out == null) {
            throw new IllegalArgumentException(
                    "Specify valid names for the input and output files.");
        }
        try {
            OHDFileIO.readCardForecastsWriteASCII(new File(in), new File(out),
                    " ", null, nV);
        } catch (final Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Reads a forecast file in the NWS CS binary format and writes to a file
     * containing ascii.
     * 
     * @param in
     *            the path to the input file
     * @param out
     *            the path to the output file
     * @param nV
     *            the null value
     */
    private static void convertBinFile(final String in, final String out,
            final double nV) {
        if (in == null || out == null) {
            throw new IllegalArgumentException(
                    "Specify valid names for the input and output files.");
        }
        try {
            OHDFileIO.readBinaryForecastsWriteASCII(new File(in),
                    new File(out), " ", null, nV);
        } catch (final Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to create and show the GUI.
     */
    
    private static void createAndShowGUI() {
        // Initalize all required static classes prior to
        // running EVS
        new GlobalUnitsReader();
        new MeasurementUnitsChangeLibrary();
        try {
            // Color contrast = new Color(188, 188, 206);
            final Color contrast = new Color(190, 203, 222);
            final Color standard = new Color(241, 240, 227);
            final Color desktop = new Color(164, 164, 158);
            final Color selection = new Color(96, 128, 172);
            final Color rollover = new Color(255, 207, 49);
            final Color highlight = new Color(249, 224, 137);
            final com.incors.plaf.alloy.AlloyTheme theme = CustomThemeFactory.createTheme(contrast, standard, desktop, selection,
                    rollover, highlight);
            AlloyLookAndFeel.setProperty("alloy.licenseCode",
                    "4#James_Brown#1g2r7nj#5z9r8g");
            final LookAndFeel alloy = new AlloyLookAndFeel(theme);
            AlloyLookAndFeel.setProperty("alloy.isLookAndFeelFrameDecoration",
                    "true");
            //Windows L&F example
            //UIManager.setLookAndFeel(new com.sun.java.swing.plaf.windows.WindowsLookAndFeel());
            
            UIManager.setLookAndFeel(alloy);
            JFrame.setDefaultLookAndFeelDecorated(true);
            JDialog.setDefaultLookAndFeelDecorated(true);
            ToolTipManager.sharedInstance().setDismissDelay(10000);

            // Set all file choosers read only
            UIManager.put("FileChooser.readOnly", Boolean.TRUE);
            // Word wrap option pane
            UIManager.getDefaults().put(OptionPaneUI.class.getSimpleName(),
                    OptionPaneMultiLineUI.class.getCanonicalName());

            // Initialize application
            main = new EVSMainWindow();
            main.main = main;
            ExceptionHandler.setConsole(CONSOLE);
            try {
                final ImageIcon icon = new ImageIcon(main.getClass().getResource(EVSConstants.IMAGE_DIR + "Rand.png"));
                final Image img = icon.getImage();
                main.setIconImage(img);
            } catch (final Exception e) {
                System.out.println("Could not load image icon from file '"
                        + EVSConstants.IMAGE_DIR + "Rand.png'");
                // e.printStackTrace();
            }
            //Set the temporary directory
            //Decompress /statsexplained directory and its content from EVS.jar to temp directory
            try {
                tempDir = System.getProperty("java.io.tmpdir");                
                if (OHDUtilities.isWindowsPlatform()) {
                    tempDir = OHDUtilities.getWindowsPath(tempDir);
                }
                String writeDir = tempDir+EVSConstants.STATS_EXPLAINED_DIR;
                ResourceTools.copyFolder(EVSConstants.STATS_EXPLAINED_DIR, writeDir);
            } catch (Exception e) {
                System.err.println("Failed to decompress '" + tempDir + "' to temporary directory for browsing.");
            }
            
            main.setVisible(true);
            main.setExtendedState(MAXIMIZED_BOTH);
        } catch (final Throwable t) {
            t.printStackTrace();
            writeLogFile(t);
            try {
                System.exit(1);
            } catch (final SecurityException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Attempts to write a log file to "C:/temp" on encountering an execution
     * error.
     * 
     * @param error
     *            the error to write to file.
     */
    private static void writeLogFile(final Throwable error) {
        BufferedWriter out = null;
        try {
            final File f = new File("C:/", "evs.log");
            out = new BufferedWriter(new FileWriter(f));
            out.write(StringUtilities.stackTraceToString(error));
        } catch (final Exception e) {
            // Do nothing
        } finally {
            if (out != null) {
                try {
                    out.close();
                } catch (final Exception e) {
                    // Do nothing
                }
            }
        }
    }

    /**
     * Initializes the window components.
     */
    // <editor-fold defaultstate="collapsed"
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        taskBar = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        newProjButton = new javax.swing.JButton();
        jPanel18 = new javax.swing.JPanel();
        projButton = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        saveButton = new javax.swing.JButton();
        jPanel19 = new javax.swing.JPanel();
        helpButton = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        mainTabbedPane = new javax.swing.JTabbedPane();
        verificationPanel = new javax.swing.JPanel();
        verificationA = VERIFICATION_A;
        verificationB = VERIFICATION_B;
        aggregationPanel = new javax.swing.JPanel();
        aggregationA = AGGREGATION_A;
        outputPanel = new javax.swing.JPanel();
        outputA = OUTPUT_A;
        menuBar = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        menuItemNewProject = new javax.swing.JMenuItem();
        menuItemOpen = new javax.swing.JMenuItem();
        menuItemClose = new javax.swing.JMenuItem();
        menuItemSave = new javax.swing.JMenuItem();
        menuItemSaveAs = new javax.swing.JMenuItem();
        menuItemExit = new javax.swing.JMenuItem();
        helpMenu = new javax.swing.JMenu();
        jMenu_Help_Messages = new javax.swing.JMenuItem();
        jMenu_Console = new javax.swing.JMenuItem();
        jMenu_About = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBounds(new java.awt.Rectangle(0, 0, 0, 0));
        setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        setMinimumSize(new java.awt.Dimension(100, 25));
        setPreferredSize(new java.awt.Dimension(1024, 768));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                closeDialog(evt);
            }
        });
        getContentPane().setLayout(new javax.swing.BoxLayout(getContentPane(), javax.swing.BoxLayout.Y_AXIS));

        jPanel3.setMaximumSize(new java.awt.Dimension(32000, 3));
        jPanel3.setMinimumSize(new java.awt.Dimension(10, 3));
        jPanel3.setPreferredSize(new java.awt.Dimension(10, 3));
        getContentPane().add(jPanel3);

        taskBar.setMaximumSize(new java.awt.Dimension(32000, 30));
        taskBar.setMinimumSize(new java.awt.Dimension(0, 30));
        taskBar.setPreferredSize(new java.awt.Dimension(100, 30));
        taskBar.setLayout(new javax.swing.BoxLayout(taskBar, javax.swing.BoxLayout.LINE_AXIS));

        jPanel15.setBackground(new java.awt.Color(241, 240, 227));
        jPanel15.setMaximumSize(new java.awt.Dimension(5, 32767));
        jPanel15.setMinimumSize(new java.awt.Dimension(5, 10));
        jPanel15.setPreferredSize(new java.awt.Dimension(5, 10));
        taskBar.add(jPanel15);

        newProjButton.setBackground(new java.awt.Color(241, 240, 227));
        newProjButton.setFont(new java.awt.Font("Dialog", 1, 11)); // NOI18N
        newProjButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/NewProj24.png"))); // NOI18N
        newProjButton.setToolTipText("New project");
        newProjButton.setAlignmentX(0.5F);
        newProjButton.setBorder(null);
        newProjButton.setBorderPainted(false);
        newProjButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        newProjButton.setMaximumSize(new java.awt.Dimension(28, 28));
        newProjButton.setMinimumSize(new java.awt.Dimension(28, 28));
        newProjButton.setPreferredSize(new java.awt.Dimension(28, 28));
        newProjButton.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/images/NewProj16.png"))); // NOI18N
        newProjButton.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/images/NewProj24_rollover.png"))); // NOI18N
        newProjButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newProjButtonActionPerformed(evt);
            }
        });
        taskBar.add(newProjButton);

        jPanel18.setBackground(new java.awt.Color(241, 240, 227));
        jPanel18.setMaximumSize(new java.awt.Dimension(9, 32767));
        jPanel18.setMinimumSize(new java.awt.Dimension(9, 10));
        jPanel18.setPreferredSize(new java.awt.Dimension(9, 10));
        taskBar.add(jPanel18);

        projButton.setBackground(new java.awt.Color(241, 240, 227));
        projButton.setFont(new java.awt.Font("Dialog", 1, 11)); // NOI18N
        projButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/folder_open_24.png"))); // NOI18N
        projButton.setToolTipText("Open project");
        projButton.setAlignmentX(0.5F);
        projButton.setBorder(null);
        projButton.setBorderPainted(false);
        projButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        projButton.setMaximumSize(new java.awt.Dimension(28, 28));
        projButton.setMinimumSize(new java.awt.Dimension(28, 28));
        projButton.setPreferredSize(new java.awt.Dimension(28, 28));
        projButton.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/images/folder_open_16.png"))); // NOI18N
        projButton.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/images/folder_open_24_rollover.png"))); // NOI18N
        projButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                projButtonActionPerformed(evt);
            }
        });
        taskBar.add(projButton);

        jPanel1.setBackground(new java.awt.Color(241, 240, 227));
        jPanel1.setMaximumSize(new java.awt.Dimension(9, 32767));
        jPanel1.setMinimumSize(new java.awt.Dimension(9, 10));
        jPanel1.setPreferredSize(new java.awt.Dimension(9, 10));
        taskBar.add(jPanel1);

        saveButton.setBackground(new java.awt.Color(241, 240, 227));
        saveButton.setFont(new java.awt.Font("Dialog", 1, 11)); // NOI18N
        saveButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Save24.png"))); // NOI18N
        saveButton.setToolTipText("Save project");
        saveButton.setAlignmentX(0.5F);
        saveButton.setBorder(null);
        saveButton.setBorderPainted(false);
        saveButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        saveButton.setMaximumSize(new java.awt.Dimension(28, 28));
        saveButton.setMinimumSize(new java.awt.Dimension(28, 28));
        saveButton.setPreferredSize(new java.awt.Dimension(28, 28));
        saveButton.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Save16.png"))); // NOI18N
        saveButton.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Save24_rollover.png"))); // NOI18N
        saveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveButtonActionPerformed(evt);
            }
        });
        taskBar.add(saveButton);

        jPanel19.setBackground(new java.awt.Color(241, 240, 227));
        jPanel19.setMaximumSize(new java.awt.Dimension(9, 32767));
        jPanel19.setMinimumSize(new java.awt.Dimension(9, 10));
        jPanel19.setPreferredSize(new java.awt.Dimension(9, 10));
        taskBar.add(jPanel19);

        helpButton.setBackground(new java.awt.Color(241, 240, 227));
        helpButton.setFont(new java.awt.Font("Dialog", 1, 11)); // NOI18N
        helpButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/help24.png"))); // NOI18N
        helpButton.setToolTipText("Turn help messages on/off");
        helpButton.setAlignmentX(0.5F);
        helpButton.setBorder(null);
        helpButton.setBorderPainted(false);
        helpButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        helpButton.setMaximumSize(new java.awt.Dimension(28, 28));
        helpButton.setMinimumSize(new java.awt.Dimension(28, 28));
        helpButton.setPreferredSize(new java.awt.Dimension(28, 28));
        helpButton.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/images/help16.png"))); // NOI18N
        helpButton.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/images/help24_rollover.png"))); // NOI18N
        helpButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                helpButtonActionPerformed(evt);
            }
        });
        taskBar.add(helpButton);

        getContentPane().add(taskBar);

        jPanel2.setMaximumSize(new java.awt.Dimension(32000, 3));
        jPanel2.setMinimumSize(new java.awt.Dimension(10, 3));
        jPanel2.setPreferredSize(new java.awt.Dimension(10, 3));
        getContentPane().add(jPanel2);

        mainTabbedPane.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        mainTabbedPane.setMaximumSize(new java.awt.Dimension(32000, 32000));
        mainTabbedPane.setMinimumSize(new java.awt.Dimension(0, 0));
        mainTabbedPane.setPreferredSize(new java.awt.Dimension(1024, 768));

        verificationPanel.setMinimumSize(new java.awt.Dimension(32000, 186));
        verificationPanel.setPreferredSize(new java.awt.Dimension(32000, 800));
        verificationPanel.setLayout(new java.awt.CardLayout());
        verificationPanel.add(verificationA, "card2");
        verificationPanel.add(verificationB, "card3");

        mainTabbedPane.addTab("Verification    ", verificationPanel);

        aggregationPanel.setLayout(new java.awt.CardLayout());
        aggregationPanel.add(aggregationA, "card2");

        mainTabbedPane.addTab("Aggregation   ", aggregationPanel);

        outputPanel.setLayout(new java.awt.CardLayout());
        outputPanel.add(outputA, "card2");

        mainTabbedPane.addTab("Output           ", outputPanel);

        getContentPane().add(mainTabbedPane);

        menuBar.setMaximumSize(new java.awt.Dimension(62, 32000));

        fileMenu.setText("File");
        fileMenu.setToolTipText("File menu");

        menuItemNewProject.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/NewProj16.png"))); // NOI18N
        menuItemNewProject.setText("  New project...");
        menuItemNewProject.setToolTipText("Create a new project");
        menuItemNewProject.setMinimumSize(new java.awt.Dimension(32767, 32767));
        menuItemNewProject.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuItemNewProjectActionPerformed(evt);
            }
        });
        fileMenu.add(menuItemNewProject);

        menuItemOpen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/folder_open_16.png"))); // NOI18N
        menuItemOpen.setText("  Open project...");
        menuItemOpen.setToolTipText("Open an existing project");
        menuItemOpen.setMinimumSize(new java.awt.Dimension(32767, 32767));
        menuItemOpen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuItemOpenActionPerformed(evt);
            }
        });
        fileMenu.add(menuItemOpen);

        menuItemClose.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Close16.png"))); // NOI18N
        menuItemClose.setText("  Close project");
        menuItemClose.setToolTipText("Close the current project");
        menuItemClose.setMinimumSize(new java.awt.Dimension(32767, 32767));
        menuItemClose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuItemCloseActionPerformed(evt);
            }
        });
        fileMenu.add(menuItemClose);

        menuItemSave.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Save16.png"))); // NOI18N
        menuItemSave.setText("  Save project");
        menuItemSave.setToolTipText("Save the current project");
        menuItemSave.setMinimumSize(new java.awt.Dimension(32767, 32767));
        menuItemSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuItemSaveActionPerformed(evt);
            }
        });
        fileMenu.add(menuItemSave);

        menuItemSaveAs.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Save16.png"))); // NOI18N
        menuItemSaveAs.setText("  Save project as...");
        menuItemSaveAs.setToolTipText("Save the current project with a given name");
        menuItemSaveAs.setMinimumSize(new java.awt.Dimension(32767, 32767));
        menuItemSaveAs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuItemSaveAsActionPerformed(evt);
            }
        });
        fileMenu.add(menuItemSaveAs);

        menuItemExit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Stop16.png"))); // NOI18N
        menuItemExit.setText("  Exit");
        menuItemExit.setToolTipText("Exit DUE");
        menuItemExit.setMinimumSize(new java.awt.Dimension(32767, 32767));
        menuItemExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuItemExitActionPerformed(evt);
            }
        });
        fileMenu.add(menuItemExit);

        menuBar.add(fileMenu);

        helpMenu.setText("Help");
        helpMenu.setToolTipText("Help menu");

        jMenu_Help_Messages.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/help16.png"))); // NOI18N
        jMenu_Help_Messages.setText("  Messages on/off");
        jMenu_Help_Messages.setToolTipText("Turn help messages on/off");
        jMenu_Help_Messages.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenu_Help_MessagesActionPerformed(evt);
            }
        });
        helpMenu.add(jMenu_Help_Messages);

        jMenu_Console.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/console.png"))); // NOI18N
        jMenu_Console.setText("  Console");
        jMenu_Console.setToolTipText("View details of error messages");
        jMenu_Console.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenu_ConsoleActionPerformed(evt);
            }
        });
        helpMenu.add(jMenu_Console);

        jMenu_About.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/About16.png"))); // NOI18N
        jMenu_About.setText("  About");
        jMenu_About.setToolTipText("Shows the authorship and current version of DUE");
        jMenu_About.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenu_AboutActionPerformed(evt);
            }
        });
        helpMenu.add(jMenu_About);

        menuBar.add(helpMenu);

        setJMenuBar(menuBar);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Registers additional listeners for navigation.
     */
    private void regNavListeners() {
        // Register a change listener
        mainTabbedPane.addChangeListener(new ChangeListener() {
            // This method is called whenever the selected tab changes

            public void stateChanged(final ChangeEvent evt) {
                final JTabbedPane pane = (JTabbedPane) evt.getSource();
                // Get current tab
                final int sel = pane.getSelectedIndex();
                if (sel == 0) {
                    ((CardLayout) verificationPanel.getLayout()).first(verificationPanel);
                }
            }
        });
    }

    /**
     * Closes the current project.
     * 
     * @param evt
     *            an action event
     */
    private void menuItemCloseActionPerformed(
            final java.awt.event.ActionEvent evt) {// GEN-FIRST:event_menuItemCloseActionPerformed
        closeProject();
    }// GEN-LAST:event_menuItemCloseActionPerformed

    /**
     * Help requested.
     * 
     * @param evt
     *            an action event
     */
    private void helpButtonActionPerformed(final java.awt.event.ActionEvent evt) {// GEN-FIRST:event_helpButtonActionPerformed
        final ToolTipManager t = ToolTipManager.sharedInstance();
        t.setEnabled(!t.isEnabled());
    }// GEN-LAST:event_helpButtonActionPerformed

    /**
     * Save the current project.
     * 
     * @param evt
     *            an action event
     */
    private void saveButtonActionPerformed(final java.awt.event.ActionEvent evt) {// GEN-FIRST:event_saveButtonActionPerformed
        if (showSaveProjectDialog(false)) {
            saveProject(true);
        }
    }// GEN-LAST:event_saveButtonActionPerformed

    /**
     * Open a saved project.
     * 
     * @param evt
     *            an action event
     */
    private void projButtonActionPerformed(final java.awt.event.ActionEvent evt) {// GEN-FIRST:event_projButtonActionPerformed
        openProject();
    }// GEN-LAST:event_projButtonActionPerformed

    /**
     * create a new project.
     * 
     * @param evt
     *            an action event
     */
    private void newProjButtonActionPerformed(
            final java.awt.event.ActionEvent evt) {// GEN-FIRST:event_newProjButtonActionPerformed
        newProject();
    }// GEN-LAST:event_newProjButtonActionPerformed

    /**
     * Display information about the software.
     * 
     * @param evt
     *            an action event
     */
    private void jMenu_AboutActionPerformed(final java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jMenu_AboutActionPerformed
        EVSMainWindow.setWindowLocation(about);
        about.setVisible(true);
    }// GEN-LAST:event_jMenu_AboutActionPerformed

    /**
     * Show the console with error messages.
     * 
     * @param evt
     *            an action event
     */
    private void jMenu_ConsoleActionPerformed(
            final java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jMenu_ConsoleActionPerformed
        EVSMainWindow.main.setWindowLocation(CONSOLE);
        CONSOLE.setVisible(true);
    }// GEN-LAST:event_jMenu_ConsoleActionPerformed

    /**
     * Show or hide help messages as tool tips.
     * 
     * @param evt
     *            an action event
     */
    private void jMenu_Help_MessagesActionPerformed(
            final java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jMenu_Help_MessagesActionPerformed
        final ToolTipManager t = ToolTipManager.sharedInstance();
        t.setInitialDelay(1);
        t.setEnabled(!t.isEnabled());
    }// GEN-LAST:event_jMenu_Help_MessagesActionPerformed

    /**
     * Exits EVS.
     * 
     * @param evt
     *            an action event
     */
    private void menuItemExitActionPerformed(
            final java.awt.event.ActionEvent evt) {// GEN-FIRST:event_menuItemExitActionPerformed
        exit();
    }// GEN-LAST:event_menuItemExitActionPerformed

    /**
     * Save the current project with a given name.
     * 
     * @param evt
     *            an action event
     */
    private void menuItemSaveAsActionPerformed(
            final java.awt.event.ActionEvent evt) {// GEN-FIRST:event_menuItemSaveAsActionPerformed
        if (showSaveProjectDialog(true)) {
            saveProject(true);
        }
    }// GEN-LAST:event_menuItemSaveAsActionPerformed

    /**
     * Save the current project.
     * 
     * @param evt
     *            an action event
     */
    private void menuItemSaveActionPerformed(
            final java.awt.event.ActionEvent evt) {// GEN-FIRST:event_menuItemSaveActionPerformed
        if (showSaveProjectDialog(false)) {
            saveProject(true);
        }
    }// GEN-LAST:event_menuItemSaveActionPerformed

    /**
     * Opens a saved project.
     * 
     * @param evt
     *            an action event
     */
    private void menuItemOpenActionPerformed(
            final java.awt.event.ActionEvent evt) {// GEN-FIRST:event_menuItemOpenActionPerformed
        openProject();
    }// GEN-LAST:event_menuItemOpenActionPerformed

    /**
     * Creates a new project.
     * 
     * @param evt
     *            an action event
     */
    private void menuItemNewProjectActionPerformed(
            final java.awt.event.ActionEvent evt) {// GEN-FIRST:event_menuItemNewProjectActionPerformed
        newProject();
    }// GEN-LAST:event_menuItemNewProjectActionPerformed

    /**
     * Exits EVS.
     * 
     * @param evt
     *            an action event
     */
    private void closeDialog(final java.awt.event.WindowEvent evt) {// GEN-FIRST:event_closeDialog
        exit();
    }// GEN-LAST:event_closeDialog

    /**
     * Exits EVS.
     */
    private void exit() {
        final int n = JOptionPane.showOptionDialog(main,
                "Save project?",
                "Exiting EVS", JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.WARNING_MESSAGE, null, null, null);
        if (n == JOptionPane.YES_OPTION || n == JOptionPane.NO_OPTION) {
            try {
                if(n==JOptionPane.YES_OPTION) {
                    saveProject(true);
                }
                // Close dialogs used by several windows
                CONSOLE.setVisible(false);
                // Close dialogs used by each window
                VERIFICATION_A.disposeOfChildren();
                VERIFICATION_B.disposeOfChildren();
                AGGREGATION_A.disposeOfChildren();
                OUTPUT_A.disposeOfChildren();
                String deleteDir = tempDir+EVSConstants.STATS_EXPLAINED_DIR;
                try {
                    ResourceTools.deleteDir(deleteDir);
                } catch(Exception e) {
                    System.err.println("Failed to delete temporary directory: "+deleteDir);
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    System.exit(0);
                } catch (SecurityException f) {
                    f.printStackTrace();
                }
            }
        }
    }
    
    
    /**
     * Converts an XML file using an XSLT stylesheet, writing to the specified
     * output or standard out if null.
     * 
     * @param input the input file
     * @param style the style sheet
     * @param output the output location
     */
    
    private static void transformXML(String input, String style, String output) {
        PrintStream outStream = null;
        boolean close = false;
        try {
            System.out.println("Attempting to transform XML input file '"+input+"' "
                    + "with XSLT style sheet '"+style+"'.");
            outStream = System.out;
            if (output != null) {
                FileOutputStream out = new FileOutputStream(new File(output),true); //Append
                outStream = new PrintStream(out);  
                close = true;
            }
            XSLTControl.transform(new File(input), new File(style), outStream);
            //Don't print output message if writing to standard out
            if(output!=null) {
                System.out.println("XML transform complete: output written to '"+output+"'.");
            }
        } catch (Exception e) {
            System.err.println("Translation failed with the following errors:");
            e.printStackTrace();
        } finally {
            if(outStream!=null && close) {
                try {
                    outStream.close();
                } catch(Exception e) {
                    //Do nothing
                }
            }
        }
    }    
    
    /*******************************************************************************
     * 
     *                                 VARIABLES 
     * 
     *******************************************************************************/
    /**
     * Indicates a successful run.
     */
    public static final int SUCCESS = 101;
    /**
     * Indicates a failed run.
     */
    public static final int FAILURE = 102;
    /**
     * Instance of the main application window.
     */
    static EVSMainWindow main = null;
    
    /**
     * The temporary directory. The directory "/statsexplained" is copied to 
     * here for an external web browser to view files that explain each metric.
     */
    
    protected static String tempDir; 
    
    /**
     * The current project file.
     */
    private File projectFile = null;
    /**
     * Save project chooser.
     */
    private EVSFileChooser saveChooser = null;
    /**
     * Open project chooser.
     */
    private EVSFileChooser openChooser = null;
    /**
     * New project chooser.
     */
    private EVSFileChooser newProjChooser = null;
    /**
     * About box.
     */
    private final AboutBox about = new AboutBox();

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel aggregationA;
    private javax.swing.JPanel aggregationPanel;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JButton helpButton;
    private javax.swing.JMenu helpMenu;
    private javax.swing.JMenuItem jMenu_About;
    private javax.swing.JMenuItem jMenu_Console;
    private javax.swing.JMenuItem jMenu_Help_Messages;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JTabbedPane mainTabbedPane;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenuItem menuItemClose;
    private javax.swing.JMenuItem menuItemExit;
    private javax.swing.JMenuItem menuItemNewProject;
    private javax.swing.JMenuItem menuItemOpen;
    private javax.swing.JMenuItem menuItemSave;
    private javax.swing.JMenuItem menuItemSaveAs;
    private javax.swing.JButton newProjButton;
    private javax.swing.JPanel outputA;
    private javax.swing.JPanel outputPanel;
    private javax.swing.JButton projButton;
    private javax.swing.JButton saveButton;
    private javax.swing.JPanel taskBar;
    private javax.swing.JPanel verificationA;
    private javax.swing.JPanel verificationB;
    private javax.swing.JPanel verificationPanel;
    // End of variables declaration//GEN-END:variables
}
