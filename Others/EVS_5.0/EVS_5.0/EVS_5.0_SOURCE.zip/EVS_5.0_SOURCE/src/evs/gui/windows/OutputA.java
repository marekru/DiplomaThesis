package evs.gui.windows;

//Java swing dependencies
import evs.data.fileio.WriteOption;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

//Java awt dependencies
import java.awt.event.*;
import java.awt.*;

//Java util dependencies
import java.util.*;

//EVS dependencies
import evs.analysisunits.*;
import evs.metric.metrics.*;
import evs.metric.results.*;
import evs.metric.parameters.*;
import evs.gui.utilities.*;
import evs.utilities.*;

/**
 * Window to plot the verification statistics associated with a verification
 * unit or an aggregation unit.
 * 
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class OutputA extends JPanel implements GUIInterface {
    
/********************************************************************************
 *                                                                              *
 *                               CONSTRUCTOR                                    *
 *                                                                              *
 *******************************************************************************/
    
    /**
     * Construct the import dialog.
     */
    
     protected OutputA() {
        initComponents();
        unitTable.getColumnModel().getColumn(0).setPreferredWidth(5000);
        unitTable.getColumnModel().getColumn(1).setPreferredWidth(2000); 
        leadTable.getColumnModel().getColumn(0).setPreferredWidth(5000);
        leadTable.getColumnModel().getColumn(1).setPreferredWidth(850);  
        productTable.getColumnModel().getColumn(0).setPreferredWidth(5000);
        productTable.getColumnModel().getColumn(1).setPreferredWidth(850);  
        
        unitTable.setRowHeight(25);
        leadTable.setRowHeight(25);
        productTable.setRowHeight(25);
        //Only allow one row to be selected
        unitTable.getSelectionModel().setSelectionMode(unitTable.getSelectionModel().SINGLE_SELECTION);
        
        //Set the cell renderer to differentiate between statistic types
        unitTable.setDefaultRenderer(Object.class,new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                if(column == 1 && value instanceof String) {
                    if((value+"").equalsIgnoreCase("Verification")) {
                        super.setForeground(Color.blue);
                    }
                    else if((value+"").equalsIgnoreCase("Aggregation")) {
                        super.setForeground(Color.red);
                    }
                }
                else {
                    super.setForeground(Color.black);
                }
                return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }
        });
        
        //Add a listener to the unit table to coordinate local display
        ListSelectionListener unitListen = new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent evt) {
                //Display data if selection has been completed
                int row = unitTable.getSelectedRow();
                if(!evt.getValueIsAdjusting() && row >-1) {
                    productTable.clearSelection();  //Clear selection of product on new unit selection
                    showLocalData();
                }
            }
        };
        unitTable.getSelectionModel().addListSelectionListener(unitListen);
        unitTable.getColumnModel().getSelectionModel().addListSelectionListener(unitListen);
        
        //Add a listener to the product table to coordinate local display
        ListSelectionListener productListen = new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent evt) {
                //Display data if selection has been completed
                int row = productTable.getSelectedRow();
                if(!evt.getValueIsAdjusting() && row >-1) {
                    showLocalData();
                }
            }
        };
        productTable.getSelectionModel().addListSelectionListener(productListen);
        productTable.getColumnModel().getSelectionModel().addListSelectionListener(productListen);        
        gen = new ProductGeneratorDialog(false,false);
        
        bottomRightScrollPane.setViewportView(gen.getOptionPane());
        bottomRightScrollPane.getViewport().setBackground(bottomRightPanel.getBackground());
        
        //Hide additional options button until they become available
        moreButton.setVisible(false);
        
        setVisible(true);      
    }

/********************************************************************************
 *                                                                              *
 *                           INHERITED PUBLIC METHODS                           *
 *                                                                              *
 *******************************************************************************/       
    
    /**
     * Closes any open dialogs or frames associated with the GUI window.
     */
     
    public void disposeOfChildren() {
        if(gen!=null) {
            gen.dispose();
        }
    }
     
    /**
     * Saves the properties of the selected verification unit for the current
     * window.
     *
     * @return true if the data were saved
     */
    
    public boolean saveData() throws IllegalArgumentException {
        return true; //Nothing saved to unit here
    }  
     
    /**
     * Clears the window.
     */
    
    public void clearAllLocalData() {
        clearUnitTable();
        clearLeadTable();
        clearProductTable();
        localPars.clear();
        lastResult = null;
        gen.returnToDefaults();
    } 
     
    /**
     * Saves local data in the active input fields to a temporary store.
     */
    
    public void saveLocalData() {
        //Only booleans are edited and these are saved via check box listeners
    }
    
    /**
     * Displays the local data previously saved to a temporary store.  Local data 
     * should always be displayed in preference to saved data, because saved data 
     * should be used to update the store of local data once available. This will
     * only show data for a new unit selection, not a current selection.
     */
    
    public void showLocalData() {
        if(unitTable.getRowCount()==0) {
            setUnitTable(VERIFICATION_A.getVerificationUnits());
        }
        //Ensure a unit is selected
        int row = unitTable.getSelectedRow();
        if(row > -1 && unitTable.getValueAt(row,0)!=null) {
            //Populate the product table 
            AnalysisUnit an = (AnalysisUnit)unitTable.getValueAt(row,0);
            int pCount = productTable.getRowCount();
            int prodRow = productTable.getSelectionModel().getAnchorSelectionIndex();

            //Only update for a different unit
            if(pCount==0 || ((DisplayMetricResult)productTable.getValueAt(0,0)).getParentUnit()!=an) {
                setProductTable(an);
            }
            
            //Set the lead table if required: only update for a different metric
            if(prodRow > -1 && ! productTable.getSelectionModel().isSelectionEmpty() && 
                    productTable.getValueAt(0,0)!= null && prodRow < productTable.getRowCount() &&
                    productTable.getValueAt(prodRow,1).equals(true)) {
                DisplayMetricResult res = (DisplayMetricResult)productTable.getValueAt(prodRow,0);
                if(res != lastResult) {
                    setLeadTable(res);
                    lastResult = res;
                }
            }
            else {
                clearLeadTable();
            }
        }
        else {
            clearLeadTable();
            clearProductTable();
        }
    }

    /**
     * Updates local data with a saved AnalysisUnit.
     *
     * @param unit the unit
     */

    public void updateLocalData(AnalysisUnit unit) {
         updateLocalData();
    }

    /**
     * Updates local data. 
     */
    
    public void updateLocalData() {        
         //Clear the window
         clearAllLocalData();
         Vector<VerificationUnit> units = VERIFICATION_A.getVerificationUnits();
         if(units != null && units.size()>0) {
             setUnitTable(units); 
             //Set the store of local parameters
             Vector<AnalysisUnit> total = new Vector();
             int tot = unitTable.getRowCount();
             for(int i = 0; i < tot; i++) {
                total.add((AnalysisUnit)unitTable.getValueAt(i,0));
             }
             int length = total.size();
             //Iterate through the units
             for(int i = 0; i < length; i++) {
                 AnalysisUnit next = total.get(i);
                 if(next.hasMetrics()) {
                     TreeMap<String,Metric> nxtMet = next.getMetricsWithResults();
                     Iterator j = nxtMet.keySet().iterator();
                     
                     //Iterate through the metrics
                     Vector<DisplayMetricResult> results = new Vector();
                     while(j.hasNext()) {
                         Object metName = j.next();
                         Metric m = nxtMet.get(metName);

                         //Result type
                         int type = ForecastTypeParameter.REGULAR_FORECAST;
                         if (m.isSkillMetric()) {
                             type = ForecastTypeParameter.SKILL;
                         }
                         
                         //Results exist
                         if(m.hasResult(type)) {
                             //Get the results
                             MetricResultByLeadTime res = m.getResult(type);
                             //Add the new results
                             DisplayMetricResult nextDisp = new DisplayMetricResult(metName+"",res,m,next,type);
                             
                             //Include as a single product?
//                             int ID = m.getID();
//                             int stored = res.getLowestLevelResultID();
//                             if (stored==res.DOUBLE_RESULT 
//                                    || stored==res.ENSEMBLE_SCORE_DECOMPOSITION_RESULT 
//                                    || stored==res.INTEGER_RESULT
//                                    || ID == m.BOX_DIAGRAM_POOLED_BY_LEAD
//                                    || ID == m.ROCS) {
//                                 nextDisp.setSingleProduct(true);
//                             }
                             results.add(nextDisp);
                         }
                     }
                     if(results.size()>0) {
                         localPars.put(next,results);
                     }
                 }
             }
         }        
    }
    
    /**
     * Removes local data from the temporary store for a specified AnalysisUnit. 
     *
     * @param unit the unit
     */
    
    public void clearLocalData(AnalysisUnit unit) {
        clearAllLocalData();
    }            
         
/********************************************************************************
 *                                                                              *
 *                                PRIVATE METHODS                               *
 *                                                                              *
 *******************************************************************************/     

     /**
      * Sets the unit table.
      *
      * @param units the analysis units
      */
     
     private void setUnitTable(Vector<VerificationUnit> units) {
         //Add the verification units
         DefaultTableModel unitMod = (DefaultTableModel)unitTable.getModel();
         ArrayList<AggregationUnit> agg = new ArrayList<AggregationUnit>();  //Store of unique aggregation units
         unitMod.setRowCount(0);
         for(int i = 0; i < units.size(); i++) {
             //Check that the unit has metrics
             if(units.get(i).hasMetricsWithResults()) {
                 unitMod.addRow(new Object[]{units.get(i),"VERIFICATION"});
             }
             //JB @ 11th March 2013
             ArrayList<AggregationUnit> next = units.get(i).getAggregationUnits();
             for(AggregationUnit a : next) {
                 if(a.hasMetricsWithResults() && ! agg.contains(a)) {
                      agg.add(a);
                 }
             }
         }
         //Add the aggregation units last
         for(int i = 0; i < agg.size(); i++) {
             unitMod.addRow(new Object[]{agg.get(i),"AGGREGATION"});
         }
     }    
     
     /**
      * Sets the product table.
      *
      * @param unit the analysis unit for which products should be shown
      */
     
     private void setProductTable(AnalysisUnit unit) {
         DefaultTableModel mod = (DefaultTableModel)productTable.getModel();
         mod.setRowCount(0);
         if(unit != null) {
             Vector<DisplayMetricResult> results = localPars.get(unit);
             if (results != null) {
                 int length = results.size();
                 for (int i = 0; i < length; i++) {
                     mod.addRow(new Object[]{results.get(i), results.get(i).getInclude()});
                     //Register a listener on the JCheckBox cell editor to update the lead table
                     final TableCellEditor ed = productTable.getCellEditor(i, 1);
                     final JCheckBox c = (JCheckBox) ed.getTableCellEditorComponent(productTable, false, false, i, 1);
                     c.addActionListener(new ActionListener() {

                         public void actionPerformed(ActionEvent evt) {
                             ed.stopCellEditing();
                             int row = productTable.getSelectedRow();
                             if (row > -1) {
                                 DisplayMetricResult r = (DisplayMetricResult) productTable.getValueAt(row, 0);
                                 if (r != null) {
                                     r.setInclude(c.isSelected());
                                     if (!c.isSelected()) {
                                         r.setIncludeAllLeads(false);
                                     }
                                 }
                                 showLocalData();
                             }
                         }
                     });
                 }
             }
         }
     }
     
     /**
      * Sets the lead times available for a specified result.
      *
      * @param result the result to show
      */
     
     private void setLeadTable(DisplayMetricResult result) {
         if(result != null) { 
             Vector<Double> times = result.getLeadTimes();
             DefaultTableModel mod = (DefaultTableModel)leadTable.getModel();
             mod.setRowCount(0);
             int length = times.size();
             for(int i = 0; i < length; i++) {
                 double time = times.get(i);
                 mod.addRow(new Object[]{time,result.getIncludeLead(time)});
                 //Register a listener on the JCheckBox cell editor to update the lead table
                 final TableCellEditor ed = leadTable.getCellEditor(i,1);
                 final JCheckBox c = (JCheckBox)ed.getTableCellEditorComponent(leadTable,false,false,i,1);
                 c.addActionListener(new ActionListener() {
                     public void actionPerformed(ActionEvent evt) {
                         ed.stopCellEditing();
                         int row = productTable.getSelectedRow();
                         int row2 = leadTable.getSelectedRow();
                         if(row > -1 && row2 > -1) {
                             DisplayMetricResult r = (DisplayMetricResult)productTable.getValueAt(row,0);
                             if(r != null) {
                                 r.setIncludeLead((Double)leadTable.getValueAt(row2,0),c.isSelected());
                             }
                         }
                     }
                 });
             }
             leadTable.setPreferredSize(new Dimension(450,(leadTable.getRowCount()+1)*25));
         }
     }     
     
     /**
      * Clears the units table.
      */
     
     private void clearUnitTable() {
         ((DefaultTableModel)unitTable.getModel()).setRowCount(0);
     }          
     
     /**
      * Clears the lead time table.
      */
     
     private void clearLeadTable() {
         ((DefaultTableModel)leadTable.getModel()).setRowCount(0);
         lastResult = null;
     }
     
     /**
      * Clears the product table.
      */
     
     private void clearProductTable() {
         ((DefaultTableModel)productTable.getModel()).setRowCount(0);
     }
     
     /**
      * Returns the products selected for generation.
      *
      * @return the products to do
      */
     
     private Vector<DisplayMetricResult> getProductsToDo() {
         //Check that one or more results will be displayed
         final Vector<DisplayMetricResult> toDisplay = new Vector();  //Results to display
         Iterator i = localPars.keySet().iterator();
         while(i.hasNext()) {
             Vector<DisplayMetricResult> result = localPars.get(i.next());
             int length = result.size();
             for(int j = 0; j < length; j++) {
                 DisplayMetricResult next = result.get(j);
                 if(next.getInclude() && next.hasIncludeTimes()) {
                     MetricResultByLeadTime res = next.getResult();
                     //Construct a new result with selected lead times to display
                     MetricResultByLeadTime newResult = new MetricResultByLeadTime(res.getIDForStoredResults());
                     int len = res.getResultCount();
                     Vector<Double> leads = next.getLeadTimes();
                     for(int k = 0; k < len; k++) {
                         double hours = leads.get(k);
                         if(next.getIncludeLead(hours)) {
                             newResult.addResult(hours,res.getResult(hours));
                         }
                     }
                     DisplayMetricResult newDisp = new DisplayMetricResult(next.toString(),
                             newResult,next.getParentMetric(),next.getParentUnit(),next.getForecastType());
                     if(next.hasThreshold()) {
                         newDisp.setThreshold(next.getThreshold());
                     }
//                     if(next.getSingleProduct()) {
//                         newDisp.setSingleProduct(true);
//                     }
                     //Include all lead times
                     newDisp.setIncludeAllLeads(true);
                     toDisplay.add(newDisp);
                 }
             }
         }
         return toDisplay;
     }
     
    /**
     * Initializes the window components.
     */      

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        leadTableMenu = new javax.swing.JPopupMenu();
        leadSelectAll = new javax.swing.JMenuItem();
        leadSelectSome = new javax.swing.JMenuItem();
        leadSelectNone = new javax.swing.JMenuItem();
        productTableMenu = new javax.swing.JPopupMenu();
        productSelectAllLeadsProducts = new javax.swing.JMenuItem();
        productSelectAllLeadsUnitsProducts = new javax.swing.JMenuItem();
        productSelectAllLeads = new javax.swing.JMenuItem();
        productSelectNone = new javax.swing.JMenuItem();
        unitTableMenu = new javax.swing.JPopupMenu();
        unitSelectAll = new javax.swing.JMenuItem();
        unitSelectNone = new javax.swing.JMenuItem();
        mainPanel = new javax.swing.JPanel();
        topPanel = new javax.swing.JPanel();
        topSplitPane = new javax.swing.JSplitPane();
        leftPanel = new javax.swing.JPanel();
        leftScrollPane = new javax.swing.JScrollPane();
        unitTable = new javax.swing.JTable();
        topRightPanel = new javax.swing.JPanel();
        topRightScrollPane = new javax.swing.JScrollPane();
        productTable = new javax.swing.JTable();
        topBottomSep = new javax.swing.JPanel();
        bottomPanel = new javax.swing.JPanel();
        bottomLeftPanel = new javax.swing.JPanel();
        bottomLeftScrollPane = new javax.swing.JScrollPane();
        leadTable = new javax.swing.JTable();
        bottomRightPanel = new javax.swing.JPanel();
        bottomRightScrollPane = new javax.swing.JScrollPane();
        navigationPanel = new javax.swing.JPanel();
        runButton = new javax.swing.JButton();
        jPanel1417 = new javax.swing.JPanel();
        moreButton = new javax.swing.JButton();
        jPanel20 = new javax.swing.JPanel();
        jPanel1416 = new javax.swing.JPanel();
        backButton = new javax.swing.JButton();
        jPanel1414 = new javax.swing.JPanel();
        startButton = new javax.swing.JButton();

        leadSelectAll.setText("Select all times");
        leadSelectAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                leadSelectAllActionPerformed(evt);
            }
        });
        leadTableMenu.add(leadSelectAll);

        leadSelectSome.setText("Select highlighted times");
        leadSelectSome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                leadSelectSomeActionPerformed(evt);
            }
        });
        leadTableMenu.add(leadSelectSome);

        leadSelectNone.setText("Clear selection");
        leadSelectNone.setPreferredSize(new java.awt.Dimension(75, 19));
        leadSelectNone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                leadSelectNoneActionPerformed(evt);
            }
        });
        leadTableMenu.add(leadSelectNone);

        productSelectAllLeadsProducts.setText("Select all times and products");
        productSelectAllLeadsProducts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                productSelectAllLeadsProductsActionPerformed(evt);
            }
        });
        productTableMenu.add(productSelectAllLeadsProducts);

        productSelectAllLeadsUnitsProducts.setText("Select all times for the highlighted products across all units");
        productSelectAllLeadsUnitsProducts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                productSelectAllLeadsUnitsProductsActionPerformed(evt);
            }
        });
        productTableMenu.add(productSelectAllLeadsUnitsProducts);

        productSelectAllLeads.setText("Select all times for the highlighted products");
        productSelectAllLeads.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                productSelectAllLeadsActionPerformed(evt);
            }
        });
        productTableMenu.add(productSelectAllLeads);

        productSelectNone.setText("Clear selection");
        productSelectNone.setPreferredSize(new java.awt.Dimension(75, 19));
        productSelectNone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                productSelectNoneActionPerformed(evt);
            }
        });
        productTableMenu.add(productSelectNone);

        unitSelectAll.setText("Select all products for all units");
        unitSelectAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                unitSelectAllActionPerformed(evt);
            }
        });
        unitTableMenu.add(unitSelectAll);

        unitSelectNone.setText("Clear selection");
        unitSelectNone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                unitSelectNoneActionPerformed(evt);
            }
        });
        unitTableMenu.add(unitSelectNone);

        setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        setMaximumSize(new java.awt.Dimension(32000, 500));
        setMinimumSize(new java.awt.Dimension(500, 330));
        setPreferredSize(new java.awt.Dimension(1024, 768));
        setLayout(new javax.swing.BoxLayout(this, javax.swing.BoxLayout.Y_AXIS));

        mainPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "1. Choose results to output", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 12), new java.awt.Color(0, 0, 0))); // NOI18N
        mainPanel.setLayout(new javax.swing.BoxLayout(mainPanel, javax.swing.BoxLayout.Y_AXIS));

        topPanel.setMinimumSize(new java.awt.Dimension(85, 0));
        topPanel.setPreferredSize(new java.awt.Dimension(39, 3000));
        topPanel.setLayout(new javax.swing.BoxLayout(topPanel, javax.swing.BoxLayout.LINE_AXIS));

        topSplitPane.setDividerSize(7);
        topSplitPane.setResizeWeight(0.5);
        topSplitPane.setMaximumSize(new java.awt.Dimension(32000, 32000));

        leftPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "1a. Select unit(s) with results", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11), new java.awt.Color(0, 0, 0))); // NOI18N
        leftPanel.setLayout(new java.awt.GridLayout(1, 0));

        leftScrollPane.setMaximumSize(new java.awt.Dimension(32000, 32000));
        leftScrollPane.setPreferredSize(new java.awt.Dimension(0, 0));

        unitTable.setModel(getUnitTableModel());
        unitTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                unitTableMousePressed(evt);
            }
        });
        leftScrollPane.setViewportView(unitTable);

        leftPanel.add(leftScrollPane);

        topSplitPane.setLeftComponent(leftPanel);

        topRightPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "1b. Choose products for selected unit", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11), new java.awt.Color(51, 51, 51))); // NOI18N
        topRightPanel.setLayout(new java.awt.GridLayout(1, 0));

        topRightScrollPane.setEnabled(false);
        topRightScrollPane.setMaximumSize(new java.awt.Dimension(32000, 32000));
        topRightScrollPane.setPreferredSize(new java.awt.Dimension(0, 0));

        productTable.setModel(getProductTableModel());
        productTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                productTableMousePressed(evt);
            }
        });
        topRightScrollPane.setViewportView(productTable);

        topRightPanel.add(topRightScrollPane);

        topSplitPane.setRightComponent(topRightPanel);

        topPanel.add(topSplitPane);

        mainPanel.add(topPanel);

        topBottomSep.setMaximumSize(new java.awt.Dimension(32767, 3));
        topBottomSep.setMinimumSize(new java.awt.Dimension(10, 3));
        topBottomSep.setPreferredSize(new java.awt.Dimension(10, 3));
        mainPanel.add(topBottomSep);

        bottomPanel.setMaximumSize(new java.awt.Dimension(32000, 32000));
        bottomPanel.setMinimumSize(new java.awt.Dimension(85, 0));
        bottomPanel.setPreferredSize(new java.awt.Dimension(39, 3000));
        bottomPanel.setLayout(new java.awt.GridLayout(1, 2));

        bottomLeftPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "1c. Choose lead times for selected product", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11), new java.awt.Color(0, 0, 0))); // NOI18N
        bottomLeftPanel.setLayout(new java.awt.GridLayout(1, 0));

        bottomLeftScrollPane.setEnabled(false);
        bottomLeftScrollPane.setMaximumSize(new java.awt.Dimension(32000, 32000));
        bottomLeftScrollPane.setPreferredSize(new java.awt.Dimension(0, 0));

        leadTable.setModel(getLeadTableModel());
        leadTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                leadTableMousePressed(evt);
            }
        });
        bottomLeftScrollPane.setViewportView(leadTable);

        bottomLeftPanel.add(bottomLeftScrollPane);

        bottomPanel.add(bottomLeftPanel);
        bottomLeftPanel.getAccessibleContext().setAccessibleName("Products to generate");

        bottomRightPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "1d. Choose output data type(s)", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11), new java.awt.Color(0, 0, 0))); // NOI18N
        bottomRightPanel.setLayout(new java.awt.GridLayout(1, 0));

        bottomRightScrollPane.setBorder(null);
        bottomRightScrollPane.setEnabled(false);
        bottomRightScrollPane.setMaximumSize(new java.awt.Dimension(32000, 32000));
        bottomRightScrollPane.setMinimumSize(new java.awt.Dimension(0, 0));
        bottomRightPanel.add(bottomRightScrollPane);

        bottomPanel.add(bottomRightPanel);

        mainPanel.add(bottomPanel);

        add(mainPanel);

        navigationPanel.setMaximumSize(new java.awt.Dimension(32899, 40));
        navigationPanel.setMinimumSize(new java.awt.Dimension(142, 40));
        navigationPanel.setPreferredSize(new java.awt.Dimension(144, 40));
        navigationPanel.setLayout(new javax.swing.BoxLayout(navigationPanel, javax.swing.BoxLayout.LINE_AXIS));

        runButton.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        runButton.setText("Run");
        runButton.setAlignmentY(0.25F);
        runButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        runButton.setMaximumSize(new java.awt.Dimension(65, 29));
        runButton.setMinimumSize(new java.awt.Dimension(65, 29));
        runButton.setPreferredSize(new java.awt.Dimension(65, 29));
        runButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                runButtonActionPerformed(evt);
            }
        });
        navigationPanel.add(runButton);

        jPanel1417.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel1417.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel1417.setPreferredSize(new java.awt.Dimension(4, 10));
        navigationPanel.add(jPanel1417);

        moreButton.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        moreButton.setText("More");
        moreButton.setToolTipText("Edit defaults for output");
        moreButton.setAlignmentY(0.25F);
        moreButton.setEnabled(false);
        moreButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        moreButton.setMaximumSize(new java.awt.Dimension(65, 29));
        moreButton.setMinimumSize(new java.awt.Dimension(65, 29));
        moreButton.setPreferredSize(new java.awt.Dimension(65, 29));
        moreButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                moreButtonActionPerformed(evt);
            }
        });
        navigationPanel.add(moreButton);

        jPanel20.setMinimumSize(new java.awt.Dimension(10, 29));
        navigationPanel.add(jPanel20);

        jPanel1416.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel1416.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel1416.setPreferredSize(new java.awt.Dimension(4, 10));
        navigationPanel.add(jPanel1416);

        backButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        backButton.setText("Back");
        backButton.setAlignmentY(0.25F);
        backButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        backButton.setMaximumSize(new java.awt.Dimension(65, 29));
        backButton.setMinimumSize(new java.awt.Dimension(65, 29));
        backButton.setPreferredSize(new java.awt.Dimension(65, 29));
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });
        navigationPanel.add(backButton);

        jPanel1414.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel1414.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel1414.setPreferredSize(new java.awt.Dimension(4, 10));
        navigationPanel.add(jPanel1414);

        startButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        startButton.setText("First");
        startButton.setAlignmentY(0.25F);
        startButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        startButton.setMaximumSize(new java.awt.Dimension(65, 29));
        startButton.setMinimumSize(new java.awt.Dimension(65, 29));
        startButton.setPreferredSize(new java.awt.Dimension(65, 29));
        startButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startButtonActionPerformed(evt);
            }
        });
        navigationPanel.add(startButton);

        add(navigationPanel);
    }// </editor-fold>//GEN-END:initComponents
   
    /**
     * Selects all times and products.
     *
     * @param evt an action event
     */    
    
    private void productSelectAllLeadsProductsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_productSelectAllLeadsProductsActionPerformed
        setAllLeadAndProductSelected(true);  
    }//GEN-LAST:event_productSelectAllLeadsProductsActionPerformed

    /**
     * Selects all lead times for the highlighted products
     *
     * @param evt an action event
     */        
    
    private void productSelectAllLeadsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_productSelectAllLeadsActionPerformed
        selectAllTimesByProducts();
    }//GEN-LAST:event_productSelectAllLeadsActionPerformed

    /**
     * Selects highlighted times.
     *
     * @param evt an action event
     */    
    
    private void leadSelectSomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_leadSelectSomeActionPerformed
        setSomeLeadSelected();  
    }//GEN-LAST:event_leadSelectSomeActionPerformed

    /**
     * Selects all times and products.
     *
     * @param evt an action event
     */    
    
    /**
     * Shows the menu for selecting or deselecting all products.
     *
     * @param evt an action event
     */  
    
    private void productTableMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_productTableMousePressed
        if(productTable.getRowCount()>0) {
            if(evt.getModifiers() == evt.BUTTON3_MASK) {
                productTableMenu.show(productTable,evt.getX(),evt.getY());
                productSelectNone.setVisible(true);
            }
        }
    }//GEN-LAST:event_productTableMousePressed
    
    /**
     * Deselects all products for a particular time.
     *
     * @param evt an action event
     */    
    
    private void productSelectNoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_productSelectNoneActionPerformed
        setAllLeadAndProductSelected(false);      
    }//GEN-LAST:event_productSelectNoneActionPerformed

    /**
     * Shows the menu for selecting or deselecting all lead times.
     *
     * @param evt an action event
     */     
    
    private void leadTableMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_leadTableMousePressed
        if(leadTable.getRowCount()>0) {
            if(evt.getModifiers() == evt.BUTTON3_MASK) {
                leadTableMenu.show(leadTable,evt.getX(),evt.getY());
                leadSelectAll.setVisible(true);
                leadSelectNone.setVisible(true);
            }
        }
    }//GEN-LAST:event_leadTableMousePressed

    /**
     * Deselects all lead times.
     *
     * @param evt an action event
     */    
    
    private void leadSelectNoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_leadSelectNoneActionPerformed
        setAllLeadSelection(false);
    }//GEN-LAST:event_leadSelectNoneActionPerformed

    /**
     * Generates the products with default options, namely writing graphics in PNG
     * format and writing numerics in XML format but not displaying them.
     *
     * @param evt an action event
     */
    
    private void runButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_runButtonActionPerformed
        try {
            final Vector<DisplayMetricResult> results = getProductsToDo();
            boolean dG = gen.getDisplayGraphics();
            boolean wG = gen.getWriteGraphics();
            boolean dN = gen.getDisplayNumerics();
            boolean wN = gen.getWriteNumerics();
            WriteOption opt = gen.getWriteOptions();
            ProductGeneratorDialog.generateProducts(results,dG,wG,dN,wN,opt,true);            
        }
        catch(Throwable e) {
            CONSOLE.addMessage(StringUtilities.stackTraceToString(e));
            ExceptionHandler.displayException(e);
        }
    }//GEN-LAST:event_runButtonActionPerformed

    /** 
     * Shows a dialog for generating the products.
     *
     * @param evt an action event
     */
    
    private void moreButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_moreButtonActionPerformed
//        try {
//            EVSMainWindow.setWindowLocation(gen);
//            gen.setVisible(true);
//        }
//        catch(Throwable e) {
//            CONSOLE.addMessage(StringUtilities.stackTraceToString(e));
//            ExceptionHandler.displayException(e);
//        }
}//GEN-LAST:event_moreButtonActionPerformed
        
    /**
     * Selects all lead times.
     *
     * @param evt an action event
     */
    
    private void leadSelectAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_leadSelectAllActionPerformed
        setAllLeadSelection(true);
    }//GEN-LAST:event_leadSelectAllActionPerformed
     
    /**
     * Returns to the first window.
     *
     * @param evt an action event
     */   
    
    private void startButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startButtonActionPerformed
        JPanel dis = (JPanel)this.getParent();
        JTabbedPane parent = (JTabbedPane)dis.getParent();
        ((CardLayout)VERIFICATION_A.getParent().getLayout()).first(VERIFICATION_A.getParent());
        parent.setSelectedIndex(0); 
    }//GEN-LAST:event_startButtonActionPerformed
                       
    /**
     * Returns to the previous window.
     *
     * @param evt an action event
     */    
    
    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        JPanel dis = (JPanel)this.getParent();
        JTabbedPane parent = (JTabbedPane)dis.getParent();
        parent.setSelectedIndex((parent.getSelectedIndex())-1);       
    }//GEN-LAST:event_backButtonActionPerformed

    /**
     * Selects all products for all units.
     *
     * @param evt an action event
     */

    private void unitSelectAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_unitSelectAllActionPerformed
        setAllUnitSelection(true);
    }//GEN-LAST:event_unitSelectAllActionPerformed

    /**
     * Deselects all products for all units.
     *
     * @param evt an action event
     */

    private void unitSelectNoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_unitSelectNoneActionPerformed
        setAllUnitSelection(false);
    }//GEN-LAST:event_unitSelectNoneActionPerformed

    /**
     * Show the unit table menu.
     * 
     * @param evt a mouse event
     */

    private void unitTableMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_unitTableMousePressed
        if(unitTable.getRowCount()>0) {
            if(evt.getModifiers() == evt.BUTTON3_MASK) {
                unitTableMenu.show(unitTable,evt.getX(),evt.getY());
            }
        }
    }//GEN-LAST:event_unitTableMousePressed


    /**
     * Selects all lead times for the highlighted products across all units.
     *
     * @param evt an action event
     */            
    
    private void productSelectAllLeadsUnitsProductsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_productSelectAllLeadsUnitsProductsActionPerformed
        selectAllTimesUnitsByProducts();
    }//GEN-LAST:event_productSelectAllLeadsUnitsProductsActionPerformed

    /**
     * Toggles the selection of all or no units according to the boolean input.
     *
     * @param selectAll is true to select all, false to deselect all
     */

    private void setAllUnitSelection(boolean selectAll) {
        Iterator it = localPars.keySet().iterator();
        while(it.hasNext()) {
            Vector<DisplayMetricResult> v = (Vector<DisplayMetricResult>)localPars.get(it.next());
            for(DisplayMetricResult s : v) {
                s.setInclude(selectAll);
                s.setIncludeAllLeads(selectAll);
            }
        }
        //Update products and lead table for currently selected unit (not done by show local data)
        setAllLeadAndProductSelected(selectAll);
    }

    /**
     * Toggles the selection of all or no lead times according to the boolean
     * input.
     *
     * @param selectAll is true to select all, false to deselect all
     */
    
    private void setAllLeadSelection(boolean selectAll) {
        int row = productTable.getSelectedRow();
        if(row > -1) {
            DisplayMetricResult s = (DisplayMetricResult)productTable.getValueAt(row,0);
            s.setIncludeAllLeads(selectAll);
            //Update lead table for currently selected unit (not done by show local data)
            int length = leadTable.getRowCount();
            for(int i = 0; i < length; i++) {
                leadTable.setValueAt(selectAll,i,1);
            }
        }
        showLocalData();
    }
 
    /**
     * Selects all lead times and products.
     *
     * @param selectAll is true to select all
     */
    
    private void setAllLeadAndProductSelected(boolean selectAll) {
        int rows = productTable.getRowCount();
        for(int i = 0; i < rows; i++) {
            DisplayMetricResult s = (DisplayMetricResult)productTable.getValueAt(i,0);
            //Update product table for currently selected unit (not done by show local data)
            productTable.setValueAt(selectAll,i,1);
            s.setInclude(selectAll);
            s.setIncludeAllLeads(selectAll);
        }
        //Update lead table for currently selected unit (not done by show local data)
        int tot = leadTable.getRowCount();
        if(tot > 0) {
            for(int j = 0; j < tot; j++) {
                leadTable.setValueAt(true,j,1);
            }
        }
        showLocalData();
    }         
    
    /**
     * Selects all lead times for the highlighted products.
     */
    
    private void selectAllTimesByProducts() {
        int[] rows = productTable.getSelectedRows();
        for(int i = 0; i < rows.length; i++) {
            DisplayMetricResult s = (DisplayMetricResult)productTable.getValueAt(rows[i],0);
            s.setInclude(true);
            s.setIncludeAllLeads(true);
            //Update product table for currently selected unit (not done by show local data)
            productTable.setValueAt(true,rows[i],1);
        }
        //Update lead table for currently selected unit (not done by show local data)
        if(rows.length > 0) {
            int tot = leadTable.getRowCount();
            for(int j = 0; j < tot; j++) {
                leadTable.setValueAt(true,j,1);
            }
        }
        showLocalData();                
    }
    
    /**
     * Selects all lead times for the highlighted products across all units.
     */
    
    private void selectAllTimesUnitsByProducts() {
        //Get required metrics
        HashSet<Integer> ids = new HashSet<Integer>();
        int[] rows = productTable.getSelectedRows();
        for(int r : rows) {
            DisplayMetricResult s = (DisplayMetricResult)productTable.getValueAt(r,0);
            ids.add(s.getParentMetric().getID());
            //Update product table for currently selected unit (not done by show local data)
            productTable.setValueAt(true,r,1);            
        }
        //Set all leads true
        Iterator it = localPars.keySet().iterator();
        while(it.hasNext()) {
            Vector<DisplayMetricResult> v = (Vector<DisplayMetricResult>)localPars.get(it.next());
            for(DisplayMetricResult s : v) {
                if(ids.contains(s.getParentMetric().getID())) {
                    s.setInclude(true);
                    s.setIncludeAllLeads(true);
                }
            }
        }        
        
        //Update lead table for currently selected unit (not done by show local data)
        if(rows.length > 0) {
            int tot = leadTable.getRowCount();
            for(int j = 0; j < tot; j++) {
                leadTable.setValueAt(true,j,1);
            }
        }
        showLocalData();                
    }    
    
    /**
     * Selects the highlighted lead times.
     */
    
    private void setSomeLeadSelected() {
        int[] rows = leadTable.getSelectedRows();
        int row = productTable.getSelectedRow();
        if(row > -1) {
            DisplayMetricResult s = (DisplayMetricResult)productTable.getValueAt(row,0);
            for(int i = 0; i < rows.length; i++) {
                s.setIncludeLead((Double)leadTable.getValueAt(rows[i],0),true);
                //Update lead table for currently selected unit (not done by show local data)
                leadTable.setValueAt(true,rows[i],1);
            }
        }
        showLocalData();                
    }    
    
    /**
     * Returns the units table model with a listener that sets the size of the 
     * units table according to the rows added or deleted.
     * 
     * @return a table model for the units table
     */
    
    private DefaultTableModel getUnitTableModel() {
        return new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Unit type"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
            
            public void fireTableRowsDeleted(int firstRow, int lastRow) {
                super.fireTableRowsDeleted(firstRow, lastRow);
                unitTable.setPreferredSize(new Dimension(75, unitTable.getRowHeight()
                        * (unitTable.getRowCount() + 1)));
            }

            public void fireTableRowsInserted(int firstRow, int lastRow) {
                super.fireTableRowsInserted(firstRow, lastRow);
                unitTable.setPreferredSize(new Dimension(75, unitTable.getRowHeight()
                        * (unitTable.getRowCount() + 1)));
            }
            
        };   
    }  

    /**
     * Returns the products table model with a listener that sets the size of the 
     * units table according to the rows added or deleted.
     * 
     * @return a table model for the products table
     */
    
    private DefaultTableModel getProductTableModel() {
        return new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Product", "Include?"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
            
            public void fireTableRowsDeleted(int firstRow, int lastRow) {
                super.fireTableRowsDeleted(firstRow, lastRow);
                productTable.setPreferredSize(new Dimension(75, productTable.getRowHeight()
                        * (productTable.getRowCount() + 1)));
            }

            public void fireTableRowsInserted(int firstRow, int lastRow) {
                super.fireTableRowsInserted(firstRow, lastRow);
                productTable.setPreferredSize(new Dimension(75, productTable.getRowHeight()
                        * (productTable.getRowCount() + 1)));
            }
            
        };  
    }   

    /**
     * Returns the lead time table model with a listener that sets the size of the 
     * units table according to the rows added or deleted.
     * 
     * @return a table model for the lead time table
     */
    
    private DefaultTableModel getLeadTableModel() {
        return new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Lead time (hours)", "Include?"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
            
            public void fireTableRowsDeleted(int firstRow, int lastRow) {
                super.fireTableRowsDeleted(firstRow, lastRow);
                leadTable.setPreferredSize(new Dimension(75, leadTable.getRowHeight()
                        * (leadTable.getRowCount() + 1)));
            }

            public void fireTableRowsInserted(int firstRow, int lastRow) {
                super.fireTableRowsInserted(firstRow, lastRow);
                leadTable.setPreferredSize(new Dimension(75, leadTable.getRowHeight()
                        * (leadTable.getRowCount() + 1)));
            }
            
        };  
    }   
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLES                              *
     *                                                                              *
     *******************************************************************************/
    
     /**
      * A store of local parameters for each analysis unit in the output window.
      * The map keys are analysis units and the values are vectors of lead time 
      * stores.
      */
    
    private TreeMap<AnalysisUnit,Vector<DisplayMetricResult>> localPars = new TreeMap();
    
    /**
     * Product generator dialog with options.
     */
    
    private ProductGeneratorDialog gen = null;
    
    /**
     * Last result displayed.
     */
    
    private DisplayMetricResult lastResult = null;
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.JPanel bottomLeftPanel;
    private javax.swing.JScrollPane bottomLeftScrollPane;
    private javax.swing.JPanel bottomPanel;
    private javax.swing.JPanel bottomRightPanel;
    private javax.swing.JScrollPane bottomRightScrollPane;
    private javax.swing.JPanel jPanel1414;
    private javax.swing.JPanel jPanel1416;
    private javax.swing.JPanel jPanel1417;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JMenuItem leadSelectAll;
    private javax.swing.JMenuItem leadSelectNone;
    private javax.swing.JMenuItem leadSelectSome;
    private javax.swing.JTable leadTable;
    private javax.swing.JPopupMenu leadTableMenu;
    private javax.swing.JPanel leftPanel;
    private javax.swing.JScrollPane leftScrollPane;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JButton moreButton;
    private javax.swing.JPanel navigationPanel;
    private javax.swing.JMenuItem productSelectAllLeads;
    private javax.swing.JMenuItem productSelectAllLeadsProducts;
    private javax.swing.JMenuItem productSelectAllLeadsUnitsProducts;
    private javax.swing.JMenuItem productSelectNone;
    private javax.swing.JTable productTable;
    private javax.swing.JPopupMenu productTableMenu;
    private javax.swing.JButton runButton;
    private javax.swing.JButton startButton;
    private javax.swing.JPanel topBottomSep;
    private javax.swing.JPanel topPanel;
    private javax.swing.JPanel topRightPanel;
    private javax.swing.JScrollPane topRightScrollPane;
    private javax.swing.JSplitPane topSplitPane;
    private javax.swing.JMenuItem unitSelectAll;
    private javax.swing.JMenuItem unitSelectNone;
    private javax.swing.JTable unitTable;
    private javax.swing.JPopupMenu unitTableMenu;
    // End of variables declaration//GEN-END:variables

}
