package evs.gui.windows;

//Java swing dependencies
import java.awt.Frame;
import java.awt.Dialog;

//EVS dependencies
import evs.utilities.StringUtilities;
import evs.gui.utilities.ErrorDialog;

/**
 * Class for informing users about run-time exceptions.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ExceptionHandler {

/*******************************************************************************
 *                                                                             *
 *                             INSTANCE VARIABLES                              *
 *                                                                             *
 ******************************************************************************/     
        
    /**
     * Console to which exceptions should be written.
     */
    
    private static Console con = null;

    /**
     * Error dialog.
     */
    
    private static ErrorDialog errors = null;    
    
/*******************************************************************************
 *                                                                             *
 *                              ACCESSOR METHODS                               *
 *                                                                             *
 ******************************************************************************/     
   
    /**
     * Displays an exception in a simple window using the EVS main window as the
     * parent.
     *
     * @param e the exception to display.
     */

    protected static void displayException(Throwable e) {
        displayException(e,EVSMainWindow.main);
    }    
    
    /**
     * Displays an exception in a simple window.
     *
     * @param owner the frame owner
     * @param e the exception to display.
     */

    protected static void displayException(Throwable e, Frame owner) {
        //Construct the error dialog
        errors = new ErrorDialog(owner, "Error dialog", "", "");
        EVSMainWindow.main.setWindowLocation(errors);
        appendThrowable(e, true);
    }
    
    /**
     * Displays an exception in a simple window.
     *
     * @param owner the dialog owner
     * @param e the exception to display.
     */
    
    protected static void displayException(Throwable e, Dialog owner) {
        //Construct the error dialog
        errors = new ErrorDialog(owner, "Error dialog", "", "");
        EVSMainWindow.main.setWindowLocation(errors);
        appendThrowable(e, true);
    }    

    /**
     * Appends a message from throwable to the console and shows an error dialog.
     * 
     * @param e the throwable
     * @param showMessage is true to show the error dialog
     */
    
    private static void appendThrowable(Throwable e, boolean showMessage) {
        if (con != null) {
            con.addMessage(StringUtilities.stackTraceToString(e));
        }
        //The message
        if (showMessage) {
            final String basicMessage = "Incorrect user action (see details).";
            final String extendedMessage = e.getMessage();
            errors.setMessages(basicMessage, extendedMessage);
            errors.setVisible(true);
        }
        e.printStackTrace();  //Bug fixing        
    }
    
/*******************************************************************************
 *                                                                             *
 *                              MUTATOR METHODS                                *
 *                                                                             *
 ******************************************************************************/     

    /**
     * Sets the console for writing output.
     *
     * @param console the console
     */
    
    protected static void setConsole(Console console) {
        con = console;
    }
    
}
