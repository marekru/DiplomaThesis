package evs.gui.windows;

import java.awt.Image;

import javax.swing.ImageIcon;

import evs.utilities.EVSConstants;
import evs.utilities.EVSUtilities;

/**
 * Shows the current version, copyright and authorship of EVS.
 * 
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class AboutBox extends javax.swing.JFrame {

    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/

    /**
     * Constructs the about box.
     */

    protected AboutBox() {
        initComponents();
        setTitle("About EVS");
        try {
            final ImageIcon icon = new ImageIcon(getClass().getResource(EVSConstants.IMAGE_DIR + "Rand.png"));
            final Image img = icon.getImage();
            setIconImage(img);
        }
        catch(final Exception e) {
            System.out.println("Could not load image icon from file '" + EVSConstants.IMAGE_DIR + "Rand.png'");
            //e.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        aboutPane = new javax.swing.JTextPane();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(450, 495));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        getContentPane().setLayout(new javax.swing.BoxLayout(getContentPane(), javax.swing.BoxLayout.Y_AXIS));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setMinimumSize(new java.awt.Dimension(450, 50));
        jPanel3.setPreferredSize(new java.awt.Dimension(450, 50));
        jPanel3.setLayout(new java.awt.GridLayout(1, 0));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/About_upper.png"))); // NOI18N
        jLabel1.setAlignmentX(0.5F);
        jPanel3.add(jLabel1);

        getContentPane().add(jPanel3);

        jPanel2.setMinimumSize(new java.awt.Dimension(500, 230));
        jPanel2.setPreferredSize(new java.awt.Dimension(450, 290));
        jPanel2.setLayout(new java.awt.GridLayout(1, 0));

        aboutPane.setEditable(false);
        aboutPane.setContentType(""); // NOI18N
        aboutPane.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        aboutPane.setText(EVSUtilities.getVersionInfo()+"\n"+"This software and related documentation was originally developed by the National Weather Service (NWS) and, subsequently, by Hydrologic Solutions Limited (HSL), hereafter referred to as \"The Developers\". Pursuant to Title 17, Section 105 of the United States Code this software is not subject to copyright protection and may be used, copied, modified, and distributed without fee or cost. Parties who develop software incorporating predominantly NWS developed software must include notice, as required by Title 17, Section 403 of the United States Code. The Developers provide no warranty, expressed or implied, as to the correctness of the furnished software or its suitability for any purpose. The Developers assume no responsibility, whatsoever, for its use by other parties, about its quality, reliability, or any other characteristic. The Developers may change this software to meet their own needs or discontinue its use without prior notice. The Developers cannot assist users without prior agreement and are not obligated to fix reported problems. The EVS is released under the GNU Lesser General Public License (LGPL) Version 3.0. A copy of the LGPL is provided with this distribution.");
        aboutPane.setToolTipText("");
        aboutPane.setMinimumSize(new java.awt.Dimension(6, 80));
        aboutPane.setPreferredSize(new java.awt.Dimension(6, 80));
        aboutPane.setSelectionColor(new java.awt.Color(255, 255, 255));
        jPanel2.add(aboutPane);

        getContentPane().add(jPanel2);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setMinimumSize(new java.awt.Dimension(450, 50));
        jPanel4.setPreferredSize(new java.awt.Dimension(450, 50));
        jPanel4.setLayout(new java.awt.GridLayout(1, 0));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/About_lower.png"))); // NOI18N
        jLabel2.setAlignmentX(0.5F);
        jLabel2.setMaximumSize(new java.awt.Dimension(450, 72));
        jLabel2.setMinimumSize(new java.awt.Dimension(450, 72));
        jLabel2.setPreferredSize(new java.awt.Dimension(450, 72));
        jPanel4.add(jLabel2);

        getContentPane().add(jPanel4);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /*******************************************************************************
     *                                                                             *
     *                                 METHODS                                     *
     *                                                                             *
     ******************************************************************************/

    /**
     * Detects window closing event.
     * 
     * @param evt the closing event.
     */

    private void formWindowClosing(final java.awt.event.WindowEvent evt)
    {//GEN-FIRST:event_formWindowClosing
        setVisible(false);
        dispose();
    }//GEN-LAST:event_formWindowClosing
    
    /*******************************************************************************
     *                                                                             *
     *                             INSTANCE VARIABLES                              *
     *                                                                             *
     ******************************************************************************/
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextPane aboutPane;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    // End of variables declaration//GEN-END:variables
}
