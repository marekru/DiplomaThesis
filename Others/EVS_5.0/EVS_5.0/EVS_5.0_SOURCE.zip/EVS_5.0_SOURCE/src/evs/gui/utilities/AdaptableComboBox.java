package evs.gui.utilities;

//Java dependencies
import javax.swing.*;
import java.awt.*;
import java.util.*;

/**
 * Provides a combo box whose menu adapts to the size of the widest item in the
 * menu. 
 * 
 * @author evs@hydrosolved.com
 */

public class AdaptableComboBox extends JComboBox {

    /**
     * Type.
     */
    
    private String type;
    
    /**
     * Is laying out.
     */
    
    private boolean layingOut = false;
    
    /**
     * Widest length.
     */
    private int widestLength = 0;
    
    /**
     * Is wide.
     */
    
    private boolean wide = false;

    /**
     * Construct with items.
     * 
     * @param objs the items
     */
    
    public AdaptableComboBox(Object[] objs) {
        super(objs);
    }
    
    /**
     * Construct with items.
     * 
     * @param objs the items
     */
    
    public AdaptableComboBox(Vector objs) {
        super(objs);
    }    
    
    /**
     * Construct without items.
     */
    
    public AdaptableComboBox() {
        super();
    }    

    /**
     * Returns true if adaptable, false otherwise.
     * 
     * @return true if adaptable
     */
    
    public boolean isWide() {
        return wide;
    }
    
    /**
     * Sets the JComboBox adaptable.
     * 
     * @param wide is true to use an adaptable box
     */
    
    public void setWide(boolean wide) {
        this.wide = wide;
        widestLength = getWidestItemWidth();
    }

    /**
     * Returns the size.
     * 
     * @return the size 
     */
    
    public Dimension getSize() {
        Dimension dim = super.getSize();
        if (!layingOut && isWide()) {
            dim.width = Math.max(widestLength,dim.width);
        }
        return dim;
    }

    /**
     * Returns the length of the widest item stored.
     * 
     * @return the length of the widest item
     */
    
    public int getWidestItemWidth() {              
        int numOfItems = getItemCount();
        Font font = getFont();
        FontMetrics metrics = getFontMetrics(font);
        int widest = 0;
        for (int i = 0; i < numOfItems; i++) {
            Object item = getItemAt(i);
            int lineWidth = metrics.stringWidth(item.toString());
            widest = Math.max(widest,lineWidth);
        }
        return widest + 35;  //Need to account for scroll pane
    }

    /**
     * Set the layout.
     */
    
    public void doLayout() {
        try {
            layingOut = true;
            super.doLayout();
        } finally {
            layingOut = false;
        }
    }

    /**
     * Return the type.
     * 
     * @return the type
     */
    
    public String getType() {
        return type;
    }

    /**
     * Sets the type.
     * 
     * @param t the type
     */
    
    public void setType(String t) {
        type = t;
    }

    public static void main(String[] args) {
        String title = "Combo Test";
        JFrame frame = new JFrame(title);

        AdaptableComboBox simpleCombo = new AdaptableComboBox();
        
        String[] items = new String[]{"I need a lot of width to be visible, I am visible now", "I need a lot of width to be visible, I am visible now"};
        DefaultComboBoxModel m = new DefaultComboBoxModel(items);
        simpleCombo.setModel(m);
        simpleCombo.setPreferredSize(new Dimension(180, 20));
        simpleCombo.setWide(true);
        JLabel label = new JLabel("Wider Drop Down Demo");

        frame.getContentPane().add(simpleCombo, BorderLayout.NORTH);
        frame.getContentPane().add(label, BorderLayout.SOUTH);
        int width = 200;
        int height = 150;
        frame.setSize(width, height);
        frame.setVisible(true);

    }
}
