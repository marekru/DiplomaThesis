package evs.gui.utilities;

//EVS dependencies
import evs.metric.parameters.DecomposeParameter;
import evs.metric.metrics.DecomposableScore;

//Java dependencies
import javax.swing.DefaultComboBoxModel;

/**
 * Class for storing and displaying score decomposition options in a combo box.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DisplayScoreDecompPar extends DefaultComboBoxModel {
    
    /**
     * Construct with a specified range of decomposition types and an initial
     * type.
     *
     * @param type the logical type
     */
    public DisplayScoreDecompPar(int[] types, int type) {
        super();
        DisplayScoreDecompParItem[] g = getItems(types);
        for(DisplayScoreDecompParItem item : g) {
            super.addElement(item);
        }
        setSelectedItem(new DisplayScoreDecompParItem(type));
    }

    /**
     * Sets the selected decomposition if available.
     *
     * @param type the decomposition type
     */
    public void setSelectedItem(int type) {
        try {
            setSelectedItem(new DisplayScoreDecompParItem(type));
        } catch(Exception e) {
            //Do nothing
        }
    }

    /**
     * Returns the selected decomposition type.
     *
     * @return the selected decomposition type
     */
    public DecomposeParameter getDecomposePar() {
        Object item = getSelectedItem();
        if(item!=null && item instanceof DisplayScoreDecompParItem) {
            return new DecomposeParameter(((DisplayScoreDecompParItem)item).type);
        }
        return new DecomposeParameter(false);
    }    
    
    /**
     * Returns a list of items to display based on the specified decomposition
     * types.
     * 
     * @param types the decomposition types
     */
    
    private DisplayScoreDecompParItem[] getItems(int[] types) {
        if(types == null || types.length == 0) {
            throw new IllegalArgumentException("Enter a valid array of decomposition options.");
        }
        DisplayScoreDecompParItem[] v = new DisplayScoreDecompParItem[types.length];
        //Always add DecomposableScore.NONE
        boolean noneThere = false;
        for(int i = 0; i < types.length; i++) {
            switch(types[i]) {
                case DecomposableScore.CALIBRATION_REFINEMENT:{}; break;
                case DecomposableScore.LIKELIHOOD_BASE_RATE:{}; break;
                case DecomposableScore.CR_AND_LBR:{}; break;
                case DecomposableScore.NONE:{noneThere=true;}; break;
                default: throw new IllegalArgumentException("Unrecognized score decomposition type for display.");
            }
            v[i]=new DisplayScoreDecompParItem(types[i]);
        }
        if(!noneThere) {
            DisplayScoreDecompParItem[] w = new DisplayScoreDecompParItem[types.length+1];
            w[0]=new DisplayScoreDecompParItem(DecomposableScore.NONE);
            System.arraycopy(v,0,w,1,v.length);
            v=w;
        }
        return v;
    }
    
    /**
     * Decomposition display item.
     */
    
    private final static class DisplayScoreDecompParItem {
        int type;
        String typeString;
        
        /**
         * Construct with a decomposition type.
         * 
         * @param type the decomposition type
         */
        
        private DisplayScoreDecompParItem(int type) {
            switch(type) {
                case DecomposableScore.CALIBRATION_REFINEMENT: {
                    typeString = "Calibration-Refinement (CR)";
                }; break;
                case DecomposableScore.LIKELIHOOD_BASE_RATE: {
                    typeString = "Likelihood-Base-Rate (LBR)";
                }; break;
                case DecomposableScore.CR_AND_LBR: {
                    typeString = "Both CR and LBR";
                }; break;
                case DecomposableScore.NONE:{
                    typeString = "None";
                }; break;
                default: throw new IllegalArgumentException("Unrecognized score decomposition type for display.");
            }
            this.type=type;                    
        }
        
        /**
         * Returns a string representation of the type.
         * 
         * @return a string representation.
         */

        public String toString() {
            return typeString;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final DisplayScoreDecompParItem other = (DisplayScoreDecompParItem) obj;
            if (this.type != other.type) {
                return false;
            }
            return true;
        }

        @Override
        public int hashCode() {
            int hash = 7;
            hash = 29 * hash + this.type;
            return hash;
        }
        
    }
    
    
} 
        
   
