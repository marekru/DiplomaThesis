package evs.gui.windows;

//Java swing dependencies
import evs.data.ValueCondition;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import javax.swing.event.*;

//Java awt dependencies
import java.awt.*;
import java.awt.event.*;

//Java util dependencies
import java.util.*;
        
//Java io dependencies
import java.io.*;

//EVS dependencies
import evs.analysisunits.*;
import evs.data.fileio.*;
import evs.data.*;
import evs.metric.metrics.*;
import evs.utilities.*;
import evs.gui.utilities.*;
import evs.metric.parameters.*;

/**
 * First window where Verification Unit's (VUs) are defined and managed.  A VU
 * comprises a time-series of one variable (e.g. precipitation) at a specific location
 * and is uniquely identified by these two attributes.  
 *
 * In this window, a VU can be associated with some input data, some parameters 
 * for defining the verification window (start and end time etc.) and an output 
 * directory for writing the verification statistics.    
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class VerificationA extends JPanel implements GUIInterface {
   
/*******************************************************************************
 *                                                                             *
 *                                CONSTRUCTOR                                  *
 *                                                                             *
 ******************************************************************************/
    
    /**
     * Constructs the first verification window.
     */
    
     protected VerificationA() {
        initComponents();
        //Construct start and end date dialogs and add listener for closing event
        startDateDialog = new DateSelector("Select start date",false);
        startDateDialog.addWindowListener(new WindowAdapter() {
            public void windowDeactivated(WindowEvent evt) {
                if(startDateDialog.getExitStatus()==startDateDialog.OK_EXIT) {
                    Calendar c = startDateDialog.getCalendar().getCalendar();
                    startYearField.setText(c.get(c.YEAR)+"");
                    startMonthBox.setSelectedIndex(c.get(c.MONTH)+1);
                    setStartDayBox();
                    startDayBox.setSelectedIndex(c.get(c.DAY_OF_MONTH));
                }
            }
        });
        endDateDialog = new DateSelector("Select end date",false);
        endDateDialog.addWindowListener(new WindowAdapter() {
            public void windowDeactivated(WindowEvent evt) {
                if(endDateDialog.getExitStatus()==endDateDialog.OK_EXIT) {
                    Calendar c = endDateDialog.getCalendar().getCalendar();
                    endYearField.setText(c.get(c.YEAR)+"");
                    endMonthBox.setSelectedIndex(c.get(c.MONTH)+1);
                    setEndDayBox();
                    endDayBox.setSelectedIndex(c.get(c.DAY_OF_MONTH));
                }
            }
        });
        
        //Set the disabled color of the headers in the verification properties panel
        setPanelsEnabled(false);
        //Add a selection changed method to the table
        ListSelectionListener listener = new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent evt) {                
                //Selection is still adjusting: handle change now
                if(evt.getValueIsAdjusting()) {
                    updateUnitSelection();
                }
            }
        };
        unitsTable.getSelectionModel().addListSelectionListener(listener);   
        unitsTable.getColumnModel().getSelectionModel().addListSelectionListener(listener);
        
        //Increases the table row height
        unitsTable.setRowHeight(25);
        unitsTable.getSelectionModel().setSelectionMode(unitsTable.getSelectionModel().MULTIPLE_INTERVAL_SELECTION);
        
        //Set available time systems and file types
        try {
            observedTSBox.setModel(new DefaultComboBoxModel(GlobalUnitsReader.getTimeSystems()));
            forecastTSBox.setModel(new DefaultComboBoxModel(GlobalUnitsReader.getTimeSystems()));
            //climateTSBox.setModel(new DefaultComboBoxModel(GlobalUnitsReader.getTimeSystems()));
            observedTSBox.setSelectedItem(GlobalUnitsReader.getTimeSystem("Coordinated Universal Time (UTC)"));
            forecastTSBox.setSelectedItem(GlobalUnitsReader.getTimeSystem("Coordinated Universal Time (UTC)"));
            //climateTSBox.setSelectedItem(GlobalUnitsReader.getTimeSystem("Coordinated Universal Time (UTC)"));
            //Set the available file types
            observedFileTypeBox.setModel(new javax.swing.DefaultComboBoxModel(FileIO.getObservedFileTypeStrings()));
            forecastFileTypeBox.setModel(new javax.swing.DefaultComboBoxModel(FileIO.getForecastFileTypeStrings()));
            //Set the available time units
            forecastLeadBox.setModel(new DefaultComboBoxModel(GlobalUnitsReader.getTimeUnits()));
            temporalResolutionBox.setModel(new DefaultComboBoxModel(GlobalUnitsReader.getTimeUnits()));
            forecastLeadBox.setSelectedItem("DAY");
            temporalResolutionBox.setSelectedItem("DAY");
        } catch(Exception e) {
            e.printStackTrace();
        }
        //Set the options dialogs
        moreInputDialog = new MoreInputDialog();
        outputOptions = new MoreOutputOptions("Output options dialog",true);
        setVisible(true);
    }

/********************************************************************************
 *                                                                              *
 *                           INHERITED PUBLIC METHODS                           *
 *                                                                              *
 *******************************************************************************/     
     
    /**
     * Closes any open dialogs or frames associated with the GUI window.
     */
     
    public void disposeOfChildren() {
        if(startDateDialog!=null) {
            startDateDialog.dispose();
        }
        if(endDateDialog!=null) {
            endDateDialog.dispose();
        }
        if(moreInputDialog!=null) {
            moreInputDialog.dispose();
        }
        if(outputOptions!=null) {
            outputOptions.dispose();
        }
    }
          
     /**
      * Attempts to save the specified inputs to an existing verification unit.
      * Throws an exception if any of the input parameters are undefined or take
      * incorrect values.  This is a local save for the current window.
      *
      * @return true if saved, false otherwise
      */

    public boolean saveData() throws IllegalArgumentException {
        //Update any recent changes to the selected unit
        saveLocalData();

        //Attempt to construct the individual verification units first
        //Construct temporary units until all changes are deemed valid
        LinkedHashMap<VerificationUnit,HashMap<Integer,Object>> tempUnits = new LinkedHashMap();
        VerificationUnit[] oldUnits = new VerificationUnit[localData.size()];
        VerificationUnit[] newUnits = new VerificationUnit[localData.size()];
        
        //Create a vector of existing units that will be updated as the changes progress
        //These will be used for synchronization of the changes on individual units
        //Deep copy the existing units, in case any changes are invalid
        Vector<VerificationUnit> copy = new Vector();
        Iterator it = localData.keySet().iterator();
        int tt = 0;
        while(it.hasNext()) {
            VerificationUnit o = (VerificationUnit)it.next();
            VerificationUnit c = o.deepCopy(false);  //Do not deep copy metrics
            copy.add(c);
            oldUnits[tt]=o;
            newUnits[tt]=c;
            tt++;
        }
        //Store of aggregation units on which warnings have been issued
        Vector<AggregationUnit> aggWarn = new Vector<AggregationUnit>();
        int size = localData.size();
        for(int i = 0; i < size; i++) {
            HashMap<Integer,Object> localPars = localData.get(oldUnits[i]);

            //Create a deep copy of the unit to test
            VerificationUnit toUpdate = newUnits[i];  //The new units are updated as this loop is iterated
            
            //Check that the identifiers are unique in this context
            //The test unit is the old VU at this index
            VerificationUnit old = new VerificationUnit(localPars.get(LOCATION_ID)+"",
                    localPars.get(VARIABLE_ID)+"");
            if(localPars.containsKey(ADDITIONAL_ID) && !localPars.get(ADDITIONAL_ID).equals("")) {
                old.setAdditionalID(localPars.get(ADDITIONAL_ID)+"");
            }
            
            //Check that the identifiers don't match another unit, which is not allowed
            //If the old unit identifiers are different from the new unit identifiers,
            //check they aren't already taken
            if(!(old+"").equals(toUpdate+"")) {
                if(localData.containsKey(old)) {
                    HashMap<Integer,Object> parsTest = localData.get(old);
                    //Check that the identifiers are unique in this context
                    VerificationUnit toChangeTo = new VerificationUnit(parsTest.get(LOCATION_ID) + "",
                            parsTest.get(VARIABLE_ID) + "");
                    if (parsTest.containsKey(ADDITIONAL_ID) && !parsTest.get(ADDITIONAL_ID).equals("")) {
                        toChangeTo.setAdditionalID(parsTest.get(ADDITIONAL_ID) + "");
                    }
                    //A unit with the requested name already exists and the existing unit
                    //is not about to change name
                    if((old+"").equals(toChangeTo+"")) {
                        throw new IllegalArgumentException("Each verification unit must have a unique combination of identifiers. Check: "+old);
                    }
                }
            }
            
            toUpdate.setLocationID(localPars.get(LOCATION_ID)+"");
            toUpdate.setVariableID(localPars.get(VARIABLE_ID)+"");

            if(localPars.get(ADDITIONAL_ID) != null) {
                toUpdate.setAdditionalID(localPars.get(ADDITIONAL_ID)+"");
            }
            
            //If a file array, then this was set using the dialog
            if(localPars.containsKey(FORECAST_DATA)) {
                toUpdate.setForecastData((DataSource)localPars.get(FORECAST_DATA));
            }
            else {
                toUpdate.deleteForecastData();
            }
            if(localPars.containsKey(FORECAST_TIME_SYS)) {
                toUpdate.setForecastTimeSystem((TimeZone)localPars.get(FORECAST_TIME_SYS));
            }
            else {
                toUpdate.deleteForecastTimeSystem();
            }
            if(localPars.containsKey(FORECAST_FILE_TYPE)) {
                toUpdate.setForecastFileType(FileIO.getFileTypeIDForString(localPars.get(FORECAST_FILE_TYPE)+""));
            }

            if(localPars.containsKey(OBSERVED_DATA) && !localPars.get(OBSERVED_DATA).equals("")) {
                toUpdate.setObservedData(new FileDataSource(new File(localPars.get(OBSERVED_DATA)+"")));
            }
            //Remove
            else {
                toUpdate.deleteObservedData();
            }
            if(localPars.containsKey(OBSERVED_TIME_SYS)) {
                toUpdate.setObservedTimeSystem((TimeZone)localPars.get(OBSERVED_TIME_SYS));
            }
            else {
                toUpdate.deleteObservedTimeSystem();
            }
            if(localPars.containsKey(OBSERVED_FILE_TYPE)) {
                toUpdate.setObservedFileType(FileIO.getFileTypeIDForString(localPars.get(OBSERVED_FILE_TYPE)+""));
            }

            //Set the dates, or return on cancelling operation
            if(syncDates(toUpdate,copy,
                    localPars.get(START_YEAR),
                    localPars.get(START_MONTH),
                    localPars.get(START_DAY),
                    localPars.get(END_YEAR),
                    localPars.get(END_MONTH),
                    localPars.get(END_DAY)
                    )) {
                return false;
            }
            //Set the forecast lead times
            if(localPars.containsKey(FIRST_LEAD_TIME) && 
                    (!localPars.get(FIRST_LEAD_TIME).equals("")||!localPars.get(LAST_LEAD_TIME).equals(""))) {
                try {
                    toUpdate.setLeadTimes(new Double(localPars.get(FIRST_LEAD_TIME)+""),
                            new Double(localPars.get(LAST_LEAD_TIME)+""),localPars.get(LEAD_UNITS)+"");
                } catch(NumberFormatException e) {
                    throw new IllegalArgumentException("Incorrect format for the first and last forecast lead times associated with verification unit '"+toUpdate+"': "
                            + "both must be empty or comprise valid numbers.");
                }
            }
            else {
                toUpdate.deleteForecastLeadTimes();
            }
            
            //Set the verification resolution, or return on cancelling operation
            if(syncVerificationRes(toUpdate,copy,localPars.get(AGG_RES),localPars.get(AGG_RES_UNITS))) {
                return false;
            }
            //Output folder
            if(localPars.containsKey(OUTPUT_DATA) && ! localPars.get(OUTPUT_DATA).equals("")) {
                toUpdate.setOutputData(new FileDataSource(new File(localPars.get(OUTPUT_DATA)+"")));
            }
            else {
                toUpdate.deleteOutputData();
            }
            //Add to the temporary units array
            tempUnits.put(toUpdate,localPars);
            int index = copy.indexOf(toUpdate);  //Use old unit, in case of name change
            copy.set(index,toUpdate);
        }
        //Check that no aggregation units have been impacted by changes to verification units
        Iterator j = localData.keySet().iterator();
        Iterator k = tempUnits.keySet().iterator();
        while(j.hasNext()) {
            VerificationUnit next = (VerificationUnit)j.next();
            ArrayList<AggregationUnit> agg = next.getAggregationUnits();
            VerificationUnit compare = (VerificationUnit)k.next();
            if (next.hasUsableAggregationUnit() && !next.aggregationEquals(compare, false)) {
                //JB @ 11th March 2013
                for(AggregationUnit a : agg) {
                    if (!aggWarn.contains(a)) {
                        //Warn user of a change that will affect the aggregation unit
                        int n = JOptionPane.showOptionDialog(EVSMainWindow.main, "These changes will invalidate an existing aggregation unit.  Proceed and delete the aggregation unit?", "Warning: data changes elsewhere", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, null, null, null);
                        if (n == JOptionPane.YES_OPTION) {
                            next.deleteAndUpdateAggregationUnit(a);
                            AGGREGATION_A.clearLocalData(a);  //Update elsewhere
                            aggWarn.add(a);  //Update warning list to avoid repetition
                        } else {
                            return false; //No changes made
                        }
                    } //Agg unit already updated from previous call: proceed silently
                    else {
                        next.deleteAndUpdateAggregationUnit(a);
                        AGGREGATION_A.clearLocalData(a);  //Update elsewhere
                    }
                }
            }
//JB @ 5th December 2012. See below            
//            if (next.hasAggregationUnit()) {
//                compare.setAggregationUnit(next.getAggregationUnit());
//            }
                        
        }
        
        //JB @ 5th December 2012. Previously this compare.setAggregationUnit
        //took place in the loop above, but it must take place after the updating/
        //deleting has taken place for all units because a change to a later unit
        //in the loop could also result in deletion of the unit earlier in the loop
        //yet that unit already passed the check next.aggregationEquals(compare,false) = TRUE
        //and did not have the unit deleted (hence the position of this 
        //compare.setAggregationUnit(next.getAggregationUnit()) before led to the aggregation unit
        //being set for the temporary unit ("compare") which subsequently becomes the final unit.
        Iterator p = localData.keySet().iterator();
        Iterator q = tempUnits.keySet().iterator();
        while(p.hasNext()) {
            VerificationUnit next = (VerificationUnit)p.next();   
            VerificationUnit compare = (VerificationUnit)q.next();
            //Set any remaining aggregation units (not deleted above for the 
            //local data), which are not copied across when deep copying the 
            //verification units above
            //JB @ 11th March 2013
            if (next.hasAggregationUnit()) {
                ArrayList<AggregationUnit> agg = next.getAggregationUnits();
                for(AggregationUnit a : agg) {
                    compare.addAggregationUnit(a);
                }
            }
        }
        
        //Create a mapping of old unit names to new unit names
        HashMap<String,String> mapping = new HashMap<String,String>();
        int tot = newUnits.length;
        for(int n = 0; n < tot; n++) {
            mapping.put(oldUnits[n].toString(),newUnits[n].toString());
        }
        
        //Replace units with the new temporary units if all conditions met
        localData = tempUnits;    
        
        //Update the reference forecasts for any saved metrics and update the 
        //table with the new (deep copied) units
        int tot2 = 0;
        Iterator m = localData.keySet().iterator();
        while(m.hasNext()) {
            VerificationUnit unit = (VerificationUnit)m.next();
            unit.updateReferenceForecasts(mapping);
            unitsTable.setValueAt(unit,tot2,0);
            tot2++;
        }
        
        //Synchronize any name changes that impact variable value conditions
        //and any reference forecasts for metrics that are already set and saved
        for(int n = 0; n < tot; n++) {
            syncVarValConditions(oldUnits[n],newUnits[n]);
        }
        
        //Synchronize the reference forecast identifiers for skill metrics in the
        //local data store in VERIFICATION_B
        VERIFICATION_B.synchronizeVUNames(oldUnits,newUnits);
        AGGREGATION_A.synchronizeVUNames(oldUnits,newUnits);
        return true;
    }
        
     /**
      * Saves the local data to an object array, stored with the unique identifier
      * of the selected verification unit. 
      */
     
     public void saveLocalData() {        
         //Save
         if(saveIndex > -1 && saveIndex < unitsTable.getRowCount() && 
                 unitsTable.getValueAt(saveIndex,0)!=null) {
             VerificationUnit unit = (VerificationUnit)unitsTable.getValueAt(saveIndex,0);
             HashMap<Integer,Object> data = new HashMap<Integer,Object>();
             data.put(LOCATION_ID,locationIDField.getText());
             data.put(VARIABLE_ID,variableIDField.getText());
             data.put(ADDITIONAL_ID,additionalIDField.getText());

             //Update the forecast files parameter 
             HashMap<Integer,Object> pars = localData.get(unit);
             //Data source already available
             if(pars != null && pars.get(FORECAST_DATA) instanceof DataSource) {
                 //Update single file in case direct changes made in window
                 if(pars.get(FORECAST_DATA) instanceof FileDataSource) {
                     data.put(FORECAST_DATA,new FileDataSource(new File(forecastFileField.getText())));
                 } 
                 //File array previously defined, but since been updated manually in window
                 else if(pars.get(FORECAST_DATA) instanceof FileArrayDataSource
                         && !forecastFileField.getText().startsWith("[FILE ARRAY]")) {
                     data.put(FORECAST_DATA,new FileDataSource(new File(forecastFileField.getText())));
                 }
                 else {
                     data.put(FORECAST_DATA,pars.get(FORECAST_DATA));
                 }
             }
             //No data source yet defined
//             else {
//                 //Try to save the data source
//                 try {
//                    data.put(FORECAST_DATA,new FileDataSource(new File(forecastFileField.getText())));
//                 }
//                 catch(Exception e) {
//                     data.remove(FORECAST_DATA);
//                 }
//             }
             data.put(OBSERVED_DATA,observedFileField.getText());
             //data[5] = climatologyFileField.getText();
             data.put(FORECAST_TIME_SYS,forecastTSBox.getSelectedItem());
             data.put(OBSERVED_TIME_SYS,observedTSBox.getSelectedItem());
             data.put(FORECAST_FILE_TYPE,forecastFileTypeBox.getSelectedItem());
             data.put(OBSERVED_FILE_TYPE,observedFileTypeBox.getSelectedItem());

             //data[8] = climateTSBox.getSelectedItem();
             data.put(START_YEAR,startYearField.getText());
             String sM = startMonthBox.getSelectedItem()+"";
             String eM = endMonthBox.getSelectedItem()+"";
             if(!sM.equals("MM")) {
                sM = (Integer.parseInt(sM)-1)+"";
             }
             if(!eM.equals("MM")) {
                eM = (Integer.parseInt(eM)-1)+"";
             }
             data.put(START_MONTH,sM);
             data.put(START_DAY,startDayBox.getSelectedItem());
             data.put(FIRST_LEAD_TIME,firstLeadField.getText());
             data.put(LAST_LEAD_TIME,lastLeadField.getText());
             data.put(LEAD_UNITS,forecastLeadBox.getSelectedItem());
             data.put(END_YEAR,endYearField.getText());
             data.put(END_MONTH,eM);
             data.put(END_DAY,endDayBox.getSelectedItem());
             data.put(AGG_RES,temporalResolutionField.getText());
             data.put(AGG_RES_UNITS,temporalResolutionBox.getSelectedItem());
             data.put(OUTPUT_DATA,outputFolderField.getText());
             localData.put(unit,data);
         }
     }
     
    /**
     * Displays the local data previously saved to a temporary store.  Local data 
     * should always be displayed in preference to saved data, because saved data 
     * should be used to update the store of local data once available.
     */
    
     public void showLocalData() {
         clearDisplay();
//         //Select a unit if available, updating the local data if not already available
//         if(!unitIsSelected() && unitsTable.getRowCount()>0 && unitsTable.getValueAt(0,0)!=null) {
//             unitsTable.setRowSelectionInterval(0,0);
//         }
         //Check that a unit is selected and that local data are available
         if(unitIsSelected() && localData.containsKey(getSelectedUnit())) {
             setPanelsEnabled(true);
             VerificationUnit unit = getSelectedUnit();
             HashMap<Integer,Object> data = localData.get(unit);
             if(data.containsKey(LOCATION_ID)) {
                 locationIDField.setText(data.get(LOCATION_ID)+"");
             }
             if(data.containsKey(VARIABLE_ID)) {
                 variableIDField.setText(data.get(VARIABLE_ID)+"");
             }
             if(data.containsKey(ADDITIONAL_ID)) {
                 additionalIDField.setText(data.get(ADDITIONAL_ID)+"");
             }
             if(data.containsKey(FORECAST_DATA)) {
                 forecastFileField.setText(data.get(FORECAST_DATA)+"");
             }
             if(data.containsKey(OBSERVED_DATA)) {
                 observedFileField.setText(data.get(OBSERVED_DATA)+"");
             }
             //if(data[5]!=null) {
             //    climatologyFileField.setText(data[5]+"");
             //}
             if(data.containsKey(FORECAST_TIME_SYS)) {
                 forecastTSBox.setSelectedItem(data.get(FORECAST_TIME_SYS));
             }
             if(data.containsKey(OBSERVED_TIME_SYS)) {
                 observedTSBox.setSelectedItem(data.get(OBSERVED_TIME_SYS));
             }
             if(data.containsKey(FORECAST_FILE_TYPE)) {
                 forecastFileTypeBox.setSelectedItem(data.get(FORECAST_FILE_TYPE));
             }
             if(data.containsKey(OBSERVED_FILE_TYPE)) {
                 observedFileTypeBox.setSelectedItem(data.get(OBSERVED_FILE_TYPE));
             }
             //if(data[8]!=null) {
             //    climateTSBox.setSelectedItem(data[8]);
             //}
             if(data.containsKey(START_YEAR)) {
                 startYearField.setText(data.get(START_YEAR)+"");
             }
             if(data.containsKey(START_MONTH)) {
                 if(data.get(START_MONTH).equals("MM")) {
                     startMonthBox.setSelectedItem(data.get(START_MONTH));
                 } else {
                     int index = Integer.parseInt(data.get(START_MONTH)+"");
                     startMonthBox.setSelectedIndex(index+1);
                 }
                 setStartDayBox();
             }
             if(data.containsKey(START_DAY)) {
                 startDayBox.setSelectedItem(data.get(START_DAY));
             }
             if(data.containsKey(FIRST_LEAD_TIME)) {
                 firstLeadField.setText(data.get(FIRST_LEAD_TIME)+"");
             }
             if(data.containsKey(LAST_LEAD_TIME)) {
                 lastLeadField.setText(data.get(LAST_LEAD_TIME)+"");
             }
             if(data.containsKey(LEAD_UNITS)) {
                 forecastLeadBox.setSelectedItem(data.get(LEAD_UNITS));
             }
             if(data.containsKey(END_YEAR)) {
                 endYearField.setText(data.get(END_YEAR)+"");
             }
             if(data.containsKey(END_MONTH)) {
                 if(data.get(END_MONTH).equals("MM")) {
                     endMonthBox.setSelectedItem(data.get(END_MONTH));
                 }
                 else {
                     int index = Integer.parseInt(data.get(END_MONTH)+"");
                     endMonthBox.setSelectedIndex(index+1);
                 }
                 setEndDayBox();
             }
             if(data.containsKey(END_DAY)) {
                 endDayBox.setSelectedItem(data.get(END_DAY));
             }
             if(data.containsKey(AGG_RES)) {
                 temporalResolutionField.setText(data.get(AGG_RES)+"");
             }
             if(data.containsKey(AGG_RES_UNITS)) {
                 temporalResolutionBox.setSelectedItem(data.get(AGG_RES_UNITS));
             }   
             if(data.containsKey(OUTPUT_DATA)) {
                 outputFolderField.setText(data.get(OUTPUT_DATA)+"");
             }
         }
         else {
             setPanelsEnabled(false);
         }    
     }
     
    /**
     * Updates local data with a saved AnalysisUnit, adding a unit or replacing an 
     * existing unit.
     *
     * @param unit the unit
     */
    
    public void updateLocalData(AnalysisUnit unit) {
        if(unit instanceof VerificationUnit) {
        //JB @17th May 2013    
            //Update the save index on first loading data
//            if(unitsTable.getRowCount()==0) {
//                saveIndex = 0;
//            }
            VerificationUnit vu = (VerificationUnit)unit;
            HashMap<Integer,Object> data = new HashMap<Integer,Object>();
            data.put(LOCATION_ID,vu.getLocationID());
            data.put(VARIABLE_ID,vu.getVariableID());
            if(vu.hasAdditionalID()) {
                data.put(ADDITIONAL_ID,vu.getAdditionalID());
            }
            if(vu.hasForecastData()) {
                data.put(FORECAST_DATA,vu.getForecastData());
            }
            if(vu.getObservedData() instanceof FileDataSource) {
                data.put(OBSERVED_DATA,vu.getObservedData());
            }
//            if(vu.getClimatologyData() instanceof FileDataSource) {
//                data[5] = vu.getClimatologyData();
//            }
            if(vu.hasForecastTimeSystem()) {
                data.put(FORECAST_TIME_SYS,vu.getForecastTimeSystem());
            }
            data.put(FORECAST_FILE_TYPE,FileIO.getFileTypeStringForID(vu.getForecastFileType()));

            if(vu.hasObservedTimeSystem()) {
                data.put(OBSERVED_TIME_SYS,vu.getObservedTimeSystem());
            }
            data.put(OBSERVED_FILE_TYPE,FileIO.getFileTypeStringForID(vu.getObservedFileType()));
//            if(vu.hasClimatologyTimeSystem()) {
//                data[8] = vu.getClimatologyTimeSystem();
//            }
            Calendar c = vu.getStartDate();
            if(c != null) {
                data.put(START_YEAR,c.get(c.YEAR)+"");
                data.put(START_MONTH,c.get(c.MONTH)+"");  
                data.put(START_DAY,c.get(c.DAY_OF_MONTH)+"");
            }
            if(vu.hasLeadTimes()) {
                data.put(FIRST_LEAD_TIME,vu.getFirstLeadTime());
                data.put(LAST_LEAD_TIME,vu.getLastLeadTime());
                data.put(LEAD_UNITS,vu.getForecastLeadTimeUnits());
            }
            Calendar d = vu.getEndDate();
            if(d != null) {
                data.put(END_YEAR,d.get(d.YEAR)+"");
                data.put(END_MONTH,d.get(d.MONTH)+"");
                data.put(END_DAY,d.get(d.DAY_OF_MONTH)+"");
            }
            if(vu.hasResolution()) {
                data.put(AGG_RES,vu.getResolution());
                data.put(AGG_RES_UNITS,vu.getResolutionUnits());
            }
            if(vu.getOutputData() instanceof FileDataSource) {
                data.put(OUTPUT_DATA,vu.getOutputData());
            }
            //Add to the table if required
            if(!localData.containsKey((VerificationUnit)unit)) {
                ((DefaultTableModel)unitsTable.getModel()).addRow(new Object[]{unit});
            }
            localData.put((VerificationUnit)unit,data);
        }
    }   
    
    /**
     * Removes local data from the temporary store for a specified AnalysisUnit. 
     *
     * @param unit the unit
     */
    
    public void clearLocalData(AnalysisUnit unit) {
        if(unit != null) {
            localData.remove(unit);
            int rows = unitsTable.getRowCount();
            DefaultTableModel mod = (DefaultTableModel)unitsTable.getModel();
            //Remove in reverse
            for(int  i = (rows-1); i > -1; i--) {
                if(unit.toString().equals(unitsTable.getValueAt(i,0)+"")) {
                    mod.removeRow(i);
                    if(saveIndex==i) {
                        saveIndex = -1;
                    }
                }
            }
        }
    }    
    
    /**
     * Clears the verification window of all objects, updating (clearing) all dependent 
     * windows.  Does not modify any underlying project.
     */
    
    public void clearAllLocalData() {
        ((DefaultTableModel)unitsTable.getModel()).setRowCount(0);
        setPanelsEnabled(false);
        localData.clear();
        saveIndex = -1;
    }
    
/********************************************************************************
 *                                                                              *
 *                             PROTECTED METHODS                                *
 *                                                                              *
 *******************************************************************************/

    /**
     * Returns true if a unit is selected, false otherwise.
     *
     * @return true if a unit is selected, false otherwise.
     */ 
    
    protected boolean unitIsSelected() {
        return unitsTable.getSelectedRow() >-1 && localData.size() > 0; 
    }
    
    /**
     * Displays a file chooser and returns the files chosen or null.
     *
     * @param filter a file filter (can be null)
     * @param selectMe an array of files to select (can be null)
     * @param type is the display type (e.g. JFileChooser.FILES_ONLY)
     * @param multiSelection is true to allow multiple file selection
     * @return the files or null
     */
    
    protected File[] getTargetFiles(InputFileFilter filter, File[] selectMe, int type, boolean multiSelection) {
        File[] files = null;
        try {
            EVSFileChooser chooser = new EVSFileChooser();
            if(filter != null) {
                chooser.setFileFilter(filter);
            }
            chooser.setPreferredSize(new Dimension(500,330));
            chooser.setFileSelectionMode(type);
            chooser.setMultiSelectionEnabled(multiSelection);
            if(selectMe != null) {
                try {
                    chooser.setSelectedFiles(selectMe);
                }
                catch(Exception e) {
                    System.out.println("Could not locate one or more files required to display in file dialog.");
                }
            }
            int status = chooser.showOpenDialog(EVSMainWindow.main);
            if(status == EVSFileChooser.APPROVE_OPTION) {
                if(multiSelection) {
                    files = chooser.getSelectedFiles();
                }
                else {
                    files = new File[]{chooser.getSelectedFile()};
                }
            }
        } catch(Exception e) {
            CONSOLE.addMessage(StringUtilities.stackTraceToString(e));
            ExceptionHandler.displayException(e);
        }
        return files;
    }    

    /**
     * Returns all the current verification units.
     *
     * @return the verification units
     */
    
    protected Vector<VerificationUnit> getVerificationUnits() {
        return new Vector(localData.keySet());
    }
    
    /**
     * Returns true if one or more verification units are defined, false otherwise.
     * 
     * @return true if one or more units are defined, false otherwise
     */
    
     protected boolean hasVerificationUnits() {
        return getVerificationUnits().size()>0;
    }   
    
    /**
     * Returns the selected verification unit or null.
     *
     * @return the selected verification unit
     */
    
    protected VerificationUnit getSelectedUnit() {
        //Return the unit from the local data source rather than the table
        VerificationUnit selected = null;
        int row = unitsTable.getSelectionModel().getAnchorSelectionIndex();
        if(row>-1 && localData.size() > 0) {
            Vector<VerificationUnit> units = getVerificationUnits();
            selected = units.get(row);        
        }
        return selected;
    }
    
    /**
     * Returns all selected verification units or an empty vector.
     *
     * @return the selected verification units
     */
    
    protected Vector<VerificationUnit> getSelectedVerificationUnits() {
        //Return the unit from the local data source rather than the table
        Vector<VerificationUnit> selected = new Vector();
        int[] rows = unitsTable.getSelectedRows();
        if(rows.length >0 && localData.size() > 0) {
            Vector<VerificationUnit> units = getVerificationUnits();
            int tot = rows.length;
            for(int i = 0; i < tot; i++) {
                selected.add(units.get(rows[i]));
            }
        }
        return selected;
    }    
    
    /**
     * Returns the verification start date if set.
     *
     * @return the start date or null if not defined
     */
    
    protected Calendar getStartDate() throws IllegalArgumentException {
        Calendar start = null;
        try {
            int month = Integer.parseInt(startMonthBox.getSelectedItem()+"")-1;
            start = getDate(startYearField.getText(),month+"",startDayBox.getSelectedItem()+"");
        } catch(NumberFormatException e) {
            throw new IllegalArgumentException("Incorrect format for date inputs.");
        }
        return start;
    }
    
    /**
     * Returns the verification end date if set.
     *
     * @return the end date or null if not defined
     */
    
    protected Calendar getEndDate() throws IllegalArgumentException {
        Calendar end = null;
        try {
            int month = Integer.parseInt(endMonthBox.getSelectedItem()+"")-1;
            end = getDate(endYearField.getText(),month+"",endDayBox.getSelectedItem()+"");
        } catch(NumberFormatException e) {
            throw new IllegalArgumentException("Incorrect format for date inputs.");
        }
        return end;
    }    
     
    /**
     * Synchronizes any variable value conditions following a change in the input
     * unit, such as adding pairs or changing parameter values.
     *
     * @param oldUnit the old unit
     * @param newUnit the new unit
     */
    
    protected void syncVarValConditions(VerificationUnit oldUnit, VerificationUnit newUnit) {
        Vector<VerificationUnit> units = getVerificationUnits();
        int length = units.size();        
        for(int i = 0; i < length; i++) {
            VerificationUnit next = units.get(i);
            if(next.hasValueConditions(oldUnit.toString())) {
                Vector<ValueCondition> v = next.getValueConditions(oldUnit.toString());
                int tot = v.size();
                for(int j = 0; j < tot; j++) {
                    next.setValueCondition((ValueCondition)v.get(j).deepCopy(newUnit));  //Attempts deep copy with new input
                    if(!oldUnit.toString().equals(newUnit.toString())) {
                        next.deleteValueConditions(oldUnit.toString());
                    }
                }
            }
        }
    }
    
    /**
     * Sets the default unit selection if one is available.
     */
    
    protected void setDefaultSelection() {
         //Select a unit if available, updating the local data if not already available
         if(!unitIsSelected() && unitsTable.getRowCount()>0 && unitsTable.getValueAt(0,0)!=null) {
             unitsTable.setRowSelectionInterval(0,0);
             updateUnitSelection();
         }
    }
    
    
/********************************************************************************
 *                                                                              *
 *                               PRIVATE METHODS                                *
 *                                                                              *
 *******************************************************************************/
    
    /**
     * Enables or disables the panels identifying the properties of the selected
     * verification unit.  Disable the panels when no units are selected, otherwise
     * enable all panels.
     *
     * @param enabled is true to enable panels, false to disable panels
     */
    
    private void setPanelsEnabled(Boolean enabled) {
        copyButton.setEnabled(enabled);
        deleteButton.setEnabled(enabled);
        forecastFileButton.setEnabled(enabled);
        forecastFileField.setEnabled(enabled);
        moreButton.setEnabled(enabled);
        moreButton1.setEnabled(enabled);
        moreButton2.setEnabled(enabled);
        observedTSBox.setEnabled(enabled);
        forecastTSBox.setEnabled(enabled);
        observedTSLabel.setEnabled(enabled);
        forecastTSLabel.setEnabled(enabled);
        forecastFileTypeLabel.setEnabled(enabled);
        forecastFileTypeBox.setEnabled(enabled);
        observedFileTypeLabel.setEnabled(enabled);
        observedFileTypeBox.setEnabled(enabled);
        //climateTSBox.setEnabled(enabled);
        //climateTSLabel.setEnabled(enabled);
        temporalResolutionField.setEnabled(enabled);
        temporalResolutionBox.setEnabled(enabled);
        forecastLeadBox.setEnabled(enabled);
        firstLeadField.setEnabled(enabled);
        lastLeadField.setEnabled(enabled);
        forecastFileLabel.setEnabled(enabled);
        verificationTimestepLabel.setEnabled(enabled);
        firstLeadLabel.setEnabled(enabled);
        lastLeadLabel.setEnabled(enabled);
        observedFileLabel.setEnabled(enabled);
        //climatologyFileLabel.setEnabled(enabled);
        outputFolderLabel.setEnabled(enabled);
        locationIDLabel.setEnabled(enabled);
        observedFileField.setEnabled(enabled);
        //climatologyFileField.setEnabled(enabled);
        outputFolderField.setEnabled(enabled);
        locationIDField.setEnabled(enabled);
        nextButton.setEnabled(enabled);
        outputFolderButton.setEnabled(enabled);
        observedFileButton.setEnabled(enabled);
        //climatologyFileButton.setEnabled(enabled);
        startDateButton.setEnabled(enabled);
        endDateButton.setEnabled(enabled);
        variableIDLabel.setEnabled(enabled);
        variableIDField.setEnabled(enabled);
        additionalIDLabel.setEnabled(enabled);
        additionalIDField.setEnabled(enabled);
        startDateLabel.setEnabled(enabled);
        endDateLabel.setEnabled(enabled);
        startYearField.setEnabled(enabled);
        endYearField.setEnabled(enabled);
        startMonthBox.setEnabled(enabled);
        endMonthBox.setEnabled(enabled);
        startDayBox.setEnabled(enabled);
        endDayBox.setEnabled(enabled);
        clearDisplay();
        Color c = Color.BLACK;
        if(!enabled) {
            c = new Color(157,154,118);
        }
        ((TitledBorder)rightPanel.getBorder()).setTitleColor(c);
        ((TitledBorder)identifiersPanel.getBorder()).setTitleColor(c);
        ((TitledBorder)sourceDataPanel.getBorder()).setTitleColor(c);
        ((TitledBorder)timePanel.getBorder()).setTitleColor(c);
        ((TitledBorder)outputPanel.getBorder()).setTitleColor(c);
        repaint();
    }
    
    /**
     * Clears the display, but does not remove any local data.
     */
    
    private void clearDisplay() {
        //Reset the inputs
        forecastFileField.setText("");
        temporalResolutionField.setText("");
        firstLeadField.setText("");
        lastLeadField.setText("");
        observedFileField.setText("");
        //climatologyFileField.setText("");
        outputFolderField.setText("");
        locationIDField.setText("");
        variableIDField.setText("");
        additionalIDField.setText("");
        startYearField.setText("YYYY");
        endYearField.setText("YYYY");
        startDayBox.setSelectedIndex(0);
        startMonthBox.setSelectedIndex(0);
        endDayBox.setSelectedIndex(0);
        endMonthBox.setSelectedIndex(0);   
        //Set the defaults for time zones and data types
        forecastFileTypeBox.setSelectedItem(
        		FileIO.getFileTypeStringForID(EVSConstants.DEFAULT_INPUT_TYPE));
        observedFileTypeBox.setSelectedItem(
        		FileIO.getFileTypeStringForID(EVSConstants.DEFAULT_INPUT_TYPE));
        forecastTSBox.setSelectedItem(EVSConstants.DEFAULT_ZONE);
        observedTSBox.setSelectedItem(EVSConstants.DEFAULT_ZONE);
    }
    
    /**
     * Attempts to set the start day selection box according to the year and 
     * month specified.
     */
    
    private void setStartDayBox() {
        try {
            String year = startYearField.getText();
            Calendar cal = new GregorianCalendar(new Integer(year),startMonthBox.getSelectedIndex()-1,1);
            int days = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
            DefaultComboBoxModel mod = new DefaultComboBoxModel();
            mod.addElement("DD");
            for(int i = 0; i < days; i++) {
                mod.addElement((i+1)+"");
            }
            startDayBox.setModel(mod);
        }
        catch(Exception e) {
            //Do nothing
        }
    }
    
     /**
     * Attempts to set the start day selection box according to the year and 
     * month specified.
     */
    
    private void setEndDayBox() {
        try {
            String year = endYearField.getText();
            Calendar cal = new GregorianCalendar(new Integer(year),endMonthBox.getSelectedIndex()-1,1);
            int days = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
            DefaultComboBoxModel mod = new DefaultComboBoxModel();
            mod.addElement("DD");
            for(int i = 0; i < days; i++) {
                mod.addElement((i+1)+"");
            }
            endDayBox.setModel(mod);
        }
        catch(Exception e) {
            //Do nothing
        }
    }    
    
    /**
     * Synchronizes any recent changes in the verification window with the 
     * advanced options for setting date and variable value conditions.  Prompts
     * are given if changes are required to ensure synchronization. 
     *
     * @return true if the data were synchronized, false otherwise (e.g. on canceling)
     */
    
    private boolean syncAdvancedData() {
        //Update any recent changes to the selected unit
        saveLocalData();
        Iterator i = localData.keySet().iterator();
        int tot = 0;
        Vector<VerificationUnit> v = new Vector(localData.keySet());
        while(i.hasNext()) {
            VerificationUnit ver = (VerificationUnit)i.next();  
            HashMap<Integer,Object> pars = localData.get(ver);
            //No changes 
            if(syncDates(ver,v,
                    pars.get(START_YEAR),
                    pars.get(START_MONTH),
                    pars.get(START_DAY),
                    pars.get(END_YEAR),
                    pars.get(END_MONTH),
                    pars.get(END_DAY)
                    )) {
                return false;
            }
            if(syncVerificationRes(ver,v,pars.get(AGG_RES),pars.get(AGG_RES_UNITS))) {
                return false;
            }
            tot++;
        }
        return true;
    }
    
    /**
     * Sets the dates for the specified unit using the specified date elements in
     * string format.  Prompts are given in case the changes will compromise conditions 
     * on this unit or other units (such as value conditions).
     *
     * @param unit the verification unit
     * @param units the units to synchronize in the event of changes in other units
     * @param startYear the start year
     * @param startMonth the start month
     * @param startDay the start day 
     * @param endYear the end year
     * @param endMonth the end month
     * @param endDay the end day
     * @return true if the operation was canceled
     */
    
    private boolean syncDates(VerificationUnit unit, Vector<VerificationUnit> units, Object startYear, Object  startMonth, Object startDay, Object endYear, Object endMonth, Object endDay) {

        //Set the start and end dates for the verification
        Calendar start = null;
        Calendar end = null;
        try {
            if(startYear != null && startMonth != null && startDay != null && !startYear.equals("YYYY") && !startMonth.equals("MM") && !startDay.equals("DD")) {
                start = getDate(startYear+"",startMonth+"",startDay+"");
            }
            if(endYear != null && endMonth != null && endDay != null && !endYear.equals("YYYY") && !endMonth.equals("MM") && !endDay.equals("DD")) {
                end = getDate(endYear+"",endMonth+"",endDay+"");
            }
        } 
        catch(NumberFormatException e) {
            throw new IllegalArgumentException("Incorrect format for one or more date elements associated with unit '"+unit.toString()+"'.");
        }
        
        boolean willChangeDates = false;
        if(start != null) {
            willChangeDates = !start.equals(unit.getStartDate());
        }
        if(!willChangeDates && end != null) {
            willChangeDates = !end.equals(unit.getEndDate());
        }
        if(!willChangeDates && start == null) {
            willChangeDates = unit.hasStartDate();
        }
        if(!willChangeDates && end == null) {
            willChangeDates = unit.hasEndDate();
        }
        
        //Warn in case other changes will be compromised
        if(willChangeDates) {
            //Current unit has date condition
            if(unit.hasDateCondition()) {
                int n = JOptionPane.showOptionDialog(EVSMainWindow.main,"The dates for unit '"+unit+"' have changed, but conditions based on the old dates remain.  Proceed and delete these conditions?","Warning: data changes elsewhere", JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
                if(n == JOptionPane.YES_OPTION) {
                    unit.deleteDateCondition();
                    unit.deleteAllValueConditions();
                } else {
                    return true; //No changes made
                }
            }
            //Delete value condition for the current unit
            if(unit.hasValueConditions()) {
                int n = JOptionPane.showOptionDialog(EVSMainWindow.main,"Unit '"+unit+"' has one or more value conditions that will be compromised by the date change.  Proceed and delete these conditions?","Warning: data changes elsewhere", JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
                if(n == JOptionPane.YES_OPTION) {
                    unit.deleteAllValueConditions();
                } else {
                    return true; //No changes made
                } 
            }
            
            //Check to ensure that value conditions of other units will not be compromised
            int length = units.size();
            for(int j = 0; j < length; j++) {
                if(!units.get(j).toString().equals(unit.toString()) && units.get(j).hasValueConditions(unit.toString())) {
                    int n = JOptionPane.showOptionDialog(EVSMainWindow.main,"The dates for unit '"+unit+"' have changed, but other units have conditions that depend on this unit.  Proceed and delete these conditions?","Warning: data changes elsewhere", JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
                    if(n == JOptionPane.YES_OPTION) {
                        units.get(j).deleteValueConditions(unit.toString());
                        System.out.println("Deleted value condition based on '"+unit.toString()+"' from unit '"+units.get(j)+"'.");
                    }
                    else {
                        return true;
                    }
                }
            }
        }
        unit.setStartDate(start);
        unit.setEndDate(end);
        return false;
    }
    
    /**
     * Sets the verification resolution for the specified unit using the specified 
     * resolution and period in String format.
     *
     * @param unit the verification unit
     * @param units the units to synchronize
     * @param res the resolution
     * @param resUnits the resolution units
     * @return true if the operation was canceled
     */
    
    private boolean syncVerificationRes(VerificationUnit unit, Vector<VerificationUnit> units,Object res, Object resUnits) {
        //Verification resolution
        try {
            int newRes = -999;
            String newUnits = "";
            if(res != null && !res.equals("") && resUnits != null && !resUnits.equals("")) {
                newRes = new Integer(res+"");
                newUnits = resUnits+"";
            }
            //Establish if an existing condition will be removed or altered
            boolean willRemoveCondition = newRes==-999 && unit.hasResolution();
            boolean willChangeCondition = false;
            if(unit.hasResolution() && newRes != -999) {
                willChangeCondition = unit.getResolution() != newRes || !unit.getResolutionUnits().equals(newUnits);
            }
            else {
                willChangeCondition = newRes != -999;
            }
            
            //Delete value condition for the current unit
            if(unit.hasValueConditions() && (willRemoveCondition || willChangeCondition)) {
                int n = JOptionPane.showOptionDialog(EVSMainWindow.main,"The resolution for unit '"+unit+"' has changed, but conditions based on the old resolution remain.  Proceed and delete these conditions?","Warning: data changes elsewhere", JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
                if(n == JOptionPane.YES_OPTION) {
                    unit.deleteAllValueConditions();
                } else {
                    return true; //No changes made
                } 
            }            
            
            //Check to ensure that value conditions of other units will not be compromised by the change
            //Must remove conditions elsewhere (i.e. do not ask).
            int length = units.size();
            for(int j = 0; j < length; j++) {
                if(units.get(j).hasValueConditions(unit.toString()) && (willRemoveCondition || willChangeCondition)) {
                    units.get(j).deleteValueConditions(unit.toString());
                }
            }
            //Existing value will change (including no value)
            if(willChangeCondition) {
                unit.setResolution(newRes,newUnits);
            }
            //Existing value will be removed
            else if(willRemoveCondition) {
                unit.deleteResolution();
            }
        } catch(NumberFormatException e) {
            throw new IllegalArgumentException("Specify an integer aggregation period for verification unit '"+unit+"'.");
        }
        return false;
    }
    
    /**
     * Returns a date from a string year, month and day, or throws an exception.
     * The time system is UTC.
     *
     * @param year the year
     * @param month the month
     * @param day the day
     * @return a date
     */
    
    private Calendar getDate(String year, String month, String day) throws IllegalArgumentException {
        Calendar c = Calendar.getInstance();
        c.setTimeZone(TimeZone.getTimeZone("UTC"));
        c.clear();
        int[] months = new int[]{c.JANUARY,c.FEBRUARY,c.MARCH,c.APRIL,c.MAY,
        c.JUNE,c.JULY,c.AUGUST,c.SEPTEMBER,c.OCTOBER,c.NOVEMBER,c.DECEMBER};
        try {
            int mon = new Integer(month+"");
            //Start date
            c.set(c.YEAR,new Integer(year+""));
            c.set(c.MONTH,months[mon]); 
            c.set(c.DAY_OF_MONTH,new Integer(day+""));
            return c;
        } catch(NumberFormatException e) {
            throw new IllegalArgumentException("Incorrect format for one or more date elements'.");
        }       
    }
    
    /**
     * Updates a unit selection in the unit table using the following protocol: 
     * 
     * 1. If a single row is selected, proceed (also triggered at start of multi-row selection)
     * 2. Save data for most recent (previous) selection
     * 3. Update the save index for next call
     * 4. Show the data for the anchor index of the current selection
     */
    
    private void updateUnitSelection() {
        //JB @ 17th May 2013: fixed bug whereby list selection fired across every
        //cell during multi-row selection, so need to check when only one row is 
        //selected
        int row = unitsTable.getSelectionModel().getAnchorSelectionIndex();
        int[] rows = unitsTable.getSelectedRows();
        //Single row selected
        if (rows != null && rows.length == 1) {
            saveLocalData();
            //Finally, set the index for saving data, which will then correspond to the last 
            //selected index
            saveIndex = row;
            //Row contains unit (extra-safe)
            if (unitIsSelected()) {
                VerificationUnit selected = getSelectedUnit();
                VERIFICATION_A.showLocalData();
                VERIFICATION_B.updateLocalData(selected);
                VERIFICATION_B.showLocalData();
                AGGREGATION_A.updateLocalData(selected);
                AGGREGATION_A.showLocalData();
                OUTPUT_A.updateLocalData(selected);
                OUTPUT_A.showLocalData();
            }
        }
        if(!unitIsSelected()) {
            VERIFICATION_A.showLocalData();
            VERIFICATION_B.clearAllLocalData();
            AGGREGATION_A.clearAllLocalData();
            OUTPUT_A.clearAllLocalData();
        }
    }
    
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        variableMenu = new javax.swing.JPopupMenu();
        precipitation = new javax.swing.JMenuItem();
        temperature = new javax.swing.JMenuItem();
        streamflow = new javax.swing.JMenuItem();
        stage = new javax.swing.JMenuItem();
        splitPane = new javax.swing.JSplitPane();
        leftPanel = new javax.swing.JPanel();
        scrollPane = new javax.swing.JScrollPane();
        unitsTable = new ToolTipTable();
        rightPanel = new javax.swing.JPanel();
        identifiersPanel = new javax.swing.JPanel();
        identifierScrollPane = new javax.swing.JScrollPane();
        jPanel35 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        locationIDLabel = new javax.swing.JLabel();
        locationIDField = new javax.swing.JTextField();
        variableIDLabel = new javax.swing.JLabel();
        variableIDField = new javax.swing.JTextField();
        jPanel57 = new javax.swing.JPanel();
        jPanel69 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel53 = new javax.swing.JPanel();
        additionalIDLabel = new javax.swing.JLabel();
        additionalIDField = new javax.swing.JTextField();
        blankIDLabel = new javax.swing.JLabel();
        jPanel100 = new javax.swing.JPanel();
        jPanel58 = new javax.swing.JPanel();
        jPanel70 = new javax.swing.JPanel();
        seperator1 = new javax.swing.JPanel();
        sourceDataPanel = new javax.swing.JPanel();
        inputScrollPane = new javax.swing.JScrollPane();
        jPanel36 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        forecastFileLabel = new javax.swing.JLabel();
        forecastFileField = new javax.swing.JTextField();
        observedFileLabel = new javax.swing.JLabel();
        observedFileField = new javax.swing.JTextField();
        jPanel24 = new javax.swing.JPanel();
        jPanel51 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel27 = new javax.swing.JPanel();
        jPanel32 = new javax.swing.JPanel();
        forecastFileButton = new javax.swing.JButton();
        jPanel52 = new javax.swing.JPanel();
        jPanel28 = new javax.swing.JPanel();
        jPanel29 = new javax.swing.JPanel();
        jPanel48 = new javax.swing.JPanel();
        observedFileButton = new javax.swing.JButton();
        jPanel49 = new javax.swing.JPanel();
        jPanel30 = new javax.swing.JPanel();
        jPanel50 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jPanel86 = new javax.swing.JPanel();
        forecastFileTypeLabel = new javax.swing.JLabel();
        jPanel87 = new javax.swing.JPanel();
        forecastTSLabel = new javax.swing.JLabel();
        jPanel88 = new javax.swing.JPanel();
        jPanel89 = new javax.swing.JPanel();
        jPanel84 = new javax.swing.JPanel();
        jPanel85 = new javax.swing.JPanel();
        forecastFileTypeBox = new AdaptableComboBox();
        jPanel90 = new javax.swing.JPanel();
        forecastTSBox = new AdaptableComboBox();
        jPanel91 = new javax.swing.JPanel();
        jPanel92 = new javax.swing.JPanel();
        observedFileTypeLabel = new javax.swing.JLabel();
        jPanel93 = new javax.swing.JPanel();
        observedTSLabel = new javax.swing.JLabel();
        jPanel94 = new javax.swing.JPanel();
        jPanel95 = new javax.swing.JPanel();
        jPanel96 = new javax.swing.JPanel();
        jPanel97 = new javax.swing.JPanel();
        observedFileTypeBox = new AdaptableComboBox();
        jPanel98 = new javax.swing.JPanel();
        observedTSBox = new AdaptableComboBox();
        jPanel99 = new javax.swing.JPanel();
        jPanel25 = new javax.swing.JPanel();
        jPanel45 = new javax.swing.JPanel();
        jPanel46 = new javax.swing.JPanel();
        moreButton = new javax.swing.JButton();
        seperator3 = new javax.swing.JPanel();
        timePanel = new javax.swing.JPanel();
        temporalScrollPane = new javax.swing.JScrollPane();
        jPanel37 = new javax.swing.JPanel();
        jPanel54 = new javax.swing.JPanel();
        startDateLabel = new javax.swing.JLabel();
        jPanel72 = new javax.swing.JPanel();
        startYearField = new javax.swing.JTextField();
        jPanel12 = new javax.swing.JPanel();
        startMonthBox = new javax.swing.JComboBox();
        jPanel15 = new javax.swing.JPanel();
        startDayBox = new javax.swing.JComboBox();
        endDateLabel = new javax.swing.JLabel();
        jPanel82 = new javax.swing.JPanel();
        endYearField = new javax.swing.JTextField();
        jPanel21 = new javax.swing.JPanel();
        endMonthBox = new javax.swing.JComboBox();
        jPanel34 = new javax.swing.JPanel();
        endDayBox = new javax.swing.JComboBox();
        jPanel71 = new javax.swing.JPanel();
        jPanel31 = new javax.swing.JPanel();
        jPanel56 = new javax.swing.JPanel();
        jPanel42 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jPanel59 = new javax.swing.JPanel();
        startDateButton = new javax.swing.JButton();
        jPanel61 = new javax.swing.JPanel();
        jPanel41 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jPanel62 = new javax.swing.JPanel();
        endDateButton = new javax.swing.JButton();
        jPanel63 = new javax.swing.JPanel();
        jPanel33 = new javax.swing.JPanel();
        jPanel55 = new javax.swing.JPanel();
        jPanel83 = new javax.swing.JPanel();
        jPanel40 = new javax.swing.JPanel();
        firstLeadLabel = new javax.swing.JLabel();
        jPanel77 = new javax.swing.JPanel();
        lastLeadLabel = new javax.swing.JLabel();
        jPanel81 = new javax.swing.JPanel();
        jPanel80 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jPanel39 = new javax.swing.JPanel();
        firstLeadField = new javax.swing.JTextField();
        jPanel43 = new javax.swing.JPanel();
        lastLeadField = new javax.swing.JTextField();
        jPanel44 = new javax.swing.JPanel();
        forecastLeadBox = new javax.swing.JComboBox();
        verificationTimestepLabel = new javax.swing.JLabel();
        jPanel23 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        temporalResolutionField = new javax.swing.JTextField();
        jPanel26 = new javax.swing.JPanel();
        temporalResolutionBox = new javax.swing.JComboBox();
        jPanel64 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        moreButton1 = new javax.swing.JButton();
        seperator2 = new javax.swing.JPanel();
        outputPanel = new javax.swing.JPanel();
        outputScrollPane = new javax.swing.JScrollPane();
        jPanel38 = new javax.swing.JPanel();
        jPanel65 = new javax.swing.JPanel();
        outputFolderLabel = new javax.swing.JLabel();
        jPanel68 = new javax.swing.JPanel();
        outputFolderField = new javax.swing.JTextField();
        jPanel73 = new javax.swing.JPanel();
        jPanel67 = new javax.swing.JPanel();
        jPanel47 = new javax.swing.JPanel();
        jPanel76 = new javax.swing.JPanel();
        jPanel78 = new javax.swing.JPanel();
        outputFolderButton = new javax.swing.JButton();
        jPanel79 = new javax.swing.JPanel();
        jPanel75 = new javax.swing.JPanel();
        jPanel66 = new javax.swing.JPanel();
        jPanel74 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jPanel60 = new javax.swing.JPanel();
        moreButton2 = new javax.swing.JButton();
        jPanel19 = new javax.swing.JPanel();
        addButton = new javax.swing.JButton();
        jPanel1413 = new javax.swing.JPanel();
        deleteButton = new javax.swing.JButton();
        jPanel1414 = new javax.swing.JPanel();
        copyButton = new javax.swing.JButton();
        jPanel1415 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        nextButton = new javax.swing.JButton();

        precipitation.setText("Precipitation");
        precipitation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                precipitationActionPerformed(evt);
            }
        });
        variableMenu.add(precipitation);

        temperature.setText("Temperature");
        temperature.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                temperatureActionPerformed(evt);
            }
        });
        variableMenu.add(temperature);

        streamflow.setText("Streamflow");
        streamflow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                streamflowActionPerformed(evt);
            }
        });
        variableMenu.add(streamflow);

        stage.setText("Water_level");
        stage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stageActionPerformed(evt);
            }
        });
        variableMenu.add(stage);

        setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        setMaximumSize(new java.awt.Dimension(32000, 500));
        setMinimumSize(new java.awt.Dimension(500, 330));
        setPreferredSize(new java.awt.Dimension(1024, 768));
        setLayout(new javax.swing.BoxLayout(this, javax.swing.BoxLayout.Y_AXIS));

        splitPane.setDividerLocation(260);
        splitPane.setDividerSize(7);
        splitPane.setResizeWeight(0.25);
        splitPane.setMaximumSize(new java.awt.Dimension(2147363747, 2147363747));
        splitPane.setMinimumSize(new java.awt.Dimension(10000000, 0));
        splitPane.setPreferredSize(new java.awt.Dimension(0, 0));

        leftPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "1. Add verification unit(s)", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 12))); // NOI18N
        leftPanel.setMinimumSize(new java.awt.Dimension(30, 47));
        leftPanel.setPreferredSize(new java.awt.Dimension(27000, 34));
        leftPanel.setLayout(new java.awt.GridLayout(1, 0));

        scrollPane.setPreferredSize(new java.awt.Dimension(450, 3000));

        unitsTable.setModel(getUnitsTableModel());
        unitsTable.setInheritsPopupMenu(true);
        unitsTable.setMaximumSize(new java.awt.Dimension(32000, 32000));
        unitsTable.setRequestFocusEnabled(false);
        scrollPane.setViewportView(unitsTable);

        leftPanel.add(scrollPane);

        splitPane.setLeftComponent(leftPanel);

        rightPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "2. Set properties of selected verification unit", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 12))); // NOI18N
        rightPanel.setMaximumSize(new java.awt.Dimension(32779, 32794));
        rightPanel.setMinimumSize(new java.awt.Dimension(30, 47));
        rightPanel.setPreferredSize(new java.awt.Dimension(35000, 34));
        rightPanel.setLayout(new javax.swing.BoxLayout(rightPanel, javax.swing.BoxLayout.Y_AXIS));

        identifiersPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "2a. Set unit identifiers (right click for defaults)", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11))); // NOI18N
        identifiersPanel.setMaximumSize(new java.awt.Dimension(32000, 11000));
        identifiersPanel.setMinimumSize(new java.awt.Dimension(0, 0));
        identifiersPanel.setPreferredSize(new java.awt.Dimension(32000, 0));
        identifiersPanel.setLayout(new javax.swing.BoxLayout(identifiersPanel, javax.swing.BoxLayout.LINE_AXIS));

        identifierScrollPane.setBorder(null);
        identifierScrollPane.setPreferredSize(new java.awt.Dimension(100, 200));

        jPanel35.setMinimumSize(new java.awt.Dimension(0, 0));
        jPanel35.setPreferredSize(new java.awt.Dimension(10, 160));
        jPanel35.setLayout(new javax.swing.BoxLayout(jPanel35, javax.swing.BoxLayout.LINE_AXIS));

        jPanel1.setAlignmentX(0.0F);
        jPanel1.setMaximumSize(new java.awt.Dimension(2800, 32767));
        jPanel1.setMinimumSize(new java.awt.Dimension(78, 192));
        jPanel1.setPreferredSize(new java.awt.Dimension(30, 1200));
        jPanel1.setLayout(new javax.swing.BoxLayout(jPanel1, javax.swing.BoxLayout.Y_AXIS));

        locationIDLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        locationIDLabel.setText("Location identifier");
        locationIDLabel.setEnabled(false);
        locationIDLabel.setMaximumSize(new java.awt.Dimension(32767, 32767));
        locationIDLabel.setMinimumSize(new java.awt.Dimension(1000, 22));
        locationIDLabel.setPreferredSize(new java.awt.Dimension(100, 22));
        jPanel1.add(locationIDLabel);

        locationIDField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        locationIDField.setEnabled(false);
        locationIDField.setMaximumSize(new java.awt.Dimension(32000, 30));
        locationIDField.setMinimumSize(new java.awt.Dimension(4, 30));
        locationIDField.setPreferredSize(new java.awt.Dimension(1000, 30));
        jPanel1.add(locationIDField);

        variableIDLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        variableIDLabel.setText("Environmental variable identifier");
        variableIDLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        variableIDLabel.setEnabled(false);
        variableIDLabel.setMaximumSize(new java.awt.Dimension(32767, 32767));
        variableIDLabel.setMinimumSize(new java.awt.Dimension(1000, 27));
        variableIDLabel.setPreferredSize(new java.awt.Dimension(100, 27));
        jPanel1.add(variableIDLabel);

        variableIDField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        variableIDField.setEnabled(false);
        variableIDField.setMaximumSize(new java.awt.Dimension(32000, 30));
        variableIDField.setMinimumSize(new java.awt.Dimension(4, 30));
        variableIDField.setPreferredSize(new java.awt.Dimension(1000, 30));
        variableIDField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                variableIDFieldMouseClicked(evt);
            }
        });
        jPanel1.add(variableIDField);

        jPanel57.setPreferredSize(new java.awt.Dimension(10, 10000));
        jPanel1.add(jPanel57);

        jPanel69.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel69.setMinimumSize(new java.awt.Dimension(10, 30));
        jPanel69.setPreferredSize(new java.awt.Dimension(10, 30));
        jPanel1.add(jPanel69);

        jPanel35.add(jPanel1);

        jPanel3.setMaximumSize(new java.awt.Dimension(40, 500));
        jPanel3.setMinimumSize(new java.awt.Dimension(10, 176));
        jPanel3.setPreferredSize(new java.awt.Dimension(40, 1000));
        jPanel35.add(jPanel3);

        jPanel53.setMaximumSize(new java.awt.Dimension(2800, 32767));
        jPanel53.setMinimumSize(new java.awt.Dimension(78, 192));
        jPanel53.setPreferredSize(new java.awt.Dimension(30, 10000));
        jPanel53.setLayout(new javax.swing.BoxLayout(jPanel53, javax.swing.BoxLayout.Y_AXIS));

        additionalIDLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        additionalIDLabel.setText("Additional identifier [optional]");
        additionalIDLabel.setEnabled(false);
        additionalIDLabel.setMaximumSize(new java.awt.Dimension(32767, 32767));
        additionalIDLabel.setMinimumSize(new java.awt.Dimension(1000, 22));
        additionalIDLabel.setPreferredSize(new java.awt.Dimension(100, 22));
        jPanel53.add(additionalIDLabel);

        additionalIDField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        additionalIDField.setEnabled(false);
        additionalIDField.setMaximumSize(new java.awt.Dimension(32000, 30));
        additionalIDField.setMinimumSize(new java.awt.Dimension(4, 30));
        additionalIDField.setPreferredSize(new java.awt.Dimension(1000, 30));
        jPanel53.add(additionalIDField);

        blankIDLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        blankIDLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        blankIDLabel.setEnabled(false);
        blankIDLabel.setMaximumSize(new java.awt.Dimension(32767, 32767));
        blankIDLabel.setMinimumSize(new java.awt.Dimension(1000, 27));
        blankIDLabel.setPreferredSize(new java.awt.Dimension(100, 27));
        jPanel53.add(blankIDLabel);

        jPanel100.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel100.setMinimumSize(new java.awt.Dimension(10, 30));
        jPanel100.setPreferredSize(new java.awt.Dimension(10, 27));
        jPanel53.add(jPanel100);

        jPanel58.setPreferredSize(new java.awt.Dimension(10, 10000));
        jPanel53.add(jPanel58);

        jPanel70.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel70.setMinimumSize(new java.awt.Dimension(10, 30));
        jPanel70.setPreferredSize(new java.awt.Dimension(10, 30));
        jPanel53.add(jPanel70);

        jPanel35.add(jPanel53);

        identifierScrollPane.setViewportView(jPanel35);

        identifiersPanel.add(identifierScrollPane);

        rightPanel.add(identifiersPanel);

        seperator1.setMaximumSize(new java.awt.Dimension(10000, 3));
        seperator1.setMinimumSize(new java.awt.Dimension(5, 3));
        seperator1.setPreferredSize(new java.awt.Dimension(10000, 3));
        rightPanel.add(seperator1);

        sourceDataPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "2b. Identify input data sources", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11), new java.awt.Color(51, 51, 51))); // NOI18N
        sourceDataPanel.setMaximumSize(new java.awt.Dimension(32000, 11000));
        sourceDataPanel.setMinimumSize(new java.awt.Dimension(0, 0));
        sourceDataPanel.setPreferredSize(new java.awt.Dimension(32000, 0));
        sourceDataPanel.setLayout(new javax.swing.BoxLayout(sourceDataPanel, javax.swing.BoxLayout.LINE_AXIS));

        inputScrollPane.setBorder(null);
        inputScrollPane.setPreferredSize(new java.awt.Dimension(100, 200));

        jPanel36.setMinimumSize(new java.awt.Dimension(0, 0));
        jPanel36.setPreferredSize(new java.awt.Dimension(100, 160));
        jPanel36.setLayout(new javax.swing.BoxLayout(jPanel36, javax.swing.BoxLayout.LINE_AXIS));

        jPanel18.setAlignmentX(0.0F);
        jPanel18.setMaximumSize(new java.awt.Dimension(2800, 32767));
        jPanel18.setMinimumSize(new java.awt.Dimension(78, 192));
        jPanel18.setPreferredSize(new java.awt.Dimension(30, 120));
        jPanel18.setLayout(new javax.swing.BoxLayout(jPanel18, javax.swing.BoxLayout.Y_AXIS));

        forecastFileLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        forecastFileLabel.setText("File(s) or directory containing forecast data");
        forecastFileLabel.setAlignmentX(0.5F);
        forecastFileLabel.setEnabled(false);
        forecastFileLabel.setMaximumSize(new java.awt.Dimension(32767, 32767));
        forecastFileLabel.setMinimumSize(new java.awt.Dimension(1000, 22));
        forecastFileLabel.setPreferredSize(new java.awt.Dimension(100, 22));
        jPanel18.add(forecastFileLabel);

        forecastFileField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        forecastFileField.setEnabled(false);
        forecastFileField.setMaximumSize(new java.awt.Dimension(32000, 30));
        forecastFileField.setMinimumSize(new java.awt.Dimension(4, 30));
        forecastFileField.setPreferredSize(new java.awt.Dimension(1000, 30));
        jPanel18.add(forecastFileField);

        observedFileLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        observedFileLabel.setText("File containing observed data");
        observedFileLabel.setAlignmentX(0.5F);
        observedFileLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        observedFileLabel.setEnabled(false);
        observedFileLabel.setMaximumSize(new java.awt.Dimension(32767, 32767));
        observedFileLabel.setMinimumSize(new java.awt.Dimension(1000, 27));
        observedFileLabel.setPreferredSize(new java.awt.Dimension(100, 27));
        jPanel18.add(observedFileLabel);

        observedFileField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        observedFileField.setEnabled(false);
        observedFileField.setMaximumSize(new java.awt.Dimension(32000, 30));
        observedFileField.setMinimumSize(new java.awt.Dimension(4, 30));
        observedFileField.setPreferredSize(new java.awt.Dimension(1000, 30));
        jPanel18.add(observedFileField);

        jPanel24.setPreferredSize(new java.awt.Dimension(10, 10000));
        jPanel18.add(jPanel24);

        jPanel51.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel51.setMinimumSize(new java.awt.Dimension(10, 30));
        jPanel51.setPreferredSize(new java.awt.Dimension(10, 30));
        jPanel18.add(jPanel51);

        jPanel36.add(jPanel18);

        jPanel16.setMaximumSize(new java.awt.Dimension(40, 500));
        jPanel16.setPreferredSize(new java.awt.Dimension(40, 1000));
        jPanel16.setLayout(new javax.swing.BoxLayout(jPanel16, javax.swing.BoxLayout.Y_AXIS));

        jPanel17.setMinimumSize(new java.awt.Dimension(10, 22));
        jPanel17.setPreferredSize(new java.awt.Dimension(10, 22));
        jPanel16.add(jPanel17);

        jPanel27.setMaximumSize(new java.awt.Dimension(32000, 32000));
        jPanel27.setMinimumSize(new java.awt.Dimension(10, 30));
        jPanel27.setPreferredSize(new java.awt.Dimension(10, 30));
        jPanel27.setLayout(new javax.swing.BoxLayout(jPanel27, javax.swing.BoxLayout.LINE_AXIS));

        jPanel32.setMaximumSize(new java.awt.Dimension(5, 32767));
        jPanel32.setMinimumSize(new java.awt.Dimension(5, 5));
        jPanel32.setPreferredSize(new java.awt.Dimension(5, 10));
        jPanel27.add(jPanel32);

        forecastFileButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/files.png"))); // NOI18N
        forecastFileButton.setAlignmentX(0.5F);
        forecastFileButton.setEnabled(false);
        forecastFileButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
        forecastFileButton.setMaximumSize(new java.awt.Dimension(30, 30));
        forecastFileButton.setMinimumSize(new java.awt.Dimension(30, 30));
        forecastFileButton.setPreferredSize(new java.awt.Dimension(30, 30));
        forecastFileButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                forecastFileButtonActionPerformed(evt);
            }
        });
        jPanel27.add(forecastFileButton);

        jPanel52.setMaximumSize(new java.awt.Dimension(5, 32767));
        jPanel52.setMinimumSize(new java.awt.Dimension(5, 5));
        jPanel52.setPreferredSize(new java.awt.Dimension(5, 10));
        jPanel27.add(jPanel52);

        jPanel16.add(jPanel27);

        jPanel28.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        jPanel28.setMinimumSize(new java.awt.Dimension(10, 27));
        jPanel28.setPreferredSize(new java.awt.Dimension(10, 27));
        jPanel16.add(jPanel28);

        jPanel29.setMaximumSize(new java.awt.Dimension(32000, 32000));
        jPanel29.setMinimumSize(new java.awt.Dimension(10, 30));
        jPanel29.setPreferredSize(new java.awt.Dimension(10, 30));
        jPanel29.setLayout(new javax.swing.BoxLayout(jPanel29, javax.swing.BoxLayout.LINE_AXIS));

        jPanel48.setMaximumSize(new java.awt.Dimension(5, 32767));
        jPanel48.setMinimumSize(new java.awt.Dimension(5, 5));
        jPanel48.setPreferredSize(new java.awt.Dimension(5, 10));
        jPanel29.add(jPanel48);

        observedFileButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/files.png"))); // NOI18N
        observedFileButton.setAlignmentX(0.5F);
        observedFileButton.setEnabled(false);
        observedFileButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
        observedFileButton.setMaximumSize(new java.awt.Dimension(30, 30));
        observedFileButton.setMinimumSize(new java.awt.Dimension(30, 30));
        observedFileButton.setPreferredSize(new java.awt.Dimension(30, 30));
        observedFileButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                observedFileButtonActionPerformed(evt);
            }
        });
        jPanel29.add(observedFileButton);

        jPanel49.setMaximumSize(new java.awt.Dimension(5, 32767));
        jPanel49.setMinimumSize(new java.awt.Dimension(5, 5));
        jPanel49.setPreferredSize(new java.awt.Dimension(5, 10));
        jPanel29.add(jPanel49);

        jPanel16.add(jPanel29);

        jPanel30.setPreferredSize(new java.awt.Dimension(10, 10000));
        jPanel16.add(jPanel30);

        jPanel36.add(jPanel16);

        jPanel50.setMaximumSize(new java.awt.Dimension(2800, 32767));
        jPanel50.setMinimumSize(new java.awt.Dimension(78, 192));
        jPanel50.setPreferredSize(new java.awt.Dimension(30, 120));
        jPanel50.setLayout(new javax.swing.BoxLayout(jPanel50, javax.swing.BoxLayout.Y_AXIS));

        jPanel14.setMaximumSize(new java.awt.Dimension(2800, 32767));
        jPanel14.setMinimumSize(new java.awt.Dimension(1000, 0));
        jPanel14.setPreferredSize(new java.awt.Dimension(1000, 0));
        jPanel14.setLayout(new javax.swing.BoxLayout(jPanel14, javax.swing.BoxLayout.Y_AXIS));

        jPanel86.setMinimumSize(new java.awt.Dimension(0, 22));
        jPanel86.setLayout(new javax.swing.BoxLayout(jPanel86, javax.swing.BoxLayout.LINE_AXIS));

        forecastFileTypeLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        forecastFileTypeLabel.setText("Forecast file type");
        forecastFileTypeLabel.setAlignmentX(0.5F);
        forecastFileTypeLabel.setEnabled(false);
        forecastFileTypeLabel.setMaximumSize(new java.awt.Dimension(32000, 32767));
        forecastFileTypeLabel.setMinimumSize(new java.awt.Dimension(0, 22));
        forecastFileTypeLabel.setPreferredSize(new java.awt.Dimension(495, 22));
        jPanel86.add(forecastFileTypeLabel);

        jPanel87.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel86.add(jPanel87);

        forecastTSLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        forecastTSLabel.setText("Forecast time zone");
        forecastTSLabel.setAlignmentX(0.5F);
        forecastTSLabel.setEnabled(false);
        forecastTSLabel.setMaximumSize(new java.awt.Dimension(32000, 32767));
        forecastTSLabel.setMinimumSize(new java.awt.Dimension(0, 22));
        forecastTSLabel.setPreferredSize(new java.awt.Dimension(495, 22));
        jPanel86.add(forecastTSLabel);

        jPanel88.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel86.add(jPanel88);

        jPanel89.setMaximumSize(new java.awt.Dimension(100, 32767));
        jPanel89.setMinimumSize(new java.awt.Dimension(100, 10));
        jPanel89.setPreferredSize(new java.awt.Dimension(75, 10));
        jPanel86.add(jPanel89);

        jPanel14.add(jPanel86);

        jPanel84.setMaximumSize(new java.awt.Dimension(32000, 30));
        jPanel84.setMinimumSize(new java.awt.Dimension(4, 30));
        jPanel84.setPreferredSize(new java.awt.Dimension(1000, 28));
        jPanel84.setLayout(new javax.swing.BoxLayout(jPanel84, javax.swing.BoxLayout.LINE_AXIS));

        jPanel85.setMaximumSize(new java.awt.Dimension(32000, 30));
        jPanel85.setMinimumSize(new java.awt.Dimension(0, 30));
        jPanel85.setLayout(new javax.swing.BoxLayout(jPanel85, javax.swing.BoxLayout.LINE_AXIS));

        forecastFileTypeBox.setBackground(java.awt.Color.WHITE);
        forecastFileTypeBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        forecastFileTypeBox.setEnabled(false);
        forecastFileTypeBox.setMaximumSize(new java.awt.Dimension(32000, 30));
        forecastFileTypeBox.setMinimumSize(new java.awt.Dimension(0, 30));
        forecastFileTypeBox.setPreferredSize(new java.awt.Dimension(495, 30));
        forecastFileTypeBox.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                forecastFileTypeBoxPopupMenuWillBecomeVisible(evt);
            }
        });
        jPanel85.add(forecastFileTypeBox);

        jPanel90.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel85.add(jPanel90);

        forecastTSBox.setBackground(java.awt.Color.WHITE);
        forecastTSBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        forecastTSBox.setEnabled(false);
        forecastTSBox.setMaximumSize(new java.awt.Dimension(32000, 30));
        forecastTSBox.setMinimumSize(new java.awt.Dimension(0, 30));
        forecastTSBox.setPreferredSize(new java.awt.Dimension(495, 30));
        forecastTSBox.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                forecastTSBoxPopupMenuWillBecomeVisible(evt);
            }
        });
        jPanel85.add(forecastTSBox);

        jPanel84.add(jPanel85);

        jPanel91.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel91.setMinimumSize(new java.awt.Dimension(110, 10));
        jPanel91.setPreferredSize(new java.awt.Dimension(85, 10));
        jPanel84.add(jPanel91);

        jPanel14.add(jPanel84);

        jPanel92.setMinimumSize(new java.awt.Dimension(1000, 27));
        jPanel92.setPreferredSize(new java.awt.Dimension(100, 27));
        jPanel92.setLayout(new javax.swing.BoxLayout(jPanel92, javax.swing.BoxLayout.LINE_AXIS));

        observedFileTypeLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        observedFileTypeLabel.setText("Observed file type");
        observedFileTypeLabel.setAlignmentX(0.5F);
        observedFileTypeLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        observedFileTypeLabel.setEnabled(false);
        observedFileTypeLabel.setMaximumSize(new java.awt.Dimension(32000, 32767));
        observedFileTypeLabel.setMinimumSize(new java.awt.Dimension(0, 22));
        observedFileTypeLabel.setPreferredSize(new java.awt.Dimension(495, 22));
        jPanel92.add(observedFileTypeLabel);

        jPanel93.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel92.add(jPanel93);

        observedTSLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        observedTSLabel.setText("Observed time zone");
        observedTSLabel.setAlignmentX(0.5F);
        observedTSLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        observedTSLabel.setEnabled(false);
        observedTSLabel.setMaximumSize(new java.awt.Dimension(32000, 32767));
        observedTSLabel.setMinimumSize(new java.awt.Dimension(0, 22));
        observedTSLabel.setPreferredSize(new java.awt.Dimension(495, 22));
        jPanel92.add(observedTSLabel);

        jPanel94.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel92.add(jPanel94);

        jPanel95.setMaximumSize(new java.awt.Dimension(100, 32767));
        jPanel95.setMinimumSize(new java.awt.Dimension(100, 10));
        jPanel95.setPreferredSize(new java.awt.Dimension(75, 10));
        jPanel92.add(jPanel95);

        jPanel14.add(jPanel92);

        jPanel96.setMaximumSize(new java.awt.Dimension(32000, 30));
        jPanel96.setMinimumSize(new java.awt.Dimension(4, 30));
        jPanel96.setPreferredSize(new java.awt.Dimension(1000, 28));
        jPanel96.setLayout(new javax.swing.BoxLayout(jPanel96, javax.swing.BoxLayout.LINE_AXIS));

        jPanel97.setMaximumSize(new java.awt.Dimension(32000, 30));
        jPanel97.setMinimumSize(new java.awt.Dimension(0, 30));
        jPanel97.setLayout(new javax.swing.BoxLayout(jPanel97, javax.swing.BoxLayout.LINE_AXIS));

        observedFileTypeBox.setBackground(java.awt.Color.WHITE);
        observedFileTypeBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        observedFileTypeBox.setEnabled(false);
        observedFileTypeBox.setMaximumSize(new java.awt.Dimension(32000, 30));
        observedFileTypeBox.setMinimumSize(new java.awt.Dimension(0, 30));
        observedFileTypeBox.setPreferredSize(new java.awt.Dimension(495, 30));
        observedFileTypeBox.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                observedFileTypeBoxPopupMenuWillBecomeVisible(evt);
            }
        });
        jPanel97.add(observedFileTypeBox);

        jPanel98.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel97.add(jPanel98);

        observedTSBox.setBackground(java.awt.Color.WHITE);
        observedTSBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        observedTSBox.setEnabled(false);
        observedTSBox.setMaximumSize(new java.awt.Dimension(32000, 30));
        observedTSBox.setMinimumSize(new java.awt.Dimension(0, 30));
        observedTSBox.setPreferredSize(new java.awt.Dimension(495, 30));
        observedTSBox.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                observedTSBoxPopupMenuWillBecomeVisible(evt);
            }
        });
        jPanel97.add(observedTSBox);

        jPanel96.add(jPanel97);

        jPanel99.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel99.setMinimumSize(new java.awt.Dimension(110, 10));
        jPanel99.setPreferredSize(new java.awt.Dimension(85, 10));
        jPanel96.add(jPanel99);

        jPanel14.add(jPanel96);

        jPanel25.setPreferredSize(new java.awt.Dimension(10, 10000));
        jPanel14.add(jPanel25);

        jPanel50.add(jPanel14);

        jPanel45.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel45.setMinimumSize(new java.awt.Dimension(10, 30));
        jPanel45.setPreferredSize(new java.awt.Dimension(10, 30));
        jPanel45.setLayout(new javax.swing.BoxLayout(jPanel45, javax.swing.BoxLayout.LINE_AXIS));

        jPanel46.setAlignmentX(0.0F);
        jPanel46.setAlignmentY(0.0F);
        jPanel46.setMaximumSize(new java.awt.Dimension(32767, 29));
        jPanel46.setMinimumSize(new java.awt.Dimension(10, 29));
        jPanel46.setPreferredSize(new java.awt.Dimension(10, 29));
        jPanel45.add(jPanel46);

        moreButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        moreButton.setText("More");
        moreButton.setAlignmentY(0.0F);
        moreButton.setEnabled(false);
        moreButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        moreButton.setMaximumSize(new java.awt.Dimension(65, 29));
        moreButton.setMinimumSize(new java.awt.Dimension(65, 29));
        moreButton.setPreferredSize(new java.awt.Dimension(65, 29));
        moreButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                moreButtonActionPerformed(evt);
            }
        });
        jPanel45.add(moreButton);

        jPanel50.add(jPanel45);

        jPanel36.add(jPanel50);

        inputScrollPane.setViewportView(jPanel36);

        sourceDataPanel.add(inputScrollPane);

        rightPanel.add(sourceDataPanel);

        seperator3.setMaximumSize(new java.awt.Dimension(10000, 3));
        seperator3.setMinimumSize(new java.awt.Dimension(5, 3));
        seperator3.setPreferredSize(new java.awt.Dimension(10000, 3));
        rightPanel.add(seperator3);

        timePanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "2c. Set time parameters", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11))); // NOI18N
        timePanel.setMaximumSize(new java.awt.Dimension(32000, 11000));
        timePanel.setMinimumSize(new java.awt.Dimension(0, 0));
        timePanel.setPreferredSize(new java.awt.Dimension(32000, 0));
        timePanel.setLayout(new javax.swing.BoxLayout(timePanel, javax.swing.BoxLayout.LINE_AXIS));

        temporalScrollPane.setBorder(null);
        temporalScrollPane.setPreferredSize(new java.awt.Dimension(100, 200));

        jPanel37.setMinimumSize(new java.awt.Dimension(0, 0));
        jPanel37.setPreferredSize(new java.awt.Dimension(10, 160));
        jPanel37.setLayout(new javax.swing.BoxLayout(jPanel37, javax.swing.BoxLayout.LINE_AXIS));

        jPanel54.setMaximumSize(new java.awt.Dimension(2800, 10000));
        jPanel54.setMinimumSize(new java.awt.Dimension(78, 0));
        jPanel54.setPreferredSize(new java.awt.Dimension(30, 0));
        jPanel54.setLayout(new javax.swing.BoxLayout(jPanel54, javax.swing.BoxLayout.Y_AXIS));

        startDateLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        startDateLabel.setText("Start of verification period");
        startDateLabel.setAlignmentX(0.5F);
        startDateLabel.setEnabled(false);
        startDateLabel.setMaximumSize(new java.awt.Dimension(32767, 32768));
        startDateLabel.setMinimumSize(new java.awt.Dimension(1000, 22));
        startDateLabel.setPreferredSize(new java.awt.Dimension(100, 22));
        jPanel54.add(startDateLabel);

        jPanel72.setMaximumSize(new java.awt.Dimension(32000, 28));
        jPanel72.setMinimumSize(new java.awt.Dimension(4, 30));
        jPanel72.setPreferredSize(new java.awt.Dimension(1000, 27));
        jPanel72.setLayout(new javax.swing.BoxLayout(jPanel72, javax.swing.BoxLayout.LINE_AXIS));

        startYearField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        startYearField.setText("YYYY");
        startYearField.setEnabled(false);
        startYearField.setMaximumSize(new java.awt.Dimension(32000, 30));
        startYearField.setMinimumSize(new java.awt.Dimension(0, 30));
        startYearField.setPreferredSize(new java.awt.Dimension(500, 30));
        startYearField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                startYearFieldMouseClicked(evt);
            }
        });
        startYearField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                startYearFieldKeyReleased(evt);
            }
        });
        jPanel72.add(startYearField);

        jPanel12.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel72.add(jPanel12);

        startMonthBox.setBackground(java.awt.Color.WHITE);
        startMonthBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        startMonthBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "MM", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));
        startMonthBox.setEnabled(false);
        startMonthBox.setMinimumSize(new java.awt.Dimension(51, 27));
        startMonthBox.setPreferredSize(new java.awt.Dimension(75, 30));
        startMonthBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startMonthBoxActionPerformed(evt);
            }
        });
        jPanel72.add(startMonthBox);

        jPanel15.setAlignmentX(0.0F);
        jPanel15.setAlignmentY(0.0F);
        jPanel15.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel72.add(jPanel15);

        startDayBox.setBackground(java.awt.Color.WHITE);
        startDayBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        startDayBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "DD", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        startDayBox.setEnabled(false);
        startDayBox.setMinimumSize(new java.awt.Dimension(51, 27));
        startDayBox.setPreferredSize(new java.awt.Dimension(75, 30));
        jPanel72.add(startDayBox);

        jPanel54.add(jPanel72);

        endDateLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        endDateLabel.setText("End of verification period");
        endDateLabel.setAlignmentX(0.5F);
        endDateLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        endDateLabel.setEnabled(false);
        endDateLabel.setMaximumSize(new java.awt.Dimension(32767, 32767));
        endDateLabel.setMinimumSize(new java.awt.Dimension(1000, 27));
        endDateLabel.setPreferredSize(new java.awt.Dimension(100, 27));
        jPanel54.add(endDateLabel);

        jPanel82.setMaximumSize(new java.awt.Dimension(32000, 28));
        jPanel82.setMinimumSize(new java.awt.Dimension(4, 30));
        jPanel82.setPreferredSize(new java.awt.Dimension(1000, 27));
        jPanel82.setLayout(new javax.swing.BoxLayout(jPanel82, javax.swing.BoxLayout.LINE_AXIS));

        endYearField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        endYearField.setText("YYYY");
        endYearField.setEnabled(false);
        endYearField.setMaximumSize(new java.awt.Dimension(32000, 30));
        endYearField.setMinimumSize(new java.awt.Dimension(0, 30));
        endYearField.setPreferredSize(new java.awt.Dimension(500, 30));
        endYearField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                endYearFieldMouseClicked(evt);
            }
        });
        endYearField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                endYearFieldKeyReleased(evt);
            }
        });
        jPanel82.add(endYearField);

        jPanel21.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel82.add(jPanel21);

        endMonthBox.setBackground(java.awt.Color.WHITE);
        endMonthBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        endMonthBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "MM", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));
        endMonthBox.setEnabled(false);
        endMonthBox.setMinimumSize(new java.awt.Dimension(51, 27));
        endMonthBox.setPreferredSize(new java.awt.Dimension(75, 30));
        endMonthBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                endMonthBoxActionPerformed(evt);
            }
        });
        jPanel82.add(endMonthBox);

        jPanel34.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel82.add(jPanel34);

        endDayBox.setBackground(java.awt.Color.WHITE);
        endDayBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        endDayBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "DD", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        endDayBox.setEnabled(false);
        endDayBox.setMinimumSize(new java.awt.Dimension(51, 27));
        endDayBox.setPreferredSize(new java.awt.Dimension(75, 30));
        jPanel82.add(endDayBox);

        jPanel54.add(jPanel82);

        jPanel71.setPreferredSize(new java.awt.Dimension(10, 10000));
        jPanel54.add(jPanel71);

        jPanel31.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel31.setMinimumSize(new java.awt.Dimension(10, 30));
        jPanel31.setPreferredSize(new java.awt.Dimension(10, 30));
        jPanel54.add(jPanel31);

        jPanel37.add(jPanel54);

        jPanel56.setMaximumSize(new java.awt.Dimension(40, 500));
        jPanel56.setMinimumSize(new java.awt.Dimension(10, 176));
        jPanel56.setPreferredSize(new java.awt.Dimension(40, 1000));
        jPanel56.setLayout(new javax.swing.BoxLayout(jPanel56, javax.swing.BoxLayout.Y_AXIS));

        jPanel42.setMinimumSize(new java.awt.Dimension(10, 22));
        jPanel42.setPreferredSize(new java.awt.Dimension(10, 22));
        jPanel56.add(jPanel42);

        jPanel7.setMaximumSize(new java.awt.Dimension(32000, 32000));
        jPanel7.setMinimumSize(new java.awt.Dimension(10, 30));
        jPanel7.setPreferredSize(new java.awt.Dimension(10, 30));
        jPanel7.setLayout(new javax.swing.BoxLayout(jPanel7, javax.swing.BoxLayout.LINE_AXIS));

        jPanel59.setMaximumSize(new java.awt.Dimension(5, 32767));
        jPanel59.setMinimumSize(new java.awt.Dimension(5, 5));
        jPanel59.setPreferredSize(new java.awt.Dimension(5, 10));
        jPanel7.add(jPanel59);

        startDateButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/files.png"))); // NOI18N
        startDateButton.setAlignmentX(0.5F);
        startDateButton.setEnabled(false);
        startDateButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
        startDateButton.setMaximumSize(new java.awt.Dimension(30, 30));
        startDateButton.setMinimumSize(new java.awt.Dimension(30, 30));
        startDateButton.setPreferredSize(new java.awt.Dimension(30, 30));
        startDateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startDateButtonActionPerformed(evt);
            }
        });
        jPanel7.add(startDateButton);

        jPanel61.setMaximumSize(new java.awt.Dimension(5, 32767));
        jPanel61.setMinimumSize(new java.awt.Dimension(5, 5));
        jPanel61.setPreferredSize(new java.awt.Dimension(5, 10));
        jPanel7.add(jPanel61);

        jPanel56.add(jPanel7);

        jPanel41.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        jPanel41.setMinimumSize(new java.awt.Dimension(10, 27));
        jPanel41.setPreferredSize(new java.awt.Dimension(10, 27));
        jPanel56.add(jPanel41);

        jPanel10.setMaximumSize(new java.awt.Dimension(32000, 32000));
        jPanel10.setMinimumSize(new java.awt.Dimension(10, 30));
        jPanel10.setPreferredSize(new java.awt.Dimension(10, 30));
        jPanel10.setLayout(new javax.swing.BoxLayout(jPanel10, javax.swing.BoxLayout.LINE_AXIS));

        jPanel62.setMaximumSize(new java.awt.Dimension(5, 32767));
        jPanel62.setMinimumSize(new java.awt.Dimension(5, 5));
        jPanel62.setPreferredSize(new java.awt.Dimension(5, 10));
        jPanel10.add(jPanel62);

        endDateButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/files.png"))); // NOI18N
        endDateButton.setAlignmentX(0.5F);
        endDateButton.setEnabled(false);
        endDateButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
        endDateButton.setMaximumSize(new java.awt.Dimension(30, 30));
        endDateButton.setMinimumSize(new java.awt.Dimension(30, 30));
        endDateButton.setPreferredSize(new java.awt.Dimension(30, 30));
        endDateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                endDateButtonActionPerformed(evt);
            }
        });
        jPanel10.add(endDateButton);

        jPanel63.setMaximumSize(new java.awt.Dimension(5, 32767));
        jPanel63.setMinimumSize(new java.awt.Dimension(5, 5));
        jPanel63.setPreferredSize(new java.awt.Dimension(5, 10));
        jPanel10.add(jPanel63);

        jPanel56.add(jPanel10);

        jPanel33.setPreferredSize(new java.awt.Dimension(10, 10000));
        jPanel56.add(jPanel33);

        jPanel37.add(jPanel56);

        jPanel55.setMaximumSize(new java.awt.Dimension(2800, 32767));
        jPanel55.setMinimumSize(new java.awt.Dimension(78, 192));
        jPanel55.setPreferredSize(new java.awt.Dimension(30, 120));
        jPanel55.setLayout(new javax.swing.BoxLayout(jPanel55, javax.swing.BoxLayout.Y_AXIS));

        jPanel83.setMaximumSize(new java.awt.Dimension(2800, 32767));
        jPanel83.setLayout(new javax.swing.BoxLayout(jPanel83, javax.swing.BoxLayout.Y_AXIS));

        jPanel40.setMinimumSize(new java.awt.Dimension(0, 22));
        jPanel40.setLayout(new javax.swing.BoxLayout(jPanel40, javax.swing.BoxLayout.LINE_AXIS));

        firstLeadLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        firstLeadLabel.setText("First lead time");
        firstLeadLabel.setAlignmentX(0.5F);
        firstLeadLabel.setEnabled(false);
        firstLeadLabel.setMaximumSize(new java.awt.Dimension(32000, 32767));
        firstLeadLabel.setMinimumSize(new java.awt.Dimension(0, 22));
        firstLeadLabel.setPreferredSize(new java.awt.Dimension(495, 22));
        jPanel40.add(firstLeadLabel);

        jPanel77.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel40.add(jPanel77);

        lastLeadLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        lastLeadLabel.setText("Last lead time");
        lastLeadLabel.setAlignmentX(0.5F);
        lastLeadLabel.setEnabled(false);
        lastLeadLabel.setMaximumSize(new java.awt.Dimension(32000, 32767));
        lastLeadLabel.setMinimumSize(new java.awt.Dimension(0, 22));
        lastLeadLabel.setPreferredSize(new java.awt.Dimension(495, 22));
        jPanel40.add(lastLeadLabel);

        jPanel81.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel40.add(jPanel81);

        jPanel80.setMaximumSize(new java.awt.Dimension(100, 32767));
        jPanel80.setMinimumSize(new java.awt.Dimension(100, 10));
        jPanel80.setPreferredSize(new java.awt.Dimension(75, 10));
        jPanel40.add(jPanel80);

        jPanel83.add(jPanel40);

        jPanel9.setMaximumSize(new java.awt.Dimension(32000, 30));
        jPanel9.setMinimumSize(new java.awt.Dimension(4, 30));
        jPanel9.setPreferredSize(new java.awt.Dimension(1000, 28));
        jPanel9.setLayout(new javax.swing.BoxLayout(jPanel9, javax.swing.BoxLayout.LINE_AXIS));

        jPanel39.setMaximumSize(new java.awt.Dimension(32000, 30));
        jPanel39.setMinimumSize(new java.awt.Dimension(0, 30));
        jPanel39.setLayout(new javax.swing.BoxLayout(jPanel39, javax.swing.BoxLayout.LINE_AXIS));

        firstLeadField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        firstLeadField.setEnabled(false);
        firstLeadField.setMaximumSize(new java.awt.Dimension(32000, 30));
        firstLeadField.setMinimumSize(new java.awt.Dimension(0, 30));
        firstLeadField.setPreferredSize(new java.awt.Dimension(495, 30));
        jPanel39.add(firstLeadField);

        jPanel43.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel39.add(jPanel43);

        lastLeadField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        lastLeadField.setEnabled(false);
        lastLeadField.setMaximumSize(new java.awt.Dimension(32000, 30));
        lastLeadField.setMinimumSize(new java.awt.Dimension(0, 30));
        lastLeadField.setPreferredSize(new java.awt.Dimension(495, 30));
        jPanel39.add(lastLeadField);

        jPanel9.add(jPanel39);

        jPanel44.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel9.add(jPanel44);

        forecastLeadBox.setBackground(java.awt.Color.WHITE);
        forecastLeadBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        forecastLeadBox.setEnabled(false);
        forecastLeadBox.setMaximumSize(new java.awt.Dimension(100, 32767));
        forecastLeadBox.setMinimumSize(new java.awt.Dimension(100, 27));
        forecastLeadBox.setPreferredSize(new java.awt.Dimension(75, 30));
        forecastLeadBox.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                forecastLeadBoxPopupMenuWillBecomeVisible(evt);
            }
        });
        jPanel9.add(forecastLeadBox);

        jPanel83.add(jPanel9);

        verificationTimestepLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        verificationTimestepLabel.setText("Aggregation period [optional]");
        verificationTimestepLabel.setAlignmentX(0.5F);
        verificationTimestepLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        verificationTimestepLabel.setEnabled(false);
        verificationTimestepLabel.setMaximumSize(new java.awt.Dimension(32767, 32767));
        verificationTimestepLabel.setMinimumSize(new java.awt.Dimension(1000, 27));
        verificationTimestepLabel.setPreferredSize(new java.awt.Dimension(100, 27));
        jPanel83.add(verificationTimestepLabel);

        jPanel23.setMaximumSize(new java.awt.Dimension(32000, 32767));
        jPanel23.setMinimumSize(new java.awt.Dimension(4, 30));
        jPanel23.setPreferredSize(new java.awt.Dimension(1000, 27));
        jPanel23.setLayout(new javax.swing.BoxLayout(jPanel23, javax.swing.BoxLayout.LINE_AXIS));

        jPanel2.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel2.setPreferredSize(new java.awt.Dimension(1000, 30));
        jPanel2.setLayout(new java.awt.GridLayout(1, 0));

        temporalResolutionField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        temporalResolutionField.setEnabled(false);
        temporalResolutionField.setMaximumSize(new java.awt.Dimension(32000, 30));
        temporalResolutionField.setMinimumSize(new java.awt.Dimension(0, 30));
        temporalResolutionField.setPreferredSize(new java.awt.Dimension(1000, 30));
        jPanel2.add(temporalResolutionField);

        jPanel23.add(jPanel2);

        jPanel26.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel23.add(jPanel26);

        temporalResolutionBox.setBackground(java.awt.Color.WHITE);
        temporalResolutionBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        temporalResolutionBox.setEnabled(false);
        temporalResolutionBox.setMaximumSize(new java.awt.Dimension(100, 32767));
        temporalResolutionBox.setMinimumSize(new java.awt.Dimension(100, 27));
        temporalResolutionBox.setPreferredSize(new java.awt.Dimension(75, 30));
        temporalResolutionBox.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                temporalResolutionBoxPopupMenuWillBecomeVisible(evt);
            }
        });
        jPanel23.add(temporalResolutionBox);

        jPanel83.add(jPanel23);

        jPanel64.setPreferredSize(new java.awt.Dimension(10, 10000));
        jPanel83.add(jPanel64);

        jPanel55.add(jPanel83);

        jPanel4.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel4.setMinimumSize(new java.awt.Dimension(10, 30));
        jPanel4.setPreferredSize(new java.awt.Dimension(10, 30));
        jPanel4.setLayout(new javax.swing.BoxLayout(jPanel4, javax.swing.BoxLayout.LINE_AXIS));

        jPanel5.setAlignmentX(0.0F);
        jPanel5.setAlignmentY(0.0F);
        jPanel5.setMaximumSize(new java.awt.Dimension(32767, 29));
        jPanel5.setMinimumSize(new java.awt.Dimension(10, 29));
        jPanel5.setPreferredSize(new java.awt.Dimension(10, 29));
        jPanel4.add(jPanel5);

        moreButton1.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        moreButton1.setText("More");
        moreButton1.setAlignmentY(0.0F);
        moreButton1.setEnabled(false);
        moreButton1.setMargin(new java.awt.Insets(2, 10, 2, 10));
        moreButton1.setMaximumSize(new java.awt.Dimension(65, 29));
        moreButton1.setMinimumSize(new java.awt.Dimension(65, 29));
        moreButton1.setPreferredSize(new java.awt.Dimension(65, 29));
        moreButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                moreButton1ActionPerformed(evt);
            }
        });
        jPanel4.add(moreButton1);

        jPanel55.add(jPanel4);

        jPanel37.add(jPanel55);

        temporalScrollPane.setViewportView(jPanel37);

        timePanel.add(temporalScrollPane);

        rightPanel.add(timePanel);

        seperator2.setMaximumSize(new java.awt.Dimension(10000, 3));
        seperator2.setMinimumSize(new java.awt.Dimension(5, 3));
        seperator2.setPreferredSize(new java.awt.Dimension(10000, 3));
        rightPanel.add(seperator2);

        outputPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "2d. Set location for output data", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11))); // NOI18N
        outputPanel.setMaximumSize(new java.awt.Dimension(32000, 6500));
        outputPanel.setMinimumSize(new java.awt.Dimension(0, 0));
        outputPanel.setPreferredSize(new java.awt.Dimension(32000, 0));
        outputPanel.setLayout(new javax.swing.BoxLayout(outputPanel, javax.swing.BoxLayout.LINE_AXIS));

        outputScrollPane.setBorder(null);
        outputScrollPane.setMinimumSize(new java.awt.Dimension(21, 0));
        outputScrollPane.setPreferredSize(new java.awt.Dimension(100, 0));

        jPanel38.setMinimumSize(new java.awt.Dimension(0, 0));
        jPanel38.setPreferredSize(new java.awt.Dimension(10, 80));
        jPanel38.setLayout(new javax.swing.BoxLayout(jPanel38, javax.swing.BoxLayout.LINE_AXIS));

        jPanel65.setMaximumSize(new java.awt.Dimension(2800, 32767));
        jPanel65.setMinimumSize(new java.awt.Dimension(78, 192));
        jPanel65.setPreferredSize(new java.awt.Dimension(30, 120));
        jPanel65.setLayout(new javax.swing.BoxLayout(jPanel65, javax.swing.BoxLayout.Y_AXIS));

        outputFolderLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        outputFolderLabel.setText("Folder for output statistics");
        outputFolderLabel.setAlignmentX(0.5F);
        outputFolderLabel.setEnabled(false);
        outputFolderLabel.setMaximumSize(new java.awt.Dimension(32767, 32767));
        outputFolderLabel.setMinimumSize(new java.awt.Dimension(1000, 22));
        outputFolderLabel.setPreferredSize(new java.awt.Dimension(100, 22));
        jPanel65.add(outputFolderLabel);

        jPanel68.setMaximumSize(new java.awt.Dimension(32000, 28));
        jPanel68.setLayout(new java.awt.GridLayout(1, 0));
        jPanel65.add(jPanel68);

        outputFolderField.setEnabled(false);
        outputFolderField.setMaximumSize(new java.awt.Dimension(32000, 30));
        outputFolderField.setMinimumSize(new java.awt.Dimension(4, 30));
        outputFolderField.setPreferredSize(new java.awt.Dimension(1000, 30));
        jPanel65.add(outputFolderField);

        jPanel73.setPreferredSize(new java.awt.Dimension(10, 10000));
        jPanel65.add(jPanel73);

        jPanel38.add(jPanel65);

        jPanel67.setMaximumSize(new java.awt.Dimension(40, 500));
        jPanel67.setPreferredSize(new java.awt.Dimension(40, 10));
        jPanel67.setLayout(new javax.swing.BoxLayout(jPanel67, javax.swing.BoxLayout.Y_AXIS));

        jPanel47.setMinimumSize(new java.awt.Dimension(10, 22));
        jPanel47.setPreferredSize(new java.awt.Dimension(10, 22));
        jPanel67.add(jPanel47);

        jPanel76.setMaximumSize(new java.awt.Dimension(32000, 32000));
        jPanel76.setMinimumSize(new java.awt.Dimension(10, 30));
        jPanel76.setPreferredSize(new java.awt.Dimension(10, 30));
        jPanel76.setLayout(new javax.swing.BoxLayout(jPanel76, javax.swing.BoxLayout.LINE_AXIS));

        jPanel78.setMaximumSize(new java.awt.Dimension(5, 32767));
        jPanel78.setMinimumSize(new java.awt.Dimension(5, 5));
        jPanel78.setPreferredSize(new java.awt.Dimension(5, 10));
        jPanel76.add(jPanel78);

        outputFolderButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/files.png"))); // NOI18N
        outputFolderButton.setAlignmentX(0.5F);
        outputFolderButton.setEnabled(false);
        outputFolderButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
        outputFolderButton.setMaximumSize(new java.awt.Dimension(30, 30));
        outputFolderButton.setMinimumSize(new java.awt.Dimension(30, 30));
        outputFolderButton.setPreferredSize(new java.awt.Dimension(30, 30));
        outputFolderButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                outputFolderButtonActionPerformed(evt);
            }
        });
        jPanel76.add(outputFolderButton);

        jPanel79.setMaximumSize(new java.awt.Dimension(5, 32767));
        jPanel79.setMinimumSize(new java.awt.Dimension(5, 5));
        jPanel79.setPreferredSize(new java.awt.Dimension(5, 10));
        jPanel76.add(jPanel79);

        jPanel67.add(jPanel76);

        jPanel75.setPreferredSize(new java.awt.Dimension(10, 10000));
        jPanel67.add(jPanel75);

        jPanel38.add(jPanel67);

        jPanel66.setMaximumSize(new java.awt.Dimension(2800, 32767));
        jPanel66.setMinimumSize(new java.awt.Dimension(78, 0));
        jPanel66.setPreferredSize(new java.awt.Dimension(30, 0));
        jPanel66.setLayout(new javax.swing.BoxLayout(jPanel66, javax.swing.BoxLayout.Y_AXIS));

        jPanel74.setMinimumSize(new java.awt.Dimension(10, 0));
        jPanel66.add(jPanel74);

        jPanel6.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel6.setMinimumSize(new java.awt.Dimension(10, 30));
        jPanel6.setPreferredSize(new java.awt.Dimension(10, 30));
        jPanel6.setLayout(new javax.swing.BoxLayout(jPanel6, javax.swing.BoxLayout.LINE_AXIS));

        jPanel60.setAlignmentX(0.0F);
        jPanel60.setAlignmentY(0.0F);
        jPanel60.setMaximumSize(new java.awt.Dimension(32767, 29));
        jPanel60.setMinimumSize(new java.awt.Dimension(10, 29));
        jPanel60.setPreferredSize(new java.awt.Dimension(10, 29));
        jPanel6.add(jPanel60);

        moreButton2.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        moreButton2.setText("More");
        moreButton2.setAlignmentY(0.0F);
        moreButton2.setEnabled(false);
        moreButton2.setMargin(new java.awt.Insets(2, 10, 2, 10));
        moreButton2.setMaximumSize(new java.awt.Dimension(65, 29));
        moreButton2.setMinimumSize(new java.awt.Dimension(65, 29));
        moreButton2.setPreferredSize(new java.awt.Dimension(65, 29));
        moreButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                moreButton2ActionPerformed(evt);
            }
        });
        jPanel6.add(moreButton2);

        jPanel66.add(jPanel6);

        jPanel38.add(jPanel66);

        outputScrollPane.setViewportView(jPanel38);

        outputPanel.add(outputScrollPane);

        rightPanel.add(outputPanel);

        splitPane.setRightComponent(rightPanel);

        add(splitPane);

        jPanel19.setMaximumSize(new java.awt.Dimension(32899, 40));
        jPanel19.setMinimumSize(new java.awt.Dimension(142, 40));
        jPanel19.setPreferredSize(new java.awt.Dimension(144, 40));
        jPanel19.setLayout(new javax.swing.BoxLayout(jPanel19, javax.swing.BoxLayout.LINE_AXIS));

        addButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        addButton.setText("Add");
        addButton.setAlignmentY(0.25F);
        addButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        addButton.setMaximumSize(new java.awt.Dimension(65, 29));
        addButton.setMinimumSize(new java.awt.Dimension(65, 29));
        addButton.setPreferredSize(new java.awt.Dimension(65, 29));
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });
        jPanel19.add(addButton);

        jPanel1413.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel1413.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel1413.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel19.add(jPanel1413);

        deleteButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        deleteButton.setText("Delete");
        deleteButton.setAlignmentY(0.25F);
        deleteButton.setEnabled(false);
        deleteButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        deleteButton.setMaximumSize(new java.awt.Dimension(65, 29));
        deleteButton.setMinimumSize(new java.awt.Dimension(65, 29));
        deleteButton.setPreferredSize(new java.awt.Dimension(65, 29));
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });
        jPanel19.add(deleteButton);

        jPanel1414.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel1414.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel1414.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel19.add(jPanel1414);

        copyButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        copyButton.setText("Copy");
        copyButton.setAlignmentY(0.25F);
        copyButton.setEnabled(false);
        copyButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        copyButton.setMaximumSize(new java.awt.Dimension(65, 29));
        copyButton.setMinimumSize(new java.awt.Dimension(65, 29));
        copyButton.setPreferredSize(new java.awt.Dimension(65, 29));
        copyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                copyButtonActionPerformed(evt);
            }
        });
        jPanel19.add(copyButton);

        jPanel1415.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel1415.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel1415.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel19.add(jPanel1415);

        jPanel20.setMinimumSize(new java.awt.Dimension(10, 29));
        jPanel19.add(jPanel20);

        nextButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        nextButton.setText("Next");
        nextButton.setAlignmentY(0.25F);
        nextButton.setEnabled(false);
        nextButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        nextButton.setMaximumSize(new java.awt.Dimension(65, 29));
        nextButton.setMinimumSize(new java.awt.Dimension(65, 29));
        nextButton.setPreferredSize(new java.awt.Dimension(65, 29));
        nextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextButtonActionPerformed(evt);
            }
        });
        jPanel19.add(nextButton);

        add(jPanel19);
    }// </editor-fold>//GEN-END:initComponents
    
    /**
     * Updates the start day box following a change in the month field.
     *
     * @param evt an action event
     */ 
    
    private void startMonthBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startMonthBoxActionPerformed
        setStartDayBox();
    }//GEN-LAST:event_startMonthBoxActionPerformed

    /**
     * Updates the end day box following a change in the month field.
     *
     * @param evt an action event
     */    
    
    private void endMonthBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_endMonthBoxActionPerformed
        setEndDayBox();
    }//GEN-LAST:event_endMonthBoxActionPerformed

    /**
     * Updates the start day box following a change in the year field.
     *
     * @param evt an action event
     */
   
    private void endYearFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_endYearFieldKeyReleased
        int id = evt.getKeyCode();
        //Could increase sophistication
        boolean go = id != evt.VK_DOWN && id != evt.VK_UP && id != evt.VK_LEFT && id != evt.VK_RIGHT;
        if(go) {        
            setEndDayBox();
        }
    }//GEN-LAST:event_endYearFieldKeyReleased

    /**
     * Updates the start day box following a change in the year field.
     *
     * @param evt an action event
     */
    
    private void startYearFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_startYearFieldKeyReleased
        int id = evt.getKeyCode();
        //Could increase sophistication
        boolean go = id != evt.VK_DOWN && id != evt.VK_UP && id != evt.VK_LEFT && id != evt.VK_RIGHT;
        if(go) {        
            setStartDayBox();
        }
    }//GEN-LAST:event_startYearFieldKeyReleased

    /**
     * Opens a scale editing dialog.
     *
     * @param evt an action event
     */
    
    private void moreButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_moreButtonActionPerformed
        //Update any recent changes
        try { 
            moreInputDialog.updateLocalData(getSelectedUnit());
            EVSMainWindow.main.setWindowLocation(moreInputDialog);        
            moreInputDialog.setVisible(true);
        }
        catch(Exception e) {
            ExceptionHandler.displayException(e);
            e.printStackTrace();
        }        
    }//GEN-LAST:event_moreButtonActionPerformed

    /**
     * Alters the width of the climatology time system pop-up menu to match the contents.
     *
     * @param evt a pop-up menu event
     */        
    
    /**
     * Shows a dialog for refining the verification window based on time period 
     * and variable value.
     *
     * @param evt an action event
     */
    
    private void moreButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_moreButton1ActionPerformed
        //Update any recent changes
        try { 
            if(syncAdvancedData()) {
                MoreVerificationWindowDialog advancedDialog = new MoreVerificationWindowDialog();
                advancedDialog.updateLocalData(getSelectedUnit());
                EVSMainWindow.main.setWindowLocation(advancedDialog);        
                advancedDialog.setVisible(true);
            }
        }
        catch(Exception e) {
            ExceptionHandler.displayException(new IllegalArgumentException("Complete the required parameters of the verification window first: "+e.getMessage()));
            e.printStackTrace();
        }
    }//GEN-LAST:event_moreButton1ActionPerformed

    /**
     * Alters the width of the forecast lead time pop-up menu to match the contents.
     *
     * @param evt a pop-up menu event
     */        
    
    private void forecastLeadBoxPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_forecastLeadBoxPopupMenuWillBecomeVisible
        EVSMainWindow.main.setPopupWidth(evt);
    }//GEN-LAST:event_forecastLeadBoxPopupMenuWillBecomeVisible

    /**
     * Opens a dialog for selecting the end date.
     *
     * @param evt an action event
     */    
    
    private void endDateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_endDateButtonActionPerformed
        try {
            endDateDialog.getCalendar().setCalendar(getEndDate());
        }
        catch(Exception e) {
            endDateDialog.getCalendar().setCalendar(Calendar.getInstance());
        }
        endDateDialog.setVisible(true);
    }//GEN-LAST:event_endDateButtonActionPerformed

    /**
     * Opens a dialog for selecting the start date.
     *
     * @param evt an action event
     */       
    
    private void startDateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startDateButtonActionPerformed
        try {
            startDateDialog.getCalendar().setCalendar(getStartDate());
        }
        catch(Exception e) {
            startDateDialog.getCalendar().setCalendar(Calendar.getInstance());
        }
        startDateDialog.setVisible(true);
    }//GEN-LAST:event_startDateButtonActionPerformed

    /**
     * Alters the width of the observed time system pop-up menu to match the contents.
     *
     * @param evt a pop-up menu event
     */    
    
    private void observedTSBoxPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_observedTSBoxPopupMenuWillBecomeVisible
        EVSMainWindow.main.setPopupWidth(evt);
    }//GEN-LAST:event_observedTSBoxPopupMenuWillBecomeVisible
    
    /**
     * Alters the width of the forecast time system pop-up menu to match the contents.
     *
     * @param evt a pop-up menu event
     */
    
    private void forecastTSBoxPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_forecastTSBoxPopupMenuWillBecomeVisible
        EVSMainWindow.main.setPopupWidth(evt);
    }//GEN-LAST:event_forecastTSBoxPopupMenuWillBecomeVisible

    /**
     * Forecast directory selected.
     *
     * @param evt an action event
     */    
    
    private void forecastFileButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_forecastFileButtonActionPerformed
        String file = forecastFileField.getText();
        File[] selectMe = null;
        if(file.startsWith("[FILE ARRAY]")) {
            file = file.substring(14,file.length());
            if(unitIsSelected()) {
                if(getSelectedUnit().getForecastData() instanceof FileArrayDataSource) {
                    selectMe = (File[])getSelectedUnit().getForecastData().getData();
                }
            }
        }
        if(selectMe == null) {
            selectMe = new File[]{new File(file)};
        }
        InputFileFilter filter = null;
        try { 
            filter = new InputFileFilter(FileIO.getSupportedForecastFileTypes(false));
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        File[] targetFiles = getTargetFiles(filter,selectMe,EVSFileChooser.FILES_AND_DIRECTORIES,true);
        if(targetFiles != null && targetFiles.length > 0 && targetFiles[0] != null) {
            HashMap<Integer,Object> pars = localData.get(getSelectedUnit());
            if(!targetFiles[0].isDirectory()) {
                FileArrayDataSource source = new FileArrayDataSource(targetFiles);
                forecastFileField.setText(source.toString());
                //Set the files parameter
                pars.put(FORECAST_DATA,source); //Sets the file array
            }
            else {
                FileDataSource source = new FileDataSource(targetFiles[0]);
                forecastFileField.setText(source.toString());
                pars.put(FORECAST_DATA,source);
            }
        }
    }//GEN-LAST:event_forecastFileButtonActionPerformed

    /**
     * Observed file selected.
     *
     * @param evt an action event
     */       
    
    private void observedFileButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_observedFileButtonActionPerformed
        String file = observedFileField.getText();
        InputFileFilter filter = null;
        try { 
            filter = new InputFileFilter(FileIO.getSupportedObservedFileTypes(false));
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        File[] selectMe = new File[]{new File(file)};
        File[] targetFiles = getTargetFiles(filter,selectMe,EVSFileChooser.FILES_ONLY,false);
        if(targetFiles != null && targetFiles.length > 0) {
            observedFileField.setText(targetFiles[0].getAbsolutePath());
        }
    }//GEN-LAST:event_observedFileButtonActionPerformed
 
    /**
     * Alters the width of the temporal resolution pop-up menu to match the contents.
     *
     * @param evt a pop-up menu event
     */    
    
    private void temporalResolutionBoxPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_temporalResolutionBoxPopupMenuWillBecomeVisible
        EVSMainWindow.main.setPopupWidth(evt);
    }//GEN-LAST:event_temporalResolutionBoxPopupMenuWillBecomeVisible
    
    /**
     * Start year selected. 
     *
     * @param evt a mouse event
     */
    
    private void startYearFieldMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_startYearFieldMouseClicked
        if(startYearField.getText().equals("YYYY")) {
            startYearField.setText("");
        }
    }//GEN-LAST:event_startYearFieldMouseClicked
 
    /**
     * End year selected. 
     *
     * @param evt a mouse event
     */
    
    private void endYearFieldMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_endYearFieldMouseClicked
        if(endYearField.getText().equals("YYYY")) {
            endYearField.setText("");
        }
    }//GEN-LAST:event_endYearFieldMouseClicked
    
    /**
     * Variable identifier field selected.
     *
     * @param evt a mouse event
     */
    
    private void variableIDFieldMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_variableIDFieldMouseClicked
        if(evt.getModifiers() == evt.BUTTON3_MASK && variableIDField.isEnabled()) {
            variableMenu.show(variableIDField,evt.getX(),evt.getY());
        }
    }//GEN-LAST:event_variableIDFieldMouseClicked

    /**
     * Streamflow selected as the verification variable.
     * 
     * @param evt an action event
     */
    
    private void streamflowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_streamflowActionPerformed
        variableIDField.setText(evt.getActionCommand());
    }//GEN-LAST:event_streamflowActionPerformed

    /**
     * Temperature selected as the verification variable.
     * 
     * @param evt an action event
     */
    
    private void temperatureActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_temperatureActionPerformed
        variableIDField.setText(evt.getActionCommand());
    }//GEN-LAST:event_temperatureActionPerformed

    /**
     * Precipitation selected as the verification variable.
     * 
     * @param evt an action event
     */
    
    private void precipitationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_precipitationActionPerformed
        variableIDField.setText(evt.getActionCommand());
    }//GEN-LAST:event_precipitationActionPerformed

   
    /** 
     * Verification unit chosen for copying.
     *
     * @param evt an action event
     */
    
    private void copyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_copyButtonActionPerformed
        //Copy the unit and update the selection
        copySelectedUnit();   
    }//GEN-LAST:event_copyButtonActionPerformed

    /** 
     * Verification unit chosen for deletion.
     *
     * @param evt an action event
     */
    
    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        deleteSelectedUnits();
    }//GEN-LAST:event_deleteButtonActionPerformed

    /** 
     * Verification unit added.
     *
     * @param evt an action event
     */
    
    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
//JB @ 17th May 2013
//        saveIndex = unitsTable.getSelectionModel().getAnchorSelectionIndex();
//        saveLocalData();
        addDefaultUnit();
//        int row = unitsTable.getRowCount()-1;
//        unitsTable.setRowSelectionInterval(row,row);
//        saveIndex = row;
//        showLocalData();
    }//GEN-LAST:event_addButtonActionPerformed

    /**
     * Stage selected as the verification variable.
     * 
     * @param evt an action event
     */

private void stageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stageActionPerformed
    variableIDField.setText(evt.getActionCommand());
}//GEN-LAST:event_stageActionPerformed

private void moreButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_moreButton2ActionPerformed
    if(unitIsSelected()) {
        outputOptions.setVerificationUnit(getSelectedUnit());
        EVSMainWindow.setWindowLocation(outputOptions);
        outputOptions.setVisible(true);
    }
}//GEN-LAST:event_moreButton2ActionPerformed

private void outputFolderButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_outputFolderButtonActionPerformed
    String file = outputFolderField.getText();
    File[] selectMe = new File[]{new File(file)};
    File[] targetFiles = getTargetFiles(null,selectMe,EVSFileChooser.DIRECTORIES_ONLY,false);
    if(targetFiles != null && targetFiles.length > 0) {
        outputFolderField.setText(targetFiles[0].getAbsolutePath());
    }
}//GEN-LAST:event_outputFolderButtonActionPerformed

    /**
     * Alters the width of the forecast file type pop-up menu to match the contents.
     *
     * @param evt a pop-up menu event
     */

private void forecastFileTypeBoxPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_forecastFileTypeBoxPopupMenuWillBecomeVisible
    EVSMainWindow.main.setPopupWidth(evt);
}//GEN-LAST:event_forecastFileTypeBoxPopupMenuWillBecomeVisible

    /**
     * Alters the width of the observed file type pop-up menu to match the contents.
     *
     * @param evt a pop-up menu event
     */

private void observedFileTypeBoxPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_observedFileTypeBoxPopupMenuWillBecomeVisible
    EVSMainWindow.main.setPopupWidth(evt);
}//GEN-LAST:event_observedFileTypeBoxPopupMenuWillBecomeVisible

    /**
     * Moves to the next window.
     *
     * @param evt the action event
     */
    
    private void nextButtonActionPerformed(ActionEvent evt) {                                           
        JPanel model = (JPanel)this.getParent();
        ((CardLayout)model.getLayout()).next(model);
    }      
    
    /**
     * Adds a default verification unit to the list of units.  
     */
    
    private void addDefaultUnit() {
        if(unitsTable.getRowCount() > 0 && unitsTable.getValueAt(0,0)==null) {
            ((DefaultTableModel)unitsTable.getModel()).setRowCount(0);
        }
        int defCount = 0;
        Vector<VerificationUnit> units = new Vector(localData.keySet());
        int length = units.size();
        for(int i = 0; i < length; i++) {
            if(units.get(i).toString().startsWith("default_location")) {
                defCount++;
            }
        }
        VerificationUnit v = new VerificationUnit("default_location","default_variable_"+defCount);
        updateLocalData(v); 
        int row = unitsTable.getRowCount()-1;
        unitsTable.setRowSelectionInterval(row,row);
        updateUnitSelection();
    } 

    /**
     * Returns true if a valid location ID and variable ID has been provided for 
     * the selected location, false otherwise.
     *
     * @return true if the verification IDs are valid
     */
    
    private boolean verificationIDsAreSet() {
        return !locationIDField.getText().equals("") && !variableIDField.getText().equals("");
    }
    
    /**
     * Deletes the selected verification unit.
     */
    
    private void deleteSelectedUnits() {
        if(unitIsSelected()) {
            Vector<VerificationUnit> sel = getSelectedVerificationUnits();
            boolean warned = false;
            boolean warned2 = false;
            int len = sel.size();
            int row = unitsTable.getSelectedRow();  //Try to maintain row selection
            
            //Iterate through the selected units
            int n = JOptionPane.NO_OPTION;
            for(int u = 0; u < len; u++) {
                VerificationUnit selected = sel.get(u);
                if(! warned) {
                    n = JOptionPane.showOptionDialog(EVSMainWindow.main,"Delete selected verification unit(s)?","Warning: data deletion", JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
                    if(n==JOptionPane.NO_OPTION) {
                        return;
                    }
                    warned = true;
                }
                if(n == JOptionPane.YES_OPTION) {
                    if(selected.hasUsableAggregationUnit()) {
                        if(!warned2) {
                            int n2 = JOptionPane.showOptionDialog(EVSMainWindow.main,"This will also update or delete aggregation units.  Proceed?","Warning: data deletion", JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
                            if(n2==JOptionPane.NO_OPTION) {
                                return;
                            }
                            warned2 = true;
                        }
                        //Updates or deletes unit
                        //JB @ 11th March 2013
                        ArrayList<AggregationUnit> agg = selected.getAggregationUnits();
                        for(AggregationUnit a : agg) {
                            selected.deleteAndUpdateAggregationUnit(a);
                            AGGREGATION_A.clearLocalData(a);
                        }
                    }
                    //Warn in case other units rely on the selected unit for variable value conditions or 
                    //as a reference forecast in a skill calculation
                    Vector<VerificationUnit> units = new Vector(localData.keySet());
                    int length = units.size();
                    for(int i = 0; i < length; i++) {
                        VerificationUnit next = units.get(i);
                        if(next != selected) {
                            if(next.hasValueConditions(selected.toString())) {
                                int n3 = JOptionPane.showOptionDialog(EVSMainWindow.main,"Unit "+next+" has a parameter that refers to the selected unit.  Continue and delete this dependency?","Warning: data deletion", JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
                                if(n3==JOptionPane.NO_OPTION) {
                                    return;
                                }
                                //Delete the dependency
                                next.deleteValueConditions(selected.toString());
                            }
                            if(next.hasReferenceForecast(selected.toString())) {
                                int n4 = JOptionPane.showOptionDialog(EVSMainWindow.main,"Unit "+next+" uses unit '"+selected+"' as a reference forecast.  Continue and delete associated dependencies?","Warning: data deletion", JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
                                if(n4==JOptionPane.NO_OPTION) {
                                    return;
                                }
                                //Delete the dependency
                                next.deleteReferenceForecast(selected.toString());
                            }
                        }
                    }
                    
                    //Clear parameters
                    clearLocalData(selected);
                    VERIFICATION_B.clearLocalData(selected);
                }
            }
            if(row>=unitsTable.getRowCount()) {
                row = unitsTable.getRowCount()-1;
            }
            if (row > -1 && row < unitsTable.getRowCount()) {
                unitsTable.setRowSelectionInterval(row, row);
            }
            saveIndex = -1; //Important because delete has destroyed previous save index            
            updateUnitSelection();
            //EVSMainWindow.main.updateAndShowLocalData();
        }
    }

    /**
     * Creates a copy of the selected unit with a different name and adds it to the 
     * user interface. 
     */
    
    private void copySelectedUnit() {
        if(unitIsSelected()) {
            saveLocalData(); //Update any info. recently entered
            VerificationUnit newUnit = getSelectedUnit().deepCopy(true);
            //Remove reference to any existing paired data source
            newUnit.deletePairedDataSourceReference();

            //Add an integer ID to the end of the location and time series IDs
            //until a unique one is found.
            for(int i = 0; i < 10000; i++) {  //Finite
                VerificationUnit test = new VerificationUnit(newUnit.getLocationID(),newUnit.getVariableID()+"_"+i);
                if(!localData.containsKey(test)) {
                    newUnit.setVariableID(newUnit.getVariableID()+"_"+i);
                    break;
                }
            }
            //Update the local data with the local data from the current unit
            HashMap<Integer,Object> pars = localData.get(getSelectedUnit());
            HashMap<Integer,Object> copy = new HashMap<Integer,Object>();
            copy.putAll(pars);
            copy.put(VARIABLE_ID,newUnit.getVariableID()); //Set the new variable ID
            updateLocalData(newUnit);  //Adds the unit
            localData.put(newUnit,copy);  //Sets the local pars
            AGGREGATION_A.updateLocalData(AGGREGATION_A.getSelectedUnit());  //Updates the aggregation window
            int row = unitsTable.getRowCount()-1;
            unitsTable.setRowSelectionInterval(row,row);
            updateUnitSelection();    //JB @ 17th May 2013
        }
    }
    
    /**
     * Returns the units table model with a listener that sets the size of the 
     * units table according to the rows added or deleted.
     * 
     * @return a table model for the units table
     */
    
    private DefaultTableModel getUnitsTableModel() {
        return new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Unique identifier"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
            
            public void fireTableRowsDeleted(int firstRow, int lastRow) {
                super.fireTableRowsDeleted(firstRow, lastRow);
                unitsTable.setPreferredSize(new Dimension(75, unitsTable.getRowHeight()
                        * (unitsTable.getRowCount() + 1)));
            }

            public void fireTableRowsInserted(int firstRow, int lastRow) {
                super.fireTableRowsInserted(firstRow, lastRow);
                unitsTable.setPreferredSize(new Dimension(75, unitsTable.getRowHeight()
                        * (unitsTable.getRowCount() + 1)));
            }
            
        };   
    }
    

/********************************************************************************
 *                                                                              *
 *                              INSTANCE VARIABLES                              *
 *                                                                              *
 *******************************************************************************/    
    
    /**
     * The index for saving data.
     */
    
    private int saveIndex = -1;
    
    /**
     * Scale dialog.
     */
    
    private MoreInputDialog moreInputDialog = null;
    
    /**
     * Start date dialog.
     */
    
    private DateSelector startDateDialog = null;
    
    /**
     * Output options dialog.
     */
    
    private MoreOutputOptions outputOptions = null;
    
    /**
     * End date dialog.
     */
    
    private DateSelector endDateDialog = null;
    
    /**
     * Local store of data associated with the verification units.  The data are 
     * stored in a map and indexed by their unique parameter identifiers provided
     * in this class.
     */
    
    private LinkedHashMap<VerificationUnit,HashMap<Integer,Object>> localData =
            new LinkedHashMap<VerificationUnit,HashMap<Integer,Object>>();

    /**
     * Identifiers for local storage of parameters.
     */

    private static final int LOCATION_ID = 201;
    private static final int VARIABLE_ID = 202;
    private static final int ADDITIONAL_ID = 203;
    private static final int FORECAST_DATA = 204;
    private static final int OBSERVED_DATA = 205;
    private static final int FORECAST_TIME_SYS = 206;
    private static final int OBSERVED_TIME_SYS = 207;
    private static final int START_YEAR = 208;
    private static final int START_MONTH = 209;
    private static final int START_DAY = 210;
    private static final int FIRST_LEAD_TIME = 211;
    private static final int LAST_LEAD_TIME = 212;
    private static final int LEAD_UNITS = 213;
    private static final int END_YEAR = 214;
    private static final int END_MONTH = 215;
    private static final int END_DAY = 216;
    private static final int AGG_RES = 217;
    private static final int AGG_RES_UNITS = 218;
    private static final int OUTPUT_DATA = 219;
    private static final int FORECAST_FILE_TYPE = 220;
    private static final int OBSERVED_FILE_TYPE = 221;

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JTextField additionalIDField;
    private javax.swing.JLabel additionalIDLabel;
    private javax.swing.JLabel blankIDLabel;
    private javax.swing.JButton copyButton;
    private javax.swing.JButton deleteButton;
    private javax.swing.JButton endDateButton;
    private javax.swing.JLabel endDateLabel;
    private javax.swing.JComboBox endDayBox;
    private javax.swing.JComboBox endMonthBox;
    private javax.swing.JTextField endYearField;
    private javax.swing.JTextField firstLeadField;
    private javax.swing.JLabel firstLeadLabel;
    private javax.swing.JButton forecastFileButton;
    private javax.swing.JTextField forecastFileField;
    private javax.swing.JLabel forecastFileLabel;
    private javax.swing.JComboBox forecastFileTypeBox;
    private javax.swing.JLabel forecastFileTypeLabel;
    private javax.swing.JComboBox forecastLeadBox;
    private javax.swing.JComboBox forecastTSBox;
    private javax.swing.JLabel forecastTSLabel;
    private javax.swing.JScrollPane identifierScrollPane;
    private javax.swing.JPanel identifiersPanel;
    private javax.swing.JScrollPane inputScrollPane;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel100;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel1413;
    private javax.swing.JPanel jPanel1414;
    private javax.swing.JPanel jPanel1415;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel41;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel46;
    private javax.swing.JPanel jPanel47;
    private javax.swing.JPanel jPanel48;
    private javax.swing.JPanel jPanel49;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel50;
    private javax.swing.JPanel jPanel51;
    private javax.swing.JPanel jPanel52;
    private javax.swing.JPanel jPanel53;
    private javax.swing.JPanel jPanel54;
    private javax.swing.JPanel jPanel55;
    private javax.swing.JPanel jPanel56;
    private javax.swing.JPanel jPanel57;
    private javax.swing.JPanel jPanel58;
    private javax.swing.JPanel jPanel59;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel60;
    private javax.swing.JPanel jPanel61;
    private javax.swing.JPanel jPanel62;
    private javax.swing.JPanel jPanel63;
    private javax.swing.JPanel jPanel64;
    private javax.swing.JPanel jPanel65;
    private javax.swing.JPanel jPanel66;
    private javax.swing.JPanel jPanel67;
    private javax.swing.JPanel jPanel68;
    private javax.swing.JPanel jPanel69;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel70;
    private javax.swing.JPanel jPanel71;
    private javax.swing.JPanel jPanel72;
    private javax.swing.JPanel jPanel73;
    private javax.swing.JPanel jPanel74;
    private javax.swing.JPanel jPanel75;
    private javax.swing.JPanel jPanel76;
    private javax.swing.JPanel jPanel77;
    private javax.swing.JPanel jPanel78;
    private javax.swing.JPanel jPanel79;
    private javax.swing.JPanel jPanel80;
    private javax.swing.JPanel jPanel81;
    private javax.swing.JPanel jPanel82;
    private javax.swing.JPanel jPanel83;
    private javax.swing.JPanel jPanel84;
    private javax.swing.JPanel jPanel85;
    private javax.swing.JPanel jPanel86;
    private javax.swing.JPanel jPanel87;
    private javax.swing.JPanel jPanel88;
    private javax.swing.JPanel jPanel89;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPanel jPanel90;
    private javax.swing.JPanel jPanel91;
    private javax.swing.JPanel jPanel92;
    private javax.swing.JPanel jPanel93;
    private javax.swing.JPanel jPanel94;
    private javax.swing.JPanel jPanel95;
    private javax.swing.JPanel jPanel96;
    private javax.swing.JPanel jPanel97;
    private javax.swing.JPanel jPanel98;
    private javax.swing.JPanel jPanel99;
    private javax.swing.JTextField lastLeadField;
    private javax.swing.JLabel lastLeadLabel;
    private javax.swing.JPanel leftPanel;
    private javax.swing.JTextField locationIDField;
    private javax.swing.JLabel locationIDLabel;
    private javax.swing.JButton moreButton;
    private javax.swing.JButton moreButton1;
    private javax.swing.JButton moreButton2;
    private javax.swing.JButton nextButton;
    private javax.swing.JButton observedFileButton;
    private javax.swing.JTextField observedFileField;
    private javax.swing.JLabel observedFileLabel;
    private javax.swing.JComboBox observedFileTypeBox;
    private javax.swing.JLabel observedFileTypeLabel;
    private javax.swing.JComboBox observedTSBox;
    private javax.swing.JLabel observedTSLabel;
    private javax.swing.JButton outputFolderButton;
    private javax.swing.JTextField outputFolderField;
    private javax.swing.JLabel outputFolderLabel;
    private javax.swing.JPanel outputPanel;
    private javax.swing.JScrollPane outputScrollPane;
    private javax.swing.JMenuItem precipitation;
    private javax.swing.JPanel rightPanel;
    private javax.swing.JScrollPane scrollPane;
    private javax.swing.JPanel seperator1;
    private javax.swing.JPanel seperator2;
    private javax.swing.JPanel seperator3;
    private javax.swing.JPanel sourceDataPanel;
    private javax.swing.JSplitPane splitPane;
    private javax.swing.JMenuItem stage;
    private javax.swing.JButton startDateButton;
    private javax.swing.JLabel startDateLabel;
    private javax.swing.JComboBox startDayBox;
    private javax.swing.JComboBox startMonthBox;
    private javax.swing.JTextField startYearField;
    private javax.swing.JMenuItem streamflow;
    private javax.swing.JMenuItem temperature;
    private javax.swing.JComboBox temporalResolutionBox;
    private javax.swing.JTextField temporalResolutionField;
    private javax.swing.JScrollPane temporalScrollPane;
    private javax.swing.JPanel timePanel;
    private javax.swing.JTable unitsTable;
    private javax.swing.JTextField variableIDField;
    private javax.swing.JLabel variableIDLabel;
    private javax.swing.JPopupMenu variableMenu;
    private javax.swing.JLabel verificationTimestepLabel;
    // End of variables declaration//GEN-END:variables

}