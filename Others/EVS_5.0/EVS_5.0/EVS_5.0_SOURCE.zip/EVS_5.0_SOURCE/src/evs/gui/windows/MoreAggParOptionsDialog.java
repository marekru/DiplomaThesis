package evs.gui.windows;

//Java swing dependencies
import javax.swing.*;
import javax.swing.event.*;
//Java awt dependencies
import java.awt.*;
import java.awt.event.*;

//Java util dependencies
import java.util.*;

//EVS dependencies
import evs.analysisunits.*;
import evs.gui.utilities.*;
import evs.utilities.mathutil.*;

/**
 * Constructs a dialog of parameter options for an Aggregation Unit.  This is
 * currently a simple editor that allows direct editing of parameter values.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public final class MoreAggParOptionsDialog extends SimpleDialog implements GUICommunicator {
    
/*******************************************************************************
 *                                                                             *
 *                               CONSTRUCTORS                                  *
 *                                                                             *
 ******************************************************************************/  

    /**
     * Construct an options dialog.
     *
     * @param modal is true to set the dialog modal
     */
    
    protected MoreAggParOptionsDialog(boolean modal) {
        super(modal);
        setProperties(); 
        //setSize(750,550);
    }
    
/*******************************************************************************
 *                                                                             *
 *                              PROTECTED METHODS                              *
 *                                                                             *
 ******************************************************************************/                  
    
    /**
     * Sets the current parameter values with an input Aggregation Unit.
     * 
     * @param aggUnit the aggregation unit
     */
    
    protected void setParOptions(AggregationUnit aggUnit) {
        if(aggUnit!=null) {
            String name = "Options for " + aggUnit;
            if (name.length() > 100) {
                name = name.substring(0, 100) + "...";
            }
            setTitle(name);

            //Display the current parameter values
            poolPairsBox.setSelected(aggUnit.isPoolPairs());
            bootstrapBox.setSelected(aggUnit.isBootstrap()); 
            dependentBox.setSelected(aggUnit.isStatDependent()); 
            dependentBox.setEnabled(aggUnit.isBootstrap());
            this.aggUnit = aggUnit;
        }
    }
    
    /**
     * Override the superclass method.
     *
     * @param exitStatus the exit status
     */

    @Override
    protected void close(int exitStatus) {
        switch(exitStatus) {
            case OK_EXIT: {
                if(bootstrapBox.isSelected()&& !poolPairsBox.isSelected()) {
                    throw new IllegalArgumentException("Cannot bootstrap aggregated metrics by averaging " +
                            "the individual metrics: pairs must be pooled from the component verification units.");
                }
                if(aggUnit!=null) {
                    aggUnit.setPoolPairs(poolPairsBox.isSelected());
                    aggUnit.setBootstrap(bootstrapBox.isSelected());
                    aggUnit.setStatDependent(dependentBox.isSelected());
                }
            }; break;
        }
        //Sensibility checks complete: allow close
        aggUnit = null; //Always reset the local pointers on exit
        super.close(exitStatus);
    }    
    
    /**
     * Sets the properties of the dialog.
     */

    @Override
    protected void setProperties() {
        JPanel main = new JPanel();
        poolPairsBox = new JCheckBox();
        dependentBox = new JCheckBox();
        bootstrapBox = new JCheckBox();
        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));

        //Pool pairs
        poolPairsBox.setFont(new Font("Verdana", 0, 11));
        poolPairsBox.setText("Pool pairs (will ignore weight parameters).");
//        poolPairsBox.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
//        poolPairsBox.setMargin(new Insets(1, 1, 1, 1));
        poolPairsBox.setMaximumSize(new Dimension(32000, 30));
        poolPairsBox.setMinimumSize(new Dimension(400, 30));
        poolPairsBox.setPreferredSize(new Dimension(32000, 30));
        main.add(poolPairsBox); 
         
         //Bootstrap
        bootstrapBox.setFont(new Font("Verdana", 0, 11));
        bootstrapBox.setText("Compute confidence intervals (if bootstrap set for component units).");
//        bootstrapBox.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
//        bootstrapBox.setMargin(new Insets(1, 1, 1, 1));
        bootstrapBox.setMaximumSize(new Dimension(32000, 30));
        bootstrapBox.setMinimumSize(new Dimension(400, 30));
        bootstrapBox.setPreferredSize(new Dimension(32000, 30));
        
        ItemListener itemListener = new ItemListener() {
            public void itemStateChanged(ItemEvent itemEvent) {
                AbstractButton abstractButton =
                        (AbstractButton) itemEvent.getSource();
                ButtonModel buttonModel = abstractButton.getModel();
                boolean selected = buttonModel.isSelected();
                dependentBox.setEnabled(selected);
                if (!selected) {
                    dependentBox.setSelected(false);
                }
            }
        };   
        bootstrapBox.addItemListener(itemListener);  
        
        main.add(bootstrapBox);   
        
        //Dependent pairs
        dependentBox.setFont(new Font("Verdana", 0, 11));
        dependentBox.setText("Verification units are statistically dependent in space (for confidence intervals).");
//        dependentBox.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
//        dependentBox.setMargin(new Insets(1, 1, 1, 1));
        dependentBox.setMaximumSize(new Dimension(32000, 30));
        dependentBox.setMinimumSize(new Dimension(400, 30));
        dependentBox.setPreferredSize(new Dimension(32000, 30));
        main.add(dependentBox);      
        
        addMainPanel(main);
    }
    
    /*******************************************************************************
     *                                                                             *
     *                              INSTANCE VARIABLES                             *
     *                                                                             *
     ******************************************************************************/

    /**
     * The aggregation unit for editing.
     */

    private AggregationUnit aggUnit = null;

    /**
     * Check box for pooling pairs rather than weighing metrics.
     */
    
    private JCheckBox poolPairsBox;
    
    /**
     * Check box for identifying the VUs within an AU as statistically dependent.
     */
    
    private JCheckBox dependentBox;
    
    /**
     * Check box for identifying whether aggregation metrics should be bootstrapped
     * if verification metrics contain bootstrap parameters.
     */
    
    private JCheckBox bootstrapBox;

}
