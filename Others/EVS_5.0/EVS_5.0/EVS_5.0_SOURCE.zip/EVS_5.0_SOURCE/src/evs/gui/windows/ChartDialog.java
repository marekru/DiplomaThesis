package evs.gui.windows;

//Java swing dependencies
import javax.swing.JTabbedPane;

//Java awt dependencies
import java.awt.Dimension;

//Java util dependencies
import java.util.Timer;
import java.util.TimerTask;

//JFreeChart dependencies
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;

/**
 * Constructs a dialog for displaying an org.jfree.chart.JFreeChart.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ChartDialog extends SimpleDialog implements GUICommunicator {
    
    /*******************************************************************************
     *                                                                             *
     *                              INSTANCE VARIABLES                             *
     *                                                                             *
     ******************************************************************************/

    /**
     * The charts.
     */
    
    private JFreeChart[] chart = null;

    /**
     * Tabbed pane containing multiple charts.
     */
    
    private JTabbedPane tabbed = null;
    
/*******************************************************************************
 *                                                                             *
 *                               CONSTRUCTORS                                  *
 *                                                                             *
 ******************************************************************************/  
    
    /**
     * Construct an empty chart dialog with a title.
     *
     * @param title the dialog title
     */
    
    protected ChartDialog(String title) {
        super(title);
        setProperties(); 
    }      
    
    /**
     * Construct a chart dialog.
     *
     * @param title the dialog title
     * @param chart the chart
     */
    
    protected ChartDialog(String title,JFreeChart chart) {
        super(title);
        this.chart = new JFreeChart[]{chart};
        setProperties(); 
    }    

/*******************************************************************************
 *                                                                             *
 *                              PROTECTED METHODS                              *
 *                                                                             *
 ******************************************************************************/                  

    /**
     * Sets the properties of the dialog.
     */
    
    protected void setProperties() {
        setCancelVisible(false);
        setOKButtonName("Close");
        setMaximumSize(new Dimension(32000, 32000));
        setPreferredSize(new Dimension(800, 600));
        if(chart != null) { 
            ChartPanel main = new ChartPanel(chart[0]);
            main.setMaximumSize(getMaximumSize());
            main.setMinimumSize(getMinimumSize());
            main.setPreferredSize(getPreferredSize());
            addMainPanel(main);   
        } 
        pack();
    }
    
    /**
     * Adds a chart to a tabbed pane.
     * 
     * @param tabName the tab name to display
     * @param chart the new chart
     */
    
    protected void addChart(String tabName, JFreeChart chart) {
        if(tabbed == null) {
            tabbed = new JTabbedPane();
            //Add the first chart if it exists
            if(this.chart != null) {
                ChartPanel first = new ChartPanel(this.chart[0]);
                tabbed.addTab(this.chart[0].getTitle().getText(),first);
            }
        }
        setCancelVisible(true);
        //Use the redundant cancel button for animation
        setCancelButtonName("Animate");
        ChartPanel next = new ChartPanel(chart);
        next.setMaximumSize(getMaximumSize());
        next.setPreferredSize(getPreferredSize());
        tabbed.addTab(tabName,next);
        removeMainPanel();
        addMainPanel(tabbed);    
    }    
    
    /**
     * Overrides an action on the "cancel" button, which is used here for
     * animation of a chart window with multiple charts, and is labeled "Animate".
     * The cancel button in the superclass calls the close method. Override the
     * close method here to perform animation if the exit status is CANCELLED_EXIT
     * indicating that the cancel (animate) button was activated.
     *
     * @param exitStatus the exit status
     */
    
    protected void close(int exitStatus) {
        //Cancel button now animate button
        if(exitStatus == CANCELLED_EXIT) {
            if(tabbed != null && tabbed.getTabCount()>1) {
                final int count = tabbed.getTabCount();
                final Timer t = new Timer();
                TimerTask task = new TimerTask() {
                    public void run() {
                        int index = tabbed.getSelectedIndex();
                        //Animate until end
                        if((index+1)<count) {
                            tabbed.setSelectedIndex(index+1);
                        }
                        else {
                            tabbed.setSelectedIndex(0);
                            t.cancel();
                        }
                    }
                };
                t.scheduleAtFixedRate(task,0,300);
            }
        }
        else {
            super.close(exitStatus);
        }
    }    
    
    /*******************************************************************************
     *                                                                             *
     *                                 TEST METHOD                                 *
     *                                                                             *
     ******************************************************************************/    
    
    /**
     * Main method.
     *
     * @param args the arguments
     */
    
    public static void main(String[] args) {
        JFreeChart ch = evs.products.plots.defaults.ChartFactory.getDefaultChart(evs.metric.metrics.Metric.SPREAD_BIAS_DIAGRAM,null);
        evs.metric.results.DoubleMatrix2DResult m = new evs.metric.results.DoubleMatrix2DResult(new evs.utilities.matrix.DenseDoubleMatrix2D(new double[][]{{0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0},{0.25,0.36,0.45,0.45,0.76,0.78,0.89,0.95,0.99,0.995}}));
        evs.products.plots.defaults.EVSPlot plot = (evs.products.plots.defaults.EVSPlot)ch.getPlot();
        plot.addDataset("Test",m);
        ChartDialog chD = new ChartDialog("Test chart dialog",ch);
        chD.setVisible(true);
    }

}
