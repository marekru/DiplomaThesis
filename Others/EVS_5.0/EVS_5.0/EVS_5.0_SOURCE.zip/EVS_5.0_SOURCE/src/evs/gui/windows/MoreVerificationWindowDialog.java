package evs.gui.windows;

import evs.data.DateElement;
import evs.data.DateCondition;
import evs.data.ValueCondition;
import evs.gui.utilities.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*;
import javax.swing.border.*;

//Java awt dependencies
import java.awt.*;
import java.awt.event.*;

//Java util depdendencies
import java.util.*;
import java.util.List; //Avoid ambiguity with awt List

//EVS dependencies
import evs.data.fileio.*;
import evs.analysisunits.*;
import evs.utilities.mathutil.*;

/**
 * Dialog for refining the verification window based on date and variable value.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class MoreVerificationWindowDialog extends JDialog implements GUIInterface, GUICommunicator {
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Construct the dialog with a parent frame.
     */
    
    protected MoreVerificationWindowDialog() {
        super();
        initComponents();
        //Construct the functions
        setFunctionsForDisplay();
        setTitle("Refine verification window");
        //Set the cell renderer to differentiate between data types in the unit table
        unitTable.setDefaultRenderer(Object.class,new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                if(column == 1 && value instanceof String) {
                    if((value+"").equalsIgnoreCase("Forecast")) {
                        super.setForeground(Color.blue);
                    } else if((value+"").equalsIgnoreCase("Observed")) {
                        super.setForeground(Color.red);
                    }
                } else {
                    super.setForeground(Color.black);
                }
                return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }
        });
        categoryTable.setDefaultRenderer(Object.class,new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                if(column == 1 && value instanceof String) {
                    if((value+"").startsWith("V")) {  //Valid time
                        super.setForeground(Color.blue);
                    } else if((value+"").startsWith("B")) {  //Basis/issue time
                        super.setForeground(Color.red);
                    }
                } else {
                    //Hide valid time/basis time description from DateElement#toString();
                    if(column == 0 && value instanceof DateElement) {
                        String v = value.toString();
                        if(v.contains("(")) {
                            value = v.substring(0,v.indexOf("(")-1); 
                        } 
                    }
                    super.setForeground(Color.black);
                }
                return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }
        });        
         //Add a listener to the date categories table for the current verification unit
        categoryTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent evt) {
                if(! evt.getValueIsAdjusting()) {
                    showLocalData();
                }
                //No need to save local data as the edits are performed directly on the table
            }
        });   
        //Add a listener to the verification unit table
        unitTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent evt) {
                int index = unitTable.getSelectedRow();
                if(evt.getValueIsAdjusting()) {
                    saveLocalData();
                    varValIndex = index;
                }
                else {
                    showLocalData();
                }
            }
        });    
        //Set the time units in the variable value conditions
        timeUnits = GlobalUnitsReader.getTimeUnits();
        timeUnits.add(0,"NONE");

        dataStatBox.addItemListener(new ItemListener(){
            public void itemStateChanged(ItemEvent e) {
                if(e.getStateChange()==e.SELECTED) {
                    saveLocalData();
                    //Clear data if selection changed to "NONE"
                    if("NONE".equals(dataStatBox.getSelectedItem())) {
                        String id = VERIFICATION_A.getSelectedUnit()+"";
                        TreeMap map = varValParsMap.get(id);
                        int sel = unitTable.getSelectedRow();
                        if(sel > -1) {
                            String id2 = ""+unitTable.getValueAt(sel,0)+VerificationUnit.getIDSepChar()+unitTable.getValueAt(sel,1);
                            map.put(id2,new String[]{"NONE","","","","","","","","",""});
                        }
                    }
                    //Update the editable value conditions once a valid statistic is selected
                    setValueConditionsEnabled(true);
                }
            }            
        }); 
        windowUnitsBox.addItemListener(new ItemListener(){
            public void itemStateChanged(ItemEvent e) {
                if(e.getStateChange()==e.SELECTED) {
                    saveLocalData();
                }
            }            
        });
        
        String[] funcs =  FunctionLibrary.getSupportedAggregationFunctions();
        for(int i = 0; i < funcs.length; i++) {
            aggStatBox.addItem(funcs[i].toUpperCase());
        }
                
    };    
    
    
    
    
/********************************************************************************
 *                                                                              *
 *                           INHERITED PUBLIC METHODS                           *
 *                                                                              *
 *******************************************************************************/     
     
    /**
     * Closes any open dialogs or frames associated with the GUI window.
     */
     
    public void disposeOfChildren() {
        //No dialogs or frames to close
    }    
    
    /**
     * Saves any existing conditions to the selected verification unit.
     *
     * @return true if the data were saved
     */
    
    public boolean saveData() {
        saveLocalData();  //Update any new selections
        VerificationUnit ver = VERIFICATION_A.getSelectedUnit();
        
        //Save any date conditions
        if(!ver.hasDates()) {
            ver.setDates(VERIFICATION_A.getStartDate(),VERIFICATION_A.getEndDate());
        }
        DateCondition resetDate = ver.getDateCondition();
        ver.deleteDateCondition();
        if(hasLocalDateCondition(ver)) {
            try {
                ver.setDateCondition(getLocalDateCondition(ver));
            } catch(IllegalArgumentException e) {
                //Clean-up
                if(resetDate!=null) {
                    ver.setDateCondition(resetDate);
                }
                throw e;
            }
        }
        //Save any value conditions
        Vector<ValueCondition> resetValue = ver.getValueConditions();
        ver.deleteAllValueConditions();
        if(hasLocalValueConditions(ver)) {
            try {
                Vector<ValueCondition> conditions = getLocalValueConditions(ver);
                ver.setValueConditions(conditions);
            } catch (IllegalArgumentException e) {
                //Clean-up
                if(resetValue!=null) {
                    ver.deleteAllValueConditions();
                    ver.setValueConditions(resetValue);
                }
                throw e;
            }
        }
        //Save the temporal aggregation function
        ver.setTemporalAggFunc(FunctionLibrary.getVectorFunction(aggStatBox.getSelectedItem()+""));

        //Save the sample size constraint
        String sample = sampleSizeField.getText();
        try {
            ver.setSampleSizeConstraint(new Double(sample));
        }
        catch(NumberFormatException e) {
            throw new IllegalArgumentException("Enter a valid numeric fraction [0,1] for the sample size constraint: "+sample+" is not allowed.");
        }
        //Save the aggregation start hour
        String aggHour = aggregationStartField.getText();
        if (aggHour != null && !aggHour.equals("")) {
            try {
                ver.setAggregationStartHourUTC(new Integer(aggHour));
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Enter a valid numeric hour in UTC [0,23] for the aggregation start time: " + aggHour + " is not allowed.");
            }
        } else {
        	ver.setAggregationStartHourUTC(null);
        }
        //Save the aggregation start hour
        String aggLeadHour = aggregationStartLeadField.getText();
        if (aggLeadHour != null && !aggLeadHour.equals("")) {
            try {
                ver.setAggregationStartLeadHour(new Double(aggLeadHour));
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Enter a valid numeric forecast lead hour from which to begin aggregation: " + aggLeadHour + " is not allowed.");
            }
        } else {
        	ver.setAggregationStartLeadHour(null);
        }
        
        //Refresh VERIFICATION_B, which has parameters for value conditions
        VERIFICATION_B.updateLocalData(VERIFICATION_A.getSelectedUnit());
        return true;
    }    

     /**
      * Saves the local data currently displayed to an object array, stored with 
      * the unique identifier of the selected dataset. 
      */
     
     public void saveLocalData() {
         if(saveLocalData) {  //Save local data?
             //Local data associated with date conditions is stored automatically
             //in the table models, which are found in the dateMap map.
             //Save local data associated with variable value conditions
             String func = "NONE";
             int statIndex = dataStatBox.getSelectedIndex();
             
             //Save data
             if(varValIndex>-1) {
                 String[] data = new String[]{"","","","","","","","",""};
                 if(statIndex > 0) {  //Otherwise -1 or "NONE" is selected
                     String test = unitTable.getValueAt(varValIndex,1)+"";
                     if(test.equals("Forecast")) {
                         func = forecastFunctions[1][statIndex].toString();
                     } else if(test.equals("Observed")) {
                         func = observedFunctions[1][statIndex].toString();
                     }
                 }
                 if(!func.equals("NONE")) {
                     data[0] = func;
                     data[1] = windowField.getText();
                     if(windowUnitsBox.getSelectedIndex() > -1) {
                         data[2] = windowUnitsBox.getSelectedItem()+"";
                     }
                     data[3] = lessThanField.getText();
                     data[4] = lessThanEqualField.getText();
                     data[5] = greaterThanField.getText();
                     data[6] = greaterThanEqualField.getText();
                     Object item = windowStatBox.getSelectedItem();
                     if(item!=null && !item.equals("NONE")) {
                         data[7] = windowStatistics[1][windowStatBox.getSelectedIndex()].toString();
                     }
                     data[8] = conditionField.getText();
                     String id = unitTable.getValueAt(varValIndex,0)+""+VerificationUnit.getIDSepChar()+unitTable.getValueAt(varValIndex,1);
                     String currentUnit = VERIFICATION_A.getSelectedUnit()+"";
                     if(varValParsMap.containsKey(currentUnit)) {
                         TreeMap map = varValParsMap.get(currentUnit);
                         map.put(id,data);
                     }
                 }
             }
             Iterator it = varValParsMap.keySet().iterator();
             while(it.hasNext()) {
                 TreeMap map = (TreeMap)varValParsMap.get(it.next());
                 Iterator it2 = map.keySet().iterator();
                 while(it2.hasNext()) {
                     Object next = it2.next();
                     String[] n = (String[])map.get(next);
                 }
             }
             aggIndex = aggStatBox.getSelectedIndex();
             sampleFraction = sampleSizeField.getText();
             aggStartHour = aggregationStartField.getText();
             aggStartLeadHour = aggregationStartLeadField.getText();
         }
     }

    /**
     * Displays the local data previously saved to a temporary store.  Local data 
     * should always be displayed in preference to saved data, because saved data 
     * should be used to update the store of local data once available.
     */
     
     public void showLocalData() {
         saveLocalData = false;  //Disable inadvertent saving through updating of components with listeners
         //Identify the current selection
         int sel = unitTable.getSelectedRow();
         int index = categoryTable.getSelectedRow();
         //Show the date conditions
         VerificationUnit current = VERIFICATION_A.getSelectedUnit();
         if(current != null && index > -1) {
             DateElement disp = (DateElement)categoryTable.getValueAt(index,0);
             DefaultTableModel mod = dateMap.get(disp);
             //Get the array of table models for the current unit
             catElementTable.setModel(mod);
             //Update table size
             catElementTable.setPreferredSize(new Dimension(450, (catElementTable.getRowCount()+1)*25));
         }
         //Clear table
         else {
             catElementTable.setModel(new DefaultTableModel(null,new String[]{"Date element","Include?"}));
         }
         catElementTable.getColumnModel().getColumn(0).setPreferredWidth(5000);
         catElementTable.getColumnModel().getColumn(1).setPreferredWidth(1600);
         
         if(current!=null) {
             //Set the temporal aggregation function
             aggStatBox.setSelectedIndex(aggIndex);
             sampleSizeField.setText(sampleFraction);
             if(aggStartHour!=null) {
                 aggregationStartField.setText(aggStartHour);
             }
             if(aggStartLeadHour!=null) {
                 aggregationStartLeadField.setText(aggStartLeadHour);
             }
         }
         //Show the variable value conditions
         if(varValParsMap.size() > 0) {
             
             //Display other parameters if previously defined
             TreeMap parsMap = varValParsMap.get(VERIFICATION_A.getSelectedUnit().toString());
             String id = "";
             if(sel > -1) {
                 id = unitTable.getValueAt(sel,0)+""+VerificationUnit.getIDSepChar()+unitTable.getValueAt(sel,1);
                 //Show the available statistics
                 if("Forecast".equals(unitTable.getValueAt(sel,1))) {
                     dataStatBox.setModel(new DefaultComboBoxModel(forecastFunctions[0]));
                 } else {
                     dataStatBox.setModel(new DefaultComboBoxModel(observedFunctions[0]));
                 }
                 windowStatBox.setModel(new DefaultComboBoxModel(windowStatistics[0]));
                 windowUnitsBox.setModel(new DefaultComboBoxModel(timeUnits));
             }
             //Show existing data if it exists
             if(sel > -1 && parsMap != null && parsMap.containsKey(id)) {
                 
                 String[] data = (String[])parsMap.get(id);
                 
                 //Show the statistic
                 //Locate the statistic
                 if(unitTable.getValueAt(sel,1).equals("Forecast")) {
                     for(int i = 0; i < forecastFunctions[0].length; i++) {
                         if(forecastFunctions[1][i] != null && forecastFunctions[1][i].toString().equals(data[0])) {
                             dataStatBox.setSelectedItem(forecastFunctions[0][i]); break;
                         }
                     }
                 } else if(unitTable.getValueAt(sel,1).equals("Observed")) {
                     for(int i = 0; i < observedFunctions[0].length; i++) {
                         if(observedFunctions[1][i] != null && observedFunctions[1][i].toString().equals(data[0])) {
                             dataStatBox.setSelectedItem(observedFunctions[0][i]); break;
                         }
                     }
                 }

                 //Show the period, if any
                 windowField.setText(data[1]);
                 windowUnitsBox.setSelectedItem(data[2]);
                 windowStatBox.setSelectedItem(data[7].toUpperCase());
                 
                 //Show the logical conditions, if any
                 lessThanField.setText(data[3]);
                 lessThanEqualField.setText(data[4]);
                 greaterThanField.setText(data[5]);
                 greaterThanEqualField.setText(data[6]);
                 lessThanButton.setSelected(!data[3].equals(""));
                 lessThanEqualButton.setSelected(!data[4].equals(""));
                 greaterThanButton.setSelected(!data[5].equals(""));
                 greaterThanEqualButton.setSelected(!data[6].equals(""));
                 
                 //Probability or inverse probability function
                 String item = dataStatBox.getSelectedItem().toString();
                 boolean enable = item.startsWith("PROBABILITY")||item.startsWith("VALUE FOR");
                 if(enable) {
                     conditionField.setText(data[8]);
                 } else {
                     conditionField.setText("");
                 }
             }
         }
         setValueConditionsEnabled(sel > -1);
         saveLocalData = true;  //Allow saving 
     }
     
    /**
     * Updates local data with a saved AnalysisUnit.  In this case the update
     * is based on the data stored locally in the VERIFICATION_A window from
     * which this dialog is accessed.
     *
     * @param unit the unit
     */
     
     public void updateLocalData(AnalysisUnit unit) {
         if(unit instanceof VerificationUnit) {
             Calendar start = VERIFICATION_A.getStartDate();
             Calendar end = VERIFICATION_A.getEndDate();
             Vector<VerificationUnit> units = VERIFICATION_A.getVerificationUnits();
             //Reset the date conditions if the selected verification unit has changed
             VerificationUnit vu = (VerificationUnit)unit;
             prepLocalDateConditions(vu,start,end);
             prepLocalValueConditions(vu,units);
             lastUnits.put(unit.toString(),vu);
             if(vu.getTemporalAggFunc()!= null) {
                 String f = vu.getTemporalAggFunc().toString().toLowerCase();
                 String[] af = FunctionLibrary.getSupportedAggregationFunctions();
                 List s = Arrays.asList(af);
                 aggIndex = s.indexOf(f);
             }
             sampleFraction = vu.getSampleSizeConstraint()+"";
             if(vu.hasAggregationStartHourUTC()) {
                aggStartHour = vu.getAggregationStartHourUTC()+"";
             }
             if(vu.hasAggregationStartLeadHour()) {
                aggStartLeadHour = vu.getAggregationStartLeadHour()+"";
             }
             showLocalData();
         }
     }
    
    /**
     * Removes local data from the temporary store for a specified AnalysisUnit. 
     *
     * @param unit the unit
     */
    
    public void clearLocalData(AnalysisUnit unit) {
        lastDates.remove(unit.toString());
        lastUnits.remove(unit.toString());
        varValParsMap.remove(unit.toString());
        dateMap.clear();
        aggIndex = -1;
        sampleFraction = null;
        aggStartHour = null;
        aggStartLeadHour = null;
    }     
    
    /**
     * Clears all local data and resets the window to its original state on
     * construction.
     */
    
    public void clearAllLocalData() {
        lastDates.clear();
        lastUnits.clear();
        varValParsMap.clear();
        dateMap.clear();
        aggIndex = -1;
        sampleFraction = null;
        aggStartHour = null;
        aggStartLeadHour = null;
    }       

    /********************************************************************************
     *                                                                              *
     *                               PRIVATE METHODS                                *
     *                                                                              *
     *******************************************************************************/
    
    /**
     * Returns true if a specified unit has some specific conditions associated with
     * it, false otherwise.
     *
     * @param unit the verification unit
     * @return true if conditions are set
     */
    
    private boolean hasConditions(VerificationUnit unit) {
        return hasLocalDateCondition(unit) || hasLocalValueConditions(unit);
    }
    
    /**
     * Returns true if a specified unit has some date conditions associated with
     * it, false otherwise.
     *
     * @param unit the verification unit
     * @return true if date conditions are set
     */
    
    private boolean hasLocalDateCondition(VerificationUnit unit) {
        return getLocalDateCondition(unit)!=null;
    }    
    
    /**
     * Returns true if a specified unit has some variable value conditions associated 
     * with it, false otherwise.
     *
     * @param unit the verification unit
     * @return true if date conditions are set
     */
    
    private boolean hasLocalValueConditions(VerificationUnit unit) {
        return varValParsMap.containsKey(unit.toString());
    }
    
    /**
     * Returns a date condition.
     * 
     * @param unit the verification unit   
     * @return the date elements not included
     */
    
    private DateCondition getLocalDateCondition(VerificationUnit unit) throws IllegalArgumentException {
        DateCondition returnMe = null;
        Iterator i = dateMap.keySet().iterator();
        while(i.hasNext()) {
            DateElement key = (DateElement)i.next();
            DefaultTableModel nextMod = dateMap.get(key);    
            Vector<Integer> conds = new Vector<Integer>();
            int length = nextMod.getRowCount();
            for(int j = 0; j < length; j++) {
                if(nextMod.getValueAt(j,1).equals(false)) {
                    conds.add(j);
                }
            }
            if(conds.size()>0) {
                if(returnMe == null) {
                    returnMe = new DateCondition(unit,key,conds);
                } else {
                    returnMe.setCondition(key,conds);
                }
            }
        }
        return returnMe;
    }
    
    /**
     * Returns a set of value conditions for the named unit.
     * 
     * @param unit the verification unit   
     * @return the value conditions
     */
    
    private Vector<ValueCondition> getLocalValueConditions(VerificationUnit unit) throws IllegalArgumentException {     
        Vector<VerificationUnit> units = VERIFICATION_A.getVerificationUnits();        
        Vector<ValueCondition> conditions = new Vector();
        if(varValParsMap.containsKey(unit.toString())) {
            TreeMap pars = varValParsMap.get(unit.toString());
            //Iterate through the value conditions
            Iterator it = pars.keySet().iterator();
            while(it.hasNext()) {
                Object name = it.next();
                
                VerificationUnit appliesTo = null;
                int tot = units.size();
                for(int i = 0; i < tot; i++) {
                    String test = (""+name).substring(0,(""+name).lastIndexOf(unit.getIDSepChar()));
                    VerificationUnit next = units.get(i);
                    if(test.equals(next.toString())) {
                        appliesTo = next;
                    }
                }
                String[] d1 = (String[])pars.get(name);
                if(d1 != null && ! d1[0].equals("NONE")) {
                    int type = ValueCondition.FORECAST_CONDITION;
                    Object[][] funcs = forecastFunctions;
                    if(name.toString().endsWith("Observed")) {
                        type = ValueCondition.OBSERVED_CONDITION;
                        funcs = observedFunctions;
                    }
                    //Construct the data statistic
                    Function stat = (Function)funcs[1][getStatIndex(d1[0],type==ValueCondition.FORECAST_CONDITION)];
                    //Data statistic employs a threshold
                    if (d1[8] != null && !d1[8].equals("")) {
                        try {
                            stat = FunctionLibrary.getVectorFunction(stat.toString(), new Double(d1[8]));
                        } catch (NumberFormatException f) {
                            f.printStackTrace();
                            throw new IllegalArgumentException("Enter a valid numeric threshold for statistic '" + stat + "'.");
                        }
                    }

                    //Construct the window if required
                    Double period = null;
                    String periodUnit = null;
                    VectorFunction windowStat = null;
                    if(!d1[1].equals("")) {
                        if(d1[7]==null || d1[7].equals("") || d1[7].equals("NONE")) {
                            throw new IllegalArgumentException("One or more conditions comprise a time window for which the 'statistic for time window' has not been defined.");
                        }
                        period = new Double(d1[1]);
                        periodUnit = d1[2];
                        //Throw an exception if threshold input is null.
                        try {
                            windowStat = FunctionLibrary.getVectorFunction(d1[7]);
                        } catch (Exception e) {
                            e.printStackTrace();
                            throw new IllegalArgumentException("Could not construct statistic for time window.");
                        }
                    }

                    Vector<DoubleProcedure> log = new Vector();
                    String proc = d1[3]+d1[4]+d1[5]+d1[6];
                    if(!proc.equals("")) {
                        try {
                            if(!d1[3].equals("")) {
                                log.add(FunctionLibrary.isLess(new Double(d1[3])));
                            }
                            if(!d1[4].equals("")) {
                                log.add(FunctionLibrary.isLessEqual(new Double(d1[4])));
                            }
                            if(!d1[5].equals("")) {
                                log.add(FunctionLibrary.isGreater(new Double(d1[5])));
                            }
                            if(!d1[6].equals("")) {
                                log.add(FunctionLibrary.isGreaterEqual(new Double(d1[6])));
                            }
                        } catch(NumberFormatException e) {
                            throw new IllegalArgumentException("Enter a valid number for each logical condition associated with unit '"+unit+"'.");
                        }
                    }
                    ValueCondition cond  = new ValueCondition(appliesTo,type,stat,
                            log.toArray(new DoubleProcedure[log.size()]),period,periodUnit,windowStat);
                    //Construct the condition and apply it to the parent
                    conditions.add(cond);
                }
            }
        }
        return conditions;
    }        
    
    /**
     * Returns the column index of the specified statistic in the observed or forecast
     * statistic array.  The name should correspond to the result of toString()
     * on the statistic (an instance of Function).
     *
     * @param stat the statistic name
     * @param isForecast is true to search the forecast array, false to search the observed array 
     * @return the column index or -1
     */
    
    private int getStatIndex(String stat, boolean isForecast) {
        int index = -1;
        if(stat != null) {
            Object[] searchMe = observedFunctions[1];
            if(isForecast) {
                searchMe = forecastFunctions[1];
            }
            for(int i = 0; i < searchMe.length; i++) {
                if(searchMe[i] != null && stat.equals(searchMe[i].toString())) {
                    index = i; break;
                }
            }
        }
        return index;
    }
    
    /**
     * Prepares the variable value conditions by adding all possible conditions
     * from the specified verification units.  An observed condition and a forecast
     * condition is added for each input verification unit.  
     *
     * @param current the current verification unit
     * @param units the verification units
     */
    
    private void prepLocalValueConditions(VerificationUnit current, Vector<VerificationUnit> units) {
        if(units == null || units.size() == 0) {
            throw new IllegalArgumentException("No verification units defined.");
        }
        unitTable.clearSelection();
        varValParsMap.clear();
        lastUnits.clear();
        //Establish whether different from last initialization
        int length = units.size();
        boolean go = false;
        if(units.size() != unitTable.getRowCount()) {
            go = true;
        } else {
            for(int i = 0; i < length; i++) {
                if(!units.get(i).toString().equals(unitTable.getValueAt(i,0)+"")) {
                    go = true;
                }
            }
        }
        //Continue (different from last initialization)
        if(go) {
            int tot = units.size();
            Vector data = new Vector();
            TreeMap map = new TreeMap();
            for(int i = 0; i < tot; i++) {
                //Can a value condition be applied using the given unit as a parameter?
                if(ValueCondition.canApplyWithRespectTo(current,units.get(i))) {
                    //Yes it can, so add a dataset for the observations and forecasts
                    Vector nextRow = new Vector();
                    Vector nextRow2 = new Vector();
                    nextRow.add(units.get(i));
                    nextRow.add("Forecast");
                    nextRow2.add(units.get(i));
                    nextRow2.add("Observed");
                    data.add(nextRow);
                    data.add(nextRow2);
                    //Add the default parameter values
                    String forc = units.get(i).toString()+VerificationUnit.getIDSepChar()+"Forecast";
                    String obs = units.get(i).toString()+VerificationUnit.getIDSepChar()+"Observed";
                    //No statistics selected by default
                    map.put(forc,new String[]{"NONE","","","","","","","",""});
                    map.put(obs,new String[]{"NONE","","","","","","","",""});
                }
            }
            varValParsMap.put(current.toString(),map);
            Vector names = new Vector();
            names.add("Identifier");
            names.add("Type");
            DefaultTableModel unitModel = new DefaultTableModel(data,names) {
                public Class getColumnClass(int columnIndex) {
                    if(columnIndex==0) {
                        return VerificationUnit.class;
                    }
                    return String.class;
                }
                public boolean isCellEditable(int rowIndex, int columnIndex) {
                    return false;
                }
            };
            unitTable.setModel(unitModel);
            unitTable.setRowHeight(25);
            unitTable.getColumnModel().getColumn(0).setPreferredWidth(5000);
            unitTable.getColumnModel().getColumn(1).setPreferredWidth(1600);
            unitTable.setPreferredSize(new Dimension(450,(unitTable.getRowCount()+1)*25));
        }
        //Sets the variable value conditions associated with the current verification unit, if any exist
        if(current.hasValueConditions()) {       
            Vector<ValueCondition> cond = current.getValueConditions();
            TreeMap localData = new TreeMap();
            int length2 = cond.size();
            for(int i = 0; i < length2; i++) {
                ValueCondition c = cond.get(i);
                String[] vals = new String[]{"","","","","","","","",""};
                //Method name of the specified statistic
                vals[0] = c.getDataStatistic().toString();
                boolean forecastType = c.getConditionType()==c.FORECAST_CONDITION;
                if(forecastType) {
                    vals[0] = forecastFunctions[1][getStatIndex(vals[0],forecastType)]+"";
                    //Value of constant for probability/inverse probability function
                    if((c.getDataStatistic() instanceof VectorFunction) &&
                            ((VectorFunction)c.getDataStatistic()).getConstants()!=null) {
                        vals[8]=((VectorFunction)c.getDataStatistic()).getConstants()[0]+"";
                    }
                }
                else {
                    vals[0] = observedFunctions[1][getStatIndex(vals[0],forecastType)]+"";
                }
                if(c.hasTimeWindow()) {
                    vals[1] = c.getTimeWindow().toString();
                    vals[2]= c.getTimeWindowUnits();
                    vals[7]= c.getWindowStatistic().toString().toUpperCase();
                }
                //Set the logical conditions
                DoubleProcedure[] proc = c.getLogicalConditions();
                for (int j = 0; j < proc.length; j++) {
                    if (proc[j] != null) {
                        //Less than condition defined
                        if (proc[j].toString().equals("isLess")) {
                            vals[3] = proc[j].getConstants()[0] + "";
                        } //Less than or equal to condition defined
                        else if (proc[j].toString().equals("isLessEqual")) {
                            vals[4] = proc[j].getConstants()[0] + "";
                        } //Greater than condition defined
                        else if (proc[j].toString().equals("isGreater")) {
                            vals[5] = proc[j].getConstants()[0] + "";
                        } //Greater than or equal to condition defined
                        else if (proc[j].toString().equals("isGreaterEqual")) {
                            vals[6] = proc[j].getConstants()[0] + "";
                        }
                    }
                }
                String type = "Observed";
                if(forecastType) {
                    type = "Forecast";
                }
                String id = c.getVerificationUnitID()+current.getIDSepChar()+type;
                localData.put(id,vals);
            }
            if(localData.size() > 0) {
                varValParsMap.put(current.toString(),localData);
            }
        }        
    }
    
    /**
     * Prepares the date conditions table by adding all required components.
     * 
     * @param unit the verification unit
     * @param start the verification start time
     * @param end the verification end time
     */
    
    private void prepLocalDateConditions(VerificationUnit unit, Calendar start, Calendar end) throws IllegalArgumentException {    
        categoryTable.clearSelection();
        dateMap.clear();
        lastDates.clear();
        //Set the date category table
        Vector<DateElement> dateCats = new Vector<DateElement>();
        
        //Only set the category element tables if the current unit has changed or the unit was not previously defined
        boolean go = false;
        //Unit not previously defined
        if(!lastDates.containsKey(unit.toString())) {
            go = true;
        }
        else {
            Calendar[] dates = lastDates.get(unit.toString());
            //Dates changed
            if(dates[0] != null) {
                go = !dates[0].equals(start);
            } else {
                go = start != null;
            }
            //Only check remaining conditions if !go
            if(!go) {
                if(dates[1] != null) {
                    go = !dates[1].equals(end);
                } else {
                    go = end != null;
                }
            }
        }
        //Continue
        if(go) {            
            //Set the years if the input dates are not null
            Vector<Object[][]> rows = new Vector();
            //Only allow refinement if period is available
            
            if(start != null && end != null) {
                if(end.getTimeInMillis() <= start.getTimeInMillis()) {
                    throw new IllegalArgumentException("Cannot refine unit: end date must be later than start date.");
                }
                
                //CALENDAR ELEMENTS WITH VALID TIME FIRST THEN BASIS TIME
                
                //Years
                int startY = start.get(start.YEAR);
                int endY = end.get(end.YEAR);
                int yrs = endY-startY;
                
                if(yrs>1) {
                    DateElement yearVT = new DateElement(Calendar.YEAR,true);
                    dateCats.add(yearVT);
                    Object[][] yearsVT = new Object[endY-startY+1][2];
                    for(int i = 0; i < yearsVT.length; i++) {
                        yearsVT[i][0] = startY+i;
                        yearsVT[i][1] = true;
                    }
                    rows.add(yearsVT);
                }
                //Months of year
                int startM = start.get(start.MONTH);
                int endM = end.get(end.MONTH);
                int months = endM-startM;
                if(yrs >= 1 || months > 1) {
                    DateElement monthVT = new DateElement(Calendar.MONTH,true);
                    dateCats.add(monthVT);
                    rows.add(new Object[][] {
                        {"January",true},
                        {"February",true},
                        {"March",true},
                        {"April",true},
                        {"May",true},
                        {"June",true},
                        {"July",true},
                        {"August",true},
                        {"September",true},
                        {"October",true},
                        {"November",true},
                        {"December",true},
                    });   
                }
                //Weeks of year
                int startW = start.get(start.WEEK_OF_YEAR);
                int endW = end.get(end.WEEK_OF_YEAR);
                int wks = endW - startW;
                if(yrs >= 1 || months >= 1 || wks > 1) {
                    DateElement weekVT = new DateElement(Calendar.WEEK_OF_YEAR,true);
                    dateCats.add(weekVT);   
                    Object[][] weeksVT = new Object[53][2];   //JB @ 21st November 2012
                    for(int i = 0; i < weeksVT.length; i++) {
                        weeksVT[i][0] = i+1;
                        weeksVT[i][1] = true;
                    }
                    rows.add(weeksVT);
                }
                //Days of week
                int startD = start.get(start.DAY_OF_YEAR);
                int endD = end.get(end.DAY_OF_YEAR);
                int days = endD - startD;
                if(yrs >= 1 || months >= 1 || wks >= 1 || days > 1) {
                    DateElement daysVT = new DateElement(Calendar.DAY_OF_WEEK,true);
                    dateCats.add(daysVT);                    
                    rows.add(new Object[][] {
                        {"Monday",true},
                        {"Tuesday",true}, 
                        {"Wednesday",true},
                        {"Thursday",true},
                        {"Friday",true},
                        {"Saturday",true},
                        {"Sunday",true},
                    });     
                }
                //Hours of day (UTC)
                if(yrs >= 1 || months >= 1 || wks >= 1 || days >= 1) {
                    DateElement hourVT = new DateElement(Calendar.HOUR_OF_DAY,true);
                    dateCats.add(hourVT);  
                    Object[][] hoursVT = new Object[24][2];
                    for(int i = 0;i < 24; i++) {
                        hoursVT[i][0]=i+"";
                        hoursVT[i][1]=true;
                    }
                    rows.add(hoursVT);                  
                }

                //BASIS TIME
                
                //Years
                if(yrs>1) {
                    DateElement yearIT = new DateElement(Calendar.YEAR,false);
                    dateCats.add(yearIT);
                    Object[][] yearsIT = new Object[endY-startY+1][2];
                    for(int i = 0; i < yearsIT.length; i++) {
                        yearsIT[i][0] = startY+i;
                        yearsIT[i][1] = true;
                    }
                    rows.add(yearsIT);
                }
                //Months of year
                if(yrs >= 1 || months > 1) {
                    DateElement monthIT = new DateElement(Calendar.MONTH,false);
                    dateCats.add(monthIT);
                    rows.add(new Object[][] {
                        {"January",true},
                        {"February",true},
                        {"March",true},
                        {"April",true},
                        {"May",true},
                        {"June",true},
                        {"July",true},
                        {"August",true},
                        {"September",true},
                        {"October",true},
                        {"November",true},
                        {"December",true},
                    });     
                }
                //Weeks of year
                if(yrs >= 1 || months >= 1 || wks > 1) {
                    DateElement weekIT = new DateElement(Calendar.WEEK_OF_YEAR,false);
                    dateCats.add(weekIT);   
                    Object[][] weeksIT = new Object[52][2];
                    for(int i = 0; i < weeksIT.length; i++) {
                        weeksIT[i][0] = i+1;
                        weeksIT[i][1] = true;
                    }
                    rows.add(weeksIT);
                }
                //Days of week
                if(yrs >= 1 || months >= 1 || wks >= 1 || days > 1) {
                    DateElement daysIT = new DateElement(Calendar.DAY_OF_WEEK,false);
                    dateCats.add(daysIT);                    
                    rows.add(new Object[][] {
                        {"Monday",true},
                        {"Tuesday",true}, 
                        {"Wednesday",true},
                        {"Thursday",true},
                        {"Friday",true},
                        {"Saturday",true},
                        {"Sunday",true},
                    });      
                }
                //Hours of day (UTC)
                if(yrs >= 1 || months >= 1 || wks >= 1 || days >= 1) {
                    DateElement hourIT = new DateElement(Calendar.HOUR_OF_DAY,false);
                    dateCats.add(hourIT);  
                    Object[][] hoursIT = new Object[24][2];
                    for(int i = 0;i < 24; i++) {
                        hoursIT[i][0]=i+"";
                        hoursIT[i][1]=true;
                    }
                    rows.add(hoursIT);                    
                }                
                
            }
            //Add the non null records
            int tot = rows.size();
            if(tot>0) {
                //Set the category table model
                Object[][] dates = new Object[dateCats.size()][2];
                for(int i = 0; i < tot; i++) {
                    dates[i][0] = dateCats.get(i);
                    if(dateCats.get(i).isValidTime()) {
                        dates[i][1] = "Valid time";
                    } else {
                        dates[i][1] = "Basis/issue time";
                    }
                }
                catModel = new DefaultTableModel(dates,new String[]{"Date category", "Time system"}) {
                    public Class getColumnClass(int columnIndex) {
                        return String.class;
                    }
                    public boolean isCellEditable(int rowIndex, int columnIndex) {
                        return false;
                    }
                };
                categoryTable.setModel(catModel);
                int length = rows.size();
                //Add the tables to the store
                for(int i = 0; i < length; i++) {
                    DefaultTableModel mod = new DefaultTableModel(rows.get(i),new String[]{"Date element","Include?"}) {
                        Class[] types = new Class [] {
                            String.class, Boolean.class
                        };
                        public Class getColumnClass(int columnIndex) {
                            return types[columnIndex];
                        }
                        public boolean isCellEditable(int rowIndex, int columnIndex) {
                            return columnIndex==1;
                        }
                    };
                    dateMap.put(dateCats.get(i),mod);
                }               
                
                //Set the initial units selection to none
                setValueConditionsEnabled(false);
                categoryTable.setRowSelectionInterval(0,0);
                //Edit the table properties
                categoryTable.setRowHeight(25);
                categoryTable.setPreferredSize(new Dimension(450,(categoryTable.getRowCount()+1)*25));
                catElementTable.setRowHeight(25);
            }
            lastUnits.put(unit.toString(),unit);
            lastDates.put(unit.toString(),new Calendar[]{start,end});
        }
        
        //Sets the date conditions associated with the current verification unit, if any exist
        if(unit.hasDateCondition()) {
            DateCondition d = unit.getDateCondition();
            TreeMap<DateElement,Vector<Integer>> c = d.getConditions();
            Iterator it = c.keySet().iterator();
            while(it.hasNext()) {
                DateElement n = (DateElement)it.next();
                if(dateMap.containsKey(n)) {
                    DefaultTableModel mod = dateMap.get(n);
                    Vector<Integer> rows = d.getCondition(n);
                    int count = rows.size();
                    //Rows that should not be checked
                    //The presence of a row indicates exclusion
                    for (int j = 0; j < count; j++) {
                        mod.setValueAt(false, rows.get(j), 1);
                    }
                }
            }
            //No need to showLocalData() as the data are stored as table models
        }        
    }
    
    /**
     * Sets the possible functions of a selected dataset for display.  Records
     * the display name of each statistic alongside the statistic itself.
     */
    
    private void setFunctionsForDisplay() {
        observedFunctions = new Object[2][2];
        observedFunctions[0][0] = "NONE";
        observedFunctions[1][0] = null;
        observedFunctions[0][1] = "OBSERVED VALUE";
        observedFunctions[1][1] = FunctionLibrary.getUnaryFunction("assign");

        forecastFunctions = new Object[2][10];
        forecastFunctions[0][0] = "NONE";
        forecastFunctions[1][0] = null;
        forecastFunctions[0][1] = "ENSEMBLE MEAN";
        forecastFunctions[1][1] = FunctionLibrary.getVectorFunction("mean");
        forecastFunctions[0][2] = "ENSEMBLE MEDIAN";
        forecastFunctions[1][2] = FunctionLibrary.getVectorFunction("median");
        forecastFunctions[0][3] = "ENSEMBLE MODE";
        forecastFunctions[1][3] = FunctionLibrary.getVectorFunction("mode");
        forecastFunctions[0][4] = "MINIMUM ENSEMBLE MEMBER";
        forecastFunctions[1][4] = FunctionLibrary.getVectorFunction("minimum");
        forecastFunctions[0][5] = "MAXIMUM ENSEMBLE MEMBER";
        forecastFunctions[1][5] = FunctionLibrary.getVectorFunction("maximum");
        forecastFunctions[0][6] = "RANGE OF ENSEMBLE MEMBERS";
        forecastFunctions[1][6] = FunctionLibrary.getVectorFunction("range");
        forecastFunctions[0][7] = "STANDARD DEVIATION OF ENSEMBLE MEMBERS";
        forecastFunctions[1][7] = FunctionLibrary.getVectorFunction("stdev");
        forecastFunctions[0][8] = "PROBABILITY OF NOT EXCEEDING VALUE (SPECIFY VALUE)";
        forecastFunctions[1][8] = FunctionLibrary.probabilityForValue(0.0);  //Construct with default
        forecastFunctions[0][9] = "VALUE FOR NON-EXCEEDENCE PROBABILITY (SPECIFY PROBABILITY)";
        forecastFunctions[1][9] = FunctionLibrary.valueForProbability(0.0);  //Construct with default

        windowStatistics = new Object[2][7];
        windowStatistics[0][0] = "NONE";
        windowStatistics[1][0] = null;
        windowStatistics[0][1] = "MEAN";
        windowStatistics[1][1] = FunctionLibrary.getVectorFunction("mean");
        windowStatistics[0][2] = "MEDIAN";
        windowStatistics[1][2] = FunctionLibrary.getVectorFunction("median");
        windowStatistics[0][3] = "MODE";
        windowStatistics[1][3] = FunctionLibrary.getVectorFunction("mode");
        windowStatistics[0][4] = "MINIMUM";
        windowStatistics[1][4] = FunctionLibrary.getVectorFunction("minimum");
        windowStatistics[0][5] = "MAXIMUM";
        windowStatistics[1][5] = FunctionLibrary.getVectorFunction("maximum");
        windowStatistics[0][6] = "RANGE";
        windowStatistics[1][6] = FunctionLibrary.getVectorFunction("range");
    }
    
    /**
     * Changes the enabled status of the condition window. If enabled is true
     * the window title and statistic box will always be enabled.  In addition,
     * if a valid statistic is selected, the remaining elements will be enabled.
     * If enabled is false, no elements will be enabled. 
     *
     * @param enabled is true to enable the window, false to disable
     */
    
    private void setValueConditionsEnabled(boolean enabled) {
        //The parameters window title and forecast statistic box/label
        //are always enabled if enabled is true
        int sel = unitTable.getSelectedRow();
        dataStatBox.setEnabled(enabled && sel > -1);
        functionLabel.setEnabled(dataStatBox.isEnabled());
        if(enabled) {
            ((TitledBorder)conditionsPanel.getBorder()).setTitleColor(Color.black);
        }
        else {
            ((TitledBorder)conditionsPanel.getBorder()).setTitleColor(new Color(157,154,118));
            dataStatBox.setModel(new DefaultComboBoxModel());
        }
        //Do not enable the other elements until a valid statistic is selected
        //I.E. the remaining elements are only enabled if enabled is true AND
        //a valid statistic is selected        
        if(dataStatBox.getSelectedIndex() < 0 || dataStatBox.getSelectedItem().equals("NONE")) {
            enabled = false;
        }
        
        //Single unit status
        lessThanButton.setEnabled(enabled);
        lessThanEqualButton.setEnabled(enabled);
        greaterThanButton.setEnabled(enabled);
        greaterThanEqualButton.setEnabled(enabled);
        lessThanField.setEnabled(enabled && lessThanButton.isSelected());
        lessThanEqualField.setEnabled(enabled && lessThanEqualButton.isSelected());
        greaterThanField.setEnabled(enabled && greaterThanButton.isSelected());
        greaterThanEqualField.setEnabled(enabled && greaterThanEqualButton.isSelected());
        selectedUnitLabel.setEnabled(enabled);
        windowField.setEnabled(enabled);
        windowUnitsBox.setEnabled(enabled);
        windowStatBox.setEnabled(enabled);
        windowStatLabel.setEnabled(enabled);
        timeLabel.setEnabled(enabled);
        String item = dataStatBox.getSelectedItem()+"";
        boolean vC = item.startsWith("PROBABILITY")||item.startsWith("VALUE FOR");
        conditionField.setEnabled(vC);
        thresholdLabel.setEnabled(vC);
        if(!vC) {
            conditionField.setText("");
        }
        if(!enabled) {
            //Set text color and text parameter boxes
            lessThanButton.setSelected(true);
            lessThanEqualButton.setSelected(false);
            greaterThanButton.setSelected(false);
            greaterThanEqualButton.setSelected(false);
            lessThanField.setText("");
            lessThanEqualField.setText("");
            greaterThanField.setText("");
            greaterThanEqualField.setText("");
            windowField.setText("");
            windowUnitsBox.setSelectedIndex(-1);
            windowStatBox.setSelectedIndex(-1);
        }
        //Return focus to only combo-box always showing
        if(enabled) {
            dataStatBox.requestFocusInWindow();
        }
        else {
            unitTable.requestFocusInWindow();
        }
        repaint();
    }

    /**
     * Initializes the window components.
     */
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        selectMenu = new javax.swing.JPopupMenu();
        selectAll = new javax.swing.JMenuItem();
        selectNone = new javax.swing.JMenuItem();
        toggleSelection = new javax.swing.JMenuItem();
        buttonGroup1 = new javax.swing.ButtonGroup();
        mainTabbedPane = new javax.swing.JTabbedPane();
        datePanel = new javax.swing.JPanel();
        jPanel511 = new javax.swing.JPanel();
        jSplitPane1 = new javax.swing.JSplitPane();
        jPanel17 = new javax.swing.JPanel();
        jScrollPane131 = new javax.swing.JScrollPane();
        categoryTable = new javax.swing.JTable();
        jPanel613 = new javax.swing.JPanel();
        jScrollPane13 = new javax.swing.JScrollPane();
        catElementTable = new javax.swing.JTable();
        jPanel13 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        moreButton1 = new javax.swing.JButton();
        jPanel14122 = new javax.swing.JPanel();
        resetDatesButton = new javax.swing.JButton();
        jPanel14126 = new javax.swing.JPanel();
        deleteDatesButton = new javax.swing.JButton();
        jPanel20 = new javax.swing.JPanel();
        cancelButton1 = new javax.swing.JButton();
        jPanel14121 = new javax.swing.JPanel();
        nextButton = new javax.swing.JButton();
        jPanel141212 = new javax.swing.JPanel();
        okButton1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        variablePanel = new javax.swing.JPanel();
        jPanel512 = new javax.swing.JPanel();
        jSplitPane2 = new javax.swing.JSplitPane();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane132 = new javax.swing.JScrollPane();
        unitTable = new ToolTipTable();
        conditionsPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel14 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        functionLabel = new javax.swing.JLabel();
        jPanel34 = new javax.swing.JPanel();
        thresholdLabel = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        dataStatBox = new javax.swing.JComboBox();
        jPanel23 = new javax.swing.JPanel();
        conditionField = new javax.swing.JTextField();
        timeLabel = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        windowField = new javax.swing.JTextField();
        jPanel16 = new javax.swing.JPanel();
        windowUnitsBox = new javax.swing.JComboBox();
        windowStatLabel = new javax.swing.JLabel();
        jPanel28 = new javax.swing.JPanel();
        windowStatBox = new javax.swing.JComboBox();
        jPanel32 = new javax.swing.JPanel();
        jPanel33 = new javax.swing.JPanel();
        selectedUnitLabel = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        lessThanButton = new javax.swing.JRadioButton();
        jPanel18 = new javax.swing.JPanel();
        lessThanField = new javax.swing.JTextField();
        jPanel26 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        lessThanEqualButton = new javax.swing.JRadioButton();
        jPanel19 = new javax.swing.JPanel();
        lessThanEqualField = new javax.swing.JTextField();
        jPanel25 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        greaterThanButton = new javax.swing.JRadioButton();
        jPanel21 = new javax.swing.JPanel();
        greaterThanField = new javax.swing.JTextField();
        jPanel27 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        greaterThanEqualButton = new javax.swing.JRadioButton();
        jPanel22 = new javax.swing.JPanel();
        greaterThanEqualField = new javax.swing.JTextField();
        jPanel43 = new javax.swing.JPanel();
        jPanel53 = new javax.swing.JPanel();
        jPanel45 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        moreButton2 = new javax.swing.JButton();
        jPanel14123 = new javax.swing.JPanel();
        resetValuesButton = new javax.swing.JButton();
        jPanel14125 = new javax.swing.JPanel();
        deleteValuesButton = new javax.swing.JButton();
        jPanel202 = new javax.swing.JPanel();
        cancelButton2 = new javax.swing.JButton();
        jPanel14124 = new javax.swing.JPanel();
        backButton = new javax.swing.JButton();
        jPanel141214 = new javax.swing.JPanel();
        nextButton1 = new javax.swing.JButton();
        jPanel141211 = new javax.swing.JPanel();
        okButton2 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        otherPanel = new javax.swing.JPanel();
        jPanel513 = new javax.swing.JPanel();
        optionsInsertPanel = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel29 = new javax.swing.JPanel();
        tempAggFuncLabel = new javax.swing.JLabel();
        jPanel30 = new javax.swing.JPanel();
        aggStatBox = new javax.swing.JComboBox();
        jPanel31 = new javax.swing.JPanel();
        sampleSizeLabel = new javax.swing.JLabel();
        jPanel35 = new javax.swing.JPanel();
        sampleSizeField = new javax.swing.JTextField();
        jPanel36 = new javax.swing.JPanel();
        aggStartLabel = new javax.swing.JLabel();
        jPanel37 = new javax.swing.JPanel();
        aggregationStartField = new javax.swing.JTextField();
        jPanel38 = new javax.swing.JPanel();
        aggStartLeadLabel = new javax.swing.JLabel();
        jPanel39 = new javax.swing.JPanel();
        aggregationStartLeadField = new javax.swing.JTextField();
        jPanel40 = new javax.swing.JPanel();
        jPanel48 = new javax.swing.JPanel();
        jPanel54 = new javax.swing.JPanel();
        jPanel49 = new javax.swing.JPanel();
        jPanel203 = new javax.swing.JPanel();
        cancelButton3 = new javax.swing.JButton();
        jPanel14129 = new javax.swing.JPanel();
        backButton1 = new javax.swing.JButton();
        jPanel141213 = new javax.swing.JPanel();
        okButton3 = new javax.swing.JButton();
        jPanel51 = new javax.swing.JPanel();

        selectAll.setText("Select all");
        selectAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectAllActionPerformed(evt);
            }
        });
        selectMenu.add(selectAll);

        selectNone.setText("Select none");
        selectNone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectNoneActionPerformed(evt);
            }
        });
        selectMenu.add(selectNone);

        toggleSelection.setText("Toggle selection");
        toggleSelection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toggleSelectionActionPerformed(evt);
            }
        });
        selectMenu.add(toggleSelection);

        setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                closeDialog(evt);
            }
        });
        getContentPane().setLayout(new java.awt.GridLayout(1, 0));

        mainTabbedPane.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        mainTabbedPane.setMaximumSize(new java.awt.Dimension(750, 500));
        mainTabbedPane.setMinimumSize(new java.awt.Dimension(750, 500));
        mainTabbedPane.setPreferredSize(new java.awt.Dimension(750, 500));

        datePanel.setMaximumSize(new java.awt.Dimension(2147483647, 2147483647));
        datePanel.setMinimumSize(new java.awt.Dimension(500, 60));
        datePanel.setPreferredSize(new java.awt.Dimension(500, 65));
        datePanel.setLayout(new javax.swing.BoxLayout(datePanel, javax.swing.BoxLayout.Y_AXIS));

        jPanel511.setMaximumSize(new java.awt.Dimension(32000, 5));
        jPanel511.setMinimumSize(new java.awt.Dimension(500, 5));
        jPanel511.setPreferredSize(new java.awt.Dimension(500, 5));
        datePanel.add(jPanel511);

        jSplitPane1.setResizeWeight(0.1);
        jSplitPane1.setMaximumSize(new java.awt.Dimension(2147363747, 2147363747));
        jSplitPane1.setMinimumSize(new java.awt.Dimension(10000000, 0));
        jSplitPane1.setPreferredSize(new java.awt.Dimension(32000, 2000));

        jPanel17.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Select a category to refine", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11), new java.awt.Color(0, 0, 0))); // NOI18N
        jPanel17.setMinimumSize(new java.awt.Dimension(120, 47));
        jPanel17.setPreferredSize(new java.awt.Dimension(300, 34));
        jPanel17.setLayout(new java.awt.GridLayout(1, 0));

        jScrollPane131.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane131.setPreferredSize(new java.awt.Dimension(450, 450));

        categoryTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Date category"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        categoryTable.setInheritsPopupMenu(true);
        categoryTable.setPreferredSize(new java.awt.Dimension(75, 400));
        categoryTable.setRequestFocusEnabled(false);
        jScrollPane131.setViewportView(categoryTable);

        jPanel17.add(jScrollPane131);

        jSplitPane1.setLeftComponent(jPanel17);

        jPanel613.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Refine selected category", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11), new java.awt.Color(0, 0, 0))); // NOI18N
        jPanel613.setMaximumSize(new java.awt.Dimension(32779, 32794));
        jPanel613.setMinimumSize(new java.awt.Dimension(250, 47));
        jPanel613.setPreferredSize(new java.awt.Dimension(60, 34));
        jPanel613.setLayout(new javax.swing.BoxLayout(jPanel613, javax.swing.BoxLayout.Y_AXIS));

        jScrollPane13.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane13.setPreferredSize(new java.awt.Dimension(450, 450));

        catElementTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Date element", "Include?"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        catElementTable.setPreferredSize(new java.awt.Dimension(225, 500));
        catElementTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                catElementTableMousePressed(evt);
            }
        });
        jScrollPane13.setViewportView(catElementTable);

        jPanel613.add(jScrollPane13);

        jSplitPane1.setRightComponent(jPanel613);

        datePanel.add(jSplitPane1);

        jPanel13.setMaximumSize(new java.awt.Dimension(65676, 35));
        jPanel13.setMinimumSize(new java.awt.Dimension(150, 30));
        jPanel13.setPreferredSize(new java.awt.Dimension(300, 35));
        jPanel13.setLayout(new javax.swing.BoxLayout(jPanel13, javax.swing.BoxLayout.Y_AXIS));

        jPanel1.setMaximumSize(new java.awt.Dimension(32000, 2));
        jPanel1.setMinimumSize(new java.awt.Dimension(500, 2));
        jPanel1.setPreferredSize(new java.awt.Dimension(500, 2));
        jPanel13.add(jPanel1);

        jPanel15.setMaximumSize(new java.awt.Dimension(32899, 35));
        jPanel15.setMinimumSize(new java.awt.Dimension(142, 30));
        jPanel15.setPreferredSize(new java.awt.Dimension(144, 35));
        jPanel15.setLayout(new javax.swing.BoxLayout(jPanel15, javax.swing.BoxLayout.LINE_AXIS));

        jPanel4.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel4.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel4.setPreferredSize(new java.awt.Dimension(2, 10));
        jPanel15.add(jPanel4);

        moreButton1.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        moreButton1.setText("More");
        moreButton1.setEnabled(false);
        moreButton1.setMargin(new java.awt.Insets(2, 10, 2, 10));
        moreButton1.setMaximumSize(new java.awt.Dimension(65, 29));
        moreButton1.setMinimumSize(new java.awt.Dimension(65, 29));
        moreButton1.setPreferredSize(new java.awt.Dimension(65, 29));
        moreButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                moreButton1ActionPerformed(evt);
            }
        });
        jPanel15.add(moreButton1);

        jPanel14122.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel14122.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel14122.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel15.add(jPanel14122);

        resetDatesButton.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        resetDatesButton.setText("Reset");
        resetDatesButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        resetDatesButton.setMaximumSize(new java.awt.Dimension(65, 29));
        resetDatesButton.setMinimumSize(new java.awt.Dimension(65, 29));
        resetDatesButton.setPreferredSize(new java.awt.Dimension(65, 29));
        resetDatesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetDatesButtonActionPerformed(evt);
            }
        });
        jPanel15.add(resetDatesButton);

        jPanel14126.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel14126.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel14126.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel15.add(jPanel14126);

        deleteDatesButton.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        deleteDatesButton.setText("Delete");
        deleteDatesButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        deleteDatesButton.setMaximumSize(new java.awt.Dimension(65, 29));
        deleteDatesButton.setMinimumSize(new java.awt.Dimension(65, 29));
        deleteDatesButton.setPreferredSize(new java.awt.Dimension(65, 29));
        deleteDatesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteDatesButtonActionPerformed(evt);
            }
        });
        jPanel15.add(deleteDatesButton);

        jPanel20.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel15.add(jPanel20);

        cancelButton1.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        cancelButton1.setText("Cancel");
        cancelButton1.setMargin(new java.awt.Insets(2, 10, 2, 10));
        cancelButton1.setMaximumSize(new java.awt.Dimension(65, 29));
        cancelButton1.setMinimumSize(new java.awt.Dimension(65, 29));
        cancelButton1.setPreferredSize(new java.awt.Dimension(65, 29));
        cancelButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButton1ActionPerformed(evt);
            }
        });
        jPanel15.add(cancelButton1);

        jPanel14121.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel14121.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel14121.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel15.add(jPanel14121);

        nextButton.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        nextButton.setText("Next");
        nextButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        nextButton.setMaximumSize(new java.awt.Dimension(65, 29));
        nextButton.setMinimumSize(new java.awt.Dimension(65, 29));
        nextButton.setPreferredSize(new java.awt.Dimension(65, 29));
        nextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextButtonActionPerformed(evt);
            }
        });
        jPanel15.add(nextButton);

        jPanel141212.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel141212.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel141212.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel15.add(jPanel141212);

        okButton1.setFont(new java.awt.Font("Dialog", 1, 11)); // NOI18N
        okButton1.setText("OK");
        okButton1.setMargin(new java.awt.Insets(2, 10, 2, 10));
        okButton1.setMaximumSize(new java.awt.Dimension(65, 29));
        okButton1.setMinimumSize(new java.awt.Dimension(65, 29));
        okButton1.setPreferredSize(new java.awt.Dimension(65, 29));
        okButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okButton1ActionPerformed(evt);
            }
        });
        jPanel15.add(okButton1);

        jPanel2.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel2.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel2.setPreferredSize(new java.awt.Dimension(2, 10));
        jPanel15.add(jPanel2);

        jPanel13.add(jPanel15);

        datePanel.add(jPanel13);

        mainTabbedPane.addTab("Date condition   ", datePanel);

        variablePanel.setMinimumSize(new java.awt.Dimension(500, 65));
        variablePanel.setPreferredSize(new java.awt.Dimension(500, 60));
        variablePanel.setLayout(new javax.swing.BoxLayout(variablePanel, javax.swing.BoxLayout.Y_AXIS));

        jPanel512.setMaximumSize(new java.awt.Dimension(32000, 5));
        jPanel512.setMinimumSize(new java.awt.Dimension(500, 5));
        jPanel512.setPreferredSize(new java.awt.Dimension(500, 5));
        variablePanel.add(jPanel512);

        jSplitPane2.setResizeWeight(0.1);
        jSplitPane2.setMaximumSize(new java.awt.Dimension(2147363747, 2147363747));
        jSplitPane2.setMinimumSize(new java.awt.Dimension(10000000, 0));
        jSplitPane2.setPreferredSize(new java.awt.Dimension(32000, 2000));

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "1. Select a dataset to condition on", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11), new java.awt.Color(0, 0, 0))); // NOI18N
        jPanel5.setMinimumSize(new java.awt.Dimension(120, 47));
        jPanel5.setPreferredSize(new java.awt.Dimension(300, 34));
        jPanel5.setLayout(new java.awt.GridLayout(1, 0));

        jScrollPane132.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane132.setPreferredSize(new java.awt.Dimension(450, 450));

        unitTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Identifier", "Type"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        unitTable.setInheritsPopupMenu(true);
        unitTable.setPreferredSize(new java.awt.Dimension(75, 400));
        unitTable.setRequestFocusEnabled(false);
        jScrollPane132.setViewportView(unitTable);

        jPanel5.add(jScrollPane132);

        jSplitPane2.setLeftComponent(jPanel5);

        conditionsPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "2. Specify the condition for selecting pairs", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11), new java.awt.Color(0, 0, 0))); // NOI18N
        conditionsPanel.setMaximumSize(new java.awt.Dimension(32779, 32794));
        conditionsPanel.setMinimumSize(new java.awt.Dimension(100, 47));
        conditionsPanel.setPreferredSize(new java.awt.Dimension(60, 34));
        conditionsPanel.setLayout(new javax.swing.BoxLayout(conditionsPanel, javax.swing.BoxLayout.LINE_AXIS));

        jScrollPane1.setBorder(null);
        jScrollPane1.setPreferredSize(new java.awt.Dimension(1000, 265));

        jPanel14.setMaximumSize(new java.awt.Dimension(1000, 265));
        jPanel14.setMinimumSize(new java.awt.Dimension(1000, 265));
        jPanel14.setPreferredSize(new java.awt.Dimension(300, 265));
        jPanel14.setLayout(new javax.swing.BoxLayout(jPanel14, javax.swing.BoxLayout.Y_AXIS));

        jPanel24.setLayout(new javax.swing.BoxLayout(jPanel24, javax.swing.BoxLayout.X_AXIS));

        functionLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        functionLabel.setText("a. Apply a condition to:");
        functionLabel.setMaximumSize(new java.awt.Dimension(175, 25));
        functionLabel.setMinimumSize(new java.awt.Dimension(120, 25));
        functionLabel.setPreferredSize(new java.awt.Dimension(175, 25));
        jPanel24.add(functionLabel);

        jPanel34.setMaximumSize(new java.awt.Dimension(32767, 25));
        jPanel34.setMinimumSize(new java.awt.Dimension(10, 25));
        jPanel34.setPreferredSize(new java.awt.Dimension(10, 0));
        jPanel24.add(jPanel34);

        thresholdLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        thresholdLabel.setText("b. Threshold (if applicable):");
        thresholdLabel.setMaximumSize(new java.awt.Dimension(175, 25));
        thresholdLabel.setMinimumSize(new java.awt.Dimension(120, 25));
        thresholdLabel.setPreferredSize(new java.awt.Dimension(175, 25));
        jPanel24.add(thresholdLabel);

        jPanel14.add(jPanel24);

        jPanel8.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel8.setMinimumSize(new java.awt.Dimension(100, 27));
        jPanel8.setPreferredSize(new java.awt.Dimension(1000, 27));
        jPanel8.setLayout(new javax.swing.BoxLayout(jPanel8, javax.swing.BoxLayout.LINE_AXIS));

        dataStatBox.setBackground(java.awt.Color.WHITE);
        dataStatBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        dataStatBox.setMaximumSize(new java.awt.Dimension(175, 32000));
        dataStatBox.setMinimumSize(new java.awt.Dimension(120, 27));
        dataStatBox.setPreferredSize(new java.awt.Dimension(175, 27));
        dataStatBox.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                dataStatBoxPopupMenuWillBecomeVisible(evt);
            }
        });
        jPanel8.add(dataStatBox);

        jPanel23.setMinimumSize(new java.awt.Dimension(10, 0));
        jPanel23.setPreferredSize(new java.awt.Dimension(10, 0));
        jPanel8.add(jPanel23);

        conditionField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        conditionField.setMargin(new java.awt.Insets(0, 0, 0, 0));
        conditionField.setMaximumSize(new java.awt.Dimension(175, 32000));
        conditionField.setMinimumSize(new java.awt.Dimension(120, 27));
        conditionField.setPreferredSize(new java.awt.Dimension(175, 27));
        jPanel8.add(conditionField);

        jPanel14.add(jPanel8);

        timeLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        timeLabel.setText("c. Time window (leave blank for individual times)");
        timeLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        timeLabel.setMaximumSize(new java.awt.Dimension(32000, 30));
        timeLabel.setMinimumSize(new java.awt.Dimension(32000, 30));
        timeLabel.setPreferredSize(new java.awt.Dimension(32000, 30));
        jPanel14.add(timeLabel);

        jPanel7.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel7.setMinimumSize(new java.awt.Dimension(100, 27));
        jPanel7.setPreferredSize(new java.awt.Dimension(1000, 27));
        jPanel7.setLayout(new javax.swing.BoxLayout(jPanel7, javax.swing.BoxLayout.LINE_AXIS));

        windowField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        windowField.setMargin(new java.awt.Insets(0, 0, 0, 0));
        windowField.setMaximumSize(new java.awt.Dimension(175, 32000));
        windowField.setMinimumSize(new java.awt.Dimension(120, 27));
        windowField.setPreferredSize(new java.awt.Dimension(175, 27));
        windowField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                windowFieldKeyReleased(evt);
            }
        });
        jPanel7.add(windowField);

        jPanel16.setMinimumSize(new java.awt.Dimension(10, 0));
        jPanel16.setPreferredSize(new java.awt.Dimension(10, 0));
        jPanel7.add(jPanel16);

        windowUnitsBox.setBackground(java.awt.Color.WHITE);
        windowUnitsBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        windowUnitsBox.setMaximumSize(new java.awt.Dimension(175, 32000));
        windowUnitsBox.setMinimumSize(new java.awt.Dimension(120, 27));
        windowUnitsBox.setPreferredSize(new java.awt.Dimension(175, 27));
        windowUnitsBox.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                windowUnitsBoxPopupMenuWillBecomeVisible(evt);
            }
        });
        jPanel7.add(windowUnitsBox);

        jPanel14.add(jPanel7);

        windowStatLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        windowStatLabel.setText("d. Statistic for time window (select 'NONE' for individual times)");
        windowStatLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        windowStatLabel.setMaximumSize(new java.awt.Dimension(32000, 30));
        windowStatLabel.setMinimumSize(new java.awt.Dimension(32000, 30));
        windowStatLabel.setPreferredSize(new java.awt.Dimension(32000, 30));
        jPanel14.add(windowStatLabel);

        jPanel28.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel28.setMinimumSize(new java.awt.Dimension(100, 27));
        jPanel28.setPreferredSize(new java.awt.Dimension(1000, 27));
        jPanel28.setLayout(new javax.swing.BoxLayout(jPanel28, javax.swing.BoxLayout.LINE_AXIS));

        windowStatBox.setBackground(java.awt.Color.WHITE);
        windowStatBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        windowStatBox.setMaximumSize(new java.awt.Dimension(175, 32000));
        windowStatBox.setMinimumSize(new java.awt.Dimension(120, 27));
        windowStatBox.setPreferredSize(new java.awt.Dimension(175, 27));
        windowStatBox.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                windowStatBoxPopupMenuWillBecomeVisible(evt);
            }
        });
        jPanel28.add(windowStatBox);

        jPanel32.setMinimumSize(new java.awt.Dimension(10, 0));
        jPanel32.setPreferredSize(new java.awt.Dimension(10, 0));
        jPanel28.add(jPanel32);

        jPanel33.setMaximumSize(new java.awt.Dimension(175, 30));
        jPanel33.setMinimumSize(new java.awt.Dimension(120, 10));
        jPanel33.setPreferredSize(new java.awt.Dimension(175, 10));
        jPanel28.add(jPanel33);

        jPanel14.add(jPanel28);

        selectedUnitLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        selectedUnitLabel.setText("e. Apply logical condition ('AND' applies to multiple selections).");
        selectedUnitLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        selectedUnitLabel.setMaximumSize(new java.awt.Dimension(320000, 30));
        selectedUnitLabel.setMinimumSize(new java.awt.Dimension(0, 30));
        selectedUnitLabel.setPreferredSize(new java.awt.Dimension(20, 30));
        jPanel14.add(selectedUnitLabel);

        jPanel9.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel9.setMinimumSize(new java.awt.Dimension(100, 27));
        jPanel9.setPreferredSize(new java.awt.Dimension(1000, 27));
        jPanel9.setLayout(new javax.swing.BoxLayout(jPanel9, javax.swing.BoxLayout.LINE_AXIS));

        lessThanButton.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        lessThanButton.setSelected(true);
        lessThanButton.setText("Less than");
        lessThanButton.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        lessThanButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
        lessThanButton.setMaximumSize(new java.awt.Dimension(175, 30));
        lessThanButton.setMinimumSize(new java.awt.Dimension(120, 30));
        lessThanButton.setPreferredSize(new java.awt.Dimension(175, 30));
        lessThanButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lessThanButtonActionPerformed(evt);
            }
        });
        jPanel9.add(lessThanButton);

        jPanel18.setMinimumSize(new java.awt.Dimension(10, 0));
        jPanel18.setPreferredSize(new java.awt.Dimension(10, 0));
        jPanel9.add(jPanel18);

        lessThanField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        lessThanField.setMargin(new java.awt.Insets(0, 0, 0, 0));
        lessThanField.setMaximumSize(new java.awt.Dimension(175, 32000));
        lessThanField.setMinimumSize(new java.awt.Dimension(120, 27));
        lessThanField.setPreferredSize(new java.awt.Dimension(175, 27));
        lessThanField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                lessThanFieldKeyReleased(evt);
            }
        });
        jPanel9.add(lessThanField);

        jPanel14.add(jPanel9);

        jPanel26.setMaximumSize(new java.awt.Dimension(32767, 3));
        jPanel26.setMinimumSize(new java.awt.Dimension(10, 3));
        jPanel26.setPreferredSize(new java.awt.Dimension(10, 3));
        jPanel14.add(jPanel26);

        jPanel11.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel11.setMinimumSize(new java.awt.Dimension(100, 27));
        jPanel11.setPreferredSize(new java.awt.Dimension(1000, 27));
        jPanel11.setLayout(new javax.swing.BoxLayout(jPanel11, javax.swing.BoxLayout.LINE_AXIS));

        lessThanEqualButton.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        lessThanEqualButton.setText("Less than or equal to");
        lessThanEqualButton.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        lessThanEqualButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
        lessThanEqualButton.setMaximumSize(new java.awt.Dimension(175, 30));
        lessThanEqualButton.setMinimumSize(new java.awt.Dimension(120, 30));
        lessThanEqualButton.setPreferredSize(new java.awt.Dimension(175, 30));
        lessThanEqualButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lessThanEqualButtonActionPerformed(evt);
            }
        });
        jPanel11.add(lessThanEqualButton);

        jPanel19.setMinimumSize(new java.awt.Dimension(10, 0));
        jPanel19.setPreferredSize(new java.awt.Dimension(10, 0));
        jPanel11.add(jPanel19);

        lessThanEqualField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        lessThanEqualField.setEnabled(false);
        lessThanEqualField.setMargin(new java.awt.Insets(0, 0, 0, 0));
        lessThanEqualField.setMaximumSize(new java.awt.Dimension(175, 32000));
        lessThanEqualField.setMinimumSize(new java.awt.Dimension(120, 27));
        lessThanEqualField.setPreferredSize(new java.awt.Dimension(175, 27));
        lessThanEqualField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                lessThanEqualFieldKeyReleased(evt);
            }
        });
        jPanel11.add(lessThanEqualField);

        jPanel14.add(jPanel11);

        jPanel25.setMaximumSize(new java.awt.Dimension(32767, 3));
        jPanel25.setMinimumSize(new java.awt.Dimension(10, 3));
        jPanel25.setPreferredSize(new java.awt.Dimension(10, 3));
        jPanel14.add(jPanel25);

        jPanel10.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel10.setMinimumSize(new java.awt.Dimension(100, 27));
        jPanel10.setPreferredSize(new java.awt.Dimension(1000, 27));
        jPanel10.setLayout(new javax.swing.BoxLayout(jPanel10, javax.swing.BoxLayout.LINE_AXIS));

        greaterThanButton.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        greaterThanButton.setText("Greater than");
        greaterThanButton.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        greaterThanButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
        greaterThanButton.setMaximumSize(new java.awt.Dimension(175, 30));
        greaterThanButton.setMinimumSize(new java.awt.Dimension(120, 30));
        greaterThanButton.setPreferredSize(new java.awt.Dimension(175, 30));
        greaterThanButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                greaterThanButtonActionPerformed(evt);
            }
        });
        jPanel10.add(greaterThanButton);

        jPanel21.setMinimumSize(new java.awt.Dimension(10, 0));
        jPanel21.setPreferredSize(new java.awt.Dimension(10, 0));
        jPanel10.add(jPanel21);

        greaterThanField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        greaterThanField.setEnabled(false);
        greaterThanField.setMargin(new java.awt.Insets(0, 0, 0, 0));
        greaterThanField.setMaximumSize(new java.awt.Dimension(175, 32000));
        greaterThanField.setMinimumSize(new java.awt.Dimension(120, 27));
        greaterThanField.setPreferredSize(new java.awt.Dimension(175, 27));
        greaterThanField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                greaterThanFieldKeyReleased(evt);
            }
        });
        jPanel10.add(greaterThanField);

        jPanel14.add(jPanel10);

        jPanel27.setMaximumSize(new java.awt.Dimension(32767, 3));
        jPanel27.setMinimumSize(new java.awt.Dimension(10, 3));
        jPanel27.setPreferredSize(new java.awt.Dimension(10, 3));
        jPanel14.add(jPanel27);

        jPanel12.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel12.setMinimumSize(new java.awt.Dimension(100, 27));
        jPanel12.setPreferredSize(new java.awt.Dimension(1000, 27));
        jPanel12.setLayout(new javax.swing.BoxLayout(jPanel12, javax.swing.BoxLayout.LINE_AXIS));

        greaterThanEqualButton.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        greaterThanEqualButton.setText("Greater than or equal to");
        greaterThanEqualButton.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        greaterThanEqualButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
        greaterThanEqualButton.setMaximumSize(new java.awt.Dimension(175, 30));
        greaterThanEqualButton.setMinimumSize(new java.awt.Dimension(120, 30));
        greaterThanEqualButton.setPreferredSize(new java.awt.Dimension(175, 30));
        greaterThanEqualButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                greaterThanEqualButtonActionPerformed(evt);
            }
        });
        jPanel12.add(greaterThanEqualButton);

        jPanel22.setMinimumSize(new java.awt.Dimension(10, 0));
        jPanel22.setPreferredSize(new java.awt.Dimension(10, 0));
        jPanel12.add(jPanel22);

        greaterThanEqualField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        greaterThanEqualField.setEnabled(false);
        greaterThanEqualField.setMargin(new java.awt.Insets(0, 0, 0, 0));
        greaterThanEqualField.setMaximumSize(new java.awt.Dimension(175, 32000));
        greaterThanEqualField.setMinimumSize(new java.awt.Dimension(120, 27));
        greaterThanEqualField.setPreferredSize(new java.awt.Dimension(175, 27));
        greaterThanEqualField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                greaterThanEqualFieldKeyReleased(evt);
            }
        });
        jPanel12.add(greaterThanEqualField);

        jPanel14.add(jPanel12);

        jScrollPane1.setViewportView(jPanel14);
        jPanel14.getAccessibleContext().setAccessibleName("1. Local condition (applied at each forecast time)");

        conditionsPanel.add(jScrollPane1);

        jSplitPane2.setRightComponent(conditionsPanel);

        variablePanel.add(jSplitPane2);

        jPanel43.setMaximumSize(new java.awt.Dimension(65676, 35));
        jPanel43.setMinimumSize(new java.awt.Dimension(150, 30));
        jPanel43.setPreferredSize(new java.awt.Dimension(300, 35));
        jPanel43.setLayout(new javax.swing.BoxLayout(jPanel43, javax.swing.BoxLayout.Y_AXIS));

        jPanel53.setMaximumSize(new java.awt.Dimension(32000, 2));
        jPanel53.setMinimumSize(new java.awt.Dimension(500, 2));
        jPanel53.setOpaque(false);
        jPanel53.setPreferredSize(new java.awt.Dimension(500, 2));
        jPanel53.setLayout(new javax.swing.BoxLayout(jPanel53, javax.swing.BoxLayout.LINE_AXIS));
        jPanel43.add(jPanel53);

        jPanel45.setMaximumSize(new java.awt.Dimension(32909, 35));
        jPanel45.setMinimumSize(new java.awt.Dimension(152, 30));
        jPanel45.setPreferredSize(new java.awt.Dimension(150, 35));
        jPanel45.setLayout(new javax.swing.BoxLayout(jPanel45, javax.swing.BoxLayout.LINE_AXIS));

        jPanel6.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel6.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel6.setPreferredSize(new java.awt.Dimension(2, 10));
        jPanel45.add(jPanel6);

        moreButton2.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        moreButton2.setText("More");
        moreButton2.setEnabled(false);
        moreButton2.setMargin(new java.awt.Insets(2, 10, 2, 10));
        moreButton2.setMaximumSize(new java.awt.Dimension(65, 29));
        moreButton2.setMinimumSize(new java.awt.Dimension(65, 29));
        moreButton2.setPreferredSize(new java.awt.Dimension(65, 29));
        moreButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                moreButton2ActionPerformed(evt);
            }
        });
        jPanel45.add(moreButton2);

        jPanel14123.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel14123.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel14123.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel45.add(jPanel14123);

        resetValuesButton.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        resetValuesButton.setText("Reset");
        resetValuesButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        resetValuesButton.setMaximumSize(new java.awt.Dimension(65, 29));
        resetValuesButton.setMinimumSize(new java.awt.Dimension(65, 29));
        resetValuesButton.setPreferredSize(new java.awt.Dimension(65, 29));
        resetValuesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetValuesButtonActionPerformed(evt);
            }
        });
        jPanel45.add(resetValuesButton);

        jPanel14125.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel14125.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel14125.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel45.add(jPanel14125);

        deleteValuesButton.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        deleteValuesButton.setText("Delete");
        deleteValuesButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        deleteValuesButton.setMaximumSize(new java.awt.Dimension(65, 29));
        deleteValuesButton.setMinimumSize(new java.awt.Dimension(65, 29));
        deleteValuesButton.setPreferredSize(new java.awt.Dimension(65, 29));
        deleteValuesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteValuesButtonActionPerformed(evt);
            }
        });
        jPanel45.add(deleteValuesButton);

        jPanel202.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel45.add(jPanel202);

        cancelButton2.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        cancelButton2.setText("Cancel");
        cancelButton2.setMargin(new java.awt.Insets(2, 10, 2, 10));
        cancelButton2.setMaximumSize(new java.awt.Dimension(65, 29));
        cancelButton2.setMinimumSize(new java.awt.Dimension(65, 29));
        cancelButton2.setPreferredSize(new java.awt.Dimension(65, 29));
        cancelButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButton2ActionPerformed(evt);
            }
        });
        jPanel45.add(cancelButton2);

        jPanel14124.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel14124.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel14124.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel45.add(jPanel14124);

        backButton.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        backButton.setText("Back");
        backButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        backButton.setMaximumSize(new java.awt.Dimension(65, 29));
        backButton.setMinimumSize(new java.awt.Dimension(65, 29));
        backButton.setPreferredSize(new java.awt.Dimension(65, 29));
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });
        jPanel45.add(backButton);

        jPanel141214.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel141214.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel141214.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel45.add(jPanel141214);

        nextButton1.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        nextButton1.setText("Next");
        nextButton1.setMargin(new java.awt.Insets(2, 10, 2, 10));
        nextButton1.setMaximumSize(new java.awt.Dimension(65, 29));
        nextButton1.setMinimumSize(new java.awt.Dimension(65, 29));
        nextButton1.setPreferredSize(new java.awt.Dimension(65, 29));
        nextButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextButton1ActionPerformed(evt);
            }
        });
        jPanel45.add(nextButton1);

        jPanel141211.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel141211.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel141211.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel45.add(jPanel141211);

        okButton2.setFont(new java.awt.Font("Dialog", 1, 11)); // NOI18N
        okButton2.setText("OK");
        okButton2.setMargin(new java.awt.Insets(2, 10, 2, 10));
        okButton2.setMaximumSize(new java.awt.Dimension(65, 29));
        okButton2.setMinimumSize(new java.awt.Dimension(65, 29));
        okButton2.setPreferredSize(new java.awt.Dimension(65, 29));
        okButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okButton2ActionPerformed(evt);
            }
        });
        jPanel45.add(okButton2);

        jPanel3.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel3.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel3.setPreferredSize(new java.awt.Dimension(2, 10));
        jPanel45.add(jPanel3);

        jPanel43.add(jPanel45);

        variablePanel.add(jPanel43);

        mainTabbedPane.addTab("Value condition   ", variablePanel);

        otherPanel.setMinimumSize(new java.awt.Dimension(500, 65));
        otherPanel.setPreferredSize(new java.awt.Dimension(500, 60));
        otherPanel.setLayout(new javax.swing.BoxLayout(otherPanel, javax.swing.BoxLayout.Y_AXIS));

        jPanel513.setMaximumSize(new java.awt.Dimension(32000, 5));
        jPanel513.setMinimumSize(new java.awt.Dimension(500, 5));
        jPanel513.setPreferredSize(new java.awt.Dimension(500, 5));
        otherPanel.add(jPanel513);

        optionsInsertPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "1. Other options", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11), new java.awt.Color(0, 0, 0))); // NOI18N
        optionsInsertPanel.setMaximumSize(new java.awt.Dimension(32779, 32794));
        optionsInsertPanel.setMinimumSize(new java.awt.Dimension(100, 47));
        optionsInsertPanel.setPreferredSize(new java.awt.Dimension(32000, 2000));
        optionsInsertPanel.setLayout(new javax.swing.BoxLayout(optionsInsertPanel, javax.swing.BoxLayout.LINE_AXIS));

        jScrollPane2.setBorder(null);
        jScrollPane2.setPreferredSize(new java.awt.Dimension(1000, 265));

        jPanel29.setMaximumSize(new java.awt.Dimension(1000, 265));
        jPanel29.setMinimumSize(new java.awt.Dimension(1000, 265));
        jPanel29.setPreferredSize(new java.awt.Dimension(300, 265));
        jPanel29.setLayout(new javax.swing.BoxLayout(jPanel29, javax.swing.BoxLayout.Y_AXIS));

        tempAggFuncLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        tempAggFuncLabel.setText("Temporal aggregation function:");
        tempAggFuncLabel.setMaximumSize(new java.awt.Dimension(320000, 25));
        tempAggFuncLabel.setMinimumSize(new java.awt.Dimension(320000, 25));
        tempAggFuncLabel.setPreferredSize(new java.awt.Dimension(20, 25));
        jPanel29.add(tempAggFuncLabel);

        jPanel30.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel30.setMinimumSize(new java.awt.Dimension(100, 27));
        jPanel30.setPreferredSize(new java.awt.Dimension(1000, 27));
        jPanel30.setLayout(new javax.swing.BoxLayout(jPanel30, javax.swing.BoxLayout.LINE_AXIS));

        aggStatBox.setBackground(java.awt.Color.WHITE);
        aggStatBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        aggStatBox.setMaximumSize(new java.awt.Dimension(200, 32000));
        aggStatBox.setMinimumSize(new java.awt.Dimension(120, 27));
        aggStatBox.setPreferredSize(new java.awt.Dimension(200, 27));
        aggStatBox.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                aggStatBoxPopupMenuWillBecomeVisible(evt);
            }
        });
        aggStatBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aggStatBoxActionPerformed(evt);
            }
        });
        jPanel30.add(aggStatBox);

        jPanel31.setMinimumSize(new java.awt.Dimension(10, 0));
        jPanel31.setPreferredSize(new java.awt.Dimension(10, 0));
        jPanel30.add(jPanel31);

        jPanel29.add(jPanel30);

        sampleSizeLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        sampleSizeLabel.setText("Minimum sample fraction [0,1]:");
        sampleSizeLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        sampleSizeLabel.setMaximumSize(new java.awt.Dimension(32000, 30));
        sampleSizeLabel.setMinimumSize(new java.awt.Dimension(32000, 30));
        sampleSizeLabel.setPreferredSize(new java.awt.Dimension(20, 30));
        jPanel29.add(sampleSizeLabel);

        jPanel35.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel35.setMinimumSize(new java.awt.Dimension(100, 27));
        jPanel35.setPreferredSize(new java.awt.Dimension(1000, 27));
        jPanel35.setLayout(new javax.swing.BoxLayout(jPanel35, javax.swing.BoxLayout.LINE_AXIS));

        sampleSizeField.setMaximumSize(new java.awt.Dimension(200, 32000));
        sampleSizeField.setMinimumSize(new java.awt.Dimension(120, 27));
        sampleSizeField.setPreferredSize(new java.awt.Dimension(200, 27));
        jPanel35.add(sampleSizeField);

        jPanel36.setMinimumSize(new java.awt.Dimension(10, 0));
        jPanel36.setPreferredSize(new java.awt.Dimension(10, 0));
        jPanel35.add(jPanel36);

        jPanel29.add(jPanel35);

        aggStartLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        aggStartLabel.setText("Aggregation start hour in UTC [0,23]:");
        aggStartLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        aggStartLabel.setMaximumSize(new java.awt.Dimension(32000, 30));
        aggStartLabel.setMinimumSize(new java.awt.Dimension(32000, 30));
        aggStartLabel.setPreferredSize(new java.awt.Dimension(20, 30));
        jPanel29.add(aggStartLabel);

        jPanel37.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel37.setMinimumSize(new java.awt.Dimension(100, 27));
        jPanel37.setPreferredSize(new java.awt.Dimension(1000, 27));
        jPanel37.setLayout(new javax.swing.BoxLayout(jPanel37, javax.swing.BoxLayout.LINE_AXIS));

        aggregationStartField.setMaximumSize(new java.awt.Dimension(200, 32000));
        aggregationStartField.setMinimumSize(new java.awt.Dimension(120, 27));
        aggregationStartField.setPreferredSize(new java.awt.Dimension(200, 27));
        jPanel37.add(aggregationStartField);

        jPanel38.setMinimumSize(new java.awt.Dimension(10, 0));
        jPanel38.setPreferredSize(new java.awt.Dimension(10, 0));
        jPanel37.add(jPanel38);

        jPanel29.add(jPanel37);

        aggStartLeadLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        aggStartLeadLabel.setText("Aggregation start lead hour:");
        aggStartLeadLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        aggStartLeadLabel.setMaximumSize(new java.awt.Dimension(32000, 30));
        aggStartLeadLabel.setMinimumSize(new java.awt.Dimension(32000, 30));
        aggStartLeadLabel.setPreferredSize(new java.awt.Dimension(20, 30));
        jPanel29.add(aggStartLeadLabel);

        jPanel39.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel39.setMinimumSize(new java.awt.Dimension(100, 27));
        jPanel39.setPreferredSize(new java.awt.Dimension(1000, 27));
        jPanel39.setLayout(new javax.swing.BoxLayout(jPanel39, javax.swing.BoxLayout.LINE_AXIS));

        aggregationStartLeadField.setMaximumSize(new java.awt.Dimension(200, 32000));
        aggregationStartLeadField.setMinimumSize(new java.awt.Dimension(120, 27));
        aggregationStartLeadField.setPreferredSize(new java.awt.Dimension(200, 27));
        jPanel39.add(aggregationStartLeadField);

        jPanel40.setMinimumSize(new java.awt.Dimension(10, 0));
        jPanel40.setPreferredSize(new java.awt.Dimension(10, 0));
        jPanel39.add(jPanel40);

        jPanel29.add(jPanel39);

        jScrollPane2.setViewportView(jPanel29);

        optionsInsertPanel.add(jScrollPane2);

        otherPanel.add(optionsInsertPanel);

        jPanel48.setMaximumSize(new java.awt.Dimension(65676, 35));
        jPanel48.setMinimumSize(new java.awt.Dimension(150, 30));
        jPanel48.setPreferredSize(new java.awt.Dimension(300, 35));
        jPanel48.setLayout(new javax.swing.BoxLayout(jPanel48, javax.swing.BoxLayout.Y_AXIS));

        jPanel54.setMaximumSize(new java.awt.Dimension(32000, 2));
        jPanel54.setMinimumSize(new java.awt.Dimension(500, 2));
        jPanel54.setOpaque(false);
        jPanel54.setPreferredSize(new java.awt.Dimension(500, 2));
        jPanel54.setLayout(new javax.swing.BoxLayout(jPanel54, javax.swing.BoxLayout.LINE_AXIS));
        jPanel48.add(jPanel54);

        jPanel49.setMaximumSize(new java.awt.Dimension(32909, 35));
        jPanel49.setMinimumSize(new java.awt.Dimension(152, 30));
        jPanel49.setPreferredSize(new java.awt.Dimension(150, 35));
        jPanel49.setLayout(new javax.swing.BoxLayout(jPanel49, javax.swing.BoxLayout.LINE_AXIS));

        jPanel203.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel49.add(jPanel203);

        cancelButton3.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        cancelButton3.setText("Cancel");
        cancelButton3.setMargin(new java.awt.Insets(2, 10, 2, 10));
        cancelButton3.setMaximumSize(new java.awt.Dimension(65, 29));
        cancelButton3.setMinimumSize(new java.awt.Dimension(65, 29));
        cancelButton3.setPreferredSize(new java.awt.Dimension(65, 29));
        cancelButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButton3ActionPerformed(evt);
            }
        });
        jPanel49.add(cancelButton3);

        jPanel14129.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel14129.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel14129.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel49.add(jPanel14129);

        backButton1.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        backButton1.setText("Back");
        backButton1.setMargin(new java.awt.Insets(2, 10, 2, 10));
        backButton1.setMaximumSize(new java.awt.Dimension(65, 29));
        backButton1.setMinimumSize(new java.awt.Dimension(65, 29));
        backButton1.setPreferredSize(new java.awt.Dimension(65, 29));
        backButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButton1ActionPerformed(evt);
            }
        });
        jPanel49.add(backButton1);

        jPanel141213.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel141213.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel141213.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel49.add(jPanel141213);

        okButton3.setFont(new java.awt.Font("Dialog", 1, 11)); // NOI18N
        okButton3.setText("OK");
        okButton3.setMargin(new java.awt.Insets(2, 10, 2, 10));
        okButton3.setMaximumSize(new java.awt.Dimension(65, 29));
        okButton3.setMinimumSize(new java.awt.Dimension(65, 29));
        okButton3.setPreferredSize(new java.awt.Dimension(65, 29));
        okButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okButton3ActionPerformed(evt);
            }
        });
        jPanel49.add(okButton3);

        jPanel51.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel51.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel51.setPreferredSize(new java.awt.Dimension(2, 10));
        jPanel49.add(jPanel51);

        jPanel48.add(jPanel49);

        otherPanel.add(jPanel48);

        mainTabbedPane.addTab("Other options     ", otherPanel);

        getContentPane().add(mainTabbedPane);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Deletes any date conditions following confirmation.
     *
     * @param evt an action event
     */
    
    private void deleteDatesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteDatesButtonActionPerformed
        deleteDateConditions();
    }//GEN-LAST:event_deleteDatesButtonActionPerformed

    /**
     * Deletes any value conditions following confirmation.
     *
     * @param evt an action event
     */    
    
    private void deleteValuesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteValuesButtonActionPerformed
        deleteValueConditions();
    }//GEN-LAST:event_deleteValuesButtonActionPerformed
    
    /**
     * Updates the store of local parameter values following a change in the
     * input field.
     *
     * @param evt a key event
     */    
    
    private void greaterThanEqualFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_greaterThanEqualFieldKeyReleased
        saveLocalData();
    }//GEN-LAST:event_greaterThanEqualFieldKeyReleased

    /**
     * Updates the store of local parameter values following a change in the
     * input field.
     *
     * @param evt a key event
     */
    
    private void windowFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_windowFieldKeyReleased
        saveLocalData();
    }//GEN-LAST:event_windowFieldKeyReleased
    
    /**
     * Alters the width of the time period box pop-up menu to match the contents.
     *
     * @param evt a pop-up menu event
     */
    
    private void windowUnitsBoxPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_windowUnitsBoxPopupMenuWillBecomeVisible
        EVSMainWindow.main.setPopupWidth(evt);
    }//GEN-LAST:event_windowUnitsBoxPopupMenuWillBecomeVisible
    
    /**
     * Alters the width of the statistic pop-up menu to match the contents.
     *
     * @param evt a pop-up menu event
     */
    
    private void dataStatBoxPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_dataStatBoxPopupMenuWillBecomeVisible
        EVSMainWindow.main.setPopupWidth(evt);
    }//GEN-LAST:event_dataStatBoxPopupMenuWillBecomeVisible
    
    /**
     * Exits the dialog, accepting any changes made.
     *
     * @param evt an action event
     */
    
    private void okButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_okButton1ActionPerformed
        try {
            saveData();
            exit();
        }
        catch(Exception e) {
            ExceptionHandler.displayException(e);
            e.printStackTrace();
        }
    }//GEN-LAST:event_okButton1ActionPerformed
    /**
     * Cancels the dialog.
     *
     * @param evt an action event
     */
    
    private void cancelButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButton2ActionPerformed
        cancel();
    }//GEN-LAST:event_cancelButton2ActionPerformed
    
    /**
     * Resets all conditions on the variable values to no conditions.
     *
     * @param evt an action event
     */
    
    private void resetValuesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetValuesButtonActionPerformed
        resetValueConditions();
    }//GEN-LAST:event_resetValuesButtonActionPerformed
    
    /**
     * Resets all date conditions.
     *
     * @param evt an action event
     */
    
    private void resetDatesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetDatesButtonActionPerformed
        resetDateConditions();
    }//GEN-LAST:event_resetDatesButtonActionPerformed

    /**
     * Resets the date conditions to the original conditions.
     */
    
    private void resetDateConditions() {
         prepLocalDateConditions(VERIFICATION_A.getSelectedUnit(),VERIFICATION_A.getStartDate(),VERIFICATION_A.getEndDate());
    }
    
    /**
     * Resets the variable value conditions to the original conditions.
     */
    
    private void resetValueConditions() {
         prepLocalValueConditions(VERIFICATION_A.getSelectedUnit(),VERIFICATION_A.getVerificationUnits());
         showLocalData(); //Updates the display
    }
    
   /**
     * Resets the date conditions on confirming the change in an option dialog.
     */
    
    private void deleteDateConditions() {
        int n = JOptionPane.showOptionDialog(this,"Delete all date conditions?","Delete conditions",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
        //Reset all date selections to true
        if(n == JOptionPane.YES_OPTION) {
            VERIFICATION_A.getSelectedUnit().deleteDateCondition();
            prepLocalDateConditions(VERIFICATION_A.getSelectedUnit(),VERIFICATION_A.getStartDate(),VERIFICATION_A.getEndDate());
        }
    }
    
    /**
     * Deletes the variable value conditions on confirming the change
     */
    
    private void deleteValueConditions() {
        int n = JOptionPane.showOptionDialog(this,"Delete all variable value conditions?","Delete conditions",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
        if(n == JOptionPane.YES_OPTION) {
            VERIFICATION_A.getSelectedUnit().deleteAllValueConditions();
            prepLocalValueConditions(VERIFICATION_A.getSelectedUnit(),VERIFICATION_A.getVerificationUnits());
            showLocalData(); //Updates the display
        }
    }
    
    /**
     * Updates the store of local parameter values following a change in the
     * input field.
     *
     * @param evt a key event
     */
    
    private void greaterThanFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_greaterThanFieldKeyReleased
        saveLocalData();
    }//GEN-LAST:event_greaterThanFieldKeyReleased
    
    /**
     * Updates the store of local parameter values following a change in the
     * input field.
     *
     * @param evt a key event
     */
    
    private void lessThanEqualFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lessThanEqualFieldKeyReleased
        saveLocalData();
    }//GEN-LAST:event_lessThanEqualFieldKeyReleased
    
    /**
     * Updates the store of local parameter values following a change in the
     * input field.
     *
     * @param evt a key event
     */
    
    private void lessThanFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lessThanFieldKeyReleased
        saveLocalData();
    }//GEN-LAST:event_lessThanFieldKeyReleased
    
    /**
     * Displays a dialog with additional conditions for variable values.
     *
     * @param evt an action event
     */
    
    private void moreButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_moreButton2ActionPerformed
        
    }//GEN-LAST:event_moreButton2ActionPerformed
    
    /**
     * Selects or deselects the greater than or equal to condition.
     *
     * @param evt an action event
     */
    
    private void greaterThanEqualButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_greaterThanEqualButtonActionPerformed
        greaterThanButton.setSelected(false);
        greaterThanField.setEnabled(false);
        greaterThanField.setText("");
        if(! (lessThanEqualButton.isSelected() || lessThanButton.isSelected()) ) {
            greaterThanEqualButton.setSelected(true);
        }
        greaterThanEqualField.setEnabled(greaterThanEqualButton.isSelected());
        if(!greaterThanEqualField.isEnabled()) {
            greaterThanEqualField.setText("");
        }
        saveLocalData();
    }//GEN-LAST:event_greaterThanEqualButtonActionPerformed
    
    /**
     * Selects or deselects the greater than condition.
     *
     * @param evt an action event
     */
    
    private void greaterThanButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_greaterThanButtonActionPerformed
        greaterThanEqualButton.setSelected(false);
        greaterThanEqualField.setEnabled(false);
        greaterThanEqualField.setText("");
        if(! (lessThanEqualButton.isSelected() || lessThanButton.isSelected()) ) {
            greaterThanButton.setSelected(true);
        }
        greaterThanField.setEnabled(greaterThanButton.isSelected());
        if(!greaterThanField.isEnabled()) {
            greaterThanField.setText("");
        }
        saveLocalData();
    }//GEN-LAST:event_greaterThanButtonActionPerformed
    
    /**
     * Selects or deselects the less than or equal to condition.
     *
     * @param evt an action event
     */
    
    private void lessThanEqualButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lessThanEqualButtonActionPerformed
        lessThanButton.setSelected(false);
        lessThanField.setEnabled(false);
        lessThanField.setText("");
        if(! (greaterThanEqualButton.isSelected() || greaterThanButton.isSelected()) ) {
            lessThanEqualButton.setSelected(true);
        }
        lessThanEqualField.setEnabled(lessThanEqualButton.isSelected());
        if(!lessThanEqualField.isEnabled()) {
            lessThanEqualField.setText("");
        }
        saveLocalData();
    }//GEN-LAST:event_lessThanEqualButtonActionPerformed
    
    /**
     * Selects or deselects the less than condition.
     *
     * @param evt an action event
     */
    
    private void lessThanButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lessThanButtonActionPerformed
        lessThanEqualButton.setSelected(false);
        lessThanEqualField.setEnabled(false);
        lessThanEqualField.setText("");
        if(! (greaterThanEqualButton.isSelected() || greaterThanButton.isSelected()) ) {
            lessThanButton.setSelected(true);
        }
        lessThanField.setEnabled(lessThanButton.isSelected());
        if(!lessThanField.isEnabled()) {
            lessThanField.setText("");
        }
        saveLocalData();
    }//GEN-LAST:event_lessThanButtonActionPerformed
    
    /**
     * Toggles selection of items in the date element table.
     *
     * @param evt an action event
     */
    
    private void toggleSelectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toggleSelectionActionPerformed
        int count = catElementTable.getRowCount();
        for(int i = 0 ; i < count; i++) {
            catElementTable.setValueAt(!((Boolean)catElementTable.getValueAt(i,1)),i,1);
        }
    }//GEN-LAST:event_toggleSelectionActionPerformed
    
    /**
     * Selects no items in the date element table.
     *
     * @param evt an action event
     */
    
    private void selectNoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectNoneActionPerformed
        int count = catElementTable.getRowCount();
        for(int i = 0 ; i < count; i++) {
            catElementTable.setValueAt(false,i,1);
        }
    }//GEN-LAST:event_selectNoneActionPerformed
    
    /**
     * Selects all items in the date element table.
     *
     * @param evt an action event
     */
    
    private void selectAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectAllActionPerformed
        int count = catElementTable.getRowCount();
        for(int i = 0 ; i < count; i++) {
            catElementTable.setValueAt(true,i,1);
        }
    }//GEN-LAST:event_selectAllActionPerformed
    
    /**
     * Show option to select all or none of the date elements on right mouse click.
     *
     * @param evt a mouse event
     */
    
    private void catElementTableMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_catElementTableMousePressed
        if(evt.getButton()==evt.BUTTON3) {
            selectMenu.show(catElementTable,evt.getX(),evt.getY());
        }
    }//GEN-LAST:event_catElementTableMousePressed
    
    /**
     * Displays additional date editing capabilities.
     *
     * @param evt an action event
     */
    
    private void moreButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_moreButton1ActionPerformed
        
    }//GEN-LAST:event_moreButton1ActionPerformed
    
    /**
     * Returns to the previous window.
     *
     * @param evt an action event
     */
    
    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        mainTabbedPane.setSelectedIndex((mainTabbedPane.getSelectedIndex())-1);
    }//GEN-LAST:event_backButtonActionPerformed
    
    /**
     * Exits the dialog, accepting any changes made.
     *
     * @param evt an action event
     */
    
    private void okButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_okButton2ActionPerformed
        try {
            saveData();
            exit();
        }
        catch(Exception e) {
            ExceptionHandler.displayException(e);
            e.printStackTrace();
        }
    }//GEN-LAST:event_okButton2ActionPerformed
    
    /**
     * Cancels the dialog.
     *
     * @param evt an action event
     */
    
    private void cancelButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButton1ActionPerformed
        cancel();
    }//GEN-LAST:event_cancelButton1ActionPerformed
    
    /**
     * Cancels the dialog, asking if any input conditions should be deleted.
     */
    
    private void cancel() {
        resetDateConditions();
        resetValueConditions();
        exit();
    }
    
    /**
     * Clears the display, but does not remove any underlying parameter values.
     */
    
    private void clearDisplay() {
        categoryTable.clearSelection();
        unitTable.clearSelection();        
        catElementTable.setModel(new DefaultTableModel(
            new Object [][] {{null, null}},
            new String [] {"Date element", "Include?"}) {
        });
        unitTable.setModel(new DefaultTableModel(new Object[][]{{null},{null}},new String[]{"Identifier","Type"}) {
            public Class getColumnClass(int columnIndex) {
                if(columnIndex==0) {
                    return VerificationUnit.class;
                }
                return String.class;
            }
            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return false;
            }
        });
        mainTabbedPane.setSelectedIndex(0);
        varValIndex = -1;
        showLocalData();  //Clears variable value conditions
    }
    
    /**
     * Moves to the next window.
     *
     * @param evt an action event
     */
    
    private void nextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextButtonActionPerformed
        mainTabbedPane.setSelectedIndex((mainTabbedPane.getSelectedIndex())+1);
    }//GEN-LAST:event_nextButtonActionPerformed
    
    /**
     * Exits the dialog.
     *
     * @param evt a window event.
     */
    
    private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
        cancel();
    }//GEN-LAST:event_closeDialog

    /**
     * Cancel.
     * 
     * @param evt the action event.
     */
    
    private void cancelButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButton3ActionPerformed
        cancel();
    }//GEN-LAST:event_cancelButton3ActionPerformed

    /**
     * Move back one tab.
     * 
     * @param evt the action event
     */
    
    private void backButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButton1ActionPerformed
        mainTabbedPane.setSelectedIndex((mainTabbedPane.getSelectedIndex())-1);
    }//GEN-LAST:event_backButton1ActionPerformed

    /**
     * Save and exit.
     * 
     * @param evt the event
     */
    
    private void okButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_okButton3ActionPerformed
        try {
            saveData();
            exit();
        }
        catch(Exception e) {
            ExceptionHandler.displayException(e);
            e.printStackTrace();
        }
    }//GEN-LAST:event_okButton3ActionPerformed

    /**
     * Sets the pop-up menu width.
     * 
     * @param evt the event
     */
    
    private void aggStatBoxPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_aggStatBoxPopupMenuWillBecomeVisible
        EVSMainWindow.main.setPopupWidth(evt);
    }//GEN-LAST:event_aggStatBoxPopupMenuWillBecomeVisible

    /**
     * Moves to the next tab. 
     * 
     * @param evt the action event
     */
    
    private void nextButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextButton1ActionPerformed
        mainTabbedPane.setSelectedIndex((mainTabbedPane.getSelectedIndex())+1);
    }//GEN-LAST:event_nextButton1ActionPerformed

    /**
     * Sets the index from the stat box.
     * 
     * @param evt an action event
     */
    
    private void aggStatBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aggStatBoxActionPerformed
        aggIndex = aggStatBox.getSelectedIndex();
    }//GEN-LAST:event_aggStatBoxActionPerformed

    /**
     * Sets the pop-up menu width.
     *
     * @param evt the event
     */

    private void windowStatBoxPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_windowStatBoxPopupMenuWillBecomeVisible
        EVSMainWindow.main.setPopupWidth(evt);
    }//GEN-LAST:event_windowStatBoxPopupMenuWillBecomeVisible
    
    /**
     * Exits.
     */
    
    private void exit() {
        clearAllLocalData();  //Return window to initial status
        clearDisplay();
        setVisible(false);
    }
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLES                              *
     *                                                                              *
     *******************************************************************************/
    
    /**
     * Time units.
     */
    
    private Vector timeUnits = null;
    
    /**
     * Currently selected index in the variable value table.
     */
    
    private int varValIndex = -1;
    
    /**
     * Index of the currently selected temporal aggregation function.
     */
    
    private int aggIndex = -1;

    /**
     * Current sample fraction.
     */

    private String sampleFraction = null;

    /**
     * Current aggregation start hour.
     */

    private String aggStartHour = null;
    
    /**
     * Current aggregation start lead hour.
     */

    private String aggStartLeadHour = null;    

    /**
     * Functions for observations.
     */
    
    private Object[][] observedFunctions = null;
    
    /**
     * Functions for forecast values.
     */
    
    private Object[][] forecastFunctions = null;

    /**
     * Vector functions for the window statistics.
     */
    
    private Object[][] windowStatistics = null;

    /**
     * Date category table.
     */
    
    private DefaultTableModel catModel = null;
    
    /**
     * The last version of a verification unit used to set this dialog, stored
     * with the unique identifier of the verification unit.
     */
    
    private TreeMap<String,VerificationUnit> lastUnits = 
            new TreeMap<String,VerificationUnit>();
    
    /**
     * The start and end dates associated with the last version of a verification unit
     * used to set this dialog (not necessarily stored with the last verification unit).
     * The dates are stored in a Calendar[] array, with the start date at the first index
     * and referenced by the unique identifier of the verification unit.
     */
    
    private TreeMap<String,Calendar[]> lastDates = 
            new TreeMap<String,Calendar[]>();
    
    /**
     * Map of date refinement categories, with a table model for each category.
     */
    
    private TreeMap<DateElement,DefaultTableModel> dateMap = 
            new TreeMap<DateElement,DefaultTableModel>();
    
    /**
     * Store of local parameter values for the variable value conditions.  The
     * parameters are referenced to the unique identifier of a single verification
     * unit.  The parameters themselves are stored in another map (i.e. a double map)
     * where they are referenced by the identifiers used in the variable value tables.  
     * Specifically, the identifier comprises the verification unit id with the 
     * data type name appended after the VerificationUnit.getIDSepChar() separator 
     * character.
     *
     * The parameter values are contained in a String array.
     */
    
    private TreeMap<String,TreeMap> varValParsMap = 
            new TreeMap<String,TreeMap>();
    
    /**
     * Flag indicating whether local data should be saved.  Used to prevent inadvertent
     * saves when updating components with event listeners.
     */
    
    private boolean saveLocalData = true;
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel aggStartLabel;
    private javax.swing.JLabel aggStartLeadLabel;
    private javax.swing.JComboBox aggStatBox;
    private javax.swing.JTextField aggregationStartField;
    private javax.swing.JTextField aggregationStartLeadField;
    private javax.swing.JButton backButton;
    private javax.swing.JButton backButton1;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton cancelButton1;
    private javax.swing.JButton cancelButton2;
    private javax.swing.JButton cancelButton3;
    private javax.swing.JTable catElementTable;
    private javax.swing.JTable categoryTable;
    private javax.swing.JTextField conditionField;
    private javax.swing.JPanel conditionsPanel;
    private javax.swing.JComboBox dataStatBox;
    private javax.swing.JPanel datePanel;
    private javax.swing.JButton deleteDatesButton;
    private javax.swing.JButton deleteValuesButton;
    private javax.swing.JLabel functionLabel;
    private javax.swing.JRadioButton greaterThanButton;
    private javax.swing.JRadioButton greaterThanEqualButton;
    private javax.swing.JTextField greaterThanEqualField;
    private javax.swing.JTextField greaterThanField;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel14121;
    private javax.swing.JPanel jPanel141211;
    private javax.swing.JPanel jPanel141212;
    private javax.swing.JPanel jPanel141213;
    private javax.swing.JPanel jPanel141214;
    private javax.swing.JPanel jPanel14122;
    private javax.swing.JPanel jPanel14123;
    private javax.swing.JPanel jPanel14124;
    private javax.swing.JPanel jPanel14125;
    private javax.swing.JPanel jPanel14126;
    private javax.swing.JPanel jPanel14129;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel202;
    private javax.swing.JPanel jPanel203;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel48;
    private javax.swing.JPanel jPanel49;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel51;
    private javax.swing.JPanel jPanel511;
    private javax.swing.JPanel jPanel512;
    private javax.swing.JPanel jPanel513;
    private javax.swing.JPanel jPanel53;
    private javax.swing.JPanel jPanel54;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel613;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane131;
    private javax.swing.JScrollPane jScrollPane132;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JSplitPane jSplitPane2;
    private javax.swing.JRadioButton lessThanButton;
    private javax.swing.JRadioButton lessThanEqualButton;
    private javax.swing.JTextField lessThanEqualField;
    private javax.swing.JTextField lessThanField;
    private javax.swing.JTabbedPane mainTabbedPane;
    private javax.swing.JButton moreButton1;
    private javax.swing.JButton moreButton2;
    private javax.swing.JButton nextButton;
    private javax.swing.JButton nextButton1;
    private javax.swing.JButton okButton1;
    private javax.swing.JButton okButton2;
    private javax.swing.JButton okButton3;
    private javax.swing.JPanel optionsInsertPanel;
    private javax.swing.JPanel otherPanel;
    private javax.swing.JButton resetDatesButton;
    private javax.swing.JButton resetValuesButton;
    private javax.swing.JTextField sampleSizeField;
    private javax.swing.JLabel sampleSizeLabel;
    private javax.swing.JMenuItem selectAll;
    private javax.swing.JPopupMenu selectMenu;
    private javax.swing.JMenuItem selectNone;
    private javax.swing.JLabel selectedUnitLabel;
    private javax.swing.JLabel tempAggFuncLabel;
    private javax.swing.JLabel thresholdLabel;
    private javax.swing.JLabel timeLabel;
    private javax.swing.JMenuItem toggleSelection;
    private javax.swing.JTable unitTable;
    private javax.swing.JPanel variablePanel;
    private javax.swing.JTextField windowField;
    private javax.swing.JComboBox windowStatBox;
    private javax.swing.JLabel windowStatLabel;
    private javax.swing.JComboBox windowUnitsBox;
    // End of variables declaration//GEN-END:variables
    
}
