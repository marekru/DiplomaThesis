package evs.gui.utilities;

//Java swing dependencies
import javax.swing.table.TableCellEditor;

//Java util dependencies
import java.util.HashMap;

//Java awt dependencies
import java.awt.geom.Point2D;

/**
 * Table model that allows a cell editor to be defined for each cell in the table.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class EditorTable extends ToolTipTable {

/*******************************************************************************
 *                                                                              *
 *                              INSTANCE VARIABLES                              *
 *                                                                              *
 *******************************************************************************/    
    
    /**
     * The cell editors.
     */
 
    private HashMap editors = new HashMap();

/*******************************************************************************
 *                                                                             *
 *                              ACCESSOR METHODS                               *
 *                                                                             *
 ******************************************************************************/     
    
    /**
     * Overrides superclass method to return a cell editor for an individual cell.
     *
     * @param row the row index
     * @param column the column index
     * @return a cell editor
     */
    
    public TableCellEditor getCellEditor(int row, int column) { 
        Point2D index = new Point2D.Double(row,column);
        if(editors.containsKey(index)) {
            return (TableCellEditor)editors.get(index);
        }
        return super.getCellEditor(row,column); 
    }    
    
/*******************************************************************************
 *                                                                             *
 *                               MUTATOR METHODS                               *
 *                                                                             *
 ******************************************************************************/     
    
    /**
     * Sets the cell editors for the table model.
     *
     * @param eds the cell editors
     */
    
    public void setCellEditors(Object[][] eds) {
        editors = new HashMap(eds.length * eds[0].length);
        for(int i = 0; i < eds.length; i++) {
            for(int j = 0; j < eds[0].length; j++) {
                if(eds[i][j] != null) {
                    editors.put(new Point2D.Double(i,j),eds[i][j]);
                }
            }
        }
    }
    
    /**
     * Sets a cell editor for a specific cell in the table.
     *
     * @param editor the cell editor
     * @param row the row index
     * @param column the column index
     */
    
    public void setCellEditor(Object editor, int row, int column) {
        editors.put(new Point2D.Double(row,column),editor);
    }    
    
}
