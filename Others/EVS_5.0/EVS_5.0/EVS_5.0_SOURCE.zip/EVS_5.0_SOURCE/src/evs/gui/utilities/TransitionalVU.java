package evs.gui.utilities;

//EVS dependencies
import evs.analysisunits.*;
import evs.data.FileDataSource;
import evs.data.fileio.FileIO;
import java.io.File;

//Java dependencies
import java.util.*;
import javax.swing.table.DefaultTableModel;

/**
 * TODO: Consider implementing this class in future to clean-up the GUI code. 
 * However, one problem is the handling of checks across several VUs before finalizing
 * the transition for any individual VU. Currently, these checks include the 
 * opportunity to cancel (via cancel dialogs) if inconsistencies arise.
 * 
 * Class for storing an existing {@link evs.analysisunits.VerificationUnit} together
 * with a transitional dataset for updating the existing unit. The transitional
 * data comprises objects stored by integer IDs. Implement the transition method 
 * to update the existing unit with the transitional data. The transitional data
 * is distinct (i.e. separate objects in memory) from the saved data associated 
 * with the existing unit.
 * 
 * @author evs@hydrosolved.com
 */

public class TransitionalVU implements TransitionalUnit {

/*******************************************************************************
 *                                                                             *
 *                                VARIABLES                                    *
 *                                                                             *
 ******************************************************************************/   
    
    /**
     * Identifier for location ID.
     */    
    private static final int LOCATION_ID = 201;
    /**
     * Identifier for variable ID.
     */      
    private static final int VARIABLE_ID = 202;
    /**
     * Identifier for additional ID.
     */      
    private static final int ADDITIONAL_ID = 203;
    /**
     * Identifier for forecast data.
     */      
    private static final int FORECAST_DATA = 204;
    /**
     * Identifier for observed data.
     */      
    private static final int OBSERVED_DATA = 205;
    /**
     * Identifier for forecast time system.
     */      
    private static final int FORECAST_TIME_SYS = 206;
    /**
     * Identifier for observed time system.
     */      
    private static final int OBSERVED_TIME_SYS = 207;
    /**
     * Identifier for start year.
     */      
    private static final int START_YEAR = 208;
    /**
     * Identifier for start month.
     */      
    private static final int START_MONTH = 209;
    /**
     * Identifier for start day.
     */      
    private static final int START_DAY = 210;
    /**
     * Identifier for first lead time.
     */      
    private static final int FIRST_LEAD_TIME = 211;
    /**
     * Identifier for last lead time.
     */      
    private static final int LAST_LEAD_TIME = 212;
    /**
     * Identifier for lead time unit.
     */      
    private static final int LEAD_UNITS = 213;
    /**
     * Identifier for end year.
     */      
    private static final int END_YEAR = 214;
    /**
     * Identifier for end month.
     */      
    private static final int END_MONTH = 215;
    /**
     * Identifier for end day.
     */      
    private static final int END_DAY = 216;
    /**
     * Identifier for aggregation resolution.
     */      
    private static final int AGG_RES = 217;
    /**
     * Identifier for aggregation resolution units.
     */      
    private static final int AGG_RES_UNITS = 218;
    /**
     * Identifier for output data.
     */      
    private static final int OUTPUT_DATA = 219;
    /**
     * Identifier for forecast file type.
     */      
    private static final int FORECAST_FILE_TYPE = 220;
    /**
     * Identifier for observed file type.
     */      
    private static final int OBSERVED_FILE_TYPE = 221;
    
    /**
     * Local store of data associated with the verification units.  The data are 
     * stored in a map and indexed by their unique parameter identifiers provided
     * in this class.
     */
    
    private HashMap<Integer,Object> data = new HashMap<Integer,Object>();    
    
    /**
     * The current unit.
     */
    
    private VerificationUnit vu = null;
    
/*******************************************************************************
 *                                                                             *
 *                                CONSTRUCTOR                                  *
 *                                                                             *
 ******************************************************************************/
    
    /**
     * Constructs a transitional unit with an existing unit.
     * 
     * @param vu the input verification unit
     */
    
    public TransitionalVU(VerificationUnit vu) {
        this.vu=vu;
        data.put(LOCATION_ID, vu.getLocationID());
        data.put(VARIABLE_ID, vu.getVariableID());
        if (vu.hasAdditionalID()) {
            data.put(ADDITIONAL_ID, vu.getAdditionalID());
        }
        if (vu.hasForecastData()) {
            data.put(FORECAST_DATA, vu.getForecastData());
        }
        if (vu.getObservedData() instanceof FileDataSource) {
            data.put(OBSERVED_DATA, vu.getObservedData());
        }
        if (vu.hasForecastTimeSystem()) {
            data.put(FORECAST_TIME_SYS, vu.getForecastTimeSystem());
        }
        data.put(FORECAST_FILE_TYPE, FileIO.getFileTypeStringForID(vu.getForecastFileType()));

        if (vu.hasObservedTimeSystem()) {
            data.put(OBSERVED_TIME_SYS, vu.getObservedTimeSystem());
        }
        data.put(OBSERVED_FILE_TYPE, FileIO.getFileTypeStringForID(vu.getObservedFileType()));
        Calendar c = vu.getStartDate();
        if (c != null) {
            data.put(START_YEAR, c.get(c.YEAR) + "");
            data.put(START_MONTH, c.get(c.MONTH) + "");
            data.put(START_DAY, c.get(c.DAY_OF_MONTH) + "");
        }
        if (vu.hasLeadTimes()) {
            data.put(FIRST_LEAD_TIME, vu.getFirstLeadTime());
            data.put(LAST_LEAD_TIME, vu.getLastLeadTime());
            data.put(LEAD_UNITS, vu.getForecastLeadTimeUnits());
        }
        Calendar d = vu.getEndDate();
        if (d != null) {
            data.put(END_YEAR, d.get(d.YEAR) + "");
            data.put(END_MONTH, d.get(d.MONTH) + "");
            data.put(END_DAY, d.get(d.DAY_OF_MONTH) + "");
        }
        if (vu.hasResolution()) {
            data.put(AGG_RES, vu.getResolution());
            data.put(AGG_RES_UNITS, vu.getResolutionUnits());
        }
        if (vu.getOutputData() instanceof FileDataSource) {
            data.put(OUTPUT_DATA, ((File) vu.getOutputData().getData()).getAbsolutePath());
        }
    }
    
/*******************************************************************************
 *                                                                             *
 *                               MUTATOR METHODS                               *
 *                                                                             *
 ******************************************************************************/    
    
    /**
     * Updates a specified transitional parameter in the local store with the 
     * specified object. Throws an exception if the identifier is not recognized
     * or the class of the input object is inconsistent with the class of the 
     * stored temporary data
     * 
     * @param id the parameter identifier
     * @param value the parameter value
     */
    
    public void update(int id, Object value) throws IllegalArgumentException {
        if(!data.containsKey(id)) {
            throw new IllegalArgumentException("Unrecognized identifier for stored data "
                    + "associated with transitional unit '"+vu+"'");
        }
        if(value==null) {
            throw new IllegalArgumentException("Null data found: cannot update "
                    + "transitional unit '"+vu+"' with null data.");
        }
        if(!data.get(id).getClass().equals(value.getClass())) {
            throw new IllegalArgumentException("Unrecognized class for stored data "
                    + "associated with transitional unit '"+vu+"'. Expected: "+
                    data.get(id).getClass()+". Found :"+value.getClass());
        }
        data.put(id,value);
    }
    
    /**
     * Implements the transition between the local data and the existing unit.
     * 
     * It is critical that a transition is not finalized until all parameters
     * have been deemed valid. See {@link evs.gui.utilities.TransitionalUnit#testTransition()}
     * 
     * Throws an exception if any of the transitional data are invalid.
     */
    
    public void transition() throws IllegalArgumentException {
        vu = (VerificationUnit)testTransition();
    }
    
    /**
     * Tests the transition between the local data and the existing unit, returning
     * the transitioned unit, without updating the stored unit.
     * 
     * Throws an exception if any of the transitional data are invalid. Returns
     * the updated unit for convenience. 
     * 
     * @return the updated unit
     */
    
    public AnalysisUnit testTransition() throws IllegalArgumentException {
        return null;
    }    
    
    /**
     * Returns the stored verification unit. Specific implementations may decide whether
     * to return a deep copy of the stored unit, but care should be taken to avoid
     * inconsistency between the stored unit and the temporary parameter values.
     * 
     * @return the stored unit
     */
    
    public AnalysisUnit getStoredUnit() {
        return vu;
    }
    
    
}
