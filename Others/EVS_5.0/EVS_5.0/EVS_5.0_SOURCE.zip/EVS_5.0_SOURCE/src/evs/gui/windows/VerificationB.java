package evs.gui.windows;

//SwingWorker: use local version when backporting to Java 1.5
import javax.swing.SwingWorker;
//import evs.gui.utilities.SwingWorker;

//Java swing dependencies
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.html.*;
import javax.swing.table.*;
import javax.swing.event.*;

//Java awt dependencies
import java.awt.event.*;
import java.awt.*;

//Java util dependencies
import java.util.*;
import java.util.Map.Entry;

//Java net dependencies
import java.net.URL;

//Java beans dependencies
import java.beans.*;

//EVS dependencies
import evs.analysisunits.*;
import evs.analysisunits.scale.*;
import evs.metric.metrics.*;
import evs.metric.parameters.*;
import evs.gui.utilities.*;
import evs.utilities.*;
import evs.utilities.mathutil.*;
import evs.data.*;

/**
 * Allows a user to select verification statistics and their associated parameters
 * for a Verification Unit selected in the VerificationA window.  
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */
public class VerificationB extends JPanel implements GUIInterface {

    /********************************************************************************
     *                                                                              *
     *                               CONSTRUCTOR                                    *
     *                                                                              *
     *******************************************************************************/
    /**
     * Constructs the second verification window.
     */
    protected VerificationB() {
        initComponents();
        //Set the default metrics and tables
        setDefaultMetrics();
        setTables();

        //Enable html hyperlinking
        statisticTextPane.setEditorKit(new HTMLEditorKit());
        //Set statistic text pane editor
        statisticTextPane.setEditorKit(new HTMLEditorKit());
        statisticTextPane.setDocument(defaultDoc);
        statisticTextPane.setEditable(false);
        statisticTextPane.addHyperlinkListener(new HyperlinkListenerExtended());
        setVisible(true);
    }

    /********************************************************************************
     *                                                                              *
     *                           INHERITED PUBLIC METHODS                           *
     *                                                                              *
     *******************************************************************************/
    
    /**
     * Closes any open dialogs or frames associated with the GUI window.
     */
     
    public void disposeOfChildren() {
        if(parOptions!=null) {
            parOptions.dispose();
        }
    }
        
    /**
     * Clears the window and returns to default.
     */
    
    public void clearAllLocalData() {
        //Clear all parameter values
        int rows = statisticTable.getRowCount();
        for (int i = 0; i < rows; i++) {
            statisticTable.setValueAt(false, i, 2);
        }
        localPars.clear();
        setDefaultMetrics();
        clearDisplay(true);
        saveIndex = -1; //@29th Nov. 2011
    }

    /**
     * Saves the properties of the selected verification unit.
     *
     * @return true if the data were saved
     */
    public boolean saveData() throws IllegalArgumentException {
        if (VERIFICATION_A.unitIsSelected()) {
            //Update any recent changes to the selected metric
            saveLocalData();
            Vector<VerificationUnit> units = VERIFICATION_A.getVerificationUnits();
            int tot = units.size();
            //Iterate through the verification units, saving metrics to each one
            for (int u = 0; u < tot; u++) {
                VerificationUnit ver = units.get(u);
                LinkedHashMap<Metric, TreeMap<Integer, Object>> p = localPars.get(ver);
                //Set the parameters of the statistics
                if (p != null) {
                    int count = statisticTable.getRowCount();
                    boolean askedDelete = false;
                    for (int i = 0; i < count; i++) {
                        Metric next = (Metric) statisticTable.getValueAt(i, 0);
                        //Use existing metric if defined
                        if (ver.hasMetric(next.getName())) {
                            next = ver.getMetric(next.getName());
                        }

                        //Save metric
                        if (p.containsKey(next)) {
                            Metric copy = next.deepCopy();
                            TreeMap local = p.get(next);
                            TreeMap<Integer, MetricParameter> pars = new TreeMap();
                            //Thresholds
                            if (local.containsKey(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER)) {
                                int type = ((Integer) local.get(MetricParameter.INTEGER_PARAMETER));
                                //Copy pars
                                double[] thresh = (double[]) local.get(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER);
                                boolean[] main = (boolean[]) local.get(MetricParameter.BOOLEAN_ARRAY_PARAMETER);
                                String[] ids = (String[]) local.get(MetricParameter.STRING_ARRAY_PARAMETER);
                                boolean probs = (Boolean) local.get(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER);
                                try {
                                    //Store both probability thresholds and real-valued thresholds with the same
                                    //identifier for simplicity
                                    if (probs) {
                                        pars.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, new DoubleProcedureArrayParameter(
                                                new ProbabilityArrayParameter(thresh), type, probs,
                                                new BooleanArrayParameter(main),
                                                new StringArrayParameter(ids)));
                                    } else {
                                        pars.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER,
                                                new DoubleProcedureArrayParameter(new DoubleArrayParameter(thresh),
                                                type, probs, new BooleanArrayParameter(main),
                                                new StringArrayParameter(ids)));
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    if (probs) {
                                        throw new IllegalArgumentException("Could not create the probability thresholds for metric '" + copy + "'. "
                                                + e.getMessage());
                                    } else {
                                        throw new IllegalArgumentException("Could not create the thresholds for metric '" + copy + "': " + e.getMessage());
                                    }
                                }
                            }
                            //Reference forecasts
                            if (local.containsKey(MetricParameter.FORECAST_TYPE_PARAMETER)) {
                                //Copy pars
                                Vector v = new Vector();
                                //Add the regular forecast type by default
                                v.addAll((Vector) local.get(MetricParameter.FORECAST_TYPE_PARAMETER));
                                pars.put(MetricParameter.FORECAST_TYPE_PARAMETER, new ForecastTypeParameter(v));
                            }
                            //Decomposition
                            if (local.containsKey(MetricParameter.DECOMPOSE_PARAMETER)) {
                                DisplayScoreDecompPar s = (DisplayScoreDecompPar) local.get(MetricParameter.DECOMPOSE_PARAMETER);
                                pars.put(MetricParameter.DECOMPOSE_PARAMETER, s.getDecomposePar());
                            }
                            //Use unconditional pairs
                            if (local.containsKey(MetricParameter.UNCONDITIONAL_PARAMETER)) {
                                pars.put(MetricParameter.UNCONDITIONAL_PARAMETER, new UnconditionalParameter((Boolean) local.get(MetricParameter.UNCONDITIONAL_PARAMETER)));
                            }
                            //Use equal samples in reliability
                            if (local.containsKey(MetricParameter.EQUAL_SAMPLES_PARAMETER)) {
                                pars.put(MetricParameter.EQUAL_SAMPLES_PARAMETER, new EqualSamplesParameter((Boolean) local.get(MetricParameter.EQUAL_SAMPLES_PARAMETER)));
                            }
                            //ROC points
                            if (local.containsKey(MetricParameter.ROC_POINTS_PARAMETER)) {
                                try {
                                    pars.put(MetricParameter.ROC_POINTS_PARAMETER, new ROCPointsParameter(new Integer(local.get(MetricParameter.ROC_POINTS_PARAMETER) + "")));
                                } catch (NumberFormatException e) {
                                    throw new IllegalArgumentException("The ROC diagram requires a positive integer number of points to plot.");
                                }
                            }
                            //Fitted ROC
                            if (local.containsKey(MetricParameter.FITTED_ROC_PARAMETER)) {
                                pars.put(MetricParameter.FITTED_ROC_PARAMETER, new FittedROCParameter((Boolean) local.get(MetricParameter.FITTED_ROC_PARAMETER)));
                            }
                            //Fitted AUC
                            if (local.containsKey(MetricParameter.FITTED_AUC_PARAMETER)) {
                                pars.put(MetricParameter.FITTED_AUC_PARAMETER, new FittedAUCParameter((Boolean) local.get(MetricParameter.FITTED_AUC_PARAMETER)));
                            }
                            //ROC score points
                            if (local.containsKey(MetricParameter.ROC_SCORE_POINTS_PARAMETER)) {
                                try {
                                    pars.put(MetricParameter.ROC_SCORE_POINTS_PARAMETER, new ROCScorePointsParameter(new Integer(local.get(MetricParameter.ROC_SCORE_POINTS_PARAMETER) + "")));
                                } catch (NumberFormatException e) {
                                    throw new IllegalArgumentException("The ROC Score requires a positive integer number of points.");
                                }
                            }
                            //ROC score method
                            if (local.containsKey(MetricParameter.ROC_SCORE_METHOD_PARAMETER)) {
                                try {
                                    pars.put(MetricParameter.ROC_SCORE_METHOD_PARAMETER, new ROCScoreMethodParameter(new Integer(local.get(MetricParameter.ROC_SCORE_METHOD_PARAMETER) + "")));
                                } catch (NumberFormatException e) {
                                    throw new IllegalArgumentException("The ROC Score method requires an integer identifier.");
                                }
                            }
                            //Reliability points
                            if (local.containsKey(MetricParameter.RELIABILITY_POINTS_PARAMETER)) {
                                try {
                                    pars.put(MetricParameter.RELIABILITY_POINTS_PARAMETER, new ReliabilityPointsParameter(new Integer(local.get(MetricParameter.RELIABILITY_POINTS_PARAMETER) + "")));
                                } catch (NumberFormatException e) {
                                    throw new IllegalArgumentException("The reliability diagram requires a positive integer number of points to plot.");
                                }
                            }
                            //Spread-bias points
                            if (local.containsKey(MetricParameter.SPREAD_BIAS_POINTS_PARAMETER)) {
                                try {
                                    pars.put(MetricParameter.SPREAD_BIAS_POINTS_PARAMETER, new SpreadBiasPointsParameter(new Integer(local.get(MetricParameter.SPREAD_BIAS_POINTS_PARAMETER) + "")));
                                } catch (NumberFormatException e) {
                                    throw new IllegalArgumentException("The Talagrand diagram requires a positive integer number of bins for construction.");
                                }
                            }
                            //Talagrand centered on median
                            if (local.containsKey(MetricParameter.CENTRAL_SPREAD_BIAS_PARAMETER)) {
                                pars.put(MetricParameter.CENTRAL_SPREAD_BIAS_PARAMETER, new CentralSpreadBiasParameter(local.get(MetricParameter.CENTRAL_SPREAD_BIAS_PARAMETER).equals(true)));
                            }
                            //Rank histogram sample parameter
                            if (local.containsKey(MetricParameter.RANK_HIST_SAMPLE_PARAMETER)) {
                                pars.put(MetricParameter.RANK_HIST_SAMPLE_PARAMETER, new RankHistSampleParameter(local.get(MetricParameter.RANK_HIST_SAMPLE_PARAMETER).equals(true)));
                            }
                            //MCR points
                            if (local.containsKey(MetricParameter.MCR_POINTS_PARAMETER)) {
                                try {
                                    pars.put(MetricParameter.MCR_POINTS_PARAMETER, new MCRPointsParameter(new Integer(local.get(MetricParameter.MCR_POINTS_PARAMETER) + "")));
                                } catch (NumberFormatException e) {
                                    throw new IllegalArgumentException("The Mean Capture Rate diagram requires a positive integer number of points for construction.");
                                }
                            }
                            //CE points
                            if (local.containsKey(MetricParameter.MEP_POINTS_PARAMETER)) {
                                try {
                                    pars.put(MetricParameter.MEP_POINTS_PARAMETER, new MEPPointsParameter(new Integer(local.get(MetricParameter.MEP_POINTS_PARAMETER) + "")));
                                } catch (NumberFormatException e) {
                                    throw new IllegalArgumentException("The Climatological Error diagram requires a positive integer number of points for construction.");
                                }
                            }
                            //Pooled box points
                            if (local.containsKey(MetricParameter.BOX_POOLED_LEAD_POINTS_PARAMETER)) {
                                try {
                                    pars.put(MetricParameter.BOX_POOLED_LEAD_POINTS_PARAMETER, new BoxPooledLeadPointsParameter(new Integer(local.get(MetricParameter.BOX_POOLED_LEAD_POINTS_PARAMETER) + "")));
                                } catch (NumberFormatException e) {
                                    throw new IllegalArgumentException("The box plots require a positive integer number of thresholds for construction.");
                                }
                            }
                            //Unpooled box points
                            if (local.containsKey(MetricParameter.BOX_UNPOOLED_POINTS_PARAMETER)) {
                                try {
                                    pars.put(MetricParameter.BOX_UNPOOLED_POINTS_PARAMETER, new BoxUnpooledPointsParameter(new Integer(local.get(MetricParameter.BOX_UNPOOLED_POINTS_PARAMETER) + "")));
                                } catch (NumberFormatException e) {
                                    throw new IllegalArgumentException("The box plots require a positive integer number of thresholds for construction.");
                                }
                            }
                            //Unpooled box points by obs
                            if (local.containsKey(MetricParameter.BOX_UNPOOLED_OBS_POINTS_PARAMETER)) {
                                try {
                                    pars.put(MetricParameter.BOX_UNPOOLED_OBS_POINTS_PARAMETER, new BoxUnpooledObsPointsParameter(new Integer(local.get(MetricParameter.BOX_UNPOOLED_OBS_POINTS_PARAMETER) + "")));
                                } catch (NumberFormatException e) {
                                    throw new IllegalArgumentException("The box plots require a positive integer number of thresholds for construction.");
                                }
                            }
                            //Reference forecast parameter
                            if (local.containsKey(MetricParameter.REFERENCE_FORECAST_PARAMETER)) {
                                ReferenceForecastParameter ref = new ReferenceForecastParameter();
                                DisplayReferencePar s = (DisplayReferencePar) local.get(MetricParameter.REFERENCE_FORECAST_PARAMETER);
                                if (s.getSelectedIndex() > -1) {
                                    if (!s.toString().contains("None available")) {
                                        ref.setRefForecast(s.toString());
                                    }
                                }
                                //Add if valid reference selected
                                if (ref.hasRefForecast()) {
                                    pars.put(MetricParameter.REFERENCE_FORECAST_PARAMETER, ref);
                                } else {
                                    throw new IllegalArgumentException("Select a valid reference forecast for each selected skill metric.");
                                }
                            }
                            //Vector function
                            if (local.containsKey(MetricParameter.VECTOR_FUNCTION_PARAMETER)) {
                                pars.put(MetricParameter.VECTOR_FUNCTION_PARAMETER,
                                        new VectorFunctionParameter((VectorFunction) local.get(MetricParameter.VECTOR_FUNCTION_PARAMETER)));
                            }
                            //Bootstrap parameter
                            if (local.containsKey(MetricParameter.BOOTSTRAP_PARAMETER)) {
                                pars.put(MetricParameter.BOOTSTRAP_PARAMETER,
                                        (BootstrapParameter) local.get(MetricParameter.BOOTSTRAP_PARAMETER));
                            }
                            //Sample size parameter
                            if (local.containsKey(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER)) {
                                 try {
                                    pars.put(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER, new MinimumSampleSizeParameter(new Integer(local.get(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER) + "")));
                                } catch (NumberFormatException e) {
                                    throw new IllegalArgumentException("The minimum sample size must be numeric: "+local.get(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER));
                                }
                            }

                            //Set the parameters in the correct order
                            int length = pars.size();
                            MetricParameter[] finalPars = new MetricParameter[length];
                            int[] types = copy.getParTypes();
                            for (int j = 0; j < length; j++) {
                                finalPars[j] = pars.get(types[j]);
                            }

                            //Set the parameters before adding the metric, as adding metric will check results
                            copy.setParameters(finalPars);

                            //Warn in case of data deletion when results already exist
                            if (!askedDelete && ver.hasMetric(next.toString()) && ver.getMetric(next.toString()).willVoidResult(finalPars)) {
                                askedDelete = true;
                                String message = "These changes will overwrite previously computed verification results for " + ver + " and any associated aggregation units.";
                                int n = JOptionPane.showOptionDialog(EVSMainWindow.main,message+"  Continue?", "Warning: data changes", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, null, null, null);
                                System.out.println("WARNING: potential data changes. "+message);
                                if (n == JOptionPane.YES_OPTION) {
                                    //Clear results
                                    ver.clearAllMetricResults();
                                    if (ver.hasAggregationUnit()) {
                                        //JB @ 11th March 2013
                                        ArrayList<AggregationUnit> agg = ver.getAggregationUnits();
                                        for(AggregationUnit a : agg) {
                                            a.clearAllMetricResults();
                                        }
                                    }
                                    copy.clearResults();
                                    ver.addMetric(copy);
                                    //Update output dialog
                                    OUTPUT_A.updateLocalData(ver);
                                } else {
                                    return false;
                                }
                            } //Add the new metric
                            else {
                                if (ver.hasMetric(next.toString()) && ver.getMetric(next.toString()).willVoidResult(finalPars)) {
                                    ver.clearAllMetricResults();
                                    copy.clearResults();
                                    //Update output dialog
                                    OUTPUT_A.updateLocalData(ver);
                                }
                                ver.addMetric(copy);
                            }
                        } //Remove
                        else {
                            //Warn in case of data deletion when results already exist
                            if (ver.hasMetric(next.toString()) && ver.getMetric(next.toString()).hasResults()) {
                                if (!askedDelete) {
                                    askedDelete = true;
                                    String message = "These changes will delete previously computed verification results for " + ver + " and any associated aggregation units.";
                                    int n = JOptionPane.showOptionDialog(EVSMainWindow.main, message+"  Continue?", "Warning: data changes", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, null, null, null);
                                    System.out.println("WARNING: potential data changes. "+message);
                                    if (n == JOptionPane.YES_OPTION) {
                                        //UPDATE: 07/14/09
                                        ver.deleteMetric(next.toString());
                                        if (ver.hasAggregationUnit()) {
                                            //JB @ 11th March 2013
                                            ArrayList<AggregationUnit> agg = ver.getAggregationUnits();
                                            for (AggregationUnit a : agg) {
                                                OUTPUT_A.updateLocalData(a);
                                            }
                                        }
                                    } else {
                                        return false;
                                    }
                                } else {
                                    ver.deleteMetric(next.toString());
                                }
                            } else {
                                ver.deleteMetric(next.toString());
                            }
                            OUTPUT_A.updateLocalData(ver); //UPDATE: 07/09/09
                        }
                    }
                }
            }
            OUTPUT_A.showLocalData();
            return true;
        }
        OUTPUT_A.showLocalData();
        return false;
    }

    /**
     * Saves local data in the active input fields to a temporary store.
     */
    public void saveLocalData() {
        if (saveIndex > -1 && hasLocalPars()) {
            Metric stat = (Metric) statisticTable.getValueAt(saveIndex, 0);
            VerificationUnit ver = VERIFICATION_A.getSelectedUnit();
            LinkedHashMap<Metric, TreeMap<Integer, Object>> p = localPars.get(ver);
            if (p != null && p.containsKey(stat)) {
                TreeMap pars = p.get(stat);
                //Probabilities (note that the threshold type and whether the values are
                //probabilities is edited in the advanced options dialog)
                if (pars.containsKey(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER)) {
                    Object[] thresh = getLocalThresholds();
                    pars.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, thresh[0]);
                    pars.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, thresh[1]);
                    pars.put(MetricParameter.STRING_ARRAY_PARAMETER, thresh[2]);
                }
                if (pars.containsKey(MetricParameter.FORECAST_TYPE_PARAMETER)) {
                    Vector<Integer> v = new Vector();
                    //Regular forecast by default
                    v.add(ForecastTypeParameter.REGULAR_FORECAST);
                    pars.put(MetricParameter.FORECAST_TYPE_PARAMETER, v);
                }
            }
        }
    }

    /**
     * Displays the local data previously saved to a temporary store.  Local data
     * should always be displayed in preference to saved data, because saved data
     * should be used to update the store of local data once available.
     */
    public void showLocalData() {
        int row = statisticTable.getSelectedRow();
        //Clear the existing display, but not the selected row
        clearDisplay(false);

        //Update the table display
        if (VERIFICATION_A.unitIsSelected()) {
            VerificationUnit vu = VERIFICATION_A.getSelectedUnit();

            int rows = statisticTable.getRowCount();
            LinkedHashMap<Metric, TreeMap<Integer, Object>> p = localPars.get(vu);

            for (int i = 0; i < rows; i++) {
                statisticTable.setValueAt((p != null && p.containsKey(statisticTable.getValueAt(i, 0))), i, 2);
            }

            //Set the new display
            if (row > -1) {
                TreeMap pars = null;
                Metric m = (Metric) statisticTable.getValueAt(row, 0);
                if (p != null && p.containsKey(m)) {
                    pars = p.get(m);
                } //Default pars
                else {
                    pars = defaultMetrics.get(m);
                }
                //Enable the parameters and statistics explanation boxes
                setParBoxEnabledState();
                setStatTextBox();

                //Display the parameters if the statistic is selected
                if (pars.containsKey(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER)) {
                    ((DefaultTableModel) thresholdTable.getModel()).setRowCount(0);
                    double[] data = (double[]) pars.get(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER);
                    boolean[] main = (boolean[]) pars.get(MetricParameter.BOOLEAN_ARRAY_PARAMETER);
                    String[] ids = (String[]) pars.get(MetricParameter.STRING_ARRAY_PARAMETER);
                    for (int i = 0; i < data.length; i++) {
                        if (Double.isInfinite(data[i])) {
                            ((DefaultTableModel) thresholdTable.getModel()).addRow(new Object[]{"All data", ids[i], main[i]});
                        } else {
                            ((DefaultTableModel) thresholdTable.getModel()).addRow(new Object[]{data[i], ids[i], main[i]});
                        }
                        //Listen for changes and save data
                        //Add the listeners
                        final TableCellEditor ed = thresholdTable.getCellEditor(i, 0);
                        ed.addCellEditorListener(new CellEditorListener() {

                            public void editingStopped(ChangeEvent evt) {
                                saveLocalData();
                            }

                            public void editingCanceled(ChangeEvent evt) {
                            }
                        });
                    }
                }
            }
        }
    }

    /**
     * Updates local data with a saved AnalysisUnit.
     *
     * @param unit the unit
     */
    public void updateLocalData(AnalysisUnit unit) {
        //Set the saved statistics
    	if (unit != null && unit instanceof VerificationUnit) {
            VerificationUnit u = (VerificationUnit) unit;
            LinkedHashMap<Metric, TreeMap<Integer, Object>> sel = localPars.get(u);
            //Initialize if required
            if (sel == null) {
                sel = new LinkedHashMap();
                localPars.put(u, sel);
            }
            Metric[] mets = defaultMetrics.keySet().toArray(new Metric[defaultMetrics.size()]);
            for (int i = 0; i < mets.length; i++) {
                Metric next = mets[i];
                if (u.hasMetric(next.toString())) {
                    Metric addMe = u.getMetric(next.toString());
                    
                    //Update the local data
                    MetricParameter[] m = addMe.getParameters();
                    TreeMap<Integer, Object> local = new TreeMap();
                    for (int j = 0; j < m.length; j++) {
                        if (m[j] instanceof DoubleProcedureArrayParameter) {
                            //Add the threshold type
                            DoubleProcedureArrayParameter par = (DoubleProcedureArrayParameter) m[j];
                            local.put(MetricParameter.INTEGER_PARAMETER, par.getThresholdType().getParVal());
                            local.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, par.getThresholdValuesAsDoubleArray());
                            local.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, par.getMainThresholds().getParVal());
                            local.put(MetricParameter.STRING_ARRAY_PARAMETER, par.getThresholdIDs().getParVal());
                            local.put(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER, par.areProbs().getParVal());
                        } else if (m[j] instanceof ForecastTypeParameter) {
                            local.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) m[j]).getTypes());
                        } else if (m[j] instanceof DecomposeParameter) {
                            int b = ((DecomposeParameter) m[j]).getScoreDecType();
                            ThresholdMetricStore s = ((ThresholdMetricStore) next);
                            DecomposableScore score = (DecomposableScore) s.getFirstMetricInStore();
                            DisplayScoreDecompPar p = new DisplayScoreDecompPar(score.getDecompositionOptions(), b);
                            local.put(MetricParameter.DECOMPOSE_PARAMETER, p);
                        } else if (m[j] instanceof UnconditionalParameter) {
                            local.put(MetricParameter.UNCONDITIONAL_PARAMETER, ((UnconditionalParameter) m[j]).getParVal());
                        } else if (m[j] instanceof FittedROCParameter) {
                            local.put(MetricParameter.FITTED_ROC_PARAMETER, ((FittedROCParameter) m[j]).getParVal());
                        } else if (m[j] instanceof FittedAUCParameter) {
                            local.put(MetricParameter.FITTED_AUC_PARAMETER, ((FittedAUCParameter) m[j]).getParVal());
                        } else if (m[j] instanceof ROCScoreMethodParameter) {
                            local.put(MetricParameter.ROC_SCORE_METHOD_PARAMETER, ((ROCScoreMethodParameter) m[j]).getParVal());
                        } else if (m[j] instanceof EqualSamplesParameter) {
                            local.put(MetricParameter.EQUAL_SAMPLES_PARAMETER, ((EqualSamplesParameter) m[j]).getParVal());
                        } else if (m[j] instanceof CentralSpreadBiasParameter) {
                            local.put(MetricParameter.CENTRAL_SPREAD_BIAS_PARAMETER, ((CentralSpreadBiasParameter) m[j]).getParVal());
                        } else if (m[j] instanceof RankHistSampleParameter) {
                            local.put(MetricParameter.RANK_HIST_SAMPLE_PARAMETER, ((RankHistSampleParameter) m[j]).getParVal());
                        } else if (m[j] instanceof IntegerParameter) {  //Store points as string locally
                            local.put(((IntegerParameter) m[j]).getID(), ((IntegerParameter) m[j]).getParVal() + "");
                        } else if (m[j] instanceof VectorFunctionParameter) {
                            local.put(MetricParameter.VECTOR_FUNCTION_PARAMETER, ((VectorFunctionParameter) m[j]).getParVal());
                        } else if (m[j] instanceof ReferenceForecastParameter) {
                            //Display all available forecasts except the current one
                            Vector<VerificationUnit> a = VERIFICATION_A.getVerificationUnits();
                            Vector<String> name = new Vector<String>();
                            int tot = a.size();
                            String selected = u.toString();
                            for (int k = 0; k < tot; k++) {
                                String nxt = a.get(k).toString();
                                if (!nxt.equals(selected)) {
                                    name.add(nxt);
                                }
                            }
                            //Add any default reference forecasts for the current metric
                            if (next instanceof ThresholdMetricStore) {
                                ThresholdMetricStore st = ((ThresholdMetricStore) next);
                                Metric score = (Metric) st.getFirstMetricInStore();
                                if (score instanceof SkillScore) {
                                    if (((SkillScore) score).hasDefaultRefFcst()) {
                                        String ref = ((SkillScore) score).getDefaultRefFcst().getParVal();
                                        if (!name.contains(ref)) {
                                            name.add(ref);
                                        }
                                    }
                                }
                            }

                            DisplayReferencePar p = new DisplayReferencePar();
                            String[] n = name.toArray(new String[name.size()]);
                            p.setRefFcsts(n);
                            if (((ReferenceForecastParameter) m[j]).hasRefForecast()) {
                                String sl = ((ReferenceForecastParameter) m[j]).getParVal();
                                p.setSelectedIndex(StringUtilities.indexOf(n, sl));
                            }
                            local.put(MetricParameter.REFERENCE_FORECAST_PARAMETER, p);
                        } else if (m[j] instanceof BootstrapParameter) {
                            local.put(MetricParameter.BOOTSTRAP_PARAMETER, m[j].deepCopy());
                        } else if (m[j] instanceof MinimumSampleSizeParameter) {
                            local.put(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER, m[j].deepCopy());
                        }
                    }
                    //Save the local parameters
                    sel.put(next, local);
                } 
                //Update parameters for which a local store exists and the first window affects
                //the stored parameters, such as reference forecasts.  When a local store doesn't
                //yet exist (e.g. a skill metric just selected for inclusion, for which only the defaultMetrics
                //have so far been defined), the update is handled by updateLocalStore()
                else {
                      //JB@August 2012 (two lines commented)
                    TreeMap<Integer, Object> pars = sel.get(next);
                    updateRefFcsts(next,pars);
                                        
                    
//                    if (pars != null && pars.containsKey(MetricParameter.REFERENCE_FORECAST_PARAMETER)) {
//                        Vector<VerificationUnit> a = VERIFICATION_A.getVerificationUnits();
//                        Vector<String> name = new Vector<String>();
//                        int tot = a.size();
//                        String selected = VERIFICATION_A.getSelectedUnit().toString();
//                        for (int k = 0; k < tot; k++) {
//                            String nxt = a.get(k).toString();
//                            if (!nxt.equals(selected)) {
//                                name.add(nxt);
//                            }
//                        }
//                        DisplayReferencePar p = new DisplayReferencePar();
//                        //Set if potential reference forecasts available
//                        if (name.size() > 0) {
//                            p.setRefFcsts(name.toArray(new String[name.size()]));
//                        }
//                        pars.put(MetricParameter.REFERENCE_FORECAST_PARAMETER, p);
//                    }
                    
                }
            }
            ((TitledBorder) mainPanel.getBorder()).setTitle("Verification metrics to compute for unit '" + unit.toString() + "'");
        }
        runAllButton.setEnabled(VERIFICATION_A.getVerificationUnits().size() > 1);
    }

    /**
     * Removes local data from the temporary store for a specified AnalysisUnit. 
     *
     * @param unit the unit
     */
    public void clearLocalData(AnalysisUnit unit) {
        localPars.remove(unit);
    }

    /**
     * Allows an external parameter editor to set the local parameters following
     * editing.
     *
     * @param m the metric
     * @param pars the parameters
     */
    protected void setParameters(Metric m, TreeMap<Integer, Object> pars) {
        if (!VERIFICATION_A.unitIsSelected()) {
            throw new IllegalArgumentException("Cannot set parameters for metric '" + m + "': no Verification Unit selected.");
        }
        LinkedHashMap<Metric, TreeMap<Integer, Object>> map = localPars.get(VERIFICATION_A.getSelectedUnit());
        if (map == null) {
            throw new IllegalArgumentException("Cannot set parameters for metric '" + m + "': cannot find unit '" + VERIFICATION_A.getSelectedUnit() + "' in parameter map.");
        }
        if (!map.containsKey(m)) {
            throw new IllegalArgumentException("Cannot set parameters for metric '" + m + "': cannot find metric in parameter map.");
        }
        TreeMap<Integer, Object> p = map.get(m);
        if (!p.keySet().equals(pars.keySet())) {
            throw new IllegalArgumentException("Cannot set parameters for metric '" + m + "': the number or types of input parameters differ from those in the local store.");
        }
        map.put(m, pars);
    }

    /**
     * Returns a (possibly empty) vector of bootstrap parameters for the locally
     * stored metrics.
     *
     * @return the local bootstrap parameters
     */
    protected Vector<BootstrapParameter> getBootstrapPars() {
        Vector<BootstrapParameter> returnMe = new Vector<BootstrapParameter>();
        VerificationUnit v = VERIFICATION_A.getSelectedUnit();
        if (v != null && localPars.containsKey(v)) {
            LinkedHashMap<Metric, TreeMap<Integer, Object>> p = localPars.get(v);
            Iterator it = p.entrySet().iterator();
            while (it.hasNext()) {
                Entry e = (Entry) it.next();
                TreeMap<Integer, Object> nx = (TreeMap<Integer, Object>) e.getValue();
                Iterator it2 = nx.entrySet().iterator();
                while (it2.hasNext()) {
                    Entry e2 = (Entry) it2.next();
                    if (e2.getValue() instanceof BootstrapParameter) {
                        returnMe.add((BootstrapParameter) e2.getValue());
                    }
                }
            }
        }
        return returnMe;
    }
    
    /**
     * Synchronizes the unique identifiers of a verification unit in the 
     * local store. Replace the names in the local store at a given index in the
     * first array argument with the names of units at the corresponding index of the 
     * second argument. This allows VUs to be updated without removing the local
     * data store of (unsaved) parameters.
     *    
     * @param oldU the old verification units
     * @param newU the new verification units
     */
    
    protected void synchronizeVUNames(VerificationUnit[] oldU, VerificationUnit[] newU) {      
        if(oldU.length!=newU.length) {
            throw new IllegalArgumentException("Specify two arrays of equal length for remapping reference forecasts.");
        }

        //Change the parameters of the localPars first, then update the keys
        //do NOT update the keys (VU identifiers) during the iteration
        for(Iterator i = localPars.keySet().iterator(); i.hasNext();) {
            //Rename the VUs used as keys in the local data store
            VerificationUnit v = (VerificationUnit)i.next(); 
            LinkedHashMap<Metric, TreeMap<Integer, Object>> r = localPars.get(v);

            //Check for any reference forecasts and replace IDs as necessary
            String last = "";
            Iterator it2 = r.keySet().iterator();
            while (it2.hasNext()) {
                Metric key = (Metric) it2.next();
                TreeMap<Integer, Object> next2 = r.get(key);
                DisplayReferencePar ob =
                        (DisplayReferencePar) next2.get(MetricParameter.REFERENCE_FORECAST_PARAMETER);
                if (ob != null) {
                    String[] fcsts = ob.getRefFcsts();
                    int selIndex = ob.getSelectedIndex();  //Store the current index selection, which will not change
                    //Check each reference forecast for one of the old unit names and replace as necessary
                    //This must be done for all units
                    for(int m = 0; m < oldU.length; m++) {
                        String oldID = oldU[m].toString();
                        String newID = newU[m].toString();
                        if (!oldID.equals(newID)) {
                            for (int k = 0; k < fcsts.length; k++) {
                                if (fcsts[k].equals(oldID)) {
                                    String message = "Updating reference forecast option for metric "+key+" of unit " + v + " from " + oldID + " to " + newID;
                                    if(!message.equals(last)) {
                                        System.out.println(message);
                                        last = message;
                                    }
                                    fcsts[k] = newID;
                                    break;  //Reference can only appear once
                                }
                            }
                        }
                    }
                    ob.setRefFcsts(fcsts);
                    ob.setSelectedIndex(selIndex);  //Replace the index selection
                }
            }
        }
        
        //Update keys
        LinkedHashMap<VerificationUnit, LinkedHashMap<Metric,
            TreeMap<Integer, Object>>> replacedPars = new LinkedHashMap();        
        Object[] keys = localPars.keySet().toArray();
        for(int i = 0; i < keys.length; i++) {
            VerificationUnit key = (VerificationUnit)keys[i];
            LinkedHashMap<Metric,TreeMap<Integer, Object>> data = localPars.get(key);
            for(int j = 0; j < oldU.length; j++) {
                if(oldU[j].toString().equals(key.toString())) {
                    key.setLocationID(newU[j].getLocationID());
                    key.setVariableID(newU[j].getVariableID());
                    key.setAdditionalID(newU[j].getAdditionalID());
                    break;
                }
            } 
            replacedPars.put(key,data);
        }
        
        localPars = replacedPars;
        
        //Check
//        for(Iterator i = replacedPars.keySet().iterator(); i.hasNext();) {
//            //Rename the VUs used as keys in the local data store
//            VerificationUnit v = (VerificationUnit)i.next(); 
//            LinkedHashMap<Metric, TreeMap<Integer, Object>> r = replacedPars.get(v);
//            Iterator it2 = r.keySet().iterator();        
//            while(it2.hasNext()) {
//                Metric m = (Metric)it2.next();
//                TreeMap<Integer, Object> pars = r.get(m);
//                if(pars.containsKey(MetricParameter.REFERENCE_FORECAST_PARAMETER)) {
//                    DisplayReferencePar s = (DisplayReferencePar)pars.get(MetricParameter.REFERENCE_FORECAST_PARAMETER);
//                    System.out.println("Found reference "+s+" for metric "+m +" of unit "+v);
//                }
//            }
//        
//        }
        
    }    

    /********************************************************************************
     *                                                                              *
     *                               PRIVATE METHODS                                *
     *                                                                              *
     *******************************************************************************/
    /**
     * Sets the default metrics for the specified unit.
     */
    private void setDefaultMetrics() {
        //Add to the store in the order required for presentation together with
        //their default parameter values in local format
        ForecastTypeParameter type = new ForecastTypeParameter();

        //Default condition for the threshold parameters
        int tCond = DoubleProcedureParameter.GREATER_THAN;

        //Sample size: not a verification metric
        ThresholdMetricStore.setDefaultMetricClass(SampleSize.class);
        ThresholdMetricStore ss = (ThresholdMetricStore) ThresholdMetricStore.getDefaultMetric();        
        TreeMap tss = new TreeMap();
        double[] pass = ss.getDefProbThresh(SampleSize.class).getThresholdValuesAsDoubleArray();
        tss.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) type.deepCopy()).getTypes());
        tss.put(MetricParameter.INTEGER_PARAMETER, tCond);
        tss.put(MetricParameter.UNCONDITIONAL_PARAMETER, false);
        tss.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, pass);
        tss.put(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER, true);
        tss.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, getTrueBoolArr(pass.length));
        tss.put(MetricParameter.STRING_ARRAY_PARAMETER, new String[pass.length]);
        defaultMetrics.put(ss, tss);

        //Correlation
        ThresholdMetricStore.setDefaultMetricClass(Correlation.class);
        ThresholdMetricStore a = (ThresholdMetricStore) ThresholdMetricStore.getDefaultMetric();        
        TreeMap t1 = new TreeMap();
        double[] pa = a.getDefProbThresh(Correlation.class).getThresholdValuesAsDoubleArray();
        t1.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) type.deepCopy()).getTypes());
        t1.put(MetricParameter.INTEGER_PARAMETER, tCond);
        t1.put(MetricParameter.UNCONDITIONAL_PARAMETER, false);
        t1.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, pa);
        t1.put(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER, true);
        t1.put(MetricParameter.VECTOR_FUNCTION_PARAMETER, FunctionLibrary.mean());
        t1.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, getTrueBoolArr(pa.length));
        t1.put(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER, new MinimumSampleSizeParameter());
        t1.put(MetricParameter.BOOTSTRAP_PARAMETER, new BootstrapParameter());
        t1.put(MetricParameter.STRING_ARRAY_PARAMETER, new String[pa.length]);
        defaultMetrics.put(a, t1);
        
        //Mean error
        ThresholdMetricStore.setDefaultMetricClass(MeanError.class);
        ThresholdMetricStore b = (ThresholdMetricStore) ThresholdMetricStore.getDefaultMetric();        
        TreeMap t2 = new TreeMap();
        double[] pb = b.getDefProbThresh(MeanError.class).getThresholdValuesAsDoubleArray();
        t2.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, pb);
        t2.put(MetricParameter.INTEGER_PARAMETER, tCond);
        t2.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) type.deepCopy()).getTypes());
        t2.put(MetricParameter.UNCONDITIONAL_PARAMETER, false);
        t2.put(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER, true);
        t2.put(MetricParameter.VECTOR_FUNCTION_PARAMETER, FunctionLibrary.mean());
        t2.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, getTrueBoolArr(pb.length));
        t2.put(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER, new MinimumSampleSizeParameter());
        t2.put(MetricParameter.BOOTSTRAP_PARAMETER, new BootstrapParameter());
        t2.put(MetricParameter.STRING_ARRAY_PARAMETER, new String[pb.length]);
        defaultMetrics.put(b, t2);
        
        //Relative mean error
        ThresholdMetricStore.setDefaultMetricClass(RelativeMeanError.class);
        ThresholdMetricStore bb = (ThresholdMetricStore) ThresholdMetricStore.getDefaultMetric();
        TreeMap t2b = new TreeMap();
        double[] pbb = bb.getDefProbThresh(RelativeMeanError.class).getThresholdValuesAsDoubleArray();
        t2b.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, pbb);
        t2b.put(MetricParameter.INTEGER_PARAMETER, tCond);
        t2b.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) type.deepCopy()).getTypes());
        t2b.put(MetricParameter.UNCONDITIONAL_PARAMETER, false);
        t2b.put(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER, true);
        t2b.put(MetricParameter.VECTOR_FUNCTION_PARAMETER, FunctionLibrary.mean());
        t2b.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, getTrueBoolArr(pbb.length));
        t2b.put(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER, new MinimumSampleSizeParameter());
        t2b.put(MetricParameter.BOOTSTRAP_PARAMETER, new BootstrapParameter());
        t2b.put(MetricParameter.STRING_ARRAY_PARAMETER, new String[pbb.length]);
        defaultMetrics.put(bb, t2b);
        
        //Mean absolute error
        ThresholdMetricStore.setDefaultMetricClass(MeanAbsoluteError.class);
        ThresholdMetricStore c = (ThresholdMetricStore) ThresholdMetricStore.getDefaultMetric();        
        TreeMap t3 = new TreeMap();
        double[] pc = c.getDefProbThresh(MeanAbsoluteError.class).getThresholdValuesAsDoubleArray();
        t3.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, pc);
        t3.put(MetricParameter.INTEGER_PARAMETER, tCond);
        t3.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) type.deepCopy()).getTypes());
        t3.put(MetricParameter.UNCONDITIONAL_PARAMETER, false);
        t3.put(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER, true);
        t3.put(MetricParameter.VECTOR_FUNCTION_PARAMETER, FunctionLibrary.mean());
        t3.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, getTrueBoolArr(pc.length));
        t3.put(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER, new MinimumSampleSizeParameter());
        t3.put(MetricParameter.BOOTSTRAP_PARAMETER, new BootstrapParameter());
        t3.put(MetricParameter.STRING_ARRAY_PARAMETER, new String[pc.length]);
        defaultMetrics.put(c, t3);
        
        //RMSE
        ThresholdMetricStore.setDefaultMetricClass(RootMeanSquareError.class);
        ThresholdMetricStore d = (ThresholdMetricStore) ThresholdMetricStore.getDefaultMetric();        
        TreeMap t4 = new TreeMap();
        double[] pd = d.getDefProbThresh(RootMeanSquareError.class).getThresholdValuesAsDoubleArray();
        t4.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, pd);
        t4.put(MetricParameter.INTEGER_PARAMETER, tCond);
        t4.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) type.deepCopy()).getTypes());
        t4.put(MetricParameter.UNCONDITIONAL_PARAMETER, false);
        t4.put(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER, true);
        t4.put(MetricParameter.VECTOR_FUNCTION_PARAMETER, FunctionLibrary.mean());
        t4.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, getTrueBoolArr(pd.length));
        t4.put(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER, new MinimumSampleSizeParameter());
        t4.put(MetricParameter.BOOTSTRAP_PARAMETER, new BootstrapParameter());
        t4.put(MetricParameter.STRING_ARRAY_PARAMETER, new String[pd.length]);
        defaultMetrics.put(d, t4);
        
        //Brier
        ThresholdMetricStore.setDefaultMetricClass(BrierScore.class);
        ThresholdMetricStore e = (ThresholdMetricStore) ThresholdMetricStore.getDefaultMetric();        
        TreeMap t5 = new TreeMap();
        double[] pe = e.getDefProbThresh(BrierScore.class).getThresholdValuesAsDoubleArray();
        t5.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, pe);
        t5.put(MetricParameter.INTEGER_PARAMETER, tCond);
        t5.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) type.deepCopy()).getTypes());
        DecomposableScore t5Score = (DecomposableScore) e.getFirstMetricInStore();
        DisplayScoreDecompPar t5Par = new DisplayScoreDecompPar(t5Score.getDecompositionOptions(),
                t5Score.NONE);
        t5.put(MetricParameter.DECOMPOSE_PARAMETER, t5Par);
        t5.put(MetricParameter.UNCONDITIONAL_PARAMETER, false);
        t5.put(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER, true);
        t5.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, getTrueBoolArr(pe.length));
        t5.put(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER, new MinimumSampleSizeParameter());
        t5.put(MetricParameter.BOOTSTRAP_PARAMETER, new BootstrapParameter());
        t5.put(MetricParameter.STRING_ARRAY_PARAMETER, new String[pe.length]);
        defaultMetrics.put(e, t5);
        
        //CRPS
        ThresholdMetricStore.setDefaultMetricClass(MeanContRankProbScore.class);
        ThresholdMetricStore f = (ThresholdMetricStore) ThresholdMetricStore.getDefaultMetric();        
        TreeMap t6 = new TreeMap();
        double[] pf = f.getDefProbThresh(MeanContRankProbScore.class).getThresholdValuesAsDoubleArray();
        t6.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, pf);
        t6.put(MetricParameter.INTEGER_PARAMETER, tCond);
        t6.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) type.deepCopy()).getTypes());
        DecomposableScore t6Score = (DecomposableScore) f.getFirstMetricInStore();
        DisplayScoreDecompPar t6Par = new DisplayScoreDecompPar(t6Score.getDecompositionOptions(),
                t6Score.NONE);
        t6.put(MetricParameter.DECOMPOSE_PARAMETER, t6Par);
        t6.put(MetricParameter.UNCONDITIONAL_PARAMETER, false);
        t6.put(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER, true);
        t6.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, getTrueBoolArr(pf.length));
        t6.put(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER, new MinimumSampleSizeParameter());
        t6.put(MetricParameter.BOOTSTRAP_PARAMETER, new BootstrapParameter());
        t6.put(MetricParameter.STRING_ARRAY_PARAMETER, new String[pf.length]);
        defaultMetrics.put(f, t6);
        
        //MEPD
        ThresholdMetricStore.setDefaultMetricClass(MeanErrorOfProbabilityDiagram.class);
        ThresholdMetricStore g = (ThresholdMetricStore) ThresholdMetricStore.getDefaultMetric();        
        TreeMap t7 = new TreeMap();
        int count = MeanErrorOfProbabilityDiagram.getDefaultPointCount().getParVal();
        double[] pg = g.getDefProbThresh(MeanErrorOfProbabilityDiagram.class).getThresholdValuesAsDoubleArray();
        t7.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, pg);
        t7.put(MetricParameter.INTEGER_PARAMETER, tCond);
        t7.put(MetricParameter.MEP_POINTS_PARAMETER, count + "");
        t7.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) type.deepCopy()).getTypes());
        t7.put(MetricParameter.UNCONDITIONAL_PARAMETER, false);
        t7.put(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER, true);
        t7.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, getTrueBoolArr(pg.length));
        t7.put(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER, new MinimumSampleSizeParameter());
        t7.put(MetricParameter.BOOTSTRAP_PARAMETER, new BootstrapParameter());
        t7.put(MetricParameter.STRING_ARRAY_PARAMETER, new String[pg.length]);
        defaultMetrics.put(g, t7);
        
        //MCR
        ThresholdMetricStore.setDefaultMetricClass(MeanCaptureRateDiagram.class);
        ThresholdMetricStore h = (ThresholdMetricStore) ThresholdMetricStore.getDefaultMetric();        
        TreeMap t8 = new TreeMap();
        int count1 = MeanCaptureRateDiagram.getDefaultPointCount().getParVal();
        double[] ph = h.getDefProbThresh(MeanErrorOfProbabilityDiagram.class).getThresholdValuesAsDoubleArray();
        t8.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, ph);
        t8.put(MetricParameter.INTEGER_PARAMETER, tCond);
        t8.put(MetricParameter.MCR_POINTS_PARAMETER, count1 + "");
        t8.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) type.deepCopy()).getTypes());
        t8.put(MetricParameter.UNCONDITIONAL_PARAMETER, false);
        t8.put(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER, true);
        t8.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, getTrueBoolArr(ph.length));
        t8.put(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER, new MinimumSampleSizeParameter());
        t8.put(MetricParameter.BOOTSTRAP_PARAMETER, new BootstrapParameter());
        t8.put(MetricParameter.STRING_ARRAY_PARAMETER, new String[ph.length]);
        defaultMetrics.put(h, t8);
        
        //Box plot pooled by lead
        Metric i = ModifiedBoxPlotPooledByLead.getDefaultMetric();      
        TreeMap t9 = new TreeMap();
        int count2 = ModifiedBoxPlotPooledByLead.getDefaultPointCount().getParVal();
        t9.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) type.deepCopy()).getTypes());
        t9.put(MetricParameter.BOX_POOLED_LEAD_POINTS_PARAMETER, count2 + "");
        t9.put(MetricParameter.UNCONDITIONAL_PARAMETER, false);
        defaultMetrics.put(i, t9);
        
        //Box plot unpooled by lead and by forecast time
        Metric ja = ModifiedBoxPlotUnpooledByLead.getDefaultMetric();          
        TreeMap t10a = new TreeMap();
        int count3a = ModifiedBoxPlotUnpooledByLead.getDefaultPointCount().getParVal();
        t10a.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) type.deepCopy()).getTypes());
        t10a.put(MetricParameter.BOX_UNPOOLED_POINTS_PARAMETER, count3a + "");
        t10a.put(MetricParameter.UNCONDITIONAL_PARAMETER, false);
        defaultMetrics.put(ja, t10a);        
        
        //Box plot unpooled by lead and by size of obs
        Metric jb = ModifiedBoxPlotUnpooledByLeadObs.getDefaultMetric();          
        TreeMap t10b = new TreeMap();
        int count3b = ModifiedBoxPlotUnpooledByLeadObs.getDefaultPointCount().getParVal();
        t10b.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) type.deepCopy()).getTypes());
        t10b.put(MetricParameter.BOX_UNPOOLED_OBS_POINTS_PARAMETER, count3b + "");
        t10b.put(MetricParameter.UNCONDITIONAL_PARAMETER, false);
        defaultMetrics.put(jb, t10b);
        
        //ROC plots
        ThresholdMetricStore.setDefaultMetricClass(RelativeOperatingCharacteristic.class);
        ThresholdMetricStore k = (ThresholdMetricStore) ThresholdMetricStore.getDefaultMetric();        
        int count4 = RelativeOperatingCharacteristic.getDefaultPointCount().getParVal();
        double[] pi = k.getDefProbThresh(RelativeOperatingCharacteristic.class).getThresholdValuesAsDoubleArray();
        TreeMap t11 = new TreeMap();
        t11.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) type.deepCopy()).getTypes());
        t11.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, pi);
        t11.put(MetricParameter.ROC_POINTS_PARAMETER, count4 + "");
        t11.put(MetricParameter.INTEGER_PARAMETER, tCond);
        t11.put(MetricParameter.UNCONDITIONAL_PARAMETER, false);
        t11.put(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER, true);
        t11.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, getTrueBoolArr(pi.length));
        t11.put(MetricParameter.FITTED_ROC_PARAMETER, false);
        t11.put(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER, new MinimumSampleSizeParameter());
        t11.put(MetricParameter.BOOTSTRAP_PARAMETER, new BootstrapParameter());
        t11.put(MetricParameter.STRING_ARRAY_PARAMETER, new String[pi.length]);
        defaultMetrics.put(k, t11);
        
        //Reliability diagrams
        ThresholdMetricStore.setDefaultMetricClass(ReliabilityDiagram.class);
        ThresholdMetricStore m = (ThresholdMetricStore) ThresholdMetricStore.getDefaultMetric();        
        TreeMap t12 = new TreeMap();
        int count6 = ReliabilityDiagram.getDefaultPointCount().getParVal();
        double[] pk = m.getDefProbThresh(ReliabilityDiagram.class).getThresholdValuesAsDoubleArray();
        t12.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) type.deepCopy()).getTypes());
        t12.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, pk);
        t12.put(MetricParameter.INTEGER_PARAMETER, tCond);
        t12.put(MetricParameter.UNCONDITIONAL_PARAMETER, false);
        t12.put(MetricParameter.EQUAL_SAMPLES_PARAMETER, false);
        t12.put(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER, true);
        t12.put(MetricParameter.RELIABILITY_POINTS_PARAMETER, count6 + "");
        t12.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, getTrueBoolArr(pk.length));
        t12.put(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER, new MinimumSampleSizeParameter());
        t12.put(MetricParameter.BOOTSTRAP_PARAMETER, new BootstrapParameter());
        t12.put(MetricParameter.STRING_ARRAY_PARAMETER, new String[pk.length]);
        defaultMetrics.put(m, t12);
        
        //Rank histogram
        ThresholdMetricStore.setDefaultMetricClass(RankHistogram.class);
        ThresholdMetricStore na = (ThresholdMetricStore) ThresholdMetricStore.getDefaultMetric();        
        TreeMap t13a = new TreeMap();
        double[] pla = na.getDefProbThresh(RankHistogram.class).getThresholdValuesAsDoubleArray();
        t13a.put(MetricParameter.RANK_HIST_SAMPLE_PARAMETER, true);
        t13a.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, pla);
        t13a.put(MetricParameter.INTEGER_PARAMETER, tCond);
        t13a.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) type.deepCopy()).getTypes());
        t13a.put(MetricParameter.UNCONDITIONAL_PARAMETER, false);
        t13a.put(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER, true);
        t13a.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, getTrueBoolArr(pla.length));
        t13a.put(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER, new MinimumSampleSizeParameter());
        t13a.put(MetricParameter.BOOTSTRAP_PARAMETER, new BootstrapParameter());
        t13a.put(MetricParameter.STRING_ARRAY_PARAMETER, new String[pla.length]);
        defaultMetrics.put(na, t13a);          
        
        //Spread-bias diagram diagram
        ThresholdMetricStore.setDefaultMetricClass(SpreadBiasDiagram.class);
        ThresholdMetricStore nb = (ThresholdMetricStore) ThresholdMetricStore.getDefaultMetric();        
        TreeMap t13b = new TreeMap();
        int count7b = SpreadBiasDiagram.getDefaultPointCount().getParVal();
        double[] plb = nb.getDefProbThresh(SpreadBiasDiagram.class).getThresholdValuesAsDoubleArray();
        t13b.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, plb);
        t13b.put(MetricParameter.INTEGER_PARAMETER, tCond);
        t13b.put(MetricParameter.SPREAD_BIAS_POINTS_PARAMETER, count7b + "");
        t13b.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) type.deepCopy()).getTypes());
        t13b.put(MetricParameter.UNCONDITIONAL_PARAMETER, false);
        t13b.put(MetricParameter.CENTRAL_SPREAD_BIAS_PARAMETER, false);
        t13b.put(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER, true);
        t13b.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, getTrueBoolArr(plb.length));
        t13b.put(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER, new MinimumSampleSizeParameter());
        t13b.put(MetricParameter.BOOTSTRAP_PARAMETER, new BootstrapParameter());
        t13b.put(MetricParameter.STRING_ARRAY_PARAMETER, new String[plb.length]);
        defaultMetrics.put(nb, t13b);
        
        //BSS
        ThresholdMetricStore.setDefaultMetricClass(BrierSkillScore.class);
        ThresholdMetricStore o = (ThresholdMetricStore) ThresholdMetricStore.getDefaultMetric();        
        TreeMap t14 = new TreeMap();
        double[] pm = o.getDefProbThresh(BrierSkillScore.class).getThresholdValuesAsDoubleArray();
        t14.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, pm);
        t14.put(MetricParameter.INTEGER_PARAMETER, tCond);
        t14.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) type.deepCopy()).getTypes());
        DecomposableScore t15Score = (DecomposableScore) o.getFirstMetricInStore();
        DisplayScoreDecompPar t15Par = new DisplayScoreDecompPar(t15Score.getDecompositionOptions(),
                t15Score.NONE);
        t14.put(MetricParameter.DECOMPOSE_PARAMETER, t15Par);
        t14.put(MetricParameter.UNCONDITIONAL_PARAMETER, false);
        DisplayReferencePar disp1 = new DisplayReferencePar();
        t14.put(MetricParameter.REFERENCE_FORECAST_PARAMETER, disp1);
        t14.put(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER, true);
        t14.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, getTrueBoolArr(pm.length));
        t14.put(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER, new MinimumSampleSizeParameter());
        t14.put(MetricParameter.BOOTSTRAP_PARAMETER, new BootstrapParameter());
        t14.put(MetricParameter.STRING_ARRAY_PARAMETER, new String[pm.length]);
        defaultMetrics.put(o, t14);       
        
        //CRPSS
        ThresholdMetricStore.setDefaultMetricClass(MeanContRankProbSkillScore.class);
        ThresholdMetricStore p = (ThresholdMetricStore) ThresholdMetricStore.getDefaultMetric();        
        TreeMap t15 = new TreeMap();
        double[] pn = p.getDefProbThresh(MeanContRankProbSkillScore.class).getThresholdValuesAsDoubleArray();
        t15.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, pn);
        t15.put(MetricParameter.INTEGER_PARAMETER, tCond);
        t15.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) type.deepCopy()).getTypes());
        DecomposableScore t16Score = (DecomposableScore) p.getFirstMetricInStore();
        DisplayScoreDecompPar t16Par = new DisplayScoreDecompPar(t16Score.getDecompositionOptions(),
                t16Score.NONE);
        t15.put(MetricParameter.DECOMPOSE_PARAMETER, t16Par);
        t15.put(MetricParameter.UNCONDITIONAL_PARAMETER, false);
        DisplayReferencePar disp2 = new DisplayReferencePar();
        t15.put(MetricParameter.REFERENCE_FORECAST_PARAMETER, disp2);        
        t15.put(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER, true);
        t15.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, getTrueBoolArr(pn.length));
        t15.put(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER, new MinimumSampleSizeParameter());
        t15.put(MetricParameter.BOOTSTRAP_PARAMETER, new BootstrapParameter());
        t15.put(MetricParameter.STRING_ARRAY_PARAMETER, new String[pn.length]);
        defaultMetrics.put(p, t15);
        
        //ROC score plots
        ThresholdMetricStore.setDefaultMetricClass(ROCScore.class);
        ThresholdMetricStore l = (ThresholdMetricStore) ThresholdMetricStore.getDefaultMetric();        
        int count5 = ROCScore.getDefaultPointCount().getParVal();
        double[] pj = l.getDefProbThresh(ROCScore.class).getThresholdValuesAsDoubleArray();
        TreeMap t16 = new TreeMap();
        t16.put(MetricParameter.FORECAST_TYPE_PARAMETER, ((ForecastTypeParameter) type.deepCopy()).getTypes());
        t16.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, pj);
        t16.put(MetricParameter.ROC_SCORE_POINTS_PARAMETER, count5 + "");
        t16.put(MetricParameter.INTEGER_PARAMETER, tCond);
        t16.put(MetricParameter.UNCONDITIONAL_PARAMETER, false);
        t16.put(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER, true);
        t16.put(MetricParameter.ROC_SCORE_METHOD_PARAMETER,ROCScore.getDefaultMethod().getParVal());
        t16.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, getTrueBoolArr(pj.length));
        t16.put(MetricParameter.FITTED_AUC_PARAMETER, false);
        DisplayReferencePar disp3 = new DisplayReferencePar();
        t16.put(MetricParameter.REFERENCE_FORECAST_PARAMETER, disp3);        
        t16.put(MetricParameter.MINIMUM_SAMPLE_SIZE_PARAMETER, new MinimumSampleSizeParameter());
        t16.put(MetricParameter.BOOTSTRAP_PARAMETER, new BootstrapParameter());
        t16.put(MetricParameter.STRING_ARRAY_PARAMETER, new String[pj.length]);
        defaultMetrics.put(l, t16);          
    }

    /**
     * Convenience method that returns an array of boolean values with a given
     * length, all of which are true.
     *
     * @param length the length
     * @return an array of true boolean values
     */
    private boolean[] getTrueBoolArr(int length) {
        boolean[] b = new boolean[length];
        Arrays.fill(b, true);
        return b;
    }

    /**
     * Returns true if some local parameters exist in the window for saving.
     * 
     * @return true if some parameters exist
     */
    private boolean hasLocalPars() {
        return moreButton.isEnabled();  //All metrics have advanced options
    }

    /**
     * Clears the display, returning it to the default status.  Does not clear any 
     * inputs to the fields for automatic threshold generation (as these may be 
     * required across metrics or even across units).
     * 
     * @param clearRowSelection is true to clear the row selection in the metrics table
     */
    private void clearDisplay(boolean clearRowSelection) {  //JB@October 2012 added clearRowSelection option
        int length = statisticTable.getRowCount();
        statisticTextPane.setText("");
        ((TitledBorder) mainPanel.getBorder()).setTitle("Verification metrics to compute");
        ((DefaultTableModel) thresholdTable.getModel()).setRowCount(0);
        //Finally, clear the statistic table
        for (int i = 0; i < length; i++) {
            if (Boolean.valueOf(true).equals(statisticTable.getValueAt(i, 2))) {
                statisticTable.setValueAt(false, i, 2);
            }
        }
        if(clearRowSelection) {
            statisticTable.clearSelection();
        }
        setParBoxEnabledState();
    }

    /**
     * Sets the tables based on the list of local metrics.
     */
    private void setTables() {
        //Metrics
        Object[] data = defaultMetrics.keySet().toArray();
        String[] type = new String[data.length];
        for (int i = 0; i < type.length; i++) {
            if (data[i] instanceof ThresholdMetricStore) {
                Metric m = ((ThresholdMetricStore) data[i]).getFirstMetricInStore();
                if (m instanceof SampleSize) {
                    type[i] = "None";
                } else if (m.isSkillMetric() && m.isEnsembleMetric()) {
                    type[i] = "Ensemble skill";
                } //Deal with cases that are allowed to be ensemble or single-valued, but 
                //are currently only ensemble
                else if (m.isSingleValuedMetric() && m.isEnsembleMetric()) {
                    type[i] = "Ensemble distribution";
                } else if (m.isSingleValuedMetric()) {
                    type[i] = "Ensemble average";
                } else if (m.isEnsembleMetric()) {
                    type[i] = "Ensemble distribution";
                }
            } else if (data[i] instanceof SkillScore && data[i] instanceof EnsembleMetric) {
                type[i] = "Ensemble skill";
            } else if (data[i] instanceof SingleValuedMetric) {
                type[i] = "Ensemble average";
            } else if (data[i] instanceof EnsembleMetric) {
                type[i] = "Ensemble distribution";
            }
        }

        ((DefaultTableModel) statisticTable.getModel()).setRowCount(data.length);
        for (int i = 0; i < data.length; i++) {
            statisticTable.setValueAt(data[i], i, 0);
            statisticTable.setValueAt(type[i], i, 1);
            statisticTable.setValueAt(false, i, 2);
            final TableCellEditor ed = statisticTable.getCellEditor(i, 2);
            //Register a listener on the JCheckBox cell editor to update the parameter dialog
            final JCheckBox c = (JCheckBox) ed.getTableCellEditorComponent(statisticTable, false, false, i, 2);
            c.addActionListener(new ActionListener() {

                public void actionPerformed(ActionEvent evt) {
                    ed.stopCellEditing();
                    updateLocalStore();
                    //Only update when required
                    boolean selected = c.isSelected();
                    boolean current = hasLocalPars();
                    if (selected != current) {
                        showLocalData();
                    }
                }
            });
        }

        //Set model
        thresholdTable.setModel(new javax.swing.table.DefaultTableModel(
                new Object[][]{}, new String[]{"Numeric value", "ID [optional]", "Main?"}) {

            Class[] types = new Class[]{
                String.class, String.class, Boolean.class,};

            public Class getColumnClass(int columnIndex) {
                return types[columnIndex];
            }

            public boolean isCellEditable(int row, int column) {
                return super.isCellEditable(row, column);
            }

            public void fireTableRowsDeleted(int firstRow, int lastRow) {
                super.fireTableRowsDeleted(firstRow, lastRow);
                thresholdTable.setPreferredSize(new Dimension(75, thresholdTable.getRowHeight()
                        * (thresholdTable.getRowCount() + 1)));
            }

            public void fireTableRowsInserted(int firstRow, int lastRow) {
                super.fireTableRowsInserted(firstRow, lastRow);
                thresholdTable.setPreferredSize(new Dimension(75, thresholdTable.getRowHeight()
                        * (thresholdTable.getRowCount() + 1)));
            }
        });

        //Set probability threshold table
        //Add a selection changed method to the table
        thresholdTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

            public void valueChanged(ListSelectionEvent evt) {
                int row = thresholdTable.getSelectedRow();
                deleteButton.setEnabled(thresholdTable.getRowCount() > 1 && row > -1);  //Must have one threshold
            }
        });

        //Set the cell renderer for the "main" thresholds in the threshold table
        thresholdTable.setDefaultRenderer(Boolean.class, new DefaultTableCellRenderer() {

            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                JCheckBox cb = new JCheckBox();
                cb.setHorizontalAlignment(SwingConstants.CENTER);
                if (!isSelected) {
                    cb.setBackground(Color.white);
                } else {
                    Color bg = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column).getBackground();
                    cb.setBackground(bg);
                }
                cb.setEnabled(table.isEnabled());
                if (value instanceof Boolean) {
                    cb.setSelected((Boolean) value);
                }
                return cb;
            }
        });

        //Set the cell renderer to differentiate between statistic types
        statisticTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {

            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                if (column == 1) {
                    if ((value + "").equalsIgnoreCase("Ensemble distribution")) {
                        super.setForeground(Color.blue);
                    } else if ((value + "").equalsIgnoreCase("Ensemble average")) {
                        super.setForeground(Color.red);
                    } else if ((value + "").equalsIgnoreCase("Ensemble skill")) {
                        super.setForeground(Color.green.darker().darker());
                    } else if ((value + "").equalsIgnoreCase("None")) {
                        super.setForeground(Color.black);
                    }
                } else {
                    super.setForeground(Color.black);
                }
                return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }
        });

        //Finally, add a listener to the statistics table to coordinate local saving and display
        //on a change in the selection of a metric
        ListSelectionListener listener = new ListSelectionListener() {

            public void valueChanged(ListSelectionEvent evt) {
                //Display data if selection has been completed
                int row = statisticTable.getSelectedRow();
                if (!evt.getValueIsAdjusting() && row > -1) {
                    showLocalData();
                } //If the value is adjusting, save the data for the old selection
                else if (evt.getValueIsAdjusting()) {
                    saveLocalData();
                    //Finally, set the index for saving data, which will then correspond to the last
                    //selected index
                    saveIndex = row;
                }
            }
        };
        statisticTable.getSelectionModel().addListSelectionListener(listener);
        statisticTable.getColumnModel().getSelectionModel().addListSelectionListener(listener);

        //Increases the table row height
        thresholdTable.setRowHeight(25);
        thresholdTable.getSelectionModel().setSelectionMode(thresholdTable.getSelectionModel().MULTIPLE_INTERVAL_SELECTION);
        thresholdTable.getColumnModel().getColumn(0).setPreferredWidth(3350);
        thresholdTable.getColumnModel().getColumn(1).setPreferredWidth(3350);
        thresholdTable.getColumnModel().getColumn(2).setPreferredWidth(850);

        //thresholdTable.getSelectionModel().setSelectionMode(thresholdTable.getSelectionModel().SINGLE_SELECTION);
        statisticTable.setRowHeight(25);
        statisticTable.getColumnModel().getColumn(0).setPreferredWidth(5000);
        statisticTable.getColumnModel().getColumn(1).setPreferredWidth(1700);
        statisticTable.getColumnModel().getColumn(2).setPreferredWidth(850);

        //Hide threshold options by default
        thresholdLabel.setVisible(false);
        ptTableScrollPane.setVisible(false);
        addButton.setVisible(false);
        doAllButton.setVisible(false);
        deleteButton.setVisible(false);
        autoAddButton.setVisible(false);
        autoResetButton.setVisible(false);
        autoThresholdLabel.setVisible(false);
        thresholdCountLabel.setVisible(false);
        thresholdCountField.setVisible(false);
        lowerBoundLabel.setVisible(false);
        lowerBoundField.setVisible(false);
        intervalLabel.setVisible(false);
        intervalField.setVisible(false);
    }

    /**
     * Updates the local store for the selected metric in the table following a 
     * change in status (i.e. selected or unselected).
     */
    private void updateLocalStore() {
        int row = statisticTable.getSelectedRow();
        if (row > -1) {
            VerificationUnit vu = VERIFICATION_A.getSelectedUnit();
            Metric m = (Metric) statisticTable.getValueAt(row, 0);
            //Add a default metric
            if (statisticTable.getValueAt(row, 2).equals(true)) {
                //Inititialize
                if (!localPars.containsKey(vu)) {
                    localPars.put(vu, new LinkedHashMap());
                }
                LinkedHashMap pars = localPars.get(vu);
                //Shallow copy is sufficient here
                TreeMap<Integer, Object> ps = (TreeMap<Integer, Object>) defaultMetrics.get(m).clone();
                pars.put(m, ps);
                updateRefFcsts(m,ps);

//                //Update available reference forecasts
//                if (ps.containsKey(MetricParameter.REFERENCE_FORECAST_PARAMETER)) {
//                    Vector<VerificationUnit> a = VERIFICATION_A.getVerificationUnits();
//                    Vector<String> name = new Vector<String>();
//                    int tot = a.size();
//                    String selected = VERIFICATION_A.getSelectedUnit().toString();
//                    for (int k = 0; k < tot; k++) {
//                        String nxt = a.get(k).toString();
//                        if (!nxt.equals(selected)) {
//                            name.add(nxt);
//                        }
//                    }
//
//                    //Add any default reference forecasts for the current metric
//                    if (m instanceof ThresholdMetricStore) {
//                        ThresholdMetricStore st = ((ThresholdMetricStore) m);
//                        Metric score = (Metric) st.getFirstMetricInStore();
//                        if (score instanceof SkillScore) {
//                            if (((SkillScore) score).hasDefaultRefFcst()) {
//                                String ref = ((SkillScore) score).getDefaultRefFcst().getParVal();
//                                if (!name.contains(ref)) {
//                                    name.add(ref);
//                                }
//                            }
//                        }
//                    }
//
//                    DisplayReferencePar p = new DisplayReferencePar();
//                    if (name.size() > 0) {
//                        p.setRefFcsts(name.toArray(new String[name.size()]));
//                        //Set the reference forecast if only one available
//                        if (name.size() == 1) {
//                            p.setSelectedIndex(0);
//                        }
//                    }
//                    ps.put(MetricParameter.REFERENCE_FORECAST_PARAMETER, p);
//                }

            } //Remove a metric from the local store
            else {
                if (localPars.containsKey(vu)) {
                    localPars.get(vu).remove(m);
                }
            }
        }
    }
    
    /**
     * Updates the reference forecasts in an input map of parameters for a given
     * metric to reflect the current VUs available. Also add any default forecasts 
     * associated with the input metric.
     * 
     * @param m the metric
     * @param input the input map of parameters
     */
     private void updateRefFcsts(Metric m, TreeMap<Integer, Object> input) {
        if (m != null && input != null) {
            if (VERIFICATION_A.getSelectedUnit() != null) {
                // Update available reference forecasts
                if (input.containsKey(MetricParameter.REFERENCE_FORECAST_PARAMETER)) {
                    Vector<VerificationUnit> a = VERIFICATION_A.getVerificationUnits();
                    Vector<String> name = new Vector<String>();
                    int tot = a.size();
                    String selected = VERIFICATION_A.getSelectedUnit().toString();
                    for (int k = 0; k < tot; k++) {
                        String nxt = a.get(k).toString();
                        if (!nxt.equals(selected)) {
                            name.add(nxt);
                        }
                    }

                    // Add any default reference forecasts for the current
                    // metric
                    if (m instanceof ThresholdMetricStore) {
                        ThresholdMetricStore st = ((ThresholdMetricStore) m);
                        Metric score = (Metric) st.getFirstMetricInStore();
                        if (score instanceof SkillScore) {
                            if (((SkillScore) score).hasDefaultRefFcst()) {
                                String ref = ((SkillScore) score).getDefaultRefFcst().getParVal();
                                if (!name.contains(ref)) {
                                    name.add(ref);
                                }
                            }
                        }
                    }

                    DisplayReferencePar p = new DisplayReferencePar();
                    if (name.size() > 0) {
                        p.setRefFcsts(name.toArray(new String[name.size()]));
                        // Set the reference forecast if only one available
                        if (name.size() == 1) {
                            p.setSelectedIndex(0);
                        }
                    }
                    input.put(MetricParameter.REFERENCE_FORECAST_PARAMETER, p);
                }
            }
        }
    }

    /**
     * Sets the parameter box enabled status according to the table selection.
     * Does not show or alter any parameter values, either in the display or
     * local storage.  Only enables or disables the various parameter boxes.
     */
    private void setParBoxEnabledState() {
        int row = statisticTable.getSelectedRow();
        boolean enableBasic = false;
        boolean selected = false;
        Metric stat = null;
        if (row > -1) {
            stat = (Metric) statisticTable.getValueAt(row, 0);
            selected = (Boolean) statisticTable.getValueAt(row, 2);
            //Enable thresholds
            boolean enablePT = stat.hasThresholds() && selected;
            //Enable reference forecast (true for all when selected)
            boolean enableRF = selected;
            //Enable decomposition
            boolean enableDecomp = stat instanceof ScoreMetric && selected;
            //Enable advanced options
            boolean enableAdv = metricHasAdvancedOptions(stat) && selected;

            //Enables the basic parameters dialog
            enableBasic = (enablePT || enableRF || enableDecomp || enableAdv) && selected;

            thresholdLabel.setVisible(stat.hasThresholds());
            ptTableScrollPane.setVisible(stat.hasThresholds());
            addButton.setVisible(stat.hasThresholds());
            deleteButton.setVisible(stat.hasThresholds());
            doAllButton.setVisible(stat.hasThresholds());
            autoThresholdLabel.setVisible(stat.hasThresholds());
            thresholdCountLabel.setVisible(stat.hasThresholds());
            thresholdCountField.setVisible(stat.hasThresholds());
            lowerBoundLabel.setVisible(stat.hasThresholds());
            lowerBoundField.setVisible(stat.hasThresholds());
            intervalLabel.setVisible(stat.hasThresholds());
            intervalField.setVisible(stat.hasThresholds());
            autoAddButton.setVisible(stat.hasThresholds());
            autoResetButton.setVisible(stat.hasThresholds());

            //Enable basic pars?
            if (enableBasic) {
                //Threshold options
                bottomInsertPanel.setEnabled(enablePT);
                thresholdLabel.setEnabled(enablePT);
                thresholdTable.setEnabled(enablePT);
                ptTableScrollPane.setEnabled(enablePT);
                doAllButton.setEnabled(enablePT);
                addButton.setEnabled(enablePT);
                autoThresholdLabel.setEnabled(enablePT);
                thresholdCountLabel.setEnabled(enablePT);
                thresholdCountField.setEnabled(enablePT);
                lowerBoundLabel.setEnabled(enablePT);
                lowerBoundField.setEnabled(enablePT);
                intervalLabel.setEnabled(enablePT);
                intervalField.setEnabled(enablePT);
                autoAddButton.setEnabled(enablePT);
                autoResetButton.setEnabled(enablePT);

                if (enablePT) {
                    thresholdTable.getTableHeader().setForeground(Color.black);
                    thresholdTable.setForeground(Color.black);
                    ptTableScrollPane.setVerticalScrollBarPolicy(ptTableScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
                    deleteButton.setEnabled(thresholdTable.getRowCount() > 1 && thresholdTable.getSelectedRow() > 0);  //Must have one threshold
                } else {
                    thresholdTable.clearSelection();
                    thresholdTable.getTableHeader().setForeground(new Color(157, 154, 118));
                    thresholdTable.setForeground(new Color(157, 154, 118));
                    ptTableScrollPane.setVerticalScrollBarPolicy(ptTableScrollPane.VERTICAL_SCROLLBAR_NEVER);
                    deleteButton.setEnabled(false);
                }

                //Advanced button
                moreButton.setEnabled(enableAdv);
                //Titled border
                ((TitledBorder) bottomPanel.getBorder()).setTitle("3c. Edit basic parameters of selected metric '" + stat + "'");
                ((TitledBorder) bottomPanel.getBorder()).setTitleColor(Color.black);
            }
        }

        //Disable the basic elements
        if (!enableBasic) {
            if (stat == null) {
                ((TitledBorder) bottomPanel.getBorder()).setTitle("3c. Edit basic parameters of selected metric (none selected)");
            } else {
                ((TitledBorder) bottomPanel.getBorder()).setTitle("3c. Edit basic parameters of selected metric '" + stat + "'");
            }
            ((TitledBorder) bottomPanel.getBorder()).setTitleColor(new Color(157, 154, 118));

            Color c = new Color(157, 154, 118);

            //Threshold options
            bottomInsertPanel.setEnabled(false);
            thresholdLabel.setEnabled(false);
            thresholdTable.setEnabled(false);
            thresholdTable.clearSelection();
            ptTableScrollPane.setEnabled(false);
            thresholdTable.getTableHeader().setForeground(c);
            thresholdTable.setForeground(c);
            addButton.setEnabled(false);
            doAllButton.setEnabled(false);
            deleteButton.setEnabled(false);
            ptTableScrollPane.setVerticalScrollBarPolicy(ptTableScrollPane.VERTICAL_SCROLLBAR_NEVER);
            ((DefaultTableModel) thresholdTable.getModel()).setRowCount(0);
            autoThresholdLabel.setEnabled(false);
            thresholdCountLabel.setEnabled(false);
            thresholdCountField.setEnabled(false);
            lowerBoundLabel.setEnabled(false);
            lowerBoundField.setEnabled(false);
            intervalLabel.setEnabled(false);
            intervalField.setEnabled(false);
            autoAddButton.setEnabled(false);
            autoResetButton.setEnabled(false);

            //More button
            moreButton.setEnabled(false);
        }
        bottomInsertPanel.repaint();
        bottomPanel.repaint();
    }

    /**
     * Returns true if the specified metric has advanced options associated with
     * it for which the advanced options dialog should be displayed.
     *
     * @param stat the metric
     * @return true if the metric has advanced options
     */
    private boolean metricHasAdvancedOptions(Metric stat) {
        boolean returnMe = false;
        if (stat instanceof ThresholdMetricStore) {
            returnMe = true;
        }
        if (stat instanceof SpreadBiasDiagram) {
            returnMe = true;
        } else if (stat instanceof MeanCaptureRateDiagram) {
            returnMe = true;
        } else if (stat instanceof ModifiedBoxPlot) {
            returnMe = true;
        }
        if (!returnMe && VERIFICATION_A.unitIsSelected()) {
            returnMe = VERIFICATION_A.getSelectedUnit().hasValueConditions();
        }
        return returnMe;
    }

    /**
     * Selects or deselects all of the statistics in the table.
     *
     * @param select is true to select all statistics
     */
    private void selectAllStats(boolean select) {
        for (int i = 0; i < statisticTable.getRowCount(); i++) {
            statisticTable.setValueAt(select, i, 2);
        }
        VerificationUnit vu = VERIFICATION_A.getSelectedUnit();
        if (select) {
            LinkedHashMap pars = new LinkedHashMap();
            for (int i = 0; i < statisticTable.getRowCount(); i++) {
                statisticTable.setValueAt(select, i, 2);
                Metric m = (Metric)statisticTable.getValueAt(i, 0);
                TreeMap<Integer,Object> ps = 
                		(TreeMap<Integer,Object>)defaultMetrics.get(m).clone();
                pars.put(m,ps);  //Shallow copy is sufficient here
                //Update reference forecasts based on current information if applicable
                updateRefFcsts(m,ps);  
            }
            localPars.put(vu, pars);
        } else {
            //Empty the metrics, but retain the reference to the VU so the
            //unit is updated on saving
            //This behaviour duplicates the behaviour when removing each metric
            //manually until no metrics are left, which is the desired behaviour
            //Otherwise, removing the reference to the VU will cause problems on
            //saving the data because there will be no reference to the VU, which
            //is required to remove all its metrics.
            localPars.get(vu).clear();
        }
    }

    /**
     * Sets the text associated with a selected statistic or returns the text to
     * default (no text).
     */
    private void setStatTextBox() {
        statisticTextPane.setText("");
        int row = statisticTable.getSelectedRow();
        if (row > -1) {
            //Set explanation
            Metric stat = (Metric) statisticTable.getValueAt(row, 0);
            ((TitledBorder) rightPanel.getBorder()).setTitle("3b. View explanation of metric '" + stat + "'");
            URL url = stat.getDescriptionURL();
            try {
                statisticTextPane.setDocument(defaultDoc);
                statisticTextPane.setPage(url);
            } catch (Exception e) {
                e.printStackTrace();
                System.err.println(url);
                //ExceptionHandler.displayException(e);
            }
        } else {
            ((TitledBorder) rightPanel.getBorder()).setTitle("3b. View explanation of selected metric (none selected)");
        }
        rightPanel.repaint();
    }

    /**
     * Runs the verification for all available units.
     *
     * @param runAll is true to run all units, false for the selected unit
     */
    private void runVerification(final boolean runAll) throws IllegalArgumentException {
        //Attempt to save data: return if save failed (possibly due to cancellation)
        if (!EVSMainWindow.main.saveProject(true)) {
            System.out.println("Verification not conducted, as save failed.");
            return;
        }
        final Vector<VerificationUnit> units = new Vector();
        if (runAll) {
            units.addAll(VERIFICATION_A.getVerificationUnits());
        } else {
            units.add(VERIFICATION_A.getSelectedUnit());
        }

        //Provide option to enter scale information if not already entered for
        //one or more datasets
        final int length = units.size();
        for (int i = 0; i < length; i++) {
            if (!units.get(i).hasSupport(Support.ALL_SUPPORT)) {
                //Show an option dialog once
                String message = "One or more Verification Units have no scale information.";
            	int n = JOptionPane.showOptionDialog(EVSMainWindow.main, message+"  Proceed assuming that the forecast and observed scales are the same?", "Warning: scale information missing", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, null, null, null);
            	System.out.println("WARNING: scale information missing. "+message);
            	if (n == JOptionPane.YES_OPTION) {
                    break;
                } else {
                    return; //No changes made
                }
            }

            //Throw an exception if the support differs
            if (!units.get(i).hasVerifiableSupport()) {
                throw new IllegalArgumentException("The forecasts and observations must have the same temporal 'support' or a valid change-of-support: see the user's manual for change-of-support options.");
            }
        }

        //Perform verification in a separate thread
        final long start = System.currentTimeMillis();
        final ProgressMonitor pro = new ProgressMonitor(EVSMainWindow.main) {

            protected void cleanUpOnCancel() {
                PairedDataSource.getIOState().setIOState(false);  //Cancel I/O
                //Cancel metric calculation
                Vector<VerificationUnit> units = VERIFICATION_A.getVerificationUnits();
                if(runAll) {
                    for (VerificationUnit unit : units) {
                        unit.stop();
                    }
                } else {
                    VERIFICATION_A.getSelectedUnit().stop();
                }
                super.cleanUpOnCancel();
            }
        };
        final SwingWorker task = new SwingWorker() {

            public Object doInBackground() {
                final java.util.Timer tt = new java.util.Timer();
                pro.setProgress(0);  //Initialize for percent progress
                pro.setThread(this);
                try {
                    boolean ok = true;
                    StringBuffer errorMessage = new StringBuffer();

                    //Compute the metrics
                    for (int i = 0; i < length; i++) {
                        final VerificationUnit nxt = units.get(i);
                        //Check for progress
                        final double mult = 1.0 / length;
                        final int current = i;
                        TimerTask tsk = new TimerTask() {

                            public void run() {
                                double prev = (mult * current) * 100.0;
                                double curr = mult * nxt.getProgress();
                                double tot = prev + curr;
                                setProgress((int) tot);  //Update the progress: listen for this update later
                            }
                        };
                        tt.scheduleAtFixedRate(tsk, 0, 50);

                        ok = nxt.computeMetrics(VERIFICATION_A.getVerificationUnits());
                        if (!ok) {
                            errorMessage.append(nxt.getComputeErrors());
                        }
                    }

                    //Save path to pairs
                    try {
                        EVSMainWindow.main.updateProjectFile();
                    } catch (Exception e) {
                        System.out.println("Failed to update project file.");
                    }
                    if (ok) {
                        pro.stop(" complete.", true);
                        pro.setVisible(false); //Quiet close
                    } else {
                        CONSOLE.addMessage(errorMessage.toString());
                        pro.stop(" stopped with errors.", false);
                    }

                } //No memory left
                catch (OutOfMemoryError f) {
                    CONSOLE.addMessage(StringUtilities.stackTraceToString(f));
                    f.printStackTrace();
                    pro.stop(" stopped with errors.", false);
                } catch (Throwable t) { 
                    CONSOLE.addMessage(StringUtilities.stackTraceToString(t));
                    t.printStackTrace();
                    pro.stop(" stopped with errors.", false);                    
                } finally {
                    if (tt != null) {
                        tt.cancel();
                    }
                    long stop = System.currentTimeMillis();
                    System.out.println("Total time taken for verification: " + Mathematics.round((stop - start) / 60000.0, 1) + " minutes.");
                    //Allow continued I/O
                    PairedDataSource.getIOState().setIOState(true);
                    
                    //Update the output dialog
                    OUTPUT_A.updateLocalData();
                    OUTPUT_A.showLocalData();
                }
                return null;
            }
        };
        //Monitor progress and update progress bar: cancel thread if required
        task.addPropertyChangeListener(
                new PropertyChangeListener() {

                    public void propertyChange(PropertyChangeEvent evt) {
                        if ("progress".equals(evt.getPropertyName())) {
                            if (pro.wasCanceled() || task.isDone()) {
                                task.cancel(true);
                            }
                            pro.setProgress((Integer) evt.getNewValue());
                        }
                    }
                });

        task.execute();
        pro.setVisible(true);
    }

    /**
     * Returns the local thresholds, which may not be valid probability thresholds
     * in the case of probability thresholds, together with the identifiers of
     * main thresholds. The first object contains the threshold values as a double
     * array, the second object contains the String ids as a String array,
     * and the third contains the boolean values as a boolean array.
     *
     * @return the local thresholds
     */
    private Object[] getLocalThresholds() {
        int rows = thresholdTable.getRowCount();
        Vector<Double> v = new Vector<Double>();
        Vector<Boolean> w = new Vector<Boolean>();
        Vector<String> x = new Vector<String>();
        //Stop editing threshold table
        TableCellEditor ce = thresholdTable.getCellEditor();
        if (ce != null) {
            ce.stopCellEditing();
        }
        for (int i = 0; i < rows; i++) {
            try {
                if ("all data".equalsIgnoreCase(thresholdTable.getValueAt(i, 0) + "")) {
                    v.add(new Double(Double.NEGATIVE_INFINITY));
                } else {
                    v.add(new Double(thresholdTable.getValueAt(i, 0) + ""));
                }
                w.add(Boolean.valueOf(thresholdTable.getValueAt(i, 2) + ""));
                Object o = thresholdTable.getValueAt(i, 1);
                if (o == null) {
                    x.add(null);
                } else {
                    x.add(thresholdTable.getValueAt(i, 1).toString());
                }
            } catch (Exception e) {
                System.err.println("Invalid threshold ignored: ["+thresholdTable.getValueAt(i,0)+","+
                        thresholdTable.getValueAt(i, 1)+","+thresholdTable.getValueAt(i, 2)+"].");
                //e.printStackTrace();
            }
        }
        double[] a = new double[v.size()];
        boolean[] b = new boolean[w.size()];
        String[] c = new String[w.size()];
        for (int i = 0; i < a.length; i++) {
            a[i] = v.get(i);
            b[i] = w.get(i);
            c[i] = x.get(i);
        }
        return new Object[]{a, b, c};
    }

    /**
     * Initializes the window components.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tableMenu = new javax.swing.JPopupMenu();
        selectStats = new javax.swing.JMenuItem();
        browseMenu = new javax.swing.JPopupMenu();
        browse = new javax.swing.JMenuItem();
        thresholdTableMenu = new javax.swing.JPopupMenu();
        toggleMain = new javax.swing.JMenuItem();
        mainPanel = new javax.swing.JPanel();
        topPanel = new javax.swing.JPanel();
        topSplitPane = new javax.swing.JSplitPane();
        leftPanel = new javax.swing.JPanel();
        leftScrollPane = new javax.swing.JScrollPane();
        statisticTable = new javax.swing.JTable();
        rightPanel = new javax.swing.JPanel();
        rightScrollPane = new javax.swing.JScrollPane();
        statisticTextPane = new javax.swing.JEditorPane();
        bottomPanel = new javax.swing.JPanel();
        bottomScrollPane = new javax.swing.JScrollPane();
        bottomInsertPanel = new javax.swing.JPanel();
        mainPTPanel = new javax.swing.JPanel();
        manualThresholdPanel = new javax.swing.JPanel();
        thresholdLabel = new javax.swing.JLabel();
        ptTableScrollPane = new javax.swing.JScrollPane();
        thresholdTable = new javax.swing.JTable();
        ptButtonMenu = new javax.swing.JPanel();
        addButton = new javax.swing.JButton();
        jPanel1413 = new javax.swing.JPanel();
        deleteButton = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        doAllButton = new javax.swing.JButton();
        middleSpacerPanel = new javax.swing.JPanel();
        autoThreshInputsPanel = new javax.swing.JPanel();
        autoThreshInputsLowerPanel = new javax.swing.JPanel();
        autoThresholdLabel = new javax.swing.JLabel();
        thresholdCountLabel = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        thresholdCountField = new javax.swing.JTextField();
        lowerBoundLabel = new javax.swing.JLabel();
        lowerBoundField = new javax.swing.JTextField();
        intervalLabel = new javax.swing.JLabel();
        intervalField = new javax.swing.JTextField();
        autoButtonPanel = new javax.swing.JPanel();
        autoAddButton = new javax.swing.JButton();
        jPanel1417 = new javax.swing.JPanel();
        autoResetButton = new javax.swing.JButton();
        lowerSpacerPanel = new javax.swing.JPanel();
        rightSpacerPanel = new javax.swing.JPanel();
        moreButtonPanel = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        moreButton = new javax.swing.JButton();
        navigationPanel = new javax.swing.JPanel();
        runButton = new javax.swing.JButton();
        jPanel1416 = new javax.swing.JPanel();
        runAllButton = new javax.swing.JButton();
        jPanel20 = new javax.swing.JPanel();
        backButton = new javax.swing.JButton();
        jPanel1414 = new javax.swing.JPanel();
        nextButton = new javax.swing.JButton();

        selectStats.setText("Select all / none");
        selectStats.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectStatsActionPerformed(evt);
            }
        });
        tableMenu.add(selectStats);

        browse.setText("Open in external browser");
        browse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                browseActionPerformed(evt);
            }
        });
        browseMenu.add(browse);

        toggleMain.setText("Toggle \"main\" thresholds");
        toggleMain.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toggleMainActionPerformed(evt);
            }
        });
        thresholdTableMenu.add(toggleMain);

        setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        setMaximumSize(new java.awt.Dimension(32000, 500));
        setMinimumSize(new java.awt.Dimension(500, 330));
        setPreferredSize(new java.awt.Dimension(1024, 768));
        setLayout(new javax.swing.BoxLayout(this, javax.swing.BoxLayout.Y_AXIS));

        mainPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "3. Choose verification metrics to compute", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 12))); // NOI18N
        mainPanel.setLayout(new javax.swing.BoxLayout(mainPanel, javax.swing.BoxLayout.Y_AXIS));

        topPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 3, 0));
        topPanel.setMinimumSize(new java.awt.Dimension(85, 0));
        topPanel.setPreferredSize(new java.awt.Dimension(39, 2500));
        topPanel.setLayout(new javax.swing.BoxLayout(topPanel, javax.swing.BoxLayout.LINE_AXIS));

        topSplitPane.setDividerSize(7);
        topSplitPane.setResizeWeight(0.5);
        topSplitPane.setMaximumSize(new java.awt.Dimension(32000, 32000));

        leftPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "3a. Select metrics to compute", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11))); // NOI18N
        leftPanel.setLayout(new java.awt.GridLayout(1, 0));

        leftScrollPane.setMaximumSize(new java.awt.Dimension(32000, 32000));
        leftScrollPane.setPreferredSize(new java.awt.Dimension(0, 0));

        statisticTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Property verified", "Include?"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        statisticTable.setPreferredSize(new java.awt.Dimension(150, 500));
        statisticTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                statisticTableMouseReleased(evt);
            }
        });
        leftScrollPane.setViewportView(statisticTable);

        leftPanel.add(leftScrollPane);

        topSplitPane.setLeftComponent(leftPanel);

        rightPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "3b. View explanation of selected metric (none selected)", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11), new java.awt.Color(51, 51, 51))); // NOI18N
        rightPanel.setLayout(new java.awt.GridLayout(1, 0));

        statisticTextPane.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                statisticTextPaneMouseReleased(evt);
            }
        });
        rightScrollPane.setViewportView(statisticTextPane);

        rightPanel.add(rightScrollPane);

        topSplitPane.setRightComponent(rightPanel);

        topPanel.add(topSplitPane);

        mainPanel.add(topPanel);

        bottomPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "3c. Edit basic parameters of selected metric (none selected)", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11))); // NOI18N
        bottomPanel.setMinimumSize(new java.awt.Dimension(26, 0));
        bottomPanel.setPreferredSize(new java.awt.Dimension(26, 2000));
        bottomPanel.setLayout(new java.awt.GridLayout(1, 2));

        bottomScrollPane.setBorder(null);
        bottomScrollPane.setMinimumSize(new java.awt.Dimension(0, 0));

        bottomInsertPanel.setMinimumSize(new java.awt.Dimension(0, 0));
        bottomInsertPanel.setPreferredSize(new java.awt.Dimension(800, 275));
        bottomInsertPanel.setLayout(new javax.swing.BoxLayout(bottomInsertPanel, javax.swing.BoxLayout.Y_AXIS));

        mainPTPanel.setMaximumSize(new java.awt.Dimension(65534, 97534));
        mainPTPanel.setMinimumSize(new java.awt.Dimension(28, 83));
        mainPTPanel.setPreferredSize(new java.awt.Dimension(100, 600));
        mainPTPanel.setLayout(new javax.swing.BoxLayout(mainPTPanel, javax.swing.BoxLayout.LINE_AXIS));

        manualThresholdPanel.setMaximumSize(new java.awt.Dimension(32767, 97534));
        manualThresholdPanel.setMinimumSize(new java.awt.Dimension(0, 0));
        manualThresholdPanel.setPreferredSize(new java.awt.Dimension(452, 4040));
        manualThresholdPanel.setLayout(new javax.swing.BoxLayout(manualThresholdPanel, javax.swing.BoxLayout.Y_AXIS));

        thresholdLabel.setFont(new java.awt.Font("Verdana", 1, 11)); // NOI18N
        thresholdLabel.setText("Edit thresholds manually [optional]");
        thresholdLabel.setEnabled(false);
        thresholdLabel.setMaximumSize(new java.awt.Dimension(65534, 50));
        thresholdLabel.setMinimumSize(new java.awt.Dimension(100000, 25));
        thresholdLabel.setPreferredSize(new java.awt.Dimension(10000, 25));
        manualThresholdPanel.add(thresholdLabel);

        ptTableScrollPane.setEnabled(false);
        ptTableScrollPane.setPreferredSize(new java.awt.Dimension(452, 35000));

        thresholdTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Numeric value", "ID [optional]", "Main?"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Boolean.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        thresholdTable.setEnabled(false);
        thresholdTable.setPreferredSize(new java.awt.Dimension(75, 500));
        thresholdTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                thresholdTableMouseReleased(evt);
            }
        });
        ptTableScrollPane.setViewportView(thresholdTable);

        manualThresholdPanel.add(ptTableScrollPane);

        ptButtonMenu.setMaximumSize(new java.awt.Dimension(32000, 32000));
        ptButtonMenu.setMinimumSize(new java.awt.Dimension(0, 60));
        ptButtonMenu.setPreferredSize(new java.awt.Dimension(150, 60));
        ptButtonMenu.setLayout(new javax.swing.BoxLayout(ptButtonMenu, javax.swing.BoxLayout.LINE_AXIS));

        addButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        addButton.setText("Add");
        addButton.setAlignmentY(0.0F);
        addButton.setEnabled(false);
        addButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        addButton.setMaximumSize(new java.awt.Dimension(65, 29));
        addButton.setMinimumSize(new java.awt.Dimension(65, 29));
        addButton.setPreferredSize(new java.awt.Dimension(65, 29));
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });
        ptButtonMenu.add(addButton);

        jPanel1413.setMaximumSize(new java.awt.Dimension(2, 100));
        jPanel1413.setMinimumSize(new java.awt.Dimension(2, 15));
        jPanel1413.setPreferredSize(new java.awt.Dimension(4, 10));

        org.jdesktop.layout.GroupLayout jPanel1413Layout = new org.jdesktop.layout.GroupLayout(jPanel1413);
        jPanel1413.setLayout(jPanel1413Layout);
        jPanel1413Layout.setHorizontalGroup(
            jPanel1413Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 4, Short.MAX_VALUE)
        );
        jPanel1413Layout.setVerticalGroup(
            jPanel1413Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 60, Short.MAX_VALUE)
        );

        ptButtonMenu.add(jPanel1413);

        deleteButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        deleteButton.setText("Delete");
        deleteButton.setAlignmentY(0.0F);
        deleteButton.setEnabled(false);
        deleteButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        deleteButton.setMaximumSize(new java.awt.Dimension(65, 29));
        deleteButton.setMinimumSize(new java.awt.Dimension(65, 29));
        deleteButton.setPreferredSize(new java.awt.Dimension(65, 29));
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });
        ptButtonMenu.add(deleteButton);

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 105, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 60, Short.MAX_VALUE)
        );

        ptButtonMenu.add(jPanel1);

        doAllButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        doAllButton.setText("Do all");
        doAllButton.setAlignmentY(0.0F);
        doAllButton.setEnabled(false);
        doAllButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        doAllButton.setMaximumSize(new java.awt.Dimension(65, 29));
        doAllButton.setMinimumSize(new java.awt.Dimension(65, 29));
        doAllButton.setPreferredSize(new java.awt.Dimension(65, 29));
        doAllButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                doAllButtonActionPerformed(evt);
            }
        });
        ptButtonMenu.add(doAllButton);

        manualThresholdPanel.add(ptButtonMenu);

        mainPTPanel.add(manualThresholdPanel);

        middleSpacerPanel.setMaximumSize(new java.awt.Dimension(20, 97534));
        middleSpacerPanel.setPreferredSize(new java.awt.Dimension(20, 275));

        org.jdesktop.layout.GroupLayout middleSpacerPanelLayout = new org.jdesktop.layout.GroupLayout(middleSpacerPanel);
        middleSpacerPanel.setLayout(middleSpacerPanelLayout);
        middleSpacerPanelLayout.setHorizontalGroup(
            middleSpacerPanelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 13, Short.MAX_VALUE)
        );
        middleSpacerPanelLayout.setVerticalGroup(
            middleSpacerPanelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 297, Short.MAX_VALUE)
        );

        mainPTPanel.add(middleSpacerPanel);

        autoThreshInputsPanel.setMaximumSize(new java.awt.Dimension(32000, 32000));
        autoThreshInputsPanel.setPreferredSize(new java.awt.Dimension(1000, 275));
        autoThreshInputsPanel.setLayout(new javax.swing.BoxLayout(autoThreshInputsPanel, javax.swing.BoxLayout.X_AXIS));

        autoThreshInputsLowerPanel.setAlignmentX(0.0F);
        autoThreshInputsLowerPanel.setMaximumSize(new java.awt.Dimension(280000, 32000));
        autoThreshInputsLowerPanel.setMinimumSize(new java.awt.Dimension(0, 0));
        autoThreshInputsLowerPanel.setPreferredSize(new java.awt.Dimension(30000, 0));
        autoThreshInputsLowerPanel.setLayout(new javax.swing.BoxLayout(autoThreshInputsLowerPanel, javax.swing.BoxLayout.Y_AXIS));

        autoThresholdLabel.setFont(new java.awt.Font("Verdana", 1, 11)); // NOI18N
        autoThresholdLabel.setText("Generate thresholds automatically [optional]");
        autoThresholdLabel.setEnabled(false);
        autoThresholdLabel.setMaximumSize(new java.awt.Dimension(3200000, 50));
        autoThresholdLabel.setMinimumSize(new java.awt.Dimension(0, 25));
        autoThresholdLabel.setPreferredSize(new java.awt.Dimension(1000, 25));
        autoThreshInputsLowerPanel.add(autoThresholdLabel);

        thresholdCountLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        thresholdCountLabel.setText("Number of thresholds");
        thresholdCountLabel.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        thresholdCountLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        thresholdCountLabel.setEnabled(false);
        thresholdCountLabel.setMaximumSize(new java.awt.Dimension(32000, 32000));
        thresholdCountLabel.setMinimumSize(new java.awt.Dimension(0, 17));
        thresholdCountLabel.setPreferredSize(new java.awt.Dimension(1000, 17));
        thresholdCountLabel.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        autoThreshInputsLowerPanel.add(thresholdCountLabel);

        jPanel3.setMaximumSize(new java.awt.Dimension(32767, 1));
        jPanel3.setMinimumSize(new java.awt.Dimension(1, 1));
        jPanel3.setPreferredSize(new java.awt.Dimension(1000, 1));

        org.jdesktop.layout.GroupLayout jPanel3Layout = new org.jdesktop.layout.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 288, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 1, Short.MAX_VALUE)
        );

        autoThreshInputsLowerPanel.add(jPanel3);

        thresholdCountField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        thresholdCountField.setAlignmentX(0.4F);
        thresholdCountField.setAlignmentY(0.0F);
        thresholdCountField.setEnabled(false);
        thresholdCountField.setMaximumSize(new java.awt.Dimension(32000, 30));
        thresholdCountField.setMinimumSize(new java.awt.Dimension(0, 30));
        thresholdCountField.setPreferredSize(new java.awt.Dimension(1000, 30));
        autoThreshInputsLowerPanel.add(thresholdCountField);

        lowerBoundLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        lowerBoundLabel.setText("First threshold value");
        lowerBoundLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        lowerBoundLabel.setEnabled(false);
        lowerBoundLabel.setMaximumSize(new java.awt.Dimension(32000, 32767));
        lowerBoundLabel.setMinimumSize(new java.awt.Dimension(0, 27));
        lowerBoundLabel.setPreferredSize(new java.awt.Dimension(1000, 27));
        lowerBoundLabel.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        autoThreshInputsLowerPanel.add(lowerBoundLabel);

        lowerBoundField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        lowerBoundField.setAlignmentX(0.4F);
        lowerBoundField.setAlignmentY(0.0F);
        lowerBoundField.setEnabled(false);
        lowerBoundField.setMaximumSize(new java.awt.Dimension(32000, 30));
        lowerBoundField.setMinimumSize(new java.awt.Dimension(0, 30));
        lowerBoundField.setPreferredSize(new java.awt.Dimension(1000, 30));
        autoThreshInputsLowerPanel.add(lowerBoundField);

        intervalLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        intervalLabel.setText("Threshold increment (may be negative)");
        intervalLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        intervalLabel.setEnabled(false);
        intervalLabel.setMaximumSize(new java.awt.Dimension(32000, 32767));
        intervalLabel.setMinimumSize(new java.awt.Dimension(0, 27));
        intervalLabel.setPreferredSize(new java.awt.Dimension(1000, 27));
        intervalLabel.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        autoThreshInputsLowerPanel.add(intervalLabel);

        intervalField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        intervalField.setAlignmentX(0.4F);
        intervalField.setAlignmentY(0.0F);
        intervalField.setEnabled(false);
        intervalField.setMaximumSize(new java.awt.Dimension(32000, 30));
        intervalField.setMinimumSize(new java.awt.Dimension(0, 30));
        intervalField.setPreferredSize(new java.awt.Dimension(1000, 30));
        autoThreshInputsLowerPanel.add(intervalField);

        autoButtonPanel.setMaximumSize(new java.awt.Dimension(32000, 32000));
        autoButtonPanel.setMinimumSize(new java.awt.Dimension(0, 60));
        autoButtonPanel.setPreferredSize(new java.awt.Dimension(1000, 60));
        autoButtonPanel.setLayout(new javax.swing.BoxLayout(autoButtonPanel, javax.swing.BoxLayout.LINE_AXIS));

        autoAddButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        autoAddButton.setText("Add");
        autoAddButton.setAlignmentY(0.0F);
        autoAddButton.setEnabled(false);
        autoAddButton.setMargin(new java.awt.Insets(2, 12, 2, 12));
        autoAddButton.setMaximumSize(new java.awt.Dimension(65, 29));
        autoAddButton.setMinimumSize(new java.awt.Dimension(65, 29));
        autoAddButton.setPreferredSize(new java.awt.Dimension(65, 29));
        autoAddButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                autoAddButtonActionPerformed(evt);
            }
        });
        autoButtonPanel.add(autoAddButton);

        jPanel1417.setMaximumSize(new java.awt.Dimension(2, 500));
        jPanel1417.setMinimumSize(new java.awt.Dimension(2, 15));
        jPanel1417.setPreferredSize(new java.awt.Dimension(4, 20));

        org.jdesktop.layout.GroupLayout jPanel1417Layout = new org.jdesktop.layout.GroupLayout(jPanel1417);
        jPanel1417.setLayout(jPanel1417Layout);
        jPanel1417Layout.setHorizontalGroup(
            jPanel1417Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 2, Short.MAX_VALUE)
        );
        jPanel1417Layout.setVerticalGroup(
            jPanel1417Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 60, Short.MAX_VALUE)
        );

        autoButtonPanel.add(jPanel1417);

        autoResetButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        autoResetButton.setText("Set");
        autoResetButton.setAlignmentY(0.0F);
        autoResetButton.setEnabled(false);
        autoResetButton.setMargin(new java.awt.Insets(2, 12, 2, 12));
        autoResetButton.setMaximumSize(new java.awt.Dimension(65, 29));
        autoResetButton.setMinimumSize(new java.awt.Dimension(65, 29));
        autoResetButton.setPreferredSize(new java.awt.Dimension(65, 29));
        autoResetButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                autoResetButtonActionPerformed(evt);
            }
        });
        autoButtonPanel.add(autoResetButton);

        autoThreshInputsLowerPanel.add(autoButtonPanel);

        lowerSpacerPanel.setMaximumSize(new java.awt.Dimension(32000, 32757));
        lowerSpacerPanel.setMinimumSize(new java.awt.Dimension(0, 0));
        lowerSpacerPanel.setPreferredSize(new java.awt.Dimension(1000, 10000));
        autoThreshInputsLowerPanel.add(lowerSpacerPanel);

        autoThreshInputsPanel.add(autoThreshInputsLowerPanel);

        rightSpacerPanel.setMaximumSize(new java.awt.Dimension(450000, 32000));
        rightSpacerPanel.setMinimumSize(new java.awt.Dimension(0, 0));
        rightSpacerPanel.setPreferredSize(new java.awt.Dimension(40000, 0));
        autoThreshInputsPanel.add(rightSpacerPanel);

        mainPTPanel.add(autoThreshInputsPanel);

        bottomInsertPanel.add(mainPTPanel);

        moreButtonPanel.setMaximumSize(new java.awt.Dimension(32000, 29));
        moreButtonPanel.setMinimumSize(new java.awt.Dimension(0, 29));
        moreButtonPanel.setPreferredSize(new java.awt.Dimension(100, 29));
        moreButtonPanel.setLayout(new javax.swing.BoxLayout(moreButtonPanel, javax.swing.BoxLayout.LINE_AXIS));

        jPanel2.setAlignmentX(0.0F);
        jPanel2.setAlignmentY(0.0F);
        jPanel2.setMaximumSize(new java.awt.Dimension(32767, 29));
        jPanel2.setMinimumSize(new java.awt.Dimension(0, 29));
        jPanel2.setPreferredSize(new java.awt.Dimension(0, 29));
        jPanel2.setLayout(new java.awt.GridLayout(1, 0));
        moreButtonPanel.add(jPanel2);

        moreButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        moreButton.setText("More");
        moreButton.setAlignmentY(0.0F);
        moreButton.setEnabled(false);
        moreButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        moreButton.setMaximumSize(new java.awt.Dimension(65, 29));
        moreButton.setMinimumSize(new java.awt.Dimension(65, 29));
        moreButton.setPreferredSize(new java.awt.Dimension(65, 29));
        moreButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                moreButtonActionPerformed(evt);
            }
        });
        moreButtonPanel.add(moreButton);

        bottomInsertPanel.add(moreButtonPanel);

        bottomScrollPane.setViewportView(bottomInsertPanel);

        bottomPanel.add(bottomScrollPane);

        mainPanel.add(bottomPanel);

        add(mainPanel);

        navigationPanel.setMaximumSize(new java.awt.Dimension(32899, 40));
        navigationPanel.setMinimumSize(new java.awt.Dimension(142, 40));
        navigationPanel.setPreferredSize(new java.awt.Dimension(144, 40));
        navigationPanel.setLayout(new javax.swing.BoxLayout(navigationPanel, javax.swing.BoxLayout.LINE_AXIS));

        runButton.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        runButton.setText("Run");
        runButton.setAlignmentY(0.25F);
        runButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        runButton.setMaximumSize(new java.awt.Dimension(65, 29));
        runButton.setMinimumSize(new java.awt.Dimension(65, 29));
        runButton.setPreferredSize(new java.awt.Dimension(65, 29));
        runButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                runButtonActionPerformed(evt);
            }
        });
        navigationPanel.add(runButton);

        jPanel1416.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel1416.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel1416.setPreferredSize(new java.awt.Dimension(4, 10));
        navigationPanel.add(jPanel1416);

        runAllButton.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        runAllButton.setText("Run all");
        runAllButton.setAlignmentY(0.25F);
        runAllButton.setEnabled(false);
        runAllButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        runAllButton.setMaximumSize(new java.awt.Dimension(65, 29));
        runAllButton.setMinimumSize(new java.awt.Dimension(65, 29));
        runAllButton.setPreferredSize(new java.awt.Dimension(65, 29));
        runAllButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                runAllButtonActionPerformed(evt);
            }
        });
        navigationPanel.add(runAllButton);

        jPanel20.setMinimumSize(new java.awt.Dimension(10, 29));
        navigationPanel.add(jPanel20);

        backButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        backButton.setText("Back");
        backButton.setAlignmentY(0.25F);
        backButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        backButton.setMaximumSize(new java.awt.Dimension(65, 29));
        backButton.setMinimumSize(new java.awt.Dimension(65, 29));
        backButton.setPreferredSize(new java.awt.Dimension(65, 29));
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });
        navigationPanel.add(backButton);

        jPanel1414.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel1414.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel1414.setPreferredSize(new java.awt.Dimension(4, 10));
        navigationPanel.add(jPanel1414);

        nextButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        nextButton.setText("Next");
        nextButton.setAlignmentY(0.25F);
        nextButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        nextButton.setMaximumSize(new java.awt.Dimension(65, 29));
        nextButton.setMinimumSize(new java.awt.Dimension(65, 29));
        nextButton.setPreferredSize(new java.awt.Dimension(65, 29));
        nextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextButtonActionPerformed(evt);
            }
        });
        navigationPanel.add(nextButton);

        add(navigationPanel);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Attempts to open the document describing the current metric in an external browser.
     * 
     * @param evt an action event
     */
    private void browseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_browseActionPerformed
        String actualPath = "";
        try {
            HTMLDocument doc = (HTMLDocument) statisticTextPane.getDocument();
            URL url = doc.getBase();

            //the file is in EVS.jar or nonsrc/(when running in Eclipse) has been copied to the temporary dir already, need to modify the path
            actualPath = this.getFilePathInTempDir(url.toString());

            java.io.File f = new java.io.File(actualPath);
            if(!f.exists()) {
                throw new IllegalArgumentException("Cannot locate resource: "+actualPath+"."); 
            }
            BrowserControl.displayURL(actualPath);
        } catch (Exception e) {
            ExceptionHandler.displayException(new IllegalArgumentException(
                    "Cannot open '"+actualPath+"' in external browser. " + e.getMessage()));
        }
    }//GEN-LAST:event_browseActionPerformed

    /**
     * Show in external browser.
     *
     * @param evt an action event
     */
    private void statisticTextPaneMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_statisticTextPaneMouseReleased
        if (evt.getModifiers() == evt.BUTTON3_MASK) {
            if(statisticTable.getSelectedRowCount()>0) {
                browseMenu.show(statisticTextPane, evt.getX(), evt.getY());
            }
        }
    }//GEN-LAST:event_statisticTextPaneMouseReleased

    /**
     * Opens dialog for additional parameter values.
     *
     * @param evt an action event
     */
    private void moreButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_moreButtonActionPerformed
        int row = statisticTable.getSelectedRow();
        //Set the parameter options
        if (row > -1) {
            try {
                //Disable all by default, then enable included pars
                //Determine if decomposition is allowed for a score metric.
                Metric current = (Metric) statisticTable.getValueAt(row, 0);
                parOptions = new MoreParOptionsDialog(current, true);
                parOptions.setOptionsDisabled();
                LinkedHashMap<Metric, TreeMap<Integer, Object>> localMetrics
                        = localPars.get(VERIFICATION_A.getSelectedUnit());
                TreeMap<Integer, Object> pars = localMetrics.get(current);
                parOptions.setParameters(current, pars);
                EVSMainWindow.setWindowLocation(parOptions);
                parOptions.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_moreButtonActionPerformed

    /**
     * Deletes a selected probability threshold
     *
     * @param evt an action event
     */
    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        int[] rows = thresholdTable.getSelectedRows();
        if (rows.length > 0) {
            for (int i = rows.length - 1; i > -1; i--) {
                ((DefaultTableModel) thresholdTable.getModel()).removeRow(rows[i]);
            }
            saveLocalData();
        }
    }//GEN-LAST:event_deleteButtonActionPerformed

    /**
     * Adds an empty probability threshold
     *
     * @param evt an action event
     */
    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        int sel = thresholdTable.getSelectedRow();
        int row = -1;
        if (sel > -1) {
            ((DefaultTableModel) thresholdTable.getModel()).insertRow(sel + 1, new Object[]{"", null, Boolean.valueOf(true)});
            row = sel + 1;
        } else {
            ((DefaultTableModel) thresholdTable.getModel()).addRow(new Object[]{"", null, Boolean.valueOf(true)});
            row = thresholdTable.getRowCount() - 1;
        }
        //Add a listener to save changes
        final TableCellEditor ed = thresholdTable.getCellEditor(row, 0);
        ed.addCellEditorListener(new CellEditorListener() {

            public void editingStopped(ChangeEvent evt) {
                saveLocalData();
            }

            public void editingCanceled(ChangeEvent evt) {
            }
        });
    }//GEN-LAST:event_addButtonActionPerformed

    /**
     * Executes all verification units.
     *
     * @param evt an action event
     */
    private void runAllButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_runAllButtonActionPerformed
        try {
            runVerification(true);
        } catch (Throwable e) {
            CONSOLE.addMessage(StringUtilities.stackTraceToString(e));
            ExceptionHandler.displayException(e);
        }
    }//GEN-LAST:event_runAllButtonActionPerformed

    /**
     * Selects all statistics in the table automatically.
     *
     * @param evt an action event
     */
    private void selectStatsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectStatsActionPerformed
        selectAllStats(statisticTable.getRowCount() > 0 && !((Boolean) statisticTable.getValueAt(0, 2)).booleanValue());
        showLocalData();
        setStatTextBox();
    }//GEN-LAST:event_selectStatsActionPerformed

    /**
     * Executes the selected verification unit.
     *
     * @param evt an action event
     */
    private void runButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_runButtonActionPerformed
        try {
            runVerification(false);
        } catch (Throwable e) {
            CONSOLE.addMessage(StringUtilities.stackTraceToString(e));
            ExceptionHandler.displayException(e);
        }
    }//GEN-LAST:event_runButtonActionPerformed

    /**
     * Moves to the next window
     * 
     * @param evt an action event 
     */
    private void nextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextButtonActionPerformed
        JPanel verif = (JPanel) this.getParent();
        JTabbedPane parent = (JTabbedPane) verif.getParent();
        parent.setSelectedIndex((parent.getSelectedIndex()) + 1);  //Move to aggregation
    }//GEN-LAST:event_nextButtonActionPerformed

    /**
     * Returns to the last window.
     *
     * @param evt an action event
     */
    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        JPanel model = (JPanel) this.getParent();
        ((CardLayout) model.getLayout()).previous(model);
    }//GEN-LAST:event_backButtonActionPerformed

    /**
     * Append automatic thresholds to the thresholds table.
     *
     * @param evt an action event
     */
    private void autoAddButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_autoAddButtonActionPerformed
        try {
            addAutoThresholds(true);
        } catch (Exception e) {
            CONSOLE.addMessage(StringUtilities.stackTraceToString(e));
            ExceptionHandler.displayException(e);
        }
    }//GEN-LAST:event_autoAddButtonActionPerformed

    /**
     * Set automatic thresholds in the thresholds table, deleting any existing
     * thresholds.
     *
     * @param evt an action event
     */
    private void autoResetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_autoResetButtonActionPerformed
        try {
            addAutoThresholds(false);
        } catch (Exception e) {
            CONSOLE.addMessage(StringUtilities.stackTraceToString(e));
            ExceptionHandler.displayException(e);
        }
    }//GEN-LAST:event_autoResetButtonActionPerformed

    /**
     * Toggle the selection of main thresholds in the thresholds table.
     *
     * @param evt
     */
    private void toggleMainActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toggleMainActionPerformed
        if (thresholdTable.isEnabled() && thresholdTable.getRowCount() > 0) {
            //Toggle selection
            if (thresholdTable.getSelectedRowCount() > 0) {
                int[] rows = thresholdTable.getSelectedRows();
                for (int i = 0; i < rows.length; i++) {
                    thresholdTable.setValueAt(!((Boolean) thresholdTable.getValueAt(rows[i], 2)), rows[i], 2);
                }
            } //Toggle all
            else {
                int rows = thresholdTable.getRowCount();
                for (int i = 0; i < rows; i++) {
                    thresholdTable.setValueAt(!((Boolean) thresholdTable.getValueAt(i, 2)), i, 2);
                }
            }
        }
    }//GEN-LAST:event_toggleMainActionPerformed

    /**
     * Mouse released on the thresholds table.
     *
     * @param evt a mouse event
     */
    private void thresholdTableMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_thresholdTableMouseReleased
        if (evt.getModifiers() == evt.BUTTON3_MASK) {
            if (thresholdTable.isEnabled()) {
                thresholdTableMenu.show(thresholdTable, evt.getX(), evt.getY());  //Show menu on right click
            }
        }
    }//GEN-LAST:event_thresholdTableMouseReleased

    /**
     * Mouse released on the statistics table.
     *
     * @param evt a mouse event
     */
    private void statisticTableMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_statisticTableMouseReleased
        if (evt.getModifiers() == evt.BUTTON3_MASK) {
            tableMenu.show(statisticTable, evt.getX(), evt.getY());  //Show menu on right click
        }
    }//GEN-LAST:event_statisticTableMouseReleased

    /**
     * Apply thresholds for current metric to all other metrics, asking for
     * confirmation first.
     *
     * @param evt the action event
     */
    private void doAllButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_doAllButtonActionPerformed
        int n = JOptionPane.showOptionDialog(EVSMainWindow.main, "Apply the current thresholds to all selected metrics for this Verification Unit?", "Warning: apply to all metrics", JOptionPane.OK_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE, null, null, null);
        System.out.println("WARNING: applying thresholds to all metrics. This action will apply the current thresholds to all metrics.");
        if (n == JOptionPane.OK_OPTION) {
            try {
            	applyThresholdsToAll();
            } catch (Exception e) {
                CONSOLE.addMessage(StringUtilities.stackTraceToString(e));
                ExceptionHandler.displayException(e);
            }       
        } else {
            return; //No changes made
        }

    }//GEN-LAST:event_doAllButtonActionPerformed

    /**
     * Sets the current array of thresholds for all selected metrics.
     */
    private void applyThresholdsToAll() throws IllegalArgumentException {
        int row = statisticTable.getSelectedRow();
        //Set the parameter options
        if (row > -1) {
            //Disable all by default, then enable included pars
            //Determine if decomposition is allowed for a score metric.
            Metric current = (Metric) statisticTable.getValueAt(row, 0);
            VerificationUnit ver = VERIFICATION_A.getSelectedUnit();
            LinkedHashMap<Metric, TreeMap<Integer, Object>> p = localPars.get(ver);
            if (p != null) {
                Iterator it = p.keySet().iterator();
                Object[] thresh = getLocalThresholds();
                //Identify whether the thresholds are probabilities and the types of thresholds
                TreeMap<Integer,Object>  ppars = p.get(current);
                boolean prob = (Boolean)ppars.get(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER);
                Integer type = ((Integer) ppars.get(MetricParameter.INTEGER_PARAMETER));

                //Determine if one of the thresholds is unconditional, i.e. infinite
                boolean unconditional = false;
                double[] t = (double[]) thresh[0];
                boolean[] u = (boolean[]) thresh[1];
                String[] v = (String[]) thresh[2];
                double[] tminus = null;
                boolean[] uminus = null;
                String[] vminus = null;
                if (t != null && t.length > 0) {
                    //Throw exception when attempting to apply one 'All data' threshold
                	//to metrics that do not support this
                    if(hasDiscreteMetrics() && t.length==1 && Double.isInfinite(t[0])) {
                    	throw new IllegalArgumentException("Cannot apply the chosen threshold " +
                    			"to all metrics. The 'All data' threshold is not valid for " +
                    			"some metrics. Specify additional thresholds (and the 'All data' " +
                    			"threshold will be ignored automatically).");
                    }
                    tminus = new double[t.length];
                    uminus = new boolean[t.length];
                    vminus = new String[t.length];
                    int tot = 0;
                    for (int i = 0; i < t.length; i++) {
                        if (Double.isInfinite(t[i])) {
                            unconditional = true;
                        } else {
                            tminus[tot] = t[i];
                            uminus[tot] = u[i];
                            vminus[tot] = v[i];
                            tot++;
                        }
                    }
                    //Trim the array
                    if(unconditional) {
                    	double[] trimmedT = new double[tot];
                    	boolean[] trimmedU = new boolean[tot];
                    	String[] trimmedV = new String[tot];
                    	System.arraycopy(tminus,0,trimmedT,0,tot);
                    	System.arraycopy(uminus,0,trimmedU,0,tot);
                    	System.arraycopy(vminus,0,trimmedV,0,tot);
                    	tminus=trimmedT;
                    	uminus=trimmedU;
                    	vminus=trimmedV;
                    }
                    //Copy the appropriate parameters to all metrics
                    while (it.hasNext()) {
                        Metric m = (Metric) it.next();
                        TreeMap pars = p.get(m);
                        if (pars.containsKey(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER)) {
                            if (m.isDiscreteMetric() && unconditional) {
                                pars.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, tminus);
                                pars.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, uminus);
                                pars.put(MetricParameter.STRING_ARRAY_PARAMETER, vminus);
                            } else {
                                pars.put(MetricParameter.DOUBLE_PROCEDURE_ARRAY_PARAMETER, t);
                                pars.put(MetricParameter.BOOLEAN_ARRAY_PARAMETER, u);
                                pars.put(MetricParameter.STRING_ARRAY_PARAMETER, v);
                            }
                            //Add the type of condition
                            pars.put(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER,prob);
                            pars.put(MetricParameter.INTEGER_PARAMETER,type);
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Returns true if one or more metrics are chosen locally (in the table of metrics) 
     * that are defined only for discrete events, false otherwise.
     * 
     * @return true if one or more metrics are chosen that are defined only for discrete events
     */

    private boolean hasDiscreteMetrics() {
    	LinkedHashMap<Metric,TreeMap<Integer, Object>> local = 
    			localPars.get(VERIFICATION_A.getSelectedUnit());
    	if(local!=null) {
    		Iterator<Metric> it = local.keySet().iterator();
    		while(it.hasNext()) {
    			if(it.next().isDiscreteMetric()) {
    				return true;
    			}
    		}
    	}
    	return false;
    }
    
    /**
     * Appends or sets automatic thresholds to the thresholds table for the
     * current metric. If the input is true, appends to existing thresholds,
     * otherwise sets as new.
     *
     * @param append is true to append, false to set new
     */
    private void addAutoThresholds(boolean append) throws IllegalArgumentException {
        //Attempt to determine inputs
        int tCount = 0;
        double start = 0;
        double increment = 0;
        try {
            tCount = new Integer(thresholdCountField.getText());
            if (tCount <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Enter a positive integer number of thresholds.");
        }
        //Place a reasonable limit on the number of thresholds
        if (tCount >= 10000) {
            throw new IllegalArgumentException("Enter fewer than 10,000 thresholds.");
        }
        //Warn for more than 200 thresholds
        if (tCount > 200) {
            int n = JOptionPane.showOptionDialog(EVSMainWindow.main, "Continue with >200 thresholds (the computational time may be high)?", "Warning: computational time", JOptionPane.OK_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE, null, null, null);
            System.out.println("WARNING: computational time. Using more than 200 thresholds, which may substantially increase the computational time.");
            if (n != JOptionPane.OK_OPTION) {
                return;
            }
        }
        try {
            start = new Double(lowerBoundField.getText());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Enter a valid number for the first threshold.");
        }
        try {
            increment = new Double(intervalField.getText());
            if (increment == 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Enter a non-zero increment for the thresholds.");
        }
        DefaultTableModel tm = (DefaultTableModel) thresholdTable.getModel();
        if (!append) {
            tm.setRowCount(0);
        }
        for (int i = 0; i < tCount; i++) {
            tm.addRow(new Object[]{Mathematics.round(start + (i * increment), 8), null, false});
        }
    }

    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLES                              *
     *                                                                              *
     *******************************************************************************/
    /**
     * The metric index for saving local data.
     */
    private int saveIndex = -1;
    /**
     * Store of local metrics to be deep copied before saving to a verification 
     * unit.  The metrics are stored with their local (possibly invalid) parameter
     * values.  The local data are stored as generic objects to allow the possibility
     * of checking values ONLY on saving them (e.g. if they were stored as MetricParameter
     * objects this would not be possible).  They are stored against their integer 
     * parameter value types in a map.  See the evs.metric.MetricParameter class
     * for parameter types.  Each verification unit has a parameter map.  The map is
     * stored in another map, where it is referenced by the verification unit.
     */
    private LinkedHashMap<VerificationUnit, LinkedHashMap<Metric,
            TreeMap<Integer, Object>>> localPars = new LinkedHashMap();
    /**
     * HTML document for the statistics text pane.
     */
    private HTMLDocument defaultDoc = new HTMLDocument();
    /**
     * Parameter options dialog.
     */
    private MoreParOptionsDialog parOptions = null;
    /**
     * Default metrics with their default parameter values.
     */
    private LinkedHashMap<Metric, TreeMap<Integer, Object>> defaultMetrics = new LinkedHashMap();
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JButton autoAddButton;
    private javax.swing.JPanel autoButtonPanel;
    private javax.swing.JButton autoResetButton;
    private javax.swing.JPanel autoThreshInputsLowerPanel;
    private javax.swing.JPanel autoThreshInputsPanel;
    private javax.swing.JLabel autoThresholdLabel;
    private javax.swing.JButton backButton;
    private javax.swing.JPanel bottomInsertPanel;
    private javax.swing.JPanel bottomPanel;
    private javax.swing.JScrollPane bottomScrollPane;
    private javax.swing.JMenuItem browse;
    private javax.swing.JPopupMenu browseMenu;
    private javax.swing.JButton deleteButton;
    private javax.swing.JButton doAllButton;
    private javax.swing.JTextField intervalField;
    private javax.swing.JLabel intervalLabel;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel1413;
    private javax.swing.JPanel jPanel1414;
    private javax.swing.JPanel jPanel1416;
    private javax.swing.JPanel jPanel1417;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel leftPanel;
    private javax.swing.JScrollPane leftScrollPane;
    private javax.swing.JTextField lowerBoundField;
    private javax.swing.JLabel lowerBoundLabel;
    private javax.swing.JPanel lowerSpacerPanel;
    private javax.swing.JPanel mainPTPanel;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JPanel manualThresholdPanel;
    private javax.swing.JPanel middleSpacerPanel;
    private javax.swing.JButton moreButton;
    private javax.swing.JPanel moreButtonPanel;
    private javax.swing.JPanel navigationPanel;
    private javax.swing.JButton nextButton;
    private javax.swing.JPanel ptButtonMenu;
    private javax.swing.JScrollPane ptTableScrollPane;
    private javax.swing.JPanel rightPanel;
    private javax.swing.JScrollPane rightScrollPane;
    private javax.swing.JPanel rightSpacerPanel;
    private javax.swing.JButton runAllButton;
    private javax.swing.JButton runButton;
    private javax.swing.JMenuItem selectStats;
    private javax.swing.JTable statisticTable;
    private javax.swing.JEditorPane statisticTextPane;
    private javax.swing.JPopupMenu tableMenu;
    private javax.swing.JTextField thresholdCountField;
    private javax.swing.JLabel thresholdCountLabel;
    private javax.swing.JLabel thresholdLabel;
    private javax.swing.JTable thresholdTable;
    private javax.swing.JPopupMenu thresholdTableMenu;
    private javax.swing.JMenuItem toggleMain;
    private javax.swing.JPanel topPanel;
    private javax.swing.JSplitPane topSplitPane;
    // End of variables declaration//GEN-END:variables

    /********************************************************************************
     *                                                                              *
     *                              INNER CLASSES                                   *
     *                                                                              *
     *******************************************************************************/
    
    /**
     * Listens for hyperlink actions.
     */
    
    private static class HyperlinkListenerExtended implements HyperlinkListener {

        /**
         * Opens a hyperlink.
         *
         * @param evt a hyperlink event
         */
        
        public void hyperlinkUpdate(HyperlinkEvent evt) {
            if (evt.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
                String actualPath = "";
                try {
                    actualPath = evt.getURL().toString();
                    //Process a local file path: it has been copied to the temporary dir already, need to modify the path
                    if(!actualPath.contains("http")) {
                        actualPath = VERIFICATION_B.getFilePathInTempDir(actualPath);
                    }
                    BrowserControl.displayURL(actualPath);
                } catch (Exception e) {
                    ExceptionHandler.displayException(new IllegalArgumentException(
                            "Cannot open '" + actualPath + "' in external browser. " + e.getMessage()));
                }
            }
        }
    }

    /**
     * The whole directory "statsexplained" in EVS.jar (when running in JAR mode)
     * or under nonsrc/(when running in Eclipse) has been copied to the Java's
     * temporary directory(in Linux, it is /tmp/; in PC, it is C:\temp) for the
     * web browser to open them. When running in JAR mode, fileNameInJarOrNonsrc
     * has form "xx/EVS.jar!/statsexplained/crps.htm"(one example); In Eclipse,
     * the same code works too, but fileNameInJarOrNonsrc value is like
     * "xx/HEFS/trunk/evs/nonsrc/statsexplained/crps.htm". In both cases, it is necessary
     * to convert them to "/tmp/statsexplained/crps.htm"
     */
    private String getFilePathInTempDir(final String fileNameInJarOrNonsrc) throws Exception {
        final int index = fileNameInJarOrNonsrc.indexOf(EVSConstants.STATS_EXPLAINED_DIR);
        final String fileNameWithParentDir = fileNameInJarOrNonsrc.substring(index+1); //now fileNameWithParentDir is "statsexplained/crps.htm"
        return StringUtilities.cleanPath(EVSMainWindow.tempDir + fileNameWithParentDir);
    }
}
