package evs.gui.windows;

//SwingWorker: use local version when backporting to Java 1.5
import javax.swing.SwingWorker;
//import evs.gui.utilities.SwingWorker;

//Java swing dependencies
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import javax.swing.event.*;
   
//Java awt dependencies  
import java.awt.*;

//Java IO dependencies
import java.io.File;

//Java util dependencies
import java.util.*;

//Java beans dependencies
import java.beans.*;

//EVS dependencies
import evs.analysisunits.VerificationUnit;
import evs.analysisunits.AggregationUnit;
import evs.analysisunits.AnalysisUnit;
import evs.data.FileDataSource;
import evs.data.PairedDataSource;
import evs.data.DataSource;
import evs.utilities.*;
import evs.utilities.mathutil.*;

/**
 * The first aggregation window where the user manages spatial aggregation units and 
 * their associated attributes.  In this context, an aggregation unit is a set of
 * river segments with common parameters (time-series and environmental variable IDs
 * among others).
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class AggregationA extends JPanel implements GUIInterface {
  
/*******************************************************************************
 *                                                                             *
 *                                CONSTRUCTOR                                  *
 *                                                                             *
 ******************************************************************************/
    
    /**
     * Construct the import dialog.
     */
    
     protected AggregationA() {
        initComponents();
        setPanelsEnabled(false);
        //Add a selection changed method to the table
        ListSelectionListener listen = new ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                int row = unitsTable.getSelectedRow();
                //Value is adjusting due to GUI selection? 
                //NB: not caught by programatic selection, i.e. setRowSelectionInterval
                int[] rows = unitsTable.getSelectedRows();
                if (!evt.getValueIsAdjusting()) {
                        //ALWAYS show local data, regardless of whether single row or 
                        //multi-row selected. For multi-row, {@link showLocalData} uses
                        //anchor selection index of the multi-row selection
                        showLocalData();
                } //If the value is adjusting, save the data for the old selection
                else {
                    //JB@16th May 2013: avoid save for multi-row selection in progress
                    if (rows != null && rows.length == 1) {
                        saveLocalData();
                        //Finally, set the index for saving data, which will then correspond to the last
                        //selected index
                        saveIndex = row;
                    }
                }
                //Update sticky index if a valid selection has been made: this will be used to
                //retain selections across saves where possible, i.e. subject to being a sensible 
                //selection {@link showLocalData}
                if(row!=-1) {
                    //JB@16th May 2013: avoid update for multi-row selection
                    if (rows != null && rows.length == 1) {
                        stickyIndex = row;
                    }
                }
            }
        };

        //Set the listener
        unitsTable.getSelectionModel().addListSelectionListener(listen);
        unitsTable.getColumnModel().getSelectionModel().addListSelectionListener(listen);
        
        segmentsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Unique identifier", "Weight", "Include?"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }

            public void fireTableRowsDeleted(int firstRow, int lastRow) {
                super.fireTableRowsDeleted(firstRow, lastRow);
                segmentsTable.setPreferredSize(new Dimension(75,segmentsTable.getRowHeight()
                        *(segmentsTable.getRowCount()+1)));
            }
            public void fireTableRowsInserted(int firstRow, int lastRow) {
                super.fireTableRowsInserted(firstRow, lastRow);
                segmentsTable.setPreferredSize(new Dimension(75,segmentsTable.getRowHeight()
                        *(segmentsTable.getRowCount()+1)));
            }

            /*
             * Re-weight when selection changes if uniformly weighted
             */
            public void setValueAt(Object aValue, int row, int column) {
                super.setValueAt(aValue, row, column);
                //Re-weight as necessary
                if(column==2) {
                    //Reweight to equal weights if everything in the
                    //weight column is either zero or non-zero and constant
                    int rows = getRowCount();
                    boolean equal = true;
                    String test = null;
                    double count = 0.0;
                    for (int i = 0; i < rows; i++) {
                        if(getValueAt(i,2).equals(true)) {
                            count++;
                        }
                        String val = getValueAt(i,1).toString();
                        if(!val.equals("0.0")) {
                            if(test!=null) {
                                if(!test.equals(val)) {
                                    equal=false;
                                }
                            }
                            else {
                                test=val;
                            }
                        }
                    }
                    if (equal) {
                        if (count > 0) {
                            //Assign equal weights based on selected rows
                            double newW = 1.0 / count;
                            for (int i = 0; i < rows; i++) {
                                if (getValueAt(i, 2).equals(true)) {
                                    super.setValueAt(newW + "", i, 1);
                                } else {
                                    super.setValueAt(0.0 + "", i, 1);
                                }
                            }
                        }
                        else {
                            super.setValueAt("0.0",row,1);
                        }
                    }                    
                }
            }
        });       
        
        //Increases the table row height
        unitsTable.setRowHeight(25);
        segmentsTable.setRowHeight(25);
        unitsTable.getSelectionModel().setSelectionMode(unitsTable.getSelectionModel().MULTIPLE_INTERVAL_SELECTION);
        segmentsTable.getColumnModel().getColumn(0).setPreferredWidth(5000);
        segmentsTable.getColumnModel().getColumn(1).setPreferredWidth(850);
        segmentsTable.getColumnModel().getColumn(2).setPreferredWidth(850);

        //Add some default units on the basis of available verification units
        //addDefaultUnits(null);

        setVisible(true);
    }
     
/********************************************************************************
 *                                                                              *
 *                           INHERITED PUBLIC METHODS                           *
 *                                                                              *
 *******************************************************************************/          
    
    /**
     * Closes any open dialogs or frames associated with the GUI window.
     */
     
    public void disposeOfChildren() {
        //No dialogs or frames to close
    }

    /**
     * Clears the window.
     */
    public void clearAllLocalData() {
        ((DefaultTableModel) unitsTable.getModel()).setRowCount(0);
        ((DefaultTableModel) segmentsTable.getModel()).setRowCount(0);
        localData.clear();
        setPanelsEnabled(false);
        saveIndex=-1;  //@29th Nov. 2011
    }  
     
    /**
     * Attempts to save the local parameter values to aggregation units.  Throws 
     * an exception if any of the input parameters are undefined or take incorrect 
     * values.  This is a local save for the current window.
     *
     * TODO: store the local parameters in an indexed HashMap, following the
     * implementation in VerificationA.java, rather than an Object array with 
     * assumed index structure.
     * 
     * @return true if the data were saved
     */
    
    public boolean saveData() throws IllegalArgumentException {
        //Update any recent changes to the selected unit
        saveLocalData();
        Iterator i = localData.keySet().iterator();
        
        //Obtain the latest verification units for updating
        Vector<VerificationUnit> v = VERIFICATION_A.getVerificationUnits();
        while(i.hasNext()) {
            AggregationUnit next = (AggregationUnit)i.next();          
            Object[] pars = localData.get(next);
            
            //Store the original parameters until all succesfully set
            String origId = next.getAggregationID();
            DataSource origOut = next.getOutputData();
            ArrayList<VerificationUnit> origUnits = next.getVerificationUnits();
            ArrayList<Double> origWeights = next.getWeights();
            
            try {
                //Temporary name differs from the current name for this
                //unit and is the same as another name in the map: throw an exception
                if (!pars[0].equals(next.toString()) && localData.containsKey(new AggregationUnit(pars[0] + ""))) {
                    throw new IllegalArgumentException("Specify a unique name for each aggregation unit.");
                }
                next.setAggregationID(pars[0] + "");

                //Set the output path if defined
                if (pars[4] != null && !pars[4].equals("")) {
                    next.setOutputData(new FileDataSource(new File(pars[4] + "")));
                }
                Vector<VerificationUnit> current = (Vector) pars[1];
                ArrayList<VerificationUnit> include = new ArrayList<VerificationUnit>();
                ArrayList<Double> w = new ArrayList<Double>();

                //The current weights
                double[] wgh = (double[]) pars[3];

                boolean[] t = (boolean[]) pars[2];
                for (int j = 0; j < t.length; j++) {
                    if (t[j]) {
                        include.add(v.get(v.indexOf(current.get(j))));
                        w.add(wgh[j]);
                    }
                }
                //Warn in case of changes to existing data
            /*int length = current.size();
                 for(int j = 0; j < length; j++) {
                 //Change will take place
                 if(current.get(j).hasAggregationUnit() != t[j]) {
                 int n = JOptionPane.showOptionDialog(EVSMainWindow.main,"Any changes will affect previously saved units.  Proceed?","Warning: data changes elsewhere", JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
                 if(n == JOptionPane.NO_OPTION) {
                 return false;
                 }
                 break; //Ask once
                 }
                 }*/

                //Associate the aggregation unit with the current verification unit, in case no verification
                //units have yet been selected for inclusion (when they are, associations are updated automatically)
                //VERIFICATION_A.getSelectedUnit().setAggregationUnit(next);

                //Set the verification units for the current aggregation unit
                if (include.size() > 0) {
                    //Coordinates with all other units
                    next.setVerificationUnits(include, w);
                } //Delete all verification units from the current aggregation unit, but do not delete reference
                else {
                    next.deleteVerificationUnits(false);
                }
            } catch (Exception e) {
                //Restore original state and throw exception
                next.setAggregationID(origId);
                next.setOutputData(origOut);
                next.setVerificationUnits(origUnits, origWeights);
                throw new IllegalArgumentException(e.getMessage());
            }
        }
        return true;
    }     
          
    /**
     * Saves local data in the active input fields to a temporary store.
     */
    
    public void saveLocalData() throws IllegalArgumentException {   
        //JB@4th Oct 2012
//        if(saveIndex == -1) {
//            saveIndex = unitsTable.getSelectedRow();
//        }
        int rows = unitsTable.getRowCount();
        //Sensibility check: verify that saveIndex < rows in case a conflict occurs
        if(saveIndex > -1 && rows > 0 && saveIndex < rows && unitsTable.getValueAt(0,0) != null 
                && segmentsTable.getRowCount()>0) {
            AggregationUnit agg = (AggregationUnit)unitsTable.getValueAt(saveIndex,0);
            Object[] pars = localData.remove(agg);  
            String newName = aggregationIDField.getText();
            pars[0] = newName;
            localData.put(agg,pars);
            int length = segmentsTable.getRowCount();            
            boolean[] b = new boolean[length];            
            double[] w = new double[length];
            pars[2] = b;
            pars[3] = w;
            for(int i = 0; i < length; i++) {
                String s = segmentsTable.getValueAt(i,1)+""; 
                if(!s.equalsIgnoreCase("S")) {
                    try { 
                        w[i] = new Double(s);
                    }
                    catch(Exception e) {
                        throw new IllegalArgumentException("Numeric input in [0,1] required for weights.");
                    }
                } else {
                    w[i] = AggregationUnit.SAMPLE_WEIGHTS_FIRST_TIME;
                }
                b[i] = (Boolean)segmentsTable.getValueAt(i,2);
            }
            pars[4] = outputFolderField.getText();
        }
    }
    
    /**
     * Displays the local data previously saved to a temporary store.  Local data 
     * should always be displayed in preference to saved data, because saved data 
     * should be used to update the store of local data once available.
     */
    
    public void showLocalData() {
        //JB @ 16th May 2013: fixed bug to ensure anchor selection index 
        //is used when performing mult-row selection.
        int row = unitsTable.getSelectionModel().getAnchorSelectionIndex();
        if(row > -1 && row < unitsTable.getRowCount()) {  //JB @ 17th May: check rows in table, not in localData
            AggregationUnit unit = (AggregationUnit)unitsTable.getValueAt(row,0);
            Object[] pars = localData.get(unit);
            //Set window title
            ((TitledBorder)rightPanel.getBorder()).setTitle("Properties of '"+pars[0]+"'");
            setPanelsEnabled(true);
            //Display the identifier
            aggregationIDField.setText(pars[0]+"");
            Vector<VerificationUnit> v = (Vector)pars[1];
            VerificationUnit f = v.get(0);
            //Display the common properties of the aggregation unit
            variableIDField.setText(f.getVariableID());
            if(f.hasLeadTimes()) {
                firstLeadTime.setText(f.getFirstLeadTime()+" "+f.getForecastLeadTimeUnits());
                lastLeadTime.setText(f.getLastLeadTime()+" "+f.getForecastLeadTimeUnits());
            }
            if(f.hasResolution()) {
                verificationResolutionField.setText(f.getResolution()+" "+f.getResolutionUnits());
            }
            else {
                verificationResolutionField.setText("NONE");
            }
            //Dates: find earliest start date and latest end date
            Calendar start = f.getStartDate();;
            Calendar end = f.getEndDate();
            int tot = v.size();
            for(int i = 1; i < tot; i++) {
                if(v.get(i).getStartDate().before(start)) {
                    start = v.get(i).getStartDate();
                }
                if(v.get(i).getEndDate().after(end)) {
                    end = v.get(i).getEndDate();
                }
            }
            startYearField.setText(start.get(start.YEAR)+"");
            startMonthField.setText((start.get(start.MONTH)+1)+"");  //Zero-based index
            startDayField.setText(start.get(start.DAY_OF_MONTH)+"");
            endYearField.setText(end.get(end.YEAR)+"");
            endMonthField.setText((end.get(end.MONTH)+1)+"");  //Zero-based index
            endDayField.setText(end.get(end.DAY_OF_MONTH)+"");
            
            //Add the units to the table
            boolean[] sel = (boolean[])pars[2];
            double[] w = (double[])pars[3];
            
            DefaultTableModel mod = (DefaultTableModel)segmentsTable.getModel();
            mod.setRowCount(0);
            for(int i = 0; i < tot; i++) {
                String s = "0.0";  //Zero weight by default
                if(sel[i]) {  //Update weight if selected
                    if (w[i] == AggregationUnit.SAMPLE_WEIGHTS_FIRST_TIME) {
                        s = "S";
                    }
                    else {
                        s = w[i]+"";
                    }
                }
                mod.addRow(new Object[]{v.get(i),s,sel[i]});
            }

            //Set the output path
            if(pars[4] != null) {
                outputFolderField.setText(pars[4]+"");
            }
        }
        else {
            //Clear window title
            ((TitledBorder)rightPanel.getBorder()).setTitle("2. Edit properties of selected aggregation unit (none selected)");
            setPanelsEnabled(false);
        }  
    }
    
    /**
     * Updates local data with a unit. 
     *
     * @param unit the unit
     */
    
    public void updateLocalData(AnalysisUnit unit) {
        //Do not use input unit in this context, obtain all VUs from first window
        //Clear the window
        clearAllLocalData();
        //Add all of the aggregation units currently defined (i.e. iterate through all verification units)
        Vector<VerificationUnit> u = VERIFICATION_A.getVerificationUnits();
        int length = u.size();
        for(int i = 0; i < length; i++) {
            //Only add unique units
            ArrayList<AggregationUnit> next = u.get(i).getAggregationUnits();
            for (AggregationUnit a : next) {
                if (!localData.containsKey(a) && a.hasVerificationUnits()) {  //JB @20th March 2013.  Do not show empty units
                    //Define the local parameters
                    Object[] pars = new Object[5];
                    pars[0] = a.getAggregationID();
                    ArrayList<VerificationUnit> v = a.getVerificationUnits();
                    Vector<VerificationUnit> v2 = new Vector();
                    //JB @20th March 2013.  Do not show empty units
                    //No verification units yet defined
//                    if (!a.hasVerificationUnits()) {
//                        v2 = getCandidateSegments(u.get(i));
//                    } //Units already defined
//                    else {
                    for (VerificationUnit vu : v) {
                        v2.add(vu);
                    }
                    //Add any additional candidate segments recently defined
                    for (int j = 0; j < length; j++) {
                        VerificationUnit test = u.get(j);
                        if (!a.containsUnit(test) && test.aggregationEquals(v.get(0), false)) {
                            v2.add(test);
                        }
                    }
//                    }
                    pars[1] = v2;
                    boolean[] b = new boolean[v2.size()];
                    double[] weights = new double[v2.size()];
                    for (int j = 0; j < b.length; j++) {
                        b[j] = a.containsUnit(v2.get(j));
                        weights[j] = 1.0 / b.length;
                    }
                    if (a.hasWeights()) {
                        weights = EVSUtilities.toDoubleArray(a.getWeights());
                    }

                    pars[2] = b;

                    //Set the weights
                    pars[3] = weights;

                    if (a.hasOutputData()) {
                        pars[4] = a.getOutputData().getData().toString();
                    }
                    //Add to the store
                    localData.put(a, pars);
                }
            }
        }

        //Coordinate with units table
        DefaultTableModel d = (DefaultTableModel)unitsTable.getModel();
        d.setRowCount(0);
        Iterator it = localData.keySet().iterator();
        while(it.hasNext()) {
            d.addRow(new Object[]{it.next()});
        }        

        //Add any potential default units that are not in the store
        //Re-set the defaults: this methods adds rows to the units table
        addDefaultUnits(getAggregationUnits());

        //@JB 5th October 2012. Update row selection and save index when updating data
        int row = unitsTable.getSelectedRow();
        if(row == -1) {
            if(unitsTable.getRowCount()>0) {
                //If null, attempt to display last valid index, otherwise display last item
                if(stickyIndex!=-1 && stickyIndex < unitsTable.getRowCount()) {
                    row = stickyIndex;
                } else {
                    row = unitsTable.getRowCount()-1;
                }
                unitsTable.setRowSelectionInterval(row,row);
            }
            //Update save index because row selection does not trigger table listener on value is adjusting
            saveIndex = row;
        }
    }
    
    /**
     * Removes local data from the temporary store for a specified AnalysisUnit. 
     *
     * @param unit the unit
     */
    
    public void clearLocalData(AnalysisUnit unit) {
        //UPDATED 07/09/09
        localData.remove((AggregationUnit)unit);
        DefaultTableModel t = (DefaultTableModel)unitsTable.getModel();
        int tot = t.getRowCount();
        for(int i = (tot-1); i > -1; i--) {
            if(t.getValueAt(i,0).equals(unit)) {
                t.removeRow(i);
            }
        }
        showLocalData();
        //clearAllLocalData();
    }
  
/********************************************************************************
 *                                                                              *
 *                              PROTECTED METHODS                               *
 *                                                                              *
 *******************************************************************************/     

    /**
     * Returns the selected aggregation unit or null.
     *
     * @return the selected aggregation unit
     */
    
    protected AggregationUnit getSelectedUnit() {
        AggregationUnit selected = null;
        int row = unitsTable.getSelectedRow();
        if(row > -1) {
            selected = (AggregationUnit)unitsTable.getValueAt(row,0);
        }
        return selected;
    }    
    
    /**
     * Returns the selected aggregation unit or null.
     *
     * @return the selected aggregation unit
     */
    
    protected ArrayList<AggregationUnit> getSelectedAggregationUnits() {
        ArrayList<AggregationUnit> units = new ArrayList<AggregationUnit>();
        int[] rows = unitsTable.getSelectedRows();
        for(int i = 0; i < rows.length; i++) {
            units.add((AggregationUnit)unitsTable.getValueAt(rows[i],0));
        }
        return units;
    }      
    
    /**
     * Returns all aggregation units currently loaded.
     *
     * @return the aggregation units
     */
    
    protected Vector<AggregationUnit> getAggregationUnits() {
        return new Vector(localData.keySet());
    }
    
    /**
     * Returns the candidate river segments for aggregation based on the selected
     * aggregation unit.  
     *
     * @param test the unit to test
     * @return the candidate river segments for aggregation
     * @deprecated
     */
    
    protected Vector<VerificationUnit> getCandidateSegments(VerificationUnit test) {
        Vector units = new Vector();
        if(test != null && test.isAggregationCandidate()) {
            Vector<VerificationUnit> all = VERIFICATION_A.getVerificationUnits();
            int length = all.size();
            for(int i = 0; i < length; i++) {
                VerificationUnit next = all.get(i);
                if(next.aggregationEquals(test,false)) {
                    units.add(next);
                }
            }
        }
        return units;
    }
    
    /**
     * Returns true if a unit is selected, false otherwise.
     *
     * @return true if a unit is selected, false otherwise.
     */ 
    
    protected boolean unitIsSelected() {
        return unitsTable.getSelectedRow() >-1;
    }    
    
    /**
     * Synchronizes the locationID and additionalID of verification units in the 
     * local store that match the first argument with the names of units at the 
     * corresponding indices of the second argument.
     *    
     * @param oldU the old verification units
     * @param newU the new verification units
     */
    
    protected void synchronizeVUNames(VerificationUnit[] oldU, VerificationUnit[] newU) {
        for(Iterator i = localData.keySet().iterator(); i.hasNext();) {
            Vector<VerificationUnit> v = (Vector<VerificationUnit>)localData.get(i.next())[1]; 
            int sz = v.size();
            for(int j = 0; j < sz; j++) {
                //Look for match in oldU
                VerificationUnit next = v.get(j);
                for(int k = 0; k < oldU.length; k++) {
                    if(next.equals(oldU[k])) {
                        next.setLocationID(newU[k].getLocationID());
                        if(newU[k].hasAdditionalID()) {
                            next.setAdditionalID(newU[k].getAdditionalID());
                        }
                    }
                }
            }
        }
    }
    
/********************************************************************************
 *                                                                              *
 *                                PRIVATE METHODS                               *
 *                                                                              *
 *******************************************************************************/
         
    /**
     * Adds some default units on the basis of the available verification units.
     * Do not set any verification units (these must be selected by the user for
     * a given aggregation unit).  If the existingUnits variable is not null, the
     * default units will be coordinated with the existing units, and defaults will
     * only be added if they differ from the existing units.
     *
     * @param existingUnits a vector of existing units
     */
    
    private void addDefaultUnits(Vector<AggregationUnit> existingUnits) {
        Vector<VerificationUnit> u = VERIFICATION_A.getVerificationUnits();
        int length = u.size();
        DefaultTableModel mod = (DefaultTableModel)unitsTable.getModel();

        //JB @ 8th March 2013 Simplified buggy method        
        
        //Obtain the unique sets of VUs that form candidate AUs
        Vector<String> used = new Vector<String>();  //List of VUs that already form part of an AU and cannot be re-used
        //Add the VUs from any existing AUs to the list
        Iterator it = localData.keySet().iterator();
        while(it.hasNext()) {
            AggregationUnit ag = (AggregationUnit) it.next();
            ArrayList<VerificationUnit> v = ag.getVerificationUnits();
            if (v != null) {
                for (VerificationUnit vu : v) {
                    used.add(vu.toString());
                }
            }
        }
        
        for(int i = 0; i < length; i++) {
            VerificationUnit next = u.get(i);
            String currentName = next.toString();
            //Proceed to define the unique set of comparable VUs
            if(!used.contains(currentName)) {
                Vector<VerificationUnit> nextDefault = new Vector<VerificationUnit>();
                nextDefault.add(next);
                for(int j = 0; j < length; j++) {
                    VerificationUnit test = u.get(j);
                    String checkName = test.toString();
                    if(!currentName.equals(checkName)) {
                        if(test.aggregationEquals(next,false)) {
                            nextDefault.add(test);
                            used.add(checkName);
                        }
                    }
                }
                //Construct the AU
                if(nextDefault.size()>1) {
                    //Add the name of the current VU. The names of the associated VUs were added above
                    used.add(currentName);
                    String name = "Default_unit_";
                    AggregationUnit a = null;
                    //Find a valid name for the default unit
                    int rows = u.size();  //Cannot be more rows to check than verification units
                    for (int j = 0; j < rows; j++) {   //Places finite count on aggregation units
                        AggregationUnit candidate = new AggregationUnit(name + (j + 1));
                        boolean g = true;
                        if (existingUnits != null) {
                            if (existingUnits.contains(candidate)) {
                                g = false;
                            }
                        }
                        if (g && !localData.containsKey(candidate)) {
                            a = candidate;
                            break;  //Found available name
                        }
                    }
                    if (a != null) {
                        //System.out.println("Adding default aggregation unit: " + a);
                        //Add the unit with its candidate segments
                        Object[] pars = new Object[5];
                        pars[0] = a.getAggregationID();
                        pars[1] = nextDefault;
                        pars[2] = new boolean[nextDefault.size()];

                        //Equal weights by default
                        double[] p3 = new double[nextDefault.size()];
                        Arrays.fill(p3, 1.0 / p3.length);
                        pars[3] = p3;

                        if (u.get(i).hasOutputData()) {
                            pars[4] = ((File) u.get(i).getOutputData().getData()).getPath();   //JB @ 19th March (relative path allowed)
                        }
                        localData.put(a, pars);
                        mod.addRow(new Object[]{a});
                    }
                }
            }

//JB @ 8th March 2013            
//        //Unique hash codes of the string combinations of candidate segments        
//        Vector<Integer> codes = new Vector();
//        for(int i = 0; i < length; i++) {
//            //Add new unit once all parameters are available.  Only add a unique unit.
//            Vector<VerificationUnit> cand = getCandidateSegments(u.get(i));
//            if(cand.size()>1) {
//                StringBuffer b = new StringBuffer();
//                int tot = cand.size();
//                for(int j = 0; j < tot; j++) {
//                    b.append(cand.get(j));
//                }
//                String amal = b.toString();
//                //Create the hashcode
//                int code = amal.hashCode();
//                if(!codes.contains(code)) {
//                    codes.add(amal.hashCode());
//                    //Only add units that have not already been added
//                    //i.e. those with different sets of candidate verification units
//                    boolean go = true;
//                    if(existingUnits!=null) {
//                        int len = existingUnits.size();
//                        for(int j = 0; j < len; j++) {
//                            if (existingUnits.get(j).hasVerificationUnits()) {
//                                VerificationUnit[] t = existingUnits.get(j).getVerificationUnits();
//                                //If they share at least one verification unit in common, don't add a new unit.
//                                int sz = cand.size();
//                                if (t.length >= sz) {
//                                    for (int k = 0; k < sz; k++) {
//                                        if (cand.get(k).toString().equals(t[k].toString())) {
//                                            go = false;
//                                            break;
//                                        }
//                                    }
//                                } else {
//                                    for (int k = 0; k < t.length; k++) {
//                                        if (t[k].toString().equals(cand.get(k).toString())) {
//                                            go = false;
//                                            break;
//                                        }
//                                    }
//                                }
//                            }
//                        }
//                    }
//
//                    //Add a new default unit
//                    if (go) {
//                        String name = "Default_unit_";
//                        AggregationUnit a = null;
//                        //Find a valid name for the default unit
//                        int rows = u.size();  //Cannot be more rows to check than verification units
//                        for (int j = 0; j < rows; j++) {   //Places finite count on aggregation units
//                            AggregationUnit candidate = new AggregationUnit(name + (j + 1));
//                            boolean g = true;
//                            if (existingUnits != null) {
//                                if (existingUnits.contains(candidate)) {
//                                    g = false;
//                                }
//                            }
//                            if (g && !localData.containsKey(candidate)) {
//                                a = candidate;
//                                break;  //Found available name
//                            }
//                        }
//                        if (a != null) {
//
//                            //System.out.println("Adding default aggregation unit: " + a);
//
//                            //Add the unit with its candidate segments
//                            Object[] pars = new Object[5];
//                            pars[0] = a.getAggregationID();
//                            pars[1] = cand;
//                            pars[2] = new boolean[cand.size()];
//
//                            //Equal weights by default
//                            double[] p3 = new double[cand.size()];
//                            Arrays.fill(p3, 1.0 / p3.length);
//                            pars[3] = p3;
//
//                            if (u.get(i).hasOutputData()) {
//                                pars[4] = ((File) u.get(i).getOutputData().getData()).getAbsolutePath();
//                            }
//                            localData.put(a, pars);
//                            mod.addRow(new Object[]{a});
//                            codes.add(code);
//                        }
//                    }
//                }
//            }
        }
    }
    
    /**
     * Creates a copy of the selected unit with a different name and adds it to the 
     * GUI. 
     */
    
    private void copySelectedUnit() {
        if(unitIsSelected()) {
            saveLocalData();
            AggregationUnit baseUnit = getSelectedUnit();
            AggregationUnit newUnit = baseUnit.deepCopy(false);  //JB @ 25th May,  previously constructed new unit without copying pars
            //Add an integer ID to the end of the location and time series IDs
            //until a unique one is found.
            for(int i = 0; i < 10000; i++) {  //Finite
                AggregationUnit candidate = new AggregationUnit(newUnit.getAggregationID()+"_"+i);
                if(!localData.containsKey(candidate)) {
                    newUnit.setAggregationID(candidate.getAggregationID());
                    break;
                }
            }
            Object[] pars = localData.get(baseUnit);
            Object[] copy = new Object[pars.length];
            for(int i = 0; i < pars.length; i++) {
                copy[i]=pars[i]; //Shallow copy as pars are all immutable objects
            }
            copy[0]=newUnit.getAggregationID();  //Set new name
            //Set the new data
            localData.put(newUnit,copy);
            DefaultTableModel mod = (DefaultTableModel)unitsTable.getModel();
            mod.addRow(new Object[]{newUnit});
            int row = unitsTable.getRowCount()-1;
            saveIndex = row;
            unitsTable.setRowSelectionInterval(row,row);
        }
    }

     /**
      * Enables or disables the panels identifying the properties of the selected
      * verification unit.  Disable the panels when no units are selected, otherwise
      * enable all panels.
      *
      * @param enabled is true to enable panels, false to disable panels
      */
     
     private void setPanelsEnabled(Boolean enabled) {
         outputFolderLabel.setEnabled(enabled);
         firstLeadLabel.setEnabled(enabled);
         lastLeadLabel.setEnabled(enabled);
         outputFolderField.setEnabled(enabled);
         firstLeadTime.setEnabled(enabled);
         lastLeadTime.setEnabled(enabled);
         outputFolderButton.setEnabled(enabled);
         variableIDLabel.setEnabled(enabled);
         variableIDField.setEnabled(enabled);
         verificationResolutionLabel.setEnabled(enabled);
         verificationResolutionField.setEnabled(enabled);
         aggregationIDLabel.setEnabled(enabled);
         aggregationIDField.setEnabled(enabled);
         deleteButton.setEnabled(enabled);
         copyButton.setEnabled(enabled); 
         runButton.setEnabled(enabled);
         segmentsLabel.setEnabled(enabled);
         segmentsScrollPane.setEnabled(enabled);
         moreButton.setEnabled(enabled);
         if(enabled) {
             segmentsScrollPane.setVerticalScrollBarPolicy(segmentsScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
         } else {
             segmentsScrollPane.setVerticalScrollBarPolicy(segmentsScrollPane.VERTICAL_SCROLLBAR_NEVER);
         }
         segmentsTable.setEnabled(enabled);
         startDateLabel.setEnabled(enabled);
         endDateLabel.setEnabled(enabled);
         startYearField.setEnabled(enabled);
         startMonthField.setEnabled(enabled);
         startDayField.setEnabled(enabled);
         endYearField.setEnabled(enabled);
         endMonthField.setEnabled(enabled);
         endDayField.setEnabled(enabled);
         //Clear text from each field
         outputFolderField.setText("");
         firstLeadTime.setText("");
         lastLeadTime.setText("");
         variableIDField.setText("");
         verificationResolutionField.setText("");
         aggregationIDField.setText("");
         startYearField.setText("");
         startMonthField.setText("");
         startDayField.setText("");
         endYearField.setText("");
         endMonthField.setText("");
         endDayField.setText("");
         Color c = Color.BLACK;
         if(!enabled) {
             c = new Color(157,154,118);
         }
         segmentsTable.getTableHeader().setForeground(c);
         ((TitledBorder)rightPanel.getBorder()).setTitleColor(c);
         ((TitledBorder)identifiersPanel.getBorder()).setTitleColor(c);
         ((TitledBorder)outputPanel.getBorder()).setTitleColor(c);
         ((TitledBorder)segmentsPanel.getBorder()).setTitleColor(c);
         repaint();
     }
     
     /**
      * Initializes the window components.
      */
     
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tableMenu = new javax.swing.JPopupMenu();
        selectAll = new javax.swing.JMenuItem();
        splitPane = new javax.swing.JSplitPane();
        leftPanel = new javax.swing.JPanel();
        scrollPane = new javax.swing.JScrollPane();
        unitsTable = new ToolTipTable();
        rightPanel = new javax.swing.JPanel();
        identifiersPanel = new javax.swing.JPanel();
        identifiersScrollPane = new javax.swing.JScrollPane();
        jPanel12 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        aggregationIDLabel = new javax.swing.JLabel();
        aggregationIDField = new javax.swing.JTextField();
        variableIDLabel = new javax.swing.JLabel();
        variableIDField = new javax.swing.JTextField();
        jPanel15 = new javax.swing.JPanel();
        firstLeadLabel = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        lastLeadLabel = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        firstLeadTime = new javax.swing.JTextField();
        jPanel23 = new javax.swing.JPanel();
        lastLeadTime = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel53 = new javax.swing.JPanel();
        verificationResolutionLabel = new javax.swing.JLabel();
        verificationResolutionField = new javax.swing.JTextField();
        startDateLabel = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        startYearField = new javax.swing.JTextField();
        jPanel24 = new javax.swing.JPanel();
        startMonthField = new javax.swing.JTextField();
        jPanel37 = new javax.swing.JPanel();
        startDayField = new javax.swing.JTextField();
        endDateLabel = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        endYearField = new javax.swing.JTextField();
        jPanel22 = new javax.swing.JPanel();
        endMonthField = new javax.swing.JTextField();
        jPanel35 = new javax.swing.JPanel();
        endDayField = new javax.swing.JTextField();
        jPanel17 = new javax.swing.JPanel();
        seperator1 = new javax.swing.JPanel();
        segmentsPanel = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        segmentsLabel = new javax.swing.JLabel();
        segmentsScrollPane = new javax.swing.JScrollPane();
        segmentsTable = new ToolTipTable();
        jPanel10 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        moreButtonPanel = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        moreButton = new javax.swing.JButton();
        seperator2 = new javax.swing.JPanel();
        outputPanel = new javax.swing.JPanel();
        outputScrollPane = new javax.swing.JScrollPane();
        jPanel13 = new javax.swing.JPanel();
        jPanel65 = new javax.swing.JPanel();
        outputFolderLabel = new javax.swing.JLabel();
        jPanel68 = new javax.swing.JPanel();
        outputFolderField = new javax.swing.JTextField();
        jPanel73 = new javax.swing.JPanel();
        jPanel67 = new javax.swing.JPanel();
        jPanel47 = new javax.swing.JPanel();
        jPanel76 = new javax.swing.JPanel();
        jPanel78 = new javax.swing.JPanel();
        outputFolderButton = new javax.swing.JButton();
        jPanel79 = new javax.swing.JPanel();
        jPanel75 = new javax.swing.JPanel();
        jPanel66 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        deleteButton = new javax.swing.JButton();
        jPanel1416 = new javax.swing.JPanel();
        copyButton = new javax.swing.JButton();
        jPanel1415 = new javax.swing.JPanel();
        runButton = new javax.swing.JButton();
        jPanel20 = new javax.swing.JPanel();
        backButton = new javax.swing.JButton();
        jPanel1414 = new javax.swing.JPanel();
        nextButton = new javax.swing.JButton();

        selectAll.setText("Select all / none");
        selectAll.setToolTipText("Select all / none");
        selectAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectAllActionPerformed(evt);
            }
        });
        tableMenu.add(selectAll);

        setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        setMaximumSize(new java.awt.Dimension(32000, 500));
        setMinimumSize(new java.awt.Dimension(500, 330));
        setPreferredSize(new java.awt.Dimension(1024, 768));
        setLayout(new javax.swing.BoxLayout(this, javax.swing.BoxLayout.Y_AXIS));

        splitPane.setDividerLocation(350);
        splitPane.setDividerSize(7);
        splitPane.setMaximumSize(new java.awt.Dimension(2147363747, 2147363747));
        splitPane.setMinimumSize(new java.awt.Dimension(10000000, 0));
        splitPane.setPreferredSize(new java.awt.Dimension(0, 0));

        leftPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "1. Select aggregation unit(s)", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 12))); // NOI18N
        leftPanel.setMinimumSize(new java.awt.Dimension(30, 47));
        leftPanel.setPreferredSize(new java.awt.Dimension(27000, 34));
        leftPanel.setLayout(new java.awt.GridLayout(1, 0));

        scrollPane.setPreferredSize(new java.awt.Dimension(450, 3000));

        unitsTable.setModel(getUnitsTableModel());
        unitsTable.setInheritsPopupMenu(true);
        unitsTable.setMaximumSize(new java.awt.Dimension(32000, 32000));
        unitsTable.setRequestFocusEnabled(false);
        scrollPane.setViewportView(unitsTable);

        leftPanel.add(scrollPane);

        splitPane.setLeftComponent(leftPanel);
        leftPanel.getAccessibleContext().setAccessibleName("");

        rightPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "2. Edit properties of selected aggregation unit (none selected)", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 12))); // NOI18N
        rightPanel.setMaximumSize(new java.awt.Dimension(32779, 32794));
        rightPanel.setMinimumSize(new java.awt.Dimension(30, 47));
        rightPanel.setPreferredSize(new java.awt.Dimension(35000, 34));
        rightPanel.setLayout(new javax.swing.BoxLayout(rightPanel, javax.swing.BoxLayout.Y_AXIS));

        identifiersPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "2a. Set unit identifier", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11))); // NOI18N
        identifiersPanel.setMaximumSize(new java.awt.Dimension(32000, 0));
        identifiersPanel.setMinimumSize(new java.awt.Dimension(0, 0));
        identifiersPanel.setPreferredSize(new java.awt.Dimension(32000, 550));
        identifiersPanel.setLayout(new javax.swing.BoxLayout(identifiersPanel, javax.swing.BoxLayout.LINE_AXIS));

        identifiersScrollPane.setBorder(null);
        identifiersScrollPane.setPreferredSize(new java.awt.Dimension(100, 200));

        jPanel12.setMinimumSize(new java.awt.Dimension(10, 0));
        jPanel12.setPreferredSize(new java.awt.Dimension(10, 200));
        jPanel12.setLayout(new javax.swing.BoxLayout(jPanel12, javax.swing.BoxLayout.LINE_AXIS));

        jPanel1.setAlignmentX(0.0F);
        jPanel1.setMaximumSize(new java.awt.Dimension(2800, 32767));
        jPanel1.setMinimumSize(new java.awt.Dimension(78, 192));
        jPanel1.setPreferredSize(new java.awt.Dimension(30, 1200));
        jPanel1.setLayout(new javax.swing.BoxLayout(jPanel1, javax.swing.BoxLayout.Y_AXIS));

        aggregationIDLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        aggregationIDLabel.setText("Aggregation unit identifier");
        aggregationIDLabel.setAlignmentX(0.5F);
        aggregationIDLabel.setEnabled(false);
        aggregationIDLabel.setMaximumSize(new java.awt.Dimension(32767, 32767));
        aggregationIDLabel.setMinimumSize(new java.awt.Dimension(1000, 22));
        aggregationIDLabel.setPreferredSize(new java.awt.Dimension(100, 22));
        jPanel1.add(aggregationIDLabel);

        aggregationIDField.setEnabled(false);
        aggregationIDField.setMaximumSize(new java.awt.Dimension(32000, 30));
        aggregationIDField.setMinimumSize(new java.awt.Dimension(4, 30));
        aggregationIDField.setPreferredSize(new java.awt.Dimension(1000, 30));
        jPanel1.add(aggregationIDField);

        variableIDLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        variableIDLabel.setText("Environmental variable identifier");
        variableIDLabel.setAlignmentX(0.5F);
        variableIDLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        variableIDLabel.setEnabled(false);
        variableIDLabel.setMaximumSize(new java.awt.Dimension(32767, 32767));
        variableIDLabel.setMinimumSize(new java.awt.Dimension(1000, 27));
        variableIDLabel.setPreferredSize(new java.awt.Dimension(100, 27));
        jPanel1.add(variableIDLabel);

        variableIDField.setEditable(false);
        variableIDField.setEnabled(false);
        variableIDField.setMaximumSize(new java.awt.Dimension(32000, 30));
        variableIDField.setMinimumSize(new java.awt.Dimension(4, 30));
        variableIDField.setPreferredSize(new java.awt.Dimension(1000, 30));
        jPanel1.add(variableIDField);

        jPanel15.setLayout(new javax.swing.BoxLayout(jPanel15, javax.swing.BoxLayout.LINE_AXIS));

        firstLeadLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        firstLeadLabel.setText("First lead time");
        firstLeadLabel.setAlignmentX(0.5F);
        firstLeadLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        firstLeadLabel.setEnabled(false);
        firstLeadLabel.setMaximumSize(new java.awt.Dimension(32767, 32767));
        firstLeadLabel.setMinimumSize(new java.awt.Dimension(4, 27));
        firstLeadLabel.setPreferredSize(new java.awt.Dimension(1000, 27));
        jPanel15.add(firstLeadLabel);

        jPanel25.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel15.add(jPanel25);

        lastLeadLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        lastLeadLabel.setText("Last lead time");
        lastLeadLabel.setAlignmentX(0.5F);
        lastLeadLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        lastLeadLabel.setEnabled(false);
        lastLeadLabel.setMaximumSize(new java.awt.Dimension(32767, 32767));
        lastLeadLabel.setMinimumSize(new java.awt.Dimension(4, 27));
        lastLeadLabel.setPreferredSize(new java.awt.Dimension(1000, 27));
        jPanel15.add(lastLeadLabel);

        jPanel1.add(jPanel15);

        jPanel7.setLayout(new javax.swing.BoxLayout(jPanel7, javax.swing.BoxLayout.LINE_AXIS));

        firstLeadTime.setEditable(false);
        firstLeadTime.setEnabled(false);
        firstLeadTime.setMaximumSize(new java.awt.Dimension(32000, 30));
        firstLeadTime.setMinimumSize(new java.awt.Dimension(4, 30));
        firstLeadTime.setPreferredSize(new java.awt.Dimension(1000, 30));
        jPanel7.add(firstLeadTime);

        jPanel23.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel7.add(jPanel23);

        lastLeadTime.setEditable(false);
        lastLeadTime.setEnabled(false);
        lastLeadTime.setMaximumSize(new java.awt.Dimension(32000, 30));
        lastLeadTime.setMinimumSize(new java.awt.Dimension(4, 30));
        lastLeadTime.setPreferredSize(new java.awt.Dimension(1000, 30));
        jPanel7.add(lastLeadTime);

        jPanel1.add(jPanel7);

        jPanel6.setPreferredSize(new java.awt.Dimension(10, 10000));
        jPanel1.add(jPanel6);

        jPanel12.add(jPanel1);

        jPanel3.setMaximumSize(new java.awt.Dimension(40, 500));
        jPanel3.setPreferredSize(new java.awt.Dimension(40, 10));
        jPanel12.add(jPanel3);

        jPanel53.setMaximumSize(new java.awt.Dimension(2800, 32767));
        jPanel53.setMinimumSize(new java.awt.Dimension(78, 192));
        jPanel53.setPreferredSize(new java.awt.Dimension(30, 10000));
        jPanel53.setLayout(new javax.swing.BoxLayout(jPanel53, javax.swing.BoxLayout.Y_AXIS));

        verificationResolutionLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        verificationResolutionLabel.setText("Aggregation of lead period");
        verificationResolutionLabel.setAlignmentX(0.5F);
        verificationResolutionLabel.setEnabled(false);
        verificationResolutionLabel.setMaximumSize(new java.awt.Dimension(32767, 32767));
        verificationResolutionLabel.setMinimumSize(new java.awt.Dimension(10000, 22));
        verificationResolutionLabel.setPreferredSize(new java.awt.Dimension(100, 22));
        jPanel53.add(verificationResolutionLabel);

        verificationResolutionField.setEditable(false);
        verificationResolutionField.setEnabled(false);
        verificationResolutionField.setMaximumSize(new java.awt.Dimension(32000, 30));
        verificationResolutionField.setMinimumSize(new java.awt.Dimension(4, 30));
        verificationResolutionField.setPreferredSize(new java.awt.Dimension(1000, 30));
        jPanel53.add(verificationResolutionField);

        startDateLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        startDateLabel.setText("Start of verification period (YYYY/MM/DD)");
        startDateLabel.setAlignmentX(0.5F);
        startDateLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        startDateLabel.setEnabled(false);
        startDateLabel.setMaximumSize(new java.awt.Dimension(32767, 32767));
        startDateLabel.setMinimumSize(new java.awt.Dimension(1000, 27));
        startDateLabel.setPreferredSize(new java.awt.Dimension(100, 27));
        jPanel53.add(startDateLabel);

        jPanel14.setMaximumSize(new java.awt.Dimension(32000, 30));
        jPanel14.setMinimumSize(new java.awt.Dimension(4, 30));
        jPanel14.setPreferredSize(new java.awt.Dimension(1000, 27));
        jPanel14.setLayout(new javax.swing.BoxLayout(jPanel14, javax.swing.BoxLayout.LINE_AXIS));

        startYearField.setEditable(false);
        startYearField.setEnabled(false);
        startYearField.setMaximumSize(new java.awt.Dimension(32000, 30));
        startYearField.setMinimumSize(new java.awt.Dimension(4, 30));
        startYearField.setPreferredSize(new java.awt.Dimension(1000, 30));
        jPanel14.add(startYearField);

        jPanel24.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel14.add(jPanel24);

        startMonthField.setEditable(false);
        startMonthField.setEnabled(false);
        startMonthField.setMaximumSize(new java.awt.Dimension(32000, 30));
        startMonthField.setMinimumSize(new java.awt.Dimension(52, 30));
        startMonthField.setPreferredSize(new java.awt.Dimension(100, 30));
        jPanel14.add(startMonthField);

        jPanel37.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel14.add(jPanel37);

        startDayField.setEditable(false);
        startDayField.setEnabled(false);
        startDayField.setMaximumSize(new java.awt.Dimension(32000, 30));
        startDayField.setMinimumSize(new java.awt.Dimension(52, 30));
        startDayField.setPreferredSize(new java.awt.Dimension(100, 30));
        jPanel14.add(startDayField);

        jPanel53.add(jPanel14);

        endDateLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        endDateLabel.setText("End of verification period (YYYY/MM/DD)");
        endDateLabel.setAlignmentX(0.5F);
        endDateLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        endDateLabel.setEnabled(false);
        endDateLabel.setMaximumSize(new java.awt.Dimension(32767, 32767));
        endDateLabel.setMinimumSize(new java.awt.Dimension(1000, 27));
        endDateLabel.setPreferredSize(new java.awt.Dimension(100, 27));
        jPanel53.add(endDateLabel);

        jPanel11.setMaximumSize(new java.awt.Dimension(32000, 30));
        jPanel11.setMinimumSize(new java.awt.Dimension(4, 30));
        jPanel11.setPreferredSize(new java.awt.Dimension(1000, 27));
        jPanel11.setLayout(new javax.swing.BoxLayout(jPanel11, javax.swing.BoxLayout.LINE_AXIS));

        endYearField.setEditable(false);
        endYearField.setEnabled(false);
        endYearField.setMaximumSize(new java.awt.Dimension(32000, 30));
        endYearField.setMinimumSize(new java.awt.Dimension(4, 30));
        endYearField.setPreferredSize(new java.awt.Dimension(1000, 30));
        jPanel11.add(endYearField);

        jPanel22.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel11.add(jPanel22);

        endMonthField.setEditable(false);
        endMonthField.setEnabled(false);
        endMonthField.setMaximumSize(new java.awt.Dimension(32000, 30));
        endMonthField.setMinimumSize(new java.awt.Dimension(52, 30));
        endMonthField.setPreferredSize(new java.awt.Dimension(100, 30));
        jPanel11.add(endMonthField);

        jPanel35.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel11.add(jPanel35);

        endDayField.setEditable(false);
        endDayField.setEnabled(false);
        endDayField.setMaximumSize(new java.awt.Dimension(32000, 30));
        endDayField.setMinimumSize(new java.awt.Dimension(52, 30));
        endDayField.setPreferredSize(new java.awt.Dimension(100, 30));
        jPanel11.add(endDayField);

        jPanel53.add(jPanel11);

        jPanel17.setPreferredSize(new java.awt.Dimension(10, 10000));
        jPanel53.add(jPanel17);

        jPanel12.add(jPanel53);

        identifiersScrollPane.setViewportView(jPanel12);

        identifiersPanel.add(identifiersScrollPane);

        rightPanel.add(identifiersPanel);

        seperator1.setMaximumSize(new java.awt.Dimension(10000, 3));
        seperator1.setMinimumSize(new java.awt.Dimension(5, 3));
        seperator1.setPreferredSize(new java.awt.Dimension(10000, 3));
        rightPanel.add(seperator1);

        segmentsPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "2b. Select verification units to include in aggregation", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11))); // NOI18N
        segmentsPanel.setMaximumSize(new java.awt.Dimension(32000, 0));
        segmentsPanel.setMinimumSize(new java.awt.Dimension(0, 0));
        segmentsPanel.setPreferredSize(new java.awt.Dimension(32000, 750));
        segmentsPanel.setLayout(new javax.swing.BoxLayout(segmentsPanel, javax.swing.BoxLayout.LINE_AXIS));

        jPanel2.setMaximumSize(new java.awt.Dimension(2800, 32767));
        jPanel2.setMinimumSize(new java.awt.Dimension(78, 192));
        jPanel2.setPreferredSize(new java.awt.Dimension(30, 1200));
        jPanel2.setLayout(new javax.swing.BoxLayout(jPanel2, javax.swing.BoxLayout.Y_AXIS));

        segmentsLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        segmentsLabel.setText("Available units (specify S to weigh by sample size)");
        segmentsLabel.setEnabled(false);
        segmentsLabel.setMaximumSize(new java.awt.Dimension(32767, 22));
        segmentsLabel.setMinimumSize(new java.awt.Dimension(1000, 22));
        segmentsLabel.setPreferredSize(new java.awt.Dimension(100, 22));
        jPanel2.add(segmentsLabel);

        segmentsScrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        segmentsScrollPane.setPreferredSize(new java.awt.Dimension(450, 3000));

        segmentsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Unique identifier", "Weight", "Include?"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        segmentsTable.setInheritsPopupMenu(true);
        segmentsTable.setPreferredSize(new java.awt.Dimension(75, 500));
        segmentsTable.setRequestFocusEnabled(false);
        segmentsTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                segmentsTableMouseClicked(evt);
            }
        });
        segmentsScrollPane.setViewportView(segmentsTable);

        jPanel2.add(segmentsScrollPane);

        jPanel10.setMaximumSize(new java.awt.Dimension(32767, 52767));
        jPanel10.setMinimumSize(new java.awt.Dimension(10, 20));
        jPanel10.setPreferredSize(new java.awt.Dimension(10, 300));
        jPanel2.add(jPanel10);

        segmentsPanel.add(jPanel2);

        jPanel8.setMaximumSize(new java.awt.Dimension(40, 32000));
        jPanel8.setPreferredSize(new java.awt.Dimension(40, 32000));
        jPanel8.setLayout(new java.awt.GridLayout(1, 0));
        segmentsPanel.add(jPanel8);

        jPanel9.setMaximumSize(new java.awt.Dimension(2800, 32767));
        jPanel9.setMinimumSize(new java.awt.Dimension(78, 192));
        jPanel9.setPreferredSize(new java.awt.Dimension(30, 10000));
        jPanel9.setLayout(new javax.swing.BoxLayout(jPanel9, javax.swing.BoxLayout.Y_AXIS));

        jPanel5.setPreferredSize(new java.awt.Dimension(10, 32000));
        jPanel9.add(jPanel5);

        moreButtonPanel.setMaximumSize(new java.awt.Dimension(32000, 30));
        moreButtonPanel.setMinimumSize(new java.awt.Dimension(0, 30));
        moreButtonPanel.setPreferredSize(new java.awt.Dimension(100, 30));
        moreButtonPanel.setLayout(new javax.swing.BoxLayout(moreButtonPanel, javax.swing.BoxLayout.LINE_AXIS));

        jPanel4.setAlignmentX(0.0F);
        jPanel4.setAlignmentY(0.0F);
        jPanel4.setMaximumSize(new java.awt.Dimension(32767, 29));
        jPanel4.setMinimumSize(new java.awt.Dimension(10000, 29));
        jPanel4.setPreferredSize(new java.awt.Dimension(100, 29));
        jPanel4.setLayout(new java.awt.GridLayout(1, 0));
        moreButtonPanel.add(jPanel4);

        moreButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        moreButton.setText("More");
        moreButton.setAlignmentY(0.0F);
        moreButton.setEnabled(false);
        moreButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        moreButton.setMaximumSize(new java.awt.Dimension(65, 29));
        moreButton.setMinimumSize(new java.awt.Dimension(65, 29));
        moreButton.setPreferredSize(new java.awt.Dimension(65, 29));
        moreButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                moreButtonActionPerformed(evt);
            }
        });
        moreButtonPanel.add(moreButton);

        jPanel9.add(moreButtonPanel);

        segmentsPanel.add(jPanel9);

        rightPanel.add(segmentsPanel);

        seperator2.setMaximumSize(new java.awt.Dimension(10000, 3));
        seperator2.setMinimumSize(new java.awt.Dimension(5, 3));
        seperator2.setPreferredSize(new java.awt.Dimension(10000, 3));
        rightPanel.add(seperator2);

        outputPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "2c. Set location for output data", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11))); // NOI18N
        outputPanel.setMaximumSize(new java.awt.Dimension(32000, 0));
        outputPanel.setMinimumSize(new java.awt.Dimension(0, 0));
        outputPanel.setPreferredSize(new java.awt.Dimension(32000, 325));
        outputPanel.setLayout(new javax.swing.BoxLayout(outputPanel, javax.swing.BoxLayout.LINE_AXIS));

        outputScrollPane.setBorder(null);

        jPanel13.setMinimumSize(new java.awt.Dimension(10, 0));
        jPanel13.setPreferredSize(new java.awt.Dimension(10, 80));
        jPanel13.setLayout(new javax.swing.BoxLayout(jPanel13, javax.swing.BoxLayout.LINE_AXIS));

        jPanel65.setMaximumSize(new java.awt.Dimension(2800, 32767));
        jPanel65.setMinimumSize(new java.awt.Dimension(78, 192));
        jPanel65.setPreferredSize(new java.awt.Dimension(30, 120));
        jPanel65.setLayout(new javax.swing.BoxLayout(jPanel65, javax.swing.BoxLayout.Y_AXIS));

        outputFolderLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        outputFolderLabel.setText("Folder for aggregated statistics");
        outputFolderLabel.setEnabled(false);
        outputFolderLabel.setMaximumSize(new java.awt.Dimension(32767, 32767));
        outputFolderLabel.setMinimumSize(new java.awt.Dimension(1000, 22));
        outputFolderLabel.setPreferredSize(new java.awt.Dimension(100, 22));
        jPanel65.add(outputFolderLabel);

        jPanel68.setMaximumSize(new java.awt.Dimension(32000, 28));
        jPanel68.setLayout(new java.awt.GridLayout(1, 0));

        outputFolderField.setAlignmentX(0.4F);
        outputFolderField.setAlignmentY(0.0F);
        outputFolderField.setEnabled(false);
        outputFolderField.setMaximumSize(new java.awt.Dimension(32000, 28));
        outputFolderField.setMinimumSize(new java.awt.Dimension(4, 30));
        outputFolderField.setPreferredSize(new java.awt.Dimension(1000, 27));
        jPanel68.add(outputFolderField);

        jPanel65.add(jPanel68);

        jPanel73.setPreferredSize(new java.awt.Dimension(10, 10000));
        jPanel65.add(jPanel73);

        jPanel13.add(jPanel65);

        jPanel67.setMaximumSize(new java.awt.Dimension(40, 500));
        jPanel67.setPreferredSize(new java.awt.Dimension(40, 10));
        jPanel67.setLayout(new javax.swing.BoxLayout(jPanel67, javax.swing.BoxLayout.Y_AXIS));

        jPanel47.setMinimumSize(new java.awt.Dimension(10, 22));
        jPanel47.setPreferredSize(new java.awt.Dimension(10, 22));
        jPanel67.add(jPanel47);

        jPanel76.setMaximumSize(new java.awt.Dimension(32000, 32000));
        jPanel76.setMinimumSize(new java.awt.Dimension(10, 30));
        jPanel76.setPreferredSize(new java.awt.Dimension(10, 30));
        jPanel76.setLayout(new javax.swing.BoxLayout(jPanel76, javax.swing.BoxLayout.LINE_AXIS));

        jPanel78.setMaximumSize(new java.awt.Dimension(5, 32767));
        jPanel78.setMinimumSize(new java.awt.Dimension(5, 5));
        jPanel78.setPreferredSize(new java.awt.Dimension(5, 10));
        jPanel76.add(jPanel78);

        outputFolderButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/files.png"))); // NOI18N
        outputFolderButton.setAlignmentX(0.5F);
        outputFolderButton.setEnabled(false);
        outputFolderButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
        outputFolderButton.setMaximumSize(new java.awt.Dimension(30, 30));
        outputFolderButton.setMinimumSize(new java.awt.Dimension(30, 30));
        outputFolderButton.setPreferredSize(new java.awt.Dimension(30, 30));
        outputFolderButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                outputFolderButtonActionPerformed(evt);
            }
        });
        jPanel76.add(outputFolderButton);

        jPanel79.setMaximumSize(new java.awt.Dimension(5, 32767));
        jPanel79.setMinimumSize(new java.awt.Dimension(5, 5));
        jPanel79.setPreferredSize(new java.awt.Dimension(5, 10));
        jPanel76.add(jPanel79);

        jPanel67.add(jPanel76);

        jPanel75.setPreferredSize(new java.awt.Dimension(10, 10000));
        jPanel67.add(jPanel75);

        jPanel13.add(jPanel67);

        jPanel66.setMaximumSize(new java.awt.Dimension(2800, 32767));
        jPanel66.setMinimumSize(new java.awt.Dimension(78, 192));
        jPanel66.setPreferredSize(new java.awt.Dimension(30, 120));
        jPanel66.setLayout(new java.awt.GridLayout(1, 0));
        jPanel13.add(jPanel66);

        outputScrollPane.setViewportView(jPanel13);

        outputPanel.add(outputScrollPane);

        rightPanel.add(outputPanel);

        splitPane.setRightComponent(rightPanel);

        add(splitPane);

        jPanel19.setMaximumSize(new java.awt.Dimension(32899, 40));
        jPanel19.setMinimumSize(new java.awt.Dimension(142, 40));
        jPanel19.setPreferredSize(new java.awt.Dimension(144, 40));
        jPanel19.setLayout(new javax.swing.BoxLayout(jPanel19, javax.swing.BoxLayout.LINE_AXIS));

        deleteButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        deleteButton.setText("Delete");
        deleteButton.setAlignmentY(0.25F);
        deleteButton.setEnabled(false);
        deleteButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        deleteButton.setMaximumSize(new java.awt.Dimension(65, 29));
        deleteButton.setMinimumSize(new java.awt.Dimension(65, 29));
        deleteButton.setPreferredSize(new java.awt.Dimension(65, 29));
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });
        jPanel19.add(deleteButton);

        jPanel1416.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel1416.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel1416.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel19.add(jPanel1416);

        copyButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        copyButton.setText("Copy");
        copyButton.setAlignmentY(0.25F);
        copyButton.setEnabled(false);
        copyButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        copyButton.setMaximumSize(new java.awt.Dimension(65, 29));
        copyButton.setMinimumSize(new java.awt.Dimension(65, 29));
        copyButton.setPreferredSize(new java.awt.Dimension(65, 29));
        copyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                copyButtonActionPerformed(evt);
            }
        });
        jPanel19.add(copyButton);

        jPanel1415.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel1415.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel1415.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel19.add(jPanel1415);

        runButton.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        runButton.setText("Run");
        runButton.setAlignmentY(0.25F);
        runButton.setEnabled(false);
        runButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        runButton.setMaximumSize(new java.awt.Dimension(65, 29));
        runButton.setMinimumSize(new java.awt.Dimension(65, 29));
        runButton.setPreferredSize(new java.awt.Dimension(65, 29));
        runButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                runButtonActionPerformed(evt);
            }
        });
        jPanel19.add(runButton);

        jPanel20.setMinimumSize(new java.awt.Dimension(10, 29));
        jPanel19.add(jPanel20);

        backButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        backButton.setText("Back");
        backButton.setAlignmentY(0.25F);
        backButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        backButton.setMaximumSize(new java.awt.Dimension(65, 29));
        backButton.setMinimumSize(new java.awt.Dimension(65, 29));
        backButton.setPreferredSize(new java.awt.Dimension(65, 29));
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });
        jPanel19.add(backButton);

        jPanel1414.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel1414.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel1414.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel19.add(jPanel1414);

        nextButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        nextButton.setText("Next");
        nextButton.setAlignmentY(0.25F);
        nextButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        nextButton.setMaximumSize(new java.awt.Dimension(65, 29));
        nextButton.setMinimumSize(new java.awt.Dimension(65, 29));
        nextButton.setPreferredSize(new java.awt.Dimension(65, 29));
        nextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextButtonActionPerformed(evt);
            }
        });
        jPanel19.add(nextButton);

        add(jPanel19);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Deletes one or more aggregation units on accepting a warning message.
     *
     * @param evt an action event
     */
    
    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        deleteSelectedUnits();
    }//GEN-LAST:event_deleteButtonActionPerformed

    /**
     * Runs the aggregation.
     *
     * @param evt an action event
     */
    
    private void runButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_runButtonActionPerformed
        try {
            runAggregation();
        } catch(Throwable e) {
            CONSOLE.addMessage(StringUtilities.stackTraceToString(e));
            ExceptionHandler.displayException(e);
        }
    }//GEN-LAST:event_runButtonActionPerformed

    /**
     * Returns to the previous window.
     *
     * @param evt an action event
     */
    
    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        JPanel agg = (JPanel)this.getParent();
        JTabbedPane parent = (JTabbedPane)agg.getParent();
        //Set to first tab
        parent.setSelectedIndex(0);
        //Set to last index of first tab
        JPanel model = (JPanel)VERIFICATION_A.getParent();
        ((CardLayout)model.getLayout()).last(model);        
    }//GEN-LAST:event_backButtonActionPerformed

    /**
     * Moves to the next window.
     *
     * @param evt an action event
     */    
    
    private void nextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextButtonActionPerformed
        JPanel agg = (JPanel)this.getParent();
        JTabbedPane parent = (JTabbedPane)agg.getParent();
        parent.setSelectedIndex((parent.getSelectedIndex())+1);  //Move to display
    }//GEN-LAST:event_nextButtonActionPerformed

    /*
     * Opens a file dialog to select the output directory.
     *
     * @param evt the action event
     */
    
    private void outputFolderButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_outputFolderButtonActionPerformed
        String file = outputFolderField.getText();
        File[] selectMe = new File[]{new File(file)};
        File[] targetFiles = VERIFICATION_A.getTargetFiles(null,selectMe,JFileChooser.DIRECTORIES_ONLY,false);
        if(targetFiles != null && targetFiles.length > 0) {
            outputFolderField.setText(targetFiles[0].getAbsolutePath());
        }
    }//GEN-LAST:event_outputFolderButtonActionPerformed

    /**
     * Shows a menu for selecting/deselecting all elements in the table. 
     * 
     * @param evt a mouse event
     */
    
    private void segmentsTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_segmentsTableMouseClicked
        if(segmentsTable.getRowCount() > 0 && segmentsTable.getValueAt(0,0) != null && evt.getModifiers() == evt.BUTTON3_MASK) {
            tableMenu.show(segmentsTable,evt.getX(),evt.getY());  //Show menu on right click
        }        
    }//GEN-LAST:event_segmentsTableMouseClicked

    /**
     * Toggle selection of items in segment table.
     * 
     * @param evt an action event
     */
    
    private void selectAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectAllActionPerformed
        selectAllSegments(segmentsTable.getRowCount() > 0 && segmentsTable.getValueAt(0, 0) != null && !((Boolean) segmentsTable.getValueAt(0, 2)).booleanValue());
    }//GEN-LAST:event_selectAllActionPerformed

    /**
     * Opens a parameter editing dialog.
     *
     * @param evt the action event
     */

    private void moreButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_moreButtonActionPerformed
        int row = unitsTable.getSelectedRow();
        //Set the parameter options
        if (row > -1) {
            try {
                MoreAggParOptionsDialog parOptions = new MoreAggParOptionsDialog(true);           
                parOptions.setParOptions(getSelectedUnit());
                EVSMainWindow.setWindowLocation(parOptions);
                parOptions.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
}//GEN-LAST:event_moreButtonActionPerformed

    /**
     * Copies the selected aggregation unit
     * 
     * @param evt an action event
     */
    
    private void copyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_copyButtonActionPerformed
        copySelectedUnit();
    }//GEN-LAST:event_copyButtonActionPerformed

    /**
     * Selects or deselects all of the segments in the aggregation table for the
     * current unit.
     *
     * @param select is true to select all segments
      */
     
     private void selectAllSegments(boolean select) {
         int rows = segmentsTable.getRowCount();
         for(int i = 0; i < rows; i++) {
             segmentsTable.setValueAt(select,i,2);
         }
     }    
    
    /**
     * Deletes the selected aggregation unit.
     */
    
    private void deleteSelectedUnits() {
        if(unitIsSelected()) {
            ArrayList<AggregationUnit> sel = getSelectedAggregationUnits();
            if(sel.size() > 0) {
                int n = JOptionPane.showOptionDialog(EVSMainWindow.main,"Delete selected aggregation unit(s) and return to defaults?","Warning: data deletion", JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
                if(n == JOptionPane.NO_OPTION) {
                    return;
                }
            }
            for (AggregationUnit a : sel) {
                a.deleteVerificationUnits(true);  //Delete references in VUs also 
                localData.remove(a);
            }
            //Some units left
            if(localData.size() > 0) {
                //Coordinate with units table
                DefaultTableModel d = (DefaultTableModel) unitsTable.getModel();
                d.setRowCount(0);
                Iterator it = localData.keySet().iterator();
                while (it.hasNext()) {
                    d.addRow(new Object[]{it.next()});
                }

                //@JB 5th October 2012. Update row selection and save index when updating data
                int row = unitsTable.getSelectedRow();
                if (row == -1) {
                    if (unitsTable.getRowCount() > 0) {
                        //If null, attempt to display last valid index, otherwise display last item
                        if (stickyIndex != -1 && stickyIndex < unitsTable.getRowCount()) {
                            row = stickyIndex;
                        } else {
                            row = unitsTable.getRowCount() - 1;
                        }
                        unitsTable.setRowSelectionInterval(row, row);
                    }
                    //Update save index because row selection does not trigger table listener on value is adjusting
                    saveIndex = row;
                }
            } 
            //No units left
            else {
                clearAllLocalData();
            }
            //Reinstate any default unit options JB @ 25th May 2013
            addDefaultUnits(getAggregationUnits());
        }
    }
    
     /**
      * Runs the aggregation.
      */
     
     private void runAggregation() throws IllegalArgumentException {
         if(!EVSMainWindow.main.saveProject(true)){
            throw new IllegalArgumentException("Aggregation not conducted, as project save failed.");
         }
         //Perform aggregation in a separate thread
         final long start = System.currentTimeMillis();
         final Vector<AggregationUnit> units = getAggregationUnits();
         final int length = units.size();
         int count = 0;
         //Warn in case metrics with unequal paramater values exist and will not be computed
         String[] warn  = null;
         for(int i = 0; i < length; i++) {
             AggregationUnit un = units.get(i);
             if(un.hasVerificationUnits()) {
                 count++;
                 if(warn==null) {
                    warn = VerificationUnit.getUnequalMetrics(un.getVerificationUnits());
                 }
             }
         }
         if(count == 0) {
             throw new IllegalArgumentException("No aggregation units with valid verification units to aggregate.");
         }
         //Some aggregation units with inconsistent metrics 
         if(warn != null) {
             StringBuffer bf = new StringBuffer();
             String nL = System.getProperty("line.separator");
             bf.append("Some metrics have inconsistent paramater values, and will not be computed. Proceed?");
             bf.append(nL);
             bf.append("The metrics with inconsistent parameter values: ");
             bf.append(nL);
             for(String s : warn) {
                 bf.append(s);
                 bf.append(nL);
             }
             int n = JOptionPane.showOptionDialog(EVSMainWindow.main, bf.toString(), "Warning: expect incomplete results", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, null, null, null);
             if (n == JOptionPane.NO_OPTION) {
                 return;
             }     
         }
         //Continue with valid units
         final ProgressMonitor pro = new ProgressMonitor(EVSMainWindow.main) {
             protected void cleanUpOnCancel() {
                 PairedDataSource.getIOState().setIOState(false);  //Cancel I/O
                 //Cancel metric calculation
                 for(AggregationUnit unit : units) {
                     unit.stop();
                 }
                 Vector<VerificationUnit> units = VERIFICATION_A.getVerificationUnits();
                 for(VerificationUnit unit : units) {
                     unit.stop();
                 }
                 super.cleanUpOnCancel();
             }
         };
         final java.util.Timer tt = new java.util.Timer();
         final SwingWorker task = new SwingWorker() {
             public Object doInBackground() {
                 pro.setProgress(0);  //Initialize for percent progress
                 try {
                     boolean ok = true;
                     StringBuffer errorMessage= new StringBuffer();
                     
                     //Compute the metrics
                     for(int i = 0; i < length; i++) {
                         final AggregationUnit nxt = units.get(i);
                         if(nxt.hasVerificationUnits()) {

                             //Check for progress every tenth second
                             final double mult = 1.0 / length;
                             final int current = i;
                             TimerTask tsk = new TimerTask() {

                                 public void run() {
                                     double prev = (mult * current) * 100.0;
                                     double curr = mult * nxt.getProgress();
                                     double tot = prev + curr;
                                     setProgress((int) tot);  //Update the progress: listen for this update later
                                 }
                             };
                             tt.scheduleAtFixedRate(tsk, 0, 50);

                             ok = nxt.computeMetrics(VERIFICATION_A.getVerificationUnits()); //Specify potential ref. forecasts
                             if (!ok) {
                                 errorMessage.append(nxt.getComputeErrors());
                             }
                         }
                     }
                     OUTPUT_A.updateLocalData(VERIFICATION_A.getSelectedUnit());
                     OUTPUT_A.showLocalData();
                     
                     //Save path to pairs
                     try {
                         EVSMainWindow.main.updateProjectFile();
                     } catch(Exception e) {
                         System.out.println("Failed to update project file.");
                     }
                     if(ok) {
                         pro.stop(" complete.",true);
                         pro.setVisible(false); //Quiet close
                     } else {
                         CONSOLE.addMessage(errorMessage.toString());
                         pro.stop(" stopped with errors.",false);
                     }
                 } catch (Exception e) {
                     CONSOLE.addMessage(StringUtilities.stackTraceToString(e));
                     e.printStackTrace();
                     pro.stop(" stopped with errors.",false);
                 }
                 //No memory left
                 catch(OutOfMemoryError f) {
                     CONSOLE.addMessage(StringUtilities.stackTraceToString(f));
                     f.printStackTrace();
                     pro.stop(" stopped with errors.",false);
                 } finally {
                     if(tt != null) {
                         tt.cancel();
                     }
                     long stop = System.currentTimeMillis();
                     System.out.println("Total time taken for aggregation: "+ Mathematics.round((stop - start) / 60000.0,1)+ " minutes.");
                     PairedDataSource.getIOState().setIOState(true);  //Restore I/O
                 }
                 return null;
             }
         };

         //Monitor progress and update progress bar: cancel thread if required
         task.addPropertyChangeListener(
                 new PropertyChangeListener() {
                     public void propertyChange(PropertyChangeEvent evt) {
                         if ("progress".equals(evt.getPropertyName())) {
                             if (pro.wasCanceled() || task.isDone()) {
                                 task.cancel(true);
                             }
                             pro.setProgress((Integer) evt.getNewValue());
                         }
                     }
                 }
         );

         task.execute();
         pro.setVisible(true);
     }

    /**
     * Returns the units table model with a listener that sets the size of the 
     * units table according to the rows added or deleted.
     * 
     * @return a table model for the units table
     */
    
    private DefaultTableModel getUnitsTableModel() {
        return new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Unique identifier"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
            
            public void fireTableRowsDeleted(int firstRow, int lastRow) {
                super.fireTableRowsDeleted(firstRow, lastRow);
                unitsTable.setPreferredSize(new Dimension(75, unitsTable.getRowHeight()
                        * (unitsTable.getRowCount() + 1)));
            }

            public void fireTableRowsInserted(int firstRow, int lastRow) {
                super.fireTableRowsInserted(firstRow, lastRow);
                unitsTable.setPreferredSize(new Dimension(75, unitsTable.getRowHeight()
                        * (unitsTable.getRowCount() + 1)));
            }
            
        };   
    }     
     
/********************************************************************************
 *                                                                              *
 *                              INSTANCE VARIABLES                              *
 *                                                                              *
 *******************************************************************************/    
    
    /**
     * The row index for saving local data.
     */
    
    private int saveIndex = -1;     
    
    /**
     * Last index selected in units table. Do not clear this upon clearing local
     * data.
     */
     
    private int stickyIndex = -1; 
    
    /**
     * Stores the aggregation units with their temporary parameter values in an 
     * object array.
     */
    
    private LinkedHashMap<AggregationUnit,Object[]> localData = new LinkedHashMap();
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField aggregationIDField;
    private javax.swing.JLabel aggregationIDLabel;
    private javax.swing.JButton backButton;
    private javax.swing.JButton copyButton;
    private javax.swing.JButton deleteButton;
    private javax.swing.JLabel endDateLabel;
    private javax.swing.JTextField endDayField;
    private javax.swing.JTextField endMonthField;
    private javax.swing.JTextField endYearField;
    private javax.swing.JLabel firstLeadLabel;
    private javax.swing.JTextField firstLeadTime;
    private javax.swing.JPanel identifiersPanel;
    private javax.swing.JScrollPane identifiersScrollPane;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel1414;
    private javax.swing.JPanel jPanel1415;
    private javax.swing.JPanel jPanel1416;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel47;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel53;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel65;
    private javax.swing.JPanel jPanel66;
    private javax.swing.JPanel jPanel67;
    private javax.swing.JPanel jPanel68;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel73;
    private javax.swing.JPanel jPanel75;
    private javax.swing.JPanel jPanel76;
    private javax.swing.JPanel jPanel78;
    private javax.swing.JPanel jPanel79;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JLabel lastLeadLabel;
    private javax.swing.JTextField lastLeadTime;
    private javax.swing.JPanel leftPanel;
    private javax.swing.JButton moreButton;
    private javax.swing.JPanel moreButtonPanel;
    private javax.swing.JButton nextButton;
    private javax.swing.JButton outputFolderButton;
    private javax.swing.JTextField outputFolderField;
    private javax.swing.JLabel outputFolderLabel;
    private javax.swing.JPanel outputPanel;
    private javax.swing.JScrollPane outputScrollPane;
    private javax.swing.JPanel rightPanel;
    private javax.swing.JButton runButton;
    private javax.swing.JScrollPane scrollPane;
    private javax.swing.JLabel segmentsLabel;
    private javax.swing.JPanel segmentsPanel;
    private javax.swing.JScrollPane segmentsScrollPane;
    private javax.swing.JTable segmentsTable;
    private javax.swing.JMenuItem selectAll;
    private javax.swing.JPanel seperator1;
    private javax.swing.JPanel seperator2;
    private javax.swing.JSplitPane splitPane;
    private javax.swing.JLabel startDateLabel;
    private javax.swing.JTextField startDayField;
    private javax.swing.JTextField startMonthField;
    private javax.swing.JTextField startYearField;
    private javax.swing.JPopupMenu tableMenu;
    private javax.swing.JTable unitsTable;
    private javax.swing.JTextField variableIDField;
    private javax.swing.JLabel variableIDLabel;
    private javax.swing.JTextField verificationResolutionField;
    private javax.swing.JLabel verificationResolutionLabel;
    // End of variables declaration//GEN-END:variables

/*******************************************************************************
 *                                                                             *
 *                               INNER CLASSES                                 *
 *                                                                             *
 ******************************************************************************/    
    
    /** 
     * This table displays a tool tip text based on the string representation
     * of the cell value.
     */
        
    private static class ToolTipTable extends JTable {
        public Component prepareRenderer(TableCellRenderer renderer,int rowIndex, int vColIndex) {
            Component c = super.prepareRenderer(renderer, rowIndex, vColIndex);
            if (c instanceof JComponent) {
                JComponent jc = (JComponent)c;
                jc.setToolTipText(getValueAt(rowIndex, vColIndex)+"");
            }
            return c;
        }
    }


}
