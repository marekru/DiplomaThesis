package evs.gui.utilities;

//EVS dependencies
import evs.metric.parameters.ROCScoreMethodParameter;

/**
 * Class for storing and displaying an AUC method parameter in a combo box.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DisplayAUCMethodPar {

    /**
     * The method.
     */
    private int type;

    /**
     * Construct with a specified method.
     *
     * @param type the method
     */   
    public DisplayAUCMethodPar(int type) {
        switch(type) {
            case ROCScoreMethodParameter.MASON_GRAHAM:{}; break;
            case ROCScoreMethodParameter.TRAPEZOID:{}; break;
            default: throw new IllegalArgumentException("Unrecognized AUC method parameter for display.");
        }
        this.type = type;
    }

    /**
     * Returns the method type.
     *
     * @return the method type
     */
    public int getID() {
        return type;
    }

    /**
     * Display method.
     *
     * @return the string to display
     */
    public String toString() {
        switch (type) {
            case ROCScoreMethodParameter.MASON_GRAHAM: {
                return "Mason and Graham (2000)";
            }
            case ROCScoreMethodParameter.TRAPEZOID: {
                return "Trapezoid rule";
            }
            default: {
                throw new IllegalArgumentException("Unrecognized type.");
            }
        }
    }
} 
        
   
