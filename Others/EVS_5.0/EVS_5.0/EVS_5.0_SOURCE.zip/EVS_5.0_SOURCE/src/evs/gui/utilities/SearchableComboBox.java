package evs.gui.utilities;

//Java swing dependencies
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.ComboBoxModel;
import javax.swing.JTextField;

//Java util dependencies
import java.util.Vector;
  
//EVS dependencies
import evs.gui.windows.EVSMainWindow;

/**
 * Searchable ComboBox.  Efficiency would be improved by caching intermediate
 * results after each key event.  Searching is conducted on key release for all
 * keys except delete and backspace.
 * 
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class SearchableComboBox extends AdaptableComboBox {

    
/*******************************************************************************
 *                                                                             *
 *                              INSTANCE VARIABLES                             *
 *                                                                             *
 ******************************************************************************/     
    
    /**
     * Original dataset (i.e. no items removed).
     */
    
    private Vector original = null;
    
    /**
     * Reduced dataset.
     */
    
    private Vector reduced = null;
    
    /**
     * Denotes the search mode as auto-completion only.
     */
    
    private static final int SEARCH = 101;
        
    /**
     * Denotes the search mode as deletion.
     */
    
    private static final int DELETE = 102;
    
    /**
     * Denotes the current search mode.
     */
    
    private int mode = DELETE;
    
/*******************************************************************************
 *                                                                             *
 *                               CONSTRUCTOR                                   *
 *                                                                             *
 ******************************************************************************/     
    
    /**
     * Construct a searchable combobox with a vector of items.
     *
     * @param input a vector of items
     */
    
    public SearchableComboBox(Vector input) {
        super(input);
        Vector v = new Vector();
        int length = input.size(); 
        for(int i = 0; i < length; i++) {
            v.add(input.get(i));
        }
        original = v;
        reduced = new Vector();
        setEditable(true);
        final JTextField c = (JTextField)getComponent(2);
        c.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                //Delete or autocomplete only
                switch(mode) {
                    case DELETE: {
                        if(evt.getKeyCode() != evt.VK_SHIFT) {
                            String old = c.getText();
                            delete(c.getText());
                            //Autocomplete if one item left and not a deletion action
                            if(evt.getKeyCode() != evt.VK_DELETE && evt.getKeyCode() != evt.VK_BACK_SPACE) {
                                if(getModel().getSize() == 1) {
                                    setSelectedIndex(0);
                                }
                                else {
                                    c.setText(old);
                                }                                
                            }
                            else {
                                c.setText(old);
                            }
                        }                        
                    }; break;
                    case SEARCH: {
                        if(evt.getKeyCode() != evt.VK_SHIFT && evt.getKeyCode() != evt.VK_DELETE && evt.getKeyCode() != evt.VK_BACK_SPACE) {
                            search(c.getText());
                        }
                    }; break;
                }
            }
        });
        
        //Add a listener to set the dimensions of the menu
        addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {}
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {}
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                EVSMainWindow.setPopupWidth(evt);
            } 
        });        
    }
    
    /**
     * Construct a searchable combobox with an array of items.
     *
     * @param input an array of items
     */
    
    public SearchableComboBox(Object[] input) {
        super(input);
        Vector v = new Vector();
        int length = input.length; 
        for(int i = 0; i < length; i++) {
            v.add(input[i]);
        }
        original = v;
        reduced = new Vector();
        setEditable(true);
        final JTextField c = (JTextField)getComponent(2);
        c.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                //Delete or autocomplete only
                switch(mode) {
                    case DELETE: {
                        if(evt.getKeyCode() != evt.VK_SHIFT) {
                            String old = c.getText();
                            delete(c.getText());
                            //Autocomplete if one item left and not a deletion action
                            if(evt.getKeyCode() != evt.VK_DELETE && evt.getKeyCode() != evt.VK_BACK_SPACE) {
                                if(getModel().getSize() == 1) {
                                    setSelectedIndex(0);
                                }
                                else {
                                    c.setText(old);
                                }                                
                            }
                            else {
                                c.setText(old);
                            }
                        }                        
                    }; break;
                    case SEARCH: {
                        if(evt.getKeyCode() != evt.VK_SHIFT && evt.getKeyCode() != evt.VK_DELETE && evt.getKeyCode() != evt.VK_BACK_SPACE) {
                            search(c.getText());
                        }
                    }; break;
                }
            }
        });
    }
    
    /**
     * Constructor for default searchable combo box.
     */
    
    public SearchableComboBox() {
        super();
        original = new Vector();
        reduced = new Vector();
        setEditable(true);
        final JTextField c = (JTextField)getComponent(2);
        c.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                //Delete or autocomplete only
                switch(mode) {
                    case DELETE: {
                        if(evt.getKeyCode() != evt.VK_SHIFT) {
                            String old = c.getText();
                            delete(c.getText());
                            //Autocomplete if one item left and not a deletion action
                            if(evt.getKeyCode() != evt.VK_DELETE && evt.getKeyCode() != evt.VK_BACK_SPACE) {
                                if(getModel().getSize() == 1) {
                                    setSelectedIndex(0);
                                }
                                else {
                                    c.setText(old);
                                }                                
                            }
                            else {
                                c.setText(old);
                            }
                        }                        
                    }; break;
                    case SEARCH: {
                        if(evt.getKeyCode() != evt.VK_SHIFT && evt.getKeyCode() != evt.VK_DELETE && evt.getKeyCode() != evt.VK_BACK_SPACE) {
                            search(c.getText());
                        }
                    }; break;
                }
            }
        });
    }    
    
/*******************************************************************************
 *                                                                             *
 *                               MUTATOR METHODS                               *
 *                                                                             *
 ******************************************************************************/  
    
    /**
     * Returns the current search mode: one of SearchableComboBox.SEARCH_ONLY or 
     * SearchableComboBox.SEARCH_DELETE. 
     *
     * @return the current search mode
     */
    
    public int getMode() {
        return mode;
    }    
    
/*******************************************************************************
 *                                                                             *
 *                               MUTATOR METHODS                               *
 *                                                                             *
 ******************************************************************************/  
    
    /**
     * Changes the search mode to one of SearchableComboBox.SEARCH or 
     * SearchableComboBox.DELETE. 
     *
     * @param mode the search mode
     */
    
    public void setMode(int mode) throws IllegalArgumentException {
        if(mode == SEARCH || mode == DELETE) {
            this.mode = mode;
        }
        else {
            throw new IllegalArgumentException("Unrecognised search mode.");
        }
    }
    
    /**
     * Override superclass method to set model.
     * 
     * @param aModel the data model
     */
    
    public void setModel(ComboBoxModel aModel) {
        super.setModel(aModel);
        original = new Vector();
        int size = aModel.getSize();
        for(int i = 0; i < size; i++) {
            original.add(aModel.getElementAt(i));
        }
    }
    
/*******************************************************************************
 *                                                                             *
 *                               PRIVATE METHODS                               *
 *                                                                             *
 ******************************************************************************/  
        
    /**
     * Searches for the specified item and auto-completes when a unique match is 
     * found.  
     *
     * @param text the string to match.
     */
    
    private void search(String text) {
        int length = getItemCount();
        int count = 0;
        int index = -1;
        for(int i = 0; i < length; i++) {
            if(getItemAt(i).toString().toLowerCase().startsWith(text.toLowerCase())) {
                count++;
                index = i;        
            }
        }
        if(count == 1) {
            JTextField t = (JTextField)getComponent(2);
            t.setText(getItemAt(index).toString());
        }
    }

    /**
     * Deletes all except matching items. 
     *
     * @param text the string to match.
     */
    
    private void delete(String text) {
        if(text.equals("")) {
            reduced.clear();
            int length = original.size(); 
            for(int i = 0; i < length; i++) {
                reduced.add(original.get(i));
            }            
        }
        else {
            Vector last = new Vector();
            int ln = reduced.size(); 
            for(int i = 0; i < ln; i++) {
                last.add(reduced.get(i));
            }            
            reduced.clear();
            int length = original.size();
            for(int i = 0; i < length; i++) {
                Object item = original.get(i);
                if(item.toString().toLowerCase().startsWith(text.toLowerCase())) {
                    reduced.add(item);
                }
            }
            //Replace with the last positive list if empty
            if(reduced.size() == 0) {
                reduced = last;
            }               
        }
        DefaultComboBoxModel def = new DefaultComboBoxModel(reduced);
        super.setModel(def);
    }        
    
}