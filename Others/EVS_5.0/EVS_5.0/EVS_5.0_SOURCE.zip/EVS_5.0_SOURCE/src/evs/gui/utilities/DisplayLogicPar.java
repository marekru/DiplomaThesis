package evs.gui.utilities;

//EVS dependencies
import evs.metric.parameters.DoubleProcedureParameter;

/**
 * Class for storing and displaying a logical condition in a combo box.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DisplayLogicPar {

    /**
     * The logical type.
     */
    private int type;

    /**
     * Construct with a specified logical type.
     *
     * @param type the logical type
     */   
    public DisplayLogicPar(int type) {
        switch(type) {
            case DoubleProcedureParameter.LESS_THAN:{}; break;
            case DoubleProcedureParameter.GREATER_THAN:{}; break;
            case DoubleProcedureParameter.LESS_EQUAL:{}; break;
            case DoubleProcedureParameter.GREATER_EQUAL:{}; break;
            case DoubleProcedureParameter.BETWEEN:{}; break;
            default: throw new IllegalArgumentException("Unrecognized logical parameter for display.");
        }
        this.type = type;
    }

    /**
     * Returns the logical type.
     *
     * @return the logical type
     */
    public int getID() {
        return type;
    }

    /**
     * Display name.
     *
     * @return the display name
     */
    public String toString() {
        switch (type) {
            case DoubleProcedureParameter.LESS_THAN: {
                return "Less than (<)";
            }
            case DoubleProcedureParameter.GREATER_THAN: {
                return "Greater than (>)";
            }
            case DoubleProcedureParameter.LESS_EQUAL: {
                return "Less than or equal to (<=)";
            }
            case DoubleProcedureParameter.GREATER_EQUAL: {
                return "Greater than or equal to (>=)";
            }
            case DoubleProcedureParameter.BETWEEN: {
                return "Between (lower <= x <= upper)";
            }
            default: {
                throw new IllegalArgumentException("Unrecognized type.");
            }
        }
    }
} 
        
   
