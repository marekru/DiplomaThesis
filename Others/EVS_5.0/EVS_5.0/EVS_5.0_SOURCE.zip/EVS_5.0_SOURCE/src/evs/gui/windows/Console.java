package evs.gui.windows;

import java.io.File;
import java.io.BufferedWriter;
import java.io.FileWriter;

//Java swing dependencies
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.text.StyleConstants;
import javax.swing.text.Style;
import javax.swing.text.StyledDocument;

//Java awt dependencies
import java.awt.Dimension;

//Java util dependencies
import java.util.Date;

//EVS dependencies
import evs.gui.utilities.EVSFileChooser;
import java.awt.Color;

/**
 * Constructs a console for showing details of exceptions thrown.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class Console extends JDialog {
   
/*******************************************************************************
 *                                                                             *
 *                               CONSTRUCTORS                                  *
 *                                                                             *
 ******************************************************************************/  

    /**
     * Construct a console.
     * 
     * @param modal is true to set the dialog modal
     */
    
    protected Console(boolean modal) {
        super();
        super.setModal(modal);
        initComponents();       
        setTitle("Console"); 
    }    
    
    /**
     * Construct a console with a parent dialog and modal status.
     * 
     * @param parent the parent dialog
     * @param modal is true to set the dialog modal
     */
    
    protected Console(JDialog parent, boolean modal) {
        super(parent,modal);
        initComponents();     
        setTitle("Console"); 
    }
    
    /**
     * Construct a console with a parent frame and modal status.
     * 
     * @param parent the parent frame
     * @param modal is true to set the frame modal
     */
    
    protected Console(JFrame parent, boolean modal) {
        super(parent,modal);  
        initComponents();    
        setTitle("Console"); 
    }        

/*******************************************************************************
 *                                                                             *
 *                              PROTECTED METHODS                              *
 *                                                                             *
 ******************************************************************************/              

    /**
     * Adds a string to the console: appends new messages to the top.
     *
     * @param message the string
     */
    
    protected void addMessage(String message) {
        try {
            String sep = System.getProperty("line.separator");
            long time = System.currentTimeMillis();
            Date date = new Date(time);
            String header = "Error thrown on " + date.toString() + ":" + sep;
            errorPane.setText(header + message + sep + errorPane.getText());
            StyledDocument doc = errorPane.getStyledDocument();
            Style style = errorPane.addStyle("Red", null);
            StyleConstants.setForeground(style, Color.red);
            StyleConstants.setBold(style, true);
            StyleConstants.setUnderline(style, true);
            Style styleB = errorPane.addStyle("Black", null);
            StyleConstants.setForeground(styleB, Color.black);
            doc.setCharacterAttributes(0, header.length() - 1, errorPane.getStyle("Red"), false);
            doc.setCharacterAttributes(header.length(),errorPane.getText().length(), errorPane.getStyle("Black"), false);
            errorPane.setCaretPosition(0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Returns the messages from the current console.
     *
     * @return the messages
     */
    
    protected String getMessages() {
        return(errorPane.getText());
    }       

    /**
     * Sets the console header text.
     *
     * @param header the header text
     */
    
    protected void setHeader(String header) {
        jLabel1.setText(header);
    }
    

/*******************************************************************************
 *                                                                             *
 *                               PRIVATE METHODS                               *
 *                                                                             *
 ******************************************************************************/      
    
    /**
     * Initializes the window components.
     */   
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel613 = new javax.swing.JPanel();
        errorScrollPane = new javax.swing.JScrollPane();
        errorPane = new javax.swing.JTextPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        saveButton = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        exitButton = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();

        setFont(new java.awt.Font("Verdana", 1, 10));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                closeDialog(evt);
            }
        });
        getContentPane().setLayout(new java.awt.GridLayout(1, 0));

        jPanel2.setMaximumSize(new java.awt.Dimension(32000, 32000));
        jPanel2.setMinimumSize(new java.awt.Dimension(500, 304));
        jPanel2.setPreferredSize(new java.awt.Dimension(630, 370));
        jPanel2.setLayout(new javax.swing.BoxLayout(jPanel2, javax.swing.BoxLayout.Y_AXIS));

        jPanel3.setMaximumSize(new java.awt.Dimension(32767, 25));
        jPanel3.setPreferredSize(new java.awt.Dimension(10, 25));
        jPanel3.setLayout(new javax.swing.BoxLayout(jPanel3, javax.swing.BoxLayout.LINE_AXIS));

        jLabel1.setFont(new java.awt.Font("Verdana", 1, 11)); // NOI18N
        jLabel1.setText(" Details of errors thrown (latest error at TOP):");
        jLabel1.setMaximumSize(new java.awt.Dimension(2500, 25));
        jLabel1.setPreferredSize(new java.awt.Dimension(122, 25));
        jPanel3.add(jLabel1);

        jPanel2.add(jPanel3);

        jPanel613.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 3, 3, 3));
        jPanel613.setMinimumSize(new java.awt.Dimension(150, 0));
        jPanel613.setPreferredSize(new java.awt.Dimension(100, 100));
        jPanel613.setLayout(new javax.swing.BoxLayout(jPanel613, javax.swing.BoxLayout.Y_AXIS));

        errorScrollPane.setPreferredSize(new java.awt.Dimension(450, 450));

        errorPane.setBorder(javax.swing.BorderFactory.createEmptyBorder(3, 3, 3, 3));
        errorScrollPane.setViewportView(errorPane);

        jPanel613.add(errorScrollPane);

        jPanel2.add(jPanel613);

        jPanel1.setMaximumSize(new java.awt.Dimension(2147483647, 30));
        jPanel1.setMinimumSize(new java.awt.Dimension(32000, 30));
        jPanel1.setPreferredSize(new java.awt.Dimension(32000, 30));
        jPanel1.setLayout(new javax.swing.BoxLayout(jPanel1, javax.swing.BoxLayout.LINE_AXIS));

        jPanel12.setPreferredSize(new java.awt.Dimension(32000, 10));

        jPanel7.setMinimumSize(new java.awt.Dimension(1, 10));
        jPanel7.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel12.add(jPanel7);

        jPanel1.add(jPanel12);

        saveButton.setFont(new java.awt.Font("Dialog", 0, 11));
        saveButton.setText("Save");
        saveButton.setAlignmentX(0.5F);
        saveButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        saveButton.setMaximumSize(new java.awt.Dimension(65, 29));
        saveButton.setMinimumSize(new java.awt.Dimension(65, 29));
        saveButton.setPreferredSize(new java.awt.Dimension(65, 29));
        saveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveButtonActionPerformed(evt);
            }
        });
        jPanel1.add(saveButton);

        jPanel4.setMaximumSize(new java.awt.Dimension(3, 32767));
        jPanel4.setMinimumSize(new java.awt.Dimension(3, 10));
        jPanel4.setPreferredSize(new java.awt.Dimension(3, 10));
        jPanel1.add(jPanel4);

        exitButton.setFont(new java.awt.Font("Dialog", 0, 11));
        exitButton.setText("Exit");
        exitButton.setAlignmentX(0.5F);
        exitButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        exitButton.setMaximumSize(new java.awt.Dimension(65, 29));
        exitButton.setMinimumSize(new java.awt.Dimension(65, 29));
        exitButton.setPreferredSize(new java.awt.Dimension(65, 29));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        jPanel1.add(exitButton);

        jPanel5.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel5.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel5.setPreferredSize(new java.awt.Dimension(2, 10));
        jPanel1.add(jPanel5);

        jPanel2.add(jPanel1);

        getContentPane().add(jPanel2);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Save the console output to file.
     *
     * @param evt an action event
     */

    private void saveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveButtonActionPerformed
        File selectedFile = null;
        EVSFileChooser chooser = new EVSFileChooser();
        chooser.setPreferredSize(new Dimension(500,330));
        int status = chooser.showSaveDialog(this);
        if (status == EVSFileChooser.APPROVE_OPTION) {
            selectedFile = chooser.getSelectedFile();
        }
        if(selectedFile != null) {
            BufferedWriter buff = null;
            try {
                buff = new BufferedWriter(new FileWriter(selectedFile,true));
                buff.write(errorPane.getText());
            }
            catch(Exception e) {
                ExceptionHandler.displayException(e);
            }
            finally {
                if(buff != null) {
                    try {
                        buff.close();
                    }
                    catch(Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }//GEN-LAST:event_saveButtonActionPerformed

    /**
     * Closes the console.
     *
     * @param evt an action event
     */    
    
    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        setVisible(false);
    }//GEN-LAST:event_exitButtonActionPerformed
     
    /**
     * Closes the console.
     *
     * @param evt a window event
     */    
    
    private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
        setVisible(false);
    }//GEN-LAST:event_closeDialog
    
    /*******************************************************************************
     *                                                                             *
     *                              INSTANCE VARIABLES                             *
     *                                                                             *
     ******************************************************************************/

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTextPane errorPane;
    private javax.swing.JScrollPane errorScrollPane;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel613;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JButton saveButton;
    // End of variables declaration//GEN-END:variables

}
