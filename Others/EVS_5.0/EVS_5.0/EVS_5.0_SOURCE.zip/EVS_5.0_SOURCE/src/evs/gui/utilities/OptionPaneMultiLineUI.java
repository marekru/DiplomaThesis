package evs.gui.utilities;

import javax.swing.plaf.basic.*;
import javax.swing.plaf.*;
import javax.swing.*;

/**
 * Class to display an option pane with wrapped text.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class OptionPaneMultiLineUI extends BasicOptionPaneUI {

    static protected final int MAX_CHARACTERS_PER_LINE_COUNT = 120;

    public static ComponentUI createUI(JComponent x) {
        return new OptionPaneMultiLineUI();
    }

    @Override
    protected int getMaxCharactersPerLineCount() {
        int maxCharactersPerLineCount = optionPane.getMaxCharactersPerLineCount();
        if (maxCharactersPerLineCount == Integer.MAX_VALUE) {
            maxCharactersPerLineCount = this.MAX_CHARACTERS_PER_LINE_COUNT;
        }
        return maxCharactersPerLineCount;
    }
}
