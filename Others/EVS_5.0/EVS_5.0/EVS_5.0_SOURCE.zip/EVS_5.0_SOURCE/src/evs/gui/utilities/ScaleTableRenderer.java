package evs.gui.utilities;

//Java awt dependencies
import java.awt.Component;
import java.awt.Color;

//Java swing dependencies
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 * Extends the default table cell renderer to allow custom editing of table
 * cell colors for the scale table.  
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class ScaleTableRenderer extends DefaultTableCellRenderer {
    
/*******************************************************************************
 *                                                                             *
 *                             INSTANCE VARIABLES                              *
 *                                                                             *
 ******************************************************************************/          
    
    /**
     * Identifier for the null data type.
     */
    
    public static final int NULL_TYPE = 101;
    
    /**
     * Default null string used in the scale editor.
     */
    
    private String nullString = "NOT REQUIRED";    
    
/*******************************************************************************
 *                                                                             *
 *                              ACCESSOR METHODS                               *
 *                                                                             *
 ******************************************************************************/          
        
    /**
     * Renders a cell according to the value it contains.
     *
     * @param table the table
     * @param value the cell value
     * @param isSelected is true if the cell is selected
     * @param hasFocus is true if the cell has focus
     * @param row the row number
     * @param column the column number
     * @return a rendered cell
     */
    
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        Component cell = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        Object nullType = NULL_TYPE;
        if(nullType.equals(value)) {
            super.setValue(nullString);
            cell.setForeground(Color.blue);
        } else {
            cell.setForeground(Color.black);
        }
        return cell;
    }
    
/*******************************************************************************
 *                                                                             *
 *                               MUTATOR METHODS                               *
 *                                                                             *
 ******************************************************************************/          
    
    /**
     * Sets the display value for a null cell.
     *
     * @param nullString the null string
     */
    
    protected void setNullString(String nullString) {
        this.nullString = nullString;
    }

    //Override the defaults for improved performance
    public void validate(){}
    public void revalidate(){}
    protected void firePropertyChange(String propertyName, Object oldValue, Object newValue) {}
    public void firePropertyChange(String propertyName, boolean oldValue, boolean newValue) {}

}

