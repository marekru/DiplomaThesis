package evs.gui.windows;

//Java swing dependencies
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

//Java awt dependencies
import java.awt.event.*;
import java.awt.*;

//Java util dependencies
import java.util.*;

//EVS dependencies
import evs.metric.metrics.*;
import evs.metric.parameters.*;
import evs.gui.utilities.*;
import evs.utilities.mathutil.*;
import evs.data.fileio.*;

/**
 * Constructs a dialog of parameter options
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class MoreParOptionsDialog extends JDialog implements GUICommunicator {
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/

    /**
     * Construct an options dialog.
     *
     * @param m the metric for which options are required
     * @param modal is true to set the dialog modal
     */
    
    protected MoreParOptionsDialog(Metric m,boolean modal) {
        //Set the bootstrap display options
        if(m instanceof ThresholdMetricStore) {
            bootstrapable = ((ThresholdMetricStore)m).isBootstrapable();
        }
        else {
            bootstrapable = m instanceof BootstrapableMetric;
        }
        initComponents();
        setModal(modal);
        String name = "Options for " + m;
        if (name.length() > 100) {
            name = name.substring(0, 100) + "...";
        }
        setTitle(name);
        setProperties(); 
        setSize(750,550);
        Metric c = m;
        if (m instanceof ThresholdMetricStore) {
            c = (((ThresholdMetricStore)m)).getFirstMetricInStore();
        }
        this.m = c;
        if(m instanceof DecomposableScore) {
            allowDecomp = true;
        }

        //Set the interval table
        //Add a selection changed method to the table
        intervalTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent evt) {
                int row = intervalTable.getSelectedRow();
                deleteButton.setEnabled(intervalTable.getRowCount() > 0 && row > -1);  //Must have one threshold
            }
        });

        //Set the cell renderer for the "main" thresholds in the interval table
        intervalTable.setDefaultRenderer(Boolean.class,new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                JCheckBox cb = new JCheckBox();
                cb.setHorizontalAlignment(SwingConstants.CENTER);
                if(!isSelected) {
                    cb.setBackground(Color.white);
                } else {
                    Color bg = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column).getBackground();
                    cb.setBackground(bg);
                }
                cb.setEnabled(table.isEnabled());
                cb.setSelected((Boolean) value);
                return cb;
            }
        });

        //Add a listener for a change in technique
        techniqueBox.addItemListener(new ItemListener(){
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == e.SELECTED) {
                    boolean enabled = intervalTable.isEnabled();
                    boolean willEnable = !e.getItem().toString().equalsIgnoreCase("None");
                    if (enabled != willEnable) {
                        setOptionEnabled(MetricParameter.BOOTSTRAP_PARAMETER,willEnable);
                    }
                }
            }
        });

        //Increases the table row height
        intervalTable.setRowHeight(25);
        intervalTable.getSelectionModel().setSelectionMode(intervalTable.
                getSelectionModel().MULTIPLE_INTERVAL_SELECTION);
        intervalTable.getColumnModel().getColumn(0).setPreferredWidth(3350);
        intervalTable.getColumnModel().getColumn(1).setPreferredWidth(3350);
        intervalTable.getColumnModel().getColumn(2).setPreferredWidth(850);

    }

    /**
     * Check and set the parameter values and then close the dialog.
     */

    protected void close() {
        if (pars != null) {
            if (pars.containsKey(MetricParameter.ROC_POINTS_PARAMETER)) {
                pars.put(MetricParameter.ROC_POINTS_PARAMETER, pointField.getText());
            }
            if (pars.containsKey(MetricParameter.FITTED_AUC_PARAMETER)) {
                pars.put(MetricParameter.FITTED_AUC_PARAMETER, fittedROCBox.isSelected());
            }
            if (pars.containsKey(MetricParameter.FITTED_ROC_PARAMETER)) {
                pars.put(MetricParameter.FITTED_ROC_PARAMETER, fittedROCBox.isSelected());
            }
            if (pars.containsKey(MetricParameter.ROC_SCORE_POINTS_PARAMETER)) {
                pars.put(MetricParameter.ROC_SCORE_POINTS_PARAMETER, pointField.getText());
            }
            if (pars.containsKey(MetricParameter.ROC_SCORE_METHOD_PARAMETER)) {
                pars.put(MetricParameter.ROC_SCORE_METHOD_PARAMETER, 
                        ((DisplayAUCMethodPar) aucBox.getSelectedItem()).getID());
            }
            if (pars.containsKey(MetricParameter.RELIABILITY_POINTS_PARAMETER)) {
                pars.put(MetricParameter.RELIABILITY_POINTS_PARAMETER, pointField.getText());
            }
            if (pars.containsKey(MetricParameter.SPREAD_BIAS_POINTS_PARAMETER)) {
                pars.put(MetricParameter.SPREAD_BIAS_POINTS_PARAMETER, pointField.getText());
            }
            if (pars.containsKey(MetricParameter.CENTRAL_SPREAD_BIAS_PARAMETER)) {
                pars.put(MetricParameter.CENTRAL_SPREAD_BIAS_PARAMETER, centSBCheckBox.isSelected());
            }
            if (pars.containsKey(MetricParameter.RANK_HIST_SAMPLE_PARAMETER)) {
                pars.put(MetricParameter.RANK_HIST_SAMPLE_PARAMETER, rankHistCheckBox.isSelected());
            }
            if (pars.containsKey(MetricParameter.MCR_POINTS_PARAMETER)) {
                pars.put(MetricParameter.MCR_POINTS_PARAMETER, pointField.getText());
            }
            if (pars.containsKey(MetricParameter.MEP_POINTS_PARAMETER)) {
                pars.put(MetricParameter.MEP_POINTS_PARAMETER, pointField.getText());
            }
            if (pars.containsKey(MetricParameter.BOX_POOLED_LEAD_POINTS_PARAMETER)) {
                pars.put(MetricParameter.BOX_POOLED_LEAD_POINTS_PARAMETER, pointField.getText());
            }
            if (pars.containsKey(MetricParameter.BOX_UNPOOLED_POINTS_PARAMETER)) {
                pars.put(MetricParameter.BOX_UNPOOLED_POINTS_PARAMETER, pointField.getText());
            }
            if (pars.containsKey(MetricParameter.BOX_UNPOOLED_OBS_POINTS_PARAMETER)) {
                pars.put(MetricParameter.BOX_UNPOOLED_OBS_POINTS_PARAMETER, pointField.getText());
            }
            if (pars.containsKey(MetricParameter.INTEGER_PARAMETER)) {
                pars.put(MetricParameter.INTEGER_PARAMETER, 
                        ((DisplayLogicPar) logBox.getSelectedItem()).getID());
            }
            if (pars.containsKey(MetricParameter.UNCONDITIONAL_PARAMETER)) {
                pars.put(MetricParameter.UNCONDITIONAL_PARAMETER, uncCheckBox.isSelected());
            }
            if (pars.containsKey(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER)) {
                pars.put(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER, probCheckBox.isSelected());
            }
            if (pars.containsKey(MetricParameter.EQUAL_SAMPLES_PARAMETER)) {
                pars.put(MetricParameter.EQUAL_SAMPLES_PARAMETER, equalCheckBox.isSelected());
            }
            if (pars.containsKey(MetricParameter.REFERENCE_FORECAST_PARAMETER)) {
                DisplayReferencePar p = (DisplayReferencePar) 
                        pars.get(MetricParameter.REFERENCE_FORECAST_PARAMETER);
                Object item = refBox.getSelectedItem();
                if(item!=null) {
                    p.setSelectedItem(item.toString());
                }
            }
            if (pars.containsKey(MetricParameter.VECTOR_FUNCTION_PARAMETER)) {
                pars.put(MetricParameter.VECTOR_FUNCTION_PARAMETER, 
                        ((VectorFunction) statBox.getSelectedItem()));
            }

            if (pars.containsKey(MetricParameter.BOOTSTRAP_PARAMETER)) {
                BootstrapParameter p = (BootstrapParameter) pars.get(MetricParameter.BOOTSTRAP_PARAMETER);
                //Attempt to set the parameters
                if(techniqueBox.getSelectedIndex()==0) {
                    p.clear();
                } else {
                    int sampleCount;
                    int minSampleCount;
                    double blockSize;
                    String blockUnit;
                    ProbabilityIntervalParameter[] pr;
                    ProbabilityIntervalParameter main = null;
                    try {
                        sampleCount = Double.valueOf(sampleField.getText()).intValue();
                        minSampleCount = Double.valueOf(minSampleField.getText()).intValue();
                    } catch(Exception e) {
                        throw new IllegalArgumentException("Unable to set the sample count parameters for the "
                                + "stationary block bootstrap: "+e.getMessage());
                    }
                    try {
                        blockSize = Double.valueOf(blockSizeField.getText());
                        blockUnit = blockUnitBox.getSelectedItem()+"";
                    } catch(Exception e) {
                        throw new IllegalArgumentException("Unable to set the block size parameters for the "
                                + "stationary block bootstrap: "+e.getMessage());
                    }
                    try {
                        //Create the intervals
                        int rows = intervalTable.getRowCount();
                        pr = new ProbabilityIntervalParameter[rows];
                        for (int i = 0; i < rows; i++) {
                            if(intervalTable.isEditing()) {
                                intervalTable.getCellEditor(i,0).stopCellEditing();
                                intervalTable.getCellEditor(i,1).stopCellEditing();
                            }
                            double low = Double.valueOf(intervalTable.getValueAt(i, 0) + "");
                            double high = Double.valueOf(intervalTable.getValueAt(i, 1) + "");
                            pr[i] = new ProbabilityIntervalParameter(low, high);
                            if (Boolean.valueOf(true).equals(intervalTable.getValueAt(i, 2))) {
                                main = pr[i];
                            }
                        }
                    } catch (Exception e) {
                        //e.printStackTrace();
                        throw new IllegalArgumentException("Unable to set the probability intervals for the "
                                + "stationary block bootstrap: "+e.getMessage());
                    }
                    //Set the parameters
                    if(sampleCount>10000) {
                        int n = JOptionPane.showOptionDialog(EVSMainWindow.main,"Bootstrapping with more than "
                                + "ten thousand samples may be time consuming. Proceed?","Warning: time "
                                + "consuming operation", JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
                        if(n == JOptionPane.NO_OPTION) {
                            return;
                        }
                    }
                    p = new BootstrapParameter(blockSize,blockUnit,sampleCount,minSampleCount,pr,main);
                    //Check for consistency with block sizes of other metrics if defined
                    Vector<BootstrapParameter> check = VERIFICATION_B.getBootstrapPars();
                    for(BootstrapParameter pc : check) {
                        if(pc.isBootstrap() && pc.getNominalBlockSizeInMillis()
                                !=p.getNominalBlockSizeInMillis()) {
                            throw new IllegalArgumentException("The block size is inconsistent with "
                                    + "that of at least one other metric defined for unit '"
                                    +VERIFICATION_A.getSelectedUnit()+"', yet the paired data (and "
                                    + "hence temporal dependence) are the same.");
                        }
                    }
                }
                pars.put(MetricParameter.BOOTSTRAP_PARAMETER,p);
            }

//            //Conduct sensibility check for combined options before setting parameters
//            if (pars.containsKey(MetricParameter.DECOMPOSE_PARAMETER)) {
//                DisplayScoreDecompPar p = (DisplayScoreDecompPar) pars.get(MetricParameter.DECOMPOSE_PARAMETER);
//                //Do not allow decomposition other than for climatology
//                if (p.getDecomposePar().getParVal() && pars.containsKey(MetricParameter.REFERENCE_FORECAST_PARAMETER)) {
//                    DisplayReferencePar r = (DisplayReferencePar) pars.get(MetricParameter.REFERENCE_FORECAST_PARAMETER);
//                    int sel = r.getSelectedIndex();
//                    if (m instanceof BrierSkillScore) {
//                        if(sel==-1) {
//                            throw new IllegalArgumentException("Select a reference forecast for the Brier Skill Score.");
//                        }
//                        else if(!r.getRefFcsts()[sel].equalsIgnoreCase(ForecastTypeParameter.SAMPLE_CLIMATOLOGY_STRING)) {
//                            //Reset the selected decomposition
//                            p.setSelectedItem(DecomposableScore.NONE);
//                            throw new IllegalArgumentException("Brier Skill Score decomposition is only supported for reference forecast '"
//                                    + ForecastTypeParameter.SAMPLE_CLIMATOLOGY_STRING+"'.");
//                        }
//                    } else if (m instanceof MeanContRankProbSkillScore) {
//                        if(sel==-1) {
//                            throw new IllegalArgumentException("Select a reference forecast for the CRPSS.");
//                        }
//                        else if(!r.getRefFcsts()[sel].equalsIgnoreCase(ForecastTypeParameter.SAMPLE_CLIMATOLOGY_STRING)) {
//                            //Reset the selected decomposition
//                            p.setSelectedItem(DecomposableScore.NONE);
//                            throw new IllegalArgumentException("The CRPSS decomposition is only supported for reference forecast '"
//                                    + ForecastTypeParameter.SAMPLE_CLIMATOLOGY_STRING+"'.");
//                        }
//                    }
//                }
//            }

            //Set the new parameters
            VERIFICATION_B.setParameters(m, pars);

            //Sensibility checks complete: allow close
            pars = null; //Always reset the local pointers on exit
            m = null;
            allowDecomp = false;
        }
        setVisible(false);
    }

    /**
     * Cancels the dialog without changing any parameter values.
     */

    private void cancel() {
        setVisible(false);
    }

    /**
     * Sets the properties of the dialog.
     */

    private void setProperties() {

        //Implement this code when the ROC points parameter
        //is not required for the ROC Score UNLESS the fitted ROC Score is requested
//        fittedROCBox.addChangeListener(new ChangeListener() {
//            public void stateChanged(ChangeEvent changeEvent) {
//                pointLabel.setEnabled(fittedROCBox.isSelected());
//                if(!fittedROCBox.isSelected()) {
//                    pointField.setText("");
//                }
//                pointField.setEnabled(fittedROCBox.isSelected());
//            }
//        });

        //Averaging options for single-valued metrics
        DefaultComboBoxModel smod = new DefaultComboBoxModel();
        smod.addElement(FunctionLibrary.mean());
        smod.addElement(FunctionLibrary.median());
        smod.addElement(FunctionLibrary.mode());
        statBox.setModel(smod);

        //Logical conditions for event identification
        DefaultComboBoxModel mod = new DefaultComboBoxModel();
        mod.addElement(new DisplayLogicPar(DoubleProcedureParameter.LESS_THAN));
        mod.addElement(new DisplayLogicPar(DoubleProcedureParameter.GREATER_THAN));
        mod.addElement(new DisplayLogicPar(DoubleProcedureParameter.LESS_EQUAL));
        mod.addElement(new DisplayLogicPar(DoubleProcedureParameter.GREATER_EQUAL));
        mod.addElement(new DisplayLogicPar(DoubleProcedureParameter.BETWEEN));
        logBox.setModel(mod);

        //Options for AUC method parameter
        DefaultComboBoxModel auc = new DefaultComboBoxModel();
        auc.addElement(new DisplayAUCMethodPar(ROCScoreMethodParameter.MASON_GRAHAM));
        auc.addElement(new DisplayAUCMethodPar(ROCScoreMethodParameter.TRAPEZOID));
        aucBox.setModel(auc);
        
        //Bootstrap method options
        if(bootstrapable) {
            DefaultComboBoxModel bootMod = new DefaultComboBoxModel();
            bootMod.addElement("None");
            bootMod.addElement("Stationary block bootstrap");
            techniqueBox.setModel(bootMod);
        }

        //Block units
        blockUnitBox.setModel(new DefaultComboBoxModel(GlobalUnitsReader.getTimeUnits()));

    }

    /**
     * Enables or disables a specified parameter option.  This may be called for
     * specific options after calling disableAllOptions()
     *
     * @param option the parameter option
     * @param enable is true to enable, false to disable
     */

    protected void setOptionEnabled(int option, boolean enable) {
        switch(option) {
            case MetricParameter.DECOMPOSE_PARAMETER: {
                if(allowDecomp) {
                    scoreDecLabel.setEnabled(enable);
                    scoreDecBox.setEnabled(enable);
                }
            }; break;
            case MetricParameter.ROC_POINTS_PARAMETER: {
                pointLabel.setEnabled(enable);
                pointField.setEnabled(enable);
            }; break;
            case MetricParameter.ROC_SCORE_METHOD_PARAMETER: {
                aucMethodLabel.setEnabled(enable);
                aucBox.setEnabled(enable);
            }; break;
            case MetricParameter.FITTED_ROC_PARAMETER: {
                fittedROCBox.setEnabled(enable);
            }; break;
            case MetricParameter.FITTED_AUC_PARAMETER: {
                fittedROCBox.setEnabled(enable);
            }; break;
            case MetricParameter.ROC_SCORE_POINTS_PARAMETER: {
                pointLabel.setEnabled(enable);
                pointField.setEnabled(enable);
            }; break;
            case MetricParameter.RELIABILITY_POINTS_PARAMETER: {
                pointLabel.setEnabled(enable);
                pointField.setEnabled(enable);
            }; break;
            case MetricParameter.SPREAD_BIAS_POINTS_PARAMETER: {
                pointLabel.setEnabled(enable);
                pointField.setEnabled(enable);
            }; break;
            case MetricParameter.MCR_POINTS_PARAMETER: {
                pointLabel.setEnabled(enable);
                pointField.setEnabled(enable);
            }; break;
            case MetricParameter.MEP_POINTS_PARAMETER: {
                pointLabel.setEnabled(enable);
                pointField.setEnabled(enable);
            }; break;
            case MetricParameter.BOX_POOLED_LEAD_POINTS_PARAMETER: {
                pointLabel.setEnabled(enable);
                pointField.setEnabled(enable);
            }; break;
            case MetricParameter.BOX_UNPOOLED_OBS_POINTS_PARAMETER: {
                pointLabel.setEnabled(enable);
                pointField.setEnabled(enable);
            }; break;
            case MetricParameter.BOX_UNPOOLED_POINTS_PARAMETER: {
                pointLabel.setEnabled(enable);
                pointField.setEnabled(enable);
            }; break;
            case MetricParameter.DOUBLE_PROCEDURE_PARAMETER: {
                logLabel.setEnabled(enable);
                logBox.setEnabled(enable);
            }; break;
            case MetricParameter.UNCONDITIONAL_PARAMETER: {
                uncCheckBox.setEnabled(enable);
            }; break;
            case MetricParameter.EQUAL_SAMPLES_PARAMETER: {
                equalCheckBox.setEnabled(enable);
            }; break;
            case MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER: {
                probCheckBox.setEnabled(enable);
            }; break;
            case MetricParameter.CENTRAL_SPREAD_BIAS_PARAMETER: {
                centSBCheckBox.setEnabled(enable);
            }; break;
            case MetricParameter.RANK_HIST_SAMPLE_PARAMETER: {
                rankHistCheckBox.setEnabled(enable);
            }; break;
            case MetricParameter.REFERENCE_FORECAST_PARAMETER: {
                refLabel.setEnabled(enable);
                refBox.setEnabled(enable);
            }; break;
            case MetricParameter.VECTOR_FUNCTION_PARAMETER: {
                statLabel.setEnabled(enable);
                statBox.setEnabled(enable);
            }; break;
            case MetricParameter.BOOTSTRAP_PARAMETER: {
                sampleLabel.setEnabled(enable);
                sampleField.setEnabled(enable);
                minSampleLabel.setEnabled(enable);
                minSampleField.setEnabled(enable);
                blockSizeLabel.setEnabled(enable);
                blockSizeField.setEnabled(enable);
                blockUnitLabel.setEnabled(enable);
                blockUnitBox.setEnabled(enable);
                intervalLabel.setEnabled(enable);
                intervalTable.setEnabled(enable);
                intervalTable.clearSelection();
                addButton.setEnabled(enable);
                if(enable) {
                    intervalTable.getTableHeader().setForeground(Color.black);
                    intervalTable.setForeground(Color.black);
                    intervalTableScrollPane.setVerticalScrollBarPolicy(intervalTableScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
                    deleteButton.setEnabled(intervalTable.getRowCount() > 0 && intervalTable.getSelectedRow() > 0);
                } else {
                    intervalTable.clearSelection();
                    intervalTable.getTableHeader().setForeground(new Color(157, 154, 118));
                    intervalTable.setForeground(new Color(157, 154, 118));
                    intervalTableScrollPane.setVerticalScrollBarPolicy(intervalTableScrollPane.VERTICAL_SCROLLBAR_NEVER);
                    blockUnitBox.setSelectedIndex(-1);
                    deleteButton.setEnabled(false);
                    sampleField.setText("");
                    minSampleField.setText("");
                    blockSizeField.setText("");
                    blockUnitBox.setSelectedIndex(-1);
                    ((DefaultTableModel)intervalTable.getModel()).setRowCount(0);
                }
            }; break;
        }
    }

    /**
     * Disables all options and clears the list of parameter values.
     */

    protected void setOptionsDisabled() {
        pointLabel.setEnabled(false);
        pointField.setText("");
        pointField.setEnabled(false);
        uncCheckBox.setSelected(false);
        uncCheckBox.setEnabled(false);
        equalCheckBox.setSelected(false);
        equalCheckBox.setEnabled(false);
        centSBCheckBox.setSelected(false);
        centSBCheckBox.setEnabled(false);
        rankHistCheckBox.setSelected(false);
        rankHistCheckBox.setEnabled(false);
        fittedROCBox.setSelected(false);
        fittedROCBox.setEnabled(false);
        probCheckBox.setEnabled(false);
        refLabel.setEnabled(false);
        refBox.setSelectedIndex(-1);
        refBox.setEnabled(false);
        statLabel.setEnabled(false);
        statBox.setSelectedIndex(-1);
        statBox.setEnabled(false);
        aucMethodLabel.setEnabled(false);
        aucBox.setSelectedIndex(-1);
        aucBox.setEnabled(false);
        logLabel.setEnabled(false);
        logBox.setSelectedIndex(-1);
        logBox.setEnabled(false);
        scoreDecLabel.setEnabled(false);
        scoreDecBox.setSelectedIndex(-1);
        scoreDecBox.setEnabled(false);
        pars = null;
        m = null;
        allowDecomp = false;
    }

    /**
     * Sets map of parameters to edit.  Obtains current values from the parameter
     * map to display and stores them locally, to allow updating, until exiting.
     *
     * @param metric the metric associated with the parameters
     * @param pars the parameters to edit
     */

    protected void setParameters(Metric metric, TreeMap<Integer,Object> pars) {
        //Set the metric
        Metric c = metric;
        if (metric instanceof ThresholdMetricStore) {
            c = (((ThresholdMetricStore) metric)).getFirstMetricInStore();
        }
        m = c;
        if (m instanceof DecomposableScore) {
            allowDecomp = true;
        }
        //Any mutable parameters must be deep copied for the local store: most are immutable
        this.pars = new TreeMap<Integer,Object>();
        if(pars.containsKey(MetricParameter.ROC_POINTS_PARAMETER)) {
            setOptionEnabled(MetricParameter.ROC_POINTS_PARAMETER,true);
            pointField.setText(pars.get(MetricParameter.ROC_POINTS_PARAMETER)+"");
        }
        if(pars.containsKey(MetricParameter.FITTED_ROC_PARAMETER)) {
            setOptionEnabled(MetricParameter.FITTED_ROC_PARAMETER,true);
            fittedROCBox.setSelected(pars.get(MetricParameter.FITTED_ROC_PARAMETER).equals(true));
        }
        if(pars.containsKey(MetricParameter.FITTED_AUC_PARAMETER)) {
            setOptionEnabled(MetricParameter.FITTED_AUC_PARAMETER,true);
            fittedROCBox.setSelected(pars.get(MetricParameter.FITTED_AUC_PARAMETER).equals(true));
        }
        if(pars.containsKey(MetricParameter.ROC_SCORE_METHOD_PARAMETER)) { 
            setOptionEnabled(MetricParameter.ROC_SCORE_METHOD_PARAMETER,true);  
            int index = getAUCIndex(new Integer(pars.get(MetricParameter.ROC_SCORE_METHOD_PARAMETER)+""));
            if(index > -1) {
                aucBox.setSelectedIndex(index);
            }
        }
        if(pars.containsKey(MetricParameter.ROC_SCORE_POINTS_PARAMETER)) {
            setOptionEnabled(MetricParameter.ROC_SCORE_POINTS_PARAMETER,true);
            pointField.setText(pars.get(MetricParameter.ROC_SCORE_POINTS_PARAMETER)+"");
        }
        if(pars.containsKey(MetricParameter.RELIABILITY_POINTS_PARAMETER)) {
            setOptionEnabled(MetricParameter.RELIABILITY_POINTS_PARAMETER,true);
            pointField.setText(pars.get(MetricParameter.RELIABILITY_POINTS_PARAMETER)+"");
        }
        if(pars.containsKey(MetricParameter.SPREAD_BIAS_POINTS_PARAMETER)) {
            setOptionEnabled(MetricParameter.SPREAD_BIAS_POINTS_PARAMETER,true);
            pointField.setText(pars.get(MetricParameter.SPREAD_BIAS_POINTS_PARAMETER)+"");
        }
        if(pars.containsKey(MetricParameter.CENTRAL_SPREAD_BIAS_PARAMETER)) {
            setOptionEnabled(MetricParameter.CENTRAL_SPREAD_BIAS_PARAMETER,true);
            centSBCheckBox.setSelected(pars.get(MetricParameter.CENTRAL_SPREAD_BIAS_PARAMETER).equals(true));
        }
        if(pars.containsKey(MetricParameter.RANK_HIST_SAMPLE_PARAMETER)) {
            setOptionEnabled(MetricParameter.RANK_HIST_SAMPLE_PARAMETER,true);
            rankHistCheckBox.setSelected(pars.get(MetricParameter.RANK_HIST_SAMPLE_PARAMETER).equals(true));
        }        
        if(pars.containsKey(MetricParameter.MCR_POINTS_PARAMETER)) {
            setOptionEnabled(MetricParameter.MCR_POINTS_PARAMETER,true);
            pointField.setText(pars.get(MetricParameter.MCR_POINTS_PARAMETER)+"");
        }
        if(pars.containsKey(MetricParameter.MEP_POINTS_PARAMETER)) {
            setOptionEnabled(MetricParameter.MEP_POINTS_PARAMETER,true);
            pointField.setText(pars.get(MetricParameter.MEP_POINTS_PARAMETER)+"");
        }
        if(pars.containsKey(MetricParameter.BOX_POOLED_LEAD_POINTS_PARAMETER)) {
            setOptionEnabled(MetricParameter.BOX_POOLED_LEAD_POINTS_PARAMETER,true);
            pointField.setText(pars.get(MetricParameter.BOX_POOLED_LEAD_POINTS_PARAMETER)+"");
        }
        if(pars.containsKey(MetricParameter.BOX_UNPOOLED_OBS_POINTS_PARAMETER)) {
            setOptionEnabled(MetricParameter.BOX_UNPOOLED_OBS_POINTS_PARAMETER,true);
            pointField.setText(pars.get(MetricParameter.BOX_UNPOOLED_OBS_POINTS_PARAMETER)+"");
        }
        if(pars.containsKey(MetricParameter.BOX_UNPOOLED_POINTS_PARAMETER)) {
            setOptionEnabled(MetricParameter.BOX_UNPOOLED_POINTS_PARAMETER,true);
            pointField.setText(pars.get(MetricParameter.BOX_UNPOOLED_POINTS_PARAMETER)+"");
        }
        if(pars.containsKey(MetricParameter.UNCONDITIONAL_PARAMETER)) {
            setOptionEnabled(MetricParameter.UNCONDITIONAL_PARAMETER,true);
            uncCheckBox.setSelected(pars.get(MetricParameter.UNCONDITIONAL_PARAMETER).equals(true));
        }
        if(pars.containsKey(MetricParameter.EQUAL_SAMPLES_PARAMETER)) {
            setOptionEnabled(MetricParameter.EQUAL_SAMPLES_PARAMETER,true);
            equalCheckBox.setSelected(pars.get(MetricParameter.EQUAL_SAMPLES_PARAMETER).equals(true));
        }
        if(pars.containsKey(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER)) {
            setOptionEnabled(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER,true);
            probCheckBox.setSelected(pars.get(MetricParameter.PROBABILITY_IDENTIFIER_PARAMETER).equals(true));
        }
        if(pars.containsKey(MetricParameter.INTEGER_PARAMETER)) { //The locally stored type
            setOptionEnabled(MetricParameter.DOUBLE_PROCEDURE_PARAMETER,true);  //The actual parameter type
            int index = getLogIndex(new Integer(pars.get(MetricParameter.INTEGER_PARAMETER)+""));
            if(index > -1) {
                logBox.setSelectedIndex(index);
            }
        }
        if(pars.containsKey(MetricParameter.VECTOR_FUNCTION_PARAMETER)) {
            setOptionEnabled(MetricParameter.VECTOR_FUNCTION_PARAMETER,true);
            statBox.setSelectedItem(pars.get(MetricParameter.VECTOR_FUNCTION_PARAMETER));
        }
        //Copy all parameters, then replace mutable ones modified here
        this.pars.putAll(pars);
        //Mutable parameters follow
        if(pars.containsKey(MetricParameter.DECOMPOSE_PARAMETER)) {
            if(allowDecomp) {
                setOptionEnabled(MetricParameter.DECOMPOSE_PARAMETER,true);
                DisplayScoreDecompPar s = (DisplayScoreDecompPar)pars.get(MetricParameter.DECOMPOSE_PARAMETER);
                DisplayScoreDecompPar sCopy = new DisplayScoreDecompPar(((DecomposableScore)m).getDecompositionOptions(),
                        s.getDecomposePar().getScoreDecType());
                scoreDecBox.setModel(sCopy);
                this.pars.put(MetricParameter.DECOMPOSE_PARAMETER,sCopy);
            }
        }
        if(pars.containsKey(MetricParameter.REFERENCE_FORECAST_PARAMETER)) {
            setOptionEnabled(MetricParameter.REFERENCE_FORECAST_PARAMETER,true);
            DisplayReferencePar s = (DisplayReferencePar)pars.get(MetricParameter.REFERENCE_FORECAST_PARAMETER);
            DefaultComboBoxModel mod = new DefaultComboBoxModel();
            String[] in = s.getRefFcsts();
            String[] inCopy = new String[in.length];
            System.arraycopy(in,0,inCopy,0,in.length);
            DisplayReferencePar sCopy = new DisplayReferencePar(inCopy);
            for(int i = 0; i < in.length; i++) {
                mod.addElement(in[i]);
            }
            ((SearchableComboBox)refBox).setModel(mod);
            mod.setSelectedItem(s.toString());
            refBox.setSelectedItem(s);
            this.pars.put(MetricParameter.REFERENCE_FORECAST_PARAMETER,sCopy);
        }
        //Set the bootstrap parameter for a bootstrap metric
        if (pars.containsKey(MetricParameter.BOOTSTRAP_PARAMETER)) {
            if (!bootstrapable) {
                throw new IllegalArgumentException("Cannot add a bootstrap parameter to a parameter "
                        + "window that was constructed for a non-bootstrap metric.");
            }
            BootstrapParameter copy = (BootstrapParameter)((MetricParameter)pars.get(
                    MetricParameter.BOOTSTRAP_PARAMETER)).deepCopy();
            this.pars.put(MetricParameter.BOOTSTRAP_PARAMETER,copy);
            //Update the parameter display: only two options at present, namely "None" and SBB
            if(copy.isBootstrap()) {
                sampleField.setText(copy.getSampleCount()+"");
                minSampleField.setText(copy.getMinSampleCount()+"");
                blockSizeField.setText(copy.getNominalBlockSize()+"");
                blockUnitBox.setSelectedItem(copy.getNominalBlockSizeUnits());
                //Add intervals to the table
                DefaultTableModel iMod = (DefaultTableModel)intervalTable.getModel();
                iMod.setRowCount(0);
                ProbabilityIntervalParameter[] ints = copy.getIntervals();
                ProbabilityIntervalParameter main = copy.getMainInterval();
                for(ProbabilityIntervalParameter n : ints) {
                    iMod.addRow(new Object[]{n.getLower(),n.getUpper(),n.equals(main)});
                }
                techniqueBox.setSelectedIndex(1);
            } else {
                techniqueBox.setSelectedIndex(0);
            }
            setOptionEnabled(MetricParameter.BOOTSTRAP_PARAMETER,copy.isBootstrap());
        }
    }

    /**
     * Returns the index in the logical conditions box corresponding to the logical condition
     * type, or -1.
     *
     * @return the logical index
     */

    private int getLogIndex(int type) {
        int nullIndex = -1;
        int length = logBox.getItemCount();
        for(int i = 0; i < length; i++) {
            if(((DisplayLogicPar)logBox.getItemAt(i)).getID()==type) {
                return i;
            }
        }
        return nullIndex;
    }
    
    /**
     * Returns the index in the AUC methods box corresponding to the AUC method
     * or -1.
     *
     * @return the method index
     */

    private int getAUCIndex(int type) {
        int nullIndex = -1;
        int length = aucBox.getItemCount();
        for(int i = 0; i < length; i++) {
            if(((DisplayAUCMethodPar)aucBox.getItemAt(i)).getID()==type) {
                return i;
            }
        }
        return nullIndex;
    }    

    /**
     * Initializes the window components.
     */
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainTabbedPane = new javax.swing.JTabbedPane();
        mainPanel = new javax.swing.JPanel();
        jPanel511 = new javax.swing.JPanel();
        mainOptionsPanel = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel16 = new javax.swing.JPanel();
        uncCheckBox = new javax.swing.JCheckBox();
        equalCheckBox = new javax.swing.JCheckBox();
        rankHistCheckBox = new javax.swing.JCheckBox();
        probCheckBox = new javax.swing.JCheckBox();
        centSBCheckBox = new javax.swing.JCheckBox();
        fittedROCBox = new javax.swing.JCheckBox();
        boxPanel = new javax.swing.JPanel();
        leftBox = new javax.swing.JPanel();
        statLabel = new javax.swing.JLabel();
        statPanel = new javax.swing.JPanel();
        statBox = new javax.swing.JComboBox();
        logLabel = new javax.swing.JLabel();
        logPanel = new javax.swing.JPanel();
        logBox = new javax.swing.JComboBox();
        scoreDecLabel = new javax.swing.JLabel();
        scoreDecPanel = new javax.swing.JPanel();
        scoreDecBox = new javax.swing.JComboBox();
        rightBox = new javax.swing.JPanel();
        refLabel = new javax.swing.JLabel();
        refPanel = new javax.swing.JPanel();
        refBox = new SearchableComboBox();
        pointLabel = new javax.swing.JLabel();
        pointPanel = new javax.swing.JPanel();
        pointField = new javax.swing.JTextField();
        aucMethodLabel = new javax.swing.JLabel();
        aucPanel = new javax.swing.JPanel();
        aucBox = new javax.swing.JComboBox();
        jPanel4 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        cancelButton1 = new javax.swing.JButton();
        nextSpacerPanel = new javax.swing.JPanel();
        nextButton = new javax.swing.JButton();
        jPanel141212 = new javax.swing.JPanel();
        okButton1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        intervalPanel = new javax.swing.JPanel();
        jPanel512 = new javax.swing.JPanel();
        conditionsPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel14 = new javax.swing.JPanel();
        techniqueLabel = new javax.swing.JLabel();
        techniquePanel = new javax.swing.JPanel();
        techniqueBox = new javax.swing.JComboBox();
        sampleLabelPanel = new javax.swing.JPanel();
        sampleLabel = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        minSampleLabel = new javax.swing.JLabel();
        samplePanel = new javax.swing.JPanel();
        sampleField = new javax.swing.JTextField();
        jPanel9 = new javax.swing.JPanel();
        minSampleField = new javax.swing.JTextField();
        blockLabelPanel = new javax.swing.JPanel();
        blockSizeLabel = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        blockUnitLabel = new javax.swing.JLabel();
        blockPanel = new javax.swing.JPanel();
        blockSizeField = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        blockUnitBox = new javax.swing.JComboBox();
        intervalLabel = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        intervalInputPanel = new javax.swing.JPanel();
        intervalTableScrollPane = new javax.swing.JScrollPane();
        intervalTable = new javax.swing.JTable();
        intervalButtonMenu = new javax.swing.JPanel();
        addButton = new javax.swing.JButton();
        jPanel1413 = new javax.swing.JPanel();
        deleteButton = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jPanel43 = new javax.swing.JPanel();
        jPanel53 = new javax.swing.JPanel();
        jPanel45 = new javax.swing.JPanel();
        jPanel202 = new javax.swing.JPanel();
        cancelButton2 = new javax.swing.JButton();
        jPanel14124 = new javax.swing.JPanel();
        backButton = new javax.swing.JButton();
        jPanel141214 = new javax.swing.JPanel();
        okButton2 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();

        setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        setMinimumSize(new java.awt.Dimension(400, 275));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                closeDialog(evt);
            }
        });
        getContentPane().setLayout(new java.awt.GridLayout(1, 0));

        mainTabbedPane.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        mainTabbedPane.setMaximumSize(new java.awt.Dimension(750, 500));
        mainTabbedPane.setMinimumSize(new java.awt.Dimension(0, 0));
        mainTabbedPane.setPreferredSize(new java.awt.Dimension(750, 500));

        mainPanel.setMaximumSize(new java.awt.Dimension(2147483647, 2147483647));
        mainPanel.setMinimumSize(new java.awt.Dimension(500, 60));
        mainPanel.setPreferredSize(new java.awt.Dimension(500, 65));
        mainPanel.setLayout(new javax.swing.BoxLayout(mainPanel, javax.swing.BoxLayout.Y_AXIS));

        jPanel511.setMaximumSize(new java.awt.Dimension(32000, 5));
        jPanel511.setMinimumSize(new java.awt.Dimension(500, 5));
        jPanel511.setPreferredSize(new java.awt.Dimension(500, 5));
        mainPanel.add(jPanel511);

        mainOptionsPanel.setMaximumSize(new java.awt.Dimension(32779, 32794));
        mainOptionsPanel.setMinimumSize(new java.awt.Dimension(100, 47));
        mainOptionsPanel.setPreferredSize(new java.awt.Dimension(60, 34));
        mainOptionsPanel.setLayout(new javax.swing.BoxLayout(mainOptionsPanel, javax.swing.BoxLayout.LINE_AXIS));

        jScrollPane2.setBorder(null);

        jPanel16.setMaximumSize(new java.awt.Dimension(1000, 1000));
        jPanel16.setMinimumSize(new java.awt.Dimension(0, 0));
        jPanel16.setPreferredSize(new java.awt.Dimension(600, 380));
        jPanel16.setLayout(new javax.swing.BoxLayout(jPanel16, javax.swing.BoxLayout.Y_AXIS));

        uncCheckBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        uncCheckBox.setText("Ignore all conditions on variable values of this metric");
        uncCheckBox.setAlignmentX(0.5F);
        uncCheckBox.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        uncCheckBox.setMargin(new java.awt.Insets(0, 0, 0, 0));
        uncCheckBox.setMaximumSize(new java.awt.Dimension(32000, 30));
        uncCheckBox.setMinimumSize(new java.awt.Dimension(220, 30));
        uncCheckBox.setPreferredSize(new java.awt.Dimension(220, 30));
        jPanel16.add(uncCheckBox);

        equalCheckBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        equalCheckBox.setText("Use a constant sample count in each bin");
        equalCheckBox.setAlignmentX(0.5F);
        equalCheckBox.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        equalCheckBox.setMargin(new java.awt.Insets(0, 0, 0, 0));
        equalCheckBox.setMaximumSize(new java.awt.Dimension(32000, 30));
        equalCheckBox.setMinimumSize(new java.awt.Dimension(220, 30));
        equalCheckBox.setPreferredSize(new java.awt.Dimension(220, 30));
        jPanel16.add(equalCheckBox);

        rankHistCheckBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        rankHistCheckBox.setText("Use relative frequencies (uncheck for absolute sample counts)");
        rankHistCheckBox.setAlignmentX(0.5F);
        rankHistCheckBox.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        rankHistCheckBox.setMargin(new java.awt.Insets(0, 0, 0, 0));
        rankHistCheckBox.setMaximumSize(new java.awt.Dimension(32000, 30));
        rankHistCheckBox.setMinimumSize(new java.awt.Dimension(220, 30));
        rankHistCheckBox.setPreferredSize(new java.awt.Dimension(220, 30));
        jPanel16.add(rankHistCheckBox);

        probCheckBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        probCheckBox.setText("Threshold values are non-exceedence climatological probabilities");
        probCheckBox.setAlignmentX(0.5F);
        probCheckBox.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        probCheckBox.setMargin(new java.awt.Insets(0, 0, 0, 0));
        probCheckBox.setMaximumSize(new java.awt.Dimension(32000, 30));
        probCheckBox.setMinimumSize(new java.awt.Dimension(220, 30));
        probCheckBox.setPreferredSize(new java.awt.Dimension(220, 30));
        jPanel16.add(probCheckBox);

        centSBCheckBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        centSBCheckBox.setText("Center windows around forecast median");
        centSBCheckBox.setAlignmentX(0.5F);
        centSBCheckBox.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        centSBCheckBox.setMargin(new java.awt.Insets(0, 0, 0, 0));
        centSBCheckBox.setMaximumSize(new java.awt.Dimension(32000, 30));
        centSBCheckBox.setMinimumSize(new java.awt.Dimension(220, 30));
        centSBCheckBox.setPreferredSize(new java.awt.Dimension(220, 30));
        jPanel16.add(centSBCheckBox);

        fittedROCBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        fittedROCBox.setText("Fit a smooth function to empirical ROC");
        fittedROCBox.setAlignmentX(0.5F);
        fittedROCBox.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        fittedROCBox.setMargin(new java.awt.Insets(0, 0, 0, 0));
        fittedROCBox.setMaximumSize(new java.awt.Dimension(32000, 30));
        fittedROCBox.setMinimumSize(new java.awt.Dimension(220, 30));
        fittedROCBox.setPreferredSize(new java.awt.Dimension(220, 30));
        jPanel16.add(fittedROCBox);

        boxPanel.setLayout(new javax.swing.BoxLayout(boxPanel, javax.swing.BoxLayout.LINE_AXIS));

        leftBox.setPreferredSize(new java.awt.Dimension(500, 50));
        leftBox.setLayout(new javax.swing.BoxLayout(leftBox, javax.swing.BoxLayout.Y_AXIS));

        statLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        statLabel.setText("Average of ensemble members:");
        statLabel.setAlignmentX(0.5F);
        statLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        statLabel.setMaximumSize(new java.awt.Dimension(32000, 30));
        statLabel.setMinimumSize(new java.awt.Dimension(275, 30));
        statLabel.setPreferredSize(new java.awt.Dimension(275, 30));
        leftBox.add(statLabel);

        statPanel.setMaximumSize(new java.awt.Dimension(32000, 30));
        statPanel.setMinimumSize(new java.awt.Dimension(275, 30));
        statPanel.setPreferredSize(new java.awt.Dimension(275, 30));
        statPanel.setLayout(new javax.swing.BoxLayout(statPanel, javax.swing.BoxLayout.LINE_AXIS));

        statBox.setBackground(java.awt.Color.WHITE);
        statBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        statBox.setMaximumSize(new java.awt.Dimension(250, 32767));
        statBox.setMinimumSize(new java.awt.Dimension(250, 30));
        statBox.setPreferredSize(new java.awt.Dimension(250, 30));
        statBox.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                statBoxPopupMenuWillBecomeVisible(evt);
            }
        });
        statPanel.add(statBox);

        leftBox.add(statPanel);

        logLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        logLabel.setText("Logical condition for event threshold:");
        logLabel.setAlignmentX(0.5F);
        logLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        logLabel.setMaximumSize(new java.awt.Dimension(32000, 30));
        logLabel.setMinimumSize(new java.awt.Dimension(275, 30));
        logLabel.setPreferredSize(new java.awt.Dimension(275, 30));
        leftBox.add(logLabel);

        logPanel.setMaximumSize(new java.awt.Dimension(32000, 30));
        logPanel.setMinimumSize(new java.awt.Dimension(275, 30));
        logPanel.setPreferredSize(new java.awt.Dimension(275, 30));
        logPanel.setLayout(new javax.swing.BoxLayout(logPanel, javax.swing.BoxLayout.LINE_AXIS));

        logBox.setBackground(java.awt.Color.WHITE);
        logBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        logBox.setMaximumSize(new java.awt.Dimension(250, 32767));
        logBox.setMinimumSize(new java.awt.Dimension(250, 30));
        logBox.setPreferredSize(new java.awt.Dimension(250, 30));
        logBox.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                logBoxPopupMenuWillBecomeVisible(evt);
            }
        });
        logPanel.add(logBox);

        leftBox.add(logPanel);

        scoreDecLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        scoreDecLabel.setText("Select score decomposition:");
        scoreDecLabel.setAlignmentX(0.5F);
        scoreDecLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        scoreDecLabel.setMaximumSize(new java.awt.Dimension(32000, 30));
        scoreDecLabel.setMinimumSize(new java.awt.Dimension(275, 30));
        scoreDecLabel.setPreferredSize(new java.awt.Dimension(275, 30));
        leftBox.add(scoreDecLabel);

        scoreDecPanel.setMaximumSize(new java.awt.Dimension(32000, 30));
        scoreDecPanel.setMinimumSize(new java.awt.Dimension(275, 30));
        scoreDecPanel.setPreferredSize(new java.awt.Dimension(275, 30));
        scoreDecPanel.setLayout(new javax.swing.BoxLayout(scoreDecPanel, javax.swing.BoxLayout.LINE_AXIS));

        scoreDecBox.setBackground(java.awt.Color.WHITE);
        scoreDecBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        scoreDecBox.setMaximumSize(new java.awt.Dimension(250, 32767));
        scoreDecBox.setMinimumSize(new java.awt.Dimension(250, 30));
        scoreDecBox.setPreferredSize(new java.awt.Dimension(250, 30));
        scoreDecBox.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                scoreDecBoxPopupMenuWillBecomeVisible(evt);
            }
        });
        scoreDecPanel.add(scoreDecBox);

        leftBox.add(scoreDecPanel);

        boxPanel.add(leftBox);

        rightBox.setMaximumSize(new java.awt.Dimension(32000, 180));
        rightBox.setMinimumSize(new java.awt.Dimension(250, 180));
        rightBox.setPreferredSize(new java.awt.Dimension(1750, 50));
        rightBox.setLayout(new javax.swing.BoxLayout(rightBox, javax.swing.BoxLayout.Y_AXIS));

        refLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        refLabel.setText("Reference forecast for skill:");
        refLabel.setAlignmentX(0.5F);
        refLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        refLabel.setMaximumSize(new java.awt.Dimension(32000, 30));
        refLabel.setMinimumSize(new java.awt.Dimension(220, 30));
        refLabel.setPreferredSize(new java.awt.Dimension(220, 30));
        rightBox.add(refLabel);

        refPanel.setMaximumSize(new java.awt.Dimension(32000, 30));
        refPanel.setLayout(new javax.swing.BoxLayout(refPanel, javax.swing.BoxLayout.LINE_AXIS));

        refBox.setBackground(java.awt.Color.WHITE);
        refBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        refBox.setMaximumSize(new java.awt.Dimension(250, 32767));
        refBox.setMinimumSize(new java.awt.Dimension(250, 30));
        refBox.setPreferredSize(new java.awt.Dimension(250, 30));
        refBox.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                refBoxPopupMenuWillBecomeVisible(evt);
            }
        });
        refPanel.add(refBox);

        rightBox.add(refPanel);

        pointLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        pointLabel.setText("Number of points in diagram:");
        pointLabel.setAlignmentX(0.5F);
        pointLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        pointLabel.setMaximumSize(new java.awt.Dimension(32000, 30));
        pointLabel.setMinimumSize(new java.awt.Dimension(220, 30));
        pointLabel.setPreferredSize(new java.awt.Dimension(220, 30));
        rightBox.add(pointLabel);

        pointPanel.setMaximumSize(new java.awt.Dimension(32000, 30));
        pointPanel.setLayout(new javax.swing.BoxLayout(pointPanel, javax.swing.BoxLayout.LINE_AXIS));

        pointField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        pointField.setMargin(new java.awt.Insets(0, 0, 0, 0));
        pointField.setMaximumSize(new java.awt.Dimension(250, 32767));
        pointField.setMinimumSize(new java.awt.Dimension(250, 30));
        pointField.setPreferredSize(new java.awt.Dimension(250, 30));
        pointPanel.add(pointField);

        rightBox.add(pointPanel);

        aucMethodLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        aucMethodLabel.setText("Method for computing AUC:");
        aucMethodLabel.setAlignmentX(0.5F);
        aucMethodLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        aucMethodLabel.setMaximumSize(new java.awt.Dimension(32000, 30));
        aucMethodLabel.setMinimumSize(new java.awt.Dimension(220, 30));
        aucMethodLabel.setPreferredSize(new java.awt.Dimension(220, 30));
        rightBox.add(aucMethodLabel);

        aucPanel.setMaximumSize(new java.awt.Dimension(32000, 30));
        aucPanel.setLayout(new javax.swing.BoxLayout(aucPanel, javax.swing.BoxLayout.LINE_AXIS));

        aucBox.setBackground(java.awt.Color.WHITE);
        aucBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        aucBox.setMaximumSize(new java.awt.Dimension(250, 32767));
        aucBox.setMinimumSize(new java.awt.Dimension(250, 30));
        aucBox.setPreferredSize(new java.awt.Dimension(250, 30));
        aucBox.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                aucBoxPopupMenuWillBecomeVisible(evt);
            }
        });
        aucPanel.add(aucBox);

        rightBox.add(aucPanel);

        boxPanel.add(rightBox);

        jPanel4.setMaximumSize(new java.awt.Dimension(100000, 180));
        jPanel4.setMinimumSize(new java.awt.Dimension(100000, 180));
        jPanel4.setPreferredSize(new java.awt.Dimension(100000, 180));

        org.jdesktop.layout.GroupLayout jPanel4Layout = new org.jdesktop.layout.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 100000, 100000)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 180, Short.MAX_VALUE)
        );

        boxPanel.add(jPanel4);

        jPanel16.add(boxPanel);

        jScrollPane2.setViewportView(jPanel16);

        mainOptionsPanel.add(jScrollPane2);

        mainPanel.add(mainOptionsPanel);

        jPanel13.setMaximumSize(new java.awt.Dimension(65676, 35));
        jPanel13.setMinimumSize(new java.awt.Dimension(150, 30));
        jPanel13.setPreferredSize(new java.awt.Dimension(300, 35));
        jPanel13.setLayout(new javax.swing.BoxLayout(jPanel13, javax.swing.BoxLayout.Y_AXIS));

        jPanel1.setMaximumSize(new java.awt.Dimension(32000, 2));
        jPanel1.setMinimumSize(new java.awt.Dimension(500, 2));
        jPanel1.setPreferredSize(new java.awt.Dimension(500, 2));
        jPanel13.add(jPanel1);

        jPanel15.setMaximumSize(new java.awt.Dimension(32899, 35));
        jPanel15.setMinimumSize(new java.awt.Dimension(142, 30));
        jPanel15.setPreferredSize(new java.awt.Dimension(144, 35));
        jPanel15.setLayout(new javax.swing.BoxLayout(jPanel15, javax.swing.BoxLayout.LINE_AXIS));

        jPanel20.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel15.add(jPanel20);

        cancelButton1.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        cancelButton1.setText("Cancel");
        cancelButton1.setMargin(new java.awt.Insets(2, 10, 2, 10));
        cancelButton1.setMaximumSize(new java.awt.Dimension(65, 29));
        cancelButton1.setMinimumSize(new java.awt.Dimension(65, 29));
        cancelButton1.setPreferredSize(new java.awt.Dimension(65, 29));
        cancelButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButton1ActionPerformed(evt);
            }
        });
        jPanel15.add(cancelButton1);

        nextSpacerPanel.setMaximumSize(new java.awt.Dimension(2, 32767));
        nextSpacerPanel.setMinimumSize(new java.awt.Dimension(2, 10));
        nextSpacerPanel.setPreferredSize(new java.awt.Dimension(4, 10));

        if(bootstrapable) {

            jPanel15.add(nextSpacerPanel);
        }

        nextButton.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        nextButton.setText("Next");
        nextButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        nextButton.setMaximumSize(new java.awt.Dimension(65, 29));
        nextButton.setMinimumSize(new java.awt.Dimension(65, 29));
        nextButton.setPreferredSize(new java.awt.Dimension(65, 29));
        nextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextButtonActionPerformed(evt);
            }
        });
        if(bootstrapable) {
            jPanel15.add(nextButton);
        }

        jPanel141212.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel141212.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel141212.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel15.add(jPanel141212);

        okButton1.setFont(new java.awt.Font("Dialog", 1, 11)); // NOI18N
        okButton1.setText("OK");
        okButton1.setMargin(new java.awt.Insets(2, 10, 2, 10));
        okButton1.setMaximumSize(new java.awt.Dimension(65, 29));
        okButton1.setMinimumSize(new java.awt.Dimension(65, 29));
        okButton1.setPreferredSize(new java.awt.Dimension(65, 29));
        okButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okButton1ActionPerformed(evt);
            }
        });
        jPanel15.add(okButton1);

        jPanel2.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel2.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel2.setPreferredSize(new java.awt.Dimension(2, 10));
        jPanel15.add(jPanel2);

        jPanel13.add(jPanel15);

        mainPanel.add(jPanel13);

        mainTabbedPane.addTab("Main options           ", mainPanel);

        intervalPanel.setMinimumSize(new java.awt.Dimension(500, 65));
        intervalPanel.setPreferredSize(new java.awt.Dimension(500, 60));
        intervalPanel.setLayout(new javax.swing.BoxLayout(intervalPanel, javax.swing.BoxLayout.Y_AXIS));

        jPanel512.setMaximumSize(new java.awt.Dimension(32000, 5));
        jPanel512.setMinimumSize(new java.awt.Dimension(500, 5));
        jPanel512.setPreferredSize(new java.awt.Dimension(500, 5));
        intervalPanel.add(jPanel512);

        conditionsPanel.setMaximumSize(new java.awt.Dimension(32779, 32794));
        conditionsPanel.setMinimumSize(new java.awt.Dimension(100, 47));
        conditionsPanel.setPreferredSize(new java.awt.Dimension(60, 34));
        conditionsPanel.setLayout(new javax.swing.BoxLayout(conditionsPanel, javax.swing.BoxLayout.LINE_AXIS));

        jScrollPane1.setBorder(null);
        jScrollPane1.setPreferredSize(new java.awt.Dimension(1000, 265));

        jPanel14.setMaximumSize(new java.awt.Dimension(1000, 100));
        jPanel14.setMinimumSize(new java.awt.Dimension(0, 0));
        jPanel14.setPreferredSize(new java.awt.Dimension(600, 380));
        jPanel14.setLayout(new javax.swing.BoxLayout(jPanel14, javax.swing.BoxLayout.Y_AXIS));

        techniqueLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        techniqueLabel.setText("Technique:");
        techniqueLabel.setAlignmentX(0.5F);
        techniqueLabel.setMaximumSize(new java.awt.Dimension(32000, 25));
        techniqueLabel.setMinimumSize(new java.awt.Dimension(120, 25));
        techniqueLabel.setPreferredSize(new java.awt.Dimension(175, 25));
        jPanel14.add(techniqueLabel);

        techniquePanel.setMaximumSize(new java.awt.Dimension(32000, 30));
        techniquePanel.setLayout(new javax.swing.BoxLayout(techniquePanel, javax.swing.BoxLayout.LINE_AXIS));

        techniqueBox.setBackground(java.awt.Color.WHITE);
        techniqueBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        techniqueBox.setMaximumSize(new java.awt.Dimension(250, 32767));
        techniqueBox.setMinimumSize(new java.awt.Dimension(250, 30));
        techniqueBox.setPreferredSize(new java.awt.Dimension(250, 30));
        techniqueBox.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                techniqueBoxPopupMenuWillBecomeVisible(evt);
            }
        });
        techniquePanel.add(techniqueBox);

        jPanel14.add(techniquePanel);

        sampleLabelPanel.setMaximumSize(new java.awt.Dimension(32000, 30));
        sampleLabelPanel.setLayout(new javax.swing.BoxLayout(sampleLabelPanel, javax.swing.BoxLayout.LINE_AXIS));

        sampleLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        sampleLabel.setText("Sample size:");
        sampleLabel.setAlignmentX(0.5F);
        sampleLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        sampleLabel.setMaximumSize(new java.awt.Dimension(250, 30));
        sampleLabel.setMinimumSize(new java.awt.Dimension(250, 30));
        sampleLabel.setPreferredSize(new java.awt.Dimension(250, 30));
        sampleLabelPanel.add(sampleLabel);

        jPanel7.setMaximumSize(new java.awt.Dimension(20, 32767));
        jPanel7.setMinimumSize(new java.awt.Dimension(20, 10));
        jPanel7.setPreferredSize(new java.awt.Dimension(20, 10));
        sampleLabelPanel.add(jPanel7);

        minSampleLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        minSampleLabel.setText("Minimum sample size:");
        minSampleLabel.setAlignmentX(0.5F);
        minSampleLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        minSampleLabel.setMaximumSize(new java.awt.Dimension(250, 30));
        minSampleLabel.setMinimumSize(new java.awt.Dimension(250, 30));
        minSampleLabel.setPreferredSize(new java.awt.Dimension(250, 30));
        sampleLabelPanel.add(minSampleLabel);

        jPanel14.add(sampleLabelPanel);

        samplePanel.setMaximumSize(new java.awt.Dimension(32000, 30));
        samplePanel.setLayout(new javax.swing.BoxLayout(samplePanel, javax.swing.BoxLayout.LINE_AXIS));

        sampleField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        sampleField.setMargin(new java.awt.Insets(0, 0, 0, 0));
        sampleField.setMaximumSize(new java.awt.Dimension(250, 32767));
        sampleField.setMinimumSize(new java.awt.Dimension(250, 30));
        sampleField.setPreferredSize(new java.awt.Dimension(250, 30));
        samplePanel.add(sampleField);

        jPanel9.setMaximumSize(new java.awt.Dimension(20, 32767));
        jPanel9.setMinimumSize(new java.awt.Dimension(20, 10));
        jPanel9.setPreferredSize(new java.awt.Dimension(20, 10));
        samplePanel.add(jPanel9);

        minSampleField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        minSampleField.setMargin(new java.awt.Insets(0, 0, 0, 0));
        minSampleField.setMaximumSize(new java.awt.Dimension(250, 32767));
        minSampleField.setMinimumSize(new java.awt.Dimension(250, 30));
        minSampleField.setPreferredSize(new java.awt.Dimension(250, 30));
        samplePanel.add(minSampleField);

        jPanel14.add(samplePanel);

        blockLabelPanel.setMaximumSize(new java.awt.Dimension(32000, 30));
        blockLabelPanel.setLayout(new javax.swing.BoxLayout(blockLabelPanel, javax.swing.BoxLayout.LINE_AXIS));

        blockSizeLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        blockSizeLabel.setText("Average block size:");
        blockSizeLabel.setAlignmentX(0.5F);
        blockSizeLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        blockSizeLabel.setMaximumSize(new java.awt.Dimension(250, 30));
        blockSizeLabel.setMinimumSize(new java.awt.Dimension(250, 30));
        blockSizeLabel.setPreferredSize(new java.awt.Dimension(250, 30));
        blockLabelPanel.add(blockSizeLabel);

        jPanel5.setMaximumSize(new java.awt.Dimension(20, 32767));
        jPanel5.setMinimumSize(new java.awt.Dimension(20, 10));
        jPanel5.setPreferredSize(new java.awt.Dimension(20, 10));
        blockLabelPanel.add(jPanel5);

        blockUnitLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        blockUnitLabel.setText("Units for block size:");
        blockUnitLabel.setAlignmentX(0.5F);
        blockUnitLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        blockUnitLabel.setMaximumSize(new java.awt.Dimension(250, 30));
        blockUnitLabel.setMinimumSize(new java.awt.Dimension(250, 30));
        blockUnitLabel.setPreferredSize(new java.awt.Dimension(250, 30));
        blockLabelPanel.add(blockUnitLabel);

        jPanel14.add(blockLabelPanel);

        blockPanel.setMaximumSize(new java.awt.Dimension(32767, 30));
        blockPanel.setMinimumSize(new java.awt.Dimension(0, 30));
        blockPanel.setPreferredSize(new java.awt.Dimension(0, 30));
        blockPanel.setLayout(new javax.swing.BoxLayout(blockPanel, javax.swing.BoxLayout.LINE_AXIS));

        blockSizeField.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        blockSizeField.setMargin(new java.awt.Insets(0, 0, 0, 0));
        blockSizeField.setMaximumSize(new java.awt.Dimension(250, 32767));
        blockSizeField.setMinimumSize(new java.awt.Dimension(250, 30));
        blockSizeField.setPreferredSize(new java.awt.Dimension(250, 30));
        blockPanel.add(blockSizeField);

        jPanel6.setMaximumSize(new java.awt.Dimension(20, 32767));
        jPanel6.setMinimumSize(new java.awt.Dimension(20, 10));
        jPanel6.setPreferredSize(new java.awt.Dimension(20, 10));
        blockPanel.add(jPanel6);

        blockUnitBox.setBackground(java.awt.Color.WHITE);
        blockUnitBox.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        blockUnitBox.setMaximumSize(new java.awt.Dimension(250, 32767));
        blockUnitBox.setMinimumSize(new java.awt.Dimension(250, 30));
        blockUnitBox.setPreferredSize(new java.awt.Dimension(250, 30));
        blockUnitBox.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                blockUnitBoxPopupMenuWillBecomeVisible(evt);
            }
        });
        blockPanel.add(blockUnitBox);

        jPanel14.add(blockPanel);

        intervalLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        intervalLabel.setText("Interval specification:");
        intervalLabel.setAlignmentX(0.5F);
        intervalLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 0, 0, 0));
        intervalLabel.setMaximumSize(new java.awt.Dimension(32000, 30));
        intervalLabel.setMinimumSize(new java.awt.Dimension(220, 30));
        intervalLabel.setPreferredSize(new java.awt.Dimension(220, 30));
        jPanel14.add(intervalLabel);

        jPanel8.setLayout(new javax.swing.BoxLayout(jPanel8, javax.swing.BoxLayout.X_AXIS));

        intervalInputPanel.setMaximumSize(new java.awt.Dimension(32000, 97534));
        intervalInputPanel.setMinimumSize(new java.awt.Dimension(395, 0));
        intervalInputPanel.setPreferredSize(new java.awt.Dimension(395, 4040));
        intervalInputPanel.setLayout(new javax.swing.BoxLayout(intervalInputPanel, javax.swing.BoxLayout.Y_AXIS));

        intervalTableScrollPane.setEnabled(false);
        intervalTableScrollPane.setMaximumSize(new java.awt.Dimension(395, 32767));
        intervalTableScrollPane.setMinimumSize(new java.awt.Dimension(395, 100));
        intervalTableScrollPane.setPreferredSize(new java.awt.Dimension(395, 35000));

        intervalTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {},new String [] {"Lower", "Upper", "Main?"}) {

            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Boolean.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            @Override
            public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
                if(columnIndex==2) {
                    if(Boolean.valueOf(true).equals(aValue)) {
                        int rows = getRowCount();
                        for(int i = 0; i < rows; i++) {
                            if(i!=rowIndex) {
                                super.setValueAt(false,i,2);
                            }
                        }
                        super.setValueAt(true,rowIndex,2);
                    } else {
                        super.setValueAt(false,rowIndex,2);
                    }
                } else {
                    super.setValueAt(aValue,rowIndex,columnIndex);
                }
            }
        });
        intervalTable.setEnabled(false);
        intervalTable.setMaximumSize(new java.awt.Dimension(395, 32000));
        intervalTable.setMinimumSize(new java.awt.Dimension(395, 100));
        intervalTable.setPreferredSize(new java.awt.Dimension(395, 200));
        intervalTableScrollPane.setViewportView(intervalTable);

        intervalInputPanel.add(intervalTableScrollPane);

        intervalButtonMenu.setMaximumSize(new java.awt.Dimension(395, 32000));
        intervalButtonMenu.setMinimumSize(new java.awt.Dimension(395, 60));
        intervalButtonMenu.setPreferredSize(new java.awt.Dimension(395, 60));
        intervalButtonMenu.setLayout(new javax.swing.BoxLayout(intervalButtonMenu, javax.swing.BoxLayout.LINE_AXIS));

        addButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        addButton.setText("Add");
        addButton.setAlignmentY(0.0F);
        addButton.setEnabled(false);
        addButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        addButton.setMaximumSize(new java.awt.Dimension(65, 29));
        addButton.setMinimumSize(new java.awt.Dimension(65, 29));
        addButton.setPreferredSize(new java.awt.Dimension(65, 29));
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });
        intervalButtonMenu.add(addButton);

        jPanel1413.setMaximumSize(new java.awt.Dimension(2, 100));
        jPanel1413.setMinimumSize(new java.awt.Dimension(2, 15));
        jPanel1413.setPreferredSize(new java.awt.Dimension(4, 10));

        org.jdesktop.layout.GroupLayout jPanel1413Layout = new org.jdesktop.layout.GroupLayout(jPanel1413);
        jPanel1413.setLayout(jPanel1413Layout);
        jPanel1413Layout.setHorizontalGroup(
            jPanel1413Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 2, Short.MAX_VALUE)
        );
        jPanel1413Layout.setVerticalGroup(
            jPanel1413Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 60, Short.MAX_VALUE)
        );

        intervalButtonMenu.add(jPanel1413);

        deleteButton.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        deleteButton.setText("Delete");
        deleteButton.setAlignmentY(0.0F);
        deleteButton.setEnabled(false);
        deleteButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        deleteButton.setMaximumSize(new java.awt.Dimension(65, 29));
        deleteButton.setMinimumSize(new java.awt.Dimension(65, 29));
        deleteButton.setPreferredSize(new java.awt.Dimension(65, 29));
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });
        intervalButtonMenu.add(deleteButton);

        intervalInputPanel.add(intervalButtonMenu);

        jPanel8.add(intervalInputPanel);

        jPanel10.setPreferredSize(new java.awt.Dimension(32000, 10));
        jPanel8.add(jPanel10);

        jPanel14.add(jPanel8);

        jScrollPane1.setViewportView(jPanel14);
        jPanel14.getAccessibleContext().setAccessibleName("1. Local condition (applied at each forecast time)");

        conditionsPanel.add(jScrollPane1);

        intervalPanel.add(conditionsPanel);

        jPanel43.setMaximumSize(new java.awt.Dimension(65676, 35));
        jPanel43.setMinimumSize(new java.awt.Dimension(150, 30));
        jPanel43.setPreferredSize(new java.awt.Dimension(300, 35));
        jPanel43.setLayout(new javax.swing.BoxLayout(jPanel43, javax.swing.BoxLayout.Y_AXIS));

        jPanel53.setMaximumSize(new java.awt.Dimension(32000, 2));
        jPanel53.setMinimumSize(new java.awt.Dimension(500, 2));
        jPanel53.setOpaque(false);
        jPanel53.setPreferredSize(new java.awt.Dimension(500, 2));
        jPanel53.setLayout(new javax.swing.BoxLayout(jPanel53, javax.swing.BoxLayout.LINE_AXIS));
        jPanel43.add(jPanel53);

        jPanel45.setMaximumSize(new java.awt.Dimension(32909, 35));
        jPanel45.setMinimumSize(new java.awt.Dimension(152, 30));
        jPanel45.setPreferredSize(new java.awt.Dimension(150, 35));
        jPanel45.setLayout(new javax.swing.BoxLayout(jPanel45, javax.swing.BoxLayout.LINE_AXIS));

        jPanel202.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel45.add(jPanel202);

        cancelButton2.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        cancelButton2.setText("Cancel");
        cancelButton2.setMargin(new java.awt.Insets(2, 10, 2, 10));
        cancelButton2.setMaximumSize(new java.awt.Dimension(65, 29));
        cancelButton2.setMinimumSize(new java.awt.Dimension(65, 29));
        cancelButton2.setPreferredSize(new java.awt.Dimension(65, 29));
        cancelButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButton2ActionPerformed(evt);
            }
        });
        jPanel45.add(cancelButton2);

        jPanel14124.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel14124.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel14124.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel45.add(jPanel14124);

        backButton.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        backButton.setText("Back");
        backButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        backButton.setMaximumSize(new java.awt.Dimension(65, 29));
        backButton.setMinimumSize(new java.awt.Dimension(65, 29));
        backButton.setPreferredSize(new java.awt.Dimension(65, 29));
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });
        jPanel45.add(backButton);

        jPanel141214.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel141214.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel141214.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel45.add(jPanel141214);

        okButton2.setFont(new java.awt.Font("Dialog", 1, 11)); // NOI18N
        okButton2.setText("OK");
        okButton2.setMargin(new java.awt.Insets(2, 10, 2, 10));
        okButton2.setMaximumSize(new java.awt.Dimension(65, 29));
        okButton2.setMinimumSize(new java.awt.Dimension(65, 29));
        okButton2.setPreferredSize(new java.awt.Dimension(65, 29));
        okButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okButton2ActionPerformed(evt);
            }
        });
        jPanel45.add(okButton2);

        jPanel3.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel3.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel3.setPreferredSize(new java.awt.Dimension(2, 10));
        jPanel45.add(jPanel3);

        jPanel43.add(jPanel45);

        intervalPanel.add(jPanel43);

        if(bootstrapable) {
            mainTabbedPane.addTab("Confidence intervals  ", intervalPanel);
        }

        getContentPane().add(mainTabbedPane);
        mainTabbedPane.getAccessibleContext().setAccessibleName("   Main options  ");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Alters the width of the statistic pop-up menu to match the contents.
     *
     * @param evt a pop-up menu event
     */
    
    private void techniqueBoxPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_techniqueBoxPopupMenuWillBecomeVisible
        EVSMainWindow.main.setPopupWidth(evt);
    }//GEN-LAST:event_techniqueBoxPopupMenuWillBecomeVisible
    
    /**
     * Exits the dialog, accepting any changes made.
     *
     * @param evt an action event
     */
    
    private void okButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_okButton1ActionPerformed
        try {
            close();
        }
        catch(Exception e) {
            ExceptionHandler.displayException(e,this);
            e.printStackTrace();
        }
    }//GEN-LAST:event_okButton1ActionPerformed

    /**
     * Cancels the dialog.
     *
     * @param evt an action event
     */
    
    private void cancelButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButton2ActionPerformed
        cancel();
    }//GEN-LAST:event_cancelButton2ActionPerformed
 
    /**
     * Returns to the previous window.
     *
     * @param evt an action event
     */
    
    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        mainTabbedPane.setSelectedIndex((mainTabbedPane.getSelectedIndex())-1);
    }//GEN-LAST:event_backButtonActionPerformed
    
    /**
     * Exits the dialog, accepting any changes made.
     *
     * @param evt an action event
     */
    
    private void okButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_okButton2ActionPerformed
        try {
            close();
        }
        catch(Exception e) {
            ExceptionHandler.displayException(e,this);
            e.printStackTrace();
        }
    }//GEN-LAST:event_okButton2ActionPerformed
    
    /**
     * Cancels the dialog.
     *
     * @param evt an action event
     */
    
    private void cancelButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButton1ActionPerformed
        cancel();
    }//GEN-LAST:event_cancelButton1ActionPerformed
 
    /**
     * Moves to the next window.
     *
     * @param evt an action event
     */
    
    private void nextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextButtonActionPerformed
        mainTabbedPane.setSelectedIndex((mainTabbedPane.getSelectedIndex())+1);
    }//GEN-LAST:event_nextButtonActionPerformed
    
    /**
     * Exits the dialog.
     *
     * @param evt a window event.
     */
    
    private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog

    }//GEN-LAST:event_closeDialog

    /**
     * A menu will appear: re-size the width of the pop-up menu to the largest
     * item.
     *
     * @param evt menu event
     */

    private void blockUnitBoxPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_blockUnitBoxPopupMenuWillBecomeVisible
        EVSMainWindow.main.setPopupWidth(evt);
    }//GEN-LAST:event_blockUnitBoxPopupMenuWillBecomeVisible

    /**
     * Adds a row to the interval table.
     *
     * @param evt the action event
     */

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        int sel = intervalTable.getSelectedRow();
        if(sel > -1) {
            ((DefaultTableModel)intervalTable.getModel()).insertRow(sel+1,new Object[]{"","",Boolean.valueOf(false)});
        } else {
            ((DefaultTableModel)intervalTable.getModel()).addRow(new Object[]{"","",Boolean.valueOf(false)});
        }
}//GEN-LAST:event_addButtonActionPerformed

    /**
     * Deletes a row from the interval table.
     *
     * @param evt the action event
     */

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        int[] rows = intervalTable.getSelectedRows();
        if(rows.length > 0) {
            for(int i = rows.length-1; i > -1; i--) {
                ((DefaultTableModel)intervalTable.getModel()).removeRow(rows[i]);
            }
        }
}//GEN-LAST:event_deleteButtonActionPerformed

    /**
     * A menu will appear: re-size the width of the pop-up menu to the largest
     * item.
     *
     * @param evt menu event
     */

    private void statBoxPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_statBoxPopupMenuWillBecomeVisible
        EVSMainWindow.main.setPopupWidth(evt);
    }//GEN-LAST:event_statBoxPopupMenuWillBecomeVisible

    /**
     * A menu will appear: re-size the width of the pop-up menu to the largest
     * item.
     *
     * @param evt menu event
     */

    private void scoreDecBoxPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_scoreDecBoxPopupMenuWillBecomeVisible
        EVSMainWindow.main.setPopupWidth(evt);
    }//GEN-LAST:event_scoreDecBoxPopupMenuWillBecomeVisible

    /**
     * A menu will appear: re-size the width of the pop-up menu to the largest
     * item.
     *
     * @param evt menu event
     */

    private void refBoxPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_refBoxPopupMenuWillBecomeVisible
        EVSMainWindow.main.setPopupWidth(evt);
    }//GEN-LAST:event_refBoxPopupMenuWillBecomeVisible

    /**
     * A menu will appear: re-size the width of the pop-up menu to the largest
     * item.
     *
     * @param evt menu event
     */

    private void logBoxPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_logBoxPopupMenuWillBecomeVisible
        EVSMainWindow.main.setPopupWidth(evt);
    }//GEN-LAST:event_logBoxPopupMenuWillBecomeVisible

    /**
     * A menu will appear: re-size the width of the pop-up menu to the largest
     * item.
     *
     * @param evt menu event
     */
    
    private void aucBoxPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_aucBoxPopupMenuWillBecomeVisible
        EVSMainWindow.main.setPopupWidth(evt);
    }//GEN-LAST:event_aucBoxPopupMenuWillBecomeVisible

    /*******************************************************************************
     *                                                                             *
     *                              INSTANCE VARIABLES                             *
     *                                                                             *
     ******************************************************************************/

    /**
     * Selected metric.
     */

    private Metric m = null;

    /**
     * This variable is used to restrict the display of score decomposition options
     * to specific scores until all decompositions are implemented.
     */

    private boolean allowDecomp = false;

    /**
     * TreeMap of parameters for local editing.
     */

    private TreeMap<Integer,Object> pars = null;

    /**
     * Is true if the metric can be bootstrapped, false otherwise.
     */

    private boolean bootstrapable = false;

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JComboBox aucBox;
    private javax.swing.JLabel aucMethodLabel;
    private javax.swing.JPanel aucPanel;
    private javax.swing.JButton backButton;
    private javax.swing.JPanel blockLabelPanel;
    private javax.swing.JPanel blockPanel;
    private javax.swing.JTextField blockSizeField;
    private javax.swing.JLabel blockSizeLabel;
    private javax.swing.JComboBox blockUnitBox;
    private javax.swing.JLabel blockUnitLabel;
    private javax.swing.JPanel boxPanel;
    private javax.swing.JButton cancelButton1;
    private javax.swing.JButton cancelButton2;
    private javax.swing.JCheckBox centSBCheckBox;
    private javax.swing.JPanel conditionsPanel;
    private javax.swing.JButton deleteButton;
    private javax.swing.JCheckBox equalCheckBox;
    private javax.swing.JCheckBox fittedROCBox;
    private javax.swing.JPanel intervalButtonMenu;
    private javax.swing.JPanel intervalInputPanel;
    private javax.swing.JLabel intervalLabel;
    private javax.swing.JPanel intervalPanel;
    private javax.swing.JTable intervalTable;
    private javax.swing.JScrollPane intervalTableScrollPane;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel141212;
    private javax.swing.JPanel jPanel141214;
    private javax.swing.JPanel jPanel14124;
    private javax.swing.JPanel jPanel1413;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel202;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel511;
    private javax.swing.JPanel jPanel512;
    private javax.swing.JPanel jPanel53;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel leftBox;
    private javax.swing.JComboBox logBox;
    private javax.swing.JLabel logLabel;
    private javax.swing.JPanel logPanel;
    private javax.swing.JPanel mainOptionsPanel;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JTabbedPane mainTabbedPane;
    private javax.swing.JTextField minSampleField;
    private javax.swing.JLabel minSampleLabel;
    private javax.swing.JButton nextButton;
    private javax.swing.JPanel nextSpacerPanel;
    private javax.swing.JButton okButton1;
    private javax.swing.JButton okButton2;
    private javax.swing.JTextField pointField;
    private javax.swing.JLabel pointLabel;
    private javax.swing.JPanel pointPanel;
    private javax.swing.JCheckBox probCheckBox;
    private javax.swing.JCheckBox rankHistCheckBox;
    private javax.swing.JComboBox refBox;
    private javax.swing.JLabel refLabel;
    private javax.swing.JPanel refPanel;
    private javax.swing.JPanel rightBox;
    private javax.swing.JTextField sampleField;
    private javax.swing.JLabel sampleLabel;
    private javax.swing.JPanel sampleLabelPanel;
    private javax.swing.JPanel samplePanel;
    private javax.swing.JComboBox scoreDecBox;
    private javax.swing.JLabel scoreDecLabel;
    private javax.swing.JPanel scoreDecPanel;
    private javax.swing.JComboBox statBox;
    private javax.swing.JLabel statLabel;
    private javax.swing.JPanel statPanel;
    private javax.swing.JComboBox techniqueBox;
    private javax.swing.JLabel techniqueLabel;
    private javax.swing.JPanel techniquePanel;
    private javax.swing.JCheckBox uncCheckBox;
    // End of variables declaration//GEN-END:variables
    
}
