package evs.gui.windows;

//Java swing dependencies
import javax.swing.JDialog;

//Java awt dependencies
import java.awt.Component;

/**
 * Constructs a simple dialog with an OK button and a cancel button.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public abstract class SimpleDialog extends JDialog { 
   
/*******************************************************************************
 *                                                                             *
 *                               CONSTRUCTORS                                  *
 *                                                                             *
 ******************************************************************************/  

    /**
     * Construct a dialog.
     */

    protected SimpleDialog() {
        super();
        initComponents();
    }

    /**
     * Construct a dialog.  
     *
     * @param title the dialog title
     */
    
    protected SimpleDialog(String title) {
        super();
        initComponents();    
        setTitle(title); 
    }    

    /**
     * Construct a dialog with a modal status.
     *
     * @param modal is true to set the dialog modal
     */

    protected SimpleDialog(boolean modal) {
        super();
        setModal(modal);
        initComponents();
    }

    /**
     * Construct a dialog with a title and modal status.
     * 
     * @param title the dialog title
     * @param modal is true to set the dialog modal
     */
    
    protected SimpleDialog(String title, boolean modal) {
        super();
        setModal(modal);
        initComponents(); 
        setTitle(title);
    }

/*******************************************************************************
 *                                                                             *
 *                              PUBLIC METHODS                                 *
 *                                                                             *
 ******************************************************************************/    

    /**
     * Overrides the superclass method to set the window location also.
     *
     * @param visible is true to set visible, false to set invisible.
     */
    
    public void setVisible(boolean visible) {
        EVSMainWindow.main.setWindowLocation(this);
        super.setVisible(visible);
    }
    
/*******************************************************************************
 *                                                                             *
 *                              PROTECTED METHODS                              *
 *                                                                             *
 ******************************************************************************/              

    /**
     * Adds the main panel to the dialog.
     *
     * @param panel the panel
     */
    
    protected void addMainPanel(Component panel) {
        mainPanel.add(panel);
    }
    
    /**
     * Removes the main panel from the dialog.
     */
    
    protected void removeMainPanel() {
        mainPanel.removeAll();
    }    
    
    /**
     * Returns the exit status of the dialog.  One of OK_EXIT or CANCELLED_EXIT.
     *
     * @return the exit status
     */
    
    protected int getExitStatus() {
        return exitStatus;
    }
    
    /**
     * Closes the dialog and sets the exit status.
     *
     * @param exitStatus the exit status
     */
    
    protected void close(int exitStatus) {
        this.exitStatus = exitStatus;
        setVisible(false);
    }
    
    /**
     * Sets the visibility of the canceled button.
     * 
     * @param aFlag is true to set the button visible
     */
    
    protected void setCancelVisible(boolean aFlag) {
        cancelButton.setVisible(aFlag);
        if(!aFlag) {
            exitStatus = OK_EXIT;
        }
    }
    
    /**
     * Sets the text for the OK button.
     *
     * @param name the name
     */
    
    protected void setOKButtonName(String name) {
        okButton.setText(name);
    }
    
    /**
     * Sets the text for the cancel button.
     *
     * @param name the name
     */
    
    protected void setCancelButtonName(String name) {
        cancelButton.setText(name);
    }    
    
    /**
     * Used to set the main panel of the dialog.
     */
    
    protected abstract void setProperties();
    
    /**
     * Initializes the window components.
     */   
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        rootPanel = new javax.swing.JPanel();
        mainPanel = new javax.swing.JPanel();
        buttonPanel = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        cancelButton = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        okButton = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();

        setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                closeDialog(evt);
            }
        });
        getContentPane().setLayout(new java.awt.GridLayout(1, 0));

        rootPanel.setMinimumSize(new java.awt.Dimension(400, 275));
        rootPanel.setPreferredSize(new java.awt.Dimension(750, 500));
        rootPanel.setLayout(new javax.swing.BoxLayout(rootPanel, javax.swing.BoxLayout.Y_AXIS));

        mainPanel.setPreferredSize(new java.awt.Dimension(0, 0));
        mainPanel.setLayout(new java.awt.GridLayout(1, 1));
        rootPanel.add(mainPanel);

        buttonPanel.setMaximumSize(new java.awt.Dimension(2147483647, 35));
        buttonPanel.setMinimumSize(new java.awt.Dimension(32000, 30));
        buttonPanel.setPreferredSize(new java.awt.Dimension(32000, 30));
        buttonPanel.setLayout(new javax.swing.BoxLayout(buttonPanel, javax.swing.BoxLayout.LINE_AXIS));

        jPanel12.setPreferredSize(new java.awt.Dimension(32000, 10));

        jPanel7.setMinimumSize(new java.awt.Dimension(1, 10));
        jPanel7.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel12.add(jPanel7);

        buttonPanel.add(jPanel12);

        cancelButton.setFont(new java.awt.Font("Dialog", 0, 11));
        cancelButton.setText("Cancel");
        cancelButton.setAlignmentX(0.5F);
        cancelButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        cancelButton.setMaximumSize(new java.awt.Dimension(65, 29));
        cancelButton.setMinimumSize(new java.awt.Dimension(65, 29));
        cancelButton.setPreferredSize(new java.awt.Dimension(65, 29));
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(cancelButton);

        jPanel4.setMaximumSize(new java.awt.Dimension(3, 32767));
        jPanel4.setMinimumSize(new java.awt.Dimension(3, 10));
        jPanel4.setPreferredSize(new java.awt.Dimension(3, 10));
        buttonPanel.add(jPanel4);

        okButton.setFont(new java.awt.Font("Dialog", 1, 11));
        okButton.setText("OK");
        okButton.setAlignmentX(0.5F);
        okButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        okButton.setMaximumSize(new java.awt.Dimension(65, 29));
        okButton.setMinimumSize(new java.awt.Dimension(65, 29));
        okButton.setPreferredSize(new java.awt.Dimension(65, 29));
        okButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(okButton);

        jPanel5.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel5.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel5.setPreferredSize(new java.awt.Dimension(2, 10));
        buttonPanel.add(jPanel5);

        rootPanel.add(buttonPanel);

        getContentPane().add(rootPanel);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Closes the console, not accepting the displayed date.
     *
     * @param evt an action event
     */        
    
    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonActionPerformed
        close(CANCELLED_EXIT);
    }//GEN-LAST:event_cancelButtonActionPerformed

    /**
     * Closes the console, accepting the displayed date.
     *
     * @param evt an action event
     */    
    
    private void okButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_okButtonActionPerformed
        try {
            close(OK_EXIT);
        } catch(Exception e) {
            ExceptionHandler.displayException(e,this);
        }
    }//GEN-LAST:event_okButtonActionPerformed
     
    /**
     * Closes the console.
     *
     * @param evt a window event
     */    
    
    private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
        close(CANCELLED_EXIT);
    }//GEN-LAST:event_closeDialog
    
    /*******************************************************************************
     *                                                                             *
     *                              INSTANCE VARIABLES                             *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Exit status of the dialog.
     */
    
    private int exitStatus = CANCELLED_EXIT;
    
    /**
     * Canceled exit status
     */
    
    protected static final int CANCELLED_EXIT = 101;
    
    /**
     * OK exit status
     */
    
    protected static final int OK_EXIT = 102;   
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel buttonPanel;
    private javax.swing.JButton cancelButton;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JButton okButton;
    private javax.swing.JPanel rootPanel;
    // End of variables declaration//GEN-END:variables

}
