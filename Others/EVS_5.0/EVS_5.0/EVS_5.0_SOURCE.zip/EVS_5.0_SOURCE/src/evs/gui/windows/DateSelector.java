package evs.gui.windows;

//Java swing dependencies
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.JComboBox;

//Java awt dependencies
import java.awt.Dimension;
import java.awt.Component;
import java.awt.Color;

//Calendar utility
import com.toedter.calendar.JCalendar;

/**
 * Constructs a dialog for date selection.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class DateSelector extends SimpleDialog {
    
/*******************************************************************************
 *                                                                             *
 *                               CONSTRUCTORS                                  *
 *                                                                             *
 ******************************************************************************/  

    /**
     * Construct a date selector.
     *
     * @param title the dialog title
     */
    
    protected DateSelector(String title) {
        super(title);
        setProperties(); 
        setMinimumSize(new Dimension(395, 310));
        setPreferredSize(new Dimension(395, 310));
        pack(); //Update preferred size
    }    
    
    /**
     * Construct a date selector.
     *
     * @param title the dialog title
     * @param modal is true for a modal dialog
     */
    
    protected DateSelector(String title, boolean modal) {
        super(title,modal);
        setProperties(); 
        setMinimumSize(new Dimension(395, 310));
        setPreferredSize(new Dimension(395, 310));
        pack(); //Update preferred size
    }    
    
/*******************************************************************************
 *                                                                             *
 *                              PROTECTED METHODS                              *
 *                                                                             *
 ******************************************************************************/              

    /**
     * Returns the calendar object.
     *
     * @return the messages
     */
    
    protected JCalendar getCalendar() {
        return date;
    }       
    
    /**
     * Edits several dimensions in the JCalendar object for improved display.
     */
    
    protected void setProperties() {
        
        //Edit spin field with year
        date.getYearChooser().setMaximumSize(new Dimension(2147483647, 2147483647));
        date.getYearChooser().setMinimumSize(new Dimension(0, 32000));
        date.getYearChooser().setPreferredSize(new Dimension(0, 32000));
        JSpinner spin = (JSpinner)date.getYearChooser().getSpinner();
        spin.setBorder(null);
        JTextField spinField = (JTextField)spin.getEditor();
        spinField.setBorder(new LineBorder(Color.gray));
        ((Component)date.getYearChooser().getAccessibleContext().getAccessibleParent()).setMaximumSize(new Dimension(2147483647, 2147483647));
        ((Component)date.getYearChooser().getAccessibleContext().getAccessibleParent()).setMinimumSize(new Dimension(134, 25));
        ((Component)date.getYearChooser().getAccessibleContext().getAccessibleParent()).setPreferredSize(new Dimension(134, 25));

        //Edit combobox with month
        date.getMonthChooser().setMaximumSize(new Dimension(116, 25));
        date.getMonthChooser().setMinimumSize(new Dimension(116, 2));
        date.getMonthChooser().setPreferredSize(new Dimension(116, 25));   
        JComboBox box = (JComboBox)date.getMonthChooser().getComboBox();
        box.setPreferredSize(new Dimension(100, 25));
        box.setBackground(Color.white);
        box.setBorder(new LineBorder(Color.gray));
        
        //Edit day chooser
        date.getDayChooser().setWeekOfYearVisible(false);
        addMainPanel(date);
    }

    /*******************************************************************************
     *                                                                             *
     *                              INSTANCE VARIABLES                             *
     *                                                                             *
     ******************************************************************************/

    /**
     * Calendar panel.
     */
    
    private JCalendar date = new JCalendar();   
        
}
