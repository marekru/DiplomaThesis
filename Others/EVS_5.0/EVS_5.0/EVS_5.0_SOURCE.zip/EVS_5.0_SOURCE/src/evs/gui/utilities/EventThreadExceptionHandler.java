package evs.gui.utilities;

//Java dependencies
import java.lang.Thread.UncaughtExceptionHandler;

/**
 * Thread to catch unhandled errors/exceptions on the event dispatch thread.
 *
 * @author evs@hydrosolved.com
 */

public class EventThreadExceptionHandler implements UncaughtExceptionHandler {

    /**
     * Handle the exception.
     *
     * @param t the thread
     * @param e the error thrown
     */

    public void uncaughtException(Thread t, Throwable e) {
        e.printStackTrace();
        // TODO: Log this error to a file, e.g. Logger.error("Caught this unhandled exception", e );
    }
}

