package evs.gui.windows;

//EVS dependencies
import evs.analysisunits.AnalysisUnit;

/**
 * A root interface containing methods for saving data permanently to an analysis 
 * unit and for storing and displaying temporary data that has not yet been saved.  
 * Local data should always be displayed in preference to saved data, because saved 
 * data should be used to update the store of local data once available.  
 * By implication, local data should always be updated after loading saved data.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public interface GUIInterface extends GUICommunicator {
    
/********************************************************************************
 *                                                                              *
 *                               MUTATOR METHODS                                *
 *                                                                              *
 *******************************************************************************/    
    
    /**
     * Saves local data in the active input fields to a temporary store for the
     * active analysis unit.
     */
    
    abstract void saveLocalData();
    
    /**
     * Saves data in the local store to an analysis unit.
     * 
     * @return true if the data were saved.
     */
    
    abstract boolean saveData();

    /**
     * Displays the local data previously saved to a temporary store.  Local data 
     * should always be displayed in preference to saved data, because saved data 
     * should be used to update the store of local data once available.
     */
    
    abstract void showLocalData();    
    
    /**
     * Updates local data with a saved AnalysisUnit. 
     *
     * @param unit the unit
     */
    
    abstract void updateLocalData(AnalysisUnit unit);
    
    /**
     * Removes local data from the temporary store for a specified AnalysisUnit. 
     *
     * @param unit the unit
     */
    
    abstract void clearLocalData(AnalysisUnit unit);    
    
    /**
     * Clears all local data, resetting the window to its original condition. 
     */
    
    abstract void clearAllLocalData();        
    
    /**
     * Disposes of any open dialogs or frames associated with the GUI window. Call
     * this method before initiating a shutdown. 
     */
    
    abstract void disposeOfChildren();
    
}
