package evs.gui.windows;

//Java dependencies
import evs.analysisunits.AnalysisUnit;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;

//EVS dependencies
import evs.analysisunits.*;
import evs.analysisunits.scale.*;
import evs.gui.utilities.*;
import evs.data.fileio.GlobalUnitsReader;
import evs.utilities.StringUtilities;
 
/**
 * Dialog for associating scale information with the forecasts and observations.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class MoreInputDialog extends JDialog implements GUICommunicator {
    
    /*******************************************************************************
     *                                                                             *
     *                               CONSTRUCTOR                                   *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Construct the dialog with a parent frame.
     */
    
    protected MoreInputDialog() {
        super();
        setTitle("Additional options");
        initComponents();
        forecastModel = new ScaleTableModel();
        observedModel = new ScaleTableModel();
        forecastTable.setModel(forecastModel);
        observedTable.setModel(observedModel);        
        //Set the table cell editors
        ((EditorTable)forecastTable).setCellEditors(forecastModel.getCellEditors());
        ((EditorTable)observedTable).setCellEditors(observedModel.getCellEditors());
        JTextField field = new JTextField();
        field.setHorizontalAlignment(JTextField.CENTER);
        JCheckBox cb = new JCheckBox();
        JCheckBox cb2 = new JCheckBox();
        JCheckBox cb3 = new JCheckBox();
        JCheckBox cb4 = new JCheckBox();
        cb.setHorizontalAlignment(SwingConstants.CENTER);
        cb2.setHorizontalAlignment(SwingConstants.CENTER);
        cb3.setHorizontalAlignment(SwingConstants.CENTER);
        cb4.setHorizontalAlignment(SwingConstants.CENTER);
        JTextField pairField = new JTextField();
        pairField.setHorizontalAlignment(JTextField.CENTER);      
        JTextField fDateField = new JTextField();
        fDateField.setHorizontalAlignment(JTextField.CENTER);      
        JTextField oDateField = new JTextField();
        oDateField.setHorizontalAlignment(JTextField.CENTER); 
        JTextField fLocIDField = new JTextField();
        fLocIDField.setHorizontalAlignment(JTextField.CENTER); 
        JTextField fVarIDField = new JTextField();
        fVarIDField.setHorizontalAlignment(JTextField.CENTER);         
        JTextField oLocIDField = new JTextField();
        oLocIDField.setHorizontalAlignment(JTextField.CENTER); 
        JTextField oVarIDField = new JTextField();
        oVarIDField.setHorizontalAlignment(JTextField.CENTER);      
//        JTextField startLeadField = new JTextField();
//        startLeadField.setHorizontalAlignment(JTextField.CENTER);         
        
        Object[][] editors = new Object[][]{
            {null,new DefaultCellEditor(field)},
            {null,new DefaultCellEditor(cb)},
            {null,new DefaultCellEditor(cb2)},
            {null,new DefaultCellEditor(cb3)},
            {null,new DefaultCellEditor(cb4)},
            {null,new DefaultCellEditor(pairField)},
            {null,new DefaultCellEditor(fDateField)},
            {null,new DefaultCellEditor(oDateField)},
            {null,new DefaultCellEditor(fLocIDField)},
            {null,new DefaultCellEditor(fVarIDField)},
            {null,new DefaultCellEditor(oLocIDField)},
            {null,new DefaultCellEditor(oVarIDField)}
//            {null,new DefaultCellEditor(startLeadField)}              
        };
        ((EditorTable)otherTable).setCellEditors(editors);
        //Set the table cell renderers
        forecastTable.setDefaultRenderer(Object.class,new ScaleTableRenderer());
        observedTable.setDefaultRenderer(Object.class,new ScaleTableRenderer());
        forecastTable.setRowHeight(25);
        observedTable.setRowHeight(25);        
        otherTable.setRowHeight(25);
        otherTable.setValueAt(false,1,1);
        otherTable.setValueAt(false,2,1);
        otherTable.setValueAt(false,3,1);
        otherTable.setValueAt(false,4,1);        
        otherTable.getColumnModel().getColumn(0).setPreferredWidth(7500);
        otherTable.getColumnModel().getColumn(1).setPreferredWidth(2500);

        //Set the cell renderer
        otherTable.setDefaultRenderer(Object.class,new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                if (column == 1) {
                    if (row == 0 || row > 4) {
                        JTextField field = new JTextField();
                        field.setBorder(null);
                        field.setHorizontalAlignment(JTextField.CENTER);
                        field.setText(value.toString());
                        if (!isSelected) {
                            field.setBackground(Color.white);
                        } else {
                            Color bg = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column).getBackground();
                            field.setBackground(bg);
                        }
                        return field;
                    } else if (row > 0 && row < 5) {
                        JCheckBox cb = new JCheckBox();
                        cb.setHorizontalAlignment(SwingConstants.CENTER);
                        if (!isSelected) {
                            cb.setBackground(Color.white);
                        } else {
                            Color bg = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column).getBackground();
                            cb.setBackground(bg);
                        }
                        cb.setSelected(value.toString().equalsIgnoreCase("true"));
                        return cb;
                    }
                }
                return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }
        });

    };
    
    /********************************************************************************
     *                                                                              *
     *                              PROTECTED METHODS                               *
     *                                                                              *
     *******************************************************************************/
    
    /**
     * Updates local data with a saved AnalysisUnit.
     *
     * @param unit the unit
     */
    
    protected void updateLocalData(VerificationUnit unit) {
        clearDisplay();
        if(unit.hasSupport(Support.FORECAST_SUPPORT)) {
            forecastModel.setSupport(unit.getSupport(Support.FORECAST_SUPPORT));
        }
        else {
            forecastModel.clearSupport();
        }
        if(unit.hasSupport(Support.OBSERVED_SUPPORT)) {
            observedModel.setSupport(unit.getSupport(Support.OBSERVED_SUPPORT));
        }
        else {
            observedModel.clearSupport(); 
        }
        otherTable.setValueAt(unit.getNullValue(),0,1);
        otherTable.setValueAt(unit.isStripNullMembers(),1,1);
        otherTable.setValueAt(unit.isUseFullClimatology(),2,1);
        otherTable.setValueAt(unit.isApplyDateCondToClim(),3,1);
        otherTable.setValueAt(unit.isApplyValueCondToClim(),4,1);
        otherTable.setValueAt(unit.getPairPrecision(),5,1);
        otherTable.setValueAt(unit.getForcDateFormat(),6,1);
        otherTable.setValueAt(unit.getObsDateFormat(),7,1);
        if(unit.hasForecastFileLocationID()) {
            otherTable.setValueAt(unit.getForecastFileLocationID(),8,1);
        }
        if(unit.hasForecastFileVariableID()) {
            otherTable.setValueAt(unit.getForecastFileVariableID(),9,1);
        }
        if(unit.hasObservedFileLocationID()) {
            otherTable.setValueAt(unit.getObservedFileLocationID(),10,1);
        }
        if(unit.hasObservedFileVariableID()) {
            otherTable.setValueAt(unit.getObservedFileVariableID(),11,1);
        }
//        if(unit.hasPairedStartLeadHour()) {
//            otherTable.setValueAt(unit.getPairedStartLeadHour(),12,1);
//        }        
    }
    
    /********************************************************************************
     *                                                                              *
     *                               PRIVATE METHODS                                *
     *                                                                              *
     *******************************************************************************/
    
    /**
     * Removes local data from the temporary store for a specified AnalysisUnit.
     */
    
    private void clearDisplay() {
        forecastModel.clearSupport();
        observedModel.clearSupport();
        otherTable.setValueAt("",0,1);
        otherTable.setValueAt(false,1,1);
        otherTable.setValueAt(false,2,1);
        otherTable.setValueAt(false,3,1);
        otherTable.setValueAt(false,4,1);
        otherTable.setValueAt("",5,1);
        otherTable.setValueAt("",6,1);
        otherTable.setValueAt("",7,1);
        otherTable.setValueAt("",8,1);
        otherTable.setValueAt("",9,1);
        otherTable.setValueAt("",10,1);
        otherTable.setValueAt("",11,1);
//        otherTable.setValueAt("",12,1);     
    }
     
    /**
     * Saves any existing conditions to the current verification unit. Returns
     * false if saving did not complete.
     */
    
    private boolean saveData() {
        VerificationUnit unit = VERIFICATION_A.getSelectedUnit();
        if(unit != null) {
            //Finalize any entries that may not be final
            TableCellEditor c = ((EditorTable)otherTable).getCellEditor();
            if(c!=null) {
                c.stopCellEditing();
            }
            TableCellEditor d = ((EditorTable)observedTable).getCellEditor();
            if(d!=null) {
                d.stopCellEditing();
            }
            TableCellEditor f = ((EditorTable)forecastTable).getCellEditor();
            if(f!=null) {
                f.stopCellEditing();
            }
            //Get any warnings out of the way
            //Warn if the date format is unrecognized
            String forcFormat = otherTable.getValueAt(6,1).toString();
            String obsFormat = otherTable.getValueAt(7,1).toString();
            if (!(StringUtilities.isCheckDateFormat(forcFormat) && StringUtilities.isCheckDateFormat(obsFormat))) {
                //Warn user of a change that will affect the aggregation unit
                int n = JOptionPane.showOptionDialog(this, "WARNING: one or or more of the ASCII date "
                        + "formats is not a common type. Note that format strings are case sensitive "
                        + "(e.g. m=minute, M=month).", "Warning: ASCII date format", JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE, null, new Object[]{"Ignore","Edit"}, null);
                if(n==JOptionPane.NO_OPTION) {
                    return false;
                }
            }            
            
            if(forecastModel.hasSupportInput()) {
                unit.setSupport(Support.FORECAST_SUPPORT,forecastModel.getSupport());
            }
            else {
                unit.deleteSupport(Support.FORECAST_SUPPORT);
            }
            if(observedModel.hasSupportInput()) {
                unit.setSupport(Support.OBSERVED_SUPPORT,observedModel.getSupport());
            }
            else {
                unit.deleteSupport(Support.OBSERVED_SUPPORT);
            }
            String value = otherTable.getValueAt(0,1)+"";
            try {
                double val = new Double(value);
                unit.setNullValue(val);
            } 
            catch(Exception e) {
                throw new IllegalArgumentException("Enter a valid number for the null identifier: "+e.getMessage());
            }
            unit.setStripNullMembers(otherTable.getValueAt(1,1).toString().equalsIgnoreCase("true"));
            unit.setUseFullClimatology(otherTable.getValueAt(2,1).toString().equalsIgnoreCase("true"));
            unit.setApplyDateCondToClim(otherTable.getValueAt(3,1).toString().equalsIgnoreCase("true"));
            unit.setApplyValueCondToClim(otherTable.getValueAt(4,1).toString().equalsIgnoreCase("true"));
            try {
                unit.setPairPrecision(new Integer(otherTable.getValueAt(5,1)+""));
            } catch(NumberFormatException e) {
                throw new IllegalArgumentException("Enter a valid number for the paired writing precision.");
            }
            //Set the date formats, see above for checks
            unit.setForcDateFormat(forcFormat);
            unit.setObsDateFormat(obsFormat);
            unit.setForecastFileLocationID(otherTable.getValueAt(8,1).toString());
            unit.setForecastFileVariableID(otherTable.getValueAt(9,1).toString());
            unit.setObservedFileLocationID(otherTable.getValueAt(10,1).toString());
            unit.setObservedFileVariableID(otherTable.getValueAt(11,1).toString());
//            try {
//                String lead = otherTable.getValueAt(12,1)+"";
//                if(!"".equals(lead)) {
//                    double val = new Double(lead);
//                    unit.setPairedStartLeadHour(val);
//                }
//            } 
//            catch(Exception e) {
//                throw new IllegalArgumentException("Enter a valid forecast lead time in hours at which to begin pairing: "+e.getMessage());
//            }            
        }
        return true;
    }    
    
    /**
     * Intializes the window components.
     */
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainTabbedPane = new javax.swing.JTabbedPane();
        forecastPanel = new javax.swing.JPanel();
        jPanel511 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jScrollPane131 = new javax.swing.JScrollPane();
        forecastTable = new EditorTable();
        jPanel13 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        resetForcSupport = new javax.swing.JButton();
        jPanel20 = new javax.swing.JPanel();
        cancelButton1 = new javax.swing.JButton();
        jPanel14121 = new javax.swing.JPanel();
        nextButton = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        observedPanel = new javax.swing.JPanel();
        jPanel512 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane132 = new javax.swing.JScrollPane();
        observedTable = new EditorTable();
        jPanel43 = new javax.swing.JPanel();
        jPanel53 = new javax.swing.JPanel();
        jPanel45 = new javax.swing.JPanel();
        resetObsButton = new javax.swing.JButton();
        jPanel202 = new javax.swing.JPanel();
        cancelButton2 = new javax.swing.JButton();
        jPanel14124 = new javax.swing.JPanel();
        backButton = new javax.swing.JButton();
        jPanel141213 = new javax.swing.JPanel();
        nextButton1 = new javax.swing.JButton();
        jPanel141211 = new javax.swing.JPanel();
        okButton = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        otherOptionsPanel = new javax.swing.JPanel();
        jPanel514 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jScrollPane134 = new javax.swing.JScrollPane();
        otherTable = new EditorTable();
        jPanel4 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        resetNullButton = new javax.swing.JButton();
        jPanel203 = new javax.swing.JPanel();
        cancelButton3 = new javax.swing.JButton();
        jPanel14125 = new javax.swing.JPanel();
        backButton1 = new javax.swing.JButton();
        jPanel141212 = new javax.swing.JPanel();
        okButton1 = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();

        setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                closeDialog(evt);
            }
        });
        getContentPane().setLayout(new java.awt.GridLayout(1, 0));

        mainTabbedPane.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        mainTabbedPane.setMaximumSize(new java.awt.Dimension(750, 500));
        mainTabbedPane.setMinimumSize(new java.awt.Dimension(750, 500));
        mainTabbedPane.setPreferredSize(new java.awt.Dimension(750, 500));

        forecastPanel.setMaximumSize(new java.awt.Dimension(2147483647, 2147483647));
        forecastPanel.setMinimumSize(new java.awt.Dimension(500, 60));
        forecastPanel.setPreferredSize(new java.awt.Dimension(500, 65));
        forecastPanel.setLayout(new javax.swing.BoxLayout(forecastPanel, javax.swing.BoxLayout.Y_AXIS));

        jPanel511.setMaximumSize(new java.awt.Dimension(32000, 5));
        jPanel511.setMinimumSize(new java.awt.Dimension(500, 5));
        jPanel511.setPreferredSize(new java.awt.Dimension(500, 5));
        forecastPanel.add(jPanel511);

        jPanel17.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Enter scale information for the forecasts", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11))); // NOI18N
        jPanel17.setMinimumSize(new java.awt.Dimension(120, 47));
        jPanel17.setPreferredSize(new java.awt.Dimension(32000, 2000));
        jPanel17.setLayout(new java.awt.GridLayout(1, 0));

        jScrollPane131.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane131.setPreferredSize(new java.awt.Dimension(450, 450));

        forecastTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Variable", "Value"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        forecastTable.setInheritsPopupMenu(true);
        forecastTable.setPreferredSize(new java.awt.Dimension(75, 300));
        forecastTable.setRequestFocusEnabled(false);
        jScrollPane131.setViewportView(forecastTable);

        jPanel17.add(jScrollPane131);

        forecastPanel.add(jPanel17);

        jPanel13.setMaximumSize(new java.awt.Dimension(65676, 35));
        jPanel13.setMinimumSize(new java.awt.Dimension(150, 30));
        jPanel13.setPreferredSize(new java.awt.Dimension(300, 35));
        jPanel13.setLayout(new javax.swing.BoxLayout(jPanel13, javax.swing.BoxLayout.Y_AXIS));

        jPanel1.setMaximumSize(new java.awt.Dimension(32000, 2));
        jPanel1.setMinimumSize(new java.awt.Dimension(500, 2));
        jPanel1.setPreferredSize(new java.awt.Dimension(500, 2));
        jPanel13.add(jPanel1);

        jPanel15.setMaximumSize(new java.awt.Dimension(32899, 35));
        jPanel15.setMinimumSize(new java.awt.Dimension(142, 30));
        jPanel15.setPreferredSize(new java.awt.Dimension(144, 35));
        jPanel15.setLayout(new javax.swing.BoxLayout(jPanel15, javax.swing.BoxLayout.LINE_AXIS));

        resetForcSupport.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        resetForcSupport.setText("Reset");
        resetForcSupport.setMargin(new java.awt.Insets(2, 10, 2, 10));
        resetForcSupport.setMaximumSize(new java.awt.Dimension(65, 29));
        resetForcSupport.setMinimumSize(new java.awt.Dimension(65, 29));
        resetForcSupport.setPreferredSize(new java.awt.Dimension(65, 29));
        resetForcSupport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetForcSupportActionPerformed(evt);
            }
        });
        jPanel15.add(resetForcSupport);

        jPanel20.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel15.add(jPanel20);

        cancelButton1.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        cancelButton1.setText("Cancel");
        cancelButton1.setMargin(new java.awt.Insets(2, 10, 2, 10));
        cancelButton1.setMaximumSize(new java.awt.Dimension(65, 29));
        cancelButton1.setMinimumSize(new java.awt.Dimension(65, 29));
        cancelButton1.setPreferredSize(new java.awt.Dimension(65, 29));
        cancelButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButton1ActionPerformed(evt);
            }
        });
        jPanel15.add(cancelButton1);

        jPanel14121.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel14121.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel14121.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel15.add(jPanel14121);

        nextButton.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        nextButton.setText("Next");
        nextButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        nextButton.setMaximumSize(new java.awt.Dimension(65, 29));
        nextButton.setMinimumSize(new java.awt.Dimension(65, 29));
        nextButton.setPreferredSize(new java.awt.Dimension(65, 29));
        nextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextButtonActionPerformed(evt);
            }
        });
        jPanel15.add(nextButton);

        jPanel2.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel2.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel2.setPreferredSize(new java.awt.Dimension(2, 10));
        jPanel15.add(jPanel2);

        jPanel13.add(jPanel15);

        forecastPanel.add(jPanel13);

        mainTabbedPane.addTab("Forecast scale  ", forecastPanel);

        observedPanel.setMinimumSize(new java.awt.Dimension(500, 65));
        observedPanel.setPreferredSize(new java.awt.Dimension(500, 60));
        observedPanel.setLayout(new javax.swing.BoxLayout(observedPanel, javax.swing.BoxLayout.Y_AXIS));

        jPanel512.setMaximumSize(new java.awt.Dimension(32000, 5));
        jPanel512.setMinimumSize(new java.awt.Dimension(500, 5));
        jPanel512.setPreferredSize(new java.awt.Dimension(500, 5));
        observedPanel.add(jPanel512);

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Enter scale information for the observations", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11))); // NOI18N
        jPanel5.setMinimumSize(new java.awt.Dimension(120, 47));
        jPanel5.setPreferredSize(new java.awt.Dimension(32000, 2000));
        jPanel5.setLayout(new java.awt.GridLayout(1, 0));

        jScrollPane132.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane132.setPreferredSize(new java.awt.Dimension(450, 450));

        observedTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Variable", "Value"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        observedTable.setInheritsPopupMenu(true);
        observedTable.setPreferredSize(new java.awt.Dimension(75, 300));
        observedTable.setRequestFocusEnabled(false);
        jScrollPane132.setViewportView(observedTable);

        jPanel5.add(jScrollPane132);

        observedPanel.add(jPanel5);

        jPanel43.setMaximumSize(new java.awt.Dimension(65676, 35));
        jPanel43.setMinimumSize(new java.awt.Dimension(150, 30));
        jPanel43.setPreferredSize(new java.awt.Dimension(300, 35));
        jPanel43.setLayout(new javax.swing.BoxLayout(jPanel43, javax.swing.BoxLayout.Y_AXIS));

        jPanel53.setMaximumSize(new java.awt.Dimension(32000, 2));
        jPanel53.setMinimumSize(new java.awt.Dimension(500, 2));
        jPanel53.setOpaque(false);
        jPanel53.setPreferredSize(new java.awt.Dimension(500, 2));
        jPanel53.setLayout(new javax.swing.BoxLayout(jPanel53, javax.swing.BoxLayout.LINE_AXIS));
        jPanel43.add(jPanel53);

        jPanel45.setMaximumSize(new java.awt.Dimension(32909, 35));
        jPanel45.setMinimumSize(new java.awt.Dimension(152, 30));
        jPanel45.setPreferredSize(new java.awt.Dimension(150, 35));
        jPanel45.setLayout(new javax.swing.BoxLayout(jPanel45, javax.swing.BoxLayout.LINE_AXIS));

        resetObsButton.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        resetObsButton.setText("Reset");
        resetObsButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        resetObsButton.setMaximumSize(new java.awt.Dimension(65, 29));
        resetObsButton.setMinimumSize(new java.awt.Dimension(65, 29));
        resetObsButton.setPreferredSize(new java.awt.Dimension(65, 29));
        resetObsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetObsButtonActionPerformed(evt);
            }
        });
        jPanel45.add(resetObsButton);

        jPanel202.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel45.add(jPanel202);

        cancelButton2.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        cancelButton2.setText("Cancel");
        cancelButton2.setMargin(new java.awt.Insets(2, 10, 2, 10));
        cancelButton2.setMaximumSize(new java.awt.Dimension(65, 29));
        cancelButton2.setMinimumSize(new java.awt.Dimension(65, 29));
        cancelButton2.setPreferredSize(new java.awt.Dimension(65, 29));
        cancelButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButton2ActionPerformed(evt);
            }
        });
        jPanel45.add(cancelButton2);

        jPanel14124.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel14124.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel14124.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel45.add(jPanel14124);

        backButton.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        backButton.setText("Back");
        backButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        backButton.setMaximumSize(new java.awt.Dimension(65, 29));
        backButton.setMinimumSize(new java.awt.Dimension(65, 29));
        backButton.setPreferredSize(new java.awt.Dimension(65, 29));
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });
        jPanel45.add(backButton);

        jPanel141213.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel141213.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel141213.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel45.add(jPanel141213);

        nextButton1.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        nextButton1.setText("Next");
        nextButton1.setMargin(new java.awt.Insets(2, 10, 2, 10));
        nextButton1.setMaximumSize(new java.awt.Dimension(65, 29));
        nextButton1.setMinimumSize(new java.awt.Dimension(65, 29));
        nextButton1.setPreferredSize(new java.awt.Dimension(65, 29));
        nextButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextButton1ActionPerformed(evt);
            }
        });
        jPanel45.add(nextButton1);

        jPanel141211.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel141211.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel141211.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel45.add(jPanel141211);

        okButton.setFont(new java.awt.Font("Dialog", 1, 11)); // NOI18N
        okButton.setText("OK");
        okButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        okButton.setMaximumSize(new java.awt.Dimension(65, 29));
        okButton.setMinimumSize(new java.awt.Dimension(65, 29));
        okButton.setPreferredSize(new java.awt.Dimension(65, 29));
        okButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okButtonActionPerformed(evt);
            }
        });
        jPanel45.add(okButton);

        jPanel3.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel3.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel3.setPreferredSize(new java.awt.Dimension(2, 10));
        jPanel45.add(jPanel3);

        jPanel43.add(jPanel45);

        observedPanel.add(jPanel43);

        mainTabbedPane.addTab("Observed scale  ", observedPanel);

        otherOptionsPanel.setLayout(new javax.swing.BoxLayout(otherOptionsPanel, javax.swing.BoxLayout.Y_AXIS));

        jPanel514.setMaximumSize(new java.awt.Dimension(32000, 5));
        jPanel514.setMinimumSize(new java.awt.Dimension(500, 5));
        jPanel514.setPreferredSize(new java.awt.Dimension(500, 5));
        otherOptionsPanel.add(jPanel514);

        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Edit other options", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 11))); // NOI18N
        jPanel10.setMinimumSize(new java.awt.Dimension(120, 47));
        jPanel10.setPreferredSize(new java.awt.Dimension(32000, 2000));
        jPanel10.setLayout(new java.awt.GridLayout(1, 0));

        jScrollPane134.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane134.setPreferredSize(new java.awt.Dimension(450, 450));

        otherTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"Global no-data value", ""},
                {"Omit no-data values from paired file", null},
                {"Use all observations (not just paired) to determine climate thresholds", ""},
                {"Apply date conditions when determining climate thresholds", null},
                {"Apply value conditions when determining climate thresholds", null},
                {"Number of decimal places for writing pairs", null},
                {"Date format used in ASCII forecast data files", ""},
                {"Date format used in ASCII observed data file", ""},
                {"Forecast file location ID", null},
                {"Forecast file variable ID", null},
                {"Observed file location ID", null},
                {"Observed file variable ID", null}
            },
            new String [] {
                "Variable", "Value"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        otherTable.setInheritsPopupMenu(true);
        otherTable.setPreferredSize(new java.awt.Dimension(75, 350));
        otherTable.setRequestFocusEnabled(false);
        otherTable.setRowHeight(25);
        jScrollPane134.setViewportView(otherTable);

        jPanel10.add(jScrollPane134);

        otherOptionsPanel.add(jPanel10);

        jPanel4.setMaximumSize(new java.awt.Dimension(65676, 35));
        jPanel4.setMinimumSize(new java.awt.Dimension(150, 30));
        jPanel4.setPreferredSize(new java.awt.Dimension(300, 35));
        jPanel4.setLayout(new javax.swing.BoxLayout(jPanel4, javax.swing.BoxLayout.Y_AXIS));

        jPanel7.setMaximumSize(new java.awt.Dimension(32000, 2));
        jPanel7.setMinimumSize(new java.awt.Dimension(500, 2));
        jPanel7.setPreferredSize(new java.awt.Dimension(500, 2));
        jPanel4.add(jPanel7);

        jPanel8.setMaximumSize(new java.awt.Dimension(32909, 35));
        jPanel8.setMinimumSize(new java.awt.Dimension(152, 30));
        jPanel8.setPreferredSize(new java.awt.Dimension(150, 35));
        jPanel8.setLayout(new javax.swing.BoxLayout(jPanel8, javax.swing.BoxLayout.LINE_AXIS));

        resetNullButton.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        resetNullButton.setText("Reset");
        resetNullButton.setMargin(new java.awt.Insets(2, 10, 2, 10));
        resetNullButton.setMaximumSize(new java.awt.Dimension(65, 29));
        resetNullButton.setMinimumSize(new java.awt.Dimension(65, 29));
        resetNullButton.setPreferredSize(new java.awt.Dimension(65, 29));
        resetNullButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetNullButtonActionPerformed(evt);
            }
        });
        jPanel8.add(resetNullButton);

        jPanel203.setMaximumSize(new java.awt.Dimension(32767, 30));
        jPanel8.add(jPanel203);

        cancelButton3.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        cancelButton3.setText("Cancel");
        cancelButton3.setMargin(new java.awt.Insets(2, 10, 2, 10));
        cancelButton3.setMaximumSize(new java.awt.Dimension(65, 29));
        cancelButton3.setMinimumSize(new java.awt.Dimension(65, 29));
        cancelButton3.setPreferredSize(new java.awt.Dimension(65, 29));
        cancelButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButton3ActionPerformed(evt);
            }
        });
        jPanel8.add(cancelButton3);

        jPanel14125.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel14125.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel14125.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel8.add(jPanel14125);

        backButton1.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        backButton1.setText("Back");
        backButton1.setMargin(new java.awt.Insets(2, 10, 2, 10));
        backButton1.setMaximumSize(new java.awt.Dimension(65, 29));
        backButton1.setMinimumSize(new java.awt.Dimension(65, 29));
        backButton1.setPreferredSize(new java.awt.Dimension(65, 29));
        backButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButton1ActionPerformed(evt);
            }
        });
        jPanel8.add(backButton1);

        jPanel141212.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel141212.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel141212.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel8.add(jPanel141212);

        okButton1.setFont(new java.awt.Font("Dialog", 1, 11)); // NOI18N
        okButton1.setText("OK");
        okButton1.setMargin(new java.awt.Insets(2, 10, 2, 10));
        okButton1.setMaximumSize(new java.awt.Dimension(65, 29));
        okButton1.setMinimumSize(new java.awt.Dimension(65, 29));
        okButton1.setPreferredSize(new java.awt.Dimension(65, 29));
        okButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okButton1ActionPerformed(evt);
            }
        });
        jPanel8.add(okButton1);

        jPanel9.setMaximumSize(new java.awt.Dimension(2, 32767));
        jPanel9.setMinimumSize(new java.awt.Dimension(2, 10));
        jPanel9.setPreferredSize(new java.awt.Dimension(2, 10));
        jPanel8.add(jPanel9);

        jPanel4.add(jPanel8);

        otherOptionsPanel.add(jPanel4);

        mainTabbedPane.addTab("Other options     ", otherOptionsPanel);

        getContentPane().add(mainTabbedPane);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Moves to the next window.
     *
     * @param evt an action event
     */
        
    private void nextButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextButton1ActionPerformed
        mainTabbedPane.setSelectedIndex((mainTabbedPane.getSelectedIndex())+1);
    }//GEN-LAST:event_nextButton1ActionPerformed

    /**
     * Exits the dialog, accepting any changes made.
     *
     * @param evt an action event
     */   
    
    private void okButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_okButton1ActionPerformed
        try {
            if(saveData()) {  //Otherwise keep dialog
                exit();
            }
        }
        catch(Exception e) {
            ExceptionHandler.displayException(e);
            e.printStackTrace();
        }
    }//GEN-LAST:event_okButton1ActionPerformed

    /**
     * Returns to the previous window.
     *
     * @param evt an action event
     */               
    
    private void backButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButton1ActionPerformed
        mainTabbedPane.setSelectedIndex((mainTabbedPane.getSelectedIndex())-1);
    }//GEN-LAST:event_backButton1ActionPerformed

    /**
     * Cancels the dialog.
     *
     * @param evt an action event
     */
      
    private void cancelButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButton3ActionPerformed
        cancel(); 
    }//GEN-LAST:event_cancelButton3ActionPerformed

    /**
     * Resets the null data values to their original values.
     *
     * @param evt an action event
     */
    
    private void resetNullButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetNullButtonActionPerformed
        otherTable.setValueAt(GlobalUnitsReader.getDefaultNullValue(),0,1);
//        otherTable.setValueAt(-999.000,1,1);
//        otherTable.setValueAt(-999.000,2,1);
    }//GEN-LAST:event_resetNullButtonActionPerformed

    /**
     * Resets the support table and removes any existing support object for the
     * forecasts.
     *
     * @param evt an action event
     */
    
    private void resetForcSupportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetForcSupportActionPerformed
        forecastModel.clearSupport(); 
    }//GEN-LAST:event_resetForcSupportActionPerformed

    /**
     * Resets the support table and removes any existing support object for the
     * observations.
     *
     * @param evt an action event
     */
    
    private void resetObsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetObsButtonActionPerformed
        observedModel.clearSupport(); 
    }//GEN-LAST:event_resetObsButtonActionPerformed
        
    /**
     * Cancels the dialog.
     *
     * @param evt an action event
     */
    
    private void cancelButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButton2ActionPerformed
        cancel();
    }//GEN-LAST:event_cancelButton2ActionPerformed

    /**
     * Returns to the previous window.
     *
     * @param evt an action event
     */
    
    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        mainTabbedPane.setSelectedIndex((mainTabbedPane.getSelectedIndex())-1);
    }//GEN-LAST:event_backButtonActionPerformed
    
    /**
     * Exits the dialog, accepting any changes made.
     *
     * @param evt an action event
     */
    
    private void okButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_okButtonActionPerformed
        try {
            saveData();
            exit();
        }
        catch(Exception e) {
            ExceptionHandler.displayException(e);
            e.printStackTrace();
        }
    }//GEN-LAST:event_okButtonActionPerformed
    
    /**
     * Cancels the dialog.
     *
     * @param evt an action event
     */
    
    private void cancelButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButton1ActionPerformed
        cancel();
    }//GEN-LAST:event_cancelButton1ActionPerformed
    
    /**
     * Cancels the dialog.
     */
    
    private void cancel() {
        clearDisplay();
        exit();
    }
    
    /**
     * Moves to the next window.
     *
     * @param evt an action event
     */
    
    private void nextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextButtonActionPerformed
        mainTabbedPane.setSelectedIndex((mainTabbedPane.getSelectedIndex())+1);
    }//GEN-LAST:event_nextButtonActionPerformed
    
    /**
     * Exits the dialog.
     *
     * @param evt a window event.
     */
    
    private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
        cancel();
    }//GEN-LAST:event_closeDialog
    
    /**
     * Exits.
     */
    
    private void exit() {
        setVisible(false);
    }
    
    /********************************************************************************
     *                                                                              *
     *                              INSTANCE VARIABLES                              *
     *                                                                              *
     *******************************************************************************/    
    
    /**
     * Scale table for the forecasts.
     */
    
    private ScaleTableModel forecastModel = null;
    
    /**
     * Scale table for the observations.
     */
    
    private ScaleTableModel observedModel = null;    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.JButton backButton1;
    private javax.swing.JButton cancelButton1;
    private javax.swing.JButton cancelButton2;
    private javax.swing.JButton cancelButton3;
    private javax.swing.JPanel forecastPanel;
    private javax.swing.JTable forecastTable;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14121;
    private javax.swing.JPanel jPanel141211;
    private javax.swing.JPanel jPanel141212;
    private javax.swing.JPanel jPanel141213;
    private javax.swing.JPanel jPanel14124;
    private javax.swing.JPanel jPanel14125;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel202;
    private javax.swing.JPanel jPanel203;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel511;
    private javax.swing.JPanel jPanel512;
    private javax.swing.JPanel jPanel514;
    private javax.swing.JPanel jPanel53;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane131;
    private javax.swing.JScrollPane jScrollPane132;
    private javax.swing.JScrollPane jScrollPane134;
    private javax.swing.JTabbedPane mainTabbedPane;
    private javax.swing.JButton nextButton;
    private javax.swing.JButton nextButton1;
    private javax.swing.JPanel observedPanel;
    private javax.swing.JTable observedTable;
    private javax.swing.JButton okButton;
    private javax.swing.JButton okButton1;
    private javax.swing.JPanel otherOptionsPanel;
    private javax.swing.JTable otherTable;
    private javax.swing.JButton resetForcSupport;
    private javax.swing.JButton resetNullButton;
    private javax.swing.JButton resetObsButton;
    // End of variables declaration//GEN-END:variables

}
