package evs.gui.windows;

//Java swing dependencies
import javax.swing.JPanel;
import javax.swing.JCheckBox;
import javax.swing.BoxLayout; 
import javax.swing.BorderFactory;

//Java awt dependencies
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;

//Java util dependencies
import evs.analysisunits.VerificationUnit;

/**
 * Constructs a dialog of output options.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public class MoreOutputOptions extends SimpleDialog implements GUICommunicator {

/*******************************************************************************
 *                                                                             *
 *                               CONSTRUCTORS                                  *
 *                                                                             *
 ******************************************************************************/  

    /**
     * Construct an options dialog.
     *
     * @param title the dialog title
     */
    
    protected MoreOutputOptions(String title) {
        super(title);
        setProperties(); 
        setSize(450,360);
    }    
    
    /**
     * Construct an options dialog with a parent dialog and modal status.
     * 
     * @param title the dialog title
     * @param modal is true to set the dialog modal
     */
    
    protected MoreOutputOptions(String title, boolean modal) {
        super(title,modal);
        setProperties(); 
        setSize(450,360);
    }
    
/*******************************************************************************
 *                                                                             *
 *                              PROTECTED METHODS                              *
 *                                                                             *
 ******************************************************************************/                  
    
    /**
     * Override the superclass method.
     *
     * @param exitStatus the exit status
     */
    
    protected void close(int exitStatus) {
        switch(exitStatus) {
            case OK_EXIT: {
                if(vu != null) {
                    vu.setWriteConditionalPairs(condPairsCheckBox.isSelected());
                    vu.setWriteUnconditionalPairs(uncondPairsCheckBox.isSelected());
                }
                vu = null; //Always reset the local pointer on exit
            }; break;
        }
        super.close(exitStatus);
    }    
    
    /**
     * Sets the properties of the dialog.
     */
    
    protected void setProperties() {
        JPanel main = new JPanel();
        condPairsCheckBox = new JCheckBox();
        uncondPairsCheckBox = new JCheckBox();
        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));

        //Write conditional pairs
        condPairsCheckBox.setFont(new Font("Verdana", 0, 11));
        condPairsCheckBox.setText("Write conditional pairs.");
        condPairsCheckBox.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        condPairsCheckBox.setMargin(new Insets(0, 0, 0, 0));
        condPairsCheckBox.setMaximumSize(new Dimension(32000, 30));
        condPairsCheckBox.setMinimumSize(new Dimension(400, 30));
        condPairsCheckBox.setPreferredSize(new Dimension(32000, 30));
        main.add(condPairsCheckBox);
        
        //Write unconditional pairs
        uncondPairsCheckBox.setFont(new Font("Verdana", 0, 11));
        uncondPairsCheckBox.setText("Write unconditional pairs.");
        uncondPairsCheckBox.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        uncondPairsCheckBox.setMargin(new Insets(0, 0, 0, 0));
        uncondPairsCheckBox.setMaximumSize(new Dimension(32000, 30));
        uncondPairsCheckBox.setMinimumSize(new Dimension(400, 30));
        uncondPairsCheckBox.setPreferredSize(new Dimension(32000, 30));        
        main.add(uncondPairsCheckBox);
        
        addMainPanel(main);
    }
    
    /**
     * Set the verification unit associated with the current dialog.
     * 
     * @param vu the verification unit
     */
    
    protected void setVerificationUnit(VerificationUnit vu) {
        this.vu = vu;
        condPairsCheckBox.setSelected(vu.isWriteConditionalPairs());
        uncondPairsCheckBox.setSelected(vu.isWriteUnconditionalPairs());
    }
    /*******************************************************************************
     *                                                                             *
     *                              INSTANCE VARIABLES                             *
     *                                                                             *
     ******************************************************************************/
    
    /**
     * Verification unit associated with the dialog.
     */
    
    private VerificationUnit vu = null;
    
    /**
     * Check box for writing conditional pairs.
     */
    
    private JCheckBox condPairsCheckBox;
    
    /**
     * Check box for writing conditional pairs.
     */
    
    private JCheckBox uncondPairsCheckBox;    
    
    /**
     * Test method.
     *
     * @param args
     */

    public static void main(String[] args) {
        MoreOutputOptions p = new MoreOutputOptions("Test");
        p.setVisible(true);
    }


}
