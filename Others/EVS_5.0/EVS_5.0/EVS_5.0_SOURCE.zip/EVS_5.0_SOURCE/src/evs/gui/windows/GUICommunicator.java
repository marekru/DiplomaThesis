package evs.gui.windows;

/**
 * Allows any window to access another window and its associated methods.
 *
 * @author evs@hydrosolved.com
 * @version 4.0
 */

public interface GUICommunicator {
    
    /**
     * Instance of VerificationA
     */
    
    static final VerificationA VERIFICATION_A = new VerificationA();
    
    /**
     * Instance of VerificationB
     */
    
    static final VerificationB VERIFICATION_B = new VerificationB();
    
    /**
     * Instance of AggregationA
     */
    
    static final AggregationA AGGREGATION_A = new AggregationA();    
    
    /**
     * Instance of OutputA
     */
    
    static final OutputA OUTPUT_A = new OutputA();    
    
    /**
     * Instance of Console
     */
    
    static final Console CONSOLE = new Console(false);
    
}
